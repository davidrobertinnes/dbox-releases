// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Securities — FY Tax Summary */

async function pageTaxSummary() {
  const content = document.getElementById('module-content');

  const today     = new Date();
  const currentFy = today.getMonth() >= 6 ? today.getFullYear() + 1 : today.getFullYear();

  content.innerHTML = `
    <div class="st-toolbar" id="ts-toolbar">
      <label style="font-size:13px;color:var(--ink2);font-weight:500">Financial Year ending 30 June</label>
      <select id="ts-fy" style="padding:7px 12px;border:1px solid var(--border);border-radius:7px;background:var(--surface);font-size:13px;font-family:inherit;color:var(--ink);outline:none">
        ${[0,1,2,3,4].map(i => {
          const y = currentFy - i;
          return `<option value="${y}" ${i === 0 ? 'selected' : ''}>${y} (${y-1}–${y})</option>`;
        }).join('')}
      </select>
      <button class="btn btn-secondary" onclick="_tsLoad()">Load</button>
      <button class="btn btn-ghost" id="ts-export-btn" style="margin-left:auto" onclick="_tsExport()">Export CSV</button>
      <button class="btn btn-ghost" onclick="_tsExportPdf()">Export PDF</button>
      <button class="btn btn-ghost" onclick="window.print()">Print Summary</button>
    </div>
    <div id="ts-content"></div>`;

  await _tsLoad();
}

async function _tsLoad() {
  const fy = parseInt(document.getElementById('ts-fy').value);
  const el = document.getElementById('ts-content');
  el.innerHTML = '<div class="st-empty"><div class="st-empty-icon">⏳</div>Loading…</div>';
  try {
    const [cgtRows, divs, rocGains, cfData] = await Promise.all([
      apiFetch(`/api/cgt?fy=${fy}`),
      apiFetch(`/api/dividends?fy=${fy}`),
      apiFetch(`/api/roc-cgt?fy=${fy}`),
      apiFetch(`/api/cgt-carryforward?fy=${fy}`),
    ]);
    _tsRender(cgtRows, divs, rocGains, fy, cfData.carry_forward || 0);
  } catch (e) {
    toast(e.message, 'err');
  }
}

function _tsRender(cgtRows, divs, rocGains, fy, carryforward) {
  const el = document.getElementById('ts-content');

  const entityType  = _appSettings?.entity_type || 'individual';
  const discFactor  = { individual: 0.5, smsf_accumulation: 1/3, smsf_pension: 0, company: 1 }[entityType] ?? 0.5;
  const discLabel   = { individual: '50%', smsf_accumulation: '1/3', smsf_pension: 'Fully exempt', company: 'None (company)' }[entityType] ?? '50%';
  const entityLabel = {
    individual:        'Individual',
    smsf_accumulation: 'SMSF (Accumulation Phase)',
    smsf_pension:      'SMSF (Pension Phase)',
    company:           'Company',
  }[entityType] ?? 'Individual';
  carryforward = carryforward || 0;
  const isExempt     = entityType === 'smsf_pension';

  // ── Dividends ──────────────────────────────────────────────────────────────
  const divFrankedRows   = divs.filter(d => (d.franking_pct > 0) || (d.franking_credit > 0));
  const divUnfrankedRows = divs.filter(d => !(d.franking_pct > 0) && !(d.franking_credit > 0));

  const ato11J = divUnfrankedRows.reduce((s, d) => s + (d.net_amount || 0), 0);
  const ato11K = divFrankedRows.reduce((s,  d) => s + (d.net_amount || 0), 0);

  const frankEligible   = divs.reduce((s, d) => d.eligible_45day !== false ? s + (d.franking_credit || 0) : s, 0);
  const frankIneligible = divs.reduce((s, d) => d.eligible_45day === false  ? s + (d.franking_credit || 0) : s, 0);
  const frankUnknown    = divs.reduce((s, d) => d.eligible_45day === null   ? s + (d.franking_credit || 0) : s, 0);
  const ato11L          = frankEligible;  // confirmed eligible only; unknown shown separately
  const divAssessable   = ato11J + ato11K + frankEligible;  // grossed-up dividend income

  // ── CGT — sales ────────────────────────────────────────────────────────────
  // Short-term (not discount-eligible)
  const shortRows      = cgtRows.filter(r => !r.discount_eligible);
  const shortGains     = shortRows.reduce((s, r) => r.gain_loss > 0 ? s + r.gain_loss     : s, 0);
  const shortLosses    = shortRows.reduce((s, r) => r.gain_loss < 0 ? s + Math.abs(r.gain_loss) : s, 0);

  // Discount-eligible (≥ 12 months)
  const discRows       = cgtRows.filter(r => r.discount_eligible);
  const discGrossGains = discRows.reduce((s, r) => r.gain_loss > 0 ? s + r.gain_loss           : s, 0);
  const discGrossLoss  = discRows.reduce((s, r) => r.gain_loss < 0 ? s + Math.abs(r.gain_loss) : s, 0);
  const discApplied    = isExempt ? discGrossGains : discGrossGains * discFactor;
  const discNet        = discGrossGains - discApplied - discGrossLoss;

  // ROC capital gains
  const rocGrossTotal  = rocGains.reduce((s, r) => s + r.excess_cg, 0);
  const rocDiscApplied = isExempt
    ? rocGrossTotal
    : rocGains.reduce((s, r) => r.discount_eligible ? s + r.excess_cg * discFactor : s, 0);
  const rocNet         = rocGrossTotal - rocDiscApplied;

  // Net (mirrors combinedDisc in cgt.js — use discounted_gain where available)
  const salesNet  = cgtRows.reduce((s, r) => s + (r.discounted_gain !== null ? r.discounted_gain : r.gain_loss), 0);
  const combined  = salesNet + rocNet;
  const netGainAmt    = Math.max(0, combined);
  const netLossAmt    = Math.max(0, -combined);
  const carryUsed     = Math.min(carryforward, netGainAmt);
  const ato18A        = Math.max(0, netGainAmt - carryUsed);
  const carryRemaining = carryforward - carryUsed;
  const ato18H         = shortGains + discGrossGains + rocGrossTotal;

  // ── Overall ────────────────────────────────────────────────────────────────
  const totalAssessable = divAssessable + ato18A;

  el.innerHTML = `
  <div class="ts-wrapper" id="ts-printable">

    <div class="ts-header">
      <div>
        <div class="ts-title">FY Tax Summary — Year Ending 30 June ${fy}</div>
        <div class="ts-subtitle">Entity: ${entityLabel}&nbsp;&nbsp;·&nbsp;&nbsp;${fy-1}–${fy} Financial Year</div>
      </div>
      <div class="ts-disclaimer">Summary only — verify figures with your accountant before lodging.</div>
    </div>

    <!-- ── Dividend Income ─────────────────────────────────────────────── -->
    <div class="ts-section">
      <div class="ts-section-title">
        Dividend Income
        <span class="ts-section-ref">Individual Tax Return — Item 11</span>
      </div>

      ${_tsRow('Unfranked dividend amount', fmtCurrency(ato11J), '11J')}
      ${_tsRow('Franked dividend amount (net received)', fmtCurrency(ato11K), '11K')}
      ${_tsRow('Franking credits (claimable tax offset)', fmtCurrency(ato11L), '11L', 'col-accent')}
      <hr class="ts-sep">
      ${_tsRow('Total dividend income (assessable)', fmtCurrency(divAssessable), null, null, true)}
      <div class="ts-note">Assessable income = net dividends + eligible franking credits (grossed-up). Franking credits are declared separately as a tax offset (Item 11L).</div>

      ${frankIneligible > 0 ? `<div class="ts-alert ts-alert-red">
        ⚠ ${fmtCurrency(frankIneligible)} in franking credits excluded from 11L — 45-day holding period rule not satisfied.
        Review flagged dividends in <strong>CGT Summary</strong>.
      </div>` : ''}
      ${frankUnknown > 0 ? `<div class="ts-alert ts-alert-amber">
        ? ${fmtCurrency(frankUnknown)} in franking credits are unverified — add ex-dividend dates to confirm 45-day eligibility.
        Until verified, these have been excluded from 11L.
      </div>` : ''}
      ${!divs.length ? `<div class="ts-empty-note">No dividends recorded for FY${fy}.</div>` : ''}
    </div>

    <!-- ── Capital Gains ───────────────────────────────────────────────── -->
    <div class="ts-section">
      <div class="ts-section-title">
        Capital Gains
        <span class="ts-section-ref">Individual Tax Return — Item 18</span>
      </div>

      ${shortGains > 0 || shortLosses > 0 ? `
      <div class="ts-subsection">Short-term disposals — held &lt; 12 months (no discount)</div>
      ${shortGains  > 0 ? _tsRow('Gains', fmtCurrency(shortGains), null, null, false, true) : ''}
      ${shortLosses > 0 ? _tsRow('Losses', '(' + fmtCurrency(shortLosses) + ')', null, 'col-red', false, true) : ''}
      <hr class="ts-sep">` : ''}

      ${discGrossGains > 0 || discGrossLoss > 0 ? `
      <div class="ts-subsection">Discount-eligible disposals — held ≥ 12 months</div>
      ${_tsRow('Gross gains', fmtCurrency(discGrossGains), null, null, false, true)}
      ${_tsRow(`Less: ${discLabel} CGT discount`, isExempt ? 'Fully exempt' : '(' + fmtCurrency(discApplied) + ')', null, isExempt ? 'col-green' : 'col-red', false, true)}
      ${discGrossLoss > 0 ? _tsRow('Losses', '(' + fmtCurrency(discGrossLoss) + ')', null, 'col-red', false, true) : ''}
      <hr class="ts-sep">` : ''}

      ${rocGrossTotal > 0 ? `
      <div class="ts-subsection">Return of capital — cost base exceeded</div>
      ${_tsRow('Excess capital gain (gross)', fmtCurrency(rocGrossTotal), null, 'col-red', false, true)}
      ${rocDiscApplied > 0 ? _tsRow(`Less: ${discLabel} CGT discount`, '(' + fmtCurrency(rocDiscApplied) + ')', null, 'col-red', false, true) : ''}
      <hr class="ts-sep">` : ''}

      ${cgtRows.length || rocGains.length ? `
      ${_tsRow('Net capital gain / (loss)', combined >= 0 ? fmtCurrency(combined) : '(' + fmtCurrency(netLossAmt) + ')', null, combined < 0 ? 'col-red' : '')}
      ${carryforward > 0 ? _tsRow('Less: prior year losses applied', carryUsed > 0 ? '(' + fmtCurrency(carryUsed) + ')' : '—', null, carryUsed > 0 ? 'col-red' : 'col-ink3') : ''}
      <hr class="ts-sep">
      ${_tsRow('Net capital gain', fmtCurrency(ato18A), '18A', ato18A > 0 ? '' : 'col-ink3', true)}
      <div style="margin-top:6px">
        ${_tsRow('Total current year capital gains (before discount/losses)', fmtCurrency(ato18H), '18H')}
      </div>
      ${carryRemaining > 0 ? `<div class="ts-note">Carry-forward loss remaining for next year: ${fmtCurrency(carryRemaining)}</div>` : ''}
      ${netLossAmt > 0 ? `<div class="ts-note">Net capital loss of ${fmtCurrency(netLossAmt)} will be included in the carry-forward balance for next year (auto-computed).</div>` : ''}
      ` : `<div class="ts-empty-note">No disposals recorded for FY${fy}.</div>`}
    </div>

    <!-- ── Tax Position Summary ────────────────────────────────────────── -->
    <div class="ts-section ts-section-summary">
      <div class="ts-section-title">Tax Position Summary</div>

      <div class="ts-summary-grid">
        <div class="ts-summary-block">
          <div class="ts-summary-label">Assessable Dividend Income</div>
          <div class="ts-summary-value">${fmtCurrency(divAssessable)}</div>
          <div class="ts-summary-sub">net dividends + eligible franking credits</div>
        </div>
        <div class="ts-summary-block">
          <div class="ts-summary-label">Net Capital Gain (Item 18A)</div>
          <div class="ts-summary-value">${fmtCurrency(ato18A)}</div>
          <div class="ts-summary-sub">after discount, losses &amp; carry-forward</div>
        </div>
        <div class="ts-summary-block ts-summary-block-total">
          <div class="ts-summary-label">Total Assessable Investment Income</div>
          <div class="ts-summary-value">${fmtCurrency(totalAssessable)}</div>
          <div class="ts-summary-sub">dividends + capital gains</div>
        </div>
        ${ato11L > 0 ? `
        <div class="ts-summary-block ts-summary-block-offset">
          <div class="ts-summary-label">Franking Credit Tax Offset (Item 11L)</div>
          <div class="ts-summary-value col-accent">${fmtCurrency(ato11L)}</div>
          <div class="ts-summary-sub">reduces tax payable — enter as tax offset in your return</div>
        </div>` : ''}
      </div>
    </div>

    <div class="ts-footer">
      Dogbox Investments &nbsp;·&nbsp; FY${fy} Tax Summary &nbsp;·&nbsp; Generated ${new Date().toLocaleDateString('en-AU')}
      &nbsp;·&nbsp; This is not tax advice.
    </div>
  </div>`;
}

function _tsExport() {
  const fy = document.getElementById('ts-fy').value;
  window.location.href = `/api/export/tax-summary.csv?fy=${fy}`;
}

function _tsExportPdf() {
  const fy = document.getElementById('ts-fy').value;
  window.location.href = `/api/export/tax-summary-fy${fy}.pdf`;
}

function _tsRow(label, value, atoRef, colorClass, isTtl, isIndent) {
  return `<div class="ts-row${isTtl ? ' ts-row-total' : ''}">
    <div class="ts-label${isIndent ? ' ts-label-indent' : ''}">
      ${label}
      ${atoRef ? `<span class="ts-ato-ref">${atoRef}</span>` : ''}
    </div>
    <div class="ts-value${colorClass ? ' ' + colorClass : ''}${isTtl ? ' ts-value-total' : ''}">${value}</div>
  </div>`;
}
