// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — Transactions (buys + sells) with edit/delete */

async function pageTransactions() {
  const content = document.getElementById('module-content');
  content.innerHTML = `
    <div class="st-toolbar">
      <input class="st-search" id="tx-search" type="search" placeholder="Search transactions…">
      <span style="font-size:12px;color:var(--ink3)">From</span>
      <input type="date" id="tx-from" style="padding:6px 10px;border:1px solid var(--border);border-radius:7px;background:var(--surface);font-size:12px;font-family:inherit;color:var(--ink);outline:none">
      <span style="font-size:12px;color:var(--ink3)">To</span>
      <input type="date" id="tx-to" style="padding:6px 10px;border:1px solid var(--border);border-radius:7px;background:var(--surface);font-size:12px;font-family:inherit;color:var(--ink);outline:none">
      <button class="btn btn-ghost btn-sm" onclick="_txClearFilters()">Clear</button>
      <button class="btn btn-secondary" onclick="_txOpenBuyCreate()">+ Buy</button>
      <button class="btn btn-primary" onclick="_txOpenSell()">Record Sale</button>
    </div>
    <div class="st-list-panel">
      <div class="tbl-overflow">
        <table class="st-table" id="tx-table">
          <thead><tr>
            <th>Date</th><th>Type</th><th>Code</th><th class="num">Qty</th>
            <th class="num">Price</th><th class="num">Brokerage</th>
            <th class="num">Total</th><th></th>
          </tr></thead>
          <tbody id="tx-tbody"></tbody>
        </table>
      </div>
    </div>
    <div class="count-pill" id="tx-count"></div>`;

  document.getElementById('tx-search').addEventListener('input', _txFilter);
  document.getElementById('tx-from').addEventListener('change', _txFilter);
  document.getElementById('tx-to').addEventListener('change', _txFilter);
  await _txLoad();
}

let _txRows = [];
let _txSecurities = [];

async function _txLoad() {
  try {
    const [parcels, sales, securities] = await Promise.all([
      apiFetch('/api/parcels'),
      apiFetch('/api/sales'),
      apiFetch('/api/securities'),
    ]);
    _txSecurities = securities;
    _txRows = [
      ...parcels.map(p => ({ ...p, tx_type: 'Buy',  date: p.acquisition_date, total: p.cost_base })),
      ...sales.map(s =>   ({ ...s, tx_type: 'Sale', date: s.sale_date,         total: s.net_proceeds })),
    ].sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id);
    _txRender();
  } catch (e) {
    toast(e.message, 'err');
  }
}

function _txFilter() {
  const q    = document.getElementById('tx-search').value.toLowerCase();
  const from = document.getElementById('tx-from').value;
  const to   = document.getElementById('tx-to').value;
  let visible = 0;
  document.querySelectorAll('#tx-tbody tr').forEach(r => {
    const date    = r.dataset.date || '';
    const inRange = (!from || date >= from) && (!to || date <= to);
    const match   = inRange && r.textContent.toLowerCase().includes(q);
    r.style.display = match ? '' : 'none';
    if (match) visible++;
  });
  document.getElementById('tx-count').textContent = `${visible} of ${_txRows.length} transactions`;
}

function _txClearFilters() {
  document.getElementById('tx-search').value = '';
  document.getElementById('tx-from').value   = '';
  document.getElementById('tx-to').value     = '';
  _txFilter();
}

function _txRender() {
  const tbody = document.getElementById('tx-tbody');
  if (!_txRows.length) {
    tbody.innerHTML = `<tr><td colspan="8"><div class="st-empty">
      <div class="st-empty-icon">↕</div>
      <div class="st-empty-title">No transactions yet</div>
    </div></td></tr>`;
    document.getElementById('tx-count').textContent = '0 transactions';
    return;
  }
  tbody.innerHTML = _txRows.map(t => {
    const isBuy = t.tx_type === 'Buy';
    const locked = _isLocked(t.date);
    const actionCell = locked
      ? '<span class="badge badge-amber" title="FY locked — cannot modify after lodgement">Locked</span>'
      : `<button class="btn btn-ghost btn-sm" onclick="_txEdit('${t.tx_type}',${t.id})">Edit</button>
         <button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="_txDelete('${t.tx_type}',${t.id})">Del</button>`;
    return `<tr data-date="${t.date}">
      <td class="mono">${fmtDate(t.date)}</td>
      <td><span class="badge ${isBuy ? 'badge-accent' : 'badge-amber'}">${t.tx_type}</span></td>
      <td class="code-cell">${t.code}</td>
      <td class="num mono">${fmtNum(t.quantity, 4)}</td>
      <td class="num mono">${fmtCurrency(t.price_per_unit)}</td>
      <td class="num mono">${fmtCurrency(t.brokerage)}</td>
      <td class="num mono">${fmtCurrency(t.total)}</td>
      <td style="white-space:nowrap">${actionCell}</td>
    </tr>`;
  }).join('');
  document.getElementById('tx-count').textContent = `${_txRows.length} transactions`;
}

// ── Edit / delete dispatch ────────────────────────────────────────────────────

function _txEdit(type, id) {
  const row = _txRows.find(r => r.tx_type === type && r.id === id);
  if (!row) return toast('Record not found', 'err');
  if (type === 'Buy')  _txOpenBuyEdit(row);
  if (type === 'Sale') _txOpenSellEdit(row);
}

async function _txDelete(type, id) {
  const label = type === 'Buy' ? 'purchase parcel' : 'sale';
  if (!confirm(`Delete this ${label}? This cannot be undone.`)) return;
  const url = type === 'Buy' ? `/api/parcels/${id}` : `/api/sales/${id}`;
  try {
    const r = await fetch(url, { method: 'DELETE' }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    toast(`${type === 'Buy' ? 'Purchase' : 'Sale'} deleted`);
    await _txLoad();
  } catch (e) {
    toast(e.message, 'err');
  }
}

// ── Buy form (create) ─────────────────────────────────────────────────────────

function _txOpenBuyCreate() {
  const secOptions = _txSecurities.map(s =>
    `<option value="${s.id}">${s.code} — ${s.name}</option>`
  ).join('');
  openPanel('Record Purchase', _txBuyFormHtml(secOptions), `
    <button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
    <button class="btn btn-primary" onclick="_txSaveBuy(null)">Save Purchase</button>`);
}

function _txOpenBuyEdit(parcel) {
  const secOptions = _txSecurities.map(s =>
    `<option value="${s.id}" ${s.id === parcel.security_id ? 'selected' : ''}>${s.code} — ${s.name}</option>`
  ).join('');
  openPanel('Edit Purchase', _txBuyFormHtml(secOptions, parcel), `
    <button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
    <button class="btn btn-primary" onclick="_txSaveBuy(${parcel.id})">Save Changes</button>`);
}

function _txBuyFormHtml(secOptions, p = {}) {
  return `
    <div class="field">
      <label>Security</label>
      <select id="buy-security" ${p.id ? 'disabled' : ''}>
        <option value="">Select…</option>${secOptions}
      </select>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Acquisition Date</label>
        <input type="date" id="buy-date" value="${p.acquisition_date || new Date().toISOString().slice(0,10)}">
      </div>
      <div class="field"><label>Quantity</label>
        <input type="number" id="buy-qty" min="0" step="any" value="${p.quantity || ''}" placeholder="0"
          ${p.id && p.quantity !== p.quantity_remaining ? 'title="Parcel partially sold — quantity locked" readonly style=background:var(--row-alt)' : ''}>
      </div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Price Per Unit ($)</label>
        <input type="number" id="buy-price" min="0" step="any" value="${p.price_per_unit || ''}" placeholder="0.00">
      </div>
      <div class="field"><label>Brokerage ($)</label>
        <input type="number" id="buy-brokerage" min="0" step="any" value="${p.brokerage || ''}" placeholder="0.00">
      </div>
    </div>
    <div class="field"><label>Other Costs ($)</label>
      <input type="number" id="buy-other" min="0" step="any" value="${p.other_costs || ''}" placeholder="0.00">
    </div>
    <div class="field"><label>Notes</label>
      <textarea id="buy-notes" placeholder="Optional">${p.notes || ''}</textarea>
    </div>`;
}

async function _txSaveBuy(parcelId) {
  const security_id    = parcelId
    ? _txRows.find(r => r.tx_type === 'Buy' && r.id === parcelId)?.security_id
    : document.getElementById('buy-security').value;
  const acquisition_date = document.getElementById('buy-date').value;
  const quantity       = document.getElementById('buy-qty').value;
  const price_per_unit = document.getElementById('buy-price').value;
  const brokerage      = document.getElementById('buy-brokerage').value || '0';
  const other_costs    = document.getElementById('buy-other').value || '0';
  const notes          = document.getElementById('buy-notes').value;

  if (!security_id)    return toast('Select a security', 'err');
  if (!acquisition_date) return toast('Acquisition date is required', 'err');
  if (!quantity || parseFloat(quantity) <= 0) return toast('Quantity must be > 0', 'err');
  if (!price_per_unit || parseFloat(price_per_unit) <= 0) return toast('Price must be > 0', 'err');

  const url    = parcelId ? `/api/parcels/${parcelId}` : '/api/parcels';
  const method = parcelId ? 'PUT' : 'POST';
  try {
    const r = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ security_id, acquisition_date, quantity, price_per_unit,
                             brokerage, other_costs, notes }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    toast(parcelId ? 'Purchase updated' : 'Purchase recorded');
    await _txLoad();
  } catch (e) {
    toast(e.message, 'err');
  }
}

// ── Sell form (create) ────────────────────────────────────────────────────────

function _txOpenSell() {
  const secOptions = _txSecurities.map(s =>
    `<option value="${s.id}">${s.code} — ${s.name}</option>`
  ).join('');
  openPanel('Record Sale', _txSellFormHtml(secOptions), `
    <button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
    <button class="btn btn-primary" onclick="_txSaveSell(null)">Record Sale</button>`);
}

function _txOpenSellEdit(sale) {
  const secOptions = _txSecurities.map(s =>
    `<option value="${s.id}" ${s.id === sale.security_id ? 'selected' : ''}>${s.code} — ${s.name}</option>`
  ).join('');
  openPanel('Edit Sale', _txSellFormHtml(secOptions, sale), `
    <button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
    <button class="btn btn-primary" onclick="_txSaveSell(${sale.id})">Save Changes</button>`);
}

function _txSellFormHtml(secOptions, s = {}) {
  return `
    <div class="field">
      <label>Security</label>
      <select id="sell-security" ${s.id ? 'disabled' : ''} onchange="_txSellInputChanged()">
        <option value="">Select…</option>${secOptions}
      </select>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Sale Date</label>
        <input type="date" id="sell-date" value="${s.sale_date || new Date().toISOString().slice(0,10)}">
      </div>
      <div class="field"><label>Quantity</label>
        <input type="number" id="sell-qty" min="0" step="any" value="${s.quantity || ''}" placeholder="0">
      </div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Price Per Unit ($)</label>
        <input type="number" id="sell-price" min="0" step="any" value="${s.price_per_unit || ''}" placeholder="0.00">
      </div>
      <div class="field"><label>Brokerage ($)</label>
        <input type="number" id="sell-brokerage" min="0" step="any" value="${s.brokerage || ''}" placeholder="0.00">
      </div>
    </div>
    <div class="field"><label>CGT Method</label>
      <select id="sell-method" onchange="_txSellInputChanged()">
        <option value="fifo"     ${(s.cgt_method||'fifo')==='fifo'     ? 'selected':''}>FIFO — First In, First Out</option>
        <option value="mingain"  ${s.cgt_method==='mingain'  ? 'selected':''}>Min Gain — Highest Cost Base First</option>
        <option value="maxgain"  ${s.cgt_method==='maxgain'  ? 'selected':''}>Max Gain — Lowest Cost Base First</option>
        <option value="specific" ${s.cgt_method==='specific' ? 'selected':''}>Specific Parcels</option>
      </select>
    </div>
    <div id="sell-parcel-picker" style="display:none">
      <div style="font-size:11px;color:var(--ink3);margin-bottom:6px">Select parcels to sell from (consumed in order checked):</div>
      <div id="sell-parcel-list"></div>
    </div>
    <div class="field"><label>Notes</label>
      <textarea id="sell-notes" placeholder="Optional">${s.notes || ''}</textarea>
    </div>`;
}

async function _txSellInputChanged() {
  const method = document.getElementById('sell-method')?.value;
  const picker = document.getElementById('sell-parcel-picker');
  if (!picker) return;
  if (method !== 'specific') { picker.style.display = 'none'; return; }
  const secId = document.getElementById('sell-security')?.value;
  if (!secId) { picker.style.display = 'none'; return; }
  picker.style.display = '';
  document.getElementById('sell-parcel-list').innerHTML = '<div style="color:var(--ink3);font-size:12px">Loading…</div>';
  try {
    const parcels = await apiFetch(`/api/parcels?security_id=${secId}&open_only=1`);
    document.getElementById('sell-parcel-list').innerHTML = _txParcelPickerHtml(parcels);
  } catch (e) {
    document.getElementById('sell-parcel-list').innerHTML = `<div style="color:var(--red);font-size:12px">${e.message}</div>`;
  }
}

function _txParcelPickerHtml(parcels) {
  if (!parcels.length) return '<div style="color:var(--ink3);font-size:12px">No open parcels found</div>';
  const today = new Date();
  return parcels.map(p => {
    const days = Math.floor((today - new Date(p.acquisition_date)) / 86400000);
    const disc = days > 365 ? '<span class="badge badge-green" style="font-size:10px">Disc</span>' : '';
    return `<label style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border);cursor:pointer;font-size:12px">
      <input type="checkbox" data-parcel-id="${p.id}" style="flex-shrink:0">
      <span style="flex:1;font-family:'DM Mono',monospace">${fmtDate(p.acquisition_date)}</span>
      <span style="color:var(--ink2)">${fmtNum(p.quantity_remaining, 4)} units</span>
      <span style="color:var(--ink3)">${fmtCurrency(p.cost_base / p.quantity)}/unit</span>
      <span style="color:var(--ink3);min-width:32px;text-align:right">${days}d</span>
      ${disc}
    </label>`;
  }).join('');
}

async function _txSaveSell(saleId) {
  const security_id  = saleId
    ? _txRows.find(r => r.tx_type === 'Sale' && r.id === saleId)?.security_id
    : document.getElementById('sell-security').value;
  const sale_date    = document.getElementById('sell-date').value;
  const quantity     = document.getElementById('sell-qty').value;
  const price_per_unit = document.getElementById('sell-price').value;
  const brokerage    = document.getElementById('sell-brokerage').value || '0';
  const cgt_method   = document.getElementById('sell-method').value;
  const notes        = document.getElementById('sell-notes').value;

  if (!security_id) return toast('Select a security', 'err');
  if (!sale_date)   return toast('Sale date is required', 'err');
  if (!quantity || parseFloat(quantity) <= 0) return toast('Quantity must be > 0', 'err');
  if (!price_per_unit || parseFloat(price_per_unit) <= 0) return toast('Price must be > 0', 'err');

  let parcel_ids = null;
  if (cgt_method === 'specific') {
    parcel_ids = [...document.querySelectorAll('#sell-parcel-list input[type=checkbox]:checked')]
      .map(cb => parseInt(cb.dataset.parcelId));
    if (!parcel_ids.length) return toast('Select at least one parcel', 'err');
  }

  const url    = saleId ? `/api/sales/${saleId}` : '/api/sales';
  const method = saleId ? 'PUT' : 'POST';
  try {
    const r = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ security_id, sale_date, quantity, price_per_unit,
                             brokerage, cgt_method, notes, parcel_ids }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    toast(saleId ? 'Sale updated' : 'Sale recorded');
    await _txLoad();
  } catch (e) {
    toast(e.message, 'err');
  }
}
