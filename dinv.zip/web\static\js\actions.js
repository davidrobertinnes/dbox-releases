// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — Corporate Actions (splits and consolidations) */

async function pageActions() {
  const content = document.getElementById('module-content');
  content.innerHTML = `
    <div class="st-toolbar">
      <input class="st-search" id="act-search" type="search" placeholder="Search actions…">
      <button class="btn btn-primary" onclick="_actOpenForm(null)">+ Record Action</button>
    </div>
    <div class="st-list-panel">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Date</th><th>Code</th><th>Type</th><th>Ratio</th>
            <th>Description</th><th></th>
          </tr></thead>
          <tbody id="act-tbody"></tbody>
        </table>
      </div>
    </div>
    <div class="count-pill" id="act-count"></div>`;

  document.getElementById('act-search').addEventListener('input', () => {
    const q = document.getElementById('act-search').value.toLowerCase();
    let v = 0;
    document.querySelectorAll('#act-tbody tr').forEach(r => {
      const show = r.textContent.toLowerCase().includes(q);
      r.style.display = show ? '' : 'none';
      if (show) v++;
    });
    document.getElementById('act-count').textContent = `${v} of ${_actRows.length} actions`;
  });

  await _actLoad();
}

let _actRows = [];
let _actSecurities = [];

async function _actLoad() {
  try {
    [_actRows, _actSecurities] = await Promise.all([
      apiFetch('/api/actions'),
      apiFetch('/api/securities'),
    ]);
    _actRender();
  } catch (e) {
    toast(e.message, 'err');
  }
}

function _actRender() {
  const tbody = document.getElementById('act-tbody');
  if (!_actRows.length) {
    tbody.innerHTML = `<tr><td colspan="6"><div class="st-empty">
      <div class="st-empty-icon">🔄</div>
      <div class="st-empty-title">No corporate actions recorded</div>
      <div>Record splits, consolidations, and rights issues here.</div>
    </div></td></tr>`;
    document.getElementById('act-count').textContent = '0 actions';
    return;
  }
  tbody.innerHTML = _actRows.map(a => {
    const isRights   = a.action_type === 'rights_issue';
    const isBonus    = a.action_type === 'bonus';
    const isRoc      = a.action_type === 'return_of_capital';
    const isDemerger = a.action_type === 'demerger';
    const label = isRights   ? 'Rights Issue'
      : isBonus    ? 'Bonus Issue'
      : isRoc      ? 'Return of Capital'
      : isDemerger ? 'Demerger'
      : a.ratio_to > a.ratio_from ? 'Split' : 'Consolidation';
    const badge = (isRights || isBonus) ? 'badge-green'
      : isRoc      ? 'badge-red'
      : isDemerger ? 'badge-ink'
      : a.ratio_to > a.ratio_from ? 'badge-accent' : 'badge-amber';
    const ratioCell = isRights
      ? `${fmtNum(a.ratio_from, 0)} @ ${fmtCurrency(a.ratio_to, 4)}`
      : isBonus
      ? `${fmtNum(a.ratio_from, 0)} @ $0.00`
      : isRoc
      ? `${fmtCurrency(a.ratio_from, 4)}/unit`
      : isDemerger
      ? `${fmtNum(a.ratio_from, 1)}% retained → ${a.new_security_code || '?'} (${fmtNum(a.ratio_to, 4)}:1)`
      : `${a.ratio_to}-for-${a.ratio_from}`;
    return `<tr>
      <td class="mono">${fmtDate(a.action_date)}</td>
      <td class="code-cell">${a.code}</td>
      <td><span class="badge ${badge}">${label}</span></td>
      <td class="mono">${ratioCell}</td>
      <td style="color:var(--ink2);font-size:12px">${a.description || ''}</td>
      <td>${
        _isLocked(a.action_date)
          ? '<span class="badge badge-amber" title="FY locked — cannot modify after lodgement">Locked</span>'
          : `<button class="btn btn-ghost btn-sm" style="color:var(--red)"
              onclick="_actDelete(${a.id}, '${a.code}', ${a.ratio_from}, ${a.ratio_to}, '${a.action_type}')">Del</button>`
      }</td>
    </tr>`;
  }).join('');
  document.getElementById('act-count').textContent =
    `${_actRows.length} action${_actRows.length !== 1 ? 's' : ''}`;
}

// ── Delete ────────────────────────────────────────────────────────────────────

async function _actDelete(id, code, ratioFrom, ratioTo, actionType) {
  const msg = (actionType === 'rights_issue' || actionType === 'bonus')
    ? `Delete this ${code} ${actionType === 'bonus' ? 'bonus issue' : 'rights issue'}?\n\nThe created parcel will be removed (if not yet sold). This cannot be undone.`
    : actionType === 'return_of_capital'
    ? `Reverse and delete this ${code} return of capital ($${parseFloat(ratioFrom).toFixed(4)}/unit)?\n\nCost bases on all affected parcels will be restored. Any CGT reported from this action will no longer appear. This cannot be undone.`
    : actionType === 'demerger'
    ? `Reverse and delete this ${code} demerger?\n\nCost bases on all original ${code} parcels will be restored, and all parcels created for the demerged entity will be removed (if not yet sold). This cannot be undone.`
    : `Reverse and delete this ${code} ${ratioTo}-for-${ratioFrom} action?\n\nAll affected parcels will be reverted to their pre-action quantities. This cannot be undone.`;
  if (!confirm(msg)) return;
  try {
    const r = await fetch(`/api/actions/${id}`, { method: 'DELETE' }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    toast('Action reversed and deleted');
    await _actLoad();
  } catch (e) {
    toast(e.message, 'err');
  }
}

// ── Form ──────────────────────────────────────────────────────────────────────

function _actOpenForm(preselectedSecurityId = null) {
  const secOptions = _actSecurities.map(s =>
    `<option value="${s.id}" ${s.id === preselectedSecurityId ? 'selected' : ''}>${s.code} — ${s.name}</option>`
  ).join('');

  openPanel('Record Corporate Action', `
    <div class="field">
      <label>Security</label>
      <select id="act-security" ${preselectedSecurityId ? 'disabled' : ''}>
        <option value="">Select…</option>${secOptions}
      </select>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Action Date</label>
        <input type="date" id="act-date" value="${new Date().toISOString().slice(0,10)}">
      </div>
      <div class="field"><label>Type</label>
        <select id="act-type" onchange="_actTypeChanged()">
          <option value="split">Split</option>
          <option value="consolidation">Consolidation</option>
          <option value="bonus">Bonus Issue</option>
          <option value="rights_issue">Rights Issue</option>
          <option value="return_of_capital">Return of Capital</option>
          <option value="demerger">Demerger</option>
        </select>
      </div>
    </div>

    <div class="field" id="act-new-sec-wrap" style="display:none">
      <label>Demerged Entity <span style="font-weight:400;text-transform:none;letter-spacing:0">the new security receiving shares</span></label>
      <select id="act-new-security" onchange="_actUpdatePreview()">
        <option value="">Select demerged security…</option>
        ${_actSecurities.map(s => `<option value="${s.id}">${s.code} — ${s.name}</option>`).join('')}
      </select>
      <div style="font-size:11px;color:var(--ink3);margin-top:4px">Must already exist — add it via Securities first if needed.</div>
    </div>

    <div class="field-row cols-2">
      <div class="field">
        <label id="act-lbl-from">From (existing shares)</label>
        <input type="number" id="act-from" min="0.0001" step="1" value="1"
          oninput="_actUpdatePreview()" placeholder="1">
      </div>
      <div class="field" id="act-to-wrap">
        <label id="act-lbl-to">To (new shares received)</label>
        <input type="number" id="act-to" min="0.0001" step="1" value="2"
          oninput="_actUpdatePreview()" placeholder="2">
      </div>
    </div>

    <div id="act-preview" style="padding:10px 14px;background:var(--accent-dim);border-radius:8px;font-size:12px;color:var(--ink2);margin-bottom:14px;font-family:'DM Mono',monospace">
      2-for-1 split — each share becomes 2 shares &middot; price halves &middot; cost base unchanged
    </div>

    <div class="field"><label>Description <span style="font-weight:400;text-transform:none;letter-spacing:0">optional</span></label>
      <input type="text" id="act-desc" placeholder="e.g. ASX announcement: 2-for-1 share split">
    </div>
    <div class="field"><label>Notes</label>
      <textarea id="act-notes" placeholder="Optional"></textarea>
    </div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_actSave(${preselectedSecurityId || 'null'})">Apply Action</button>`
  );
  _actUpdatePreview();
}

function _actTypeChanged() {
  const type       = document.getElementById('act-type')?.value;
  const lblFrom    = document.getElementById('act-lbl-from');
  const lblTo      = document.getElementById('act-lbl-to');
  const toWrap     = document.getElementById('act-to-wrap');
  const newSecWrap = document.getElementById('act-new-sec-wrap');
  if (!lblFrom || !lblTo) return;
  if (newSecWrap) newSecWrap.style.display = type === 'demerger' ? '' : 'none';
  if (type === 'rights_issue') {
    lblFrom.textContent = 'Quantity subscribed';
    lblTo.textContent   = 'Subscription price ($ per share)';
    document.getElementById('act-to').step = 'any';
    if (toWrap) toWrap.style.display = '';
  } else if (type === 'bonus') {
    lblFrom.textContent = 'Bonus shares received';
    if (toWrap) toWrap.style.display = 'none';
  } else if (type === 'return_of_capital') {
    lblFrom.textContent = 'Amount per unit ($)';
    if (toWrap) toWrap.style.display = 'none';
    document.getElementById('act-from').step = 'any';
  } else if (type === 'demerger') {
    lblFrom.textContent = 'Cost base % kept by original company (e.g. 85)';
    lblTo.textContent   = 'New shares issued per original share held (e.g. 1)';
    document.getElementById('act-from').step = 'any';
    document.getElementById('act-to').step   = 'any';
    if (toWrap) toWrap.style.display = '';
  } else {
    lblFrom.textContent = 'From (existing shares)';
    lblTo.textContent   = 'To (new shares received)';
    document.getElementById('act-to').step = '1';
    if (toWrap) toWrap.style.display = '';
  }
  _actUpdatePreview();
}

function _actUpdatePreview() {
  const from = parseFloat(document.getElementById('act-from')?.value) || 0;
  const to   = parseFloat(document.getElementById('act-to')?.value)   || 0;
  const type = document.getElementById('act-type')?.value;
  const el   = document.getElementById('act-preview');
  if (!el) return;

  if (type === 'rights_issue') {
    if (from <= 0 || to <= 0) { el.textContent = 'Enter quantity and price'; return; }
    el.innerHTML = `<strong>Rights Issue</strong> &mdash; ` +
      `${fmtNum(from, 0)} shares subscribed @ ${fmtCurrency(to, 4)} each &rarr; ` +
      `new parcel cost base ${fmtCurrency(from * to)}`;
    el.style.background = 'var(--green-dim)';
    el.style.color       = 'var(--green)';
    return;
  }

  if (type === 'bonus') {
    if (from <= 0) { el.textContent = 'Enter number of bonus shares received'; return; }
    el.innerHTML = `<strong>Bonus Issue</strong> &mdash; ` +
      `${fmtNum(from, 0)} new shares &rarr; $0.00 cost base &middot; ` +
      `original parcel cost base unchanged (ATO treatment)`;
    el.style.background = 'var(--green-dim)';
    el.style.color       = 'var(--green)';
    return;
  }

  if (type === 'return_of_capital') {
    if (from <= 0) { el.textContent = 'Enter the return of capital amount per unit'; return; }
    el.innerHTML = `<strong>Return of Capital</strong> &mdash; ` +
      `${fmtCurrency(from, 4)}/unit reduces the cost base of every open parcel. ` +
      `If any parcel&#39;s cost base reaches zero, the excess becomes a capital gain for this FY.`;
    el.style.background = 'var(--red-dim, rgba(220,53,69,0.08))';
    el.style.color       = 'var(--red)';
    return;
  }

  if (type === 'demerger') {
    const newSecEl = document.getElementById('act-new-security');
    const newSecText = newSecEl?.options[newSecEl.selectedIndex]?.text || '?';
    if (from <= 0 || from >= 100) { el.textContent = 'Enter cost base % kept by the original company (1–99)'; return; }
    if (to <= 0) { el.textContent = 'Enter new shares issued per original share held'; return; }
    el.innerHTML = `<strong>Demerger</strong> &mdash; ` +
      `${fmtNum(from, 1)}% of each parcel&#39;s cost base stays with the original &middot; ` +
      `${fmtNum(100 - from, 1)}% transfers to <strong>${newSecText}</strong> &middot; ` +
      `${fmtNum(to, 4)} new share(s) per original share &middot; ` +
      `new parcels inherit original acquisition dates (ATO rollover)`;
    el.style.background = 'var(--surface2)';
    el.style.color       = 'var(--ink2)';
    return;
  }

  if (from <= 0 || to <= 0) { el.textContent = 'Enter valid ratios'; return; }
  if (Math.abs(from - to) < 0.0001) { el.textContent = 'From and To must be different'; return; }

  const multiplier = to / from;
  const isSplit = to > from;
  const typeLabel = isSplit ? 'split' : 'consolidation';

  el.innerHTML = `<strong>${to}-for-${from} ${typeLabel}</strong> &mdash; ` +
    `quantity &times;${multiplier.toFixed(4).replace(/\.?0+$/, '')} &middot; ` +
    `price &divide;${multiplier.toFixed(4).replace(/\.?0+$/, '')} &middot; ` +
    `cost base unchanged`;
  el.style.background = isSplit ? 'var(--accent-dim)' : 'var(--amber-dim)';
  el.style.color       = isSplit ? 'var(--ink2)' : 'var(--amber)';
}

async function _actSave(preselectedSecurityId) {
  const security_id = preselectedSecurityId ||
                      document.getElementById('act-security').value;
  const action_date    = document.getElementById('act-date').value;
  const action_type    = document.getElementById('act-type').value;
  const ratio_from     = document.getElementById('act-from').value;
  let   ratio_to       = document.getElementById('act-to').value;
  const description    = document.getElementById('act-desc').value;
  const notes          = document.getElementById('act-notes').value;
  const new_security_id = document.getElementById('act-new-security')?.value || null;

  if (!security_id)  return toast('Select a security', 'err');
  if (!action_date)  return toast('Action date is required', 'err');
  if (action_type === 'rights_issue') {
    if (!ratio_from || parseFloat(ratio_from) <= 0) return toast('Quantity must be > 0', 'err');
    if (!ratio_to   || parseFloat(ratio_to)   <= 0) return toast('Subscription price must be > 0', 'err');
  } else if (action_type === 'bonus') {
    if (!ratio_from || parseFloat(ratio_from) <= 0) return toast('Bonus shares must be > 0', 'err');
    ratio_to = '0';
  } else if (action_type === 'return_of_capital') {
    if (!ratio_from || parseFloat(ratio_from) <= 0) return toast('Amount per unit must be > 0', 'err');
    ratio_to = '0';
  } else if (action_type === 'demerger') {
    const pct = parseFloat(ratio_from);
    if (!ratio_from || pct <= 0 || pct >= 100) return toast('Cost base % must be between 0 and 100', 'err');
    if (!ratio_to   || parseFloat(ratio_to) <= 0) return toast('Share ratio must be > 0', 'err');
    if (!new_security_id) return toast('Select the demerged entity security', 'err');
    if (new_security_id === String(security_id)) return toast('Demerged entity must be a different security', 'err');
  } else {
    if (!ratio_from || parseFloat(ratio_from) <= 0) return toast('From ratio must be > 0', 'err');
    if (!ratio_to   || parseFloat(ratio_to)   <= 0) return toast('To ratio must be > 0', 'err');
    if (Math.abs(parseFloat(ratio_from) - parseFloat(ratio_to)) < 0.0001)
      return toast('From and To ratios must be different', 'err');
  }

  try {
    const r = await fetch('/api/actions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ security_id, action_date, action_type, ratio_from, ratio_to,
                             description, notes, new_security_id }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    toast('Corporate action applied');
    await _actLoad();
  } catch (e) {
    toast(e.message, 'err');
  }
}
