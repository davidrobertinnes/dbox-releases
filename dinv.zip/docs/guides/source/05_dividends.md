# Dividends
Recording dividends, franking credits, DRPs and the 45-day rule

## Recording a Dividend
Click **+ Dividend** on the Dividends page or a company's page, and fill it in from your dividend statement:

1. **Security** and **Payment Date**: the date the dividend was paid.
2. **Ex-Dividend Date**: needed to check the 45-day rule (see below). It's on the company's ASX announcement and often on the statement.
3. **Record Date**: optional. From 9 March 2016, if you leave the ex-dividend date blank, the business day before the record date is used instead (shown as estimated).
4. **Quantity Held**: the number of shares the dividend was paid on, from the statement.
5. **Amount Per Share**.
6. **Franking %** and **Franking Credit ($)**: copy the franking credit dollar amount from the statement.
7. If you're in the company's dividend reinvestment plan, fill in the DRP section (see below).
8. Click **Save Dividend**.

Warning: always enter the **franking credit dollar amount** shown on your statement. It isn't worked out from the franking percentage, because the company tax rate behind it isn't always 30%: base rate entities pay 25%, and rates have changed over the years.

## Dividend Reinvestment (DRP)
If the dividend was reinvested, enter the **DRP Shares Issued** and the **DRP Price** from the statement. Dogbox Investments records the new shares as a parcel dated the payment date, costing the cash you'd otherwise have received.

The dividend still counts as income in full, even though you didn't receive the cash.

DRP details can't be edited once saved. To change them, delete the dividend and enter it again.

## The Dividends Page
The Dividends page lists every dividend with the shares held, amount per share, gross amount, franking, the 45-day check and the net amount. Use the search box and the From and To dates to narrow the list. **Edit** and **Del** change or remove one.

## Franking Credits
A franking credit is tax the company has already paid on the dividend. You declare it as income along with the dividend, then claim it back as a tax offset, which reduces your tax or comes back as a refund.

On your tax return:

- **11J:** unfranked amounts.
- **11K:** franked amounts (the cash part).
- **11L:** franking credits you can claim.

Partly franked dividends are split between 11J and 11K for you. The FY Tax Summary has these figures for each year.

## The 45-Day Rule
To claim a franking credit you must have held the shares "at risk" for at least 45 days (90 days for preference shares), not counting the day you bought or sold them. The days must fall between the day after you bought them and the 45th day after they went ex-dividend.

Dogbox Investments checks every dividend with an ex-dividend date and shows the result in the **45d** column:

- **✓ (green):** the rule is met, and the credit can be claimed.
- **✗ (red):** the rule isn't met, so the credit can't be claimed. It's left out of 11L, and the FY Tax Summary says how much was left out.
- **? (amber):** there's no ex-dividend date, so the rule can't be checked. The credit is left out of 11L until you add the date.

**Small shareholder exemption:** if you're an individual and your franking credits for the whole year total $5,000 or less, you don't need to meet the 45-day rule. Dogbox Investments applies this automatically, and the FY Tax Summary says when it has.

Note: the rule is also broken if you reduced your risk on the shares, for example with options or other hedges. Dogbox Investments can't see those, so allow for them yourself.

## Shares Held Jointly
If a holding is shared (for example 50% with your partner), enter the dividend in full, as on the statement. The tax figures use your share. See the Joint and Inherited Shares guide.
