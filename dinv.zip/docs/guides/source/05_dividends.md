# Dividends
Recording dividends, franking credits, DRPs, tax withheld and foreign companies, and the 45-day rule

## Recording a Dividend
Click **+ Dividend** on the Dividends page or a company's page, and fill it in from your dividend statement:

1. **Security** and **Payment Date**: the date the dividend was paid.
2. **Ex-Dividend Date**: needed to check the 45-day rule (see below). It's on the company's ASX announcement and often on the statement.
3. **Record Date**: optional. From 9 March 2016, if you leave the ex-dividend date blank, the business day before the record date is used instead (shown as estimated).
4. **Quantity Held**: the number of shares the dividend was paid on, from the statement.
5. **Amount Per Share**: the dividend per share before any tax was withheld.
6. **Franking %** and **Franking Credit ($)**: copy the franking credit dollar amount from the statement.
7. **Tax Withheld**: only if tax was taken out of the dividend (see below).
8. If you're in the company's dividend reinvestment plan, fill in the DRP section (see below).
9. Click **Save Dividend**.

Warning: always enter the **franking credit dollar amount** shown on your statement. It isn't worked out from the franking percentage, because the company tax rate behind it isn't always 30%: base rate entities pay 25%, and rates have changed over the years.

## Dividend Reinvestment (DRP)
If the dividend was reinvested, enter the **DRP Shares Issued** and the **DRP Price** from the statement. Dogbox Investments records the new shares as a parcel dated the payment date, costing the cash you'd otherwise have received.

The dividend still counts as income in full, even though you didn't receive the cash.

DRP details can't be edited once saved. To change them, delete the dividend and enter it again.

## Tax Withheld
Sometimes tax is taken out of a dividend before it's paid. Enter the amount in **Tax Withheld**, from the statement. Keep **Amount Per Share** as the dividend before the tax. The form then shows what was paid to you, which should match the amount paid on the statement; if it's less, you've entered the amount per share after tax.

- **An Australian company** withholds tax when it doesn't have your TFN. It goes at **11M** on your tax return (TFN amounts withheld), and the dividend is still declared in full at 11J and 11K.
- **A foreign company** usually has foreign tax withheld. You can claim it as a foreign income tax offset (see Foreign Companies below).

## Foreign Companies
For a company based overseas (for example Newmont, which pays in US dollars), tick **Foreign company** on the security (Securities, **Edit**). Its dividends are then foreign income on your tax return, not Australian dividends:

- **20E** and **20M:** the dividends before foreign tax was withheld.
- **20O:** the foreign income tax offset, which is the foreign tax withheld.

If a franked dividend comes from a foreign company (some New Zealand companies pay Australian franking credits), the franked part stays at 11K and 11L, and only the unfranked part is foreign income.

**Treaty Rate:** a tax treaty limits how much tax the other country should withhold, for example 15% for US dividends when you've given the broker or registry a W-8BEN form. Enter it on the security if you know it. If more than the treaty rate was withheld, you can only claim up to the treaty rate here, and the FY Tax Summary shows the rest as not claimable; you'd need to ask the other country for it. Leave the treaty rate blank to claim everything withheld.

**A company that moved country:** dividends follow the company's status on the date they were paid. See A Company Moving Country in the Corporate Actions guide, and Residency Changes in the Securities guide.

**Amounts in a foreign currency:** type the amounts as they appear on the statement, for example **US$0.25** per share and **US$7.50** tax withheld, and enter the **Exchange Rate**: Australian dollars per 1 unit of the other currency (for example 1.53 when US$1 buys A$1.53). Dogbox Investments converts them and keeps everything in Australian dollars from then on. A$ amounts are typed as usual, and one dividend can only use one foreign currency. Use the exchange rate on the statement, or the ATO's rate for the payment date.

Note: if the foreign income tax offset for the year is over $1,000, the amount you can claim also depends on the rest of your tax return. The FY Tax Summary flags it; work out the offset limit, or ask your accountant.

## The Dividends Page
Click the **paperclip** button on a dividend to keep its statement with it (see Contract Notes and Other Documents in the Buying and Selling guide).

The Dividends page lists every dividend with the shares held, amount per share, gross amount, franking, the 45-day check, tax withheld and the net amount. **Gross** is the gross payment on your dividend statement: the cash before any tax withheld. It's the same as **Net** unless tax was withheld. The franking credit is shown separately and is added to the dividend in the FY tax summary. Foreign companies are marked **Foreign**. Use the search box and the From and To dates to narrow the list. **Edit** and **Del** change or remove one.

## Franking Credits
A franking credit is tax the company has already paid on the dividend. You declare it as income along with the dividend, then claim it back as a tax offset, which reduces your tax or comes back as a refund.

On your tax return:

- **11J:** unfranked amounts.
- **11K:** franked amounts (the cash part).
- **11L:** franking credits you can claim.

Partly franked dividends are split between 11J and 11K for you. The FY Tax Summary has these figures for each year.

## The 45-Day Rule
To claim a franking credit you must have held the shares "at risk" for at least 45 days (90 days for preference shares), not counting the day you bought or sold them. The days must fall between the day after you bought them and the 45th day after they went ex-dividend.

Dogbox Investments checks every dividend and shows the result in the **45d** column. Without an ex-dividend date or record date, it still knows the ex-dividend date came before the payment date, and that you held the dividend's **Qty Held** the day before it. If every such date gives the same answer, that's the result. For example, shares bought years ago and still held 45 days after the payment date pass whatever the ex-dividend date was. Hover over the ✓ or ✗ to see when it was worked out this way.

- **✓ (green):** the rule is met, and the credit can be claimed.
- **✗ (red):** the rule isn't met, so the credit can't be claimed. It's left out of 11L, and the FY Tax Summary says how much was left out.
- **? (amber):** there's no ex-dividend date and the answer depends on what it was, so the rule can't be checked. The credit is left out of 11L until you add the ex-dividend date or record date.

**Small shareholder exemption:** if you're an individual and your franking credits for the whole year total $5,000 or less, you don't need to meet the 45-day rule. Dogbox Investments applies this automatically, and the FY Tax Summary says when it has.

Note: the rule is also broken if you reduced your risk on the shares, for example with options or other hedges. Dogbox Investments can't see those, so allow for them yourself.

## Shares Held Jointly
If a holding is shared (for example 50% with your partner), enter the dividend in full, as on the statement. The tax figures use your share. See the Joint and Inherited Shares guide.
