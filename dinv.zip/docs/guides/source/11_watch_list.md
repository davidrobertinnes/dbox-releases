# Watch List
Target prices, alerts, and planning a purchase or sale

## The Watch List
The **Watch List** keeps an eye on companies you hold or are thinking about buying. Each line shows the current price, your target buy and sell prices, a signal when the price reaches a target, a simple technical indicator (**Rec.**), any franking alert, and your notes. Companies you hold are marked **HELD**.

A company is added to the watch list automatically the first time you buy it. Click **Refresh Prices** for the latest prices.

Warning: the watch list is a planning tool. Its signals are rudimentary and aren't financial advice.

## Adding a Company
Click **+ Add to Watch List** (or **+ Watch** on Holdings or a company's page), choose the **Security**, and enter:

- **Target Buy:** a signal shows when the price is at or below this.
- **Target Sell:** a signal shows when the price is at or above this.
- **Notes**, if you like.

**Edit** and **Del** change or remove a line.

## Alerts
When a company's price is in its buy or sell zone, it's listed under **Watch List Alerts** on the Dashboard.

The **Franking Alert** shows when today is within the 45-day period around a company's latest ex-dividend date (90 days for preference shares). Selling or buying around then can affect whether you can claim the franking credit, so it shows the date you'd need to hold until. See the Dividends guide for the 45-day rule.

## Analysing a Company
Click **Analyse** on a line to plan a trade:

- **Build / Acquire:** plan a purchase. Enter the cash you have, any cash to keep in reserve, the entry price and brokerage. It shows how many shares you can buy, the total cost, the cash left and the break-even sell price, and if you already hold the company, your new quantity, average cost and break-even.
- **Balance / Maintain:** for a company you hold. Enter your cash and a cash buffer percentage. It splits the rest of the portfolio equally across the companies you hold and shows, for each, how much to buy or sell to get there, and whether you have cash to spare or need to raise some.
- **Divest / Sell:** plan selling some or all over a number of weeks, with brokerage, the cost base returned (oldest parcels first), the capital gain and an estimate of the cash left after tax at your marginal tax rate.
- **Market Analysis:** the price history against the All Ordinaries index.

Note: the sale estimate prices everything as a single sale today and leaves out your other gains and losses for the year. For the full picture, see the FY Tax Summary, and talk to your tax adviser.
