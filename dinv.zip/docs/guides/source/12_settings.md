# Settings
Your details, tax settings, holdings, year locks, backups, the audit log and the app's port

## Portfolio
- **Owner Name:** whose portfolio this is. It appears on reports.
- **Tax File Number (TFN):** optional. It's stored only in your portfolio file, and it's left out of Export Everything.

## Transactions
**Default Brokerage** is filled in for you on purchase and sale forms. Change it on any form when the brokerage was different.

## Tax
These settings change your tax figures, so set them before you rely on any reports.

- **Entity Type:** an individual (50% CGT discount), an SMSF in accumulation phase (one-third discount), an SMSF in pension phase (capital gains exempt) or a company (no discount). See the Capital Gains Tax guide.
- **Your Share of These Holdings (%):** for a portfolio of shares all held jointly in the same way, for example 50%. Leave at 100% otherwise, or set up holdings below. See the Joint and Inherited Shares guide.
- **Shares Acquired Before 21 Sep 1999:** the method for sales of these shares from 21 September 1999: the CGT discount, indexation, or whichever gives the lower gain for each sale. A parcel's **Method** button on the company's page overrides it. Companies always use indexation.
- **Marginal Tax Rate (%):** your top tax rate, from the list of current ATO resident rates (not including the Medicare levy). It's only used for after-tax estimates when you plan a sale; it doesn't change your tax figures.
- **Opening CGT Loss Balance ($):** capital losses carried forward from years before your first recorded transaction. Leave it at zero if you've recorded everything since your first investment; Dogbox Investments works out later carry-forwards itself.

Click **Save Settings** when you're done.

## Financial Year Lock
Once you've lodged a year's tax return, lock it so its figures can't change by accident. Choose the year under **Lock up to FY** and click **Lock FY**. That year and every year before it are locked.

In a locked year, purchases, sales, dividends and corporate actions can't be added, changed or deleted; they show as **Locked**. **Remove All Locks** unlocks every year, for example if you need to amend a return.

Tip: when you add older records with Import / Export → Add to this portfolio, the preview shows any changes to locked years before you go ahead.

## Holdings
Set up each broker account, HIN or SRN, with your share of it, and record moves between brokers and a joint holder's death. See the Joint and Inherited Shares guide.

## Backups
Dogbox Investments backs up the open portfolio automatically: once a day while it's open, if anything has changed, and when you quit, update or switch portfolio. See Backups in the Getting Started guide.

- **Back up this portfolio automatically:** on unless you turn it off.
- **Backup Folder:** where the backups go. Leave it blank for the Dogbox Backups folder in Documents. A cloud-synced folder or a USB drive keeps a copy off your computer.
- **Keep:** how many backups of each portfolio to keep (10 unless you change it). The oldest are deleted.

Click **Save Backup Settings** after a change. **Back Up Now** makes a backup straight away, even with automatic backups off. The last backup's date and time are shown beside it. If an automatic backup fails, for example because the USB drive isn't plugged in, the reason is shown here.

These settings apply to every portfolio on this computer.

## Audit Log
Every edit and deletion is recorded with the date, what was changed and what the record was before. If the ATO asks about a return you've lodged, it shows what your records looked like then.

Click **Show audit log** to see it. Changes made by an update that corrected or recalculated figures are listed here too.

## App: Port
Dogbox Investments runs a small web server on your computer, which its window connects to. It normally uses port 5100. If another program is using that port, it starts on the next free one by itself.

To always use a particular port, enter it under **Port** and click **Save Port**. It takes effect the next time you open Dogbox Investments. You'd only need this if another program on your computer needs port 5100.
