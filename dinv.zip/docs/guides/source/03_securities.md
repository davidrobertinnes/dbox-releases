# Securities and Company Pages
Adding companies and funds, code and name changes, and each company's own page

## Adding a Security
A security is anything you hold or watch: a company's shares, an ETF, a property trust, a bond or a preference share. Add each one once.

1. Open **Securities** and click **+ Add Security**.
2. Enter the **Code** (for example CBA) and **Name** (Commonwealth Bank of Australia).
3. Choose the **Exchange**, the **Type** and the **Currency**. Most will be ASX, Share and AUD.
4. For a company based overseas, tick **Foreign company**, and enter the **Treaty Rate %** if you know it (for example 15 for the US). Its dividends then go on your tax return as foreign income. See Foreign Companies in the Dividends guide.
5. Click **Add Security**.

You can also add one while recording a purchase: choose **+ Add new security** in the Security list on the purchase form.

The code is used to fetch prices from Yahoo Finance, so use the code the company trades under.

Note: choose **Preference Share** as the type for preference shares. The 45-day rule is 90 days for them, and Dogbox Investments checks the right period from the type.

## Editing and Inactive Securities
Click **Edit** on a security to change its details or notes. A security you no longer hold or watch can be put away with **Deactivate**: it moves to the bottom of the list, marked Inactive. Its history is kept, and it still counts in the tax figures for the years you held it. **Activate** brings it back.

## Code and Name Changes
When a company changes its code or name (for example Woodside's code changing from WPL to WDS), don't add a new security. Instead:

1. Open **Securities**, click **Edit** on the company, and find **Code & name changes**.
2. Enter the date of the change and the new code and/or name, and click **Add change**.
3. Click **Save Changes**.

The security's code becomes the new one, and its whole history stays together. Each year's tax reports use the code and name the company had on 30 June of that year, so older reports still match your old statements.

If the change came with a different number of shares or a new company, it's a corporate action instead (a consolidation, demerger or takeover). See the Corporate Actions guide.

## Residency Changes
A company that becomes foreign, or Australian, without your shares being swapped, can have the date recorded so each dividend is treated by the date it was paid:

1. Open **Securities**, click **Edit** on the company, and find **Residency changes**.
2. Enter the date of the change, choose whether it **Became** foreign or Australian, and enter the **Treaty Rate %** for a foreign company if you know it.
3. Click **Add change**.

Dividends paid from that date go on your tax return as foreign income (Item 20), or as Item 11 income for a company that became Australian. Earlier dividends stay where they were, so one year can have some of each. **Foreign company** on the form then shows the company's status today.

Most companies that move country do it with a scheme that swaps your shares for shares in a new company. That's a redomicile: record it under Corporate Actions instead (see A Company Moving Country in the Corporate Actions guide).

## A Company's Page
Open a company's page with **View ›** on Holdings or by clicking it on the Securities page. It shows everything about that company:

- **Summary:** quantity held, average cost, total cost base, dividend income, sale proceeds, current price and market value.
- **Parcels:** each purchase, DRP, bonus or inherited parcel, with its cost base and how many shares are left. A parcel is Open, Partial (partly sold) or Closed.
- **Sales:** every sale and its proceeds.
- **Dividends:** every dividend, with franking and the 45-day check.
- **Corporate Actions:** splits, returns of capital and other events for this company.

Each section has its own buttons: **+ Buy**, **+ Inherited**, **+ Employee Shares**, **Record Sale**, **Estimate Sale**, **+ Dividend** and **+ Action**. **+ Watch** adds the company to your watch list.

Parcels bought before 20 September 1985 are marked **Pre-CGT**, inherited parcels are marked **Inherited**, and employee shares are marked **Employee** (or **Restricted until** a date, while they can't be sold; see the Buying and Selling guide). For parcels bought before 21 September 1999, the **Method** button chooses the CGT discount or indexation for that parcel. See the Capital Gains Tax guide.

## Estimating a Sale
**Estimate Sale** on a company's page shows what a sale today would mean for tax, before you sell. Enter the quantity to sell. It shows the cost base of the shares sold (oldest first), the gain or loss, how much would be taxable after the discount, and an estimated after-tax gain using the marginal tax rate in Settings.

Note: the estimate looks at this sale on its own. Your other gains and losses for the year, and losses carried forward, are applied in the FY Tax Summary. It's an estimate, not advice.
