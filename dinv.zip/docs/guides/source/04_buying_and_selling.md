# Buying and Selling
Recording purchases and sales, parcels, choosing which shares you sell, and keeping contract notes

## Parcels
Every purchase is a **parcel**: a number of shares bought on one date for one cost. Dogbox Investments keeps track of each parcel separately because the tax rules work parcel by parcel. Each parcel has its own purchase date (which decides whether the CGT discount applies) and its own cost base.

A DRP, a bonus issue taken up as new shares, a rights issue, inherited shares or employee shares also make parcels.

## Recording a Purchase
Click **+ Buy** on Holdings, Transactions or a company's page.

1. Choose the **Security**. If it isn't there yet, choose **+ Add new security**.
2. Enter the **Acquisition Date**: the trade date on your contract note, not the settlement date.
3. Enter the **Quantity** and the **Price Per Unit**.
4. Enter the **Brokerage**, and any **Other Costs** such as stamp duty or levies. They're part of the cost base.
5. If you've set up holdings (broker accounts or HINs) in Settings, choose the **Holding** the shares are in.
6. Click **Save Purchase**.

On a company's page, the purchase form also takes **Or Total Cost** instead of a price (the total before brokerage; whichever you type last is kept), and a parcel **Label** such as amp or drp22 to tell parcels apart.

Tip: set a **Default Brokerage** in Settings to have it filled in for you.

Note: purchases and sales are entered in Australian dollars. For shares bought or sold on an overseas exchange, convert the price, brokerage and other costs to A$ using the exchange rate on the contract note for each trade. Dividends from foreign companies can be entered in their own currency (see Dividends).

## Employee Shares
Use **+ Employee Shares** on the company's page for shares from an employee share plan that is taxed upfront, such as the plans that give employees up to $1,000 of shares tax-free each year (the Wesfarmers Employee Share Acquisition Plan is one).

1. Enter the **Date Acquired** and the **Quantity**.
2. Enter the **Market Value**: the total value of the shares on the date you acquired them. It's on your employee share scheme (ESS) statement. This is your cost base, even if you paid nothing for the shares.
3. Enter **Restricted Until**: the end of the plan's restriction period, if it has one (for example 3 years, or until you leave the employer). Leave it blank if there isn't one.
4. Click **Save**.

The 12 months for the CGT discount start on the date you acquired the shares, not when the restriction ends. You own the shares during the restriction period, so record their dividends as usual.

While the shares are restricted, the parcel is marked **Restricted until** with the date, and sales don't take shares from it unless you choose it with **Specific Parcels**. If the restriction ended early (for example you left the employer), click the marker to change or clear the date. After it ends, the parcel is marked **Employee** and is sold like any other.

Employee shares aren't counted in **Total Invested** on the Dashboard, because you didn't pay for them.

Note: the discount you received (the ESS amount) is income in the year you got the shares. It goes in your tax return from your ESS statement, and isn't part of Dogbox Investments' figures. For a plan where tax is deferred (for example rights or options that only become shares later), the cost base and dates follow different rules: ask your accountant before entering them.

## Entering Purchases from Before a Split
Always enter a purchase exactly as on the contract note, even if the company has split or consolidated its shares since. Dogbox Investments applies the later split itself and shows the parcel in today's units. When you edit the purchase later, the form shows the contract note figures with a note of the change since.

## Recording a Sale
Click **Record Sale** on Transactions or a company's page.

1. Choose the **Security** and enter the **Sale Date** (the trade date).
2. Enter the **Quantity**, **Price Per Unit** and **Brokerage**.
3. Choose the **CGT Method**, which decides which parcels the shares come from (see below).
4. If you've set up holdings, choose the **Holding** the shares are sold from. Only shares in that holding are used.
5. Click **Record Sale**.

The capital gain or loss is worked out straight away, parcel by parcel, and shows on CGT Detail and the FY Tax Summary.

You can't sell more shares than you held on the sale date, or shares bought after it.

## Choosing Which Shares You Sell
When you sell part of a holding, the ATO lets you choose which parcels the shares come from, as long as you can identify them. The **CGT Method** on the sale form chooses for you:

- **FIFO (First In, First Out):** the oldest shares first. This is the default, and usually the most likely to get the CGT discount.
- **Min Gain (Highest Cost Base First):** the parcels that cost the most, for the smallest gain.
- **Max Gain (Lowest Cost Base First):** the parcels that cost the least, for the largest gain, for example to use up capital losses.
- **Pro rata:** the same proportion from every parcel.
- **Specific Parcels:** tick the parcels yourself. Enter how many shares come from each, or leave the quantities blank to use the ticked parcels in the order you ticked them.

FIFO, Min Gain and Max Gain don't use employee shares that are still in their restriction period on the sale date. Pro rata and Specific Parcels can.

Tip: before you sell, use **Estimate Sale** on the company's page to see the tax effect. Min Gain isn't always best: a parcel held for more than 12 months gets the discount, and a newer, more expensive parcel may not.

## Editing and Deleting
On **Transactions**, click **Edit** or **Del** on a purchase or sale. Use the search box and the From and To dates to find one.

Purchases show the quantity and price from the contract note, even after a later split or consolidation; hover over the quantity to see how many units the parcel is now.

Once some shares in a parcel have been sold, its quantity is locked so the sales stay right. To change it, delete the sale first, fix the purchase, then record the sale again.

Records in a financial year you've locked in Settings can't be changed (shown as **Locked**). See the Settings guide.

Every edit and deletion is recorded in Settings → Audit Log.

## Contract Notes and Other Documents
You can keep the source document with each record: the contract note for a purchase or sale, the statement for a dividend, the company's notice or the ATO class ruling for a corporate action. The ATO expects you to keep records of what you paid for shares until 5 years after you sell them, which can be decades.

1. Click the **paperclip** button on the record's row: on Transactions, Dividends, Corporate Actions or the company's page.
2. Drop files onto the panel, or click it to choose them. PDFs, photos and scans up to 10 MB each, as many as you like.
3. Click a document's name to open it, **Save** to save a copy, or the red cross to delete it.

The paperclip shows how many documents a record has. You can add documents in a locked year: they don't change any figures.

Documents are kept inside the portfolio file, so a copy or backup of the file includes them. Deleting a record deletes its documents too.

Shares that came from a dividend or corporate action, such as DRP shares or shares from a demerger, have no paperclip of their own: attach the document to the dividend or the corporate action.

Note: a CSV export can't hold documents. To move a portfolio with its documents, use **Export with Documents (.zip)** (see the Importing and Exporting guide).
