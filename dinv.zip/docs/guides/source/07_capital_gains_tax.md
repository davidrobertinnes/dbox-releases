# Capital Gains Tax
How your capital gains and losses are worked out, and the rules Dogbox Investments applies

## The Basics
When you sell shares (or something else ends your ownership, like a takeover or cancellation), you make a capital gain or a capital loss on each parcel:

    capital proceeds − cost base = gain (or loss)

The **capital proceeds** are what you received, less brokerage. The **cost base** is what you paid, including brokerage and other costs, less any returns of capital since.

All your gains and losses for the financial year are added together on your tax return. Dogbox Investments does this for you on the FY Tax Summary.

Note: this guide explains what Dogbox Investments does. It's general information, not tax advice. The ATO's website has the full rules.

## The CGT Discount
If you held the shares for more than 12 months, the gain is discounted:

- **Individuals:** 50% of the gain is taxed.
- **SMSFs (accumulation phase):** two thirds of the gain is taxed (a one-third discount).
- **Companies:** no discount.

The 12 months must be complete: the sale has to be after the first anniversary of the purchase, not on it. On the sale form, parcels that qualify are marked **Disc**.

Your entity type is set in **Settings → Tax**, so set it before you rely on any figures.

## Capital Losses
Capital losses can only be used against capital gains, not other income. Each year they're applied in the order the ATO sets out:

1. This year's capital losses come off this year's gains.
2. Losses carried forward from earlier years come off what's left.
3. The CGT discount applies only to the discount-eligible gains remaining.

The result is your **net capital gain (18A)**. Losses you couldn't use are carried forward to the next year **(18V)**, and Dogbox Investments carries them forward for you every year until they're used up.

If you had capital losses from before your first recorded transaction, enter them in **Settings → Opening CGT Loss Balance**.

## Shares Bought Before 20 September 1985
Capital gains tax started on 20 September 1985. Shares bought before then are **pre-CGT**: selling them makes no capital gain or loss. They're marked Pre-CGT on the company's page, and their sales show as exempt.

Bonus shares on pre-CGT shares are pre-CGT too.

## Indexation (Shares Bought Before 21 September 1999)
Before the CGT discount began on 21 September 1999, gains were worked out by indexing the cost base for inflation, frozen at the September 1999 quarter. For shares bought before 21 September 1999 and held at least 12 months, you can use either indexation or the discount, whichever suits you:

- Sales before 21 September 1999 always use indexation.
- For later sales, choose the default in **Settings → Shares Acquired Before 21 Sep 1999**: the CGT discount, indexation, or whichever gives the lower gain for each sale.
- To choose for one parcel, click **Method** next to it on the company's page.
- Companies always use indexation, as they don't get the discount.

Indexation can't create or increase a loss. The method used for each sale shows on **CGT Detail**.

Note: once a return of capital on a parcel makes a gain with one method, later sales from that parcel use the same method, as the ATO requires.

## SMSFs in Pension Phase
If your entity type is **SMSF — Pension**, capital gains are exempt and capital losses are disregarded. The FY Tax Summary shows the gains as exempt.

## Division 296 (SMSFs)
From 1 July 2026, members whose total super balance is over $3 million pay 15% more on their share of the fund's Division 296 earnings, and a further 10% above $10 million. The fund works out those earnings from its taxable income and reports each member's share.

For an SMSF in accumulation phase, CGT Detail and the FY Tax Summary show the part of those earnings that comes from the investments recorded here, from the 2026–27 year: assessable dividends (with franking credits) and the net capital gain. Contributions, expenses, the member's share and the balance tests are worked out by the fund's accountant or actuary.

**Cost base reset election:** an SMSF can choose, once, to reset the cost base of all its assets to their market value at the end of 30 June 2026, for Division 296 only. If your fund has made this choice, tick it under **Settings → Division 296** and enter each company's value at 30 June 2026 there (**Fetch missing closing prices** fills in listed shares from Yahoo Finance; check them and enter any others by hand). The capital gain for Division 296 is then worked out from those values, less any later returns of capital. The fund's own tax return is not affected.

## The CGT Detail Page
**CGT Detail** shows one financial year in full. Choose the year and click **Load**.

- The cards at the top total the year: gross gains and losses, the net capital gain (18A), capital gains from returns of capital, prior-year losses applied, and claimable franking credits.
- **Disposals** lists every sale, parcel by parcel: sale date, purchase date, quantity, proceeds, cost base, gain or loss, the method (discount, indexed, pre-CGT, roll-over) and the taxable gain. Share cancellations, takeovers and inherited parcels are labelled.
- **Returns of capital** that went over a parcel's cost base are listed with the excess gain.
- **Dividends** for the year, with franking credits and the 45-day check.

**Export CGT Schedule** saves the disposals as a spreadsheet file for your accountant, and **Export Income CSV** saves the dividends.
