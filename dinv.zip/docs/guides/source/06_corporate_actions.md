# Corporate Actions
Splits, consolidations, bonus and rights issues, returns of capital, demergers, takeovers and share cancellations

## What a Corporate Action Is
A corporate action is something a company does that changes your shares or their cost base: a share split, a return of capital, a demerger, a takeover and so on. Record each one when it happens, using the company's ASX announcement or your registry statement. Without them, your quantities and cost bases drift away from your statements and your capital gains come out wrong.

## Recording an Action
1. Open **Corporate Actions** and click **+ Record Action**, or use **+ Action** on a company's page.
2. Choose the **Security**, the **Action Date** and the **Type**.
3. Fill in the figures for that type (below). A line under the form shows what will happen before you apply it.
4. Add a **Description** if you like, for example "ASX announcement: 2-for-1 share split".
5. Click **Apply Action**.

The action applies to every parcel you held on the date, in every holding.

**Same-day order:** when several things happen on one day, Dogbox Investments always applies purchases first, then corporate actions, then sales. So shares you sell on the day of a return of capital still receive it, and shares bought that day are included. Shares issued that day by a bonus or rights issue, or by a dividend reinvestment plan (DRP), are not: they weren't held at the record date. If you enter a return of capital as a total (in an import file), it's spread over the shares that received it.

**Record date and ex-date:** for a return of capital or a demerger you can also enter the **Record Date** and **Ex-Date** from the company's notice. Only shares on the register at the record date receive it, so shares bought on or after the ex-date are left out, even though you held them on the action date. From 9 March 2016 the ex-date is worked out from the record date (the business day before). For earlier actions, enter the ex-date from the notice; if you only enter the record date, shares bought on or after the record date are left out. Leave both blank and the action applies to every share you held on the action date. On the Corporate Actions page, an action with these dates has a * after its date: hover over the date to see them.

**Shares sold before the payment:** if you sold shares on or after the ex-date but before a return of capital was paid, you were still on the register, so the payment is yours. The ATO treats it as a capital gain on the day it's paid (CGT event C2): you no longer own the shares, so there's no cost base and the whole payment is a gain, with the CGT discount if you'd held the shares for 12 months. Dogbox Investments works this out when you enter the record date or ex-date, and shows it on CGT Detail as "sold before payment". The sale itself is worked out without the return of capital. For a demerger, shares sold in that time are also entitled to the new shares, but how to treat them depends on the demerger, so the Dashboard lists them for you to check against the company's booklet or the ATO's guidance.

## Splits and Consolidations
Enter **From** (existing shares) and **To** (new shares received). A 2-for-1 split is From 1, To 2; a 1-for-10 consolidation is From 10, To 1.

Your number of shares changes, but your cost base and purchase dates don't. Nothing is taxed.

Shares trade in the new number from the **Ex-Date**, a few days before the split takes effect. If you bought or sold shares between the ex-date and the action date, enter the ex-date (or, from 9 March 2016, the record date): shares bought from the ex-date aren't changed, and sales from the ex-date are taken as being in the new number of shares. The same applies to bonus issues. For an earlier split you need the ex-date itself, from the company's notice.

## Bonus Issues
Enter how many bonus shares you get for every so many shares held, for example 1 for every 10.

The cost base is spread over your original and bonus shares, and the bonus shares keep the original purchase dates, as the ATO requires. Nothing is taxed when they're issued.

## Rights Issues
For rights you took up, enter the **Quantity subscribed** and the **Subscription price** per share. The new shares become a new parcel, dated the action date, costing what you paid.

## Returns of Capital
Enter the **Amount per unit** paid. It isn't income: it reduces the cost base of each parcel you held.

If a return of capital is more than a parcel's remaining cost base, the cost base goes to zero and the excess is a capital gain in that year. It shows in its own section on CGT Detail.

If the return of capital came on the same day as a split or consolidation, enter the amount per share held **before** the split or consolidation.

## Demergers
A demerger is when a company spins off part of its business as a new listed company and gives you shares in it.

1. Add the new company under **Securities** first, if it isn't there.
2. Choose **Demerger**, and choose the new company as the **Demerged Entity**.
3. Enter the **Cost base % kept by the original company** (for example 85) and the **New shares issued per original share held** (for example 1).

The company's demerger booklet or the ATO class ruling gives the cost base split. Your cost base is divided between the two companies, and the new shares keep your original purchase dates, so the CGT discount still applies to them.

## Takeovers and Mergers
Use **Takeover / Merger** when a company is taken over for cash, shares in the buyer, or both.

1. Add the company whose shares you receive under **Securities**, if it isn't there.
2. Choose **Takeover / Merger** and choose the **Security Received**.
3. Enter the **Cash per share held** (0 if none) and the **New shares per share held**.
4. If there's cash as well as shares, enter the **Market value of one new share** on the day, for example the day's volume-weighted average price.
5. Tick **Choose scrip-for-scrip roll-over** if you're choosing roll-over.

**With roll-over**, only the cash is taxed now. The part of your cost base that relates to the cash is worked out as the ATO requires, the rest moves to the new shares, and they keep your original purchase dates.

**Without roll-over** (shares bought before 20 September 1985, a loss, or if you don't choose it), the takeover is a full disposal of your old shares, and the new shares cost their market value on the day.

Either way, the takeover appears under sales, with any capital gain or loss.

Note: a takeover where you receive only cash is simply a sale: record it with **Record Sale** at the price paid per share.

## A Company Moving Country (Redomicile)
Sometimes a company moves its home to another country, or to Australia, by a scheme: a new company in the other country takes over the old one, and your shares become shares or CDIs in the new company, usually under the same ASX code. Examples: AVITA Medical (AVH) moving to the US in 2020, and Civmec (CVL) moving from Singapore to Australia in 2024.

For tax, the swap is a disposal of your old shares. Roll-over is normally available, so nothing is taxed at the time. Record it as a redomicile:

1. Choose the company, the date the scheme was implemented, and **Redomicile (company moves country)**.
2. Enter the **New shares or CDIs per share held** (for example 0.05 for 5 CDIs for every 100 shares).
3. Enter the **New company's name**. Leave **The new company is foreign** ticked for a move overseas and enter the **Treaty Rate %** if you know it, or untick it for a move to Australia.
4. Tick **Choose scrip-for-scrip roll-over** if you're choosing roll-over (most people do).
5. If you don't choose roll-over, or some of your shares were bought before 20 September 1985, enter the **Market value of one new share** on the day, for example the day's volume-weighted average price. The new shares in those parcels cost that value.

The new company takes over the code, and its dividends are foreign income (Item 20) or Item 11 income, depending on where it's based. The old company keeps its history and, from the date of the move, shows with -OLD after its code (for example AVH-OLD). With roll-over, the new shares keep your cost base and original purchase dates, so the CGT discount still applies. The swap appears under sales, with no gain.

The scheme booklet or the ATO class ruling for the scheme gives the number of new shares and says whether roll-over is available.

Note: if a company became foreign (or Australian) without your shares being swapped, it isn't a corporate action. Record the date under **Securities → Edit → Residency changes**. See the Securities guide.

## Share Cancellations
When a company cancels some of your shares and pays you for them (for example a buy-back of the same proportion from every holder), choose **Share Cancellation** and enter the **Shares cancelled** and the **Total payment received**.

It's recorded as a disposal (CGT event C2), as the ATO requires. The payment is your capital proceeds, each parcel gives up the same proportion of its shares, and the gain or loss appears with your sales.

Warning: off-market buy-backs can include a dividend component and other special treatment. Check the company's booklet or the ATO class ruling before recording one.

## Code and Name Changes
A change of code or name with no other change isn't a corporate action. Record it under **Securities → Edit → Code & name changes**. See the Securities guide.

## Keeping the Notice
Click the **paperclip** button on an action to keep the company's notice, the ATO class ruling or the cost base split with it (see Contract Notes and Other Documents in the Buying and Selling guide).

## Deleting an Action
Click **Del** on an action to reverse it and delete it. Everything it changed is put back. To correct an action, delete it and record it again.

Actions in a financial year you've locked in Settings can't be deleted.
