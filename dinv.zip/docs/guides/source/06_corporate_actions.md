# Corporate Actions
Splits, consolidations, bonus and rights issues, returns of capital, demergers, takeovers and share cancellations

## What a Corporate Action Is
A corporate action is something a company does that changes your shares or their cost base: a share split, a return of capital, a demerger, a takeover and so on. Record each one when it happens, using the company's ASX announcement or your registry statement. Without them, your quantities and cost bases drift away from your statements and your capital gains come out wrong.

## Recording an Action
1. Open **Corporate Actions** and click **+ Record Action**, or use **+ Action** on a company's page.
2. Choose the **Security**, the **Action Date** and the **Type**.
3. Fill in the figures for that type (below). A line under the form shows what will happen before you apply it.
4. Add a **Description** if you like, for example "ASX announcement: 2-for-1 share split".
5. Click **Apply Action**.

The action applies to every parcel you held on the date, in every holding.

**Same-day order:** when several things happen on one day, Dogbox Investments always applies purchases first, then corporate actions, then sales. So shares you sell on the day of a return of capital still receive it, and shares bought that day are included.

## Splits and Consolidations
Enter **From** (existing shares) and **To** (new shares received). A 2-for-1 split is From 1, To 2; a 1-for-10 consolidation is From 10, To 1.

Your number of shares changes, but your cost base and purchase dates don't. Nothing is taxed.

## Bonus Issues
Enter how many bonus shares you get for every so many shares held, for example 1 for every 10.

The cost base is spread over your original and bonus shares, and the bonus shares keep the original purchase dates, as the ATO requires. Nothing is taxed when they're issued.

## Rights Issues
For rights you took up, enter the **Quantity subscribed** and the **Subscription price** per share. The new shares become a new parcel, dated the action date, costing what you paid.

## Returns of Capital
Enter the **Amount per unit** paid. It isn't income: it reduces the cost base of each parcel you held.

If a return of capital is more than a parcel's remaining cost base, the cost base goes to zero and the excess is a capital gain in that year. It shows in its own section on CGT Detail.

If the return of capital came on the same day as a split or consolidation, enter the amount per share held **before** the split or consolidation.

## Demergers
A demerger is when a company spins off part of its business as a new listed company and gives you shares in it.

1. Add the new company under **Securities** first, if it isn't there.
2. Choose **Demerger**, and choose the new company as the **Demerged Entity**.
3. Enter the **Cost base % kept by the original company** (for example 85) and the **New shares issued per original share held** (for example 1).

The company's demerger booklet or the ATO class ruling gives the cost base split. Your cost base is divided between the two companies, and the new shares keep your original purchase dates, so the CGT discount still applies to them.

## Takeovers and Mergers
Use **Takeover / Merger** when a company is taken over for cash, shares in the buyer, or both.

1. Add the company whose shares you receive under **Securities**, if it isn't there.
2. Choose **Takeover / Merger** and choose the **Security Received**.
3. Enter the **Cash per share held** (0 if none) and the **New shares per share held**.
4. If there's cash as well as shares, enter the **Market value of one new share** on the day, for example the day's volume-weighted average price.
5. Tick **Choose scrip-for-scrip roll-over** if you're choosing roll-over.

**With roll-over**, only the cash is taxed now. The part of your cost base that relates to the cash is worked out as the ATO requires, the rest moves to the new shares, and they keep your original purchase dates.

**Without roll-over** (shares bought before 20 September 1985, a loss, or if you don't choose it), the takeover is a full disposal of your old shares, and the new shares cost their market value on the day.

Either way, the takeover appears under sales, with any capital gain or loss.

Note: a takeover where you receive only cash is simply a sale: record it with **Record Sale** at the price paid per share.

## Share Cancellations
When a company cancels some of your shares and pays you for them (for example a buy-back of the same proportion from every holder), choose **Share Cancellation** and enter the **Shares cancelled** and the **Total payment received**.

It's recorded as a disposal (CGT event C2), as the ATO requires. The payment is your capital proceeds, each parcel gives up the same proportion of its shares, and the gain or loss appears with your sales.

Warning: off-market buy-backs can include a dividend component and other special treatment. Check the company's booklet or the ATO class ruling before recording one.

## Code and Name Changes
A change of code or name with no other change isn't a corporate action. Record it under **Securities → Edit → Code & name changes**. See the Securities guide.

## Deleting an Action
Click **Del** on an action to reverse it and delete it. Everything it changed is put back. To correct an action, delete it and record it again.

Actions in a financial year you've locked in Settings can't be deleted.
