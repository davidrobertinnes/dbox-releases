# Dashboard and Holdings
Your portfolio at a glance, what you own now, and what you owned on any date

## The Dashboard
The Dashboard is the first page you see. Across the top:

- **Open Positions:** how many companies you hold.
- **Cost Base:** the total cost base of the shares you hold now.
- **Market Value:** what they're worth at the last prices fetched.
- **Unrealised P&L:** market value less cost base, the gain or loss you'd have if you sold everything today.
- **Dividend Income:** dividends received this financial year.
- **Disposals:** the cash you've received from sales. New shares received in a takeover aren't counted, only cash.

The **Total Return** panel adds up how the portfolio has done since you started: what you've invested, unrealised and realised gains, and dividends.

**Total Invested** is what you actually paid: purchases, DRPs, and the starting cost of inherited shares. Shares that came from other shares (takeovers, demergers, bonus issues) aren't counted again.

Below are your holdings, recent activity and the latest prices.

## Prices
Click **Refresh Prices** on the Dashboard, Holdings or Watch List to fetch the latest closing prices from Yahoo Finance. You need an internet connection. Prices are only used for market values and the watch list; they never affect your tax figures.

## Things to Check
Sometimes the Dashboard shows a box asking you to check some records. It appears after an update has corrected the way something is worked out, when a record couldn't be corrected automatically: for example a purchase entered after a share split, where the quantity might be in the units from before the split.

Each box explains what to look at. Once you've checked the records listed, click **I've checked these**.

The Dashboard also lists **Watch List Alerts**: companies on your watch list in their buy or sell zone, and companies where selling now could cost you franking credits under the 45-day rule. See the Watch List guide.

## Holdings
**Holdings** lists every company you hold, with quantity, average cost, cost base, price, market value and profit or loss. The list can be grouped **By Type** (shares, ETFs and so on) or **By Holding** (by broker account or HIN, if you've set up holdings in Settings).

Use the search box to find a company, and **View ›** to open its page. **+ Watch** adds it to your watch list.

**+ Buy** records a purchase (see the Buying and Selling guide). **Export CSV** saves the list as a spreadsheet file.

## Holdings at a Past Date
Change **View** from Current Holdings to **Holdings at Date**, choose the date under **As at** and click **Load**. You'll see what you held on that date, parcel by parcel, with each parcel's cost base on that date.

This is handy for checking against a broker or registry statement, or for working out what someone held on the day they died.

**Export as Inherited** saves the holdings on that date as a file of inherited shares, to add to the beneficiary's portfolio. See the Joint and Inherited Shares guide.

Note: quantities are shown as they were on that date. If a company has split its shares since, you see the number of shares you held before the split, as on a statement from that time.
