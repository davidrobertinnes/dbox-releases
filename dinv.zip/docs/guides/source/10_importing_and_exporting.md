# Importing and Exporting
Bringing in records from a broker or spreadsheet, and saving your whole portfolio to one file

## Three Ways to Bring Records In
**Import / Export** has three kinds of import:

- **Import transactions from CSV:** purchases and sales (and some dividends) from a broker's export file, into the portfolio that's open.
- **Import into New Portfolio:** a whole portfolio from a full export file or your own master file, as a new portfolio.
- **Add to this portfolio:** extra records from a file, such as older purchases or inherited shares, into the portfolio that's open.

## Importing from a Broker
1. Add each company under **Securities** first. Rows for codes that aren't there are skipped.
2. On **Import / Export**, choose the **Format**, or leave it on **Auto-detect**.
3. Choose the CSV file under **Select CSV file**.
4. Check the preview. Each row shows **Ready**, or why it will be skipped.
5. Click **Import** (it shows how many transactions will be imported).

The formats are:

- **CommSec Trade Confirmations:** ConfirmationDetails.csv from CommSec (Portfolio › Transactions › Export). Buys and sells only; CommSec doesn't include dividends in this file.
- **SelfWealth Transaction History:** buys, sells and dividends.
- **Generic (flexible columns):** any CSV with columns for date, code, type, quantity and price. Column names can vary.
- **Dogbox Investments Template:** the standard layout. **Download Template** gives you the column names.

Rows are applied in date order, so a newest-first file imports correctly. After importing, add any dividends and corporate actions the file didn't include.

**Export All Transactions** saves your purchases and sales as a CSV file.

## Export Everything
**Export Everything** saves the whole portfolio as one CSV file: securities and their code and name changes, purchases, dividends, corporate actions, sales with the parcels they used, holdings, the watch list and settings. Your TFN is left out.

Importing it into a new portfolio gives exactly the same figures. So it's a good backup, and a way to keep your records in a spreadsheet and rebuild the portfolio from it at any time.

A CSV file can't hold the documents attached to records (contract notes, statements). **Export with Documents (.zip)** saves a .zip file with the same CSV file and every document. Import the .zip, not the CSV, to bring the documents across.

## Your Own Master File
If you already keep your share history in a spreadsheet, you can import it as a **master file**: one row per event, with the row type in a **Type** column.

**Download Master File Template** gives an example with every row type and a note on each. It's the easiest starting point: copy your records into it, save it as CSV, and import it with **Import into New Portfolio**.

Dates can be YYYY-MM-DD or DD/MM/YYYY, and rows can be in any order. A row with text in the Type column only is a comment. Corporate actions apply to every holding, so one row is enough.

## Master File Row Types
- **Owner, TFN, FYE, Entity, Tax, Loss:** settings. Name = owner, TFN, FYE (June30 or Dec31) or entity (individual, smsf, smsf pension, company); Ratio = marginal tax rate; Cost = capital loss carried in.
- **Security:** Code, Name. Optional: without Security rows, each code is added with its code as its name. Foreign = Yes for a foreign company, or its treaty rate (e.g. 15%).
- **Holding:** Code, Name, Ratio = your share (1 sole, 0.5 joint). One per HIN or SRN; optional. A second Holding row with a Date and a new Ratio records a joint holder's death.
- **Buy:** Date, Code, Quantity, Cost (total) or Price (per share), Brokerage, Parcel = a label, Holding.
- **Sell:** Date, Code, Quantity, Price or Cost, Brokerage, Parcel = the labels to sell from, then MIN, MAX or FIFO. Holding.
- **Div:** Date (paid), Code, Franked, Unfranked, Credit, Record or Ex Date. Franked and Unfranked are the dividend before any tax was withheld, not the amount paid to you. Withheld = tax withheld. Unfranked and Withheld can be as on the statement (US$50.00) with Ratio = the exchange rate (A$ per US$1). For a DRP: Quantity and Cost of the shares received.
- **Bonus:** Ratio = shares after per share before, or Quantity = bonus shares received in the row's Holding.
- **Rights:** Quantity taken up and Price per share: a new parcel.
- **RoC:** a return of capital: Price per share, or Cost = the total.
- **Con / Split:** Ratio = shares after per share before, or Quantity = the change in shares. Cost on a Con = a return of capital paid with it.
- **Cancel:** shares cancelled for a payment (a disposal): Quantity, Price or Cost; taken from every parcel in proportion.
- **Demerger:** Code, Code2 = the new company, Quantity = new shares per share, Ratio = the share of the cost base moving to it.
- **Merger:** a takeover: Code = the company received, Code2 = the one given up, Quantity = new shares in all, Cost = total cash, Price = market value of one new share.
- **Rename:** Code = the code before, Code2 = the new code and/or Name = the new name.
- **Transfer:** Holding = from, To Holding = to, Code = one company only. Not a CGT event.
- **Inherit:** Date = date of death, Quantity, Cost = the deceased's cost base, Original Date = their purchase date (pre-CGT: Cost = market value, no Original Date).
- **Value:** Date, Code, Price = market value of one share, for pre-CGT shares at a joint holder's death.

The same list is under **Master file format** on the Import / Export page.

## Import into New Portfolio
1. Enter a **New portfolio name**.
2. Choose the **Full export file**: a full export (.csv, or .zip with documents) or your master file.
3. Click **Import into New Portfolio**.

The portfolio that's open isn't changed. If anything in the file can't be imported, nothing is created and the problem line is shown, so you can fix it and try again. If you import a CSV export of a portfolio that had documents, you're told how many were left out.

## Add to This Portfolio
**Add to this portfolio** adds the records in a file to the portfolio that's open: for example purchases from before you started using Dogbox Investments, or an inherited portfolio (see the Joint and Inherited Shares guide).

1. Choose the **File to add** and click **Preview Changes**.
2. The preview lists the tax figures that would change, year by year, with the figure now and after adding. Years you've locked are marked.
3. Click **Add to This Portfolio** to go ahead, or **Cancel**.

The portfolio is rebuilt from its whole history in date order, so earlier purchases get later splits and other corporate actions. Sales already recorded keep the parcels they used, and every record keeps its documents. The file's settings are ignored. A .zip export can be added too, and brings its documents with it. A backup copy of the portfolio is saved next to it first.
