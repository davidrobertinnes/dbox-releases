# Getting Started
Installing, opening your portfolio, and finding your way around

## What Dogbox Investments Does
Dogbox Investments keeps the records of your Australian shares and works out the tax figures that come from them: capital gains and losses, dividend income and franking credits. It's built around the Australian financial year (1 July to 30 June) and the ATO's rules, so the figures line up with your tax return.

It runs on your own computer. Your records are kept in a portfolio file (ending in .dinv) that stays on your computer. There's no account to sign up for and nothing is stored online.

Note: Dogbox Investments gives general information about your own records. It isn't tax advice. Check your figures against your statements, and with your accountant or the ATO if you're unsure.

## Installing
Download the installer for your computer from the Dogbox Software website.

- **Windows:** save install_dinv.bat, then double-click it. It installs Python if needed, puts Dogbox Investments in a DogboxInvestments folder in your user folder, and adds a **Dogbox Investments** shortcut to your desktop.
- **Mac:** save the installer, then right-click it and choose Open. It installs to a DogboxInvestments folder in your home folder and adds a shortcut to your desktop.
- **Linux:** paste the command from the website into a terminal. Start it afterwards with bash ~/DogboxInvestments/run.sh.

Running the installer again updates the program and keeps your portfolio files.

## Opening Dogbox Investments
Double-click the **Dogbox Investments** shortcut. It opens in its own window, like any other program. The first time, it creates an empty portfolio called portfolio.dinv in the DogboxInvestments folder.

If it's already open, the shortcut brings up the window that's already running instead of starting a second copy.

Closing the window closes Dogbox Investments.

## Your First Steps
1. Open **Settings** and fill in the Tax section, especially **Entity Type** (an individual, an SMSF or a company), because it decides which CGT rules apply. See the Settings guide.
2. Bring in your history. If you keep a spreadsheet of your shares, see the Importing and Exporting guide. If you're starting from scratch, add your purchases with **+ Buy** on the Holdings page.
3. Record dividends as they're paid, and sales when you sell.
4. Record company events (splits, returns of capital, demergers, takeovers) under **Corporate Actions** when they happen.
5. At tax time, open **FY Tax Summary** for the figures that go on your tax return.

## Finding Your Way Around
The menu on the left has:

- **Dashboard:** totals, recent activity and anything that needs your attention.
- **Holdings:** what you own now, or on any past date.
- **Transactions:** every purchase and sale.
- **Watch List:** companies you're watching, with target buy and sell prices.
- **Dividends:** every dividend, with franking credits and the 45-day rule.
- **FY Tax Summary:** the figures for your tax return for one financial year.
- **CGT Detail:** every sale and its capital gain or loss, and dividend detail.
- **Cost Base:** a reconciliation of your cost base from the start of a year to the end.
- **Corporate Actions:** splits, consolidations, bonus and rights issues, returns of capital, demergers, takeovers and share cancellations.
- **Securities:** the companies and funds in your portfolio.
- **Import / Export:** bring records in from a broker or spreadsheet, or save everything to one file.
- **Settings:** your details, tax settings, holdings, year locks and the audit log.
- **Help:** these guides.
- **Portfolios:** switch between portfolio files or start a new one.

Each company also has its own page, with its parcels, sales, dividends and corporate actions in one place. Open it from **Holdings** (View ›) or from the list on the **Securities** page.

## Portfolios
Each portfolio is one file. Keep one per taxpayer: for example one for yourself, one for your partner and one for an SMSF, since each has its own tax return.

Click **Portfolios** in the menu to see the portfolio files in the same folder as the one that's open, open a different one, or create a new one with **+ New Portfolio**. A new portfolio is created in that same folder.

## Backups
Your portfolio file holds all your records, so keep a copy of it somewhere safe, like any other important file. Copy the .dinv file to a USB drive or a cloud folder from time to time, with Dogbox Investments closed.

Dogbox Investments also makes its own copies when it matters. Before it corrects or recalculates a portfolio after an update, or before it adds a file to your portfolio, it saves a copy next to the portfolio file, ending in .bak.

**Import / Export → Export Everything** saves the whole portfolio as one spreadsheet file, which is another good backup. See the Importing and Exporting guide.

## Updates
Dogbox Investments checks for a new version once a day. When there is one, a banner shows what's new, and **Update now** installs it and restarts. Your portfolio files are never touched by an update.

The version number is at the bottom of the menu. Click it to check for an update straight away.

## If Something Isn't Right
If a figure looks wrong, open the company's page and check its purchases, dividends and corporate actions against your statements. Most differences come from a missing corporate action or a quantity entered in the wrong units after a split.

Settings → Audit Log shows every change and deletion, with what the record was before.
