# Joint and Inherited Shares
Shares held with someone else, moving shares between brokers, and shares from a deceased estate

## Holdings
A **holding** is one place your shares are registered: a HIN with a broker, or an SRN with a share registry. Setting up holdings is optional. It's useful when:

- you have shares with more than one broker or registry, and want to see them separately; or
- some shares are yours alone and some are held jointly with someone else.

To set them up, open **Settings → Holdings** and click **Add Holding**. Give each one a **Code** (a short name, for example csj), a **Name** (for example "CommSec, joint with Mary, HIN 0012345678") and **Your Share** of it: 100% if it's yours alone, 50% if you hold it equally with one other person.

Once you have holdings, purchase and sale forms ask which holding the shares are in, and sales only use shares from that holding. Holdings can also group the Holdings page (**By Holding**).

## Shares Held Jointly
Enter everything **in full**, as it appears on your statements: the full quantity bought, the full dividend paid. The tax pages and exports use your share of each holding, so your tax return figures are right.

If all the shares in a portfolio are held jointly in the same way, you can skip holdings and set **Settings → Your Share of These Holdings** instead (for example 50%).

Tip: keep a separate portfolio for each taxpayer. If you and your partner hold shares jointly, each of you can have a portfolio with the joint holding at 50%, alongside your own shares at 100%.

## Moving Shares Between Brokers
Moving shares from one broker or account to another with the same owners (for example CommSec to SelfWealth) isn't a sale and isn't taxed. Record it so your holdings stay right:

1. Open **Settings → Holdings** and click **Move Shares…** (it shows once you have two holdings).
2. Choose the holding the shares are moving **From** and **To**, and the **Date**.
3. Choose one **Security**, or **All securities**.
4. Click **Move**.

Every parcel of that security in the first holding moves. The parcels keep their purchase dates and cost bases. Moves are listed under **Moves between holdings**, where **Del** undoes one.

## When a Joint Holder Dies
When someone you hold shares jointly with dies, their share passes to you. Record it on the holding:

1. In **Settings → Holdings**, click **Joint holder died…** on the holding.
2. Enter the **Date of Death** and **Your Share Afterwards** (usually 100%).
3. If any shares in the holding were bought before 20 September 1985, enter their market value on the date of death. The part you inherit costs that value. Otherwise there's nothing else to enter.

Your share goes up from that date. Shares bought from 20 September 1985 keep their cost base and purchase dates.

## Inheriting Shares
When you inherit shares from a deceased estate, you take over the deceased's cost base, and for the CGT discount you're treated as having owned them since they bought them. For shares they bought before 20 September 1985, your cost base is instead their market value on the date of death.

To record one parcel, click **+ Inherited** on the company's page and enter:

- the **Date of Death** and the **Quantity**;
- the **Deceased's Purchase Date**; and
- the **Deceased's cost base**, or for shares they bought before 20 September 1985, the **market value** on the date of death.

Inherited parcels are marked **Inherited**.

## Moving a Whole Portfolio to a Beneficiary
If the deceased's shares are in their own Dogbox Investments portfolio, you don't need to enter them again:

1. Open the deceased's portfolio (**Portfolios** in the menu).
2. Open **Holdings**, change View to **Holdings at Date**, choose the date of death and click **Load**.
3. Click **Export as Inherited**. If they had shares bought before 20 September 1985, you're asked for their market value on the date of death. Save the file.
4. Open the beneficiary's portfolio, go to **Import / Export → Add to this portfolio**, choose the file and click **Preview Changes**, then add it.

The file has every parcel with the deceased's cost base and purchase dates. Jointly held shares are left out, because they pass to the surviving holder, not through the estate.

If the shares are split between several beneficiaries, each one's portfolio needs their own part. Edit the quantities in the file before adding it, or use **+ Inherited** instead.
