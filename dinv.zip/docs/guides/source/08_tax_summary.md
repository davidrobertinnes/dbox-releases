# FY Tax Summary and Cost Base
The figures for your tax return, and checking your cost base from year to year

## The FY Tax Summary
**FY Tax Summary** puts together the figures from your share records that go on your tax return for one financial year. Choose the year under **Financial Year ending 30 June** and click **Load**.

Warning: it's a summary of the records you've entered. Check the figures against your statements, and with your accountant if you have one, before you lodge.

## Dividend Income (Item 11)
- **11J:** unfranked dividends.
- **11K:** franked dividends, the cash part you received.
- **11L:** franking credits you can claim as a tax offset.

The total dividend income is the dividends plus the claimable franking credits.

Below the figures, notes tell you about anything that changed them:

- franking credits left out because the 45-day rule wasn't met;
- franking credits left out because a dividend has no ex-dividend date yet;
- when the small shareholder exemption applies (franking credits of $5,000 or less);
- franked dividends with no franking credit amount entered.

**11M** shows tax withheld from Australian companies' dividends because they didn't have your TFN.

See the Dividends guide for these rules.

## Dividends by Company
**Dividends by Company** breaks the Item 11 figures down the way the ATO's pre-filled tax return lists them: one line for each company and holding (HIN, SRN or broker account) for the year, with the unfranked amount, franked amount, franking credits and TFN amounts withheld. Jointly held shares show your share.

Use it to check the ATO's pre-filled dividends, or to type in dividends the ATO hasn't pre-filled. Click a line to see the dividends that make it up, because the ATO sometimes lists a company's dividends separately. **Show each dividend** opens every line.

The franking credits column shows all the credits on your statements. A **!** marks credits that are left out of 11L because of the 45-day rule (not met, or no ex-dividend date yet). Foreign companies are under Item 20 instead, unless they paid franked dividends.

The CSV and PDF exports include the same breakdown.

## Foreign Dividends (Item 20)
Shown when you have dividends from a company marked **Foreign company**:

- **20E:** assessable foreign source income, and **20M:** other net foreign source income — the dividends before foreign tax was withheld;
- **20O:** the foreign income tax offset — the foreign tax withheld, up to the treaty rate where one is set.

Add any other foreign income you have (for example foreign bank interest) to 20E and 20M yourself. A note shows any tax withheld above the treaty rate, which can't be claimed here, and flags an offset over $1,000, when the amount you can claim depends on your whole return.

**Foreign Dividends by Company** breaks these figures down by company and holding for the year, in Australian dollars: the foreign income (before foreign tax was withheld), the foreign tax withheld, and the offset you can claim. The lines add up to 20E, 20M and 20O. Click a line, or **Show each dividend**, to see the dividends that make it up. A **!** marks tax withheld above the treaty rate. The CSV and PDF exports include the same breakdown.

## Capital Gains (Item 18)
The capital gains section shows how the net capital gain is reached:

- gains on shares held less than 12 months, and on shares held 12 months or more;
- gains from returns of capital that went over the cost base;
- **18H:** total current year capital gains, before losses and the discount;
- less this year's capital losses, then losses carried forward from earlier years;
- less the CGT discount, applied after the losses;
- **18A:** net capital gain;
- **18V:** net capital losses carried forward to later years, shown every year a loss remains, even in a year with no sales.

See the Capital Gains Tax guide for how each step works.

## Tax Position Summary
At the bottom, the year's investment income is brought together: assessable dividend income (including foreign dividends), net capital gain, total assessable investment income, the franking credit tax offset, the foreign income tax offset and TFN amounts withheld.

For an SMSF in accumulation phase, a **Division 296** section is also shown from the 2026–27 year: the fund's Division 296 earnings from these investments (see the Capital Gains Tax guide).

## Saving and Printing
- **Export PDF** saves the summary as a PDF, to keep with your tax papers or send to your accountant.
- **Export CSV** saves the figures as a spreadsheet file.
- **Print Summary** prints it.

Tip: for the detail behind each figure (every sale, parcel by parcel, and every dividend), see **CGT Detail**, which has its own exports.

## Shares Held Jointly
If you've set your share of jointly held shares in Settings, every figure is your share. A note at the top of the page says so.

## Cost Base Reconciliation
**Cost Base** checks that your records add up from one year to the next. Choose the year and click **Load**. For each company it shows:

    opening cost base on 1 July
    + additions: purchases, DRPs, rights, bonus issues, demergers in
    − reductions: shares sold, returns of capital, demergers out
    = computed closing cost base

The computed figure is compared with the cost base of the shares you actually held on 30 June. If they match, the line shows **Reconciles**. If not, it shows **Discrepancy**: click it for the details, which usually point to a record to check.

**Export CSV** saves the reconciliation as a spreadsheet file.

## Locking a Year After You Lodge
Once you've lodged a year's tax return, lock it in **Settings → Financial Year Lock** so its figures can't change by accident. See the Settings guide.
