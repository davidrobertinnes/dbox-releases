# Design: CGT reform from 1 July 2027

Status: **design, not built** (2026-11-27). Law and guidance as read on 2026-11-27 — see NOTES.md
"CGT reform from 1 July 2027" for the sources and section references.

## 1. What the law requires (for this app's users)

Resident **individuals** (and trusts/partnerships, which Dogbox doesn't model separately), for CGT
events **on or after 1 July 2027**:

1. **No 50% discount** on gains accruing from 1 July 2027 (s 115-100). Instead the cost base is
   **indexed by CPI** quarter to quarter if the asset was held at least 12 months (s 110-36(1A),
   s 114-10, s 960-275(1B)). Indexation is **never used to work out a loss** (s 100-40(2)).
2. **Assets held at 30 June 2027** are treated as sold just before 1 July 2027 and bought back just
   after, at **market value just before 1 July 2027** (s 112-155). The notional gain/loss on that
   deemed sale is **deferred** to the year of the real sale (s 112-160) and keeps the old rules —
   50% discount if held 12 months; for assets bought 20 Sep 1985 – 21 Sep 1999 **only** the
   discount, no indexation choice (ATO table). The 12-month test counts the whole holding, ignoring
   the deemed sale (s 114-10(9)): bought less than 12 months before 1 July 2027 but held 12 months in
   total → discount on the deferred part *and* indexation on the later part.
3. **Pre-CGT assets** (acquired before 20 Sep 1985) stop being pre-CGT on 1 July 2027: the deemed
   sale's gain is disregarded and their cost base becomes the 1 July 2027 market value (s 112-175).
4. An **apportioning method** (instead of market value) may be chosen — not yet made (ATO, Oct 2026). Heffron
   (Sep 2026) says the ATO "put forward a draft" of it, for assets without a readily identifiable market value
   or for properties — so listed shares will use market value; the apportioning method matters little here.
5. **30% minimum tax** (Div 119) on individuals' net capital gains from post-2027 events — depends
   on the whole return; Dogbox can only estimate it.
6. Loss order (s 102-5(1) step 1): deferred non-residential, deferred residential, non-residential,
   residential losses. Shares are all **non-residential**.

Unchanged: **companies** (no discount before or after), **complying super funds** (keep 33⅓% — Heffron,
Sep 2026; see §12 q1), everything before 1 July 2027.

## 2. Scope

**Version 1 (build now — only changes figures for sales from 1 July 2027, so nothing current moves):**
CPI after 1999; 30 June 2027 values; split gain per sale row; pre-CGT parcels; reports (CGT Detail,
Item 18 components, Tax Summary page/CSV/PDF, Estimate Sale); guides; tests.

**Later:** the apportioning method (when the instrument exists); minimum tax estimate; 2028 return
labels (when the ATO publishes the 2027–28 form/instructions); corporate-action edge cases in §7 once
the ATO gives worked examples.

**Out of scope:** foreign/temporary residents (Dogbox assumes residents), residential property, small
business concessions.

## 3. Who gets the new rules

A setting-level switch on `entity_type`:

| entity_type        | from 1 Jul 2027                                  |
|--------------------|--------------------------------------------------|
| individual         | new rules (split, indexation, no discount after) |
| smsf (accumulation)| unchanged (33⅓% discount)                                |
| smsf pension       | unchanged (exempt)                               |
| company            | unchanged                                        |

`_new_rules(conn, event_date)` = entity is individual and event_date ≥ `REFORM_DATE = '2027-07-01'`.

## 4. Data

### 4.1 CPI (core/cpi.py)
- **The law (ITAA 1997, compiled 1 Oct 2026 — unchanged by Act 49 except s 960-275(1B)/(1C)):**
  - s 960-280(1): the index number is "the All Groups Consumer Price Index number (being the weighted
    average of the 8 capital cities) **first published** by the Australian Statistician for the quarter" —
    later ABS revisions of a quarter are ignored.
  - s 960-280(3): if the ABS changes the index reference period, only numbers published on the new
    reference period are used after the change.
  - s 960-275(1B): factor = index for the quarter of the CGT event ÷ index for the quarter the
    expenditure was incurred (on or after 1 Jul 2027; Note 1 covers the deemed reacquisition on
    1 Jul 2027 → the Sep 2027 quarter). (1C): later calls on partly-paid shares, from the quarter paid.
    s 960-275(4): never the third element (costs of ownership).
  - s 960-275(5): 3 decimal places, rounding up if the fourth is 5 or more (half-up).
  - s 960-270(2): no indexation if the factor is 1 or less.
- ABS (checked 28 Nov 2026): since Nov 2025 the ABS publishes a monthly CPI; the quarterly CPI "has been
  re-referenced and aligned to the new monthly CPI series", reference period **September 2025 = 100**.
  Quarterly figures are in Tables 17 and 18, and each new quarter is added in the March, June, September
  and December monthly releases (out late the following month). Every figure used under (1B) is from Sep
  2027 on, so all are on this reference period — unless the ABS re-references again (s 960-280(3)).
- ATO (checked 28 Nov 2026): its "Consumer price index (CPI) rates" page is still on the 2011–12 base,
  ending at Sep 2025 (143.6) with Dec 2025 "Nil", and it doesn't mention the new series. "Indexing the cost
  base" (updated 29 Jun 2026) covers only pre-1999 indexation: "Resources will be available at a later
  date". So the data source is the ABS, not the ATO; recheck the ATO before the first figure is needed
  (the Dec 2027 quarter, out late Jan 2028).
- Built (step 1): `core/cpi_2027.py` (generated: `REFERENCE_PERIOD`, `QUARTERS = {'2027-Q3': (index, date
  added)}`), from 2025-Q3 — quarters before 2027-Q3 aren't used by the law, only for reference and tests.
  Source: ABS Data API, dataflow `CPI`, key `1.10001.10.50.Q` (All groups, original, 8 capitals,
  quarterly); its "Reference Base Period" column detects a re-reference. `tools/update_cpi.py`
  **adds** quarters and never overwrites one (the first-published rule). If the ABS re-references, the
  tool replaces the whole table with numbers on the new period and records the change (s 960-280(3)).
  Ratios are taken within one reference period. The pre-1999 `CPI` table is unchanged.
- New `indexation_factor_2027(incurred, event)`: incurred quarter is the Sep 2027 quarter for the
  deemed reacquisition, or the real quarter for later expenditure (purchases after 1 Jul 2027,
  incidental costs). Returns `(factor, provisional)` — provisional when the event quarter's CPI isn't
  published yet (released ~4 weeks after quarter end): use the latest published quarter and flag it.
- `tools/update_cpi.py` + a release checklist line: add each quarter's figure (four times a year).

### 4.2 30 June 2027 values (existing `market_values` table)
- One row per security: `value_date = '2027-06-30'`, `price` = market value per share just before
  1 July 2027 **in units as at that date**. Reuses the table and the full export's `Value` rows, so
  import/export already round-trip.
- New column `market_values.source`: 'yahoo', 'entered' — shown so the user knows what to check.
- Needed for every security with a parcel held at the end of 30 Jun 2027 (any holding).

### 4.3 Per sale-parcel results (sale_parcels, new columns; all NULL for old-rule rows)

| column            | meaning                                                                  |
|-------------------|--------------------------------------------------------------------------|
| `pre_gain`        | deferred gain/loss on the deemed sale: MV − cost base just before 1 Jul 2027, for these units |
| `pre_basis`       | 'discount' / 'other' / 'pre_cgt' (disregarded)                          |
| `post_cost_base`  | MV for these units + later cost-base changes                            |
| `post_indexed_cb` | post_cost_base indexed (NULL if not held 12 months or a loss)            |
| `post_gain`       | proceeds − post_indexed_cb (gain) or proceeds − post_cost_base (loss)    |
| `rules`           | '2027' for split rows                                                    |

`gain_loss` stays as the **total** (pre + post) so existing totals, Dashboard realised gains and the
performance figures keep working; `discount_eligible` / `cgt_basis` describe the pre part.

## 5. Calculation (core/portfolio.py)

In `_rebuild_parcel_costs`, for each sale_parcels row where `_new_rules(sale_date)` and the parcel was
acquired before 1 Jul 2027 (`_cgt_acq` < REFORM_DATE):

1. `cb_then` = per-unit cost base at the end of 30 Jun 2027 (the existing `steps` replay: reductions
   dated ≤ 2027-06-30) × units.
2. `mv` = 30 Jun 2027 price ÷ `_split_factor(2027-06-30)` (to today's units) × units. Missing → the
   row is marked `needs_value` and left out of totals; CGT Detail lists it (see §6).
3. **Pre part:** `pre_gain = mv − cb_then`.
   - acquired before 20 Sep 1985 → `pre_basis = 'pre_cgt'`, gain disregarded;
   - gain > 0 and whole holding ≥ 12 months at the sale → 'discount'; else 'other' (losses 'other').
4. **Post part:** `post_cost_base = mv − (reductions dated after 2027-06-30, same-day rule as now)`.
   - held ≥ 12 months (whole holding, original acquisition date) and nominal gain > 0 →
     indexed from the Sep 2027 quarter to the sale quarter; gain = proceeds − indexed (not below 0:
     if indexation turns a gain into a loss, the gain is nil — s 100-40(2) "not in working out a
     capital loss");
   - else nominal (a loss is never indexed).
5. Parcels **acquired on or after 1 Jul 2027**: no pre part; post part as in 4 from the purchase cost,
   indexed from the purchase quarter.
6. `gain_loss = pre_gain + post_gain` (pre-CGT pre part counted as 0).

Returns of capital and C2 gains (`roc_parcels`, `roc_sold_parcels`) from 1 Jul 2027 on old parcels:
excess over the post cost base, no discount (G1 uses the indexed cost base when held 12 months, as the
existing pre-1999 rule does). Same `_new_rules` gate.

## 6. Reporting

- **`_fy_cgt_components`**: split rows contribute the pre part to `disc_*` / `short_*` by
  `pre_basis` and the post part to new `idx_gains` / `idx_losses` (non-discount). The ATO method then
  applies losses to non-discount gains first (already the app's order — best for the taxpayer, and
  consistent with step 1 since all shares are non-residential; deferred losses are applied first).
  `compute_fy_cgt` gains `deferred_gains`, `deferred_losses`, `indexed_gains` for display.
- **CGT Detail**: a split row shows two lines under the sale — "Up to 30 Jun 2027 (deferred)" and
  "From 1 Jul 2027 (indexed)" with value at 1 Jul 2027, CPI factor, and each part's taxable share.
  Rows missing a 30 Jun 2027 value: amber box "Enter the 30 June 2027 value for XYZ" with a link.
- **Tax Summary page, CSV, PDF**: Item 18 totals unchanged in shape (18H total gains, 18A net); a new
  sub-section "Gains on assets held at 1 July 2027" listing both parts. Item 18 labels get revisited
  when the 2027–28 return is published.
- **Estimate Sale**: uses the same split. Before 1 Jul 2027, an estimate dated after it uses today's
  price as a stand-in for the 30 Jun 2027 value (labelled). Shows a minimum-tax note ("a 30% minimum
  tax may apply to net capital gains — Dogbox can't work it out without your whole return").
- **Parcel history** (cost base history): an event row "Treated as sold and bought back at market
  value, 1 Jul 2027" with the deferred gain.

## 7. Corporate actions after 1 July 2027 on parcels held at that date

- Split/consolidation/bonus: units only — the 30 Jun 2027 value is converted with `_split_factor`.
- Return of capital: reduces the post cost base (§5.4).
- **Demerger / takeover roll-over:** the new parcel takes a share of the post cost base (as today).
  **Open:** how the deferred pre gain follows a roll-over (s 112-160 attaches it to the asset; the
  Act's roll-over interaction wasn't read). v1: carry the deferred gain to child parcels in the same
  proportion as the cost base, flag it in CGT Detail, revisit with ATO guidance.
- Inherited after 1 Jul 2027 from someone who held at 30 Jun 2027: **open** (deceased-estate rules).
  v1: the beneficiary's cost base as today; flag.

## 8. 30 June 2027 values — user flow

- **Before 30 Jun 2027:** Settings → "1 July 2027 values" explains the change; nothing to enter yet.
- **From 1 Jul 2027:** a Dashboard box "Record your 30 June 2027 values" listing each security held at
  the end of 30 Jun 2027 with the Yahoo closing price fetched (history API, unadjusted for later
  splits: take the raw close, or convert with our own split factors); the user confirms or edits.
  Delisted/suspended codes: entered by hand, with a note that the ATO's guidance says how to value
  them. Done once; stored in `market_values` and exported.
- The values are locked with the FY 2027–28 lock like other records.

## 9. Tests

- Unit: each acquisition band (pre-CGT, 1985–1999, 1999–2027 held ≥12m and <12m, bought < 12 months
  before 1 Jul 2027 but sold ≥12 months after, bought after 1 Jul 2027); gain/loss in each part
  (pre gain + post loss, pre loss + post gain); indexation not creating a loss; provisional CPI;
  missing value; split after 2027; RoC after 2027; SMSF/company unchanged; full export round trip.
- Before release: rerun every existing test (no pre-2027 figure may change); ATO worked examples when
  published, as fixtures.

## 10. Plan

| Step | What | When |
|------|------|------|
| 0 | Division 296 fix (§11): valuation-date flow for 30 Jun 2026, SMSF cost base reset election, drop phasing for SMSFs | **done 2026-11-27** (`valuation_list`, `fetch_close_on`, `compute_div296`) |
| 1 | CPI after 1999 (+ update tool), `indexation_factor_2027`, `_new_rules` | **done 2026-11-28** (`core/cpi_2027.py` from the ABS Data API, `tools/update_cpi.py`) |
| 2 | sale_parcels columns (migration), split calculation, G1/C2 gate | **done 2026-11-28** — backend (`_split_2027`, `_row_parts`, `_post_2027_base`, `reform_2027_status`), FY totals and taxable allocation, Estimate Sale; screens built but switched on from 1 Jul 2027 (`DINV_REFORM_PREVIEW=1` to test): Settings → 30 June 2027 Values, Dashboard reminder; CGT Detail split lines and "Value needed" warning show whenever such a sale exists |
| 3 | Reports: components, CGT Detail, Tax Summary, CSV, PDF, Estimate Sale, parcel history | Jan – Feb 2027 |
| 4 | Guides (07 CGT, 08 Tax Summary, 04 Estimate Sale), release | Feb 2027 |
| 5 | Check ATO market value guidance and worked examples; adjust; 30 Jun 2027 value flow | May – Jun 2027 |
| 6 | Prompt users to record 30 Jun 2027 values | Jul 2027 |
| 7 | Apportioning method, minimum tax estimate, 2027–28 return labels | when published / by Jul 2028 |

### Step 2 as built (2026-11-28)
- **Missing 30 June 2027 value:** the row is `rules = 'needs_value'`, counted as a non-discount gain on the
  old cost base (conservative — the deferred part could be discounted), and `compute_fy_cgt['needs_value']`
  counts them (CGT Detail warns). Entering the value re-costs the security (`set_market_value`).
- **Second cost base:** `parcels.cost_base` keeps the historical model (Holdings, reports before 2027 unchanged);
  the post-2027 cost base is tracked alongside in `_rebuild_parcel_costs` (`post_reduction` /
  `post_idx_reduction` on roc_parcels and demerger_parcels).
- **Returns of capital from 1 Jul 2027:** G1 above the post-2027 cost base (indexed if held 12 months), basis
  'indexed'/'other', no discount, pre-CGT shares no longer exempt. **C2** (sold before payment): basis 'other'.
- **Not yet handled (open, §7):** the deferred gain through a post-2027 demerger or roll-over takeover (the child
  parcel starts from its transferred cost base with no deferred part; roll-over takeover rows keep the old
  costing); inheritance of assets held at 30 Jun 2027.
- **Step 3 still to do:** Tax Summary page/CSV/PDF and CGT CSV showing the two parts; parcel history event row;
  guides (before the screens switch on).

## 11. Related: Division 296 (SMSFs) — checked 2026-11-27

ATO "About Division 296 tax for SMSFs" (updated 29 Jun 2026), read in Chrome:
- From 1 Jul 2026: 15% on a member's taxable super earnings above the large super balance threshold
  ($3M for 2026–27) and a further 10% above the very large threshold ($10M); thresholds indexed later.
  2026–27 tests the TSB at the end of the year; later years, at the start **or** end.
- The SMSF works out **Division 296 fund earnings — "an adjusted amount of fund taxable income"** (realised,
  not unrealised), attributes a share to in-scope members (an actuary usually needed) and reports it on
  the SMSF annual return from 2026–27.
- **CGT adjustment election (SMSFs):** reset the cost base of **all** directly held CGT assets to their
  **market value at the end of 30 June 2026**, for Division 296 fund earnings only (ordinary tax
  unchanged). Approved form (not yet issued); made **by the due date of the fund's 2026–27 annual return**;
  irrevocable; not lodged with the ATO; records kept per asset. A law companion ruling is being drafted.
- Secondary sources say the **phased capital gains relief applies to APRA-regulated funds, not SMSFs**.
- SMSF Australia, "SMSF capital gains tax" (smsfaustralia.com.au, undated, © 2026; read 2026-11-27): flat 15%
  above $3M and 10% more above $10M, **no phasing**; "a special carve out to exclude capital gains built up ...
  prior to 30th June 2026", opt-in "on or before the due date of their 2026/27 tax return"; realised earnings
  only. Says nothing on the 2027 reform. Its status lines are inconsistent (passed / awaiting assent) — use for
  corroboration only. Also: SMSF discount 1/3 after losses; wholly-pension funds disregard gains (Dogbox's
  `smsf_pension`); **unsegregated funds pay tax on the non-ECPI share (actuary's %) — Dogbox has no partial-ECPI
  option**, a separate gap.

**What this means for Dogbox:**
1. **The existing Division 296 section is probably wrong for SMSFs.** It applies a phased inclusion
   rate (20% FY2027, 40%, 60%, 80% FY2030+) to *gross* net capital gains (`cgt.js _cgtDiv296Html`,
   `server.py` tax summary CSV, `pdf_export.py` section 3; built 2026-06-27 from the announcement). The
   ATO's SMSF page has no phasing — instead the optional 30 June 2026 cost base reset — and fund
   earnings start from fund taxable income, which uses the 1/3-discounted gain. Fix before SMSF users
   report 2026–27: drop the phasing for SMSFs, add the election (a setting: made / not made), and work
   out the capital gain from the reset cost base when made. Exact adjustments to taxable income wait
   for the law companion ruling; say so on screen.
2. **Shared machinery with §4.2 / §5:** both need a market value per security at a date and a second
   cost base per parcel from that date. Build "valuation dates" once: `market_values` rows for
   2026-06-30 (Division 296 reset, SMSFs that elect) and 2027-06-30 (CGT reform, individuals), the same
   Yahoo-fetch-and-confirm flow (§8), and a helper giving a parcel's cost base reset to a valuation date.
3. **Timing:** the Division 296 election is due with the 2026–27 SMSF return, so SMSF users need
   their 30 June 2026 values **now**, a year before the 2027 values. So build the valuation-date flow
   first (for 2026-06-30), then reuse it for 2027.
4. Consistent with §3: Division 296 is an SMSF-member tax, separate from the 2027 reform; nothing here
   says super funds lose their 33⅓% discount.

## 12. Open questions (to settle before or during the build)

1. ~~Super funds: does the 33⅓% discount continue after 1 Jul 2027?~~ **Yes, per Heffron** (Lyn Formica, SMSF
   Adviser, 21 Sep 2026: "the changes don't apply to complying super funds, so SMSFs will still be entitled to
   their one-third discount if they've owned that asset for at least 12 months"). Consistent with the Act
   (s 115-100(ab) excludes complying super from the trust rule) and the ATO (individuals, trusts, partnerships).
   Still worth an ATO line when one appears.
2. ~~CPI series/base and rounding for s 960-275(1B).~~ **Settled by the existing law** (§4.1): All Groups,
   8 capitals, first published; 3 decimals half-up; no indexation at 1 or less; new reference period only.
   The ATO hasn't published a CPI table on the new ABS base yet (28 Nov 2026) — use the ABS figures.
3. Market value of listed shares "just before 1 July 2027": the 30 June 2027 close? (ATO guidance due.)
4. Deferred gain through demergers, takeovers with roll-over, and inheritance.
5. Parcels with indexation fixed by an earlier return of capital (`cgt_fixed`): the ATO table says the
   pre part takes the discount only — confirm what happens where indexation was already locked in.
6. Whether the 2027–28 return splits Item 18 into new labels.
