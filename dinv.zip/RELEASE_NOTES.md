# Dogbox Investments — Release Notes

## 1.1.0

**Older shares:** shares bought before 20 September 1985 are now shown as **pre-CGT** and their sales are exempt from CGT. Shares bought before 21 September 1999 can use the **indexation** method: sales before that date are indexed automatically, and for later sales you choose the CGT discount or indexation in Settings (or for each sale). Companies always use indexation. The CGT page shows the method used for each sale.

**Inherited shares:** record shares inherited from a deceased estate with **+ Inherited** on a security's page. You take over the deceased's cost base and purchase date, or for shares they bought before 20 September 1985, the market value on the date of death. To move a whole portfolio, open the deceased's portfolio, choose **Holdings → Holdings at Date → Export as Inherited** for the date of death, then add that file to the beneficiary's portfolio.

**Bonus issues** are now entered as a ratio (for example 1 for every 10 held). The cost base is spread over your original and bonus shares, and the bonus shares keep the original purchase date, as the ATO requires. Bonus issues you entered before are converted the first time you open the portfolio.

**Add to this portfolio:** **Import / Export → Add to this portfolio** adds the records in a file to the portfolio that's open, for example older purchases. Purchases dated before later splits and other corporate actions get those actions applied. You see which years' tax figures change before anything is saved.

**Your own spreadsheet layout:** imports also accept total cost instead of price, a single ratio for splits and consolidations, dividend totals (franked, unfranked, credit), and parcel labels. A sale can name the parcels it uses, e.g. `amp,drp22,MIN`.

**Editing purchases** now shows the quantity and price from your contract note, even after later splits or consolidations, and you can enter a total cost instead of a price. Tax-year lists go back to your earliest records.

**Share cancellations:** when a company cancels some of your shares and pays you for them, choose **Share Cancellation** under Corporate Actions and enter the number of shares cancelled and the total payment. It's recorded as a disposal (CGT event C2), as the ATO requires: the payment is your capital proceeds, each parcel gives up the same proportion of its shares, and the capital gain or loss appears in your CGT figures. Sales can also now use **Pro rata** parcel matching.

**Code and name changes:** if a company changed its code or name (for example WPL to WDS), record it under **Securities → Edit → Code & name changes**. Each year's tax reports use the code and name in effect on 30 June of that year.

**Export and import everything:** **Import / Export → Export Everything** saves your whole portfolio as one CSV file, including which parcels each sale used. Importing it into a new portfolio gives exactly the same figures, so you can keep your records in a spreadsheet and rebuild the portfolio from it at any time. Your TFN isn't included in the file.

**Events on the same day:** Dogbox now always applies events on the same day in one order: purchases first, then corporate actions, then sales. So shares you sell on the day of a return of capital or demerger still receive it, and bonus or rights shares issued that day don't. Portfolios with these cases are recalculated the first time you open them, with a backup saved first and changed figures listed in Settings → Audit Log.

**Fixed:** in the CGT schedule, a sale that used more than one parcel showed the whole sale's quantity and proceeds on each parcel's line. Each line now shows its own share. Your capital gain totals were not affected.

## 1.0.1

**Cost base fix:** a return of capital or demerger on the same day as a share split or consolidation could end up with the wrong cost base. The figure was right when you entered it but could change later, after you added, edited or deleted something else for that security. The return of capital or demerger is now always applied first, before any split or consolidation that day, matching the order share registries use. Enter its amount per share held *before* the split or consolidation.

Portfolios affected by this are recalculated the first time you open them. A backup copy is saved next to the file first (ending in `.bak`), and any changed figures are listed in Settings → Audit Log.

**Also fixed:** the **+ Action** button on a security's page now offers every corporate action type, including Return of Capital and Demerger.

## 1.0.0

Dogbox Investments now has version numbers and updates itself: when a new version is out, a banner offers to install it and restart. Your portfolio files are never touched by an update.

This release corrects several tax calculations. The first time you open each portfolio, it is recalculated under the corrected rules. A backup copy is saved next to it first (ending in `.bak`), and every changed figure is listed in Settings → Audit Log. Figures for years you've already lodged can change if they were affected, so it's worth checking those years.

**Capital gains**
- Capital losses (this year's, then carried-forward) are now subtracted before the 50% CGT discount, as the ATO requires. The discount applies only to the discount-eligible gain that's left.
- The "Taxable Gain" column for each sale now adds up to the Net capital gain at 18A.
- The CGT discount now starts the day after the first anniversary of purchase, not on the anniversary.
- Returns of capital and demergers on holdings you'd partly sold now give the right cost base, and any excess capital gain is reported.
- Sales can no longer use shares bought after the sale date, and selling more shares than you hold is rejected.
- Purchases entered after a split, return of capital or demerger, but dated before it, now have it applied.
- SMSFs in pension phase: all capital gains are exempt and capital losses are disregarded.

**Dividends**
- Partly franked dividends are now split between 11K (franked) and 11J (unfranked).
- The small shareholder exemption is applied: individuals with $5,000 or less in franking credits for the year don't need to meet the 45-day holding period rule.
- The 45-day rule now counts "at least 45 days", from the day after purchase.
- Franking credits are no longer estimated at 30% — enter the amount shown on your dividend statement.

**Other**
- Holdings at a past date are shown correctly across share splits, with the cost base of the shares held on that date.
- The sale estimator and the watch list "Divest" tab use the same CGT rules as your tax summary.
- Settings uses the current income tax rates.
- Broker CSV imports are applied in date order, so newest-first files import correctly.
