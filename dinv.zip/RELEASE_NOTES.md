# Dogbox Investments — Release Notes

## 1.10.0

**Cost base history for a parcel:** click **History** on a parcel on a company's page to see how its cost base changed with each event: the purchase, returns of capital, demergers, splits and consolidations, and sales. Each line shows the units held, the cost base per share and the total cost base, in the units of the time so they match your statements. Enter an **As at** date to see it up to that date. If the parcel came from a takeover, redomicile or demerger, the earlier parcel's history is shown first, back to the original purchase. It's a quick way to spot a missing corporate action.

**The code at the time:** the Transactions, Dividends and Corporate Actions pages show the code a company had on each entry's date, so it matches your contract notes and statements (for example HGG rather than today's JHG). Hover over the code to see today's code; searching for either code finds the entry.

**Smaller changes:**
- The master file template's example tax rate is now 30% (it was 32.5%, a rate removed in 2024).

## 1.9.0

**Companies that move country:** Corporate Actions has a new **Redomicile (company moves country)** action for a company that swaps your shares for shares in a new parent company in another country under the same code, as AVITA, Piedmont and Boart Longyear did when they moved to the US and Canada, and Civmec when it moved to Australia. Dogbox Investments records the swap as a takeover (with scrip-for-scrip roll-over by default, so your cost base and acquisition dates carry over), keeps the old company under its old code, and treats dividends from the new company as foreign or Australian.

**Residency changes:** for a company that becomes foreign, or Australian, without a share swap, open the security under Securities, click **Edit** and add a **Residency change** with the date. Each dividend then goes to Item 11 or Item 20 according to the date it was paid.

**Employee share plan shares:** **+ Employee Shares** on a company's page records shares from a plan taxed upfront, such as the Wesfarmers Employee Share Acquisition Plan. Enter the market value from your ESS statement as the cost base, and the date the restriction ends. Sales won't use them before then unless you pick them yourself.

**45-day rule without an ex-dividend date:** a dividend with no ex-dividend date or record date no longer always shows **?**. If the answer is the same whatever the ex-dividend date was (for example, shares bought years ago and still held 45 days after the payment date), Dogbox Investments now shows ✓ or ✗, and the FY Tax Summary counts those franking credits.

**Fix — editing purchases on the Transactions page:** after a split or consolidation, the Transactions page showed today's units, and saving a purchase there could convert them a second time and double the parcel. Purchases now show the quantity and price from the contract note, as on the company's page. If you've edited a purchase on the Transactions page since a split or consolidation, check its quantity on the company's page.

**Smaller changes:**
- The Edit Dividend form shows quantities, amounts and franking percentages without long trailing decimals.
- Hover over **Gross** on the Dividends page for what it means: the gross payment on your statement, before any tax withheld. The franking credit is shown separately.
- The Edit and Del buttons now line up whether or not a row has a 📎 or **Method** button.

## 1.8.0

**Foreign Dividends by Company:** the FY Tax Summary now breaks down foreign dividends the same way as Australian ones. Under Item 20 there's one line for each foreign company and holding for the year, in Australian dollars: the foreign income before tax was withheld, the foreign tax withheld, and the offset you can claim (your share for joint holdings). The lines add up to 20E, 20M and 20O. Click a line, or **Show each dividend**, to see the dividends that make it up. A ! marks tax withheld above the treaty rate. It's also in the CSV and PDF exports.

**FY Tax Summary:** the warning notes now show a ⚠ sign instead of a question mark.

## 1.7.0

**Dividends by Company:** the FY Tax Summary has a new section that lists your dividends the way the ATO's pre-filled tax return does: one line for each company and holding for the year, with the unfranked amount, franked amount, franking credits and TFN amounts withheld (your share for joint holdings). Use it to check the ATO's pre-filled figures, or to enter dividends the ATO hasn't pre-filled. Click a line to see the dividends that make it up, because the ATO sometimes lists them separately. **Show each dividend** opens them all. It's also in the CSV and PDF exports.

**Documents on your records:** keep contract notes, dividend statements and other papers with the record they belong to. Every purchase, sale, dividend and corporate action has a 📎 button: drop in or choose PDFs, photos or scans, then open or save them any time. They're stored in your portfolio file, so copies and backups include them. The ATO asks you to keep these records for capital gains, and now they're in one place.

**Export with Documents:** Import/Export has a new **Export with Documents (.zip)** that includes your documents with the full export, and the import options accept the .zip.

**Dividend form:** when you enter Tax Withheld, the form now shows what was paid to you after tax and says it should match your statement. That makes it easy to spot a net amount entered as the amount per share by mistake, which would understate your income and the tax offset. Amount Per Share is always before tax withheld.

## 1.6.0

**Foreign companies:** tick **Foreign company** on a security (Securities, **Edit**) for a company based overseas, such as Newmont. Its dividends now go on your tax return as foreign income (Item 20E and 20M) instead of Australian unfranked dividends, and the foreign tax withheld becomes the foreign income tax offset (Item 20O). If you know the tax treaty rate (for example 15% for US dividends), enter it on the security: anything withheld above it is shown as not claimable. The FY Tax Summary has a new Foreign Dividends section, and flags an offset over $1,000, when the amount you can claim depends on your whole return.

**Tax withheld:** dividends have a new **Tax Withheld** field. For an Australian company it's tax withheld because no TFN was given (Item 11M); for a foreign company it's the foreign tax.

**Amounts in US$:** type the amount per share and tax withheld as they appear on the statement, for example **US$0.25**, and enter the **Exchange Rate** (A$ per US$1). Dogbox Investments converts them and keeps everything in Australian dollars. Master files can do the same, with the exchange rate in Ratio and the tax in a Withheld column.

If you've been entering foreign dividends as Australian ones, tick Foreign company on the security and edit those dividends: amount per share before tax, no franking, and the tax in Tax Withheld. The Dividends guide under **Help** has the details.

**Securities:** editing an inactive security no longer makes it active again.

## 1.5.0

**Automatic backups:** Dogbox Investments now backs up your portfolio for you. While it's open, it saves a copy once a day if anything has changed, and again when you quit, update or switch to another portfolio. Each backup is a complete copy of the portfolio, named with the date and time, and the newest 10 are kept. A copy is only made when something has changed.

Backups go to a **Dogbox Backups** folder in your Documents folder. To keep a copy off your computer as well, choose a folder that's synced to the cloud (OneDrive, Dropbox or Google Drive) or on a USB drive under **Settings → Backups**. That's also where you can turn backups off, choose how many to keep, and make one straight away with **Back Up Now**.

To go back to a backup, copy it into your DogboxInvestments folder and open it with **Portfolios**. The Getting Started guide under **Help** has more.

## 1.4.0

**User guides:** Dogbox Investments now has a full set of guides, under **Help** in the menu. They cover getting started, holdings, buying and selling, dividends and the 45-day rule, corporate actions, capital gains tax, the FY Tax Summary, joint and inherited shares, importing (including the master file format), the watch list and settings. Search finds a word across all of them, and each guide has a **PDF** button to print or save it.

**Franking credits on a company's page:** the dividend form on a company's own page filled in the franking credit from the franking percentage at the 30% company tax rate, and recalculated it when you changed the amount. For companies taxed at the 25% base rate, that made a fully franked dividend's credit a third too high. It now works like the Dividends page: enter the franking credit dollar amount from your dividend statement. If you entered dividends from a company's page, check their franking credits against your statements, especially for smaller companies.

**Settings:** the Default Financial Year End setting has been removed. It wasn't used: your tax figures always use the Australian financial year to 30 June.

## 1.3.2

**Franking percentages:** a franking percentage worked out from a dividend statement's totals now shows to at most 2 decimals (e.g. 90.48% instead of 90.47619047619048%) in CGT Detail, Dividends, the security page and the Dividend Income CSV.

**Shares held on dividends:** the number of shares held on a dividend's date no longer shows a tiny rounding error such as 5253.0000000002 after a bonus issue, split or demerger. The Dividend Income CSV shows quantities to at most 4 decimals.

**Print Summary:** printing the FY Tax Summary now prints the whole report across the full page, instead of a narrow column cut off after one screen.

**Name:** CSV exports, PDFs and the import template now say "Dogbox Investments" throughout.

## 1.3.1

**Cost Base Reconciliation:** a purchase or DRP made during the year and followed by a return of capital later that year had the return of capital taken off twice, so the report showed a discrepancy that wasn't there. Additions are now counted at what they cost, and the report balances.

**Capital losses carried forward:** the FY Tax Summary (on screen, PDF and CSV) now shows **net capital losses carried forward (18V)** every year a loss remains, including years with no sales. It goes on your tax return each year.

**Sold-out companies:** a company you've sold out of no longer stays on the dashboard with 0 shares when a split or merger ratio left a tiny fraction of a share behind.

**Long ratios:** a ratio such as 1,411,571-for-999,466 now shows as ×1.41233. Simple ratios like 4-for-5 still show as announced.

**FY Tax Summary layout:** the page and the update banner are properly laid out and styled again.

**CGT discount hint when selling:** the **Disc** badge on parcels in the sale form now uses the ATO's 12-month rule, measured to the sale date you enter (and from the deceased's purchase date for inherited shares). The tax figures already used this rule.

**Usage count:** once a day, when Dogbox Investments checks for updates, it also sends a random install number, the version and your operating system, so we can count how many people use it. Nothing about you or your portfolio is sent. See the privacy policy on our website.

## 1.3.0

**Faster imports on a network drive:** importing a master file, or adding one to a portfolio, now builds the portfolio in a temporary file on your computer and copies it into place once at the end. If your portfolio is on a network drive, this takes seconds instead of about a minute.

**Dashboard figures:** **Total invested** is now what you actually paid: purchases, DRPs, and the starting cost of inherited shares. Shares that came from other shares (takeovers, demergers, bonus issues, a joint holder's death) are no longer counted a second time, and returns of capital no longer reduce it. **Disposals** shows the cash you received; the new shares from a takeover aren't counted as proceeds.

**Export as Inherited** keeps cost bases to the full precision instead of rounding them to whole cents, so the beneficiary's figures are no longer a cent out.

**Error messages** stay on screen until you click OK, so a long import error can be read in full.

**Port clashes:** if another program is using port 5100, Dogbox Investments now starts on the next free port instead of failing. Opening a portfolio that's already open brings up its window, and a second portfolio gets its own port. You can choose the port under **Settings → App → Port**.

## 1.2.0

**Takeovers and mergers:** choose **Takeover / Merger** under Corporate Actions when a company is taken over for cash and/or shares in another company. Enter the cash and new shares for each share you held, and the market value of a new share on the day. With scrip-for-scrip roll-over, only the cash is taxed now: the part of your cost base that relates to the cash is worked out as the ATO requires, the rest moves to the new shares, and they keep your original purchase dates for the CGT discount. Without roll-over (shares bought before 20 September 1985, a loss, or if you don't choose it) the takeover is a full disposal, and the new shares cost their market value. It appears under Sales with its capital gain or loss.

**Holdings:** record each HIN, SRN or broker account under **Settings → Holdings**, with your share of it (100% if it's yours alone, 50% if held jointly). Joint and sole holdings can now share one portfolio: enter everything in full, as on your statements, and the tax pages and exports use your share of the holding the shares were in. Sales only use shares in their own holding. **Move Shares** records a transfer between brokers (not a CGT event). **Joint holder died** records a joint holder's death: your share goes up from that date, and for shares bought before 20 September 1985 the part you inherit costs its market value on the date of death. Export as Inherited leaves out jointly held shares, since they pass to the surviving holder.

**Choosing parcels when you sell:** with **Specific Parcels** you can now enter how many shares come from each parcel, for example 27 from one and 3 from another. Leave the quantities blank to use the ticked parcels in order, as before.

**Dividend record dates:** dividends have a **Record Date**. If you leave the ex-dividend date blank for a dividend with a record date from 9 March 2016, it's taken as the business day before, so the 45-day rule can still be checked (shown as estimated). Imports use the record date to work out the shares entitled to a dividend when there's no ex-date.

**Master file template:** **Import / Export → Download Master File Template** gives an example spreadsheet with every row type and a note on each, to start your own master file from. **Master file format** on the same page lists the row types and their columns.

**Bonus issues by number of shares:** an imported `Bonus` row can give the bonus shares received, as on your statement, instead of a ratio. The cost base is now spread over your original and bonus shares, which keep the original purchase dates. Before, imported rows like this made the bonus shares a separate parcel costing nothing, dated the issue date, so their capital gain was overstated, and bonus shares on pre-CGT shares lost their exemption. Portfolios with such parcels are corrected the first time you open them (backup saved, changes in Settings → Audit Log).

**Export as Inherited** now asks for the market value at the date of death of any shares the deceased bought before 20 September 1985, and puts it in the file as their cost. Before, you had to fill these in yourself.

**Imports** also accept `Merger`, `Holding`, `Transfer` and `Value` rows, a `Holding` column, and consolidations given as the change in the number of shares (for example `Con` −6), with an optional same-day return of capital in the Cost column. A dividend row with nothing but zeros now says it's empty. When master files are kept per holding, a corporate action listed in more than one of them is recorded once.

**Returns of capital on older shares:** for shares bought before 21 September 1999, a return of capital that's more than the cost base can now use **indexation**, as the ATO allows. Before, its capital gain always used the CGT discount. Once a return of capital makes a gain with one method, later sales of those shares use the same method, as the ATO requires. Choose the method for a parcel with the new **Method** button on a security's page. Affected portfolios are recalculated the first time you open them, with a backup saved first and changed figures listed in Settings → Audit Log.

**Shares held jointly:** keep them in their own portfolio and set **Settings → Your Share of These Holdings** (for example 50%). Enter everything in full, as on your statements; dividends, franking credits and capital gains on the tax pages and exports show your share.

**Imports** accept a few more spreadsheet layouts: dividend rows with only the DRP shares, a return of capital given as a total amount, and `ExDiv` and `Code2` column names.

## 1.1.0

**Older shares:** shares bought before 20 September 1985 are now shown as **pre-CGT** and their sales are exempt from CGT. Shares bought before 21 September 1999 can use the **indexation** method: sales before that date are indexed automatically, and for later sales you choose the CGT discount or indexation in Settings (or for each sale). Companies always use indexation. The CGT page shows the method used for each sale.

**Inherited shares:** record shares inherited from a deceased estate with **+ Inherited** on a security's page. You take over the deceased's cost base and purchase date, or for shares they bought before 20 September 1985, the market value on the date of death. To move a whole portfolio, open the deceased's portfolio, choose **Holdings → Holdings at Date → Export as Inherited** for the date of death, then add that file to the beneficiary's portfolio.

**Bonus issues** are now entered as a ratio (for example 1 for every 10 held). The cost base is spread over your original and bonus shares, and the bonus shares keep the original purchase date, as the ATO requires. Bonus issues you entered before are converted the first time you open the portfolio.

**Add to this portfolio:** **Import / Export → Add to this portfolio** adds the records in a file to the portfolio that's open, for example older purchases. Purchases dated before later splits and other corporate actions get those actions applied. You see which years' tax figures change before anything is saved.

**Your own spreadsheet layout:** imports also accept total cost instead of price, a single ratio for splits and consolidations, dividend totals (franked, unfranked, credit), and parcel labels. A sale can name the parcels it uses, e.g. `amp,drp22,MIN`.

**Editing purchases** now shows the quantity and price from your contract note, even after later splits or consolidations, and you can enter a total cost instead of a price. Tax-year lists go back to your earliest records.

**Share cancellations:** when a company cancels some of your shares and pays you for them, choose **Share Cancellation** under Corporate Actions and enter the number of shares cancelled and the total payment. It's recorded as a disposal (CGT event C2), as the ATO requires: the payment is your capital proceeds, each parcel gives up the same proportion of its shares, and the capital gain or loss appears in your CGT figures. Sales can also now use **Pro rata** parcel matching.

**Code and name changes:** if a company changed its code or name (for example WPL to WDS), record it under **Securities → Edit → Code & name changes**. Each year's tax reports use the code and name in effect on 30 June of that year.

**Export and import everything:** **Import / Export → Export Everything** saves your whole portfolio as one CSV file, including which parcels each sale used. Importing it into a new portfolio gives exactly the same figures, so you can keep your records in a spreadsheet and rebuild the portfolio from it at any time. Your TFN isn't included in the file.

**Events on the same day:** Dogbox now always applies events on the same day in one order: purchases first, then corporate actions, then sales. So shares you sell on the day of a return of capital or demerger still receive it, and bonus or rights shares issued that day don't. Portfolios with these cases are recalculated the first time you open them, with a backup saved first and changed figures listed in Settings → Audit Log.

**Fixed:** in the CGT schedule, a sale that used more than one parcel showed the whole sale's quantity and proceeds on each parcel's line. Each line now shows its own share. Your capital gain totals were not affected.

## 1.0.1

**Cost base fix:** a return of capital or demerger on the same day as a share split or consolidation could end up with the wrong cost base. The figure was right when you entered it but could change later, after you added, edited or deleted something else for that security. The return of capital or demerger is now always applied first, before any split or consolidation that day, matching the order share registries use. Enter its amount per share held *before* the split or consolidation.

Portfolios affected by this are recalculated the first time you open them. A backup copy is saved next to the file first (ending in `.bak`), and any changed figures are listed in Settings → Audit Log.

**Also fixed:** the **+ Action** button on a security's page now offers every corporate action type, including Return of Capital and Demerger.

## 1.0.0

Dogbox Investments now has version numbers and updates itself: when a new version is out, a banner offers to install it and restart. Your portfolio files are never touched by an update.

This release corrects several tax calculations. The first time you open each portfolio, it is recalculated under the corrected rules. A backup copy is saved next to it first (ending in `.bak`), and every changed figure is listed in Settings → Audit Log. Figures for years you've already lodged can change if they were affected, so it's worth checking those years.

**Capital gains**
- Capital losses (this year's, then carried-forward) are now subtracted before the 50% CGT discount, as the ATO requires. The discount applies only to the discount-eligible gain that's left.
- The "Taxable Gain" column for each sale now adds up to the Net capital gain at 18A.
- The CGT discount now starts the day after the first anniversary of purchase, not on the anniversary.
- Returns of capital and demergers on holdings you'd partly sold now give the right cost base, and any excess capital gain is reported.
- Sales can no longer use shares bought after the sale date, and selling more shares than you hold is rejected.
- Purchases entered after a split, return of capital or demerger, but dated before it, now have it applied.
- SMSFs in pension phase: all capital gains are exempt and capital losses are disregarded.

**Dividends**
- Partly franked dividends are now split between 11K (franked) and 11J (unfranked).
- The small shareholder exemption is applied: individuals with $5,000 or less in franking credits for the year don't need to meet the 45-day holding period rule.
- The 45-day rule now counts "at least 45 days", from the day after purchase.
- Franking credits are no longer estimated at 30% — enter the amount shown on your dividend statement.

**Other**
- Holdings at a past date are shown correctly across share splits, with the cost base of the shares held on that date.
- The sale estimator and the watch list "Divest" tab use the same CGT rules as your tax summary.
- Settings uses the current income tax rates.
- Broker CSV imports are applied in date order, so newest-first files import correctly.
