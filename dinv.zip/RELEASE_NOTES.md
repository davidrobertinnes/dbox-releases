# Dogbox Investments — Release Notes

## 1.0.1

**Cost base fix:** a return of capital or demerger on the same day as a share split or consolidation could end up with the wrong cost base. The figure was right when you entered it but could change later, after you added, edited or deleted something else for that security. The return of capital or demerger is now always applied first, before any split or consolidation that day, matching the order share registries use. Enter its amount per share held *before* the split or consolidation.

Portfolios affected by this are recalculated the first time you open them. A backup copy is saved next to the file first (ending in `.bak`), and any changed figures are listed in Settings → Audit Log.

**Also fixed:** the **+ Action** button on a security's page now offers every corporate action type, including Return of Capital and Demerger.

**Tip:** a share cancellation paid out as a return of capital can be recorded as a Return of Capital plus a Consolidation on the same day.

## 1.0.0

Dogbox Investments now has version numbers and updates itself: when a new version is out, a banner offers to install it and restart. Your portfolio files are never touched by an update.

This release corrects several tax calculations. The first time you open each portfolio, it is recalculated under the corrected rules. A backup copy is saved next to it first (ending in `.bak`), and every changed figure is listed in Settings → Audit Log. Figures for years you've already lodged can change if they were affected, so it's worth checking those years.

**Capital gains**
- Capital losses (this year's, then carried-forward) are now subtracted before the 50% CGT discount, as the ATO requires. The discount applies only to the discount-eligible gain that's left.
- The "Taxable Gain" column for each sale now adds up to the Net capital gain at 18A.
- The CGT discount now starts the day after the first anniversary of purchase, not on the anniversary.
- Returns of capital and demergers on holdings you'd partly sold now give the right cost base, and any excess capital gain is reported.
- Sales can no longer use shares bought after the sale date, and selling more shares than you hold is rejected.
- Purchases entered after a split, return of capital or demerger, but dated before it, now have it applied.
- SMSFs in pension phase: all capital gains are exempt and capital losses are disregarded.

**Dividends**
- Partly franked dividends are now split between 11K (franked) and 11J (unfranked).
- The small shareholder exemption is applied: individuals with $5,000 or less in franking credits for the year don't need to meet the 45-day holding period rule.
- The 45-day rule now counts "at least 45 days", from the day after purchase.
- Franking credits are no longer estimated at 30% — enter the amount shown on your dividend statement.

**Other**
- Holdings at a past date are shown correctly across share splits, with the cost base of the shares held on that date.
- The sale estimator and the watch list "Divest" tab use the same CGT rules as your tax summary.
- Settings uses the current income tax rates.
- Broker CSV imports are applied in date order, so newest-first files import correctly.
