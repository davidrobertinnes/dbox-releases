# Dogbox Investments — Release Notes

## 1.3.1

**Cost Base Reconciliation:** a purchase or DRP made during the year and followed by a return of capital later that year had the return of capital taken off twice, so the report showed a discrepancy that wasn't there. Additions are now counted at what they cost, and the report balances.

**Capital losses carried forward:** the FY Tax Summary (on screen, PDF and CSV) now shows **net capital losses carried forward (18V)** every year a loss remains, including years with no sales. It goes on your tax return each year.

**Sold-out companies:** a company you've sold out of no longer stays on the dashboard with 0 shares when a split or merger ratio left a tiny fraction of a share behind.

**Long ratios:** a ratio such as 1,411,571-for-999,466 now shows as ×1.41233. Simple ratios like 4-for-5 still show as announced.

**FY Tax Summary layout:** the page and the update banner are properly laid out and styled again.

**CGT discount hint when selling:** the **Disc** badge on parcels in the sale form now uses the ATO's 12-month rule, measured to the sale date you enter (and from the deceased's purchase date for inherited shares). The tax figures already used this rule.

**Usage count:** once a day, when Dogbox Investments checks for updates, it also sends a random install number, the version and your operating system, so we can count how many people use it. Nothing about you or your portfolio is sent. See the privacy policy on our website.

## 1.3.0

**Faster imports on a network drive:** importing a master file, or adding one to a portfolio, now builds the portfolio in a temporary file on your computer and copies it into place once at the end. If your portfolio is on a network drive, this takes seconds instead of about a minute.

**Dashboard figures:** **Total invested** is now what you actually paid: purchases, DRPs, and the starting cost of inherited shares. Shares that came from other shares (takeovers, demergers, bonus issues, a joint holder's death) are no longer counted a second time, and returns of capital no longer reduce it. **Disposals** shows the cash you received; the new shares from a takeover aren't counted as proceeds.

**Export as Inherited** keeps cost bases to the full precision instead of rounding them to whole cents, so the beneficiary's figures are no longer a cent out.

**Error messages** stay on screen until you click OK, so a long import error can be read in full.

**Port clashes:** if another program is using port 5100, Dogbox Investments now starts on the next free port instead of failing. Opening a portfolio that's already open brings up its window, and a second portfolio gets its own port. You can choose the port under **Settings → App → Port**.

## 1.2.0

**Takeovers and mergers:** choose **Takeover / Merger** under Corporate Actions when a company is taken over for cash and/or shares in another company. Enter the cash and new shares for each share you held, and the market value of a new share on the day. With scrip-for-scrip roll-over, only the cash is taxed now: the part of your cost base that relates to the cash is worked out as the ATO requires, the rest moves to the new shares, and they keep your original purchase dates for the CGT discount. Without roll-over (shares bought before 20 September 1985, a loss, or if you don't choose it) the takeover is a full disposal, and the new shares cost their market value. It appears under Sales with its capital gain or loss.

**Holdings:** record each HIN, SRN or broker account under **Settings → Holdings**, with your share of it (100% if it's yours alone, 50% if held jointly). Joint and sole holdings can now share one portfolio: enter everything in full, as on your statements, and the tax pages and exports use your share of the holding the shares were in. Sales only use shares in their own holding. **Move Shares** records a transfer between brokers (not a CGT event). **Joint holder died** records a joint holder's death: your share goes up from that date, and for shares bought before 20 September 1985 the part you inherit costs its market value on the date of death. Export as Inherited leaves out jointly held shares, since they pass to the surviving holder.

**Choosing parcels when you sell:** with **Specific Parcels** you can now enter how many shares come from each parcel, for example 27 from one and 3 from another. Leave the quantities blank to use the ticked parcels in order, as before.

**Dividend record dates:** dividends have a **Record Date**. If you leave the ex-dividend date blank for a dividend with a record date from 9 March 2016, it's taken as the business day before, so the 45-day rule can still be checked (shown as estimated). Imports use the record date to work out the shares entitled to a dividend when there's no ex-date.

**Master file template:** **Import / Export → Download Master File Template** gives an example spreadsheet with every row type and a note on each, to start your own master file from. **Master file format** on the same page lists the row types and their columns.

**Bonus issues by number of shares:** an imported `Bonus` row can give the bonus shares received, as on your statement, instead of a ratio. The cost base is now spread over your original and bonus shares, which keep the original purchase dates. Before, imported rows like this made the bonus shares a separate parcel costing nothing, dated the issue date, so their capital gain was overstated, and bonus shares on pre-CGT shares lost their exemption. Portfolios with such parcels are corrected the first time you open them (backup saved, changes in Settings → Audit Log).

**Export as Inherited** now asks for the market value at the date of death of any shares the deceased bought before 20 September 1985, and puts it in the file as their cost. Before, you had to fill these in yourself.

**Imports** also accept `Merger`, `Holding`, `Transfer` and `Value` rows, a `Holding` column, and consolidations given as the change in the number of shares (for example `Con` −6), with an optional same-day return of capital in the Cost column. A dividend row with nothing but zeros now says it's empty. When master files are kept per holding, a corporate action listed in more than one of them is recorded once.

**Returns of capital on older shares:** for shares bought before 21 September 1999, a return of capital that's more than the cost base can now use **indexation**, as the ATO allows. Before, its capital gain always used the CGT discount. Once a return of capital makes a gain with one method, later sales of those shares use the same method, as the ATO requires. Choose the method for a parcel with the new **Method** button on a security's page. Affected portfolios are recalculated the first time you open them, with a backup saved first and changed figures listed in Settings → Audit Log.

**Shares held jointly:** keep them in their own portfolio and set **Settings → Your Share of These Holdings** (for example 50%). Enter everything in full, as on your statements; dividends, franking credits and capital gains on the tax pages and exports show your share.

**Imports** accept a few more spreadsheet layouts: dividend rows with only the DRP shares, a return of capital given as a total amount, and `ExDiv` and `Code2` column names.

## 1.1.0

**Older shares:** shares bought before 20 September 1985 are now shown as **pre-CGT** and their sales are exempt from CGT. Shares bought before 21 September 1999 can use the **indexation** method: sales before that date are indexed automatically, and for later sales you choose the CGT discount or indexation in Settings (or for each sale). Companies always use indexation. The CGT page shows the method used for each sale.

**Inherited shares:** record shares inherited from a deceased estate with **+ Inherited** on a security's page. You take over the deceased's cost base and purchase date, or for shares they bought before 20 September 1985, the market value on the date of death. To move a whole portfolio, open the deceased's portfolio, choose **Holdings → Holdings at Date → Export as Inherited** for the date of death, then add that file to the beneficiary's portfolio.

**Bonus issues** are now entered as a ratio (for example 1 for every 10 held). The cost base is spread over your original and bonus shares, and the bonus shares keep the original purchase date, as the ATO requires. Bonus issues you entered before are converted the first time you open the portfolio.

**Add to this portfolio:** **Import / Export → Add to this portfolio** adds the records in a file to the portfolio that's open, for example older purchases. Purchases dated before later splits and other corporate actions get those actions applied. You see which years' tax figures change before anything is saved.

**Your own spreadsheet layout:** imports also accept total cost instead of price, a single ratio for splits and consolidations, dividend totals (franked, unfranked, credit), and parcel labels. A sale can name the parcels it uses, e.g. `amp,drp22,MIN`.

**Editing purchases** now shows the quantity and price from your contract note, even after later splits or consolidations, and you can enter a total cost instead of a price. Tax-year lists go back to your earliest records.

**Share cancellations:** when a company cancels some of your shares and pays you for them, choose **Share Cancellation** under Corporate Actions and enter the number of shares cancelled and the total payment. It's recorded as a disposal (CGT event C2), as the ATO requires: the payment is your capital proceeds, each parcel gives up the same proportion of its shares, and the capital gain or loss appears in your CGT figures. Sales can also now use **Pro rata** parcel matching.

**Code and name changes:** if a company changed its code or name (for example WPL to WDS), record it under **Securities → Edit → Code & name changes**. Each year's tax reports use the code and name in effect on 30 June of that year.

**Export and import everything:** **Import / Export → Export Everything** saves your whole portfolio as one CSV file, including which parcels each sale used. Importing it into a new portfolio gives exactly the same figures, so you can keep your records in a spreadsheet and rebuild the portfolio from it at any time. Your TFN isn't included in the file.

**Events on the same day:** Dogbox now always applies events on the same day in one order: purchases first, then corporate actions, then sales. So shares you sell on the day of a return of capital or demerger still receive it, and bonus or rights shares issued that day don't. Portfolios with these cases are recalculated the first time you open them, with a backup saved first and changed figures listed in Settings → Audit Log.

**Fixed:** in the CGT schedule, a sale that used more than one parcel showed the whole sale's quantity and proceeds on each parcel's line. Each line now shows its own share. Your capital gain totals were not affected.

## 1.0.1

**Cost base fix:** a return of capital or demerger on the same day as a share split or consolidation could end up with the wrong cost base. The figure was right when you entered it but could change later, after you added, edited or deleted something else for that security. The return of capital or demerger is now always applied first, before any split or consolidation that day, matching the order share registries use. Enter its amount per share held *before* the split or consolidation.

Portfolios affected by this are recalculated the first time you open them. A backup copy is saved next to the file first (ending in `.bak`), and any changed figures are listed in Settings → Audit Log.

**Also fixed:** the **+ Action** button on a security's page now offers every corporate action type, including Return of Capital and Demerger.

## 1.0.0

Dogbox Investments now has version numbers and updates itself: when a new version is out, a banner offers to install it and restart. Your portfolio files are never touched by an update.

This release corrects several tax calculations. The first time you open each portfolio, it is recalculated under the corrected rules. A backup copy is saved next to it first (ending in `.bak`), and every changed figure is listed in Settings → Audit Log. Figures for years you've already lodged can change if they were affected, so it's worth checking those years.

**Capital gains**
- Capital losses (this year's, then carried-forward) are now subtracted before the 50% CGT discount, as the ATO requires. The discount applies only to the discount-eligible gain that's left.
- The "Taxable Gain" column for each sale now adds up to the Net capital gain at 18A.
- The CGT discount now starts the day after the first anniversary of purchase, not on the anniversary.
- Returns of capital and demergers on holdings you'd partly sold now give the right cost base, and any excess capital gain is reported.
- Sales can no longer use shares bought after the sale date, and selling more shares than you hold is rejected.
- Purchases entered after a split, return of capital or demerger, but dated before it, now have it applied.
- SMSFs in pension phase: all capital gains are exempt and capital losses are disregarded.

**Dividends**
- Partly franked dividends are now split between 11K (franked) and 11J (unfranked).
- The small shareholder exemption is applied: individuals with $5,000 or less in franking credits for the year don't need to meet the 45-day holding period rule.
- The 45-day rule now counts "at least 45 days", from the day after purchase.
- Franking credits are no longer estimated at 30% — enter the amount shown on your dividend statement.

**Other**
- Holdings at a past date are shown correctly across share splits, with the cost base of the shares held on that date.
- The sale estimator and the watch list "Divest" tab use the same CGT rules as your tax summary.
- Settings uses the current income tax rates.
- Broker CSV imports are applied in date order, so newest-first files import correctly.
