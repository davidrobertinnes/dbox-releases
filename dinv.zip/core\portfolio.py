# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Investments — Portfolio Business Logic
All CGT calculations, holdings aggregation, and transaction recording.
"""
import json
from datetime import date, timedelta
from .database import get_connection


def _held_12_months(acq: date, sal: date) -> bool:
    """ATO CGT discount rule: disposal must be on or after 12 calendar months after acquisition."""
    try:
        threshold = acq.replace(year=acq.year + 1)
    except ValueError:  # Feb 29 acquired in leap year — threshold is Feb 28 next year
        threshold = acq.replace(year=acq.year + 1, day=28)
    return sal >= threshold


def _sec_code(conn, security_id):
    r = conn.execute("SELECT code FROM securities WHERE id = ?", (security_id,)).fetchone()
    return r['code'] if r else str(security_id)


def _write_audit(conn, action, table_name, record_id, old_data, new_data=None):
    """Append one audit entry. Caller is responsible for the enclosing commit."""
    conn.execute(
        """INSERT INTO audit_log (action, table_name, record_id, old_data, new_data)
           VALUES (?, ?, ?, ?, ?)""",
        (action, table_name, record_id,
         json.dumps(old_data, default=str),
         json.dumps(new_data, default=str) if new_data is not None else None)
    )


# ── Securities ─────────────────────────────────────────────────────────────────

def get_securities(db_path, active_only=True):
    conn = get_connection(db_path)
    try:
        q = "SELECT * FROM securities"
        if active_only:
            q += " WHERE is_active = 1"
        q += " ORDER BY code"
        return [dict(r) for r in conn.execute(q).fetchall()]
    finally:
        conn.close()


def add_security(db_path, code, name, exchange='ASX', security_type='share',
                 currency='AUD', notes=''):
    conn = get_connection(db_path)
    try:
        c = conn.execute(
            """INSERT INTO securities (code, name, exchange, security_type, currency, notes)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (code.upper(), name, exchange, security_type, currency, notes)
        )
        conn.commit()
        return c.lastrowid
    finally:
        conn.close()


def get_security_by_code(db_path, code):
    conn = get_connection(db_path)
    try:
        r = conn.execute("SELECT * FROM securities WHERE code = ?", (code.upper(),)).fetchone()
        return dict(r) if r else None
    finally:
        conn.close()


# ── FY lock enforcement ────────────────────────────────────────────────────────

def _locked_fy(conn):
    row = conn.execute("SELECT value FROM settings WHERE key='locked_fy'").fetchone()
    try:
        return int(row['value']) if row and row['value'] else 0
    except (TypeError, ValueError):
        return 0


def _check_date_not_locked(conn, date_str, label='record'):
    if not date_str:
        return
    locked = _locked_fy(conn)
    if not locked:
        return
    d = date.fromisoformat(date_str)
    fy = d.year + 1 if d.month >= 7 else d.year
    if fy <= locked:
        raise ValueError(f"FY{fy} is locked — {label} cannot be modified after lodgement")


def _check_parcel_not_locked(conn, parcel_id):
    locked = _locked_fy(conn)
    if not locked:
        return
    parcel = conn.execute("SELECT acquisition_date FROM parcels WHERE id = ?", (parcel_id,)).fetchone()
    if parcel:
        d = date.fromisoformat(parcel['acquisition_date'])
        fy = d.year + 1 if d.month >= 7 else d.year
        if fy <= locked:
            raise ValueError(f"FY{fy} is locked — this purchase cannot be modified after lodgement")
    for row in conn.execute("""
        SELECT sa.sale_date FROM sale_parcels sp
        JOIN sales sa ON sa.id = sp.sale_id
        WHERE sp.parcel_id = ?
    """, (parcel_id,)).fetchall():
        d = date.fromisoformat(row['sale_date'])
        fy = d.year + 1 if d.month >= 7 else d.year
        if fy <= locked:
            raise ValueError(
                f"FY{fy} is locked — this parcel has a sale in a locked year "
                "and cannot be modified after lodgement"
            )


# ── Parcels (purchases) ────────────────────────────────────────────────────────

def add_parcel(db_path, security_id, acquisition_date, quantity, price_per_unit,
               brokerage=0.0, other_costs=0.0, notes=''):
    cost_base = quantity * price_per_unit + brokerage + other_costs
    conn = get_connection(db_path)
    try:
        _check_date_not_locked(conn, acquisition_date, 'purchase')
        c = conn.execute(
            """INSERT INTO parcels
               (security_id, acquisition_date, quantity, price_per_unit,
                brokerage, other_costs, cost_base, quantity_remaining, notes)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (security_id, acquisition_date, quantity, price_per_unit,
             brokerage, other_costs, cost_base, quantity, notes)
        )
        conn.commit()
        return c.lastrowid
    finally:
        conn.close()


def get_parcels(db_path, security_id=None, open_only=False):
    conn = get_connection(db_path)
    try:
        q = """SELECT p.*, s.code, s.name, s.exchange
               FROM parcels p
               JOIN securities s ON s.id = p.security_id"""
        params = []
        conditions = []
        if security_id:
            conditions.append("p.security_id = ?")
            params.append(security_id)
        if open_only:
            conditions.append("p.quantity_remaining > 0")
        if conditions:
            q += " WHERE " + " AND ".join(conditions)
        q += " ORDER BY p.acquisition_date, p.id"
        return [dict(r) for r in conn.execute(q, params).fetchall()]
    finally:
        conn.close()


# ── Holdings (current open positions) ──────────────────────────────────────────

def get_holdings(db_path):
    conn = get_connection(db_path)
    try:
        rows = conn.execute("""
            SELECT
                s.id         AS security_id,
                s.code,
                s.name,
                s.exchange,
                s.security_type,
                s.currency,
                SUM(p.quantity_remaining)        AS total_quantity,
                SUM(p.cost_base * (p.quantity_remaining / p.quantity)) AS total_cost_base,
                MIN(p.acquisition_date)          AS earliest_acquisition,
                COUNT(p.id)                      AS parcel_count
            FROM parcels p
            JOIN securities s ON s.id = p.security_id
            WHERE p.quantity_remaining > 0
            GROUP BY s.id
            ORDER BY s.code
        """).fetchall()
        holdings = []
        for r in rows:
            h = dict(r)
            h['avg_cost'] = (h['total_cost_base'] / h['total_quantity']
                             if h['total_quantity'] else 0)
            holdings.append(h)
        return holdings
    finally:
        conn.close()


# ── Sales and CGT ──────────────────────────────────────────────────────────────

def _cgt_discount_factor(conn):
    """Return the CGT discount factor based on entity_type setting.
    Individual: 0.5 (50% discount), SMSF accumulation: 1/3, SMSF pension: 1.0, Company: 0."""
    row = conn.execute("SELECT value FROM settings WHERE key='entity_type'").fetchone()
    entity = row['value'] if row else 'individual'
    return {'individual': 0.5, 'smsf_accumulation': 1/3,
            'smsf_pension': 1.0, 'company': 0.0}.get(entity, 0.5)


def _parcels_for_sale(conn, security_id, cgt_method, parcel_ids=None):
    """Return open parcels ordered per the chosen CGT method."""
    rows = conn.execute(
        "SELECT * FROM parcels WHERE security_id = ? AND quantity_remaining > 0",
        (security_id,)
    ).fetchall()
    if cgt_method == 'specific' and parcel_ids:
        order = {pid: i for i, pid in enumerate(parcel_ids)}
        rows = [r for r in rows if r['id'] in order]
        rows.sort(key=lambda r: order[r['id']])
    elif cgt_method == 'mingain':
        rows.sort(key=lambda r: r['cost_base'] / r['quantity'], reverse=True)
    elif cgt_method == 'maxgain':
        rows.sort(key=lambda r: r['cost_base'] / r['quantity'])
    else:
        rows.sort(key=lambda r: (r['acquisition_date'], r['id']))
    return rows


def add_sale(db_path, security_id, sale_date, quantity, price_per_unit,
             brokerage=0.0, cgt_method='fifo', notes='', parcel_ids=None):
    """
    Record a disposal. Allocates quantity against open parcels using the
    specified method (fifo/mingain/maxgain/specific) and calculates gain/loss.
    Returns the sale_id.
    """
    net_proceeds = quantity * price_per_unit - brokerage
    conn = get_connection(db_path)
    try:
        _check_date_not_locked(conn, sale_date, 'sale')
        # Insert sale record
        sale_id = conn.execute(
            """INSERT INTO sales
               (security_id, sale_date, quantity, price_per_unit,
                brokerage, net_proceeds, cgt_method, notes)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (security_id, sale_date, quantity, price_per_unit,
             brokerage, net_proceeds, cgt_method, notes)
        ).lastrowid

        parcels = _parcels_for_sale(conn, security_id, cgt_method, parcel_ids)
        discount_factor = _cgt_discount_factor(conn)

        remaining_to_sell = quantity
        proceeds_per_unit = net_proceeds / quantity

        for parcel in parcels:
            if remaining_to_sell <= 0:
                break
            sell_qty = min(remaining_to_sell, parcel['quantity_remaining'])
            cost_base_per_unit = parcel['cost_base'] / parcel['quantity']
            cost_base_used = cost_base_per_unit * sell_qty
            proceeds_allocated = proceeds_per_unit * sell_qty
            gain_loss = proceeds_allocated - cost_base_used

            acq = date.fromisoformat(parcel['acquisition_date'])
            sal = date.fromisoformat(sale_date)
            discount_eligible = 1 if _held_12_months(acq, sal) else 0
            discounted_gain = gain_loss * (1 - discount_factor) if discount_eligible and gain_loss > 0 else gain_loss

            conn.execute(
                """INSERT INTO sale_parcels
                   (sale_id, parcel_id, quantity_sold, cost_base_used,
                    gain_loss, discount_eligible, discounted_gain)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (sale_id, parcel['id'], sell_qty, cost_base_used,
                 gain_loss, discount_eligible, discounted_gain)
            )
            conn.execute(
                "UPDATE parcels SET quantity_remaining = quantity_remaining - ? WHERE id = ?",
                (sell_qty, parcel['id'])
            )
            remaining_to_sell -= sell_qty

        conn.commit()
        return sale_id
    finally:
        conn.close()


def get_sales(db_path, security_id=None):
    conn = get_connection(db_path)
    try:
        q = """SELECT sa.*, s.code, s.name
               FROM sales sa
               JOIN securities s ON s.id = sa.security_id"""
        params = []
        if security_id:
            q += " WHERE sa.security_id = ?"
            params.append(security_id)
        q += " ORDER BY sa.sale_date DESC, sa.id DESC"
        return [dict(r) for r in conn.execute(q, params).fetchall()]
    finally:
        conn.close()


# ── Dividends ──────────────────────────────────────────────────────────────────

def _check_45_day_rule(conn, security_id, ex_date_str, required_days=45):
    """
    ATO franking credit holding period rule.
    Returns True (eligible), False (ineligible), or None (no ex-date — cannot determine).

    Rule: shares must be held 'at risk' for MORE than required_days within the
    qualification window [ex_date - required_days, ex_date + required_days].
    The acquisition day and disposal day are excluded from the count.
    A single parcel satisfying the threshold makes the dividend eligible.

    required_days=45 for ordinary shares (default), 90 for preference shares.
    Hedging/at-risk rules are not checked (assumed all shares are held at risk).
    """
    if not ex_date_str:
        return None
    ex           = date.fromisoformat(ex_date_str)
    window_start = ex - timedelta(days=required_days)
    window_end   = ex + timedelta(days=required_days)

    rows = conn.execute("""
        SELECT p.id, p.acquisition_date, p.quantity_remaining,
               MAX(s.sale_date) as last_sale_date
        FROM parcels p
        LEFT JOIN sale_parcels sp ON sp.parcel_id = p.id
        LEFT JOIN sales s ON s.id = sp.sale_id
        WHERE p.security_id = ?
          AND p.acquisition_date < ?
        GROUP BY p.id
    """, (security_id, window_end.isoformat())).fetchall()

    for row in rows:
        acq = date.fromisoformat(row['acquisition_date'])
        # Use last_sale_date as disposal only when the parcel is fully consumed
        if row['quantity_remaining'] == 0 and row['last_sale_date']:
            dispose = date.fromisoformat(row['last_sale_date'])
        else:
            dispose = None  # parcel still (at least partially) open
        # Skip parcels fully disposed before the qualification window
        if dispose and dispose <= window_start:
            continue
        held_from = max(acq + timedelta(days=1), window_start)
        held_to   = (dispose - timedelta(days=1)) if (dispose and dispose <= window_end) else window_end
        days = max(0, (held_to - held_from).days + 1)
        if days > required_days:
            return True
    return False


def add_dividend(db_path, security_id, payment_date, quantity_held,
                 amount_per_share, franking_pct=0.0, ex_date=None,
                 is_drp=0, drp_quantity=None, drp_price=None, notes='',
                 franking_credit=None):
    gross_amount = quantity_held * amount_per_share
    if franking_credit is None:
        # Fallback for import path — user-entered dollar amount is always preferred
        franking_credit = (gross_amount * franking_pct / 100) / 0.70 * 0.30 if franking_pct else 0
    net_amount = gross_amount  # cash received (franking credit is a tax offset, not cash)

    conn = get_connection(db_path)
    try:
        _check_date_not_locked(conn, payment_date, 'dividend')
        drp_parcel_id = None
        if is_drp and drp_quantity and drp_price:
            # DRP shares get a cost base equal to the cash dividend foregone
            drp_parcel_id = conn.execute(
                """INSERT INTO parcels
                   (security_id, acquisition_date, quantity, price_per_unit,
                    brokerage, other_costs, cost_base, quantity_remaining, notes)
                   VALUES (?, ?, ?, ?, 0, 0, ?, ?, ?)""",
                (security_id, payment_date, drp_quantity, drp_price,
                 drp_quantity * drp_price, drp_quantity, 'DRP')
            ).lastrowid

        div_id = conn.execute(
            """INSERT INTO dividends
               (security_id, payment_date, ex_date, quantity_held, amount_per_share,
                gross_amount, franking_pct, franking_credit, net_amount,
                is_drp, drp_quantity, drp_price, drp_parcel_id, notes)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (security_id, payment_date, ex_date, quantity_held, amount_per_share,
             gross_amount, franking_pct, franking_credit, net_amount,
             is_drp, drp_quantity, drp_price, drp_parcel_id, notes)
        ).lastrowid

        conn.commit()
        return div_id
    finally:
        conn.close()


def get_dividends(db_path, security_id=None):
    conn = get_connection(db_path)
    try:
        q = """SELECT d.*, s.code, s.name, s.security_type
               FROM dividends d
               JOIN securities s ON s.id = d.security_id"""
        params = []
        if security_id:
            q += " WHERE d.security_id = ?"
            params.append(security_id)
        q += " ORDER BY d.payment_date DESC, d.id DESC"
        rows = [dict(r) for r in conn.execute(q, params).fetchall()]
        for row in rows:
            req = 90 if row.get('security_type') == 'preference' else 45
            row['eligible_45day'] = _check_45_day_rule(conn, row['security_id'], row.get('ex_date'), req)
        return rows
    finally:
        conn.close()


# ── CGT Summary ────────────────────────────────────────────────────────────────

def get_cgt_summary(db_path, fy_year):
    """
    Returns CGT data for the Australian financial year ending 30 June fy_year.
    e.g. fy_year=2025 covers 1 Jul 2024 – 30 Jun 2025.
    """
    fy_start = f"{fy_year - 1}-07-01"
    fy_end   = f"{fy_year}-06-30"
    conn = get_connection(db_path)
    try:
        rows = conn.execute("""
            SELECT
                s.code, s.name,
                sa.sale_date,
                sa.quantity,
                sa.net_proceeds,
                sp.cost_base_used,
                sp.gain_loss,
                sp.discount_eligible,
                sp.discounted_gain,
                p.acquisition_date
            FROM sale_parcels sp
            JOIN sales sa   ON sa.id = sp.sale_id
            JOIN parcels p  ON p.id  = sp.parcel_id
            JOIN securities s ON s.id = sa.security_id
            WHERE sa.sale_date BETWEEN ? AND ?
            ORDER BY sa.sale_date, s.code
        """, (fy_start, fy_end)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_roc_cgt(db_path, fy_year):
    """
    Returns return-of-capital capital gains for the FY ending 30 June fy_year.
    Only rows where cost base hit zero (excess_cg > 0) are returned — these must
    be included in the CGT return. Discount eligibility is based on the parcel
    holding period at the ROC action date.
    """
    fy_start = f"{fy_year - 1}-07-01"
    fy_end   = f"{fy_year}-06-30"
    conn = get_connection(db_path)
    try:
        rows = conn.execute("""
            SELECT
                s.code, s.name,
                ca.action_date,
                ca.ratio_from      AS amount_per_unit,
                ca.description,
                p.acquisition_date,
                p.quantity_remaining,
                rp.cost_base_reduction,
                rp.excess_cg,
                CASE
                    WHEN ca.action_date >= date(p.acquisition_date, '+1 year')
                    THEN 1 ELSE 0
                END AS discount_eligible
            FROM roc_parcels rp
            JOIN corporate_actions ca ON ca.id = rp.corporate_action_id
            JOIN parcels p            ON p.id  = rp.parcel_id
            JOIN securities s         ON s.id  = ca.security_id
            WHERE rp.excess_cg > 0
              AND ca.action_date BETWEEN ? AND ?
            ORDER BY ca.action_date, s.code
        """, (fy_start, fy_end)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ── CGT carry-forward ─────────────────────────────────────────────────────────

def _date_to_fy(date_str):
    """Return the FY year-end for a date string. '2024-08-01' → 2025, '2025-06-30' → 2025."""
    d = date.fromisoformat(date_str)
    return d.year + 1 if d.month >= 7 else d.year


def compute_cgt_carryforward(db_path, fy_year):
    """
    Compute the CGT carry-forward loss balance available at the start of fy_year.

    Opening balance = cgt_carryforward_loss setting (losses predating app records).
    Iterates every FY with disposal data from the earliest through fy_year-1,
    applying losses (balance grows) and absorbing gains (balance shrinks)
    in chronological order.

    Returns dict: carry_forward, opening_balance, first_fy, last_fy_processed.
    """
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT value FROM settings WHERE key='cgt_carryforward_loss'").fetchone()
        opening = float(row['value']) if row and row['value'] else 0.0

        discount_factor = _cgt_discount_factor(conn)
        retain = 1.0 - discount_factor  # fraction of gain remaining taxable after discount

        earliest_sale = conn.execute("SELECT MIN(sale_date) FROM sales").fetchone()[0]
        earliest_roc  = conn.execute("""
            SELECT MIN(ca.action_date) FROM roc_parcels rp
            JOIN corporate_actions ca ON ca.id = rp.corporate_action_id
            WHERE rp.excess_cg > 0
        """).fetchone()[0]

        candidates = [d for d in (earliest_sale, earliest_roc) if d]
        if not candidates:
            return {'carry_forward': round(opening, 2), 'opening_balance': round(opening, 2),
                    'first_fy': None, 'last_fy_processed': None}

        first_fy = min(_date_to_fy(d) for d in candidates)
        balance  = opening

        for yr in range(first_fy, fy_year):
            fy_start = f"{yr - 1}-07-01"
            fy_end   = f"{yr}-06-30"

            # Net from sales — use stored discounted_gain (calculated at sale time)
            sales_net = conn.execute("""
                SELECT COALESCE(SUM(
                    CASE WHEN sp.discounted_gain IS NOT NULL THEN sp.discounted_gain
                         ELSE sp.gain_loss END
                ), 0)
                FROM sale_parcels sp
                JOIN sales sa ON sa.id = sp.sale_id
                WHERE sa.sale_date BETWEEN ? AND ?
            """, (fy_start, fy_end)).fetchone()[0] or 0.0

            # Net from ROC gains — discount-eligible parcels get the discount applied
            roc_net = conn.execute("""
                SELECT COALESCE(SUM(
                    CASE WHEN ca.action_date >= date(p.acquisition_date, '+1 year')
                         THEN rp.excess_cg * ?
                         ELSE rp.excess_cg END
                ), 0)
                FROM roc_parcels rp
                JOIN corporate_actions ca ON ca.id = rp.corporate_action_id
                JOIN parcels p            ON p.id  = rp.parcel_id
                WHERE rp.excess_cg > 0
                  AND ca.action_date BETWEEN ? AND ?
            """, (retain, fy_start, fy_end)).fetchone()[0] or 0.0

            net = sales_net + roc_net
            if net > 0:
                balance = max(0.0, balance - net)
            else:
                balance += abs(net)

        return {
            'carry_forward':     round(balance, 2),
            'opening_balance':   round(opening, 2),
            'first_fy':          first_fy,
            'last_fy_processed': fy_year - 1,
        }
    finally:
        conn.close()


# ── Holdings at date ──────────────────────────────────────────────────────────

def get_holdings_at_date(db_path, snapshot_date):
    """
    Return per-parcel holdings as at snapshot_date.

    qty_at_date        = current quantity_remaining + sales made AFTER snapshot_date (unwound)
    cost_base_at_date  = current cost_base + ROC reductions applied AFTER snapshot_date (restored)

    Only parcels acquired on or before snapshot_date with qty_at_date > 0 are returned.
    """
    conn = get_connection(db_path)
    try:
        rows = conn.execute("""
            WITH snapshot AS (
                SELECT
                    s.id            AS security_id,
                    s.code,
                    s.name,
                    s.exchange,
                    s.security_type,
                    p.id            AS parcel_id,
                    p.acquisition_date,
                    p.quantity      AS original_quantity,
                    p.quantity_remaining + COALESCE(sa_after.qty, 0.0) AS qty_at_date,
                    p.cost_base
                        + COALESCE(roc_after.cb, 0.0)
                        + COALESCE(dem_after.cb, 0.0) AS cost_base_at_date
                FROM parcels p
                JOIN securities s ON s.id = p.security_id
                LEFT JOIN (
                    SELECT sp.parcel_id, SUM(sp.quantity_sold) AS qty
                    FROM sale_parcels sp
                    JOIN sales sa ON sa.id = sp.sale_id
                    WHERE sa.sale_date > ?
                    GROUP BY sp.parcel_id
                ) sa_after ON sa_after.parcel_id = p.id
                LEFT JOIN (
                    SELECT rp.parcel_id, SUM(rp.cost_base_reduction) AS cb
                    FROM roc_parcels rp
                    JOIN corporate_actions ca ON ca.id = rp.corporate_action_id
                    WHERE ca.action_date > ?
                    GROUP BY rp.parcel_id
                ) roc_after ON roc_after.parcel_id = p.id
                LEFT JOIN (
                    -- Restore cost base transferred out of original parcels by demergers
                    -- that happened after the snapshot date
                    SELECT dp.original_parcel_id AS parcel_id, SUM(dp.cost_base_transferred) AS cb
                    FROM demerger_parcels dp
                    JOIN corporate_actions ca ON ca.id = dp.corporate_action_id
                    WHERE ca.action_date > ?
                    GROUP BY dp.original_parcel_id
                ) dem_after ON dem_after.parcel_id = p.id
                WHERE p.acquisition_date <= ?
                  AND NOT EXISTS (
                    -- Exclude parcels created by demergers that hadn't happened yet
                    SELECT 1 FROM demerger_parcels dp2
                    JOIN corporate_actions ca2 ON ca2.id = dp2.corporate_action_id
                    WHERE dp2.new_parcel_id = p.id AND ca2.action_date > ?
                  )
            )
            SELECT * FROM snapshot WHERE qty_at_date > 0.0001
            ORDER BY code, acquisition_date, parcel_id
        """, (snapshot_date, snapshot_date, snapshot_date,
              snapshot_date, snapshot_date)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ── Cost base reconciliation ──────────────────────────────────────────────────

def get_cost_base_reconciliation(db_path, fy_year):
    """
    Per-security cost base movement for the Australian FY ending 30 June fy_year.

    Returns a list of dicts, one per security that had any holdings or activity,
    each containing opening_cb, categorised additions and reductions, computed
    closing CB, actual closing CB (from snapshot), and a reconciles flag.
    """
    fy_start  = f"{fy_year - 1}-07-01"
    fy_end    = f"{fy_year}-06-30"
    open_snap = f"{fy_year - 1}-06-30"   # proportional CB at close of prior FY

    conn = get_connection(db_path)
    try:
        def _snap_cb(snap_date):
            """Proportional cost base per security at snap_date."""
            rows = conn.execute("""
                WITH snap AS (
                    SELECT
                        p.security_id,
                        (p.cost_base
                            + COALESCE(roc_after.cb, 0.0)
                            + COALESCE(dem_after.cb, 0.0)
                        ) * (p.quantity_remaining + COALESCE(sa_after.qty, 0.0))
                          / p.quantity  AS prop_cb,
                        p.quantity_remaining + COALESCE(sa_after.qty, 0.0) AS qty
                    FROM parcels p
                    LEFT JOIN (
                        SELECT sp.parcel_id, SUM(sp.quantity_sold) AS qty
                        FROM sale_parcels sp
                        JOIN sales sa ON sa.id = sp.sale_id
                        WHERE sa.sale_date > ?
                        GROUP BY sp.parcel_id
                    ) sa_after ON sa_after.parcel_id = p.id
                    LEFT JOIN (
                        SELECT rp.parcel_id, SUM(rp.cost_base_reduction) AS cb
                        FROM roc_parcels rp
                        JOIN corporate_actions ca ON ca.id = rp.corporate_action_id
                        WHERE ca.action_date > ?
                        GROUP BY rp.parcel_id
                    ) roc_after ON roc_after.parcel_id = p.id
                    LEFT JOIN (
                        SELECT dp.original_parcel_id AS parcel_id, SUM(dp.cost_base_transferred) AS cb
                        FROM demerger_parcels dp
                        JOIN corporate_actions ca ON ca.id = dp.corporate_action_id
                        WHERE ca.action_date > ?
                        GROUP BY dp.original_parcel_id
                    ) dem_after ON dem_after.parcel_id = p.id
                    WHERE p.acquisition_date <= ?
                      AND NOT EXISTS (
                        SELECT 1 FROM demerger_parcels dp2
                        JOIN corporate_actions ca2 ON ca2.id = dp2.corporate_action_id
                        WHERE dp2.new_parcel_id = p.id AND ca2.action_date > ?
                      )
                )
                SELECT security_id, SUM(prop_cb) AS total_cb
                FROM snap WHERE qty > 0.0001
                GROUP BY security_id
            """, (snap_date,) * 5).fetchall()
            return {r['security_id']: r['total_cb'] for r in rows}

        opening_cb = _snap_cb(open_snap)
        closing_cb = _snap_cb(fy_end)

        # ── Additions ─────────────────────────────────────────────────────────

        # IDs of parcels that are DRP / rights / bonus / demerger receipts in FY
        # (so they are excluded from the "purchases" bucket)
        drp_ids = {r[0] for r in conn.execute("""
            SELECT drp_parcel_id FROM dividends
            WHERE drp_parcel_id IS NOT NULL AND payment_date BETWEEN ? AND ?
        """, (fy_start, fy_end)).fetchall()}

        ca_ids = {r[0] for r in conn.execute("""
            SELECT parcel_id FROM corporate_actions
            WHERE parcel_id IS NOT NULL
              AND action_type IN ('rights_issue','bonus')
              AND action_date BETWEEN ? AND ?
        """, (fy_start, fy_end)).fetchall()}

        dem_new_ids = {r[0] for r in conn.execute("""
            SELECT dp.new_parcel_id FROM demerger_parcels dp
            JOIN corporate_actions ca ON ca.id = dp.corporate_action_id
            WHERE ca.action_date BETWEEN ? AND ?
        """, (fy_start, fy_end)).fetchall()}

        excluded_ids = drp_ids | ca_ids | dem_new_ids

        purchases = {}
        for r in conn.execute("""
            SELECT id, security_id, cost_base FROM parcels
            WHERE acquisition_date BETWEEN ? AND ?
        """, (fy_start, fy_end)).fetchall():
            if r['id'] not in excluded_ids:
                purchases[r['security_id']] = purchases.get(r['security_id'], 0.0) + r['cost_base']

        drp = {r['security_id']: r['total'] for r in conn.execute("""
            SELECT p.security_id, SUM(p.cost_base) AS total
            FROM parcels p JOIN dividends d ON d.drp_parcel_id = p.id
            WHERE d.payment_date BETWEEN ? AND ?
            GROUP BY p.security_id
        """, (fy_start, fy_end)).fetchall()}

        rights = {r['security_id']: r['total'] for r in conn.execute("""
            SELECT p.security_id, SUM(p.cost_base) AS total
            FROM parcels p JOIN corporate_actions ca ON ca.parcel_id = p.id
            WHERE ca.action_type = 'rights_issue' AND ca.action_date BETWEEN ? AND ?
            GROUP BY p.security_id
        """, (fy_start, fy_end)).fetchall()}

        bonus = {r['security_id']: r['total'] for r in conn.execute("""
            SELECT p.security_id, SUM(p.cost_base) AS total
            FROM parcels p JOIN corporate_actions ca ON ca.parcel_id = p.id
            WHERE ca.action_type = 'bonus' AND ca.action_date BETWEEN ? AND ?
            GROUP BY p.security_id
        """, (fy_start, fy_end)).fetchall()}

        dem_receipt = {r['security_id']: r['total'] for r in conn.execute("""
            SELECT p.security_id, SUM(dp.cost_base_transferred) AS total
            FROM demerger_parcels dp
            JOIN parcels p ON p.id = dp.new_parcel_id
            JOIN corporate_actions ca ON ca.id = dp.corporate_action_id
            WHERE ca.action_date BETWEEN ? AND ?
            GROUP BY p.security_id
        """, (fy_start, fy_end)).fetchall()}

        # ── Reductions ────────────────────────────────────────────────────────

        disposals = {r['security_id']: r['total'] for r in conn.execute("""
            SELECT sa.security_id, SUM(sp.cost_base_used) AS total
            FROM sale_parcels sp JOIN sales sa ON sa.id = sp.sale_id
            WHERE sa.sale_date BETWEEN ? AND ?
            GROUP BY sa.security_id
        """, (fy_start, fy_end)).fetchall()}

        roc_reductions = {r['security_id']: r['total'] for r in conn.execute("""
            SELECT ca.security_id, SUM(rp.cost_base_reduction) AS total
            FROM roc_parcels rp JOIN corporate_actions ca ON ca.id = rp.corporate_action_id
            WHERE ca.action_date BETWEEN ? AND ?
            GROUP BY ca.security_id
        """, (fy_start, fy_end)).fetchall()}

        demerger_out = {r['security_id']: r['total'] for r in conn.execute("""
            SELECT ca.security_id, SUM(dp.cost_base_transferred) AS total
            FROM demerger_parcels dp JOIN corporate_actions ca ON ca.id = dp.corporate_action_id
            WHERE ca.action_date BETWEEN ? AND ?
            GROUP BY ca.security_id
        """, (fy_start, fy_end)).fetchall()}

        # ── Assemble ──────────────────────────────────────────────────────────

        all_sids = (set(opening_cb) | set(closing_cb) |
                    set(purchases) | set(drp) | set(rights) | set(bonus) |
                    set(dem_receipt) | set(disposals) | set(roc_reductions) |
                    set(demerger_out))
        if not all_sids:
            return []

        sec_info = {r['id']: dict(r) for r in conn.execute(
            "SELECT id, code, name FROM securities WHERE id IN ({})".format(
                ','.join('?' * len(all_sids))),
            list(all_sids)
        ).fetchall()}

        result = []
        for sid in sorted(all_sids, key=lambda x: sec_info.get(x, {}).get('code', 'ZZZ')):
            open_cb  = opening_cb.get(sid, 0.0)
            close_act = closing_cb.get(sid, 0.0)

            adds = {
                'purchases':        round(purchases.get(sid, 0.0), 2),
                'drp':              round(drp.get(sid, 0.0), 2),
                'rights_issues':    round(rights.get(sid, 0.0), 2),
                'bonus_issues':     round(bonus.get(sid, 0.0), 2),
                'demerger_receipt': round(dem_receipt.get(sid, 0.0), 2),
            }
            adds['total'] = round(sum(adds.values()), 2)

            reds = {
                'disposals':         round(disposals.get(sid, 0.0), 2),
                'return_of_capital': round(roc_reductions.get(sid, 0.0), 2),
                'demerger_out':      round(demerger_out.get(sid, 0.0), 2),
            }
            reds['total'] = round(sum(reds.values()), 2)

            computed = round(open_cb + adds['total'] - reds['total'], 2)
            actual   = round(close_act, 2)

            result.append({
                'security_id':    sid,
                'code':           sec_info.get(sid, {}).get('code', '?'),
                'name':           sec_info.get(sid, {}).get('name', '?'),
                'opening_cb':     round(open_cb, 2),
                'additions':      adds,
                'reductions':     reds,
                'computed_close': computed,
                'actual_close':   actual,
                'reconciles':     abs(computed - actual) < 0.02,
            })
        return result
    finally:
        conn.close()


# ── Security edit ─────────────────────────────────────────────────────────────

def update_security(db_path, security_id, name, exchange, security_type,
                    currency, notes, is_active=1):
    if not name:
        raise ValueError("Name is required")
    conn = get_connection(db_path)
    try:
        conn.execute(
            """UPDATE securities SET name=?, exchange=?, security_type=?,
               currency=?, notes=?, is_active=? WHERE id=?""",
            (name, exchange, security_type, currency, notes, int(is_active), security_id)
        )
        conn.commit()
    finally:
        conn.close()


# ── Settings ───────────────────────────────────────────────────────────────────

def get_settings(db_path):
    conn = get_connection(db_path)
    try:
        return {r['key']: r['value']
                for r in conn.execute("SELECT key, value FROM settings").fetchall()}
    finally:
        conn.close()


def set_setting(db_path, key, value):
    conn = get_connection(db_path)
    try:
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
        conn.commit()
    finally:
        conn.close()


# ── Performance summary ────────────────────────────────────────────────────────

def get_performance(db_path):
    """Aggregate portfolio performance: invested, unrealised, realised, income."""
    conn = get_connection(db_path)
    try:
        total_invested = conn.execute(
            "SELECT COALESCE(SUM(cost_base), 0) FROM parcels"
        ).fetchone()[0]

        open_cost = conn.execute(
            "SELECT COALESCE(SUM(cost_base * quantity_remaining / quantity), 0) "
            "FROM parcels WHERE quantity_remaining > 0"
        ).fetchone()[0]

        market_value = conn.execute("""
            SELECT COALESCE(SUM(p.quantity_remaining * pr.price), 0)
            FROM parcels p
            JOIN prices pr ON pr.security_id = p.security_id
            WHERE p.quantity_remaining > 0
        """).fetchone()[0]

        priced_open_cost = conn.execute("""
            SELECT COALESCE(SUM(p.cost_base * p.quantity_remaining / p.quantity), 0)
            FROM parcels p
            JOIN prices pr ON pr.security_id = p.security_id
            WHERE p.quantity_remaining > 0
        """).fetchone()[0]

        realized = conn.execute(
            "SELECT COALESCE(SUM(gain_loss), 0) FROM sale_parcels"
        ).fetchone()[0]

        dividends = conn.execute(
            "SELECT COALESCE(SUM(net_amount), 0) FROM dividends"
        ).fetchone()[0]

        unrealized = (market_value - priced_open_cost) if market_value > 0 else None
        total_return = (unrealized or 0) + realized + dividends
        return_pct = (total_return / total_invested * 100) if total_invested > 0 else None

        return {
            'total_invested': total_invested,
            'market_value': market_value,
            'unrealized': unrealized,
            'realized': realized,
            'dividends': dividends,
            'total_return': total_return,
            'return_pct': return_pct,
        }
    finally:
        conn.close()


# ── Corporate actions ──────────────────────────────────────────────────────────

def get_corporate_actions(db_path, security_id=None):
    conn = get_connection(db_path)
    try:
        q = ("""SELECT ca.*, s.code, s.name,
                       s2.code AS new_security_code, s2.name AS new_security_name
                FROM corporate_actions ca
                JOIN securities s  ON s.id  = ca.security_id
                LEFT JOIN securities s2 ON s2.id = ca.new_security_id""")
        params = []
        if security_id:
            q += " WHERE ca.security_id = ?"
            params.append(security_id)
        q += " ORDER BY ca.action_date DESC, ca.id DESC"
        return [dict(r) for r in conn.execute(q, params).fetchall()]
    finally:
        conn.close()


def apply_corporate_action(db_path, security_id, action_date, action_type,
                           ratio_from, ratio_to=0, description='', notes='',
                           new_security_id=None):
    """
    Record a corporate action and apply it.
    - split/consolidation: adjust parcel quantities, cost base unchanged.
    - bonus: creates zero-cost-base parcel.
    - rights_issue: ratio_from=qty, ratio_to=price. Creates a new parcel.
    - return_of_capital: ratio_from=amount_per_unit. Reduces cost base on all open
      parcels. If cost base reaches zero the excess is recorded as a capital gain
      in roc_parcels and must be included in the CGT return for this FY.
    """
    conn = get_connection(db_path)
    try:
        _check_date_not_locked(conn, action_date, 'corporate action')

        if action_type == 'demerger':
            alloc_pct   = float(ratio_from)  # % of cost base kept by original (e.g. 85)
            share_ratio = float(ratio_to)    # new shares issued per original share held
            if not (0 < alloc_pct < 100):
                raise ValueError("Original cost base allocation must be between 0 and 100")
            if share_ratio <= 0:
                raise ValueError("Share ratio must be positive")
            if not new_security_id:
                raise ValueError("Demerged security must be specified")
            new_sec = conn.execute(
                "SELECT code FROM securities WHERE id = ?", (new_security_id,)
            ).fetchone()
            if not new_sec:
                raise ValueError("Demerged security not found")
            orig_sec = conn.execute(
                "SELECT code FROM securities WHERE id = ?", (security_id,)
            ).fetchone()
            parcels = conn.execute("""
                SELECT id, acquisition_date, quantity, quantity_remaining, cost_base
                FROM parcels
                WHERE security_id = ? AND quantity_remaining > 0
                  AND acquisition_date <= ?
                ORDER BY acquisition_date
            """, (security_id, action_date)).fetchall()
            if not parcels:
                raise ValueError("No open parcels found for this security at the action date")

            transfer_pct = (100.0 - alloc_pct) / 100.0
            action_id = conn.execute("""
                INSERT INTO corporate_actions
                    (security_id, action_date, action_type, description,
                     ratio_from, ratio_to, notes, new_security_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (security_id, action_date, action_type,
                  description or (f"Demerger — {alloc_pct:.1f}% retained, "
                                  f"{100 - alloc_pct:.1f}% to {new_sec['code']}"),
                  alloc_pct, share_ratio, notes, new_security_id)).lastrowid

            for p in parcels:
                # Cost base attributable to the shares still held
                proportional_cb = p['cost_base'] * p['quantity_remaining'] / p['quantity']
                cost_base_xfer  = proportional_cb * transfer_pct
                new_qty         = p['quantity_remaining'] * share_ratio
                new_price       = cost_base_xfer / new_qty if new_qty > 0 else 0.0

                # New parcel for the demerged entity.
                # Acquisition date = original parcel's date (ATO requirement: CGT discount
                # clock continues from the original acquisition, not the demerger date).
                new_parcel_id = conn.execute("""
                    INSERT INTO parcels
                        (security_id, acquisition_date, quantity, price_per_unit,
                         brokerage, other_costs, cost_base, quantity_remaining, notes)
                    VALUES (?, ?, ?, ?, 0, 0, ?, ?, ?)
                """, (new_security_id, p['acquisition_date'], new_qty, new_price,
                      cost_base_xfer, new_qty,
                      f'Demerger from {orig_sec["code"]}')).lastrowid

                conn.execute(
                    "UPDATE parcels SET cost_base = cost_base - ? WHERE id = ?",
                    (cost_base_xfer, p['id'])
                )
                conn.execute("""
                    INSERT INTO demerger_parcels
                        (corporate_action_id, original_parcel_id, new_parcel_id, cost_base_transferred)
                    VALUES (?, ?, ?, ?)
                """, (action_id, p['id'], new_parcel_id, cost_base_xfer))

            conn.commit()
            return action_id

        if action_type == 'return_of_capital':
            amount_per_unit = float(ratio_from)
            if amount_per_unit <= 0:
                raise ValueError("Amount per unit must be positive")
            parcels = conn.execute("""
                SELECT id, acquisition_date, quantity_remaining, cost_base
                FROM parcels
                WHERE security_id = ? AND quantity_remaining > 0
                  AND acquisition_date <= ?
                ORDER BY acquisition_date
            """, (security_id, action_date)).fetchall()
            if not parcels:
                raise ValueError("No open parcels found for this security at the action date")
            action_id = conn.execute("""
                INSERT INTO corporate_actions
                    (security_id, action_date, action_type, description, ratio_from, ratio_to, notes)
                VALUES (?, ?, ?, ?, ?, 0, ?)
            """, (security_id, action_date, action_type,
                  description or f"Return of Capital ${amount_per_unit:.4f}/unit",
                  amount_per_unit, notes)).lastrowid
            for p in parcels:
                total_roc      = p['quantity_remaining'] * amount_per_unit
                actual_reduc   = min(total_roc, p['cost_base'])
                excess_cg      = max(0.0, total_roc - p['cost_base'])
                new_cost_base  = p['cost_base'] - actual_reduc
                conn.execute("""
                    INSERT INTO roc_parcels
                        (corporate_action_id, parcel_id, cost_base_reduction, excess_cg)
                    VALUES (?, ?, ?, ?)
                """, (action_id, p['id'], actual_reduc, excess_cg))
                conn.execute("UPDATE parcels SET cost_base = ? WHERE id = ?",
                             (new_cost_base, p['id']))
            conn.commit()
            return action_id

        if action_type in ('rights_issue', 'bonus'):
            qty   = float(ratio_from)
            price = float(ratio_to) if action_type == 'rights_issue' else 0.0
            if qty <= 0:
                raise ValueError("Quantity must be positive")
            if action_type == 'rights_issue' and price <= 0:
                raise ValueError("Subscription price must be positive")
            cost_base = qty * price
            default_note = 'Rights Issue' if action_type == 'rights_issue' else 'Bonus Issue'
            parcel_id = conn.execute(
                """INSERT INTO parcels
                   (security_id, acquisition_date, quantity, price_per_unit,
                    brokerage, other_costs, cost_base, quantity_remaining, notes)
                   VALUES (?, ?, ?, ?, 0, 0, ?, ?, ?)""",
                (security_id, action_date, qty, price, cost_base, qty,
                 description or default_note)
            ).lastrowid
            action_id = conn.execute(
                """INSERT INTO corporate_actions
                   (security_id, action_date, action_type, description,
                    ratio_from, ratio_to, notes, parcel_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (security_id, action_date, action_type, description,
                 qty, price, notes, parcel_id)
            ).lastrowid
            conn.commit()
            return action_id

        rf, rt = float(ratio_from), float(ratio_to)
        if rf <= 0 or rt <= 0:
            raise ValueError("Ratios must be positive numbers")
        if abs(rf - rt) < 0.0001:
            raise ValueError("ratio_from and ratio_to must be different")

        action_id = conn.execute(
            """INSERT INTO corporate_actions
               (security_id, action_date, action_type, description, ratio_from, ratio_to, notes)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (security_id, action_date, action_type, description, rf, rt, notes)
        ).lastrowid

        # Multiply quantity by rt/rf; divide price by rt/rf (inverse) to keep cost_base intact
        conn.execute(
            """UPDATE parcels SET
                   quantity           = quantity           * ? / ?,
                   quantity_remaining = quantity_remaining * ? / ?,
                   price_per_unit     = price_per_unit     * ? / ?
               WHERE security_id = ? AND acquisition_date <= ?""",
            (rt, rf,
             rt, rf,
             rf, rt,
             security_id, action_date)
        )
        conn.commit()
        return action_id
    finally:
        conn.close()


def delete_corporate_action(db_path, action_id):
    """Reverse the parcel adjustments and delete the action record."""
    conn = get_connection(db_path)
    try:
        action = conn.execute(
            "SELECT * FROM corporate_actions WHERE id = ?", (action_id,)
        ).fetchone()
        if not action:
            raise ValueError("Corporate action not found")
        _check_date_not_locked(conn, action['action_date'], 'corporate action')
        old = dict(action)
        old['code'] = _sec_code(conn, old['security_id'])
        _write_audit(conn, 'delete', 'corporate_actions', action_id, old)

        if action['action_type'] == 'demerger':
            dem_rows = conn.execute(
                """SELECT original_parcel_id, new_parcel_id, cost_base_transferred
                   FROM demerger_parcels WHERE corporate_action_id = ?""",
                (action_id,)
            ).fetchall()
            # Validate before mutating
            for row in dem_rows:
                sold = conn.execute(
                    "SELECT COUNT(*) FROM sale_parcels WHERE parcel_id = ?",
                    (row['new_parcel_id'],)
                ).fetchone()[0]
                if sold:
                    raise ValueError(
                        "Cannot delete demerger — a demerged parcel has been sold. "
                        "Delete the sale first.")
            new_parcel_ids = [row['new_parcel_id'] for row in dem_rows]
            for row in dem_rows:
                conn.execute(
                    "UPDATE parcels SET cost_base = cost_base + ? WHERE id = ?",
                    (row['cost_base_transferred'], row['original_parcel_id'])
                )
            conn.execute("DELETE FROM demerger_parcels WHERE corporate_action_id = ?", (action_id,))
            for pid in new_parcel_ids:
                conn.execute("DELETE FROM parcels WHERE id = ?", (pid,))
            conn.execute("DELETE FROM corporate_actions WHERE id = ?", (action_id,))
            conn.commit()
            return

        if action['action_type'] == 'return_of_capital':
            roc_rows = conn.execute(
                "SELECT parcel_id, cost_base_reduction FROM roc_parcels WHERE corporate_action_id = ?",
                (action_id,)
            ).fetchall()
            for row in roc_rows:
                conn.execute(
                    "UPDATE parcels SET cost_base = cost_base + ? WHERE id = ?",
                    (row['cost_base_reduction'], row['parcel_id'])
                )
            conn.execute("DELETE FROM roc_parcels WHERE corporate_action_id = ?", (action_id,))
            conn.execute("DELETE FROM corporate_actions WHERE id = ?", (action_id,))
            conn.commit()
            return

        if action['action_type'] in ('rights_issue', 'bonus'):
            parcel_id = action['parcel_id']
            if parcel_id:
                sold = conn.execute(
                    "SELECT COUNT(*) FROM sale_parcels WHERE parcel_id = ?", (parcel_id,)
                ).fetchone()[0]
                if sold:
                    raise ValueError(
                        "Cannot delete rights issue — parcel has been sold. Delete the sale first.")
            # Delete action first (it holds the FK reference to the parcel)
            conn.execute("DELETE FROM corporate_actions WHERE id = ?", (action_id,))
            if parcel_id:
                conn.execute("DELETE FROM parcels WHERE id = ?", (parcel_id,))
            conn.commit()
            return

        rf, rt = action['ratio_from'], action['ratio_to']
        conn.execute(
            """UPDATE parcels SET
                   quantity           = quantity           * ? / ?,
                   quantity_remaining = quantity_remaining * ? / ?,
                   price_per_unit     = price_per_unit     * ? / ?
               WHERE security_id = ? AND acquisition_date <= ?""",
            (rf, rt,
             rf, rt,
             rt, rf,
             action['security_id'], action['action_date'])
        )
        conn.execute("DELETE FROM corporate_actions WHERE id = ?", (action_id,))
        conn.commit()
    finally:
        conn.close()


# ── Parcel edit / delete ───────────────────────────────────────────────────────

def get_parcel(db_path, parcel_id):
    conn = get_connection(db_path)
    try:
        r = conn.execute(
            "SELECT p.*, s.code, s.name FROM parcels p "
            "JOIN securities s ON s.id = p.security_id WHERE p.id = ?",
            (parcel_id,)
        ).fetchone()
        return dict(r) if r else None
    finally:
        conn.close()


def update_parcel(db_path, parcel_id, acquisition_date, quantity, price_per_unit,
                  brokerage=0.0, other_costs=0.0, notes=''):
    conn = get_connection(db_path)
    try:
        existing = conn.execute("SELECT * FROM parcels WHERE id = ?", (parcel_id,)).fetchone()
        if not existing:
            raise ValueError("Parcel not found")
        _check_parcel_not_locked(conn, parcel_id)
        new_qty = float(quantity)
        if abs(new_qty - existing['quantity']) > 0.0001:
            sold = conn.execute(
                "SELECT COUNT(*) FROM sale_parcels WHERE parcel_id = ?", (parcel_id,)
            ).fetchone()[0]
            if sold:
                raise ValueError("Cannot change quantity of a parcel that has been (partially) sold")
        sold_qty = existing['quantity'] - existing['quantity_remaining']
        new_remaining = new_qty - sold_qty
        if new_remaining < -0.0001:
            raise ValueError("New quantity is less than quantity already sold")
        cost_base = new_qty * float(price_per_unit) + float(brokerage) + float(other_costs)

        old = dict(existing)
        old['code'] = _sec_code(conn, old['security_id'])
        _write_audit(conn, 'edit', 'parcels', parcel_id, old)

        conn.execute(
            """UPDATE parcels SET
                   acquisition_date=?, quantity=?, price_per_unit=?,
                   brokerage=?, other_costs=?, cost_base=?, quantity_remaining=?, notes=?
               WHERE id=?""",
            (acquisition_date, new_qty, float(price_per_unit),
             float(brokerage), float(other_costs), cost_base, new_remaining, notes, parcel_id))

        # Recompute sale_parcels — cost_base or acquisition_date may have changed
        discount_factor = _cgt_discount_factor(conn)
        sp_rows = conn.execute("""
            SELECT sp.id, sp.quantity_sold,
                   sa.net_proceeds, sa.quantity AS sale_qty, sa.sale_date
            FROM sale_parcels sp
            JOIN sales sa ON sa.id = sp.sale_id
            WHERE sp.parcel_id = ?
        """, (parcel_id,)).fetchall()
        for sp in sp_rows:
            cb_per_unit    = cost_base / new_qty
            cost_base_used = cb_per_unit * sp['quantity_sold']
            proceeds_alloc = (sp['net_proceeds'] / sp['sale_qty']) * sp['quantity_sold']
            gain_loss      = proceeds_alloc - cost_base_used
            disc_elig      = 1 if _held_12_months(date.fromisoformat(acquisition_date),
                                                   date.fromisoformat(sp['sale_date'])) else 0
            discounted_gain = gain_loss * (1 - discount_factor) if disc_elig and gain_loss > 0 else gain_loss
            conn.execute("""
                UPDATE sale_parcels
                SET cost_base_used=?, gain_loss=?, discount_eligible=?, discounted_gain=?
                WHERE id=?
            """, (cost_base_used, gain_loss, disc_elig, discounted_gain, sp['id']))

        conn.commit()
    finally:
        conn.close()


def delete_parcel(db_path, parcel_id):
    conn = get_connection(db_path)
    try:
        _check_parcel_not_locked(conn, parcel_id)
        sold = conn.execute(
            "SELECT COUNT(*) FROM sale_parcels WHERE parcel_id = ?", (parcel_id,)
        ).fetchone()[0]
        if sold:
            raise ValueError("Cannot delete a parcel that has been sold. Delete the sale first.")
        existing = conn.execute("SELECT * FROM parcels WHERE id = ?", (parcel_id,)).fetchone()
        if existing:
            old = dict(existing)
            old['code'] = _sec_code(conn, old['security_id'])
            _write_audit(conn, 'delete', 'parcels', parcel_id, old)
        conn.execute("DELETE FROM parcels WHERE id = ?", (parcel_id,))
        conn.commit()
    finally:
        conn.close()


# ── Sale edit / delete ─────────────────────────────────────────────────────────

def get_sale(db_path, sale_id):
    conn = get_connection(db_path)
    try:
        r = conn.execute(
            "SELECT sa.*, s.code, s.name FROM sales sa "
            "JOIN securities s ON s.id = sa.security_id WHERE sa.id = ?",
            (sale_id,)
        ).fetchone()
        return dict(r) if r else None
    finally:
        conn.close()


def _reverse_sale_allocations(conn, sale_id):
    """Restore parcel quantities consumed by a sale. Caller commits."""
    for row in conn.execute(
        "SELECT parcel_id, quantity_sold FROM sale_parcels WHERE sale_id = ?", (sale_id,)
    ).fetchall():
        conn.execute(
            "UPDATE parcels SET quantity_remaining = quantity_remaining + ? WHERE id = ?",
            (row['quantity_sold'], row['parcel_id'])
        )
    conn.execute("DELETE FROM sale_parcels WHERE sale_id = ?", (sale_id,))


def delete_sale(db_path, sale_id):
    conn = get_connection(db_path)
    try:
        sale = conn.execute("SELECT * FROM sales WHERE id = ?", (sale_id,)).fetchone()
        if sale:
            _check_date_not_locked(conn, sale['sale_date'], 'sale')
            old = dict(sale)
            old['code'] = _sec_code(conn, old['security_id'])
            _write_audit(conn, 'delete', 'sales', sale_id, old)
        _reverse_sale_allocations(conn, sale_id)
        conn.execute("DELETE FROM sales WHERE id = ?", (sale_id,))
        conn.commit()
    finally:
        conn.close()


def update_sale(db_path, sale_id, sale_date, quantity, price_per_unit,
                brokerage=0.0, cgt_method='fifo', notes='', parcel_ids=None):
    conn = get_connection(db_path)
    try:
        existing = conn.execute("SELECT * FROM sales WHERE id = ?", (sale_id,)).fetchone()
        if not existing:
            raise ValueError("Sale not found")
        security_id = existing['security_id']
        _check_date_not_locked(conn, existing['sale_date'], 'sale')
        _check_date_not_locked(conn, sale_date, 'sale')
        old = dict(existing)
        old['code'] = _sec_code(conn, security_id)
        _write_audit(conn, 'edit', 'sales', sale_id, old)

        _reverse_sale_allocations(conn, sale_id)

        qty = float(quantity)
        net_proceeds = qty * float(price_per_unit) - float(brokerage)
        conn.execute(
            """UPDATE sales SET
                   sale_date=?, quantity=?, price_per_unit=?,
                   brokerage=?, net_proceeds=?, cgt_method=?, notes=?
               WHERE id=?""",
            (sale_date, qty, float(price_per_unit),
             float(brokerage), net_proceeds, cgt_method, notes, sale_id))

        parcels = _parcels_for_sale(conn, security_id, cgt_method, parcel_ids)
        discount_factor = _cgt_discount_factor(conn)

        remaining = qty
        proceeds_per_unit = net_proceeds / qty

        for parcel in parcels:
            if remaining <= 0:
                break
            sell_qty = min(remaining, parcel['quantity_remaining'])
            cb_per_unit = parcel['cost_base'] / parcel['quantity']
            cost_base_used = cb_per_unit * sell_qty
            gain_loss = proceeds_per_unit * sell_qty - cost_base_used
            acq = date.fromisoformat(parcel['acquisition_date'])
            sal = date.fromisoformat(sale_date)
            discount_eligible = 1 if _held_12_months(acq, sal) else 0
            discounted_gain = gain_loss * (1 - discount_factor) if discount_eligible and gain_loss > 0 else gain_loss
            conn.execute(
                """INSERT INTO sale_parcels
                   (sale_id, parcel_id, quantity_sold, cost_base_used,
                    gain_loss, discount_eligible, discounted_gain)
                   VALUES (?,?,?,?,?,?,?)""",
                (sale_id, parcel['id'], sell_qty, cost_base_used,
                 gain_loss, discount_eligible, discounted_gain))
            conn.execute(
                "UPDATE parcels SET quantity_remaining=quantity_remaining-? WHERE id=?",
                (sell_qty, parcel['id']))
            remaining -= sell_qty

        if remaining > 0.001:
            conn.rollback()
            raise ValueError(f"Insufficient open parcels — {remaining:.4f} shares could not be allocated")

        conn.commit()
    finally:
        conn.close()


# ── Dividend edit / delete ─────────────────────────────────────────────────────

def get_dividend(db_path, div_id):
    conn = get_connection(db_path)
    try:
        r = conn.execute(
            "SELECT d.*, s.code, s.name, s.security_type FROM dividends d "
            "JOIN securities s ON s.id = d.security_id WHERE d.id = ?",
            (div_id,)
        ).fetchone()
        if not r:
            return None
        row = dict(r)
        req = 90 if row.get('security_type') == 'preference' else 45
        row['eligible_45day'] = _check_45_day_rule(conn, row['security_id'], row.get('ex_date'), req)
        return row
    finally:
        conn.close()


def delete_dividend(db_path, div_id):
    conn = get_connection(db_path)
    try:
        div = conn.execute("SELECT * FROM dividends WHERE id = ?", (div_id,)).fetchone()
        if not div:
            return
        _check_date_not_locked(conn, div['payment_date'], 'dividend')
        drp_parcel_id = div['drp_parcel_id']
        # Check before mutating — prevent orphaned DRP parcel
        if drp_parcel_id:
            sold = conn.execute(
                "SELECT COUNT(*) FROM sale_parcels WHERE parcel_id = ?",
                (drp_parcel_id,)
            ).fetchone()[0]
            if sold:
                raise ValueError(
                    "Cannot delete this DRP dividend — its reinvestment parcel has been sold. "
                    "Delete the sale that consumed the DRP shares first, then retry.")
        old = dict(div)
        old['code'] = _sec_code(conn, old['security_id'])
        _write_audit(conn, 'delete', 'dividends', div_id, old)
        conn.execute("DELETE FROM dividends WHERE id = ?", (div_id,))
        if drp_parcel_id:
            conn.execute("DELETE FROM parcels WHERE id = ?", (drp_parcel_id,))
        conn.commit()
    finally:
        conn.close()


def update_dividend(db_path, div_id, payment_date, quantity_held, amount_per_share,
                    franking_pct=0.0, ex_date=None, notes='', franking_credit=None):
    gross = float(quantity_held) * float(amount_per_share)
    if franking_credit is None:
        franking_credit = (gross * float(franking_pct) / 100) / 0.70 * 0.30 if franking_pct else 0
    conn = get_connection(db_path)
    try:
        existing = conn.execute("SELECT * FROM dividends WHERE id = ?", (div_id,)).fetchone()
        if existing:
            _check_date_not_locked(conn, existing['payment_date'], 'dividend')
            old = dict(existing)
            old['code'] = _sec_code(conn, old['security_id'])
            _write_audit(conn, 'edit', 'dividends', div_id, old)
        _check_date_not_locked(conn, payment_date, 'dividend')
        conn.execute(
            """UPDATE dividends SET
                   payment_date=?, ex_date=?, quantity_held=?, amount_per_share=?,
                   gross_amount=?, franking_pct=?, franking_credit=?, net_amount=?, notes=?
               WHERE id=?""",
            (payment_date, ex_date or None, float(quantity_held), float(amount_per_share),
             gross, float(franking_pct), franking_credit, gross, notes, div_id))
        conn.commit()
    finally:
        conn.close()


# ── Audit log ──────────────────────────────────────────────────────────────────

def get_audit_log(db_path, limit=200):
    conn = get_connection(db_path)
    try:
        rows = conn.execute(
            """SELECT id, timestamp, action, table_name, record_id, old_data, new_data
               FROM audit_log ORDER BY id DESC LIMIT ?""",
            (limit,)
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ── Watch list ─────────────────────────────────────────────────────────────────

def get_watchlist(db_path):
    conn = get_connection(db_path)
    try:
        rows = [dict(r) for r in conn.execute(
            """SELECT w.*, s.code, s.name, s.exchange, s.security_type,
                      d.ex_date AS latest_ex_date
               FROM watchlist w
               JOIN securities s ON s.id = w.security_id
               LEFT JOIN (
                   SELECT security_id, MAX(ex_date) AS ex_date
                   FROM dividends
                   WHERE ex_date IS NOT NULL AND ex_date != ''
                   GROUP BY security_id
               ) d ON d.security_id = w.security_id
               ORDER BY s.code"""
        ).fetchall()]
        today = date.today()
        for row in rows:
            ex_str = row.get('latest_ex_date')
            req = 90 if row.get('security_type') == 'preference' else 45
            if ex_str:
                ex = date.fromisoformat(ex_str)
                must_hold = ex + timedelta(days=req)
                alert = (today >= ex - timedelta(days=req)) and (today <= must_hold)
                row['franking_alert']   = alert
                row['must_hold_until']  = str(must_hold) if alert else None
                row['latest_ex_date']   = ex_str if alert else None
            else:
                row['franking_alert']   = False
                row['must_hold_until']  = None
                row['latest_ex_date']   = None
        return rows
    finally:
        conn.close()


def add_watchlist_item(db_path, security_id, target_buy=None, target_sell=None, notes=''):
    conn = get_connection(db_path)
    try:
        item_id = conn.execute(
            """INSERT INTO watchlist (security_id, target_buy, target_sell, notes)
               VALUES (?, ?, ?, ?)""",
            (security_id, target_buy, target_sell, notes)
        ).lastrowid
        conn.commit()
        return item_id
    finally:
        conn.close()


def update_watchlist_item(db_path, item_id, target_buy=None, target_sell=None, notes=''):
    conn = get_connection(db_path)
    try:
        conn.execute(
            "UPDATE watchlist SET target_buy=?, target_sell=?, notes=? WHERE id=?",
            (target_buy, target_sell, notes, item_id)
        )
        conn.commit()
    finally:
        conn.close()


def delete_watchlist_item(db_path, item_id):
    conn = get_connection(db_path)
    try:
        conn.execute("DELETE FROM watchlist WHERE id=?", (item_id,))
        conn.commit()
    finally:
        conn.close()
