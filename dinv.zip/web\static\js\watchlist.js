// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — Watch List */

async function pageWatchlist() {
  const content = document.getElementById('module-content');
  content.innerHTML = `
    <div class="st-toolbar">
      <button class="btn btn-primary" onclick="_wlOpenForm(null)">+ Add to Watch List</button>
    </div>
    <div class="st-list-panel">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Code</th><th>Name</th>
            <th class="num">Current Price</th>
            <th class="num">Target Buy</th>
            <th class="num">Target Sell</th>
            <th>Signal</th><th>Franking Alert</th><th>Notes</th><th></th>
          </tr></thead>
          <tbody id="wl-tbody"></tbody>
        </table>
      </div>
    </div>
    <div class="count-pill" id="wl-count"></div>`;
  await _wlLoad();
}

let _wlRows = [];
let _wlSecurities = [];
let _wlPrices = {};

async function _wlLoad() {
  try {
    [_wlRows, _wlSecurities, _wlPrices] = await Promise.all([
      apiFetch('/api/watchlist'),
      apiFetch('/api/securities'),
      apiFetch('/api/prices'),
    ]);
    _wlRender();
  } catch (e) {
    toast(e.message, 'err');
  }
}

function _wlSignal(price, targetBuy, targetSell) {
  if (price === null) return { label: '—', priceStyle: 'color:var(--ink3)' };
  if (targetBuy  !== null && price <= targetBuy)
    return { label: 'Buy zone',  priceStyle: 'color:var(--green);font-weight:600' };
  if (targetSell !== null && price >= targetSell)
    return { label: 'Sell zone', priceStyle: 'color:var(--red);font-weight:600' };
  return { label: 'Watching', priceStyle: '' };
}

function _wlDist(price, target, direction) {
  // direction: 'buy' (price should fall to target) or 'sell' (price should rise to target)
  if (price === null || target === null) return '';
  const diff = direction === 'buy' ? price - target : target - price;
  const pct  = Math.abs(diff / target * 100);
  if (diff <= 0) return `<div style="font-size:10px;color:var(--${direction === 'buy' ? 'green' : 'red'});margin-top:1px">in zone</div>`;
  const sign = direction === 'buy' ? '↓' : '↑';
  const col  = direction === 'buy' ? 'var(--amber)' : 'var(--green)';
  return `<div style="font-size:10px;color:${col};margin-top:1px">${sign} ${fmtCurrency(diff)} (${pct.toFixed(1)}%)</div>`;
}

function _wlRender() {
  const tbody = document.getElementById('wl-tbody');
  if (!_wlRows.length) {
    tbody.innerHTML = `<tr><td colspan="9"><div class="st-empty">
      <div class="st-empty-icon">👁</div>
      <div class="st-empty-title">Watch list is empty</div>
      <div>Add securities to track target buy and sell prices.</div>
    </div></td></tr>`;
    document.getElementById('wl-count').textContent = '0 items';
    return;
  }
  tbody.innerHTML = _wlRows.map(w => {
    const p      = _wlPrices[w.security_id];
    const price  = p ? p.price : null;
    const sig    = _wlSignal(price, w.target_buy, w.target_sell);
    const sigStyle = sig.label === 'Buy zone'
      ? 'color:var(--green);font-weight:600'
      : sig.label === 'Sell zone'
      ? 'color:var(--red);font-weight:600'
      : 'color:var(--ink3)';
    const frankingCell = w.franking_alert
      ? `<span class="badge badge-amber" style="font-size:10px" title="Ex-div ${fmtDate(w.latest_ex_date)} — hold 45 days to claim franking credits">Hold until ${fmtDate(w.must_hold_until)}</span>`
      : `<span style="color:var(--ink3)">—</span>`;
    return `<tr>
      <td class="code-cell">${w.code}</td>
      <td>${w.name}</td>
      <td class="num mono" style="${sig.priceStyle}">${price !== null ? fmtCurrency(price) : '—'}</td>
      <td class="num mono">${w.target_buy  !== null ? fmtCurrency(w.target_buy)  + _wlDist(price, w.target_buy,  'buy')  : '—'}</td>
      <td class="num mono">${w.target_sell !== null ? fmtCurrency(w.target_sell) + _wlDist(price, w.target_sell, 'sell') : '—'}</td>
      <td style="font-size:12px;${sigStyle}">${sig.label}</td>
      <td style="font-size:12px">${frankingCell}</td>
      <td style="font-size:12px;color:var(--ink3)">${w.notes || ''}</td>
      <td style="white-space:nowrap">
        <button class="btn btn-ghost btn-sm" onclick="_wlOpenForm(${w.id})">Edit</button>
        <button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="_wlDelete(${w.id})">Del</button>
      </td>
    </tr>`;
  }).join('');
  document.getElementById('wl-count').textContent =
    `${_wlRows.length} item${_wlRows.length !== 1 ? 's' : ''}`;
}

function _wlOpenForm(id) {
  const w      = id ? _wlRows.find(r => r.id === id) : null;
  const isEdit = !!w;
  const available = isEdit
    ? _wlSecurities
    : _wlSecurities.filter(s => s.is_active && !_wlRows.find(r => r.security_id === s.id));
  const secOptions = available.map(s =>
    `<option value="${s.id}" ${w && s.id === w.security_id ? 'selected' : ''}>${s.code} — ${s.name}</option>`
  ).join('');

  openPanel(isEdit ? `Edit Watch — ${w.code}` : 'Add to Watch List', `
    <div class="field">
      <label>Security</label>
      <select id="wl-security" ${isEdit ? 'disabled' : ''}>
        <option value="">Select…</option>${secOptions}
      </select>
    </div>
    <div class="field-row cols-2">
      <div class="field">
        <label>Target Buy ($) <span style="font-weight:400;text-transform:none;letter-spacing:0">signal when price ≤ this</span></label>
        <input type="number" id="wl-buy" min="0" step="any" value="${w?.target_buy ?? ''}" placeholder="optional">
      </div>
      <div class="field">
        <label>Target Sell ($) <span style="font-weight:400;text-transform:none;letter-spacing:0">signal when price ≥ this</span></label>
        <input type="number" id="wl-sell" min="0" step="any" value="${w?.target_sell ?? ''}" placeholder="optional">
      </div>
    </div>
    <div class="field">
      <label>Notes</label>
      <textarea id="wl-notes" placeholder="Optional">${w?.notes || ''}</textarea>
    </div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_wlSave(${id || 'null'})">${isEdit ? 'Save Changes' : 'Add to Watch List'}</button>`
  );
}

async function _wlSave(id) {
  const security_id = id
    ? _wlRows.find(r => r.id === id)?.security_id
    : document.getElementById('wl-security').value;
  const target_buy  = document.getElementById('wl-buy').value  || null;
  const target_sell = document.getElementById('wl-sell').value || null;
  const notes       = document.getElementById('wl-notes').value;

  if (!security_id) return toast('Select a security', 'err');

  const url    = id ? `/api/watchlist/${id}` : '/api/watchlist';
  const method = id ? 'PUT' : 'POST';
  const body   = id
    ? { target_buy, target_sell, notes }
    : { security_id, target_buy, target_sell, notes };

  try {
    const r = await fetch(url, {
      method, headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    toast(id ? 'Watch item updated' : 'Added to watch list');
    await _wlLoad();
  } catch (e) {
    toast(e.message, 'err');
  }
}

async function _wlDelete(id) {
  const w = _wlRows.find(r => r.id === id);
  if (!confirm(`Remove ${w?.code || 'this security'} from watch list?`)) return;
  try {
    const r = await fetch(`/api/watchlist/${id}`, { method: 'DELETE' }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    toast('Removed from watch list');
    await _wlLoad();
  } catch (e) {
    toast(e.message, 'err');
  }
}
