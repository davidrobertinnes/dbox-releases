#!/usr/bin/env python3
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Investments — Investment Portfolio Manager
Usage: python web_server.py [portfolio.dinv] [--port 5100]
       python web_server.py my_super.dinv --port 5101
"""
import sys, os, argparse, threading, subprocess, webbrowser, logging, atexit

_LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'startup.log')
if sys.stdout is None:
    sys.stdout = open(_LOG_PATH, 'w', encoding='utf-8')
if sys.stderr is None:
    sys.stderr = open(_LOG_PATH, 'a', encoding='utf-8')
logging.getLogger('werkzeug').setLevel(logging.ERROR)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

_CHROME_PROFILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.chrome-profile')
_browser_proc = None


def _close_browser():
    if not _browser_proc or _browser_proc.poll() is not None:
        return
    try:
        if sys.platform == "win32":
            subprocess.call(
                ['taskkill', '/F', '/T', '/PID', str(_browser_proc.pid)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        else:
            _browser_proc.terminate()
    except Exception:
        pass

atexit.register(_close_browser)


import web.server as _srv
from core.database import initialise_database


def _open_app_browser(url):
    global _browser_proc

    if sys.platform == "win32":
        _CHROME_PATHS = [
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%PROGRAMFILES%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%PROGRAMFILES(X86)%\Google\Chrome\Application\chrome.exe"),
        ]
        _EDGE_PATHS = [
            os.path.expandvars(r"%PROGRAMFILES(X86)%\Microsoft\Edge\Application\msedge.exe"),
            os.path.expandvars(r"%PROGRAMFILES%\Microsoft\Edge\Application\msedge.exe"),
            os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
        ]
        _BRAVE_PATHS = [
            os.path.expandvars(r"%LOCALAPPDATA%\BraveSoftware\Brave-Browser\Application\brave.exe"),
        ]
        _CHROMIUM_PATHS = [
            os.path.expandvars(r"%LOCALAPPDATA%\Chromium\Application\chrome.exe"),
        ]
    elif sys.platform == "darwin":
        _CHROME_PATHS = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
        _EDGE_PATHS   = ["/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"]
        _BRAVE_PATHS  = ["/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"]
        _CHROMIUM_PATHS = ["/Applications/Chromium.app/Contents/MacOS/Chromium"]
    else:
        _CHROME_PATHS   = ["/usr/bin/google-chrome", "/usr/bin/google-chrome-stable"]
        _EDGE_PATHS     = ["/usr/bin/microsoft-edge"]
        _BRAVE_PATHS    = ["/usr/bin/brave-browser"]
        _CHROMIUM_PATHS = ["/usr/bin/chromium-browser", "/usr/bin/chromium"]

    def _find(paths):
        for p in paths:
            if p and os.path.isfile(p):
                return p
        return None

    def _launch(exe):
        global _browser_proc
        try:
            proc = subprocess.Popen(
                [exe, f"--app={url}", f"--user-data-dir={_CHROME_PROFILE}",
                 "--no-first-run", "--no-default-browser-check",
                 "--disable-session-crashed-bubble"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            _browser_proc = proc
            _srv._browser_proc = proc
            return proc
        except Exception:
            return None

    for paths in (_EDGE_PATHS, _CHROME_PATHS, _BRAVE_PATHS, _CHROMIUM_PATHS):
        exe = _find(paths)
        if exe and _launch(exe):
            return True

    webbrowser.open(url)
    return False


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Dogbox Investments — Investment Portfolio Manager")
    parser.add_argument("db_file", nargs="?", default="portfolio.dinv",
                        help="Path to .dinv portfolio file (default: portfolio.dinv)")
    parser.add_argument("--port", type=int, default=5100)
    parser.add_argument("--host", default="127.0.0.1")
    args = parser.parse_args()

    db_path = os.path.abspath(args.db_file)
    _srv.DB_PATH = db_path
    _srv.app.config['DB_PATH'] = db_path

    import secrets
    _srv.app.secret_key = secrets.token_bytes(32)

    initialise_database(db_path)

    url = f"http://{args.host}:{args.port}"
    print(f"\n  Dogbox Investments — Investment Portfolio Manager")
    print(f"  {'-' * 38}")
    print(f"  Portfolio : {db_path}")
    print(f"  Open      : {url}\n")

    def _open_browser():
        import time; time.sleep(1.2)
        _open_app_browser(url)
    threading.Thread(target=_open_browser, daemon=True).start()

    _srv.app.run(host=args.host, port=args.port, debug=False)
