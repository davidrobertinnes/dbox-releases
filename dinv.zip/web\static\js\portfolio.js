// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — Portfolio module (current holdings) */

async function pagePortfolio() {
  const content = document.getElementById('module-content');
  const today = new Date();
  const snapYr = today.getMonth() >= 6 ? today.getFullYear() : today.getFullYear() - 1;
  const defaultSnapDate = `${snapYr}-06-30`;

  content.innerHTML = `
    <div class="st-toolbar">
      <div id="port-current-tools" style="display:contents">
        <input class="st-search" id="port-search" type="search" placeholder="Search holdings…">
        <button class="btn btn-secondary" id="port-refresh-btn" onclick="_portRefreshPrices()">Refresh Prices</button>
        <button class="btn btn-primary" onclick="_portOpenBuy()">+ Buy</button>
      </div>
      <div id="port-snap-tools" style="display:none;gap:8px;align-items:center">
        <label style="font-size:13px;color:var(--ink2);font-weight:500">As at</label>
        <input type="date" id="port-snap-date" value="${defaultSnapDate}"
          style="padding:7px 12px;border:1px solid var(--border);border-radius:7px;background:var(--surface);font-size:13px;font-family:inherit;color:var(--ink);outline:none">
        <button class="btn btn-secondary" onclick="_portLoadSnapshot()">Load</button>
        <button class="btn btn-ghost" onclick="_portExportSnapshot()">Export CSV</button>
      </div>
      <div style="margin-left:auto;display:flex;align-items:center;gap:8px">
        <span style="font-size:12px;color:var(--ink3)">View:</span>
        <select id="port-mode" onchange="_portModeChange()"
          style="padding:6px 10px;border:1px solid var(--border);border-radius:7px;background:var(--surface);font-size:12px;font-family:inherit;color:var(--ink);outline:none">
          <option value="current">Current Holdings</option>
          <option value="snapshot">Holdings at Date</option>
        </select>
      </div>
    </div>
    <div class="st-kpi-strip" id="port-kpis"></div>
    <div class="st-list-panel">
      <div class="tbl-overflow">
        <table class="st-table" id="port-table">
          <thead id="port-thead"><tr>
            <th>Code</th><th>Name</th>
            <th class="num">Qty</th><th class="num">Avg Cost</th><th class="num">Cost Base</th>
            <th class="num">Price</th><th class="num">Mkt Value</th>
            <th class="num">P&amp;L</th><th class="num">P&amp;L %</th><th></th>
          </tr></thead>
          <tbody id="port-tbody"></tbody>
        </table>
      </div>
    </div>
    <div class="count-pill" id="port-count"></div>`;

  document.getElementById('port-search').addEventListener('input', _portFilter);
  await _portLoad();
}

let _portHoldings  = [];
let _portSecurities = [];
let _portPrices    = {};
let _portWatchlist = [];

async function _portLoad() {
  try {
    [_portHoldings, _portSecurities, _portPrices, _portWatchlist] = await Promise.all([
      apiFetch('/api/holdings'),
      apiFetch('/api/securities'),
      apiFetch('/api/prices'),
      apiFetch('/api/watchlist'),
    ]);
    _portRender();
  } catch (e) {
    toast(e.message, 'err');
  }
}

async function _portRefreshPrices() {
  const btn = document.getElementById('port-refresh-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Refreshing…'; }
  try {
    await fetch('/api/prices/refresh', { method: 'POST' }).then(r => r.json());
    _portPrices = await apiFetch('/api/prices');
    _portRender();
    toast('Prices updated');
  } catch (e) {
    toast('Price refresh failed', 'err');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Refresh Prices'; }
  }
}

function _portFilter() {
  const q = document.getElementById('port-search').value.toLowerCase();
  const rows = document.querySelectorAll('#port-tbody tr');
  let visible = 0;
  rows.forEach(r => {
    const match = r.textContent.toLowerCase().includes(q);
    r.style.display = match ? '' : 'none';
    if (match) visible++;
  });
  document.getElementById('port-count').textContent =
    `${visible} of ${_portHoldings.length} holding${_portHoldings.length !== 1 ? 's' : ''}`;
}

function _portRender() {
  const tbody = document.getElementById('port-tbody');
  let totalCost = 0, totalMktVal = 0, totalMktValKnown = 0;

  const enriched = _portHoldings.map(h => {
    const p = _portPrices[h.security_id];
    const price    = p ? p.price : null;
    const mktVal   = price !== null ? price * h.total_quantity : null;
    const pnl      = mktVal !== null ? mktVal - h.total_cost_base : null;
    const pnlPct   = pnl !== null && h.total_cost_base > 0 ? pnl / h.total_cost_base * 100 : null;
    totalCost += h.total_cost_base || 0;
    if (mktVal !== null) { totalMktVal += mktVal; totalMktValKnown++; }
    return { ...h, price, mktVal, pnl, pnlPct };
  });

  const totalPnl = totalMktValKnown > 0 ? totalMktVal - totalCost : null;
  const totalPnlPct = totalPnl !== null && totalCost > 0 ? totalPnl / totalCost * 100 : null;

  document.getElementById('port-kpis').innerHTML = `
    <div class="st-kpi">
      <div class="st-kpi-label">Positions</div>
      <div class="st-kpi-value col-accent">${_portHoldings.length}</div>
    </div>
    <div class="st-kpi">
      <div class="st-kpi-label">Total Cost Base</div>
      <div class="st-kpi-value col-ink">${fmtCurrency(totalCost)}</div>
    </div>
    ${totalMktValKnown > 0 ? `
    <div class="st-kpi">
      <div class="st-kpi-label">Market Value</div>
      <div class="st-kpi-value col-ink">${fmtCurrency(totalMktVal)}</div>
      <div class="st-kpi-sub">${totalMktValKnown} of ${_portHoldings.length} priced</div>
    </div>
    <div class="st-kpi">
      <div class="st-kpi-label">Unrealised P&amp;L</div>
      <div class="st-kpi-value ${gainClass(totalPnl)}">${fmtCurrency(totalPnl)}</div>
      <div class="st-kpi-sub">${totalPnlPct !== null ? (totalPnlPct >= 0 ? '+' : '') + totalPnlPct.toFixed(2) + '%' : ''}</div>
    </div>` : ''}`;

  if (!_portHoldings.length) {
    tbody.innerHTML = `<tr><td colspan="10">
      <div class="st-empty">
        <div class="st-empty-icon">📊</div>
        <div class="st-empty-title">No holdings yet</div>
        <div>Record your first purchase to get started.</div>
      </div></td></tr>`;
    document.getElementById('port-count').textContent = '0 holdings';
    return;
  }

  const watchedIds = new Set(_portWatchlist.map(w => w.security_id));
  tbody.innerHTML = enriched.map(h => {
    const priceCell = h.price !== null ? fmtCurrency(h.price) : '<span style="color:var(--ink3)">—</span>';
    const mktCell   = h.mktVal !== null ? fmtCurrency(h.mktVal) : '<span style="color:var(--ink3)">—</span>';
    const pnlCell   = h.pnl !== null
      ? `<span class="${gainClass(h.pnl)}">${fmtCurrency(h.pnl)}</span>`
      : '<span style="color:var(--ink3)">—</span>';
    const pnlPctCell = h.pnlPct !== null
      ? `<span class="${gainClass(h.pnlPct)}">${h.pnlPct >= 0 ? '+' : ''}${h.pnlPct.toFixed(2)}%</span>`
      : '<span style="color:var(--ink3)">—</span>';
    const watchCell = watchedIds.has(h.security_id)
      ? `<span style="color:var(--ink3);font-size:11px" title="On watch list">👁</span>`
      : `<button class="btn btn-ghost btn-sm" style="font-size:11px;padding:2px 7px"
           onclick="event.stopPropagation();_portWatchAdd(${h.security_id},this)">+ Watch</button>`;
    return `
    <tr style="cursor:pointer" onclick="_portViewSecurity(${h.security_id})">
      <td class="code-cell">${h.code}</td>
      <td>${h.name}</td>
      <td class="num mono">${fmtNum(h.total_quantity, 4)}</td>
      <td class="num mono">${fmtCurrency(h.avg_cost)}</td>
      <td class="num mono">${fmtCurrency(h.total_cost_base)}</td>
      <td class="num mono">${priceCell}</td>
      <td class="num mono">${mktCell}</td>
      <td class="num mono">${pnlCell}</td>
      <td class="num mono">${pnlPctCell}</td>
      <td style="white-space:nowrap">
        ${watchCell}
        <span style="color:var(--accent);font-size:12px;margin-left:6px">View &rsaquo;</span>
      </td>
    </tr>`;
  }).join('');

  document.getElementById('port-count').textContent =
    `${_portHoldings.length} holding${_portHoldings.length !== 1 ? 's' : ''}`;

  // Asset allocation section
  _portRenderAllocation(enriched);
}

function _portRenderAllocation(enriched) {
  const container = document.getElementById('module-content');
  const existing  = document.getElementById('port-alloc');
  if (existing) existing.remove();
  if (!enriched.length) return;

  // Use market value where available, else cost base
  const getValue = h => h.mktVal !== null ? h.mktVal : h.total_cost_base;
  const total    = enriched.reduce((s, h) => s + getValue(h), 0);
  if (!total) return;

  // By security type
  const byType = {};
  enriched.forEach(h => {
    const t = h.security_type || 'other';
    byType[t] = (byType[t] || 0) + getValue(h);
  });
  const typeLabel = { share:'Shares', etf:'ETFs', lpt:'LPT/REITs', bond:'Bonds', preference:'Preference Shares', other:'Other' };
  const typeEntries = Object.entries(byType).sort((a,b) => b[1] - a[1]);

  // By holding (top 8)
  const sortedH = [...enriched].sort((a,b) => getValue(b) - getValue(a)).slice(0, 8);

  const barHtml = (pct, color) =>
    `<div style="height:6px;border-radius:3px;background:var(--border);overflow:hidden;flex:1">
       <div style="height:100%;width:${pct.toFixed(1)}%;background:${color};border-radius:3px"></div>
     </div>`;

  const colors = ['var(--accent)','var(--green)','var(--amber)','var(--red)','var(--ink3)'];

  const allocDiv = document.createElement('div');
  allocDiv.id = 'port-alloc';
  allocDiv.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:20px">
      <div>
        <div class="st-section"><div class="st-section-title">By Type</div><div class="st-section-line"></div></div>
        <div class="st-list-panel" style="padding:12px 16px">
          ${typeEntries.map(([type, val], i) => {
            const pct = val / total * 100;
            return `<div style="margin-bottom:10px">
              <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px">
                <span style="font-weight:500">${typeLabel[type] || type}</span>
                <span style="font-family:'DM Mono',monospace;color:var(--ink2)">${fmtCurrency(val)} <span style="color:var(--ink3)">${pct.toFixed(1)}%</span></span>
              </div>
              ${barHtml(pct, colors[i % colors.length])}
            </div>`;
          }).join('')}
        </div>
      </div>
      <div>
        <div class="st-section"><div class="st-section-title">By Holding</div><div class="st-section-line"></div></div>
        <div class="st-list-panel" style="padding:12px 16px">
          ${sortedH.map((h, i) => {
            const val = getValue(h);
            const pct = val / total * 100;
            return `<div style="margin-bottom:10px">
              <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px">
                <span style="font-weight:600;color:var(--accent)">${h.code}</span>
                <span style="font-family:'DM Mono',monospace;color:var(--ink2)">${fmtCurrency(val)} <span style="color:var(--ink3)">${pct.toFixed(1)}%</span></span>
              </div>
              ${barHtml(pct, colors[i % colors.length])}
            </div>`;
          }).join('')}
          ${enriched.length > 8 ? `<div style="font-size:11px;color:var(--ink3);text-align:center;padding-top:4px">+ ${enriched.length - 8} more</div>` : ''}
        </div>
      </div>
    </div>`;

  container.appendChild(allocDiv);
}

// ── Buy form ──────────────────────────────────────────────────────────────────
function _portOpenBuy() {
  const secOptions = _portSecurities.map(s =>
    `<option value="${s.id}">${s.code} — ${s.name}</option>`
  ).join('');

  const addSecLink = `<a href="#" style="font-size:11px;color:var(--accent)" onclick="event.preventDefault();_portQuickAddSecurity()">+ Add new security</a>`;

  openPanel('Record Purchase', `
    <div class="field">
      <label>Security</label>
      <select id="buy-security">
        <option value="">Select…</option>
        ${secOptions}
      </select>
      ${addSecLink}
    </div>
    <div class="field-row cols-2">
      <div class="field">
        <label>Acquisition Date</label>
        <input type="date" id="buy-date" value="${new Date().toISOString().slice(0,10)}">
      </div>
      <div class="field">
        <label>Quantity</label>
        <input type="number" id="buy-qty" min="0" step="any" placeholder="0">
      </div>
    </div>
    <div class="field-row cols-2">
      <div class="field">
        <label>Price Per Unit ($)</label>
        <input type="number" id="buy-price" min="0" step="any" placeholder="0.00">
      </div>
      <div class="field">
        <label>Brokerage ($)</label>
        <input type="number" id="buy-brokerage" min="0" step="any"
          value="${(_appSettings && _appSettings.default_brokerage) || ''}" placeholder="0.00">
      </div>
    </div>
    <div class="field">
      <label>Other Costs ($) <span style="font-weight:400;text-transform:none;letter-spacing:0">stamp duty, levies etc.</span></label>
      <input type="number" id="buy-other" min="0" step="any" placeholder="0.00">
    </div>
    <div class="field">
      <label>Notes</label>
      <textarea id="buy-notes" placeholder="Optional"></textarea>
    </div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_portSaveBuy()">Save Purchase</button>`
  );
}

async function _portSaveBuy() {
  const security_id    = document.getElementById('buy-security').value;
  const acquisition_date = document.getElementById('buy-date').value;
  const quantity       = document.getElementById('buy-qty').value;
  const price_per_unit = document.getElementById('buy-price').value;
  const brokerage      = document.getElementById('buy-brokerage').value || '0';
  const other_costs    = document.getElementById('buy-other').value || '0';
  const notes          = document.getElementById('buy-notes').value;

  if (!security_id)    return toast('Select a security', 'err');
  if (!acquisition_date) return toast('Acquisition date is required', 'err');
  if (!quantity || parseFloat(quantity) <= 0) return toast('Quantity must be > 0', 'err');
  if (!price_per_unit || parseFloat(price_per_unit) <= 0) return toast('Price must be > 0', 'err');

  try {
    await fetch('/api/parcels', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ security_id, acquisition_date, quantity, price_per_unit, brokerage, other_costs, notes }),
    }).then(r => r.json()).then(j => { if (!j.ok) throw new Error(j.error); });

    closePanel();
    toast('Purchase recorded');
    await _portLoad();
  } catch (e) {
    toast(e.message, 'err');
  }
}

// ── Quick-add security ────────────────────────────────────────────────────────
function _portQuickAddSecurity() {
  openPanel('Add Security', `
    <div class="field-row cols-2">
      <div class="field">
        <label>Code</label>
        <input type="text" id="qsec-code" placeholder="e.g. CBA" style="text-transform:uppercase">
      </div>
      <div class="field">
        <label>Exchange</label>
        <select id="qsec-exchange">
          <option>ASX</option><option>NYSE</option><option>NASDAQ</option><option>LSE</option><option>OTHER</option>
        </select>
      </div>
    </div>
    <div class="field">
      <label>Name</label>
      <input type="text" id="qsec-name" placeholder="Commonwealth Bank of Australia">
    </div>
    <div class="field-row cols-2">
      <div class="field">
        <label>Type</label>
        <select id="qsec-type">
          <option value="share">Share</option>
          <option value="etf">ETF</option>
          <option value="lpt">LPT / REIT</option>
          <option value="bond">Bond</option>
          <option value="preference">Preference Share</option>
          <option value="other">Other</option>
        </select>
      </div>
      <div class="field">
        <label>Currency</label>
        <select id="qsec-currency">
          <option>AUD</option><option>USD</option><option>GBP</option><option>EUR</option>
        </select>
      </div>
    </div>`,
    `<button class="btn btn-secondary" onclick="_portOpenBuy()">Back</button>
     <button class="btn btn-primary" onclick="_portSaveNewSecurity()">Add &amp; Continue</button>`
  );
}

async function _portViewSecurity(securityId) {
  await loadModule('security_detail');
  viewSecurity(securityId, 'portfolio');
}

async function _portWatchAdd(securityId, btn) {
  if (btn) { btn.disabled = true; btn.textContent = '…'; }
  try {
    const r = await fetch('/api/watchlist', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ security_id: securityId }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    _portWatchlist = await apiFetch('/api/watchlist');
    _portRender();
    toast('Added to watch list');
  } catch (e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = '+ Watch'; }
  }
}

// ── Holdings at Date (snapshot mode) ─────────────────────────────────────────

function _portModeChange() {
  const mode        = document.getElementById('port-mode').value;
  const currentTools = document.getElementById('port-current-tools');
  const snapTools    = document.getElementById('port-snap-tools');

  if (mode === 'snapshot') {
    currentTools.style.display = 'none';
    snapTools.style.display    = 'flex';
    _portLoadSnapshot();
  } else {
    currentTools.style.display = 'contents';
    snapTools.style.display    = 'none';
    document.getElementById('port-thead').innerHTML = `<tr>
      <th>Code</th><th>Name</th>
      <th class="num">Qty</th><th class="num">Avg Cost</th><th class="num">Cost Base</th>
      <th class="num">Price</th><th class="num">Mkt Value</th>
      <th class="num">P&amp;L</th><th class="num">P&amp;L %</th><th></th>
    </tr>`;
    _portRender();
  }
}

async function _portLoadSnapshot() {
  const snapDate = document.getElementById('port-snap-date').value;
  if (!snapDate) return toast('Select a date', 'err');
  document.getElementById('port-tbody').innerHTML = `<tr><td colspan="6">
    <div class="st-empty"><div class="st-empty-icon">⏳</div>Loading…</div>
  </td></tr>`;
  try {
    const rows = await apiFetch(`/api/holdings-at-date?date=${snapDate}`);
    _portRenderSnapshot(rows, snapDate);
  } catch (e) {
    toast(e.message, 'err');
  }
}

function _portExportSnapshot() {
  const snapDate = document.getElementById('port-snap-date').value;
  if (snapDate) window.location.href = `/api/export/holdings-at-date.csv?date=${snapDate}`;
}

function _portRenderSnapshot(rows, snapDate) {
  // Group parcels by security
  const groups = {};
  rows.forEach(r => {
    if (!groups[r.security_id]) {
      groups[r.security_id] = {
        code: r.code, name: r.name, exchange: r.exchange,
        security_type: r.security_type, parcels: [],
        total_qty: 0, total_cb: 0,
      };
    }
    const g = groups[r.security_id];
    g.parcels.push(r);
    g.total_qty += r.qty_at_date;
    g.total_cb  += r.cost_base_at_date;
  });

  const secList    = Object.values(groups).sort((a, b) => a.code.localeCompare(b.code));
  const totalCB    = secList.reduce((s, g) => s + g.total_cb, 0);
  const totalParcels = rows.length;

  document.getElementById('port-kpis').innerHTML = `
    <div class="st-kpi">
      <div class="st-kpi-label">Positions</div>
      <div class="st-kpi-value col-accent">${secList.length}</div>
      <div class="st-kpi-sub">${totalParcels} parcel${totalParcels !== 1 ? 's' : ''}</div>
    </div>
    <div class="st-kpi">
      <div class="st-kpi-label">Total Cost Base</div>
      <div class="st-kpi-value col-ink">${fmtCurrency(totalCB)}</div>
    </div>
    <div class="st-kpi">
      <div class="st-kpi-label">As at</div>
      <div class="st-kpi-value col-ink" style="font-size:15px">${fmtDate(snapDate)}</div>
    </div>`;

  document.getElementById('port-thead').innerHTML = `<tr>
    <th>Code</th><th>Name</th><th>Acquired</th>
    <th class="num">Qty</th><th class="num">Cost Base</th><th class="num">Avg Cost/Unit</th>
  </tr>`;

  const alloc = document.getElementById('port-alloc');
  if (alloc) alloc.remove();

  if (!secList.length) {
    document.getElementById('port-tbody').innerHTML = `<tr><td colspan="6">
      <div class="st-empty">
        <div class="st-empty-icon">📋</div>
        <div class="st-empty-title">No holdings at ${fmtDate(snapDate)}</div>
        <div>No open parcels found for this date.</div>
      </div></td></tr>`;
    document.getElementById('port-count').textContent = `No holdings at ${snapDate}`;
    return;
  }

  document.getElementById('port-tbody').innerHTML = secList.map(g => {
    const avgCost   = g.total_qty > 0 ? g.total_cb / g.total_qty : 0;
    const multiParcel = g.parcels.length > 1;

    const summaryRow = `<tr${multiParcel ? ' style="font-weight:600"' : ''}>
      <td class="code-cell">${g.code}</td>
      <td>${g.name}</td>
      <td class="mono" style="font-size:11px;color:var(--ink3)">
        ${multiParcel ? g.parcels.length + ' parcels' : fmtDate(g.parcels[0].acquisition_date)}
      </td>
      <td class="num mono">${fmtNum(g.total_qty, 4)}</td>
      <td class="num mono">${fmtCurrency(g.total_cb)}</td>
      <td class="num mono" style="color:var(--ink3)">${fmtCurrency(avgCost)}</td>
    </tr>`;

    if (!multiParcel) return summaryRow;

    const parcelRows = g.parcels.map(p => {
      const pAvg = p.qty_at_date > 0 ? p.cost_base_at_date / p.qty_at_date : 0;
      return `<tr style="background:var(--row-alt)">
        <td style="padding-left:28px;color:var(--ink3);font-size:12px">↳</td>
        <td style="color:var(--ink3);font-size:12px">parcel ${p.parcel_id}</td>
        <td class="mono" style="font-size:11px;color:var(--ink2)">${fmtDate(p.acquisition_date)}</td>
        <td class="num mono" style="font-size:12px">${fmtNum(p.qty_at_date, 4)}</td>
        <td class="num mono" style="font-size:12px">${fmtCurrency(p.cost_base_at_date)}</td>
        <td class="num mono" style="font-size:12px;color:var(--ink3)">${fmtCurrency(pAvg)}</td>
      </tr>`;
    }).join('');

    return summaryRow + parcelRows;
  }).join('');

  document.getElementById('port-count').textContent =
    `${secList.length} position${secList.length !== 1 ? 's' : ''} · ` +
    `${totalParcels} parcel${totalParcels !== 1 ? 's' : ''} — as at ${snapDate}`;
}

async function _portSaveNewSecurity() {
  const code     = (document.getElementById('qsec-code').value || '').trim().toUpperCase();
  const name     = (document.getElementById('qsec-name').value || '').trim();
  const exchange = document.getElementById('qsec-exchange').value;
  const security_type = document.getElementById('qsec-type').value;
  const currency = document.getElementById('qsec-currency').value;

  if (!code) return toast('Code is required', 'err');
  if (!name) return toast('Name is required', 'err');

  try {
    await fetch('/api/securities', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, name, exchange, security_type, currency }),
    }).then(r => r.json()).then(j => { if (!j.ok) throw new Error(j.error); });

    _portSecurities = await apiFetch('/api/securities');
    toast(`${code} added`);
    _portOpenBuy();
    setTimeout(() => {
      const sel = document.getElementById('buy-security');
      if (sel) {
        for (const opt of sel.options) {
          if (opt.text.startsWith(code + ' —')) { sel.value = opt.value; break; }
        }
      }
    }, 50);
  } catch (e) {
    toast(e.message, 'err');
  }
}
