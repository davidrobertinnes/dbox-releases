# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Investments — full export and import.

One CSV file holds everything needed to rebuild a portfolio exactly: settings, securities
(with code/name history), purchases, dividends, corporate actions, sales with the parcels
they used, and the watch list. Importing it into an empty portfolio gives the same figures.

Rows are in date order, and within a day in the order the app applies events (purchases
and dividends, then corporate actions — demergers, returns of capital, bonus/rights issues,
splits/consolidations — then sales). Import applies them in that order whatever order the
rows are in, so a hand-made file only needs the right dates.

Parcels are referred to by Ref (e.g. P12). A sale's Allocations column lists the parcels
it used, e.g. "P12:500;P13:250.5" (units as at the sale date). A demerger's Allocations
maps each original parcel to the parcel created for the demerged security and that
parcel's label, e.g. "P3>P17#amp". Quantities and prices of purchases are as on the
contract note (units as at that date).

Hand-made files may also use the layout of a user's own master file (see _normalise_rows):
total Cost instead of Price, a single Ratio for splits, consolidations and demergers,
franked/unfranked/credit totals for dividends, Parcel labels with a list of labels to sell
from, short row types (Div, Con, Cancel, Rename) and settings as rows (Owner, TFN, ...).
"""
import csv
import os
import io
import re
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from fractions import Fraction

from .database import get_connection
from . import portfolio as pf

FORMAT_VERSION = 2
TITLE = 'Dogbox Investments full export'

COLUMNS = ['Type', 'Date', 'Code', 'Ref', 'Label', 'Quantity', 'Price', 'Cost', 'Brokerage',
           'Other Costs', 'Original Date', 'CGT Choice',
           'Franking %', 'Franking Credit', 'Ex Date', 'DRP Quantity', 'DRP Price',
           'Ratio From', 'Ratio To', 'New Code', 'Method', 'Allocations',
           'Name', 'Exchange', 'Security Type', 'Currency', 'Active',
           'Target Buy', 'Target Sell', 'Notes']

# Settings carried in the file. The TFN is deliberately left out: export files get shared.
SETTINGS = ('owner_name', 'fy_end', 'default_brokerage', 'marginal_tax_rate',
            'entity_type', 'indexation_default', 'cgt_carryforward_loss', 'locked_fy')
IMPORT_ONLY_SETTINGS = ('tfn',)   # accepted from a hand-made file, never exported

# Order of events within one day (see core/portfolio.py, _units_sold_after)
RANK = {'Buy': 0, 'Inherit': 0, 'Dividend': 0, 'Demerger': 1, 'Return of Capital': 2,
        'Bonus': 3, 'Rights Issue': 3, 'Split': 4, 'Consolidation': 4,
        'Sell': 5, 'Cancellation': 5}
ACTION_LABEL = {'split': 'Split', 'consolidation': 'Consolidation',
                'return_of_capital': 'Return of Capital', 'demerger': 'Demerger',
                'bonus': 'Bonus', 'rights_issue': 'Rights Issue'}
ACTION_TYPE = {v: k for k, v in ACTION_LABEL.items()}

_ADJUSTED = re.compile(r'\s*\[Adjusted for [^\]]*\]')


def _num(v):
    """Exact, compact text for a number (repr round-trips a float exactly)."""
    if v is None or v == '':
        return ''
    f = float(v)
    return str(int(f)) if f.is_integer() and abs(f) < 1e15 else repr(f)


# ── Export ────────────────────────────────────────────────────────────────────

def export_portfolio(db_path):
    """The whole portfolio as CSV text."""
    conn = get_connection(db_path)
    try:
        names_cache = {}

        def code_at(sid, d):
            if d not in names_cache:
                names_cache[d] = pf._names_at(conn, d)
            return names_cache[d][sid][0]

        out = [{'Type': 'Format', 'Quantity': FORMAT_VERSION, 'Notes': TITLE,
                'Date': date.today().isoformat()}]
        settings = {r['key']: r['value'] for r in conn.execute("SELECT key, value FROM settings")}
        for k in SETTINGS:
            if settings.get(k) not in (None, ''):
                out.append({'Type': 'Setting', 'Code': k, 'Notes': settings[k]})

        for s in conn.execute("SELECT * FROM securities ORDER BY id").fetchall():
            out.append({'Type': 'Security', 'Ref': f"S{s['id']}", 'Code': s['code'], 'Name': s['name'],
                        'Exchange': s['exchange'], 'Security Type': s['security_type'],
                        'Currency': s['currency'], 'Active': 1 if s['is_active'] else 0,
                        'Notes': s['notes'] or ''})
        for n in conn.execute("SELECT * FROM security_names ORDER BY security_id, effective_date").fetchall():
            out.append({'Type': 'Name', 'Ref': f"S{n['security_id']}", 'Date': n['effective_date'],
                        'Code': n['code'], 'Name': n['name']})

        derived = {r[0] for r in conn.execute("""
            SELECT drp_parcel_id FROM dividends WHERE drp_parcel_id IS NOT NULL
            UNION SELECT parcel_id FROM corporate_actions WHERE parcel_id IS NOT NULL
            UNION SELECT new_parcel_id FROM demerger_parcels""")}

        events = []   # (date, rank, sequence, row)
        for p in conn.execute("SELECT * FROM parcels ORDER BY id").fetchall():
            if p['id'] in derived:
                continue
            f = pf._split_factor(conn, p['security_id'], p['acquisition_date'], same_day=True)
            inherited = p['origin'] == 'inherited'
            events.append((p['acquisition_date'], RANK['Buy'], p['id'], {
                'Type': 'Inherit' if inherited else 'Buy', 'Date': p['acquisition_date'],
                'Original Date': p['cgt_date'] or '' if inherited else '',
                'Code': code_at(p['security_id'], p['acquisition_date']), 'Ref': f"P{p['id']}",
                # Converted back to contract-note units: round away float noise from the split ratios
                'Label': p['label'] or '',
                'Quantity': _num(p['quantity'] if f == 1 else round(p['quantity'] / f, 10)),
                # The total if one was typed (the price is worked out from it on import)
                'Price': '' if p['entered_total'] is not None else
                         _num(p['price_per_unit'] if f == 1 else round(p['price_per_unit'] * f, 10)),
                'Cost': _num(p['entered_total']),
                'Brokerage': _num(p['brokerage'] or 0), 'Other Costs': _num(p['other_costs'] or 0),
                'Notes': _ADJUSTED.sub('', p['notes'] or '').strip()}))

        for d in conn.execute("SELECT * FROM dividends ORDER BY id").fetchall():
            row = {'Type': 'Dividend', 'Date': d['payment_date'],
                   'Code': code_at(d['security_id'], d['payment_date']),
                   'Quantity': _num(d['quantity_held']), 'Price': _num(d['amount_per_share']),
                   'Franking %': _num(d['franking_pct'] or 0),
                   'Franking Credit': _num(d['franking_credit'] or 0),
                   'Ex Date': d['ex_date'] or '', 'Notes': d['notes'] or ''}
            if d['is_drp'] and d['drp_parcel_id']:
                lbl = conn.execute("SELECT label FROM parcels WHERE id = ?", (d['drp_parcel_id'],)).fetchone()
                row.update({'Ref': f"P{d['drp_parcel_id']}", 'DRP Quantity': _num(d['drp_quantity']),
                            'DRP Price': _num(d['drp_price']), 'Label': (lbl and lbl[0]) or ''})
            events.append((d['payment_date'], RANK['Dividend'], 1e9 + d['id'], row))

        for a in conn.execute("SELECT * FROM corporate_actions ORDER BY id").fetchall():
            label = ACTION_LABEL.get(a['action_type'])
            if not label:
                continue
            row = {'Type': label, 'Date': a['action_date'],
                   'Code': code_at(a['security_id'], a['action_date']),
                   'Notes': a['notes'] or '', 'Name': a['description'] or ''}
            kind = a['action_type']
            if kind in ('split', 'consolidation'):
                row.update({'Ratio From': _num(a['ratio_from']), 'Ratio To': _num(a['ratio_to'])})
            elif kind == 'return_of_capital':
                row['Price'] = _num(a['ratio_from'])
            elif kind == 'demerger':
                row.update({'Ratio From': _num(a['ratio_from']), 'Ratio To': _num(a['ratio_to']),
                            'New Code': code_at(a['new_security_id'], a['action_date']),
                            'Allocations': ';'.join(
                                f"P{r['original_parcel_id']}>P{r['new_parcel_id']}#{r['label'] or ''}"
                                for r in conn.execute("""SELECT dp.*, p.label FROM demerger_parcels dp
                                    JOIN parcels p ON p.id = dp.new_parcel_id
                                    WHERE dp.corporate_action_id = ? ORDER BY dp.id""", (a['id'],)))})
            elif kind == 'bonus' and not a['parcel_id']:
                row.update({'Ratio From': _num(a['ratio_from']), 'Ratio To': _num(a['ratio_to'])})
            else:   # rights issue (and bonus issues recorded by earlier versions)
                lbl = a['parcel_id'] and conn.execute("SELECT label FROM parcels WHERE id = ?",
                                                      (a['parcel_id'],)).fetchone()
                row.update({'Ref': f"P{a['parcel_id']}" if a['parcel_id'] else '',
                            'Quantity': _num(a['ratio_from']), 'Label': (lbl and lbl[0]) or ''})
                if kind == 'rights_issue':
                    row['Price'] = _num(a['ratio_to'])
            events.append((a['action_date'], RANK[label], a['id'], row))

        for s in conn.execute("SELECT * FROM sales ORDER BY id").fetchall():
            alloc = ';'.join(f"P{r['parcel_id']}:{_num(r['quantity_sold'])}" for r in conn.execute(
                "SELECT parcel_id, quantity_sold FROM sale_parcels WHERE sale_id = ? ORDER BY id",
                (s['id'],)))
            label = 'Cancellation' if s['kind'] == 'cancellation' else 'Sell'
            events.append((s['sale_date'], RANK[label], s['id'], {
                'Type': label, 'Date': s['sale_date'],
                'Code': code_at(s['security_id'], s['sale_date']),
                'Quantity': _num(s['quantity']),
                'Price': '' if s['entered_total'] is not None else _num(s['price_per_unit']),
                'Cost': _num(s['entered_total']),
                'Brokerage': _num(s['brokerage'] or 0), 'Method': s['cgt_method'] or 'fifo',
                'CGT Choice': s['cgt_choice'] or '',
                'Allocations': alloc, 'Notes': s['notes'] or ''}))

        events.sort(key=lambda e: (e[0], e[1], e[2]))
        out.extend(e[3] for e in events)

        for w in conn.execute("""SELECT w.*, s.code FROM watchlist w
                                 JOIN securities s ON s.id = w.security_id ORDER BY w.id""").fetchall():
            out.append({'Type': 'Watch', 'Code': w['code'], 'Target Buy': _num(w['target_buy']),
                        'Target Sell': _num(w['target_sell']), 'Notes': w['notes'] or ''})
    finally:
        conn.close()

    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=COLUMNS, lineterminator='\n')
    w.writeheader()
    for r in out:
        w.writerow({k: r.get(k, '') for k in COLUMNS})
    return buf.getvalue()


# ── Import ────────────────────────────────────────────────────────────────────

class ImportError_(ValueError):
    """An import problem, with the CSV line it was found on."""
    def __init__(self, line, message):
        super().__init__(f"Line {line}: {message}")
        self.line = line


def _date(v, line, field='Date', required=True):
    v = (v or '').strip()
    if not v:
        if required:
            raise ImportError_(line, f"{field} is missing")
        return None
    for fmt in ('%Y-%m-%d', '%d/%m/%Y'):
        try:
            return datetime.strptime(v, fmt).date().isoformat()
        except ValueError:
            pass
    raise ImportError_(line, f"{field} '{v}' isn't a date (use YYYY-MM-DD or DD/MM/YYYY)")


def _float(v, line, field, default=None):
    v = (v or '').strip().replace(',', '').replace('$', '')
    if not v:
        if default is None:
            raise ImportError_(line, f"{field} is missing")
        return default
    try:
        return float(v)
    except ValueError:
        raise ImportError_(line, f"{field} '{v}' isn't a number")


# ── Hand-made layouts ─────────────────────────────────────────────────────────

TYPE_ALIASES = {
    'format': 'Format', 'setting': 'Setting', 'security': 'Security', 'name': 'Name',
    'watch': 'Watch', 'rename': 'Rename',
    'buy': 'Buy', 'purchase': 'Buy', 'sell': 'Sell', 'sale': 'Sell', 'inherit': 'Inherit',
    'inherited': 'Inherit',
    'div': 'Dividend', 'dividend': 'Dividend',
    'split': 'Split', 'con': 'Consolidation', 'consolidate': 'Consolidation',
    'consolidation': 'Consolidation',
    'cancel': 'Cancellation', 'cancellation': 'Cancellation',
    'demerger': 'Demerger', 'bonus': 'Bonus', 'rights': 'Rights Issue', 'rights issue': 'Rights Issue',
    'roc': 'Return of Capital', 'return of capital': 'Return of Capital',
    'capital return': 'Return of Capital',
}
# Settings written as their own row type: (setting key, column holding the value)
SETTING_ROWS = {'owner': ('owner_name', 'Name'), 'tfn': ('tfn', 'Name'), 'fye': ('fy_end', 'Name'),
                'brokerage': ('default_brokerage', 'Cost'), 'entity': ('entity_type', 'Name'),
                'tax': ('marginal_tax_rate', 'Ratio'), 'loss': ('cgt_carryforward_loss', 'Cost')}
COLUMN_ALIASES = {'ex-div': 'Ex Date', 'ex div': 'Ex Date', 'ex-date': 'Ex Date',
                  'credit': 'Franking Credit'}
ENTITY_ALIASES = {'individual': 'individual', 'smsf': 'smsf_accumulation',
                  'smsf_accumulation': 'smsf_accumulation', 'smsf accumulation': 'smsf_accumulation',
                  'smsf_pension': 'smsf_pension', 'smsf pension': 'smsf_pension', 'pension': 'smsf_pension',
                  'company': 'company'}


def _dec(v, line, field):
    try:
        return Decimal(str(v).strip().replace(',', '').replace('$', ''))
    except InvalidOperation:
        raise ImportError_(line, f"{field} '{v}' isn't a number")


def _dec_text(d):
    """Shortest exact text for a Decimal (85.00 → 85)."""
    t = format(d.normalize(), 'f')
    return t.rstrip('0').rstrip('.') if '.' in t else t


def _setting_value(key, value, line):
    v = (value or '').strip()
    if key == 'fy_end':
        low = v.lower()
        if 'jun' in low:
            return 'june'
        if 'dec' in low:
            return 'december'
        raise ImportError_(line, f"FYE '{v}' — use June30 or Dec31")
    if key == 'entity_type':
        e = ENTITY_ALIASES.get(v.lower())
        if not e:
            raise ImportError_(line, f"Entity '{v}' — use individual, smsf, smsf pension or company")
        return e
    if key == 'marginal_tax_rate':
        rate = _dec(v, line, 'Tax rate')
        return _dec_text(rate * 100 if rate <= 1 else rate)
    if key in ('default_brokerage', 'cgt_carryforward_loss'):
        return _dec_text(_dec(v, line, key.replace('_', ' ')))
    return v


def _normalise_rows(rows):
    """
    Turn rows of a hand-made master file into the export's own rows (see the module
    docstring). Rows already in the export's layout pass through unchanged.
    Returns (rows, settings) — settings is [(line, key, value)] in date order, so the
    latest-dated value of a setting wins.
    """
    out, settings = [], []
    for n, r in rows:
        r = dict(r)
        low = r['Type'].strip().lower()
        if low in SETTING_ROWS:
            key, col = SETTING_ROWS[low]
            value = next((r.get(c) for c in (col, 'Name', 'Cost', 'Ratio', 'Price', 'Quantity')
                          if r.get(c)), '')
            settings.append((r.get('Date') or '', n, key, _setting_value(key, value, n)))
            continue
        t = TYPE_ALIASES.get(low, r['Type'].strip())
        r['Type'] = t
        if t == 'Setting':
            settings.append(('', n, r.get('Code', ''), r.get('Notes', '')))
            continue

        # A single Ratio (new units per old unit) for splits and consolidations
        if t in ('Split', 'Consolidation', 'Bonus') and r.get('Ratio') and not r.get('Ratio From'):
            fr = Fraction(_dec(r['Ratio'], n, 'Ratio')).limit_denominator(1_000_000)
            if fr <= 0 or fr == 1:
                raise ImportError_(n, "Ratio must be a positive number other than 1")
            r['Ratio From'], r['Ratio To'] = str(fr.denominator), str(fr.numerator)
        # Demerger: Quantity = new shares per original share, Ratio = share of the cost
        # base that moves to the new security
        if t == 'Demerger' and r.get('Ratio') and not r.get('Ratio From'):
            moved = _dec(r['Ratio'], n, 'Ratio')
            if not 0 < moved < 1:
                raise ImportError_(n, "Demerger Ratio is the share of the cost base moving to the "
                                      "new security, between 0 and 1 (e.g. 0.15)")
            r['Ratio From'] = _dec_text((1 - moved) * 100)
            r['Ratio To'] = r.get('Quantity') or '1'
            r['Quantity'] = ''
        # Dividend given as franked / unfranked totals: Quantity and Price/Cost are the DRP
        if t == 'Dividend' and (r.get('Franked') or r.get('Unfranked')):
            r['_totals'] = True
            q = r.get('Quantity') or ''
            if q and _dec(q, n, 'Quantity') > 0:
                r['DRP Quantity'] = q
                if r.get('Price'):
                    r['DRP Price'] = r['Price']
                elif r.get('Cost'):
                    r['DRP Price'] = repr(float(_dec(r['Cost'], n, 'Cost')) / float(_dec(q, n, 'Quantity')))
                else:
                    raise ImportError_(n, "A DRP needs a Price or Cost")
            r['Quantity'], r['Price'], r['Cost'] = '', '', ''
        # Parcel: a label for the parcel(s) a row creates, or the parcels a sale uses
        if r.get('Parcel'):
            if t in ('Sell', 'Cancellation'):
                r['Parcel Spec'] = r['Parcel']
            elif not r.get('Label'):
                r['Label'] = r['Parcel']
        out.append((n, r))
    settings.sort(key=lambda x: x[0])
    return out, [(n, k, v) for _, n, k, v in settings]


def _price(r, n, qty):
    """(price per unit, total as typed or None) from Price and/or Cost. Both given must agree."""
    if r.get('Cost'):
        cost = _float(r['Cost'], n, 'Cost')
        if not qty:
            raise ImportError_(n, "Quantity is missing")
        if r.get('Price'):
            price = _float(r['Price'], n, 'Price')
            if abs(price * qty - cost) > 0.01:
                raise ImportError_(n, f"Price × Quantity is {price * qty:,.2f} but Cost is {cost:,.2f}")
        return cost / qty, cost
    return _float(r.get('Price'), n, 'Price'), None


def _day_before(d):
    return (date.fromisoformat(d) - timedelta(days=1)).isoformat()


def read_rows(text):
    """CSV text → [(line number, row)] with column names normalised, blank-Type rows dropped."""
    reader = csv.DictReader(io.StringIO(text.lstrip('﻿')))
    if not reader.fieldnames or not any((f or '').strip().lower() == 'type' for f in reader.fieldnames):
        raise ImportError_(1, "This isn't a Dogbox Investments import file (no Type column)")
    canon = {c.lower(): c for c in COLUMNS + ['Parcel', 'Ratio', 'Franked', 'Unfranked']}
    canon.update(COLUMN_ALIASES)

    def col(name):
        k = (name or '').strip()
        return canon.get(k.lower(), k)
    rows = [(i + 2, {col(k): (v or '').strip() for k, v in r.items() if k})
            for i, r in enumerate(reader)]

    def comment(r):
        # Text in the Type column and nothing else, and not a row type: a comment line
        t = r['Type'].strip().lower()
        return (t not in TYPE_ALIASES and t not in SETTING_ROWS and t not in
                {k.lower() for k in RANK} and not any(v for k, v in r.items() if k != 'Type'))
    return [(n, r) for n, r in rows if r.get('Type') and not comment(r)]


def import_portfolio(db_path, text):
    """
    Import a full export (or a hand-made file) into an EMPTY portfolio. Raises ImportError_
    (with the line number) on the first problem; the caller discards the partly filled file.
    Returns counts of what was imported, and 'notes' — things the user should know.
    """
    rows = read_rows(text)
    fmt = next((r for _, r in rows if r['Type'] == 'Format'), None)
    if fmt and fmt.get('Quantity') and int(float(fmt['Quantity'])) > FORMAT_VERSION:
        raise ImportError_(2, "This file was exported by a newer version of Dogbox Investments — update first")
    rows, settings = _normalise_rows(rows)

    conn = get_connection(db_path)
    try:
        if conn.execute("SELECT 1 FROM securities").fetchone():
            raise ValueError("A full import needs an empty portfolio")
    finally:
        conn.close()

    known = set(RANK) | {'Format', 'Security', 'Name', 'Watch', 'Rename'}
    for n, r in rows:
        if r['Type'] not in known:
            raise ImportError_(n, f"Unknown row type '{r['Type']}'")

    counts = {k: 0 for k in ('securities', 'purchases', 'dividends', 'corporate_actions', 'sales')}
    notes = []
    has_security_rows = any(r['Type'] == 'Security' for _, r in rows)
    sec_ref, parcel_ref = {}, {}
    locked_fy = None

    def resolve(code, d, n, field='Code'):
        if not code:
            raise ImportError_(n, f"{field} is missing")
        sid = pf.security_id_for_code(db_path, code, d)
        if not sid and has_security_rows:
            raise ImportError_(n, f"No security has the code '{code}' on {d} — add a Security row for it")
        if not sid:
            # A file without Security rows: add each security, named after its code
            code = code.strip().upper()
            sid = pf.add_security(db_path, code, code)
            counts['securities'] += 1
            notes.append(f"Line {n}: added security {code} (no Security row) — set its name under Securities")
        return sid

    def parcel(ref, n):
        if ref not in parcel_ref:
            raise ImportError_(n, f"Parcel {ref} isn't defined earlier in the file")
        return parcel_ref[ref]

    def label(pid, value):
        if pid and value:
            pf.set_parcel_label(db_path, pid, value)

    # Settings (the FY lock last, so lodged years can be imported), securities, name history
    for n, key, value in settings:
        if key == 'locked_fy':
            locked_fy = value
        elif key in SETTINGS or key in IMPORT_ONLY_SETTINGS:
            pf.set_setting(db_path, key, value)
        else:
            raise ImportError_(n, f"Unknown setting '{key}'")
    for n, r in rows:
        if r['Type'] != 'Security':
            continue
        if not r.get('Code') or not r.get('Name'):
            raise ImportError_(n, "A Security row needs a Code and Name")
        if pf.get_security_by_code(db_path, r['Code']):
            raise ImportError_(n, f"Security {r['Code']} appears twice")
        sid = pf.add_security(db_path, r['Code'], r['Name'], exchange=r.get('Exchange') or 'ASX',
                              security_type=r.get('Security Type') or 'share',
                              currency=r.get('Currency') or 'AUD', notes=r.get('Notes', ''))
        if r.get('Active') in ('0', 'No', 'no', 'false'):
            pf.update_security(db_path, sid, r['Name'], r.get('Exchange') or 'ASX',
                               r.get('Security Type') or 'share', r.get('Currency') or 'AUD',
                               r.get('Notes', ''), is_active=0)
        sec_ref[r.get('Ref') or r['Code']] = sid
        counts['securities'] += 1
    conn = get_connection(db_path)
    try:
        for n, r in rows:
            if r['Type'] != 'Name':
                continue
            sid = sec_ref.get(r.get('Ref'))
            if not sid:
                raise ImportError_(n, f"Name row refers to unknown security {r.get('Ref')}")
            eff = _date(r.get('Date'), n, required=False) or ''
            conn.execute("""INSERT INTO security_names (security_id, effective_date, code, name)
                            VALUES (?, ?, ?, ?)""", (sid, eff, r['Code'].upper(), r['Name']))
        conn.commit()
    finally:
        conn.close()
    # Rename rows (Code = the code before; New Code and/or Name = after), in date order
    renames = sorted(((_date(r.get('Date'), n), n, r) for n, r in rows if r['Type'] == 'Rename'),
                     key=lambda x: x[0])
    for d, n, r in renames:
        sid = resolve(r.get('Code'), _day_before(d), n)
        conn = get_connection(db_path)
        try:
            code_then, name_then = pf._names_at(conn, _day_before(d))[sid]
        finally:
            conn.close()
        try:
            pf.add_security_name(db_path, sid, d, r.get('New Code') or code_then,
                                 r.get('Name') or name_then)
        except ValueError as e:
            raise ImportError_(n, str(e))

    # Events: date order, then the order within a day, then file order
    events = []
    for idx, (n, r) in enumerate(rows):
        if r['Type'] in RANK:
            events.append((_date(r.get('Date'), n), RANK[r['Type']], idx, n, r))
    events.sort(key=lambda e: e[:3])

    for d, _, _, n, r in events:
        t = r['Type']
        try:
            sid = resolve(r.get('Code'), d, n)
            if t == 'Buy':
                qty = _float(r.get('Quantity'), n, 'Quantity')
                price, total = _price(r, n, qty)
                pid = pf.add_parcel(db_path, sid, d, qty, price,
                                    brokerage=_float(r.get('Brokerage'), n, 'Brokerage', 0.0),
                                    other_costs=_float(r.get('Other Costs'), n, 'Other Costs', 0.0),
                                    notes=r.get('Notes', ''), label=r.get('Label'),
                                    entered_total=total)
                if r.get('Ref'):
                    parcel_ref[r['Ref']] = pid
                counts['purchases'] += 1
            elif t == 'Inherit':
                qty = _float(r.get('Quantity'), n, 'Quantity')
                if not r.get('Cost') and not r.get('Price'):
                    raise ImportError_(n, "Inherited shares need a Cost — the deceased's cost base, or "
                                          "the market value at the date of death if they acquired them "
                                          "before 20 September 1985")
                price, total = _price(r, n, qty)
                pid = pf.add_inherited(db_path, sid, d, qty, total if total is not None else price * qty,
                                       original_date=_date(r.get('Original Date'), n, 'Original Date',
                                                           required=False),
                                       label=r.get('Label'), notes=r.get('Notes', ''))
                if r.get('Ref'):
                    parcel_ref[r['Ref']] = pid
                counts['purchases'] += 1
            elif t == 'Dividend':
                drp_q = _float(r.get('DRP Quantity'), n, 'DRP Quantity', 0.0)
                ex_date = _date(r.get('Ex Date'), n, 'Ex Date', required=False)
                if r.get('_totals'):
                    # Totals from the statement: per-share amount from the units entitled
                    # (held at the end of the day before the ex-date)
                    franked = _float(r.get('Franked'), n, 'Franked', 0.0)
                    gross = franked + _float(r.get('Unfranked'), n, 'Unfranked', 0.0)
                    held = pf.units_held_at(db_path, sid, _day_before(ex_date) if ex_date else d)
                    if held <= 1e-9:
                        raise ImportError_(n, f"No {r.get('Code')} shares were held "
                                              f"{'before the ex-date ' + ex_date if ex_date else 'on ' + d}")
                    qty_held, per_share = held, gross / held
                    franking_pct = franked / gross * 100 if gross else 0.0
                else:
                    qty_held = _float(r.get('Quantity'), n, 'Quantity')
                    per_share = _float(r.get('Price'), n, 'Price')
                    franking_pct = _float(r.get('Franking %'), n, 'Franking %', 0.0)
                div_id = pf.add_dividend(
                    db_path, sid, d, qty_held, per_share,
                    franking_pct=franking_pct, ex_date=ex_date,
                    is_drp=1 if drp_q else 0, drp_quantity=drp_q or None,
                    drp_price=_float(r.get('DRP Price'), n, 'DRP Price') if drp_q else None,
                    notes=r.get('Notes', ''),
                    franking_credit=_float(r.get('Franking Credit'), n, 'Franking Credit', 0.0))
                if drp_q:
                    drp_pid = pf.get_dividend(db_path, div_id)['drp_parcel_id']
                    label(drp_pid, r.get('Label'))
                    if r.get('Ref'):
                        parcel_ref[r['Ref']] = drp_pid
                counts['dividends'] += 1
            elif t in ACTION_TYPE:
                kind = ACTION_TYPE[t]
                kw = {'description': r.get('Name', ''), 'notes': r.get('Notes', '')}
                if kind in ('split', 'consolidation', 'demerger'):
                    a, b = _float(r.get('Ratio From'), n, 'Ratio From'), _float(r.get('Ratio To'), n, 'Ratio To')
                elif kind == 'return_of_capital':
                    a, b = _float(r.get('Price'), n, 'Price (amount per unit)'), 0
                elif kind == 'bonus' and r.get('Ratio From'):
                    a, b = _float(r.get('Ratio From'), n, 'Ratio From'), _float(r.get('Ratio To'), n, 'Ratio To')
                    if b <= a:
                        raise ImportError_(n, "A bonus issue's Ratio To must be more than Ratio From "
                                              "(1 for 10 = 10 to 11)")
                elif kind == 'bonus':      # old form: Quantity of bonus shares as a separate parcel
                    a, b = _float(r.get('Quantity'), n, 'Quantity'), 0
                else:
                    a = _float(r.get('Quantity'), n, 'Quantity')
                    b, _ = _price(r, n, a)
                if kind == 'demerger':
                    kw['new_security_id'] = resolve(r.get('New Code'), d, n, 'New Code')
                action_id = pf.apply_corporate_action(db_path, sid, d, kind, a, b, **kw)
                if kind in ('bonus', 'rights_issue') and b == 0 or kind == 'rights_issue':
                    a_row = [x for x in pf.get_corporate_actions(db_path, sid) if x['id'] == action_id][0]
                    label(a_row['parcel_id'], r.get('Label'))
                    if r.get('Ref'):
                        parcel_ref[r['Ref']] = a_row['parcel_id']
                if kind == 'demerger':
                    conn = get_connection(db_path)
                    try:
                        child_of = {x['original_parcel_id']: x['new_parcel_id'] for x in conn.execute(
                            "SELECT * FROM demerger_parcels WHERE corporate_action_id = ?", (action_id,))}
                    finally:
                        conn.close()
                    if r.get('Label'):      # one label for every new parcel
                        for child in child_of.values():
                            label(child, r['Label'])
                    for pair in filter(None, (r.get('Allocations') or '').split(';')):
                        orig, _, rest = pair.partition('>')
                        child, has_label, child_label = rest.partition('#')
                        opid = parcel(orig.strip(), n)
                        if opid not in child_of:
                            raise ImportError_(n, f"Parcel {orig.strip()} wasn't held on the demerger date")
                        parcel_ref[child.strip()] = child_of[opid]
                        if has_label:
                            pf.set_parcel_label(db_path, child_of[opid], child_label)
                counts['corporate_actions'] += 1
            else:   # Sell / Cancellation
                qty = _float(r.get('Quantity'), n, 'Quantity')
                price, total = _price(r, n, qty)
                method = r.get('Method') or ('prorata' if t == 'Cancellation' else 'fifo')
                allocations = None
                if r.get('Allocations'):
                    allocations = []
                    for pair in filter(None, r['Allocations'].split(';')):
                        ref, _, q = pair.partition(':')
                        allocations.append((parcel(ref.strip(), n), _float(q, n, 'allocation quantity')))
                elif r.get('Parcel Spec'):
                    spec = [x.strip() for x in r['Parcel Spec'].split(',') if x.strip()]
                    if len(spec) == 1 and spec[0].upper() in pf.LABEL_METHODS:
                        method = pf.LABEL_METHODS[spec[0].upper()]
                    else:
                        allocations = pf.allocate_by_labels(db_path, sid, d, qty, r['Parcel Spec'])
                        method = 'specific'
                pf.add_sale(db_path, sid, d, qty, price,
                            brokerage=_float(r.get('Brokerage'), n, 'Brokerage', 0.0),
                            cgt_method=method, notes=r.get('Notes', ''), allocations=allocations,
                            kind='cancellation' if t == 'Cancellation' else 'sale',
                            entered_total=total, cgt_choice=(r.get('CGT Choice') or '').lower() or None)
                counts['sales'] += 1
        except ImportError_:
            raise
        except (ValueError, KeyError) as e:
            raise ImportError_(n, str(e))

    # Watch list exactly as in the file (purchases add entries automatically)
    watch = [(n, r) for n, r in rows if r['Type'] == 'Watch']
    if watch or fmt:
        for w in pf.get_watchlist(db_path):
            pf.delete_watchlist_item(db_path, w['id'])
    for n, r in watch:
        s = pf.get_security_by_code(db_path, r.get('Code', ''))
        if not s:
            raise ImportError_(n, f"Watch list row for unknown security {r.get('Code')}")
        pf.add_watchlist_item(db_path, s['id'],
                              _float(r.get('Target Buy'), n, 'Target Buy', 0.0) or None,
                              _float(r.get('Target Sell'), n, 'Target Sell', 0.0) or None,
                              r.get('Notes') or None)
    if locked_fy:
        pf.set_setting(db_path, 'locked_fy', locked_fy)
    counts['notes'] = notes
    return counts


# ── Add a file to an existing portfolio ─────────────────────────────────────

# Figures compared before and after, per financial year
MERGE_FIGURES = (
    ('Item 11 assessable dividends', 'income', 'assessable'),
    ('Franking credits claimable',   'income', 'credits_claimable'),
    ('Item 18H total capital gains', 'cgt',    'total_gains'),
    ('Capital losses',               'cgt',    'total_losses'),
    ('Item 18A net capital gain',    'cgt',    'net_capital_gain'),
    ('Losses carried forward',       'cgt',    'carry_forward_remaining'),
)
MERGE_PREFIX = 'M_'


def _merge_temp_path(db_path):
    return db_path + '.merge.tmp'


def _activity_fys(db_path):
    """Financial years with sales, dividends or returns of capital."""
    conn = get_connection(db_path)
    try:
        dates = [r[0] for r in conn.execute("""
            SELECT sale_date FROM sales UNION SELECT payment_date FROM dividends
            UNION SELECT action_date FROM corporate_actions WHERE action_type = 'return_of_capital'""")]
    finally:
        conn.close()
    return {pf._date_to_fy(d) for d in dates if d}


def fy_figures(db_path, fys):
    out = {}
    for fy in sorted(fys):
        income, cgt = pf.compute_fy_income(db_path, fy), pf.compute_fy_cgt(db_path, fy)
        src = {'income': income, 'cgt': cgt}
        out[fy] = {label: round(float(src[kind].get(key) or 0.0), 2) for label, kind, key in MERGE_FIGURES}
    return out


def _fingerprint(db_path):
    """Changes whenever anything in the portfolio changes (for 'nothing changed since the preview')."""
    import hashlib
    return hashlib.sha256(export_portfolio(db_path).split('\n', 2)[2].encode()).hexdigest()


def _prefix_refs(r):
    p = MERGE_PREFIX
    if r.get('Ref'):
        r['Ref'] = p + r['Ref']
    if r.get('Allocations'):
        parts = []
        for pair in filter(None, r['Allocations'].split(';')):
            if '>' in pair:
                orig, _, child = pair.partition('>')
                parts.append(f"{p}{orig.strip()}>{p}{child.strip()}")
            else:
                ref, _, q = pair.partition(':')
                parts.append(f"{p}{ref.strip()}:{q}")
        r['Allocations'] = ';'.join(parts)
    return r


def merge_preview(db_path, text):
    """
    Add the events in a file (full export or hand-made) to this portfolio, by rebuilding
    the whole portfolio from its full history plus the new rows in a temporary file.
    Nothing in the portfolio changes until merge_apply. Existing sales keep the parcels
    they used. The file's settings are ignored, and securities that already exist are
    matched by code.

    Returns {'counts', 'notes', 'changes': [{'fy', 'locked', 'figures': [...]}],
             'blocked': [fy, ...], 'fingerprint'}. A locked year whose figures change blocks it.
    """
    new_rows = read_rows(text)
    notes = []
    existing = {}
    for s in pf.get_securities(db_path, active_only=False):
        existing[s['code']] = s['id']
        for n in pf.get_security_names(db_path, s['id']):
            existing.setdefault(n['code'], s['id'])
    watched = {w['code'] for w in pf.get_watchlist(db_path)}
    dropped_refs = set()

    kept = []
    for n, r in new_rows:
        low = r['Type'].strip().lower()
        t = TYPE_ALIASES.get(low, r['Type'])
        if t == 'Format':
            continue
        if t == 'Setting' or low in SETTING_ROWS:
            notes.append(f"Line {n}: settings in the file are ignored — this portfolio's settings are kept")
            continue
        if t == 'Security' and (r.get('Code') or '').upper() in existing:
            dropped_refs.add(r.get('Ref') or r['Code'])
            continue
        if t == 'Name' and r.get('Ref') in dropped_refs:
            continue        # the existing security's code history is kept
        if t == 'Rename' and (r.get('Code') or '').upper() in existing:
            sid = existing[r['Code'].upper()]
            d = _date(r.get('Date'), n)
            if any(x['effective_date'] == d for x in pf.get_security_names(db_path, sid)):
                continue    # already recorded
        if t == 'Watch' and (r.get('Code') or '').upper() in watched:
            continue
        kept.append((n, _prefix_refs(dict(r))))
    if not any(TYPE_ALIASES.get(r['Type'].strip().lower(), r['Type']) in RANK for _, r in kept):
        raise ValueError("The file has no purchases, sales, dividends or corporate actions to add")

    # The portfolio's own full export, then the new rows
    base = read_rows(export_portfolio(db_path))
    rows = [r for _, r in base] + [r for _, r in kept]
    cols = list(COLUMNS)
    for r in rows:
        cols += [k for k in r if k not in cols]
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=cols, lineterminator='\n')
    w.writeheader()
    for r in rows:
        w.writerow({k: r.get(k, '') for k in cols})
    # Line numbers in errors should point at the user's file, not the combined one
    first_new = len(base) + 2
    line_map = {first_new + i: n for i, (n, _) in enumerate(kept)}

    tmp = _merge_temp_path(db_path)
    _remove_db(tmp)
    from .database import initialise_database
    initialise_database(tmp)
    try:
        try:
            counts = import_portfolio(tmp, buf.getvalue())
        except ImportError_ as e:
            msg = str(e).split(': ', 1)[-1]
            if e.line in line_map:
                raise ImportError_(line_map[e.line], msg)
            raise ValueError(f"Your existing records couldn't be rebuilt with the new rows: {msg}")
        _carry_over(db_path, tmp)
    except Exception:
        _remove_db(tmp)
        raise

    before_counts = _record_counts(db_path)
    after_counts = _record_counts(tmp)
    added = {k: after_counts[k] - before_counts[k] for k in after_counts}

    fys = _activity_fys(db_path) | _activity_fys(tmp)
    before, after = fy_figures(db_path, fys), fy_figures(tmp, fys)
    conn = get_connection(db_path)
    try:
        locked = pf._locked_fy(conn)
    finally:
        conn.close()
    changes, blocked = [], []
    for fy in sorted(fys):
        diff = [{'label': label, 'before': before[fy][label], 'after': after[fy][label]}
                for label, _, _ in MERGE_FIGURES if abs(before[fy][label] - after[fy][label]) >= 0.005]
        if diff:
            changes.append({'fy': fy, 'locked': bool(locked and fy <= locked), 'figures': diff})
            if locked and fy <= locked:
                blocked.append(fy)
    return {'counts': added, 'notes': sorted(set(notes)) + counts.get('notes', []),
            'changes': changes, 'blocked': blocked, 'fingerprint': _fingerprint(db_path)}


def merge_apply(db_path, fingerprint):
    """Replace the portfolio with the rebuilt one from merge_preview. Backs up first."""
    tmp = _merge_temp_path(db_path)
    if not os.path.exists(tmp):
        raise ValueError("Preview the file again — the rebuilt portfolio isn't there any more")
    if fingerprint != _fingerprint(db_path):
        _remove_db(tmp)
        raise ValueError("The portfolio changed since the preview — preview the file again")
    import sqlite3
    stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
    backup = f"{db_path}.before-merge-{stamp}.bak"
    src = sqlite3.connect(db_path)
    try:
        dst = sqlite3.connect(backup)
        src.backup(dst)
        dst.close()
    finally:
        src.close()
    new = sqlite3.connect(tmp)
    try:
        dst = sqlite3.connect(db_path)
        new.backup(dst)
        dst.close()
    finally:
        new.close()
    _remove_db(tmp)
    conn = get_connection(db_path)
    try:
        pf._write_audit(conn, 'merge', 'portfolio', 0,
                        {'backup': os.path.basename(backup)},
                        {'note': 'Records added from a file; the portfolio was rebuilt from its full '
                                 'history, so record numbers in earlier audit entries refer to the '
                                 'old numbering'})
        conn.commit()
    finally:
        conn.close()
    return {'backup': backup}


def merge_cancel(db_path):
    _remove_db(_merge_temp_path(db_path))


def _record_counts(db_path):
    conn = get_connection(db_path)
    try:
        q = lambda sql: conn.execute(sql).fetchone()[0]
        return {'securities': q("SELECT COUNT(*) FROM securities"),
                'purchases': q("""SELECT COUNT(*) FROM parcels p WHERE NOT EXISTS
                    (SELECT 1 FROM dividends d WHERE d.drp_parcel_id = p.id) AND NOT EXISTS
                    (SELECT 1 FROM corporate_actions c WHERE c.parcel_id = p.id) AND NOT EXISTS
                    (SELECT 1 FROM demerger_parcels x WHERE x.new_parcel_id = p.id)"""),
                'dividends': q("SELECT COUNT(*) FROM dividends"),
                'corporate_actions': q("SELECT COUNT(*) FROM corporate_actions"),
                'sales': q("SELECT COUNT(*) FROM sales")}
    finally:
        conn.close()


def _carry_over(db_path, tmp):
    """Copy what a full export leaves out from the portfolio into the rebuilt one: every
    setting (TFN, one-off repair flags), the audit log and cached prices (matched by code)."""
    old, new = get_connection(db_path), get_connection(tmp)
    try:
        for r in old.execute("SELECT key, value FROM settings").fetchall():
            new.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (r['key'], r['value']))
        for r in old.execute("SELECT * FROM audit_log ORDER BY id").fetchall():
            new.execute("""INSERT INTO audit_log (timestamp, action, table_name, record_id, old_data, new_data)
                           VALUES (?, ?, ?, ?, ?, ?)""",
                        (r['timestamp'], r['action'], r['table_name'], r['record_id'], r['old_data'], r['new_data']))
        ids = {r['code']: r['id'] for r in new.execute("SELECT id, code FROM securities")}
        for r in old.execute("SELECT s.code, p.price, p.fetched_at FROM prices p "
                             "JOIN securities s ON s.id = p.security_id").fetchall():
            if r['code'] in ids:
                new.execute("INSERT OR REPLACE INTO prices (security_id, price, fetched_at) VALUES (?, ?, ?)",
                            (ids[r['code']], r['price'], r['fetched_at']))
        new.commit()
    finally:
        old.close()
        new.close()


def _remove_db(path):
    for suffix in ('', '-wal', '-shm'):
        try:
            os.remove(path + suffix)
        except OSError:
            pass
