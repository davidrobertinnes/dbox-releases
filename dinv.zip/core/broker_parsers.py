# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
sharetrack — Broker-specific CSV parsers.

Each parser normalises a broker's native export to the standard row dict:
  {row, date, code, type, quantity, price, brokerage, franking_pct, notes,
   security_id, security_name, warning}

type values: 'Buy' | 'Sell' | 'Dividend'
"""
import csv
import io
import re


# ── Shared helpers ─────────────────────────────────────────────────────────────

def _parse_date(s):
    s = s.strip()
    if re.match(r'^\d{4}-\d{2}-\d{2}$', s):
        return s
    if re.match(r'^\d{2}/\d{2}/\d{4}$', s):
        d, m, y = s.split('/')
        return f"{y}-{m}-{d}"
    if re.match(r'^\d{1,2}/\d{1,2}/\d{2}$', s):
        d, m, y = s.split('/')
        return f"20{y}-{m.zfill(2)}-{d.zfill(2)}"
    raise ValueError(f"Unrecognised date format: {s!r}")


def _num(s):
    return float((s or '0').replace(',', '').replace('$', '').strip() or '0')


def _read_rows(content):
    reader = csv.DictReader(io.StringIO(content))
    return [{k.strip(): (v or '').strip() for k, v in row.items()} for row in reader]


def _headers(content):
    first = content.split('\n')[0]
    return [c.strip() for c in next(csv.reader(io.StringIO(first)), [])]


# ── Format detection ───────────────────────────────────────────────────────────

def detect_format(content):
    """
    Inspect the header row and return a format identifier.

    Returns one of:
      'commsec_confirmations'  CommSec ConfirmationDetails.csv
      'selfwealth'             SelfWealth transaction history
      'generic_flex'           Any broker with standard-ish column names
      'template'               The sharetrack app template
      'unknown'                Unrecognised — caller should fall back
    """
    h = {c.lower() for c in _headers(content)}
    # CommSec ConfirmationDetails.csv
    if {'date', 'reference', 'details', 'debit($)', 'credit($)'}.issubset(h):
        return 'commsec_confirmations'
    # SelfWealth — look for their typical column set
    if {'date', 'type', 'code', 'units', 'unit price', 'brokerage'}.issubset(h):
        return 'selfwealth'
    if {'date', 'transaction type', 'code', 'units', 'unit price'}.issubset(h):
        return 'selfwealth'
    # App template — check before generic_flex (discriminated by Franking% column)
    if {'date', 'code', 'type', 'quantity', 'price', 'franking%'}.issubset(h):
        return 'template'
    # Generic flexible (separate code + type + qty + price columns)
    if {'date', 'type', 'code', 'quantity', 'price'}.issubset(h):
        return 'generic_flex'
    if {'date', 'transaction type', 'code', 'quantity', 'price'}.issubset(h):
        return 'generic_flex'
    if {'date', 'type', 'security', 'quantity', 'price'}.issubset(h):
        return 'generic_flex'
    return 'unknown'


# ── CommSec ConfirmationDetails.csv ───────────────────────────────────────────
#
# Columns: Date, Reference, Details, Debit($), Credit($), Balance($)
# Details field: "B 100 CBA @ 93.50"  or  "S 50 WOW @ 35.20"
# Brokerage = Debit − qty×price  (buy)  or  qty×price − Credit  (sell)
# Dividends are NOT included in this CommSec export.

_COMMSEC_RE = re.compile(
    r'^([BS])\s+([\d,]+)\s+([A-Z0-9]+)\s+@\s+([\d.]+)',
    re.IGNORECASE,
)


def parse_commsec_confirmations(content, securities):
    rows_raw = _read_rows(content)
    parsed, errors = [], []
    for i, row in enumerate(rows_raw, 1):
        details = row.get('Details', '')
        m = _COMMSEC_RE.match(details)
        if not m:
            continue   # non-trade rows (interest, fees, CHESS) — skip silently
        try:
            raw_type, raw_qty, code, raw_price = m.groups()
            typ    = 'Buy' if raw_type.upper() == 'B' else 'Sell'
            qty    = float(raw_qty.replace(',', ''))
            price  = float(raw_price)
            debit  = _num(row.get('Debit($)', ''))
            credit = _num(row.get('Credit($)', ''))
            if typ == 'Buy':
                brok = round(max(debit - qty * price, 0.0), 2)
            else:
                brok = round(max(qty * price - credit, 0.0), 2)
            date = _parse_date(row.get('Date', ''))
            code = code.upper()
            sec  = securities.get(code)
            parsed.append({
                'row': i, 'date': date, 'code': code, 'type': typ,
                'quantity': qty, 'price': price, 'brokerage': brok,
                'franking_pct': 0.0,
                'notes':        row.get('Reference', ''),
                'security_id':  sec['id']   if sec else None,
                'security_name': sec['name'] if sec else None,
                'warning':      f"Security {code!r} not found — row will be skipped" if not sec else None,
            })
        except Exception as e:
            errors.append({'row': i, 'error': str(e)})
    return parsed, errors


# ── SelfWealth transaction history ────────────────────────────────────────────
#
# Typical columns: Date, Type, Code, Company, Units, Unit Price, Brokerage, Net Amount
# or:              Date, Transaction Type, Code, Description, Units, Unit Price, Brokerage, Amount
# Type values: BUY, SELL, DIVIDEND (case-insensitive)

_TYPE_MAP = {
    'buy': 'Buy', 'b': 'Buy',
    'sell': 'Sell', 's': 'Sell',
    'dividend': 'Dividend', 'div': 'Dividend', 'd': 'Dividend', 'income': 'Dividend',
}


def _flex_get(row, *keys):
    for k in keys:
        v = row.get(k, '') or row.get(k.lower(), '')
        if v:
            return v
    return ''


def parse_selfwealth(content, securities):
    rows_raw = [{k.lower(): v for k, v in r.items()} for r in _read_rows(content)]
    parsed, errors = [], []
    for i, row in enumerate(rows_raw, 1):
        try:
            date_raw = _flex_get(row, 'date', 'trade date', 'settlement date', 'transaction date')
            type_raw = _flex_get(row, 'type', 'transaction type', 'trade type')
            code_raw = _flex_get(row, 'code', 'security code', 'asx code', 'security')
            qty_raw  = _flex_get(row, 'units', 'quantity', 'qty', 'volume')
            prc_raw  = _flex_get(row, 'unit price', 'price', 'price ($)', 'trade price')
            brok_raw = _flex_get(row, 'brokerage', 'brokerage ($)', 'commission', 'fee')
            frank_raw= _flex_get(row, 'franking%', 'franking %', 'franking pct')
            notes_raw= _flex_get(row, 'description', 'company', 'details', 'notes', 'reference')

            if not date_raw or not type_raw or not code_raw:
                continue
            typ = _TYPE_MAP.get(type_raw.lower().strip())
            if not typ:
                continue
            qty  = _num(qty_raw)
            prc  = _num(prc_raw)
            brok = _num(brok_raw)
            frank= _num(frank_raw)
            if qty <= 0:
                continue
            date = _parse_date(date_raw)
            code = code_raw.upper()
            sec  = securities.get(code)
            parsed.append({
                'row': i, 'date': date, 'code': code, 'type': typ,
                'quantity': qty, 'price': prc, 'brokerage': brok,
                'franking_pct': frank, 'notes': notes_raw,
                'security_id':  sec['id']   if sec else None,
                'security_name': sec['name'] if sec else None,
                'warning':      f"Security {code!r} not found — row will be skipped" if not sec else None,
            })
        except Exception as e:
            errors.append({'row': i, 'error': str(e)})
    return parsed, errors


# ── Generic flexible parser ────────────────────────────────────────────────────
#
# Accepts any CSV with separate columns for date, code, type, quantity, price.
# Handles varying column names across brokers.

def parse_generic_flex(content, securities):
    rows_raw = [{k.lower(): v for k, v in r.items()} for r in _read_rows(content)]
    parsed, errors = [], []
    for i, row in enumerate(rows_raw, 1):
        try:
            date_raw = _flex_get(row, 'date', 'trade date', 'transaction date', 'settlement date')
            code_raw = _flex_get(row, 'code', 'security', 'security code', 'asx code', 'ticker', 'symbol')
            type_raw = _flex_get(row, 'type', 'transaction type', 'trade type', 'action')
            qty_raw  = _flex_get(row, 'quantity', 'qty', 'units', 'volume', 'shares')
            prc_raw  = _flex_get(row, 'price', 'unit price', 'price ($)', 'trade price', 'unit price ($)')
            brok_raw = _flex_get(row, 'brokerage', 'brokerage ($)', 'commission', 'fees', 'fee',
                                  'brokerage incl. gst', 'brokerage (incl. gst)')
            frank_raw= _flex_get(row, 'franking%', 'franking %', 'franking pct', 'franking_pct')
            notes_raw= _flex_get(row, 'notes', 'description', 'details', 'comment', 'reference', 'name')

            if not date_raw or not code_raw or not type_raw:
                continue
            typ = _TYPE_MAP.get(type_raw.lower().strip())
            if not typ:
                continue
            qty  = _num(qty_raw)
            prc  = _num(prc_raw)
            brok = _num(brok_raw)
            frank= _num(frank_raw)
            if qty <= 0:
                continue
            date = _parse_date(date_raw)
            code = code_raw.upper()
            sec  = securities.get(code)
            parsed.append({
                'row': i, 'date': date, 'code': code, 'type': typ,
                'quantity': qty, 'price': prc, 'brokerage': brok,
                'franking_pct': frank, 'notes': notes_raw,
                'security_id':  sec['id']   if sec else None,
                'security_name': sec['name'] if sec else None,
                'warning':      f"Security {code!r} not found — row will be skipped" if not sec else None,
            })
        except Exception as e:
            errors.append({'row': i, 'error': str(e)})
    return parsed, errors


# ── sharetrack template ────────────────────────────────────────────────────────

def parse_template(content, securities):
    rows_raw = _read_rows(content)
    parsed, errors = [], []
    for i, row in enumerate(rows_raw, 1):
        try:
            code  = (row.get('Code') or row.get('code') or '').upper()
            typ   = (row.get('Type') or row.get('type') or '').strip().title()
            date  = _parse_date(row.get('Date') or row.get('date') or '')
            qty   = _num(row.get('Quantity') or row.get('quantity') or '0')
            prc   = _num(row.get('Price')    or row.get('price')    or '0')
            brok  = _num(row.get('Brokerage') or row.get('brokerage') or '0')
            frank = _num(row.get('Franking%') or row.get('franking%') or '0')
            notes = (row.get('Notes') or row.get('notes') or '').strip()
            if not code:
                raise ValueError("Code is required")
            if typ not in ('Buy', 'Sell', 'Dividend'):
                raise ValueError(f"Type must be Buy, Sell, or Dividend (got {typ!r})")
            if qty <= 0:
                raise ValueError("Quantity must be > 0")
            sec = securities.get(code)
            parsed.append({
                'row': i, 'date': date, 'code': code, 'type': typ,
                'quantity': qty, 'price': prc, 'brokerage': brok,
                'franking_pct': frank, 'notes': notes,
                'security_id':  sec['id']   if sec else None,
                'security_name': sec['name'] if sec else None,
                'warning':      f"Security {code!r} not found — row will be skipped" if not sec else None,
            })
        except Exception as e:
            errors.append({'row': i, 'error': str(e)})
    return parsed, errors


# ── Dispatch ───────────────────────────────────────────────────────────────────

FORMAT_LABELS = {
    'commsec_confirmations': 'CommSec Trade Confirmations',
    'selfwealth':            'SelfWealth Transaction History',
    'generic_flex':          'Generic (flexible columns)',
    'template':              'sharetrack Template',
    'unknown':               'sharetrack Template (fallback)',
}


def parse(content, securities, force_format=None):
    """
    Auto-detect format (or use force_format) and parse content.
    Returns (rows, errors, detected_format_label).
    """
    fmt = force_format or detect_format(content)
    if fmt in ('unknown', 'template'):
        rows, errors = parse_template(content, securities)
        fmt = 'template'
    elif fmt == 'commsec_confirmations':
        rows, errors = parse_commsec_confirmations(content, securities)
    elif fmt == 'selfwealth':
        rows, errors = parse_selfwealth(content, securities)
    else:
        rows, errors = parse_generic_flex(content, securities)
        fmt = 'generic_flex'
    return rows, errors, fmt
