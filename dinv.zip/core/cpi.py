# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Consumer price index for the CGT indexation method.

All groups, weighted average of eight capital cities, per quarter — the ATO table in the
Guide to capital gains tax / Personal investors guide appendix ("Consumer price index
(CPI)"), checked 27 Oct 2026. Indexation is frozen at the September 1999 quarter (68.7).
"""
from datetime import date
from decimal import Decimal, ROUND_HALF_UP

# year: (quarter ending 31 Mar, 30 Jun, 30 Sep, 31 Dec)
CPI = {
    1985: (37.9, 38.8, 39.7, 40.5),
    1986: (41.4, 42.1, 43.2, 44.4),
    1987: (45.3, 46.0, 46.8, 47.6),
    1988: (48.4, 49.3, 50.2, 51.2),
    1989: (51.7, 53.0, 54.2, 55.2),
    1990: (56.2, 57.1, 57.5, 59.0),
    1991: (58.9, 59.0, 59.3, 59.9),
    1992: (59.9, 59.7, 59.8, 60.1),
    1993: (60.6, 60.8, 61.1, 61.2),
    1994: (61.5, 61.9, 62.3, 62.8),
    1995: (63.8, 64.7, 65.5, 66.0),
    1996: (66.2, 66.7, 66.9, 67.0),
    1997: (67.1, 66.9, 66.6, 66.8),
    1998: (67.0, 67.4, 67.5, 67.8),
    1999: (67.8, 68.1, 68.7, None),
}
FROZEN = (1999, 2)          # September 1999 quarter


def _quarter(d):
    d = date.fromisoformat(d) if isinstance(d, str) else d
    return d.year, (d.month - 1) // 3


def cpi_for(d):
    """CPI for the quarter containing date d (capped at September 1999), or None if before 1985."""
    q = min(_quarter(d), FROZEN)
    row = CPI.get(q[0])
    return row[q[1]] if row else None


def indexation_factor(incurred, event):
    """
    CPI for the quarter of the CGT event (September 1999 at the latest) ÷ CPI for the quarter
    the cost was incurred, to 3 decimal places, a fourth decimal of 5 or more rounding up.
    1.0 if the cost was incurred after September 1999 or no CPI is known for it.
    """
    if _quarter(incurred) > FROZEN:
        return 1.0
    a, b = cpi_for(incurred), cpi_for(event)
    if not a or not b or b <= a:
        return 1.0
    return float((Decimal(str(b)) / Decimal(str(a))).quantize(Decimal('0.001'), rounding=ROUND_HALF_UP))
