# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Consumer price index for the CGT indexation method.

All groups, weighted average of eight capital cities, per quarter — the ATO table in the
Guide to capital gains tax / Personal investors guide appendix ("Consumer price index
(CPI)"), checked 27 Oct 2026. Indexation is frozen at the September 1999 quarter (68.7).
"""
from datetime import date
from decimal import Decimal, ROUND_HALF_UP

from . import cpi_2027

# year: (quarter ending 31 Mar, 30 Jun, 30 Sep, 31 Dec)
CPI = {
    1985: (37.9, 38.8, 39.7, 40.5),
    1986: (41.4, 42.1, 43.2, 44.4),
    1987: (45.3, 46.0, 46.8, 47.6),
    1988: (48.4, 49.3, 50.2, 51.2),
    1989: (51.7, 53.0, 54.2, 55.2),
    1990: (56.2, 57.1, 57.5, 59.0),
    1991: (58.9, 59.0, 59.3, 59.9),
    1992: (59.9, 59.7, 59.8, 60.1),
    1993: (60.6, 60.8, 61.1, 61.2),
    1994: (61.5, 61.9, 62.3, 62.8),
    1995: (63.8, 64.7, 65.5, 66.0),
    1996: (66.2, 66.7, 66.9, 67.0),
    1997: (67.1, 66.9, 66.6, 66.8),
    1998: (67.0, 67.4, 67.5, 67.8),
    1999: (67.8, 68.1, 68.7, None),
}
FROZEN = (1999, 2)          # September 1999 quarter


def _quarter(d):
    d = date.fromisoformat(d) if isinstance(d, str) else d
    return d.year, (d.month - 1) // 3


def cpi_for(d):
    """CPI for the quarter containing date d (capped at September 1999), or None if before 1985."""
    q = min(_quarter(d), FROZEN)
    row = CPI.get(q[0])
    return row[q[1]] if row else None


def indexation_factor(incurred, event):
    """
    CPI for the quarter of the CGT event (September 1999 at the latest) ÷ CPI for the quarter
    the cost was incurred, to 3 decimal places, a fourth decimal of 5 or more rounding up.
    1.0 if the cost was incurred after September 1999 or no CPI is known for it.
    """
    if _quarter(incurred) > FROZEN:
        return 1.0
    a, b = cpi_for(incurred), cpi_for(event)
    if not a or not b or b <= a:
        return 1.0
    return float((Decimal(str(b)) / Decimal(str(a))).quantize(Decimal('0.001'), rounding=ROUND_HALF_UP))


# ── From 1 July 2027 (Act No. 49 of 2026) ─────────────────────────────────────
# Individuals and trusts index the cost base again for CGT events from 1 July 2027 (s 110-36(1A)),
# from the quarter the expenditure was incurred — for assets held at 30 June 2027, the deemed
# reacquisition on 1 July 2027 (s 112-155(2)(b)), so the Sep 2027 quarter — to the quarter of the
# CGT event (s 960-275(1B)). Same rounding (s 960-275(5)); no indexation at a factor of 1 or less
# (s 960-270(2)). Index numbers: core/cpi_2027.py, kept up to date by tools/update_cpi.py.

REFORM_QUARTER = '2027-Q3'      # quarter containing 1 July 2027


def quarter_key(d):
    """'2027-Q3' for any date in July–September 2027."""
    y, q = _quarter(d)
    return f'{y}-Q{q + 1}'


def latest_quarter_2027(quarters=None):
    """The latest quarter in the post-2027 CPI table, or None."""
    qs = cpi_2027.QUARTERS if quarters is None else quarters
    return max(qs) if qs else None


def indexation_factor_2027(incurred, event, quarters=None):
    """
    Indexation factor under s 960-275(1B) for expenditure incurred on `incurred` (dates before
    1 July 2027 count from the Sep 2027 quarter — the deemed reacquisition) and a CGT event on
    `event`. Returns (factor, provisional):
      factor       CPI(event quarter) ÷ CPI(incurred quarter) to 3 decimals, half up; 1.0 when that
                   is 1 or less or the quarters are the same
      provisional  True when a quarter's CPI isn't in the table yet — the event quarter falls back
                   to the latest published quarter; an unpublished incurred quarter gives 1.0
    quarters: {quarter: (index, added)}, default the table in core/cpi_2027.py.
    """
    qs = cpi_2027.QUARTERS if quarters is None else quarters
    a = max(quarter_key(incurred), REFORM_QUARTER)
    b = quarter_key(event)
    if b <= a:
        return 1.0, False
    latest = latest_quarter_2027(qs)
    provisional = latest is None or b > latest
    if provisional:
        b = latest
    if a not in qs or b is None or b <= a:
        return 1.0, provisional
    f = (Decimal(str(qs[b][0])) / Decimal(str(qs[a][0]))).quantize(Decimal('0.001'), rounding=ROUND_HALF_UP)
    return (float(f) if f > 1 else 1.0), provisional
