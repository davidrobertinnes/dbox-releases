"""
Source documents (contract notes, dividend statements, company notices) attached to
purchases, sales, dividends and corporate actions. Files are stored in the .dinv file
itself, so a copy or backup of the portfolio carries them.

An attachment belongs to one record: source_type is 'parcel', 'sale', 'dividend' or
'action', source_id the record's id. Deleting the record deletes its attachments (SQL
triggers in core/database.py). Parcels and sales made by other records (DRP parcels,
rights and bonus parcels, demerger and takeover parcels, takeover disposals, a joint
holder's death) take no attachments: attach to the dividend or corporate action instead.
That keeps every attachment on a row of the full export, so it survives a re-import.

Licensing: adding attachments is meant to be a paid feature once Investments has
licensing, free for life for early adopters (everyone using it before paid licensing
starts, and Doug). Until then can_add() allows everyone. Opening, exporting and deleting
are never restricted: a user's documents are never locked away from them.
"""

import mimetypes
import os

from .database import get_connection

SOURCE_TYPES = ('parcel', 'sale', 'dividend', 'action')
MAX_BYTES = 10 * 1024 * 1024    # per file

# Parcels and sales that are made by another record (see the module docstring)
_DERIVED_PARCELS = """
    SELECT drp_parcel_id FROM dividends WHERE drp_parcel_id IS NOT NULL
    UNION SELECT parcel_id FROM corporate_actions WHERE parcel_id IS NOT NULL
    UNION SELECT new_parcel_id FROM demerger_parcels
    UNION SELECT new_parcel_id FROM takeover_parcels
    UNION SELECT own_parcel_id FROM death_parcels
    UNION SELECT inherited_parcel_id FROM death_parcels"""
_DERIVED_SALE_KINDS = ('takeover', 'transfer')
_TABLE = {'parcel': 'parcels', 'sale': 'sales', 'dividend': 'dividends', 'action': 'corporate_actions'}


def can_add(db_path):
    """Whether this installation may add attachments (see Licensing in the module docstring)."""
    return True


def mime_type(filename):
    mt, _ = mimetypes.guess_type(filename or '')
    return mt or 'application/octet-stream'


def _clean_name(filename):
    name = os.path.basename((filename or '').replace('\\', '/')).strip()
    return name or 'document'


def _check_source(conn, source_type, source_id):
    if source_type not in SOURCE_TYPES:
        raise ValueError(f"Attachments can't be added to '{source_type}'")
    row = conn.execute(f"SELECT * FROM {_TABLE[source_type]} WHERE id = ?", (source_id,)).fetchone()
    if not row:
        raise ValueError("That record doesn't exist any more")
    if source_type == 'parcel' and conn.execute(
            f"SELECT 1 FROM ({_DERIVED_PARCELS}) WHERE drp_parcel_id = ?", (source_id,)).fetchone():
        raise ValueError("These shares came from a dividend or corporate action: attach the "
                         "document to that instead")
    if source_type == 'sale' and row['kind'] in _DERIVED_SALE_KINDS:
        raise ValueError("This disposal is part of a corporate action or a joint holder's death: "
                         "attach the document there instead")


def add(db_path, source_type, source_id, filename, data, description='', uploaded_at=None,
        conn=None):
    """Store a file against a record. Returns the attachment id. With conn, the caller commits."""
    if len(data) > MAX_BYTES:
        raise ValueError(f"{_clean_name(filename)} is over the {MAX_BYTES // (1024 * 1024)} MB limit")
    if not data:
        raise ValueError(f"{_clean_name(filename)} is empty")
    own = conn is None
    conn = conn or get_connection(db_path)
    try:
        _check_source(conn, source_type, int(source_id))
        name = _clean_name(filename)
        cols = "source_type, source_id, filename, mime_type, file_size, file_data, description"
        vals = [source_type, int(source_id), name, mime_type(name), len(data), data, description or '']
        if uploaded_at:
            cols += ", uploaded_at"
            vals.append(uploaded_at)
        att_id = conn.execute(f"INSERT INTO attachments ({cols}) VALUES ({','.join('?' * len(vals))})",
                              vals).lastrowid
        if own:
            conn.commit()
        return att_id
    finally:
        if own:
            conn.close()


def list_for(db_path, source_type, source_id):
    """Attachments of one record, without the file data."""
    conn = get_connection(db_path)
    try:
        return [dict(r) for r in conn.execute(
            """SELECT id, source_type, source_id, filename, mime_type, file_size, description, uploaded_at
               FROM attachments WHERE source_type = ? AND source_id = ? ORDER BY uploaded_at, id""",
            (source_type, source_id))]
    finally:
        conn.close()


def get(db_path, att_id):
    """One attachment with its file data, or None."""
    conn = get_connection(db_path)
    try:
        r = conn.execute("SELECT * FROM attachments WHERE id = ?", (att_id,)).fetchone()
        return dict(r) if r else None
    finally:
        conn.close()


def delete(db_path, att_id):
    conn = get_connection(db_path)
    try:
        conn.execute("DELETE FROM attachments WHERE id = ?", (att_id,))
        conn.commit()
    finally:
        conn.close()


def counts(db_path, source_type):
    """{source_id: number of attachments} for every record of a type that has any."""
    conn = get_connection(db_path)
    try:
        return {r[0]: r[1] for r in conn.execute(
            "SELECT source_id, COUNT(*) FROM attachments WHERE source_type = ? GROUP BY source_id",
            (source_type,))}
    finally:
        conn.close()


def derived_parcel_ids(db_path):
    """Parcels made by another record, which take no attachments."""
    conn = get_connection(db_path)
    try:
        return {r[0] for r in conn.execute(_DERIVED_PARCELS)}
    finally:
        conn.close()


def keys_by_source(conn):
    """{(source_type, source_id): 'A1;A2'}: the keys a full export writes in its Attachments column."""
    out = {}
    for r in conn.execute("SELECT id, source_type, source_id FROM attachments ORDER BY uploaded_at, id"):
        k = (r['source_type'], r['source_id'])
        out[k] = f"{out[k]};A{r['id']}" if k in out else f"A{r['id']}"
    return out


def totals(db_path):
    """{'count', 'bytes'} over the whole portfolio."""
    conn = get_connection(db_path)
    try:
        n, size = conn.execute("SELECT COUNT(*), COALESCE(SUM(file_size), 0) FROM attachments").fetchone()
        return {'count': n, 'bytes': size}
    finally:
        conn.close()


def from_db(db_path):
    """A source for full_export: attachment key 'A<id>' → its row in db_path (with file data)."""
    def source(key):
        if not key.startswith('A') or not key[1:].isdigit():
            return None
        return get(db_path, int(key[1:]))
    return source
