# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Automatic backups of the open portfolio.

On by default. A backup is a complete copy of the portfolio, made with SQLite's backup
function so it's never half-written even while the app is using the file, saved as
<folder>/<portfolio>_auto_<YYYYMMDD-HHMMSS>.dinv — an ordinary portfolio file that opens
as it is. The newest `keep` copies of each portfolio are kept.

When: once a day while the app is open, if the portfolio has changed since the last
backup (invest.py), and when the app quits, restarts for an update or switches to another
portfolio, if it has changed (web/server.py). A copy that turns out identical to the last
one is thrown away, so opening a portfolio without changing it adds nothing.

The settings belong to this install, not the portfolio: invest.conf, next to the port.
"""

import glob
import hashlib
import json
import os
import sqlite3
import time
from datetime import datetime

DEFAULT_KEEP = 10
DAY = 24 * 3600
last_error = None        # the last automatic backup's failure, shown in Settings


def default_dir():
    """Documents/Dogbox Backups — the folder Dogbox Accounting suggests too."""
    home = os.path.expanduser('~')
    docs = os.path.join(home, 'Documents')
    return os.path.join(docs if os.path.isdir(docs) else home, 'Dogbox Backups')


def _read_conf(conf_path):
    try:
        with open(conf_path, encoding='utf-8') as f:
            conf = json.load(f)
        return conf if isinstance(conf, dict) else {}
    except Exception:
        return {}


def load_settings(conf_path):
    conf = _read_conf(conf_path)
    try:
        keep = min(100, max(1, int(conf.get('backup_keep', DEFAULT_KEEP))))
    except (TypeError, ValueError):
        keep = DEFAULT_KEEP
    folder = (conf.get('backup_dir') or '').strip()
    return {'enabled': conf.get('backup_enabled', True) is not False,
            'dir': folder or default_dir(), 'custom_dir': bool(folder), 'keep': keep}


def save_settings(conf_path, enabled, folder, keep):
    """Save the backup settings, keeping the rest of invest.conf (the port)."""
    keep = int(keep)
    if not 1 <= keep <= 100:
        raise ValueError("Keep from 1 to 100 backups")
    folder = (folder or '').strip()
    if folder and os.path.normcase(os.path.abspath(folder)) == os.path.normcase(default_dir()):
        folder = ''
    if folder and not os.path.isabs(folder):
        raise ValueError("Enter the backup folder's full path, e.g. C:\\Users\\you\\OneDrive\\Backups")
    conf = _read_conf(conf_path)
    conf['backup_enabled'] = bool(enabled)
    conf['backup_keep'] = keep
    if folder:
        conf['backup_dir'] = folder
    else:
        conf.pop('backup_dir', None)
    with open(conf_path, 'w', encoding='utf-8') as f:
        json.dump(conf, f, indent=2)


def backups(db_path, folder):
    """This portfolio's backups in the folder, oldest first."""
    stem = glob.escape(os.path.splitext(os.path.basename(db_path))[0])
    return sorted(glob.glob(os.path.join(glob.escape(folder), f'{stem}_auto_*.dinv')))


def made_at(path):
    """When a backup was made, from its name (its file time records the last check)."""
    try:
        return datetime.strptime(os.path.basename(path)[-20:-5], '%Y%m%d-%H%M%S')
    except ValueError:
        return datetime.fromtimestamp(os.path.getmtime(path))


def _last_changed(db_path):
    """When the portfolio was last written: the file or its write-ahead log."""
    times = [os.path.getmtime(p) for p in (db_path, db_path + '-wal') if os.path.exists(p)]
    return max(times) if times else 0


def _digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.digest()


def _copy(db_path, dest):
    tmp = dest + '.part'
    src = sqlite3.connect(db_path, timeout=30)
    try:
        dst = sqlite3.connect(tmp)
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()
    os.replace(tmp, dest)


def backup(db_path, conf_path, force=False, min_age=0):
    """Back up the portfolio. force: now, even if unchanged or turned off (Back up now).
    Otherwise only when turned on, changed since the last backup, and that backup is at
    least min_age seconds old. Returns the new backup's path, or None if none was needed."""
    global last_error
    s = load_settings(conf_path)
    if not (s['enabled'] or force) or not db_path or not os.path.exists(db_path):
        return None
    folder = s['dir']
    try:
        os.makedirs(folder, exist_ok=True)
        existing = backups(db_path, folder)
        last = existing[-1] if existing else None
        if last and not force:
            checked = os.path.getmtime(last)
            if _last_changed(db_path) <= checked or time.time() - checked < min_age:
                return None
        stem = os.path.splitext(os.path.basename(db_path))[0]
        stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        dest = os.path.join(folder, f'{stem}_auto_{stamp}.dinv')
        if os.path.exists(dest):                 # two in the same second
            time.sleep(1)
            return backup(db_path, conf_path, force, min_age)
        _copy(db_path, dest)
        if last and not force and _digest(last) == _digest(dest):
            os.remove(dest)                      # nothing changed: keep the last one,
            os.utime(last)                       # marked as checked now
            return None
        for old in backups(db_path, folder)[:-s['keep']]:
            try:
                os.remove(old)
            except OSError:
                pass
        last_error = None
        return dest
    except Exception as e:
        last_error = f"{type(e).__name__}: {e}"
        if force:
            raise
        return None


def status(db_path, conf_path):
    s = load_settings(conf_path)
    files = backups(db_path, s['dir']) if db_path and os.path.isdir(s['dir']) else []
    last = files[-1] if files else None
    return {**s, 'default_dir': default_dir(), 'count': len(files), 'error': last_error,
            'last': {'name': os.path.basename(last), 'path': last,
                     'made': made_at(last).isoformat(timespec='seconds')} if last else None}
