# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
sharetrack — Live price fetching via Yahoo Finance (direct HTTP, no external dependencies)
"""
import json
import datetime
import urllib.request
import urllib.parse
from .database import get_connection

_SUFFIX  = {'ASX': '.AX', 'NYSE': '', 'NASDAQ': '', 'LSE': '.L', 'TSX': '.TO', 'OTHER': ''}
_HEADERS = {'User-Agent': 'Mozilla/5.0'}
_TIMEOUT = 10


def _ticker(code, exchange):
    return f"{code}{_SUFFIX.get(exchange, '')}"


_SPARK_BATCH = 20   # Yahoo Finance spark API rejects batches larger than 20


def fetch_prices(db_path, securities):
    """
    Fetch latest closing prices from Yahoo Finance. Chunked into batches of
    _SPARK_BATCH to stay within the spark API limit. Persists to DB.
    Returns {security_id: price}.
    """
    if not securities:
        return {}

    ticker_to_id = {_ticker(s['code'], s['exchange']): s['id'] for s in securities}
    tickers      = list(ticker_to_id)
    results      = {}

    for i in range(0, len(tickers), _SPARK_BATCH):
        batch   = tickers[i:i + _SPARK_BATCH]
        symbols = ','.join(batch)
        url     = ('https://query1.finance.yahoo.com/v7/finance/spark'
                   f'?symbols={urllib.parse.quote(symbols)}&range=5d&interval=1d')
        try:
            req = urllib.request.Request(url, headers=_HEADERS)
            with urllib.request.urlopen(req, timeout=_TIMEOUT) as r:
                data = json.loads(r.read())
            for item in data.get('spark', {}).get('result', []) or []:
                sym    = item.get('symbol', '')
                resp   = (item.get('response') or [{}])[0]
                closes = resp.get('indicators', {}).get('quote', [{}])[0].get('close', [])
                last   = next((x for x in reversed(closes) if x is not None), None)
                if last is not None and sym in ticker_to_id:
                    results[ticker_to_id[sym]] = float(last)
        except Exception:
            pass

    if results:
        conn = get_connection(db_path)
        try:
            for sid, price in results.items():
                conn.execute(
                    """INSERT OR REPLACE INTO prices (security_id, price, fetched_at)
                       VALUES (?, ?, datetime('now','localtime'))""",
                    (sid, price))
            conn.commit()
        finally:
            conn.close()

    return results


_history_cache: dict = {}


def get_price_history(db_path, security_id, period='6mo'):
    """
    Fetch daily closing prices for one security. Cached for 1 hour.
    period: one of 1mo, 3mo, 6mo, 1y, 2y, 5y.
    """
    cache_key = (db_path, security_id)
    now    = datetime.datetime.now()
    cached = _history_cache.get(cache_key)
    if cached and (now - cached['fetched']).total_seconds() < 3600:
        return cached['data']

    conn = get_connection(db_path)
    try:
        sec = conn.execute(
            "SELECT code, exchange FROM securities WHERE id = ?", (security_id,)
        ).fetchone()
        if not sec:
            return []
    finally:
        conn.close()

    sym = _ticker(sec['code'], sec['exchange'])
    url = (f'https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(sym)}'
           f'?interval=1d&range={period}')
    try:
        req = urllib.request.Request(url, headers=_HEADERS)
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as r:
            data = json.loads(r.read())
        result = data['chart']['result'][0]
        ts_list = result['timestamp']
        cl_list = result['indicators']['quote'][0]['close']
        history = [
            {'date': str(datetime.date.fromtimestamp(ts)), 'price': float(c)}
            for ts, c in zip(ts_list, cl_list) if c is not None
        ]
        _history_cache[cache_key] = {'data': history, 'fetched': now}
        return history
    except Exception:
        return []


def get_prices(db_path):
    """Return {security_id: {price, fetched_at}} from the cached prices table."""
    conn = get_connection(db_path)
    try:
        return {
            r['security_id']: {'price': r['price'], 'fetched_at': r['fetched_at']}
            for r in conn.execute("SELECT * FROM prices").fetchall()
        }
    finally:
        conn.close()


_index_cache: dict = {}


def get_index_history(ticker, period='1y'):
    """Fetch daily closing prices for a market index by raw Yahoo Finance ticker (e.g. '^AORD')."""
    cache_key = (ticker, period)
    now = datetime.datetime.now()
    cached = _index_cache.get(cache_key)
    if cached and (now - cached['fetched']).total_seconds() < 3600:
        return cached['data']
    url = (f'https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(ticker)}'
           f'?interval=1d&range={period}')
    try:
        req = urllib.request.Request(url, headers=_HEADERS)
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as r:
            data = json.loads(r.read())
        result = data['chart']['result'][0]
        ts_list = result['timestamp']
        cl_list = result['indicators']['quote'][0]['close']
        history = [
            {'date': str(datetime.date.fromtimestamp(ts)), 'price': float(c)}
            for ts, c in zip(ts_list, cl_list) if c is not None
        ]
        _index_cache[cache_key] = {'data': history, 'fetched': now}
        return history
    except Exception:
        return []
