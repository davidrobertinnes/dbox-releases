# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
PDF generation for sharetrack tax summary.
Uses reportlab (pure Python, no system dependencies).
"""
import io
from datetime import date as _date

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.enums import TA_LEFT, TA_RIGHT, TA_CENTER
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle,
    Paragraph, Spacer, HRFlowable, KeepTogether,
)

# ── Palette (matches CSS variables) ───────────────────────────────────────────
_INK    = HexColor('#1a1a2e')
_INK2   = HexColor('#4a4a6a')
_INK3   = HexColor('#9898b8')
_RED    = HexColor('#e63946')
_AMBER  = HexColor('#d97706')
_GREEN  = HexColor('#2dc653')
_ACCENT = HexColor('#6c63ff')
_SURF   = HexColor('#f5f5fa')
_BORDER = HexColor('#e0e0ee')

PAGE_W, PAGE_H = A4
LM = RM = 20 * mm
TM = BM = 18 * mm
BODY_W = PAGE_W - LM - RM
COL_VAL = 42 * mm
COL_LBL = BODY_W - COL_VAL


def _sty(name, **kw):
    defaults = dict(fontName='Helvetica', fontSize=9, textColor=_INK,
                    leading=13, spaceAfter=0, spaceBefore=0)
    defaults.update(kw)
    return ParagraphStyle(name, **defaults)


def _cur(v):
    """Format as currency string."""
    return f'${v:,.2f}'


def _row_data(label, value_str, ato_ref=None, bold=False, indent=False,
              value_color=None, label_color=None):
    """Return one [label_para, value_para] list for a table row."""
    lbl_font = 'Helvetica-Bold' if bold else 'Helvetica'
    lbl_col  = label_color or _INK
    val_col  = value_color or _INK
    lbl_text = ('&nbsp;&nbsp;&nbsp;&nbsp;' if indent else '') + label
    if ato_ref:
        lbl_text += f' <font name="Helvetica-Bold" color="#9898b8" size="7"> {ato_ref}</font>'
    lbl_para = Paragraph(lbl_text, _sty('rl', fontName=lbl_font, textColor=lbl_col, fontSize=9, leading=12))
    val_para = Paragraph(value_str, _sty('rv', fontName='Helvetica-Bold' if bold else 'Helvetica',
                                         textColor=val_col, fontSize=9, leading=12, alignment=TA_RIGHT))
    return [lbl_para, val_para]


def _section_hdr(title, ato_item=None):
    txt = f'<b>{title}</b>'
    if ato_item:
        txt += f'<font name="Helvetica" color="#9898b8" size="8">  ·  {ato_item}</font>'
    return Paragraph(txt, _sty('sh', fontName='Helvetica-Bold', fontSize=10,
                                textColor=_INK, spaceBefore=10, spaceAfter=4))


def _subsection(title):
    return Paragraph(title, _sty('ss', fontName='Helvetica', fontSize=8.5,
                                  textColor=_INK2, spaceBefore=7, spaceAfter=2))


def _note(text):
    return Paragraph(text, _sty('note', fontName='Helvetica-Oblique', fontSize=7.5,
                                  textColor=_INK3, spaceBefore=3, spaceAfter=1))


def _alert(text, kind='red'):
    col = _RED if kind == 'red' else _AMBER
    return Paragraph('⚠  ' + text, _sty('alert', fontName='Helvetica', fontSize=8,
                                          textColor=col, spaceBefore=5, spaceAfter=2,
                                          leftIndent=4))


def _hr():
    return HRFlowable(width='100%', thickness=0.5, color=_BORDER, spaceAfter=4, spaceBefore=4)


def _build_table(rows, bg_total=None):
    """Wrap rows in a two-column Table."""
    tbl = Table(rows, colWidths=[COL_LBL, COL_VAL])
    style = [
        ('ALIGN',       (1, 0), (1, -1), 'RIGHT'),
        ('VALIGN',      (0, 0), (-1, -1), 'MIDDLE'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('RIGHTPADDING', (0, 0), (-1, -1), 0),
        ('TOPPADDING',  (0, 0), (-1, -1), 2),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
    ]
    tbl.setStyle(TableStyle(style))
    return tbl


def _summary_table(rows):
    """Two-column summary table with totals row highlighted."""
    tbl = Table(rows, colWidths=[COL_LBL, COL_VAL])
    style = [
        ('ALIGN',       (1, 0), (1, -1), 'RIGHT'),
        ('VALIGN',      (0, 0), (-1, -1), 'MIDDLE'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('RIGHTPADDING', (0, 0), (-1, -1), 0),
        ('TOPPADDING',  (0, 0), (-1, -1), 3),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
        ('LINEABOVE',   (0, -1), (-1, -1), 0.5, _BORDER),
    ]
    tbl.setStyle(TableStyle(style))
    return tbl


# ── Main entry point ───────────────────────────────────────────────────────────

def build_tax_summary_pdf(fy, divs, cgt_rows, roc_rows, fyc, inc, settings):
    """
    Build a PDF tax summary and return BytesIO.

    divs:     list of dividend dicts (already filtered to FY)
    cgt_rows: from get_cgt_summary(fy)
    roc_rows: from get_roc_cgt(fy)
    fyc:      from compute_fy_cgt(fy) — Item 18 figures (ATO method statement)
    inc:      from compute_fy_income(fy) — Item 11 figures
    settings: from get_settings()
    """
    buf = io.BytesIO()

    entity_type  = settings.get('entity_type', 'individual')
    entity_label = {
        'individual':        'Individual',
        'smsf_accumulation': 'SMSF (Accumulation Phase)',
        'smsf_pension':      'SMSF (Pension Phase)',
        'company':           'Company',
    }.get(entity_type, 'Individual')
    disc_label   = {'individual': '50%', 'smsf_accumulation': '1/3',
                    'smsf_pension': 'Fully exempt', 'company': 'None'}.get(entity_type, '50%')
    is_exempt    = entity_type == 'smsf_pension'
    carryforward = fyc['carry_forward']
    owner        = settings.get('owner_name', '')
    share        = settings.get('ownership_pct')
    today_str    = _date.today().strftime('%d/%m/%Y')

    # ── Calculations (mirrors CSV route) ───────────────────────────────────────
    ato_11j          = inc['unfranked']
    ato_11k          = inc['franked']
    ato_11l          = inc['credits_claimable']
    frank_ineligible = inc['credits_ineligible']
    frank_unknown    = inc['credits_unverified']
    div_assessable   = inc['assessable']

    short_gains      = fyc['short_gains']
    short_losses     = fyc['short_losses']
    disc_gross_gains = fyc['disc_gains']
    disc_gross_loss  = fyc['disc_losses']
    roc_gross        = fyc['roc_gross']
    ato_18a          = fyc['net_capital_gain']
    ato_18h          = fyc['total_gains']
    total_assessable = div_assessable + ato_18a

    # ── Doc setup ──────────────────────────────────────────────────────────────
    doc = SimpleDocTemplate(
        buf,
        pagesize=A4,
        leftMargin=LM, rightMargin=RM,
        topMargin=TM, bottomMargin=BM,
        title=f'FY{fy} Tax Summary',
        author='sharetrack',
    )

    story = []

    # ── Page header ────────────────────────────────────────────────────────────
    hdr_rows = [[
        Paragraph(f'<b>FY Tax Summary — Year Ending 30 June {fy}</b>',
                  _sty('h1', fontName='Helvetica-Bold', fontSize=14, textColor=_INK)),
        Paragraph(f'<font color="#9898b8">Generated: {today_str}</font>',
                  _sty('hd', fontSize=8.5, textColor=_INK3, alignment=TA_RIGHT)),
    ],[
        Paragraph((f'{owner}  ·  ' if owner else '') + f'Entity: {entity_label}  ·  '
                  f'FY{fy} (1 Jul {fy-1} – 30 Jun {fy})'
                  + (f'  ·  Your {share}% share of jointly held shares' if share else
                     '  ·  Your share of jointly held holdings' if settings.get('_joint_holdings') else ''),
                  _sty('h2', fontSize=9, textColor=_INK2)),
        Paragraph('Summary only — verify with your accountant before lodging.',
                  _sty('disc', fontSize=7.5, textColor=_AMBER, alignment=TA_RIGHT,
                       fontName='Helvetica-Oblique')),
    ]]
    hdr_tbl = Table(hdr_rows, colWidths=[BODY_W * 0.62, BODY_W * 0.38])
    hdr_tbl.setStyle(TableStyle([
        ('VALIGN',      (0, 0), (-1, -1), 'MIDDLE'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('RIGHTPADDING', (0, 0), (-1, -1), 0),
        ('TOPPADDING',  (0, 0), (-1, -1), 2),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
    ]))
    story.append(hdr_tbl)
    story.append(HRFlowable(width='100%', thickness=1, color=_ACCENT, spaceAfter=10, spaceBefore=6))

    # ── Section 1: Dividend Income ─────────────────────────────────────────────
    story.append(_section_hdr('Dividend Income', 'Individual Tax Return — Item 11'))
    story.append(_hr())

    div_rows_tbl = []
    div_rows_tbl.append(_row_data('Unfranked dividend amount', _cur(ato_11j), ato_ref='11J'))
    div_rows_tbl.append(_row_data('Franked dividend amount (net received)', _cur(ato_11k), ato_ref='11K'))
    div_rows_tbl.append(_row_data('Franking credits (claimable tax offset)', _cur(ato_11l),
                                   ato_ref='11L', value_color=_ACCENT))
    if div_rows_tbl:
        story.append(_build_table(div_rows_tbl))

    story.append(_hr())
    story.append(_build_table([
        _row_data('Total assessable dividend income (11J + 11K + 11L)',
                  _cur(div_assessable), bold=True)
    ]))
    story.append(_note('Assessable income = net dividends + eligible franking credits (grossed-up). '
                       'Franking credits are declared separately as a tax offset (Item 11L).'))

    if frank_ineligible > 0:
        story.append(_alert(
            f'{_cur(frank_ineligible)} in franking credits excluded from 11L — '
            '45-day holding period rule not satisfied. Review flagged dividends.', 'red'))
    if frank_unknown > 0:
        story.append(_alert(
            f'{_cur(frank_unknown)} in franking credits are unverified — '
            'add ex-dividend dates to confirm 45-day eligibility. Excluded from 11L until verified.', 'amber'))
    if inc['small_shareholder_exempt'] and inc['credits_total'] > 0:
        story.append(_note('Small shareholder exemption applies — total franking credits are $5,000 or less, '
                           'so the 45-day holding period rule does not need to be met.'))
    if inc['missing_credit_count']:
        story.append(_alert(
            f"{inc['missing_credit_count']} franked dividend(s) have no franking credit amount — "
            'enter it from the dividend statement.', 'amber'))
    if not divs:
        story.append(_note('No dividends recorded for this financial year.'))

    # ── Section 2: Capital Gains ───────────────────────────────────────────────
    story.append(Spacer(1, 6))
    story.append(_section_hdr('Capital Gains', 'Individual Tax Return — Item 18'))
    story.append(_hr())

    if not cgt_rows and not roc_rows:
        story.append(Paragraph('No disposals recorded for this financial year.',
                                _sty('empty', fontName='Helvetica-Oblique', textColor=_INK3)))
    else:
        cgt_block = []

        rows = []
        if short_gains > 0:
            rows.append(_row_data('Gains — no discount (held under 12 months, or indexed)', _cur(short_gains), indent=True))
        if disc_gross_gains > 0:
            rows.append(_row_data('Gains — held 12 months or more (discount-eligible)', _cur(disc_gross_gains), indent=True))
        if roc_gross > 0:
            rows.append(_row_data('Return of capital — cost base exceeded', _cur(roc_gross), indent=True))
        rows.append(_row_data('Total current year capital gains (before discount/losses)',
                              _cur(ato_18h), ato_ref='18H'))
        cgt_block.append(_build_table(rows))

        rows = []
        if is_exempt:
            rows.append(_row_data('Less: exempt — pension phase (capital losses disregarded)',
                                  f"({_cur(fyc['exempt_amount'])})", indent=True, value_color=_GREEN))
        if short_losses + disc_gross_loss > 0 and not is_exempt:
            rows.append(_row_data('Less: current year capital losses',
                                  f"({_cur(fyc['current_losses_applied'])})", indent=True, value_color=_RED))
        if carryforward > 0 and not is_exempt:
            used = fyc['prior_losses_applied']
            rows.append(_row_data('Less: prior year losses applied',
                                  f'({_cur(used)})' if used > 0 else '—',
                                  indent=True, value_color=_RED if used > 0 else _INK3))
        if not is_exempt and fyc['discount_applied'] > 0:
            rows.append(_row_data(f'Less: {disc_label} CGT discount (applied after losses)',
                                  f"({_cur(fyc['discount_applied'])})", indent=True, value_color=_RED))
        if rows:
            cgt_block.append(_build_table(rows))

        story.extend(cgt_block)
        story.append(Spacer(1, 4))
        story.append(_hr())

        story.append(_build_table([
            _row_data('Net capital gain (assessable)', _cur(ato_18a), ato_ref='18A',
                      bold=True, value_color=_INK if ato_18a > 0 else _INK3),
        ]))
        if fyc['carry_forward_remaining'] > 0:
            story.append(_build_table([
                _row_data('Net capital losses carried forward to later income years',
                          _cur(fyc['carry_forward_remaining']), ato_ref='18V'),
            ]))
        story.append(_note('Capital losses are applied before the CGT discount, which applies only '
                           'to discount-eligible gains remaining after losses (ATO method).'))

    # ── Section 3: Division 296 (SMSF accumulation only, FY2027+) ─────────────
    if entity_type == 'smsf_accumulation' and fy >= 2027:
        inclusion_pct    = {2027: 20, 2028: 40, 2029: 60}.get(fy, 80)
        inclusion_factor = inclusion_pct / 100
        total_net_divs   = ato_11j + ato_11k
        net_cg_gross     = fyc['total_gains'] - fyc['total_losses']
        div296_cg        = max(0.0, net_cg_gross) * inclusion_factor
        div296_earnings  = total_net_divs + div296_cg

        story.append(Spacer(1, 6))
        story.append(_section_hdr('Division 296 — Additional Super Tax', 'Effective 1 July 2026'))
        story.append(_hr())
        story.append(_alert(
            f'Division 296 applies to SMSF members with Total Superannuation Balance (TSB) over $3M. '
            f'Additional 15% tax on earnings for TSB $3M–$10M; 25% for TSB over $10M. '
            f'The ATO assesses actual liability — provide these figures to your accountant or SMSF administrator.',
            'amber'))
        story.append(Spacer(1, 4))
        div296_rows = [
            _row_data('Dividend income (included at 100%)', _cur(total_net_divs)),
            _row_data('Net realised capital gains (gross, before 1/3 fund discount)',
                      _cur(max(0.0, net_cg_gross))),
            _row_data(f'Capital gains inclusion rate FY{fy} (transitional)',
                      f'{inclusion_pct}%'),
            _row_data('Capital gains for Division 296 purposes',
                      _cur(div296_cg), indent=True),
        ]
        story.append(_build_table(div296_rows))
        story.append(_hr())
        story.append(_build_table([
            _row_data('Total Division 296 earnings', _cur(div296_earnings), bold=True)
        ]))
        story.append(_note(
            f'Inclusion rates: 20% FY2027 · 40% FY2028 · 60% FY2029 · 80% FY2030+. '
            f'Actual liability depends on your Total Superannuation Balance across all funds.'))

    # ── Section 4: Tax Position Summary ───────────────────────────────────────
    story.append(Spacer(1, 6))
    story.append(_section_hdr('Tax Position Summary'))
    story.append(_hr())

    sum_rows = [
        _row_data('Assessable dividend income', _cur(div_assessable)),
        _row_data('Net capital gain (Item 18A)', _cur(ato_18a)),
        _row_data('Total assessable investment income', _cur(total_assessable), bold=True),
    ]
    if ato_11l > 0:
        sum_rows.append(_row_data('Franking credit tax offset (Item 11L)',
                                   _cur(ato_11l), value_color=_ACCENT))
    story.append(_summary_table(sum_rows))

    if ato_11l > 0:
        story.append(_note('Franking credits reduce tax payable — declare as a tax offset in your return, not as income.'))

    # ── Footer ─────────────────────────────────────────────────────────────────
    story.append(Spacer(1, 14))
    story.append(HRFlowable(width='100%', thickness=0.5, color=_BORDER, spaceAfter=5))
    story.append(Paragraph(
        f'Dogbox Investments  ·  FY{fy} Tax Summary  ·  Generated {today_str}  ·  This is not tax advice.',
        _sty('ft', fontSize=7.5, textColor=_INK3, alignment=TA_CENTER)))

    doc.build(story)
    buf.seek(0)
    return buf
