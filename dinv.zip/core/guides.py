# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
User guides — the one source for the in-app Help page and the PDF guides.

Each guide is a text file in docs/guides/source/, named NN_slug.md:

    # Title
    One-line subtitle

    ## Section heading
    Paragraph text. Lines next to each other join into one paragraph.
    **Bold** works anywhere.

    - A bullet. Lines under it, indented, join onto it.
    1. A numbered step.

        An example line, indented 4 spaces after a blank line, is kept as written.

    Tip: a paragraph starting with Tip:, Warning: or Note: is shown as a callout.

The web route (/api/help) and tools/build_guides.py both call load_guides(), so the
Help page and the PDFs always say the same thing.
"""

import os
import re

SOURCE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                          'docs', 'guides', 'source')

_CALLOUTS = (('Tip:', 'tip'), ('Warning:', 'warn'), ('Note:', 'note'))
_STEP = re.compile(r'^(\d+)\.\s+(.*)$')


def parse_guide(text, slug=''):
    """Parse one guide's text into {slug, title, subtitle, sections:[{heading, blocks}]}.
    A block is {type: para|bullet|step|code|tip|warn|note, text, (n for steps)}."""
    title, subtitle, sections = '', '', []
    blocks = None        # blocks of the current section; None before the first ##
    para = []            # lines of the paragraph being built
    item = None          # the bullet/step block lines are joining onto
    code = []            # lines of the example block being built
    blank_before = True

    def flush_para():
        nonlocal para
        if para:
            txt = ' '.join(para)
            kind = 'para'
            for prefix, k in _CALLOUTS:
                if txt.startswith(prefix):
                    kind, txt = k, txt[len(prefix):].strip()
                    break
            blocks.append({'type': kind, 'text': txt})
            para = []

    def flush_code():
        nonlocal code
        while code and code[-1] == '':          # blank lines after an example aren't part of it
            code.pop()
        if code:
            blocks.append({'type': 'code', 'text': '\n'.join(code)})
            code = []

    for raw in text.splitlines():
        line = raw.rstrip()
        stripped = line.strip()

        if line.startswith('# ') and not title:
            title = line[2:].strip()
            continue
        if line.startswith('## '):
            if blocks is not None:
                flush_para(); flush_code()
            blocks = []
            sections.append({'heading': line[3:].strip(), 'blocks': blocks})
            item, blank_before = None, True
            continue
        if blocks is None:                      # between the title and the first section
            if stripped and not subtitle:
                subtitle = stripped
            continue

        if not stripped:
            flush_para()
            if code:
                code.append('')                 # a blank line inside an example; trimmed below
            item, blank_before = None, True
            continue

        indent = len(line) - len(line.lstrip(' '))
        if code:
            if indent >= 4:                     # the example goes on
                code.append(line[4:])
                blank_before = False
                continue
            while code and code[-1] == '':      # the example has ended
                code.pop()
            flush_code()
        elif indent >= 4 and blank_before and item is None and not para:
            code.append(line[4:])               # an example starts
            blank_before = False
            continue

        if indent > 0 and item is not None:     # continuation of a bullet or step
            item['text'] += ' ' + stripped
            continue

        if stripped.startswith('- '):
            flush_para()
            item = {'type': 'bullet', 'text': stripped[2:].strip()}
            blocks.append(item)
        elif _STEP.match(stripped) and indent == 0:
            flush_para()
            m = _STEP.match(stripped)
            item = {'type': 'step', 'n': int(m.group(1)), 'text': m.group(2).strip()}
            blocks.append(item)
        else:
            item = None
            para.append(stripped)
        blank_before = False

    if blocks is not None:
        flush_para()
        while code and code[-1] == '':
            code.pop()
        flush_code()
    return {'slug': slug, 'title': title, 'subtitle': subtitle, 'sections': sections}


def guide_files(source_dir=SOURCE_DIR):
    """The guide source files, in order (NN_slug.md)."""
    if not os.path.isdir(source_dir):
        return []
    return sorted(os.path.join(source_dir, f) for f in os.listdir(source_dir)
                  if f.endswith('.md') and re.match(r'^\d+_', f))


def load_guides(source_dir=SOURCE_DIR):
    """Every guide, parsed, in order."""
    guides = []
    for path in guide_files(source_dir):
        with open(path, encoding='utf-8') as f:
            slug = os.path.splitext(os.path.basename(path))[0]
            guides.append(parse_guide(f.read(), slug))
    return guides
