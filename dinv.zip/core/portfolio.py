# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Investments — Portfolio Business Logic
All CGT calculations, holdings aggregation, and transaction recording.
"""
import json
import os
import shutil
from datetime import date, timedelta
from .database import get_connection
from .cpi import indexation_factor


def _held_12_months(acq: date, sal: date) -> bool:
    """ATO CGT discount rule: the day of acquisition and the day of the CGT event are both
    excluded (TD 2002/10), so the event must fall AFTER the first anniversary of acquisition.
    e.g. acquired 2 Feb 2020 → discount available from 3 Feb 2021."""
    try:
        anniversary = acq.replace(year=acq.year + 1)
    except ValueError:  # Feb 29 acquired in leap year — anniversary is Feb 28 next year
        anniversary = acq.replace(year=acq.year + 1, day=28)
    return sal > anniversary


# Actions that don't change the number of units held. A bonus issue does: it's recorded
# like a split (e.g. 1 for 10 = 10:11), spreading the cost base over the original and bonus
# shares, which keep the original acquisition dates (ATO). Bonus issues recorded by earlier
# versions as a separate zero-cost parcel have ratio_to = 0 and are skipped by the ratio maths.
_NON_SPLIT_ACTIONS = ('return_of_capital', 'demerger', 'rights_issue')

# CGT start and the indexation / discount changeover (11.45 am on 21 Sep 1999 — by date here)
CGT_START = '1985-09-20'        # assets acquired before this are pre-CGT; earlier events aren't CGT events
INDEXATION_END = '1999-09-21'   # acquired before: indexation possible; events from: discount available


def _cgt_acq(p):
    """The acquisition date for CGT purposes (discount, indexation, pre-CGT status): the
    deceased's for inherited shares acquired after 20 Sep 1985, else the parcel's own."""
    return p['cgt_date'] or p['acquisition_date']


def _is_pre_cgt(p):
    return _cgt_acq(p) < CGT_START


def _cgt_choice_default(conn):
    """'discount', 'indexation' or 'lower' — the portfolio setting; companies always index."""
    rows = {r['key']: r['value'] for r in conn.execute(
        "SELECT key, value FROM settings WHERE key IN ('entity_type', 'indexation_default')")}
    if rows.get('entity_type') == 'company':
        return 'indexation'
    return rows.get('indexation_default') if rows.get('indexation_default') in ('indexation', 'lower') \
        else 'discount'


def _cgt_basis(p, event_date, nominal_gain, indexed_gain, choice, discount_factor):
    """
    How a disposal of (part of) parcel p on event_date is taxed. Returns (basis, gain):
      not_cgt    event before 20 Sep 1985 — no CGT
      pre_cgt    acquired before 20 Sep 1985 — exempt
      indexation cost base indexed to Sep 1999 (gain = proceeds − indexed cost base, never a
                 loss; a nominal loss is a loss with the unindexed cost base)
      discount   held more than 12 months, event from 21 Sep 1999
      other      everything else (including all losses)
    choice: 'discount' / 'indexation' / 'lower' for an asset acquired before 21 Sep 1999 and
    disposed of later. Before 21 Sep 1999 indexation was the only method.
    """
    acq = _cgt_acq(p)
    if event_date < CGT_START:
        return 'not_cgt', nominal_gain
    if acq < CGT_START:
        return 'pre_cgt', nominal_gain
    if nominal_gain <= 0:
        return 'other', nominal_gain
    held = _held_12_months(date.fromisoformat(acq), date.fromisoformat(event_date))
    if not held:
        return 'other', nominal_gain
    can_index = acq < INDEXATION_END
    indexed = max(indexed_gain, 0.0)
    if event_date < INDEXATION_END:
        return ('indexation', indexed) if can_index else ('other', nominal_gain)
    if not can_index or choice == 'discount' or not discount_factor:
        return ('discount', nominal_gain) if discount_factor else \
               (('indexation', indexed) if can_index else ('other', nominal_gain))
    if choice == 'lower' and nominal_gain * (1 - discount_factor) <= indexed:
        return 'discount', nominal_gain
    return 'indexation', indexed


def _split_factor(conn, security_id, after_date, same_day=False):
    """Units held at after_date × factor = the same holding in today's units
    (product of split/consolidation ratios dated after after_date).

    same_day=True also counts splits/consolidations dated on after_date. Use it for a
    return of capital or demerger: registries apply those before a same-day split or
    consolidation, so their per-unit amounts are in pre-split units. Sales and end-of-day
    snapshots come after a same-day split, so they use the default."""
    f = 1.0
    for r in conn.execute(f"""
        SELECT ratio_from, ratio_to FROM corporate_actions
        WHERE security_id = ? AND action_date {'>=' if same_day else '>'} ?
          AND action_type NOT IN ({','.join('?' * len(_NON_SPLIT_ACTIONS))})
    """, (security_id, after_date, *_NON_SPLIT_ACTIONS)).fetchall():
        if r['ratio_from'] and r['ratio_to']:
            f *= r['ratio_to'] / r['ratio_from']
    return f


# Order of events within one day (same date), used everywhere a date comparison decides
# whether one event comes before another:
#   1. purchases (including DRP parcels)
#   2. corporate actions, in registry order — demergers, returns of capital, bonus and
#      rights issues, then splits and consolidations
#   3. sales (including share cancellations)
# So a sale on the day of a return of capital or demerger still receives it, and a parcel
# created by a bonus or rights issue doesn't receive a same-day return of capital or demerger.


def _units_sold_after(conn, parcel_id, security_id, after_date, same_day=False):
    """Units of a parcel (in today's units) disposed of by sales dated after after_date.
    same_day=True also counts sales on after_date — for a corporate action on that date,
    since same-day sales come after it."""
    total = 0.0
    for r in conn.execute(f"""
        SELECT sp.quantity_sold, sa.sale_date FROM sale_parcels sp
        JOIN sales sa ON sa.id = sp.sale_id
        WHERE sp.parcel_id = ? AND sa.sale_date {'>=' if same_day else '>'} ?
    """, (parcel_id, after_date)).fetchall():
        total += r['quantity_sold'] * _split_factor(conn, security_id, r['sale_date'])
    return total


def _rebuild_parcel_costs(conn, parcel_id):
    """
    Recompute a parcel's cost base and every figure derived from it. Caller commits.

    Model: parcels.cost_base / parcels.quantity = cost base per unit still held.
    Starting from the purchase cost (quantity × price + brokerage + other costs), returns
    of capital and demergers are replayed in date order. Each applies per unit to the
    units held on its action date only — units sold earlier keep their original cost base.
    Then every sale_parcels row is re-costed at the per-unit cost base on its sale date.
    """
    p = conn.execute("SELECT * FROM parcels WHERE id = ?", (parcel_id,)).fetchone()
    if not p or not p['quantity']:
        return
    sec, q = p['security_id'], p['quantity']
    original = q * p['price_per_unit'] + (p['brokerage'] or 0) + (p['other_costs'] or 0)
    per_unit = original / q
    steps = []  # (action_date, per-unit reduction)

    events = conn.execute("""
        SELECT 'roc' AS kind, rp.id AS row_id, ca.id AS ca_id, ca.action_date,
               ca.ratio_from, ca.ratio_to, NULL AS child_id
        FROM roc_parcels rp JOIN corporate_actions ca ON ca.id = rp.corporate_action_id
        WHERE rp.parcel_id = ?
        UNION ALL
        SELECT 'dem', dp.id, ca.id, ca.action_date, ca.ratio_from, ca.ratio_to, dp.new_parcel_id
        FROM demerger_parcels dp JOIN corporate_actions ca ON ca.id = dp.corporate_action_id
        WHERE dp.original_parcel_id = ?
        ORDER BY action_date, ca_id
    """, (parcel_id, parcel_id)).fetchall()

    for e in events:
        held = p['quantity_remaining'] + _units_sold_after(conn, parcel_id, sec, e['action_date'],
                                                           same_day=True)
        if e['kind'] == 'roc':
            amount = e['ratio_from'] / _split_factor(conn, sec, e['action_date'], same_day=True)  # per today's unit
            reduction = min(amount, max(per_unit, 0.0))
            conn.execute("""UPDATE roc_parcels
                SET cost_base_reduction = ?, excess_cg = ?, cb_adjust_total = ? WHERE id = ?""",
                (reduction * held, (amount - reduction) * held, reduction * q, e['row_id']))
        else:
            reduction = per_unit * (100.0 - e['ratio_from']) / 100.0
            conn.execute("""UPDATE demerger_parcels
                SET cost_base_transferred = ?, cb_adjust_total = ? WHERE id = ?""",
                (reduction * held, reduction * q, e['row_id']))
            child = conn.execute("SELECT quantity FROM parcels WHERE id = ?",
                                 (e['child_id'],)).fetchone()
            if child and child['quantity']:
                conn.execute("""UPDATE parcels SET price_per_unit = ?, brokerage = 0, other_costs = 0
                                WHERE id = ?""", (reduction * held / child['quantity'], e['child_id']))
                _rebuild_parcel_costs(conn, e['child_id'])
        steps.append((e['action_date'], reduction))
        per_unit -= reduction

    conn.execute("UPDATE parcels SET cost_base = ? WHERE id = ?", (per_unit * q, parcel_id))

    discount_factor = _cgt_discount_factor(conn)
    default_choice = _cgt_choice_default(conn)
    for sp in conn.execute("""
        SELECT sp.id, sp.quantity_sold, sa.sale_date, sa.net_proceeds, sa.quantity AS sale_qty,
               sa.cgt_choice
        FROM sale_parcels sp JOIN sales sa ON sa.id = sp.sale_id
        WHERE sp.parcel_id = ?
    """, (parcel_id,)).fetchall():
        reductions = sum(r for d, r in steps if d <= sp['sale_date'])   # same-day actions first
        units = sp['quantity_sold'] * _split_factor(conn, sec, sp['sale_date'])   # today's units
        cost_base_used = (original / q - reductions) * units
        proceeds = sp['net_proceeds'] / sp['sale_qty'] * sp['quantity_sold']
        nominal = proceeds - cost_base_used
        # Indexed: purchase costs indexed from the acquisition quarter; later returns of
        # capital / demerger transfers come off at their nominal amount
        indexed_cb = (original / q * indexation_factor(_cgt_acq(p), sp['sale_date']) - reductions) * units
        basis, gain = _cgt_basis(p, sp['sale_date'], nominal, proceeds - indexed_cb,
                                 sp['cgt_choice'] or default_choice, discount_factor)
        disc_elig = 1 if basis == 'discount' else 0
        discounted = gain * (1 - discount_factor) if disc_elig else gain
        conn.execute("""UPDATE sale_parcels
            SET cost_base_used = ?, gain_loss = ?, discount_eligible = ?, discounted_gain = ?,
                cgt_basis = ?, indexed_cost_base = ?
            WHERE id = ?""", (cost_base_used, gain, disc_elig, discounted, basis,
                              indexed_cb if basis == 'indexation' else None, sp['id']))


def _recompute_remaining(conn, security_id):
    """quantity_remaining = quantity − units sold (each sale converted to today's units).
    Caller commits."""
    for p in conn.execute("SELECT id, quantity FROM parcels WHERE security_id = ?", (security_id,)).fetchall():
        sold = sum(r['quantity_sold'] * _split_factor(conn, security_id, r['sale_date'])
                   for r in conn.execute("""SELECT sp.quantity_sold, sa.sale_date FROM sale_parcels sp
                                            JOIN sales sa ON sa.id = sp.sale_id WHERE sp.parcel_id = ?""",
                                         (p['id'],)))
        conn.execute("UPDATE parcels SET quantity_remaining = ? WHERE id = ?",
                     (max(p['quantity'] - sold, 0.0) if abs(p['quantity'] - sold) > 1e-9 else 0.0, p['id']))


def _apply_unit_change(conn, security_id, action_date, rf, rt):
    """Apply a recorded split/consolidation/bonus issue (rf → rt units) to the parcels held
    on action_date: quantities × rt/rf, prices ÷ rt/rf (cost base unchanged), units still
    held recomputed from the sales. Caller commits."""
    conn.execute(
        """UPDATE parcels SET
               quantity       = quantity       * ? / ?,
               price_per_unit = price_per_unit * ? / ?
           WHERE security_id = ? AND acquisition_date <= ?""",
        (rt, rf, rf, rt, security_id, action_date))
    _recompute_remaining(conn, security_id)
    _rebuild_security_costs(conn, security_id)


def _rebuild_security_costs(conn, security_id):
    """Rebuild every parcel of a security — after a split/consolidation is added or deleted,
    since that changes how its returns of capital and demergers convert to today's units.
    Caller commits."""
    for (pid,) in conn.execute("SELECT id FROM parcels WHERE security_id = ? ORDER BY id",
                               (security_id,)).fetchall():
        _rebuild_parcel_costs(conn, pid)


def _actions_from(conn, security_id, acquisition_date):
    """Corporate actions that apply to a parcel acquired on acquisition_date
    (splits, consolidations, returns of capital, demergers dated on or after it)."""
    return conn.execute("""
        SELECT * FROM corporate_actions
        WHERE security_id = ? AND action_date >= ?
          AND action_type != 'rights_issue' AND NOT (action_type = 'bonus' AND parcel_id IS NOT NULL)
        ORDER BY action_date, id
    """, (security_id, acquisition_date)).fetchall()


def _issued_by_action_on(conn, parcel_id):
    """Date of the bonus/rights issue that created this parcel, or None."""
    r = conn.execute("SELECT action_date FROM corporate_actions WHERE parcel_id = ?",
                     (parcel_id,)).fetchone()
    return r['action_date'] if r else None


def _link_parcel_to_actions(conn, parcel_id, convert_units=True, issued_on=None):
    """
    Apply corporate actions already recorded with a date on or after this parcel's
    acquisition date, for parcels entered after those actions. Caller commits.

    - split/consolidation (convert_units=True, i.e. a newly entered parcel): quantity and
      price are converted from contract-note units to today's units, and a note is added
    - return of capital: linked, so the cost base reduction / excess gain applies
    - demerger: the matching parcel of the demerged security is created and linked
    issued_on: date of the bonus/rights issue that created the parcel (looked up if None);
    such a parcel comes after a return of capital or demerger on that same date.
    Returns a list of short descriptions of what was applied.
    """
    p = conn.execute("SELECT * FROM parcels WHERE id = ?", (parcel_id,)).fetchone()
    if not p:
        return []
    sec, applied = p['security_id'], []
    issued_on = issued_on or _issued_by_action_on(conn, parcel_id)
    for ca in _actions_from(conn, sec, p['acquisition_date']):
        kind = ca['action_type']
        if (kind in ('return_of_capital', 'demerger') and issued_on
                and ca['action_date'] == issued_on):
            continue
        if kind not in ('return_of_capital', 'demerger'):
            if convert_units and ca['ratio_from'] and ca['ratio_to']:
                f = ca['ratio_to'] / ca['ratio_from']
                conn.execute("""UPDATE parcels SET quantity = quantity * ?,
                                quantity_remaining = quantity_remaining * ?, price_per_unit = price_per_unit / ?
                                WHERE id = ?""", (f, f, f, parcel_id))
                applied.append(f"{ca['ratio_from']:g}:{ca['ratio_to']:g} {kind.replace('_', ' ')} "
                               f"on {ca['action_date']}")
            continue
        held = (p['quantity_remaining'] if not convert_units else
                conn.execute("SELECT quantity_remaining FROM parcels WHERE id = ?",
                             (parcel_id,)).fetchone()[0])
        held += _units_sold_after(conn, parcel_id, sec, ca['action_date'], same_day=True)
        if held <= 1e-9:
            continue
        if kind == 'return_of_capital':
            if not conn.execute("SELECT 1 FROM roc_parcels WHERE corporate_action_id = ? AND parcel_id = ?",
                                (ca['id'], parcel_id)).fetchone():
                conn.execute("""INSERT INTO roc_parcels
                    (corporate_action_id, parcel_id, cost_base_reduction, excess_cg) VALUES (?, ?, 0, 0)""",
                    (ca['id'], parcel_id))
                applied.append(f"return of capital on {ca['action_date']}")
        elif not conn.execute("SELECT 1 FROM demerger_parcels WHERE corporate_action_id = ? AND original_parcel_id = ?",
                              (ca['id'], parcel_id)).fetchone():
            new_qty = held / _split_factor(conn, sec, ca['action_date'], same_day=True) * ca['ratio_to']
            orig_code = _sec_code(conn, sec)
            child = conn.execute("""
                INSERT INTO parcels (security_id, acquisition_date, quantity, price_per_unit,
                    brokerage, other_costs, cost_base, quantity_remaining, notes,
                    label, cgt_date, origin)
                VALUES (?, ?, ?, 0, 0, 0, 0, ?, ?, ?, ?, ?)""",
                (ca['new_security_id'], p['acquisition_date'], new_qty, new_qty,
                 f'Demerger from {orig_code}', p['label'], p['cgt_date'], p['origin'])).lastrowid
            conn.execute("""INSERT INTO demerger_parcels
                (corporate_action_id, original_parcel_id, new_parcel_id, cost_base_transferred)
                VALUES (?, ?, ?, 0)""", (ca['id'], parcel_id, child))
            applied.append(f"demerger on {ca['action_date']}")
    if applied:
        _rebuild_parcel_costs(conn, parcel_id)
    return applied


def _backup_once(conn, db_path, tag):
    """Copy the portfolio to <file>.<tag>.bak before a data repair (once)."""
    if conn.execute("SELECT COUNT(*) FROM parcels").fetchone()[0]:
        conn.execute("PRAGMA wal_checkpoint(FULL)")
        backup = f"{db_path}.{tag}.bak"
        if not os.path.exists(backup):
            shutil.copy2(db_path, backup)


def run_migrations(db_path):
    _migrate_cb_rebuild(db_path)
    _migrate_link_actions(db_path)
    _migrate_same_day_order(db_path)
    _migrate_same_day_sales(db_path)
    _migrate_bonus_issues(db_path)
    _migrate_cgt_history(db_path)


def _migrate_bonus_issues(db_path):
    """
    One-off for 1.1.0: bonus issues recorded as a separate zero-cost parcel dated the issue
    date become a ratio applied to every parcel held (cost base spread over original and bonus
    shares; the original acquisition dates kept — ATO). Converted only while the bonus parcel
    is unsold; sold ones are listed on the dashboard for review. Backup + audit log.
    """
    conn = get_connection(db_path)
    try:
        if conn.execute("SELECT 1 FROM settings WHERE key = 'migration_bonus_v1'").fetchone():
            return
        old = conn.execute("""SELECT * FROM corporate_actions WHERE action_type = 'bonus'
                              AND parcel_id IS NOT NULL ORDER BY action_date, id""").fetchall()
        review = []
        if old:
            _backup_once(conn, db_path, 'before-bonus-repair')
        for ca in old:
            sec, d, bonus_pid = ca['security_id'], ca['action_date'], ca['parcel_id']
            if conn.execute("SELECT 1 FROM sale_parcels WHERE parcel_id = ?", (bonus_pid,)).fetchone():
                review.append({'parcel_id': bonus_pid, 'issue': 'bonus shares recorded as a separate '
                               'zero-cost parcel, now sold — the cost base should have been spread over '
                               'the original shares too'})
                continue
            f = _split_factor(conn, sec, d, same_day=True)
            bonus_qty = conn.execute("SELECT quantity FROM parcels WHERE id = ?", (bonus_pid,)).fetchone()[0] / f
            held = sum(p['quantity_remaining'] + _units_sold_after(conn, p['id'], sec, d, same_day=True)
                       for p in conn.execute("""SELECT * FROM parcels WHERE security_id = ?
                            AND acquisition_date <= ? AND id != ?""", (sec, d, bonus_pid)).fetchall()) / f
            if held <= 1e-9:
                review.append({'parcel_id': bonus_pid, 'issue': 'bonus shares with no other shares held'})
                continue
            _write_audit(conn, 'repair', 'corporate_actions', ca['id'], dict(ca),
                         {'action_type': 'bonus', 'ratio_from': held, 'ratio_to': held + bonus_qty})
            conn.execute("UPDATE corporate_actions SET parcel_id = NULL, ratio_from = ?, ratio_to = ? WHERE id = ?",
                         (held, held + bonus_qty, ca['id']))
            _delete_parcel_records(conn, bonus_pid)
            _apply_unit_change(conn, sec, d, held, held + bonus_qty)
        if review:
            conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('review_bonus_parcels', ?)",
                         (json.dumps(review),))
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('migration_bonus_v1', '1')")
        conn.commit()
    finally:
        conn.close()


def _migrate_cgt_history(db_path):
    """
    One-off for 1.1.0: re-cost every sale with the pre-CGT, indexation and discount-date
    rules (sale_parcels.cgt_basis). Only sales of shares acquired before 21 Sep 1999 can
    change; if there are any, the file is copied first and changed figures are audited.
    """
    conn = get_connection(db_path)
    try:
        if conn.execute("SELECT 1 FROM settings WHERE key = 'migration_cgt_history_v1'").fetchone():
            return
        affected = conn.execute("""
            SELECT 1 FROM sale_parcels sp JOIN parcels p ON p.id = sp.parcel_id
            WHERE COALESCE(p.cgt_date, p.acquisition_date) < ?
            UNION SELECT 1 FROM roc_parcels rp JOIN parcels p ON p.id = rp.parcel_id
            WHERE COALESCE(p.cgt_date, p.acquisition_date) < ?""",
            (INDEXATION_END, CGT_START)).fetchone()
        if affected:
            _backup_once(conn, db_path, 'before-cgt-history')
        before = {r['id']: dict(r) for r in conn.execute("SELECT * FROM sale_parcels")}
        for (pid,) in conn.execute("SELECT id FROM parcels ORDER BY id").fetchall():
            _rebuild_parcel_costs(conn, pid)
        keys = ('gain_loss', 'discount_eligible', 'cgt_basis')
        for r in conn.execute("SELECT * FROM sale_parcels").fetchall():
            old = before.get(r['id'])
            if old and (abs(old['gain_loss'] - r['gain_loss']) > 0.005
                        or old['discount_eligible'] != r['discount_eligible']
                        or r['cgt_basis'] in ('pre_cgt', 'not_cgt', 'indexation')):
                _write_audit(conn, 'repair', 'sale_parcels', r['id'],
                             {k: old[k] for k in keys}, {k: r[k] for k in keys})
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('migration_cgt_history_v1', '1')")
        conn.commit()
    finally:
        conn.close()


def _migrate_same_day_sales(db_path):
    """
    One-off repair (1.1.0) for the order of events within a day (see the comment above
    _units_sold_after). Before 1.1.0:
    - a sale on the day of a return of capital or demerger counted as before it, so the
      units sold didn't receive it — now they do;
    - a parcel from a bonus/rights issue received a same-day return of capital or
      demerger — now it doesn't.
    Rebuilds affected securities. Demerged parcels whose quantity changes are corrected if
    none of their shares have been sold; otherwise they are listed for review in Settings.
    Backup and audit log as for the other repairs.
    """
    conn = get_connection(db_path)
    try:
        if conn.execute("SELECT 1 FROM settings WHERE key = 'migration_same_day_sales_v1'").fetchone():
            return
        value_actions = """SELECT ca.* FROM corporate_actions ca
            WHERE ca.action_type IN ('return_of_capital', 'demerger') AND (
              EXISTS (SELECT 1 FROM sales sa WHERE sa.security_id = ca.security_id
                                               AND sa.sale_date = ca.action_date)
              OR EXISTS (SELECT 1 FROM corporate_actions b JOIN parcels p ON p.id = b.parcel_id
                         WHERE p.security_id = ca.security_id AND b.action_date = ca.action_date))"""
        actions = conn.execute(value_actions).fetchall()
        if actions:
            _backup_once(conn, db_path, 'before-same-day-sales-repair')
            before_p  = {r['id']: (r['cost_base'], r['quantity']) for r in
                         conn.execute("SELECT id, cost_base, quantity FROM parcels")}
            before_sp = {r['id']: dict(r) for r in conn.execute("SELECT * FROM sale_parcels")}
            review = []
            for ca in actions:
                issued = {r[0] for r in conn.execute("""
                    SELECT p.id FROM corporate_actions b JOIN parcels p ON p.id = b.parcel_id
                    WHERE p.security_id = ? AND b.action_date = ?""",
                    (ca['security_id'], ca['action_date']))}
                if ca['action_type'] == 'return_of_capital':
                    for pid in issued:
                        conn.execute("DELETE FROM roc_parcels WHERE corporate_action_id = ? AND parcel_id = ?",
                                     (ca['id'], pid))
                    continue
                for dp in conn.execute("SELECT * FROM demerger_parcels WHERE corporate_action_id = ?",
                                       (ca['id'],)).fetchall():
                    child = conn.execute("SELECT * FROM parcels WHERE id = ?",
                                         (dp['new_parcel_id'],)).fetchone()
                    child_sold = conn.execute("SELECT 1 FROM sale_parcels WHERE parcel_id = ?",
                                              (child['id'],)).fetchone()
                    if dp['original_parcel_id'] in issued:
                        if child_sold:
                            review.append({'parcel_id': child['id'], 'issue': 'demerged from a same-day bonus/rights parcel'})
                            continue
                        conn.execute("DELETE FROM demerger_parcels WHERE id = ?", (dp['id'],))
                        conn.execute("DELETE FROM roc_parcels WHERE parcel_id = ?", (child['id'],))
                        conn.execute("DELETE FROM parcels WHERE id = ?", (child['id'],))
                        continue
                    orig = conn.execute("SELECT * FROM parcels WHERE id = ?",
                                        (dp['original_parcel_id'],)).fetchone()
                    held = orig['quantity_remaining'] + _units_sold_after(
                        conn, orig['id'], ca['security_id'], ca['action_date'], same_day=True)
                    new_qty = held / _split_factor(conn, ca['security_id'], ca['action_date'],
                                                   same_day=True) * ca['ratio_to']
                    new_qty *= _split_factor(conn, ca['new_security_id'], ca['action_date'])
                    if abs(new_qty - child['quantity']) > 1e-6:
                        if child_sold:
                            review.append({'parcel_id': child['id'], 'issue':
                                           f'demerged quantity should be {new_qty:g}, not {child["quantity"]:g}'})
                        else:
                            conn.execute("UPDATE parcels SET quantity = ?, quantity_remaining = ? WHERE id = ?",
                                         (new_qty, new_qty, child['id']))
            for sid in {ca['security_id'] for ca in actions}:
                _rebuild_security_costs(conn, sid)
            for r in conn.execute("SELECT id, cost_base, quantity FROM parcels").fetchall():
                old = before_p.get(r['id'])
                if old and (abs(old[0] - r['cost_base']) > 0.005 or abs(old[1] - r['quantity']) > 1e-6):
                    _write_audit(conn, 'repair', 'parcels', r['id'],
                                 {'cost_base': old[0], 'quantity': old[1]},
                                 {'cost_base': r['cost_base'], 'quantity': r['quantity']})
            for pid in set(before_p) - {r[0] for r in conn.execute("SELECT id FROM parcels")}:
                _write_audit(conn, 'repair', 'parcels', pid, {'cost_base': before_p[pid][0]},
                             {'deleted': 'demerged from a same-day bonus/rights parcel'})
            keys = ('cost_base_used', 'gain_loss')
            for r in conn.execute("SELECT * FROM sale_parcels").fetchall():
                old = before_sp.get(r['id'])
                if old and abs(old['gain_loss'] - r['gain_loss']) > 0.005:
                    _write_audit(conn, 'repair', 'sale_parcels', r['id'],
                                 {k: old[k] for k in keys}, {k: r[k] for k in keys})
            if review:
                conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('review_same_day_parcels', ?)",
                             (json.dumps(review),))
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('migration_same_day_sales_v1', '1')")
        conn.commit()
    finally:
        conn.close()


def _migrate_same_day_order(db_path):
    """
    One-off repair (1.0.1): a return of capital or demerger on the same day as a split or
    consolidation was applied before it when entered, but after it whenever the cost base
    was later rebuilt, so stored cost bases depended on what had been edited since.
    Rebuilds the parcels of affected securities only. Backup and audit log as for the
    other repairs.
    """
    conn = get_connection(db_path)
    try:
        if conn.execute("SELECT 1 FROM settings WHERE key = 'migration_same_day_order_v1'").fetchone():
            return
        sids = [r[0] for r in conn.execute(f"""
            SELECT DISTINCT a.security_id FROM corporate_actions a
            JOIN corporate_actions b ON b.security_id = a.security_id
                                    AND b.action_date = a.action_date
            WHERE a.action_type IN ('return_of_capital', 'demerger')
              AND b.action_type NOT IN ({','.join('?' * len(_NON_SPLIT_ACTIONS))})
        """, _NON_SPLIT_ACTIONS).fetchall()]
        if sids:
            _backup_once(conn, db_path, 'before-same-day-repair')
            before_p  = {r['id']: r['cost_base'] for r in conn.execute("SELECT id, cost_base FROM parcels")}
            before_sp = {r['id']: dict(r) for r in conn.execute("SELECT * FROM sale_parcels")}
            for sid in sids:
                _rebuild_security_costs(conn, sid)
            for r in conn.execute("SELECT id, cost_base FROM parcels").fetchall():
                old = before_p.get(r['id'])
                if old is not None and abs(old - r['cost_base']) > 0.005:
                    _write_audit(conn, 'repair', 'parcels', r['id'], {'cost_base': old},
                                 {'cost_base': r['cost_base']})
            keys = ('cost_base_used', 'gain_loss')
            for r in conn.execute("SELECT * FROM sale_parcels").fetchall():
                old = before_sp.get(r['id'])
                if old and abs(old['gain_loss'] - r['gain_loss']) > 0.005:
                    _write_audit(conn, 'repair', 'sale_parcels', r['id'],
                                 {k: old[k] for k in keys}, {k: r[k] for k in keys})
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('migration_same_day_order_v1', '1')")
        conn.commit()
    finally:
        conn.close()


def _migrate_link_actions(db_path):
    """
    Link parcels entered after a return of capital / demerger dated on or after their
    purchase (previously ignored). Parcels entered after a split dated on or after their
    purchase are listed for review in 'review_split_parcels' — whether the quantity was
    entered in pre- or post-split units can't be known, so they are not changed.
    """
    conn = get_connection(db_path)
    try:
        if conn.execute("SELECT 1 FROM settings WHERE key = 'migration_link_actions_v1'").fetchone():
            return
        children = {r[0] for r in conn.execute("SELECT new_parcel_id FROM demerger_parcels")}
        parcels = [p for p in conn.execute("SELECT * FROM parcels ORDER BY id").fetchall()
                   if p['id'] not in children]
        needs_link, review = [], []
        for p in parcels:
            for ca in _actions_from(conn, p['security_id'], p['acquisition_date']):
                if ca['action_type'] == 'return_of_capital':
                    linked = conn.execute("SELECT 1 FROM roc_parcels WHERE corporate_action_id=? AND parcel_id=?",
                                          (ca['id'], p['id'])).fetchone()
                elif ca['action_type'] == 'demerger':
                    linked = conn.execute("SELECT 1 FROM demerger_parcels WHERE corporate_action_id=? AND original_parcel_id=?",
                                          (ca['id'], p['id'])).fetchone()
                else:
                    # >= : ties (same second) are flagged — a false alarm only asks the user to check
                    if (p['created_at'] or '') >= (ca['created_at'] or ''):
                        review.append({'parcel_id': p['id'], 'code': _sec_code(conn, p['security_id']),
                                       'acquisition_date': p['acquisition_date'], 'quantity': p['quantity'],
                                       'action_date': ca['action_date'],
                                       'ratio': f"{ca['ratio_from']:g}:{ca['ratio_to']:g}"})
                    continue
                if not linked and p['id'] not in needs_link:
                    needs_link.append(p['id'])
        if needs_link:
            _backup_once(conn, db_path, 'before-link-repair')
        for pid in needs_link:
            before = conn.execute("SELECT cost_base FROM parcels WHERE id = ?", (pid,)).fetchone()[0]
            applied = _link_parcel_to_actions(conn, pid, convert_units=False)
            if applied:
                after = conn.execute("SELECT cost_base FROM parcels WHERE id = ?", (pid,)).fetchone()[0]
                _write_audit(conn, 'repair', 'parcels', pid, {'cost_base': before},
                             {'cost_base': after, 'linked': applied})
        if review:
            conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('review_split_parcels', ?)",
                         (json.dumps(review),))
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('migration_link_actions_v1', '1')")
        conn.commit()
    finally:
        conn.close()


def _migrate_cb_rebuild(db_path):
    """
    One-off repair for portfolios created by earlier versions: rebuilds every parcel's
    cost base (return of capital / demerger on partly sold parcels, cost bases reset by
    parcel edits) and re-tests the 12-month discount boundary. A copy of the file is
    saved alongside it first, and every changed figure is written to the audit log.
    """
    conn = get_connection(db_path)
    try:
        if conn.execute("SELECT 1 FROM settings WHERE key = 'migration_cb_rebuild_v1'").fetchone():
            return
        _backup_once(conn, db_path, 'before-cb-repair')

        before_p  = {r['id']: r['cost_base'] for r in conn.execute("SELECT id, cost_base FROM parcels")}
        before_sp = {r['id']: dict(r) for r in conn.execute("SELECT * FROM sale_parcels")}
        for (pid,) in conn.execute("SELECT id FROM parcels ORDER BY id").fetchall():
            _rebuild_parcel_costs(conn, pid)
        for r in conn.execute("SELECT id, cost_base FROM parcels").fetchall():
            old = before_p.get(r['id'])
            if old is not None and abs(old - r['cost_base']) > 0.005:
                _write_audit(conn, 'repair', 'parcels', r['id'], {'cost_base': old},
                             {'cost_base': r['cost_base']})
        keys = ('cost_base_used', 'gain_loss', 'discount_eligible')
        for r in conn.execute("SELECT * FROM sale_parcels").fetchall():
            old = before_sp.get(r['id'])
            if old and (abs(old['gain_loss'] - r['gain_loss']) > 0.005
                        or old['discount_eligible'] != r['discount_eligible']):
                _write_audit(conn, 'repair', 'sale_parcels', r['id'],
                             {k: old[k] for k in keys}, {k: r[k] for k in keys})
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('migration_cb_rebuild_v1', '1')")
        conn.commit()
    finally:
        conn.close()


def _sec_code(conn, security_id):
    r = conn.execute("SELECT code FROM securities WHERE id = ?", (security_id,)).fetchone()
    return r['code'] if r else str(security_id)


def _write_audit(conn, action, table_name, record_id, old_data, new_data=None):
    """Append one audit entry. Caller is responsible for the enclosing commit."""
    conn.execute(
        """INSERT INTO audit_log (action, table_name, record_id, old_data, new_data)
           VALUES (?, ?, ?, ?, ?)""",
        (action, table_name, record_id,
         json.dumps(old_data, default=str),
         json.dumps(new_data, default=str) if new_data is not None else None)
    )


# ── Securities ─────────────────────────────────────────────────────────────────

def get_securities(db_path, active_only=True):
    conn = get_connection(db_path)
    try:
        q = "SELECT * FROM securities"
        if active_only:
            q += " WHERE is_active = 1"
        q += " ORDER BY code"
        return [dict(r) for r in conn.execute(q).fetchall()]
    finally:
        conn.close()


def add_security(db_path, code, name, exchange='ASX', security_type='share',
                 currency='AUD', notes=''):
    conn = get_connection(db_path)
    try:
        c = conn.execute(
            """INSERT INTO securities (code, name, exchange, security_type, currency, notes)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (code.upper(), name, exchange, security_type, currency, notes)
        )
        conn.commit()
        return c.lastrowid
    finally:
        conn.close()


def get_security_by_code(db_path, code):
    conn = get_connection(db_path)
    try:
        r = conn.execute("SELECT * FROM securities WHERE code = ?", (code.upper(),)).fetchone()
        return dict(r) if r else None
    finally:
        conn.close()


# ── Code / name history ───────────────────────────────────────────────────────

def _names_at(conn, as_at):
    """{security_id: (code, name)} in effect at the end of as_at (YYYY-MM-DD)."""
    out = {r['id']: (r['code'], r['name'])
           for r in conn.execute("SELECT id, code, name FROM securities")}
    for r in conn.execute("""
        SELECT n.security_id, n.code, n.name FROM security_names n
        WHERE n.effective_date = (SELECT MAX(m.effective_date) FROM security_names m
                                  WHERE m.security_id = n.security_id AND m.effective_date <= ?)
    """, (as_at,)).fetchall():
        out[r['security_id']] = (r['code'], r['name'])
    return out


def _apply_names(conn, rows, as_at):
    """Set code/name on report rows (dicts with security_id) to those in effect at as_at."""
    names = _names_at(conn, as_at)
    for r in rows:
        if r.get('security_id') in names:
            r['code'], r['name'] = names[r['security_id']]
    return rows


def get_security_names(db_path, security_id):
    conn = get_connection(db_path)
    try:
        return [dict(r) for r in conn.execute(
            "SELECT * FROM security_names WHERE security_id = ? ORDER BY effective_date",
            (security_id,)).fetchall()]
    finally:
        conn.close()


def _sync_current_name(conn, security_id):
    """securities.code/name = the history row in effect today (if there is history)."""
    today = date.today().isoformat()
    r = conn.execute("""SELECT code, name FROM security_names WHERE security_id = ?
                        AND effective_date <= ? ORDER BY effective_date DESC LIMIT 1""",
                     (security_id, today)).fetchone()
    if not r:
        return
    clash = conn.execute("SELECT code FROM securities WHERE code = ? AND id != ?",
                         (r['code'], security_id)).fetchone()
    if clash:
        raise ValueError(f"Another security already uses the code {r['code']} — change its code first")
    conn.execute("UPDATE securities SET code = ?, name = ? WHERE id = ?",
                 (r['code'], r['name'], security_id))


def add_security_name(db_path, security_id, effective_date, code, name):
    """Record a change of code and/or name from effective_date. The first change also
    records the code and name before it."""
    code, name = (code or '').strip().upper(), (name or '').strip()
    if not code or not name:
        raise ValueError("Code and name are required")
    try:
        date.fromisoformat(effective_date)
    except (TypeError, ValueError):
        raise ValueError("Enter the date the change took effect")
    conn = get_connection(db_path)
    try:
        sec = conn.execute("SELECT * FROM securities WHERE id = ?", (security_id,)).fetchone()
        if not sec:
            raise ValueError("Security not found")
        if not conn.execute("SELECT 1 FROM security_names WHERE security_id = ?", (security_id,)).fetchone():
            conn.execute("""INSERT INTO security_names (security_id, effective_date, code, name)
                            VALUES (?, '', ?, ?)""", (security_id, sec['code'], sec['name']))
        if conn.execute("SELECT 1 FROM security_names WHERE security_id = ? AND effective_date = ?",
                        (security_id, effective_date)).fetchone():
            raise ValueError(f"There's already a change dated {effective_date}")
        row_id = conn.execute("""INSERT INTO security_names (security_id, effective_date, code, name)
                                 VALUES (?, ?, ?, ?)""",
                              (security_id, effective_date, code, name)).lastrowid
        _sync_current_name(conn, security_id)
        conn.commit()
        return row_id
    finally:
        conn.close()


def delete_security_name(db_path, name_id):
    conn = get_connection(db_path)
    try:
        r = conn.execute("SELECT * FROM security_names WHERE id = ?", (name_id,)).fetchone()
        if not r:
            raise ValueError("Not found")
        if r['effective_date'] == '':
            raise ValueError("The original code and name can't be deleted — delete the later changes instead")
        conn.execute("DELETE FROM security_names WHERE id = ?", (name_id,))
        _sync_current_name(conn, r['security_id'])
        rest = conn.execute("SELECT COUNT(*) FROM security_names WHERE security_id = ?",
                            (r['security_id'],)).fetchone()[0]
        if rest == 1:   # only the original is left: no history
            conn.execute("DELETE FROM security_names WHERE security_id = ?", (r['security_id'],))
        conn.commit()
    finally:
        conn.close()


def security_id_for_code(db_path, code, on_date=None):
    """The security that had this code on on_date (or has it today)."""
    code = (code or '').strip().upper()
    conn = get_connection(db_path)
    try:
        if on_date:
            for sid, (c, _) in _names_at(conn, on_date).items():
                if c == code:
                    return sid
        r = conn.execute("SELECT id FROM securities WHERE code = ?", (code,)).fetchone()
        return r['id'] if r else None
    finally:
        conn.close()


# ── FY lock enforcement ────────────────────────────────────────────────────────

def _locked_fy(conn):
    row = conn.execute("SELECT value FROM settings WHERE key='locked_fy'").fetchone()
    try:
        return int(row['value']) if row and row['value'] else 0
    except (TypeError, ValueError):
        return 0


def _check_date_not_locked(conn, date_str, label='record'):
    if not date_str:
        return
    locked = _locked_fy(conn)
    if not locked:
        return
    d = date.fromisoformat(date_str)
    fy = d.year + 1 if d.month >= 7 else d.year
    if fy <= locked:
        raise ValueError(f"FY{fy} is locked — {label} cannot be modified after lodgement")


def _check_parcel_not_locked(conn, parcel_id):
    locked = _locked_fy(conn)
    if not locked:
        return
    parcel = conn.execute("SELECT acquisition_date FROM parcels WHERE id = ?", (parcel_id,)).fetchone()
    if parcel:
        d = date.fromisoformat(parcel['acquisition_date'])
        fy = d.year + 1 if d.month >= 7 else d.year
        if fy <= locked:
            raise ValueError(f"FY{fy} is locked — this purchase cannot be modified after lodgement")
    for row in conn.execute("""
        SELECT sa.sale_date FROM sale_parcels sp
        JOIN sales sa ON sa.id = sp.sale_id
        WHERE sp.parcel_id = ?
    """, (parcel_id,)).fetchall():
        d = date.fromisoformat(row['sale_date'])
        fy = d.year + 1 if d.month >= 7 else d.year
        if fy <= locked:
            raise ValueError(
                f"FY{fy} is locked — this parcel has a sale in a locked year "
                "and cannot be modified after lodgement"
            )


# ── Parcels (purchases) ────────────────────────────────────────────────────────

def _note_linked_actions(conn, parcel_id, issued_on=None):
    """Link a newly entered parcel to earlier-recorded corporate actions and note it."""
    applied = _link_parcel_to_actions(conn, parcel_id, issued_on=issued_on)
    if applied:
        conn.execute("""UPDATE parcels SET notes = TRIM(COALESCE(notes, '') || ' ' || ?) WHERE id = ?""",
                     (f"[Adjusted for {'; '.join(applied)}]", parcel_id))


def add_parcel(db_path, security_id, acquisition_date, quantity, price_per_unit,
               brokerage=0.0, other_costs=0.0, notes='', label=None, entered_total=None,
               cgt_date=None, origin='purchase'):
    """Record a purchase (or inherited shares: origin='inherited', cgt_date = the date the
    deceased acquired them, or the date of death for pre-CGT shares — see add_inherited).
    label: the user's name for the parcel. entered_total: total cost as typed, if one was."""
    cost_base = quantity * price_per_unit + brokerage + other_costs
    conn = get_connection(db_path)
    try:
        _check_date_not_locked(conn, acquisition_date, 'purchase')
        c = conn.execute(
            """INSERT INTO parcels
               (security_id, acquisition_date, quantity, price_per_unit,
                brokerage, other_costs, cost_base, quantity_remaining, notes,
                label, entered_total, cgt_date, origin)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (security_id, acquisition_date, quantity, price_per_unit,
             brokerage, other_costs, cost_base, quantity, notes,
             (label or '').strip() or None, entered_total,
             cgt_date if cgt_date and cgt_date != acquisition_date else None, origin or 'purchase')
        )
        _note_linked_actions(conn, c.lastrowid)
        # Auto-add to watchlist on first purchase of a security
        if not conn.execute(
            "SELECT id FROM watchlist WHERE security_id = ?", (security_id,)
        ).fetchone():
            conn.execute("INSERT INTO watchlist (security_id) VALUES (?)", (security_id,))
        conn.commit()
        return c.lastrowid
    finally:
        conn.close()


def _with_entered_units(conn, rows):
    """Add the contract-note figures to parcel dicts: entered_quantity / entered_price (units
    as at the acquisition date, before later splits/consolidations) and unit_changes (the
    splits/consolidations since, for a "now N units after ..." note)."""
    for r in rows:
        r['cgt_acquired'] = _cgt_acq(r)
        r['pre_cgt'] = r['cgt_acquired'] < CGT_START
        f = _split_factor(conn, r['security_id'], r['acquisition_date'], same_day=True)
        r['entered_quantity'] = r['quantity'] if f == 1 else round(r['quantity'] / f, 10)
        r['entered_price'] = (r['entered_total'] / r['entered_quantity']
                              if r.get('entered_total') is not None and r['entered_quantity'] else
                              r['price_per_unit'] if f == 1 else round(r['price_per_unit'] * f, 10))
        r['unit_changes'] = [dict(a) for a in conn.execute(f"""
            SELECT action_date, action_type, ratio_from, ratio_to FROM corporate_actions
            WHERE security_id = ? AND action_date >= ? AND ratio_from > 0 AND ratio_to > 0
              AND action_type NOT IN ({','.join('?' * len(_NON_SPLIT_ACTIONS))})
            ORDER BY action_date, id""", (r['security_id'], r['acquisition_date'], *_NON_SPLIT_ACTIONS))]
    return rows


def add_inherited(db_path, security_id, death_date, quantity, cost_base, original_date=None,
                  label=None, notes=''):
    """
    Shares inherited from a deceased estate, held from the date of death (death_date).
    original_date: when the deceased acquired them. Acquired on or after 20 Sep 1985, the
    beneficiary takes over the deceased's cost base (cost_base) and acquisition date for the
    CGT discount / indexation. Acquired before (or unknown), cost_base must be the market
    value at the date of death, and the shares count as acquired on the date of death.
    """
    if quantity <= 0:
        raise ValueError("Quantity must be greater than zero")
    if cost_base is None or cost_base < 0:
        raise ValueError("Enter the cost base (the market value at the date of death for shares "
                         "the deceased acquired before 20 September 1985)")
    if original_date and original_date > death_date:
        raise ValueError("The deceased's acquisition date is after the date of death")
    cgt_date = original_date if original_date and original_date >= CGT_START else None
    return add_parcel(db_path, security_id, death_date, quantity, cost_base / quantity,
                      notes=notes, label=label, entered_total=cost_base, cgt_date=cgt_date,
                      origin='inherited')


def inherited_parcels_csv(db_path, death_date):
    """The deceased's holdings at the date of death as Inherit rows for the beneficiary's
    portfolio (Add to this portfolio). Pre-CGT parcels are left without a cost: the
    beneficiary's cost base is the market value at the date of death."""
    import csv, io
    rows = get_holdings_at_date(db_path, death_date)
    conn = get_connection(db_path)
    try:
        info = {r['id']: r for r in conn.execute("SELECT id, cgt_date, acquisition_date, label FROM parcels")}
    finally:
        conn.close()
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator='\n')
    w.writerow(['Type', 'Date', 'Code', 'Quantity', 'Cost', 'Original Date', 'Label', 'Notes'])
    for r in rows:
        p = info[r['parcel_id']]
        acq = _cgt_acq(p)
        pre = acq < CGT_START
        w.writerow(['Inherit', death_date, r['code'],
                    f"{round(r['qty_at_date'], 10):.10f}".rstrip('0').rstrip('.'),
                    '' if pre else f"{r['cost_base_at_date']:.2f}", '' if pre else acq, p['label'] or '',
                    'Pre-CGT: enter the market value at the date of death as the Cost' if pre else
                    f"Bought {acq}"])
    return buf.getvalue()


def get_parcels(db_path, security_id=None, open_only=False):
    conn = get_connection(db_path)
    try:
        q = """SELECT p.*, s.code, s.name, s.exchange
               FROM parcels p
               JOIN securities s ON s.id = p.security_id"""
        params = []
        conditions = []
        if security_id:
            conditions.append("p.security_id = ?")
            params.append(security_id)
        if open_only:
            conditions.append("p.quantity_remaining > 0")
        if conditions:
            q += " WHERE " + " AND ".join(conditions)
        q += " ORDER BY p.acquisition_date, p.id"
        return _with_entered_units(conn, [dict(r) for r in conn.execute(q, params).fetchall()])
    finally:
        conn.close()


# ── Holdings (current open positions) ──────────────────────────────────────────

def get_holdings(db_path):
    conn = get_connection(db_path)
    try:
        rows = conn.execute("""
            SELECT
                s.id         AS security_id,
                s.code,
                s.name,
                s.exchange,
                s.security_type,
                s.currency,
                SUM(p.quantity_remaining)        AS total_quantity,
                SUM(p.cost_base * (p.quantity_remaining / p.quantity)) AS total_cost_base,
                MIN(p.acquisition_date)          AS earliest_acquisition,
                COUNT(p.id)                      AS parcel_count
            FROM parcels p
            JOIN securities s ON s.id = p.security_id
            WHERE p.quantity_remaining > 0
            GROUP BY s.id
            ORDER BY s.code
        """).fetchall()
        holdings = []
        for r in rows:
            h = dict(r)
            h['avg_cost'] = (h['total_cost_base'] / h['total_quantity']
                             if h['total_quantity'] else 0)
            holdings.append(h)
        return holdings
    finally:
        conn.close()


# ── Sales and CGT ──────────────────────────────────────────────────────────────

def _cgt_discount_factor(conn):
    """Return the CGT discount factor based on entity_type setting.
    Individual: 0.5 (50% discount), SMSF accumulation: 1/3, SMSF pension: 1.0, Company: 0."""
    row = conn.execute("SELECT value FROM settings WHERE key='entity_type'").fetchone()
    entity = row['value'] if row else 'individual'
    return {'individual': 0.5, 'smsf_accumulation': 1/3,
            'smsf_pension': 1.0, 'company': 0.0}.get(entity, 0.5)


def _parcels_for_sale(conn, security_id, cgt_method, parcel_ids=None, sale_date=None):
    """Return open parcels acquired on or before sale_date, ordered per the chosen CGT method."""
    rows = conn.execute(
        """SELECT * FROM parcels WHERE security_id = ? AND quantity_remaining > 1e-9
           AND acquisition_date <= ?""",
        (security_id, sale_date or '9999-12-31')
    ).fetchall()
    if cgt_method == 'specific' and parcel_ids:
        order = {pid: i for i, pid in enumerate(parcel_ids)}
        rows = [r for r in rows if r['id'] in order]
        rows.sort(key=lambda r: order[r['id']])
    elif cgt_method == 'mingain':
        rows.sort(key=lambda r: r['cost_base'] / r['quantity'], reverse=True)
    elif cgt_method == 'maxgain':
        rows.sort(key=lambda r: r['cost_base'] / r['quantity'])
    else:
        rows.sort(key=lambda r: (r['acquisition_date'], r['id']))
    return rows


SALE_KINDS = ('sale', 'cancellation')
CGT_CHOICES = ('discount', 'indexation')
LABEL_METHODS = {'FIFO': 'fifo', 'MIN': 'mingain', 'MAX': 'maxgain', 'PRORATA': 'prorata'}


def allocate_by_labels(db_path, security_id, sale_date, quantity, spec):
    """
    Exact parcel allocations [(parcel_id, units as at sale_date)] for a sale of quantity
    units, from a parcel spec like "amp,drp22,MIN": parcels with each label in turn (FIFO
    among parcels sharing a label), then the remainder by the method named last (FIFO, MIN,
    MAX or PRORATA; FIFO if none). Only parcels held on the sale date are used.
    """
    items = [x.strip() for x in (spec or '').split(',') if x.strip()]
    method = 'fifo'
    if items and items[-1].upper() in LABEL_METHODS:
        method = LABEL_METHODS[items.pop().upper()]
    for x in items:
        if x.upper() in LABEL_METHODS:
            raise ValueError(f"{x} must be the last item in the parcel list")
    conn = get_connection(db_path)
    try:
        factor = _split_factor(conn, security_id, sale_date)
        fifo = _parcels_for_sale(conn, security_id, 'fifo', None, sale_date)
        avail = {p['id']: p['quantity_remaining'] for p in fifo}
        taken, remaining = {}, quantity * factor

        def take(pid, want):
            nonlocal remaining
            q = min(want, avail[pid])
            if q > 1e-12:
                avail[pid] -= q
                taken[pid] = taken.get(pid, 0.0) + q
                remaining -= q

        for label in items:
            matches = [p for p in fifo if (p['label'] or '') == label]
            if not matches:
                raise ValueError(f"No parcel labelled '{label}' is held on {sale_date}")
            for p in matches:
                if remaining <= 1e-9:
                    break
                take(p['id'], remaining)
        if remaining > 1e-9:
            rest = _parcels_for_sale(conn, security_id, 'mingain' if method == 'mingain' else
                                     'maxgain' if method == 'maxgain' else 'fifo', None, sale_date)
            if method == 'prorata':
                held = sum(avail[p['id']] for p in rest)
                if held > 1e-9:
                    share = remaining / held
                    for p in rest:
                        take(p['id'], avail[p['id']] * share)
            else:
                for p in rest:
                    if remaining <= 1e-9:
                        break
                    take(p['id'], remaining)
        if remaining > 0.0001:
            raise ValueError(f"Insufficient shares held on {sale_date} — {remaining / factor:g} of "
                             f"{quantity:g} could not be matched")
        return [(pid, q / factor) for pid, q in taken.items()]
    finally:
        conn.close()


def set_parcel_label(db_path, parcel_id, label):
    conn = get_connection(db_path)
    try:
        conn.execute("UPDATE parcels SET label = ? WHERE id = ?", ((label or '').strip() or None, parcel_id))
        conn.commit()
    finally:
        conn.close()


def add_sale(db_path, security_id, sale_date, quantity, price_per_unit,
             brokerage=0.0, cgt_method='fifo', notes='', parcel_ids=None,
             kind='sale', allocations=None, entered_total=None, cgt_choice=None):
    """
    Record a disposal. Allocates quantity against open parcels using the
    specified method (fifo/mingain/maxgain/prorata/specific), or exactly as given in
    allocations [(parcel_id, quantity in units as at the sale date)], and calculates
    gain/loss. kind='cancellation' is a share cancellation (CGT event C2): costed like a
    sale, the payment being the capital proceeds. Returns the sale_id.
    """
    if quantity <= 0:
        raise ValueError("Quantity must be greater than zero")
    if kind not in SALE_KINDS:
        raise ValueError(f"Unknown sale kind: {kind}")
    net_proceeds = quantity * price_per_unit - brokerage
    conn = get_connection(db_path)
    try:
        _check_date_not_locked(conn, sale_date, 'sale')
        # Insert sale record
        sale_id = conn.execute(
            """INSERT INTO sales
               (security_id, sale_date, quantity, price_per_unit,
                brokerage, net_proceeds, cgt_method, notes, kind, entered_total, cgt_choice)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (security_id, sale_date, quantity, price_per_unit,
             brokerage, net_proceeds, cgt_method, notes, kind, entered_total,
             cgt_choice if cgt_choice in CGT_CHOICES else None)
        ).lastrowid
        _allocate_sale(conn, sale_id, security_id, sale_date, quantity, cgt_method, parcel_ids,
                       allocations)
        conn.commit()
        return sale_id
    finally:
        conn.close()


def _allocate_sale(conn, sale_id, security_id, sale_date, quantity, cgt_method, parcel_ids,
                   allocations=None):
    """
    Match a sale against open parcels held on the sale date, then cost it via
    _rebuild_parcel_costs. Rolls back and raises if there aren't enough shares.
    allocations: exact [(parcel_id, units as at the sale date)], overriding cgt_method.
    """
    # Sale quantities are in units as at the sale date; parcels are in today's units
    factor = _split_factor(conn, security_id, sale_date)
    remaining = quantity * factor
    touched = []
    parcels = _parcels_for_sale(conn, security_id, cgt_method, parcel_ids, sale_date)
    if allocations:
        by_id = {p['id']: p for p in parcels}
        total = sum(float(q) for _, q in allocations)
        if abs(total - quantity) > 0.0001:
            conn.rollback()
            raise ValueError(f"Parcel allocations add up to {total:g}, not the sale quantity {quantity:g}")
        plan = []
        for pid, q in allocations:
            if pid not in by_id:
                conn.rollback()
                raise ValueError(f"Parcel {pid} isn't an open parcel of this security bought on or "
                                 f"before {sale_date}")
            plan.append((by_id[pid], float(q) * factor))
    elif cgt_method == 'prorata':
        # The same proportion from every parcel held — e.g. a cancellation of 22 in every 100
        held = sum(p['quantity_remaining'] for p in parcels)
        plan = [(p, remaining * p['quantity_remaining'] / held) for p in parcels] if held > 1e-9 else []
    else:
        plan = None
    wanted = {p['id']: q for p, q in plan} if plan is not None else {}
    for parcel in (parcels if plan is None else [p for p, _ in plan]):
        if remaining <= 1e-9:
            break
        want = remaining if plan is None else min(wanted[parcel['id']], remaining)
        if plan is not None and want > parcel['quantity_remaining'] + 1e-9:
            conn.rollback()
            raise ValueError(f"The parcel bought {parcel['acquisition_date']} has only "
                             f"{parcel['quantity_remaining'] / factor:g} units left")
        sell_qty = min(want, parcel['quantity_remaining'])
        if sell_qty <= 1e-12:
            continue
        conn.execute(
            """INSERT INTO sale_parcels
               (sale_id, parcel_id, quantity_sold, cost_base_used, gain_loss, discount_eligible)
               VALUES (?, ?, ?, 0, 0, 0)""",
            (sale_id, parcel['id'], sell_qty / factor))
        conn.execute(
            "UPDATE parcels SET quantity_remaining = quantity_remaining - ? WHERE id = ?",
            (sell_qty, parcel['id']))
        touched.append(parcel['id'])
        remaining -= sell_qty
    if remaining > 0.0001:
        conn.rollback()
        raise ValueError(
            f"Insufficient shares held on {sale_date} — {remaining / factor:.4f} of {quantity:.4f} "
            "could not be matched to a purchase made on or before the sale date")
    for pid in touched:
        _rebuild_parcel_costs(conn, pid)


def get_sales(db_path, security_id=None):
    conn = get_connection(db_path)
    try:
        q = """SELECT sa.*, s.code, s.name
               FROM sales sa
               JOIN securities s ON s.id = sa.security_id"""
        params = []
        if security_id:
            q += " WHERE sa.security_id = ?"
            params.append(security_id)
        q += " ORDER BY sa.sale_date DESC, sa.id DESC"
        return [dict(r) for r in conn.execute(q, params).fetchall()]
    finally:
        conn.close()


# ── Dividends ──────────────────────────────────────────────────────────────────

def _check_45_day_rule(conn, security_id, ex_date_str, required_days=45):
    """
    ATO franking credit holding period rule.
    Returns True (eligible), False (ineligible), or None (no ex-date — cannot determine).

    Rule: shares must be held 'at risk' for AT LEAST required_days during the
    qualification period, which runs from the day after acquisition to the
    required_days-th day after the ex-dividend date. The acquisition day and
    disposal day are not counted. Only parcels acquired before the ex-dividend
    date and still held on it carry the dividend. A single parcel satisfying the
    threshold makes the dividend eligible.

    required_days=45 for ordinary shares (default), 90 for preference shares.
    Hedging/at-risk rules are not checked (assumed all shares are held at risk).
    The small shareholder exemption is applied separately (compute_fy_income).
    """
    if not ex_date_str:
        return None
    ex         = date.fromisoformat(ex_date_str)
    period_end = ex + timedelta(days=required_days)

    rows = conn.execute("""
        SELECT p.id, p.acquisition_date, p.quantity_remaining,
               MAX(s.sale_date) as last_sale_date
        FROM parcels p
        LEFT JOIN sale_parcels sp ON sp.parcel_id = p.id
        LEFT JOIN sales s ON s.id = sp.sale_id
        WHERE p.security_id = ?
          AND p.acquisition_date < ?
        GROUP BY p.id
    """, (security_id, ex.isoformat())).fetchall()

    for row in rows:
        acq = date.fromisoformat(row['acquisition_date'])
        # Use last_sale_date as disposal only when the parcel is fully consumed
        if row['quantity_remaining'] <= 1e-9 and row['last_sale_date']:
            dispose = date.fromisoformat(row['last_sale_date'])
        else:
            dispose = None  # parcel still (at least partially) open
        # Parcels disposed of before the ex-dividend date don't carry the dividend
        if dispose and dispose < ex:
            continue
        held_from = acq + timedelta(days=1)
        held_to   = (dispose - timedelta(days=1)) if (dispose and dispose <= period_end) else period_end
        days = max(0, (held_to - held_from).days + 1)
        if days >= required_days:
            return True
    return False


SMALL_SHAREHOLDER_LIMIT = 5000.0


def compute_fy_income(db_path, fy_year):
    """
    Item 11 dividend figures for the FY ending 30 June fy_year. Single source of truth
    for the CGT page, FY Tax Summary, CSV and PDF exports.

    - 11K franked amount = franked portion of each dividend (net × franking %);
      11J unfranked amount = the rest. A dividend with a franking credit but no
      franking % recorded is treated as fully franked.
    - 11L franking credits: claimable when the 45-day rule is met, or for everyone
      under the small shareholder exemption — individuals whose total franking credits
      for the year are no more than $5,000 don't need to satisfy the holding period rule.
      Without the exemption, credits failing the rule or lacking an ex-dividend date
      are excluded.
    """
    divs = get_fy_dividends(db_path, fy_year)
    entity = get_settings(db_path).get('entity_type') or 'individual'

    total_credits = sum(d['franking_credit'] or 0 for d in divs)
    exempt = entity == 'individual' and total_credits <= SMALL_SHAREHOLDER_LIMIT

    out = {'unfranked': 0.0, 'franked': 0.0, 'credits_claimable': 0.0,
           'credits_ineligible': 0.0, 'credits_unverified': 0.0,
           'credits_total': total_credits, 'small_shareholder_exempt': exempt,
           'missing_credit_count': 0, 'net_dividends': 0.0}
    for d in divs:
        net    = d['net_amount'] or 0.0
        pct    = d['franking_pct'] or 0.0
        credit = d['franking_credit'] or 0.0
        franked = net * min(pct, 100.0) / 100.0 if pct > 0 else (net if credit > 0 else 0.0)
        out['franked']       += franked
        out['unfranked']     += net - franked
        out['net_dividends'] += net
        if pct > 0 and credit <= 0:
            out['missing_credit_count'] += 1
        if exempt or d['eligible_45day'] is True:
            out['credits_claimable'] += credit
        elif d['eligible_45day'] is False:
            out['credits_ineligible'] += credit
        else:
            out['credits_unverified'] += credit
    out['assessable'] = out['unfranked'] + out['franked'] + out['credits_claimable']
    return {k: round(v, 2) if isinstance(v, float) else v for k, v in out.items()}


def add_dividend(db_path, security_id, payment_date, quantity_held,
                 amount_per_share, franking_pct=0.0, ex_date=None,
                 is_drp=0, drp_quantity=None, drp_price=None, notes='',
                 franking_credit=None):
    gross_amount = quantity_held * amount_per_share
    if franking_credit is None:
        # Never derived from a fixed company tax rate (Hard Rule 6) — the amount must come
        # from the dividend statement. Missing amounts are flagged by compute_fy_income.
        franking_credit = 0.0
    net_amount = gross_amount  # cash received (franking credit is a tax offset, not cash)

    conn = get_connection(db_path)
    try:
        _check_date_not_locked(conn, payment_date, 'dividend')
        drp_parcel_id = None
        if is_drp and drp_quantity and drp_price:
            # DRP shares get a cost base equal to the cash dividend foregone
            drp_parcel_id = conn.execute(
                """INSERT INTO parcels
                   (security_id, acquisition_date, quantity, price_per_unit,
                    brokerage, other_costs, cost_base, quantity_remaining, notes)
                   VALUES (?, ?, ?, ?, 0, 0, ?, ?, ?)""",
                (security_id, payment_date, drp_quantity, drp_price,
                 drp_quantity * drp_price, drp_quantity, 'DRP')
            ).lastrowid
            _note_linked_actions(conn, drp_parcel_id)

        div_id = conn.execute(
            """INSERT INTO dividends
               (security_id, payment_date, ex_date, quantity_held, amount_per_share,
                gross_amount, franking_pct, franking_credit, net_amount,
                is_drp, drp_quantity, drp_price, drp_parcel_id, notes)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (security_id, payment_date, ex_date, quantity_held, amount_per_share,
             gross_amount, franking_pct, franking_credit, net_amount,
             is_drp, drp_quantity, drp_price, drp_parcel_id, notes)
        ).lastrowid

        conn.commit()
        return div_id
    finally:
        conn.close()


def get_fy_dividends(db_path, fy_year):
    """Dividends paid in the FY ending 30 June fy_year, with the code/name at 30 June."""
    fy_start, fy_end = f"{fy_year - 1}-07-01", f"{fy_year}-06-30"
    divs = [d for d in get_dividends(db_path) if fy_start <= d['payment_date'] <= fy_end]
    conn = get_connection(db_path)
    try:
        return _apply_names(conn, divs, fy_end)
    finally:
        conn.close()


def get_dividends(db_path, security_id=None):
    conn = get_connection(db_path)
    try:
        q = """SELECT d.*, s.code, s.name, s.security_type
               FROM dividends d
               JOIN securities s ON s.id = d.security_id"""
        params = []
        if security_id:
            q += " WHERE d.security_id = ?"
            params.append(security_id)
        q += " ORDER BY d.payment_date DESC, d.id DESC"
        rows = [dict(r) for r in conn.execute(q, params).fetchall()]
        for row in rows:
            req = 90 if row.get('security_type') == 'preference' else 45
            row['eligible_45day'] = _check_45_day_rule(conn, row['security_id'], row.get('ex_date'), req)
        return rows
    finally:
        conn.close()


# ── CGT Summary ────────────────────────────────────────────────────────────────

def _cgt_sale_rows(db_path, fy_year):
    """
    Returns CGT data for the Australian financial year ending 30 June fy_year.
    e.g. fy_year=2025 covers 1 Jul 2024 – 30 Jun 2025.
    One row per parcel sold: quantity and net_proceeds are that parcel's share of the sale
    (sale_quantity / sale_net_proceeds are the whole sale's).
    """
    fy_start = f"{fy_year - 1}-07-01"
    fy_end   = f"{fy_year}-06-30"
    conn = get_connection(db_path)
    try:
        rows = conn.execute("""
            SELECT
                s.code, s.name, sa.security_id,
                sa.sale_date,
                sa.kind,
                sp.quantity_sold                       AS quantity,
                sa.net_proceeds * sp.quantity_sold / sa.quantity AS net_proceeds,
                COALESCE(sp.cgt_basis, CASE WHEN sp.discount_eligible THEN 'discount' ELSE 'other' END)
                                                       AS cgt_basis,
                sp.indexed_cost_base,
                p.cgt_date, p.origin,
                sa.quantity                            AS sale_quantity,
                sa.net_proceeds                        AS sale_net_proceeds,
                sp.cost_base_used,
                sp.gain_loss,
                sp.discount_eligible,
                sp.discounted_gain,
                p.acquisition_date
            FROM sale_parcels sp
            JOIN sales sa   ON sa.id = sp.sale_id
            JOIN parcels p  ON p.id  = sp.parcel_id
            JOIN securities s ON s.id = sa.security_id
            WHERE sa.sale_date BETWEEN ? AND ?
            ORDER BY sa.sale_date, s.code
        """, (fy_start, fy_end)).fetchall()
        return _apply_names(conn, [dict(r) for r in rows], fy_end)
    finally:
        conn.close()


def _roc_cgt_rows(db_path, fy_year):
    """
    Returns return-of-capital capital gains for the FY ending 30 June fy_year.
    Only rows where cost base hit zero (excess_cg > 0) are returned — these must
    be included in the CGT return. Discount eligibility is based on the parcel
    holding period at the ROC action date.
    """
    fy_start = f"{fy_year - 1}-07-01"
    fy_end   = f"{fy_year}-06-30"
    conn = get_connection(db_path)
    try:
        rows = conn.execute("""
            SELECT
                s.code, s.name, ca.security_id,
                ca.action_date,
                ca.ratio_from      AS amount_per_unit,
                ca.description,
                p.acquisition_date,
                p.cgt_date,
                p.quantity_remaining,
                rp.cost_base_reduction,
                rp.excess_cg
            FROM roc_parcels rp
            JOIN corporate_actions ca ON ca.id = rp.corporate_action_id
            JOIN parcels p            ON p.id  = rp.parcel_id
            JOIN securities s         ON s.id  = ca.security_id
            WHERE rp.excess_cg > 0.000001
              AND ca.action_date BETWEEN ? AND ?
            ORDER BY ca.action_date, s.code
        """, (fy_start, fy_end)).fetchall()
        out = _apply_names(conn, [dict(r) for r in rows if not _roc_exempt(r)], fy_end)
        for r in out:
            r['discount_eligible'] = 1 if _roc_discount_eligible(r) else 0
        return out
    finally:
        conn.close()


def _roc_exempt(r):
    """A return of capital on pre-CGT shares (or before CGT began) isn't CGT event G1."""
    return _cgt_acq(r) < CGT_START or r['action_date'] < CGT_START


def _roc_discount_eligible(r):
    """G1 gain: discount if held more than 12 months and the payment was from 21 Sep 1999.
    (Indexation isn't applied to G1 gains — assumption, see NOTES.md.)"""
    return (r['action_date'] >= INDEXATION_END and
            _held_12_months(date.fromisoformat(_cgt_acq(r)), date.fromisoformat(r['action_date'])))


CGT_EXEMPT_BASES = ('pre_cgt', 'not_cgt')


def _allocate_taxable(sale_rows, roc_rows, fyc):
    """
    Set row['taxable_gain'] so each row shows its share of Item 18A.

    Losses absorbed by each class (non-discount / discount-eligible) are spread
    pro-rata across that class's gains; the discount then applies to what remains.
    Loss rows show only the part of the loss not absorbed this year (negative),
    so in a gain year the column totals 18A, and in a loss year it totals the
    current-year net capital loss.
    """
    for r in sale_rows:
        if r.get('cgt_basis') in CGT_EXEMPT_BASES:
            r['taxable_gain'] = 0.0
    if fyc.get('exempt'):
        for r in sale_rows + roc_rows:
            r['taxable_gain'] = 0.0
        return
    sale_rows = [r for r in sale_rows if r.get('cgt_basis') not in CGT_EXEMPT_BASES]
    df = fyc['discount_factor']
    gains = [(r, r['gain_loss'], bool(r['discount_eligible'])) for r in sale_rows if r['gain_loss'] > 0]
    gains += [(r, r['excess_cg'], bool(r['discount_eligible'])) for r in roc_rows]
    class_total = {False: fyc['short_gains'] + fyc['roc_short_gains'],
                   True:  fyc['disc_gains'] + fyc['roc_disc_gains']}
    class_absorbed = {False: fyc['nondisc_losses_absorbed'], True: fyc['disc_losses_absorbed']}

    for r, g, disc in gains:
        remaining = g - class_absorbed[disc] * g / class_total[disc]
        r['taxable_gain'] = round(remaining * (1 - df) if disc else remaining, 2)
    if gains:
        # Put any rounding remainder on the largest gain so the column totals 18A exactly
        diff = round(fyc['net_capital_gain'] - sum(r['taxable_gain'] for r, _, _ in gains), 2)
        max(gains, key=lambda x: x[1])[0]['taxable_gain'] = round(
            max(gains, key=lambda x: x[1])[0]['taxable_gain'] + diff, 2)

    unabsorbed = fyc['net_capital_loss'] / fyc['total_losses'] if fyc['total_losses'] else 0.0
    for r in sale_rows:
        if r['gain_loss'] <= 0:
            r['taxable_gain'] = round(r['gain_loss'] * unabsorbed, 2) + 0.0  # avoid -0.0


def estimate_sale(db_path, security_id, sale_date, quantity, price_per_unit, brokerage=0.0,
                  cgt_method='fifo', cgt_choice=None):
    """
    What-if CGT for a proposed sale (nothing is saved). Parcels are matched exactly as
    add_sale would match them, and the sale's own gains and losses are netted per the
    ATO method (losses before discount). Other disposals in the year are not considered.
    """
    if quantity <= 0:
        raise ValueError("Quantity must be greater than zero")
    conn = get_connection(db_path)
    try:
        discount_factor = _cgt_discount_factor(conn)
        exempt = _cgt_exempt(conn)
        parcels = _parcels_for_sale(conn, security_id, cgt_method, None, sale_date)
        choice = cgt_choice if cgt_choice in CGT_CHOICES else _cgt_choice_default(conn)
    finally:
        conn.close()
    available = sum(p['quantity_remaining'] for p in parcels)
    if quantity > available + 0.0001:
        return {'insufficient': True, 'available': available}

    proceeds = quantity * price_per_unit - brokerage
    remaining, rows = quantity, []
    for p in parcels:
        if remaining <= 1e-9:
            break
        qty = min(remaining, p['quantity_remaining'])
        unit_cb = p['cost_base'] / p['quantity']
        unit_orig = (p['quantity'] * p['price_per_unit'] + (p['brokerage'] or 0)
                     + (p['other_costs'] or 0)) / p['quantity']
        indexed_cb = (unit_orig * indexation_factor(_cgt_acq(p), sale_date) - (unit_orig - unit_cb)) * qty
        cb = unit_cb * qty
        part = proceeds / quantity * qty
        basis, gl = _cgt_basis(p, sale_date, part - cb, part - indexed_cb, choice, discount_factor)
        rows.append({'acquisition_date': _cgt_acq(p), 'quantity': qty,
                     'cost_base_used': cb, 'gain_loss': gl, 'cgt_basis': basis,
                     'indexed_cost_base': indexed_cb if basis == 'indexation' else None,
                     'discount_eligible': 1 if basis == 'discount' else 0})
        remaining -= qty
    can_index = any(_cgt_acq(p) < INDEXATION_END and not _is_pre_cgt(p) for p in parcels)
    rows_taxed = [r for r in rows if r['cgt_basis'] not in CGT_EXEMPT_BASES]

    c = {'short_gains': sum(r['gain_loss'] for r in rows_taxed if r['gain_loss'] > 0 and not r['discount_eligible']),
         'disc_gains':  sum(r['gain_loss'] for r in rows_taxed if r['gain_loss'] > 0 and r['discount_eligible']),
         'roc_short_gains': 0.0, 'roc_disc_gains': 0.0}
    losses = sum(-r['gain_loss'] for r in rows_taxed if r['gain_loss'] < 0)
    res = _apply_cgt_method(c['short_gains'], c['disc_gains'], losses, 0.0, discount_factor, exempt)
    fyc = dict(c, **res, total_losses=losses, discount_factor=discount_factor)
    _allocate_taxable(rows, [], fyc)
    return {
        'insufficient':     False,
        'proceeds':         round(proceeds, 2),
        'cost_base':        round(sum(r['cost_base_used'] for r in rows), 2),
        'gross_gain':       round(sum(r['gain_loss'] for r in rows), 2),
        'discount_applied': round(res['discount_applied'], 2),
        'taxable_gain':     round(res['net_capital_gain'], 2),
        'net_loss':         round(res['net_capital_loss'], 2),
        'exempt':           exempt,
        'discount_factor':  discount_factor,
        'cgt_choice':       choice,
        'can_index':        can_index,
        'parcels':          [{k: (round(v, 2) if isinstance(v, float) and k != 'quantity' else v)
                              for k, v in r.items()} for r in rows],
    }


def _cgt_rows_with_taxable(db_path, fy_year):
    sale_rows = _cgt_sale_rows(db_path, fy_year)
    roc_rows  = _roc_cgt_rows(db_path, fy_year)
    _allocate_taxable(sale_rows, roc_rows, compute_fy_cgt(db_path, fy_year))
    return sale_rows, roc_rows


def get_cgt_summary(db_path, fy_year):
    """
    Disposal rows for the FY ending 30 June fy_year (e.g. 2025 = 1 Jul 2024 – 30 Jun 2025).
    taxable_gain is each row's share of Item 18A — losses applied before the discount.
    """
    return _cgt_rows_with_taxable(db_path, fy_year)[0]


def get_roc_cgt(db_path, fy_year):
    """Return-of-capital capital gains for the FY, with taxable_gain allocated as for disposals."""
    return _cgt_rows_with_taxable(db_path, fy_year)[1]


# ── CGT carry-forward ─────────────────────────────────────────────────────────

def _date_to_fy(date_str):
    """Return the FY year-end for a date string. '2024-08-01' → 2025, '2025-06-30' → 2025."""
    d = date.fromisoformat(date_str)
    return d.year + 1 if d.month >= 7 else d.year


def _fy_cgt_components(conn, fy_year):
    """Gross CGT components for the FY ending 30 June fy_year (no discount, no losses applied)."""
    fy_start = f"{fy_year - 1}-07-01"
    fy_end   = f"{fy_year}-06-30"
    c = {'short_gains': 0.0, 'short_losses': 0.0, 'disc_gains': 0.0, 'disc_losses': 0.0,
         'roc_short_gains': 0.0, 'roc_disc_gains': 0.0}
    for r in conn.execute("""
        SELECT sp.gain_loss, sp.discount_eligible
        FROM sale_parcels sp
        JOIN sales sa ON sa.id = sp.sale_id
        WHERE sa.sale_date BETWEEN ? AND ?
          AND COALESCE(sp.cgt_basis, '') NOT IN ('pre_cgt', 'not_cgt')
    """, (fy_start, fy_end)).fetchall():
        g = r['gain_loss'] or 0.0
        prefix = 'disc' if r['discount_eligible'] else 'short'
        if g > 0:
            c[f'{prefix}_gains'] += g
        elif g < 0:
            c[f'{prefix}_losses'] += -g
    for r in conn.execute("""
        SELECT rp.excess_cg, ca.action_date, p.acquisition_date, p.cgt_date
        FROM roc_parcels rp
        JOIN corporate_actions ca ON ca.id = rp.corporate_action_id
        JOIN parcels p            ON p.id  = rp.parcel_id
        WHERE rp.excess_cg > 0.000001
          AND ca.action_date BETWEEN ? AND ?
    """, (fy_start, fy_end)).fetchall():
        if _roc_exempt(r):
            continue
        eligible = _roc_discount_eligible(r)
        c['roc_disc_gains' if eligible else 'roc_short_gains'] += r['excess_cg']
    return c


def _apply_cgt_method(nondisc_gains, disc_gains, current_losses, prior_losses, discount_factor,
                      exempt=False):
    """
    ATO CGT method statement (Individual Tax Return Item 18):
      1. Apply current-year capital losses to gains, then prior-year net capital losses.
         Losses are applied to non-discount gains first (most favourable to the taxpayer).
      2. Apply the CGT discount only to the discount-eligible gains remaining.
      3. Net capital gain = remaining gains after discount.
    Unapplied losses carry forward. The discount is never applied before losses.

    exempt=True (SMSF in full pension phase): every gain is exempt current pension
    income and capital losses are disregarded — prior losses carry forward untouched.
    """
    if exempt:
        return {
            'current_losses_applied': 0.0, 'prior_losses_applied': 0.0,
            'nondisc_losses_absorbed': 0.0, 'disc_losses_absorbed': 0.0,
            'discount_applied': 0.0, 'exempt_amount': nondisc_gains + disc_gains,
            'net_capital_gain': 0.0, 'net_capital_loss': 0.0,
            'carry_forward_remaining': prior_losses, 'exempt': True,
        }
    def absorb(losses, nd, d):
        used = min(losses, nd); nd -= used; losses -= used
        used = min(losses, d);  d  -= used; losses -= used
        return losses, nd, d

    cur_left, nd, d     = absorb(current_losses, nondisc_gains, disc_gains)
    prior_left, nd, d   = absorb(prior_losses, nd, d)
    discount            = d * discount_factor
    return {
        'current_losses_applied': current_losses - cur_left,
        'prior_losses_applied':   prior_losses - prior_left,
        'nondisc_losses_absorbed': nondisc_gains - nd,   # all losses set against non-discount gains
        'disc_losses_absorbed':    disc_gains - d,       # all losses set against discount-eligible gains
        'discount_applied':       discount,
        'net_capital_gain':       nd + d - discount,
        'net_capital_loss':       cur_left,               # this year's unapplied losses
        'carry_forward_remaining': cur_left + prior_left,  # total to carry to next year (18V)
        'exempt_amount':          0.0,
        'exempt':                 False,
    }


def _cgt_exempt(conn):
    row = conn.execute("SELECT value FROM settings WHERE key='entity_type'").fetchone()
    return bool(row) and row['value'] == 'smsf_pension'


def compute_cgt_carryforward(db_path, fy_year):
    """
    Compute the CGT carry-forward loss balance available at the start of fy_year.

    Opening balance = cgt_carryforward_loss setting (losses predating app records).
    Iterates every FY with disposal data from the earliest through fy_year-1,
    applying the ATO method statement (losses before discount) in chronological order.

    Returns dict: carry_forward, opening_balance, first_fy, last_fy_processed.
    """
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT value FROM settings WHERE key='cgt_carryforward_loss'").fetchone()
        opening = float(row['value']) if row and row['value'] else 0.0

        discount_factor = _cgt_discount_factor(conn)

        earliest_sale = conn.execute("SELECT MIN(sale_date) FROM sales").fetchone()[0]
        earliest_roc  = conn.execute("""
            SELECT MIN(ca.action_date) FROM roc_parcels rp
            JOIN corporate_actions ca ON ca.id = rp.corporate_action_id
            WHERE rp.excess_cg > 0
        """).fetchone()[0]

        candidates = [d for d in (earliest_sale, earliest_roc) if d]
        if not candidates:
            return {'carry_forward': round(opening, 2), 'opening_balance': round(opening, 2),
                    'first_fy': None, 'last_fy_processed': None}

        first_fy = min(_date_to_fy(d) for d in candidates)
        balance  = opening

        for yr in range(first_fy, fy_year):
            c = _fy_cgt_components(conn, yr)
            res = _apply_cgt_method(
                c['short_gains'] + c['roc_short_gains'],
                c['disc_gains'] + c['roc_disc_gains'],
                c['short_losses'] + c['disc_losses'],
                balance, discount_factor, _cgt_exempt(conn))
            balance = res['carry_forward_remaining']

        return {
            'carry_forward':     round(balance, 2),
            'opening_balance':   round(opening, 2),
            'first_fy':          first_fy,
            'last_fy_processed': fy_year - 1,
        }
    finally:
        conn.close()


def compute_fy_cgt(db_path, fy_year):
    """
    Item 18 figures for the FY ending 30 June fy_year, per the ATO method statement.
    Single source of truth for the CGT page, FY Tax Summary, CSV and PDF exports.
    """
    carryforward = compute_cgt_carryforward(db_path, fy_year)['carry_forward']
    conn = get_connection(db_path)
    try:
        discount_factor = _cgt_discount_factor(conn)
        exempt = _cgt_exempt(conn)
        c = _fy_cgt_components(conn, fy_year)
    finally:
        conn.close()
    nondisc = c['short_gains'] + c['roc_short_gains']
    disc    = c['disc_gains'] + c['roc_disc_gains']
    losses  = c['short_losses'] + c['disc_losses']
    res = _apply_cgt_method(nondisc, disc, losses, carryforward, discount_factor, exempt)
    out = dict(c)
    out.update(res)
    out.update({
        'roc_gross':         c['roc_short_gains'] + c['roc_disc_gains'],
        'total_gains':       nondisc + disc,   # 18H — before discount and losses
        'total_losses':      losses,
        'carry_forward':     carryforward,     # prior-year losses available at start of FY
        'discount_factor':   discount_factor,
    })
    return {k: round(v, 2) if isinstance(v, float) else v for k, v in out.items()}


# ── Holdings at date ──────────────────────────────────────────────────────────

def _parcel_state_at(conn, p, snap_date):
    """
    (units held at end of snap_date in units as at that date, their cost base), or None if
    the parcel didn't exist yet. Undoes later sales, splits/consolidations, returns of
    capital and demergers using the same per-unit model as _rebuild_parcel_costs.
    """
    if p['acquisition_date'] > snap_date or not p['quantity']:
        return None
    created_by = conn.execute("""
        SELECT ca.action_date FROM demerger_parcels dp
        JOIN corporate_actions ca ON ca.id = dp.corporate_action_id
        WHERE dp.new_parcel_id = ?""", (p['id'],)).fetchone()
    if created_by and created_by['action_date'] > snap_date:
        return None   # demerged shares not received yet
    sec, q = p['security_id'], p['quantity']
    held_today = p['quantity_remaining'] + _units_sold_after(conn, p['id'], sec, snap_date)
    if held_today <= 1e-9:
        return None
    original = q * p['price_per_unit'] + (p['brokerage'] or 0) + (p['other_costs'] or 0)
    applied = conn.execute("""
        SELECT COALESCE(SUM(adj), 0) FROM (
            SELECT rp.cb_adjust_total AS adj FROM roc_parcels rp
            JOIN corporate_actions ca ON ca.id = rp.corporate_action_id
            WHERE rp.parcel_id = ? AND ca.action_date <= ?
            UNION ALL
            SELECT dp.cb_adjust_total FROM demerger_parcels dp
            JOIN corporate_actions ca ON ca.id = dp.corporate_action_id
            WHERE dp.original_parcel_id = ? AND ca.action_date <= ?)
    """, (p['id'], snap_date, p['id'], snap_date)).fetchone()[0]
    unit_cb = (original - applied) / q          # per unit in today's units
    return held_today / _split_factor(conn, sec, snap_date), unit_cb * held_today


def units_held_at(db_path, security_id, snapshot_date):
    """Units of a security held at the end of snapshot_date, in units as at that date."""
    conn = get_connection(db_path)
    try:
        total = 0.0
        for p in conn.execute("SELECT * FROM parcels WHERE security_id = ? AND acquisition_date <= ?",
                              (security_id, snapshot_date)).fetchall():
            state = _parcel_state_at(conn, p, snapshot_date)
            if state:
                total += state[0]
        return total
    finally:
        conn.close()


def get_holdings_at_date(db_path, snapshot_date):
    """
    Per-parcel holdings as at the end of snapshot_date.

    qty_at_date        units held on that date, in units as at that date (before any later split)
    cost_base_at_date  cost base of those units on that date (before later returns of
                       capital / demergers)
    original_quantity  the parcel's purchase quantity in units as at that date
    """
    conn = get_connection(db_path)
    try:
        out = []
        for p in conn.execute("""
            SELECT p.*, s.code, s.name, s.exchange, s.security_type
            FROM parcels p JOIN securities s ON s.id = p.security_id
            WHERE p.acquisition_date <= ?
            ORDER BY s.code, p.acquisition_date, p.id
        """, (snapshot_date,)).fetchall():
            state = _parcel_state_at(conn, p, snapshot_date)
            if not state or state[0] <= 0.0001:
                continue
            out.append({
                'security_id':       p['security_id'],
                'code':              p['code'],
                'name':              p['name'],
                'exchange':          p['exchange'],
                'security_type':     p['security_type'],
                'parcel_id':         p['id'],
                'acquisition_date':  p['acquisition_date'],
                'original_quantity': p['quantity'] / _split_factor(conn, p['security_id'], snapshot_date),
                'qty_at_date':       state[0],
                'cost_base_at_date': state[1],
            })
        return _apply_names(conn, out, snapshot_date)
    finally:
        conn.close()


# ── Cost base reconciliation ──────────────────────────────────────────────────

def get_cost_base_reconciliation(db_path, fy_year):
    """
    Per-security cost base movement for the Australian FY ending 30 June fy_year.

    Returns a list of dicts, one per security that had any holdings or activity,
    each containing opening_cb, categorised additions and reductions, computed
    closing CB, actual closing CB (from snapshot), and a reconciles flag.
    """
    fy_start  = f"{fy_year - 1}-07-01"
    fy_end    = f"{fy_year}-06-30"
    open_snap = f"{fy_year - 1}-06-30"   # proportional CB at close of prior FY

    conn = get_connection(db_path)
    try:
        def _snap_cb(snap_date):
            """Cost base per security of the units held at the end of snap_date."""
            totals = {}
            for p in conn.execute("SELECT * FROM parcels WHERE acquisition_date <= ?",
                                  (snap_date,)).fetchall():
                state = _parcel_state_at(conn, p, snap_date)
                if state and state[0] > 0.0001:
                    totals[p['security_id']] = totals.get(p['security_id'], 0.0) + state[1]
            return totals

        opening_cb = _snap_cb(open_snap)
        closing_cb = _snap_cb(fy_end)

        # ── Additions ─────────────────────────────────────────────────────────

        # IDs of parcels that are DRP / rights / bonus / demerger receipts in FY
        # (so they are excluded from the "purchases" bucket)
        drp_ids = {r[0] for r in conn.execute("""
            SELECT drp_parcel_id FROM dividends
            WHERE drp_parcel_id IS NOT NULL AND payment_date BETWEEN ? AND ?
        """, (fy_start, fy_end)).fetchall()}

        ca_ids = {r[0] for r in conn.execute("""
            SELECT parcel_id FROM corporate_actions
            WHERE parcel_id IS NOT NULL
              AND action_type IN ('rights_issue','bonus')
              AND action_date BETWEEN ? AND ?
        """, (fy_start, fy_end)).fetchall()}

        dem_new_ids = {r[0] for r in conn.execute("""
            SELECT dp.new_parcel_id FROM demerger_parcels dp
            JOIN corporate_actions ca ON ca.id = dp.corporate_action_id
            WHERE ca.action_date BETWEEN ? AND ?
        """, (fy_start, fy_end)).fetchall()}

        excluded_ids = drp_ids | ca_ids | dem_new_ids

        purchases = {}
        for r in conn.execute("""
            SELECT id, security_id, cost_base FROM parcels
            WHERE acquisition_date BETWEEN ? AND ?
        """, (fy_start, fy_end)).fetchall():
            if r['id'] not in excluded_ids:
                purchases[r['security_id']] = purchases.get(r['security_id'], 0.0) + r['cost_base']

        drp = {r['security_id']: r['total'] for r in conn.execute("""
            SELECT p.security_id, SUM(p.cost_base) AS total
            FROM parcels p JOIN dividends d ON d.drp_parcel_id = p.id
            WHERE d.payment_date BETWEEN ? AND ?
            GROUP BY p.security_id
        """, (fy_start, fy_end)).fetchall()}

        rights = {r['security_id']: r['total'] for r in conn.execute("""
            SELECT p.security_id, SUM(p.cost_base) AS total
            FROM parcels p JOIN corporate_actions ca ON ca.parcel_id = p.id
            WHERE ca.action_type = 'rights_issue' AND ca.action_date BETWEEN ? AND ?
            GROUP BY p.security_id
        """, (fy_start, fy_end)).fetchall()}

        bonus = {r['security_id']: r['total'] for r in conn.execute("""
            SELECT p.security_id, SUM(p.cost_base) AS total
            FROM parcels p JOIN corporate_actions ca ON ca.parcel_id = p.id
            WHERE ca.action_type = 'bonus' AND ca.action_date BETWEEN ? AND ?
            GROUP BY p.security_id
        """, (fy_start, fy_end)).fetchall()}

        dem_receipt = {r['security_id']: r['total'] for r in conn.execute("""
            SELECT p.security_id, SUM(dp.cost_base_transferred) AS total
            FROM demerger_parcels dp
            JOIN parcels p ON p.id = dp.new_parcel_id
            JOIN corporate_actions ca ON ca.id = dp.corporate_action_id
            WHERE ca.action_date BETWEEN ? AND ?
            GROUP BY p.security_id
        """, (fy_start, fy_end)).fetchall()}

        # ── Reductions ────────────────────────────────────────────────────────

        disposals = {r['security_id']: r['total'] for r in conn.execute("""
            SELECT sa.security_id, SUM(sp.cost_base_used) AS total
            FROM sale_parcels sp JOIN sales sa ON sa.id = sp.sale_id
            WHERE sa.sale_date BETWEEN ? AND ?
            GROUP BY sa.security_id
        """, (fy_start, fy_end)).fetchall()}

        roc_reductions = {r['security_id']: r['total'] for r in conn.execute("""
            SELECT ca.security_id, SUM(rp.cost_base_reduction) AS total
            FROM roc_parcels rp JOIN corporate_actions ca ON ca.id = rp.corporate_action_id
            WHERE ca.action_date BETWEEN ? AND ?
            GROUP BY ca.security_id
        """, (fy_start, fy_end)).fetchall()}

        demerger_out = {r['security_id']: r['total'] for r in conn.execute("""
            SELECT ca.security_id, SUM(dp.cost_base_transferred) AS total
            FROM demerger_parcels dp JOIN corporate_actions ca ON ca.id = dp.corporate_action_id
            WHERE ca.action_date BETWEEN ? AND ?
            GROUP BY ca.security_id
        """, (fy_start, fy_end)).fetchall()}

        # ── Assemble ──────────────────────────────────────────────────────────

        all_sids = (set(opening_cb) | set(closing_cb) |
                    set(purchases) | set(drp) | set(rights) | set(bonus) |
                    set(dem_receipt) | set(disposals) | set(roc_reductions) |
                    set(demerger_out))
        if not all_sids:
            return []

        names = _names_at(conn, fy_end)
        sec_info = {sid: {'code': names[sid][0], 'name': names[sid][1]}
                    for sid in all_sids if sid in names}

        result = []
        for sid in sorted(all_sids, key=lambda x: sec_info.get(x, {}).get('code', 'ZZZ')):
            open_cb  = opening_cb.get(sid, 0.0)
            close_act = closing_cb.get(sid, 0.0)

            adds = {
                'purchases':        round(purchases.get(sid, 0.0), 2),
                'drp':              round(drp.get(sid, 0.0), 2),
                'rights_issues':    round(rights.get(sid, 0.0), 2),
                'bonus_issues':     round(bonus.get(sid, 0.0), 2),
                'demerger_receipt': round(dem_receipt.get(sid, 0.0), 2),
            }
            adds['total'] = round(sum(adds.values()), 2)

            reds = {
                'disposals':         round(disposals.get(sid, 0.0), 2),
                'return_of_capital': round(roc_reductions.get(sid, 0.0), 2),
                'demerger_out':      round(demerger_out.get(sid, 0.0), 2),
            }
            reds['total'] = round(sum(reds.values()), 2)

            computed = round(open_cb + adds['total'] - reds['total'], 2)
            actual   = round(close_act, 2)

            result.append({
                'security_id':    sid,
                'code':           sec_info.get(sid, {}).get('code', '?'),
                'name':           sec_info.get(sid, {}).get('name', '?'),
                'opening_cb':     round(open_cb, 2),
                'additions':      adds,
                'reductions':     reds,
                'computed_close': computed,
                'actual_close':   actual,
                'reconciles':     abs(computed - actual) < 0.02,
            })
        return result
    finally:
        conn.close()


# ── Security edit ─────────────────────────────────────────────────────────────

def update_security(db_path, security_id, name, exchange, security_type,
                    currency, notes, is_active=1):
    if not name:
        raise ValueError("Name is required")
    conn = get_connection(db_path)
    try:
        conn.execute(
            """UPDATE securities SET name=?, exchange=?, security_type=?,
               currency=?, notes=?, is_active=? WHERE id=?""",
            (name, exchange, security_type, currency, notes, int(is_active), security_id)
        )
        # With a code/name history, a name edit corrects the entry in effect today
        conn.execute("""UPDATE security_names SET name = ? WHERE id = (
                            SELECT id FROM security_names WHERE security_id = ? AND effective_date <= ?
                            ORDER BY effective_date DESC LIMIT 1)""",
                     (name, security_id, date.today().isoformat()))
        conn.commit()
    finally:
        conn.close()


# ── Settings ───────────────────────────────────────────────────────────────────

def get_settings(db_path):
    conn = get_connection(db_path)
    try:
        return {r['key']: r['value']
                for r in conn.execute("SELECT key, value FROM settings").fetchall()}
    finally:
        conn.close()


# Settings that change how disposals are taxed: every parcel is re-costed when they change
_COSTING_SETTINGS = ('entity_type', 'indexation_default')


def set_setting(db_path, key, value):
    conn = get_connection(db_path)
    try:
        old = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
        if key in _COSTING_SETTINGS and (old['value'] if old else None) != value:
            for (pid,) in conn.execute("SELECT id FROM parcels").fetchall():
                _rebuild_parcel_costs(conn, pid)
        conn.commit()
    finally:
        conn.close()


# ── Performance summary ────────────────────────────────────────────────────────

def get_performance(db_path):
    """Aggregate portfolio performance: invested, unrealised, realised, income."""
    conn = get_connection(db_path)
    try:
        total_invested = conn.execute(
            "SELECT COALESCE(SUM(cost_base), 0) FROM parcels"
        ).fetchone()[0]

        open_cost = conn.execute(
            "SELECT COALESCE(SUM(cost_base * quantity_remaining / quantity), 0) "
            "FROM parcels WHERE quantity_remaining > 0"
        ).fetchone()[0]

        market_value = conn.execute("""
            SELECT COALESCE(SUM(p.quantity_remaining * pr.price), 0)
            FROM parcels p
            JOIN prices pr ON pr.security_id = p.security_id
            WHERE p.quantity_remaining > 0
        """).fetchone()[0]

        priced_open_cost = conn.execute("""
            SELECT COALESCE(SUM(p.cost_base * p.quantity_remaining / p.quantity), 0)
            FROM parcels p
            JOIN prices pr ON pr.security_id = p.security_id
            WHERE p.quantity_remaining > 0
        """).fetchone()[0]

        realized = conn.execute(
            "SELECT COALESCE(SUM(gain_loss), 0) FROM sale_parcels"
        ).fetchone()[0]

        dividends = conn.execute(
            "SELECT COALESCE(SUM(net_amount), 0) FROM dividends"
        ).fetchone()[0]

        unrealized = (market_value - priced_open_cost) if market_value > 0 else None
        total_return = (unrealized or 0) + realized + dividends
        return_pct = (total_return / total_invested * 100) if total_invested > 0 else None

        return {
            'total_invested': total_invested,
            'market_value': market_value,
            'unrealized': unrealized,
            'realized': realized,
            'dividends': dividends,
            'total_return': total_return,
            'return_pct': return_pct,
        }
    finally:
        conn.close()


# ── Corporate actions ──────────────────────────────────────────────────────────

def get_corporate_actions(db_path, security_id=None):
    conn = get_connection(db_path)
    try:
        q = ("""SELECT ca.*, s.code, s.name,
                       s2.code AS new_security_code, s2.name AS new_security_name
                FROM corporate_actions ca
                JOIN securities s  ON s.id  = ca.security_id
                LEFT JOIN securities s2 ON s2.id = ca.new_security_id""")
        params = []
        if security_id:
            q += " WHERE ca.security_id = ?"
            params.append(security_id)
        q += " ORDER BY ca.action_date DESC, ca.id DESC"
        return [dict(r) for r in conn.execute(q, params).fetchall()]
    finally:
        conn.close()


def _parcels_held_at(conn, security_id, action_date):
    """[(parcel_row, units_held_on_action_date)] for a return of capital or demerger —
    units in today's terms, including units sold on or after the action date (they were
    still held when it happened). Parcels from a same-day bonus/rights issue are excluded."""
    out = []
    for p in conn.execute("""
        SELECT * FROM parcels p WHERE security_id = ? AND acquisition_date <= ?
          AND NOT EXISTS (SELECT 1 FROM corporate_actions b
                          WHERE b.parcel_id = p.id AND b.action_date = ?)
        ORDER BY acquisition_date, id
    """, (security_id, action_date, action_date)).fetchall():
        held = p['quantity_remaining'] + _units_sold_after(conn, p['id'], security_id, action_date,
                                                           same_day=True)
        if held > 1e-9:
            out.append((p, held))
    return out


def apply_corporate_action(db_path, security_id, action_date, action_type,
                           ratio_from, ratio_to=0, description='', notes='',
                           new_security_id=None):
    """
    Record a corporate action and apply it.
    - split/consolidation: adjust parcel quantities, cost base unchanged.
    - bonus: ratio_from:ratio_to like a split (1 for 10 = 10:11) — the cost base is spread
      over the original and bonus shares. (ratio_to = 0: the old form, a zero-cost parcel of
      ratio_from shares, kept for importing files from earlier versions.)
    - rights_issue: ratio_from=qty, ratio_to=price. Creates a new parcel.
    - return_of_capital: ratio_from=amount_per_unit. Reduces cost base on all open
      parcels. If cost base reaches zero the excess is recorded as a capital gain
      in roc_parcels and must be included in the CGT return for this FY.
    """
    conn = get_connection(db_path)
    try:
        _check_date_not_locked(conn, action_date, 'corporate action')

        if action_type == 'demerger':
            alloc_pct   = float(ratio_from)  # % of cost base kept by original (e.g. 85)
            share_ratio = float(ratio_to)    # new shares issued per original share held
            if not (0 < alloc_pct < 100):
                raise ValueError("Original cost base allocation must be between 0 and 100")
            if share_ratio <= 0:
                raise ValueError("Share ratio must be positive")
            if not new_security_id:
                raise ValueError("Demerged security must be specified")
            new_sec = conn.execute(
                "SELECT code FROM securities WHERE id = ?", (new_security_id,)
            ).fetchone()
            if not new_sec:
                raise ValueError("Demerged security not found")
            orig_sec = conn.execute(
                "SELECT code FROM securities WHERE id = ?", (security_id,)
            ).fetchone()
            parcels = _parcels_held_at(conn, security_id, action_date)
            if not parcels:
                raise ValueError("No open parcels found for this security at the action date")

            action_id = conn.execute("""
                INSERT INTO corporate_actions
                    (security_id, action_date, action_type, description,
                     ratio_from, ratio_to, notes, new_security_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (security_id, action_date, action_type,
                  description or (f"Demerger — {alloc_pct:.1f}% retained, "
                                  f"{100 - alloc_pct:.1f}% to {new_sec['code']}"),
                  alloc_pct, share_ratio, notes, new_security_id)).lastrowid

            for p, held in parcels:
                # New parcel for the demerged entity, for the units held on the action date
                # (converted back to units as at that date if a split has happened since).
                # Acquisition date = original parcel's date (ATO requirement: CGT discount
                # clock continues from the original acquisition, not the demerger date).
                # Its cost base is set by _rebuild_parcel_costs below.
                new_qty = held / _split_factor(conn, security_id, action_date, same_day=True) * share_ratio
                new_parcel_id = conn.execute("""
                    INSERT INTO parcels
                        (security_id, acquisition_date, quantity, price_per_unit,
                         brokerage, other_costs, cost_base, quantity_remaining, notes,
                         label, cgt_date, origin)
                    VALUES (?, ?, ?, 0, 0, 0, 0, ?, ?, ?, ?, ?)
                """, (new_security_id, p['acquisition_date'], new_qty, new_qty,
                      f'Demerger from {orig_sec["code"]}', p['label'], p['cgt_date'],
                      p['origin'])).lastrowid
                conn.execute("""
                    INSERT INTO demerger_parcels
                        (corporate_action_id, original_parcel_id, new_parcel_id, cost_base_transferred)
                    VALUES (?, ?, ?, 0)
                """, (action_id, p['id'], new_parcel_id))
                _rebuild_parcel_costs(conn, p['id'])

            conn.commit()
            return action_id

        if action_type == 'return_of_capital':
            amount_per_unit = float(ratio_from)
            if amount_per_unit <= 0:
                raise ValueError("Amount per unit must be positive")
            parcels = _parcels_held_at(conn, security_id, action_date)
            if not parcels:
                raise ValueError("No open parcels found for this security at the action date")
            action_id = conn.execute("""
                INSERT INTO corporate_actions
                    (security_id, action_date, action_type, description, ratio_from, ratio_to, notes)
                VALUES (?, ?, ?, ?, ?, 0, ?)
            """, (security_id, action_date, action_type,
                  description or f"Return of Capital ${amount_per_unit:.4f}/unit",
                  amount_per_unit, notes)).lastrowid
            for p, _held in parcels:
                # Reduction / excess gain are computed per unit held on the action date
                conn.execute("""
                    INSERT INTO roc_parcels
                        (corporate_action_id, parcel_id, cost_base_reduction, excess_cg)
                    VALUES (?, ?, 0, 0)
                """, (action_id, p['id']))
                _rebuild_parcel_costs(conn, p['id'])
            conn.commit()
            return action_id

        if action_type == 'rights_issue' or (action_type == 'bonus' and not float(ratio_to or 0)):
            qty   = float(ratio_from)
            price = float(ratio_to) if action_type == 'rights_issue' else 0.0
            if qty <= 0:
                raise ValueError("Quantity must be positive")
            if action_type == 'rights_issue' and price <= 0:
                raise ValueError("Subscription price must be positive")
            cost_base = qty * price
            default_note = 'Rights Issue' if action_type == 'rights_issue' else 'Bonus Issue'
            parcel_id = conn.execute(
                """INSERT INTO parcels
                   (security_id, acquisition_date, quantity, price_per_unit,
                    brokerage, other_costs, cost_base, quantity_remaining, notes)
                   VALUES (?, ?, ?, ?, 0, 0, ?, ?, ?)""",
                (security_id, action_date, qty, price, cost_base, qty,
                 description or default_note)
            ).lastrowid
            _note_linked_actions(conn, parcel_id, issued_on=action_date)
            action_id = conn.execute(
                """INSERT INTO corporate_actions
                   (security_id, action_date, action_type, description,
                    ratio_from, ratio_to, notes, parcel_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (security_id, action_date, action_type, description,
                 qty, price, notes, parcel_id)
            ).lastrowid
            conn.commit()
            return action_id

        rf, rt = float(ratio_from), float(ratio_to)
        if rf <= 0 or rt <= 0:
            raise ValueError("Ratios must be positive numbers")
        if abs(rf - rt) < 0.0001:
            raise ValueError("ratio_from and ratio_to must be different")

        action_id = conn.execute(
            """INSERT INTO corporate_actions
               (security_id, action_date, action_type, description, ratio_from, ratio_to, notes)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (security_id, action_date, action_type, description, rf, rt, notes)
        ).lastrowid

        _apply_unit_change(conn, security_id, action_date, rf, rt)
        conn.commit()
        return action_id
    finally:
        conn.close()


def delete_corporate_action(db_path, action_id):
    """Reverse the parcel adjustments and delete the action record."""
    conn = get_connection(db_path)
    try:
        action = conn.execute(
            "SELECT * FROM corporate_actions WHERE id = ?", (action_id,)
        ).fetchone()
        if not action:
            raise ValueError("Corporate action not found")
        _check_date_not_locked(conn, action['action_date'], 'corporate action')
        old = dict(action)
        old['code'] = _sec_code(conn, old['security_id'])
        _write_audit(conn, 'delete', 'corporate_actions', action_id, old)

        if action['action_type'] == 'demerger':
            dem_rows = conn.execute(
                """SELECT original_parcel_id, new_parcel_id, cost_base_transferred
                   FROM demerger_parcels WHERE corporate_action_id = ?""",
                (action_id,)
            ).fetchall()
            # Validate before mutating
            for row in dem_rows:
                sold = conn.execute(
                    "SELECT COUNT(*) FROM sale_parcels WHERE parcel_id = ?",
                    (row['new_parcel_id'],)
                ).fetchone()[0]
                if sold:
                    raise ValueError(
                        "Cannot delete demerger — a demerged parcel has been sold. "
                        "Delete the sale first.")
            new_parcel_ids = [row['new_parcel_id'] for row in dem_rows]
            conn.execute("DELETE FROM demerger_parcels WHERE corporate_action_id = ?", (action_id,))
            for pid in new_parcel_ids:
                _delete_parcel_records(conn, pid)
            conn.execute("DELETE FROM corporate_actions WHERE id = ?", (action_id,))
            for row in dem_rows:
                _rebuild_parcel_costs(conn, row['original_parcel_id'])
            conn.commit()
            return

        if action['action_type'] == 'return_of_capital':
            roc_rows = conn.execute(
                "SELECT parcel_id FROM roc_parcels WHERE corporate_action_id = ?", (action_id,)
            ).fetchall()
            conn.execute("DELETE FROM roc_parcels WHERE corporate_action_id = ?", (action_id,))
            conn.execute("DELETE FROM corporate_actions WHERE id = ?", (action_id,))
            for row in roc_rows:
                _rebuild_parcel_costs(conn, row['parcel_id'])
            conn.commit()
            return

        if action['action_type'] == 'rights_issue' or (action['action_type'] == 'bonus'
                                                       and action['parcel_id']):
            parcel_id = action['parcel_id']
            if parcel_id:
                sold = conn.execute(
                    "SELECT COUNT(*) FROM sale_parcels WHERE parcel_id = ?", (parcel_id,)
                ).fetchone()[0]
                if sold:
                    raise ValueError(
                        "Cannot delete rights issue — parcel has been sold. Delete the sale first.")
            # Delete action first (it holds the FK reference to the parcel)
            conn.execute("DELETE FROM corporate_actions WHERE id = ?", (action_id,))
            if parcel_id:
                _delete_parcel_records(conn, parcel_id)
            conn.commit()
            return

        rf, rt = action['ratio_from'], action['ratio_to']
        conn.execute(
            """UPDATE parcels SET
                   quantity           = quantity           * ? / ?,
                   price_per_unit     = price_per_unit     * ? / ?
               WHERE security_id = ? AND acquisition_date <= ?""",
            (rf, rt,
             rt, rf,
             action['security_id'], action['action_date'])
        )
        conn.execute("DELETE FROM corporate_actions WHERE id = ?", (action_id,))
        _recompute_remaining(conn, action['security_id'])
        _rebuild_security_costs(conn, action['security_id'])
        conn.commit()
    finally:
        conn.close()


# ── Parcel edit / delete ───────────────────────────────────────────────────────

def get_parcel(db_path, parcel_id):
    conn = get_connection(db_path)
    try:
        r = conn.execute(
            "SELECT p.*, s.code, s.name FROM parcels p "
            "JOIN securities s ON s.id = p.security_id WHERE p.id = ?",
            (parcel_id,)
        ).fetchone()
        return _with_entered_units(conn, [dict(r)])[0] if r else None
    finally:
        conn.close()


_KEEP = object()


def update_parcel(db_path, parcel_id, acquisition_date, quantity, price_per_unit,
                  brokerage=0.0, other_costs=0.0, notes='', label=_KEEP, entered_total=_KEEP,
                  entered_units=False):
    """Edit a purchase. entered_units=True: quantity and price are as on the contract note
    (units as at the acquisition date) and are converted for later splits/consolidations;
    otherwise they're in today's units. label / entered_total: unchanged unless given."""
    conn = get_connection(db_path)
    try:
        existing = conn.execute("SELECT * FROM parcels WHERE id = ?", (parcel_id,)).fetchone()
        if not existing:
            raise ValueError("Parcel not found")
        _check_parcel_not_locked(conn, parcel_id)
        if entered_units:
            f = _split_factor(conn, existing['security_id'], acquisition_date, same_day=True)
            quantity, price_per_unit = float(quantity) * f, float(price_per_unit) / f
            # Unchanged figures keep their stored values exactly (no float noise from converting)
            if abs(quantity - existing['quantity']) <= 1e-9 * max(1.0, existing['quantity']):
                quantity = existing['quantity']
            if abs(price_per_unit - existing['price_per_unit']) <= 1e-9 * max(1.0, existing['price_per_unit']):
                price_per_unit = existing['price_per_unit']
        new_qty = float(quantity)
        if abs(new_qty - existing['quantity']) > 0.0001:
            sold = conn.execute(
                "SELECT COUNT(*) FROM sale_parcels WHERE parcel_id = ?", (parcel_id,)
            ).fetchone()[0]
            if sold:
                raise ValueError("Cannot change quantity of a parcel that has been (partially) sold")
        first_sale = conn.execute("""
            SELECT MIN(sa.sale_date) FROM sale_parcels sp JOIN sales sa ON sa.id = sp.sale_id
            WHERE sp.parcel_id = ?""", (parcel_id,)).fetchone()[0]
        if first_sale and acquisition_date > first_sale:
            raise ValueError(f"Acquisition date cannot be after the first sale of this parcel ({first_sale})")
        before = {a['id'] for a in _actions_from(conn, existing['security_id'], existing['acquisition_date'])}
        after  = {a['id'] for a in _actions_from(conn, existing['security_id'], acquisition_date)}
        if before != after:
            crossed = conn.execute(
                f"SELECT action_type, action_date FROM corporate_actions WHERE id IN "
                f"({','.join('?' * len(before ^ after))}) ORDER BY action_date",
                tuple(before ^ after)).fetchone()
            raise ValueError(
                f"Changing the date to {acquisition_date} moves this parcel across the "
                f"{crossed['action_type'].replace('_', ' ')} on {crossed['action_date']}. "
                "Delete that corporate action, change the date, then re-apply the action.")
        sold_qty = existing['quantity'] - existing['quantity_remaining']
        new_remaining = (existing['quantity_remaining'] if new_qty == existing['quantity']
                         else new_qty - sold_qty)
        if new_remaining < -0.0001:
            raise ValueError("New quantity is less than quantity already sold")
        cost_base = new_qty * float(price_per_unit) + float(brokerage) + float(other_costs)

        old = dict(existing)
        old['code'] = _sec_code(conn, old['security_id'])
        _write_audit(conn, 'edit', 'parcels', parcel_id, old)

        conn.execute(
            """UPDATE parcels SET
                   acquisition_date=?, quantity=?, price_per_unit=?,
                   brokerage=?, other_costs=?, cost_base=?, quantity_remaining=?, notes=?
               WHERE id=?""",
            (acquisition_date, new_qty, float(price_per_unit),
             float(brokerage), float(other_costs), cost_base, new_remaining, notes, parcel_id))
        if label is not _KEEP:
            conn.execute("UPDATE parcels SET label = ? WHERE id = ?",
                         ((label or '').strip() or None, parcel_id))
        if entered_total is not _KEEP:
            conn.execute("UPDATE parcels SET entered_total = ? WHERE id = ?", (entered_total, parcel_id))

        # Re-apply any return of capital / demerger and re-cost linked sales — editing the
        # purchase must not wipe out later cost base adjustments.
        _rebuild_parcel_costs(conn, parcel_id)
        conn.commit()
    finally:
        conn.close()


def _delete_parcel_records(conn, parcel_id):
    """
    Delete an unsold parcel with its links to returns of capital and demergers (and any
    unsold demerged parcels it received), which would otherwise block the delete.
    Raises if shares received from its demerger have been sold. Caller commits.
    """
    children = [r[0] for r in conn.execute(
        "SELECT new_parcel_id FROM demerger_parcels WHERE original_parcel_id = ?", (parcel_id,))]
    for child in children:
        if conn.execute("SELECT 1 FROM sale_parcels WHERE parcel_id = ?", (child,)).fetchone():
            raise ValueError("Shares received from a demerger of this parcel have been sold. "
                             "Delete that sale first.")
    conn.execute("DELETE FROM demerger_parcels WHERE original_parcel_id = ?", (parcel_id,))
    for child in children:
        conn.execute("DELETE FROM roc_parcels WHERE parcel_id = ?", (child,))
        conn.execute("DELETE FROM parcels WHERE id = ?", (child,))
    conn.execute("DELETE FROM roc_parcels WHERE parcel_id = ?", (parcel_id,))
    conn.execute("DELETE FROM parcels WHERE id = ?", (parcel_id,))


def delete_parcel(db_path, parcel_id):
    conn = get_connection(db_path)
    try:
        _check_parcel_not_locked(conn, parcel_id)
        sold = conn.execute(
            "SELECT COUNT(*) FROM sale_parcels WHERE parcel_id = ?", (parcel_id,)
        ).fetchone()[0]
        if sold:
            raise ValueError("Cannot delete a parcel that has been sold. Delete the sale first.")
        if conn.execute("SELECT 1 FROM demerger_parcels WHERE new_parcel_id = ?", (parcel_id,)).fetchone():
            raise ValueError("This parcel was created by a demerger — delete the demerger action instead.")
        if conn.execute("SELECT 1 FROM corporate_actions WHERE parcel_id = ?", (parcel_id,)).fetchone():
            raise ValueError("This parcel was created by a rights or bonus issue — delete that corporate action instead.")
        if conn.execute("SELECT 1 FROM dividends WHERE drp_parcel_id = ?", (parcel_id,)).fetchone():
            raise ValueError("This parcel was created by a DRP dividend — delete the dividend instead.")
        existing = conn.execute("SELECT * FROM parcels WHERE id = ?", (parcel_id,)).fetchone()
        if existing:
            old = dict(existing)
            old['code'] = _sec_code(conn, old['security_id'])
            _write_audit(conn, 'delete', 'parcels', parcel_id, old)
        _delete_parcel_records(conn, parcel_id)
        conn.commit()
    finally:
        conn.close()


# ── Sale edit / delete ─────────────────────────────────────────────────────────

def get_sale(db_path, sale_id):
    conn = get_connection(db_path)
    try:
        r = conn.execute(
            "SELECT sa.*, s.code, s.name FROM sales sa "
            "JOIN securities s ON s.id = sa.security_id WHERE sa.id = ?",
            (sale_id,)
        ).fetchone()
        return dict(r) if r else None
    finally:
        conn.close()


def _reverse_sale_allocations(conn, sale_id):
    """Restore parcel quantities consumed by a sale (converted to today's units if a
    split/consolidation happened since). Returns the affected parcel ids. Caller commits."""
    sale = conn.execute("SELECT security_id, sale_date FROM sales WHERE id = ?", (sale_id,)).fetchone()
    factor = _split_factor(conn, sale['security_id'], sale['sale_date']) if sale else 1.0
    ids = []
    for row in conn.execute(
        "SELECT parcel_id, quantity_sold FROM sale_parcels WHERE sale_id = ?", (sale_id,)
    ).fetchall():
        conn.execute(
            "UPDATE parcels SET quantity_remaining = quantity_remaining + ? WHERE id = ?",
            (row['quantity_sold'] * factor, row['parcel_id'])
        )
        ids.append(row['parcel_id'])
    conn.execute("DELETE FROM sale_parcels WHERE sale_id = ?", (sale_id,))
    return ids


def delete_sale(db_path, sale_id):
    conn = get_connection(db_path)
    try:
        sale = conn.execute("SELECT * FROM sales WHERE id = ?", (sale_id,)).fetchone()
        if sale:
            _check_date_not_locked(conn, sale['sale_date'], 'sale')
            old = dict(sale)
            old['code'] = _sec_code(conn, old['security_id'])
            _write_audit(conn, 'delete', 'sales', sale_id, old)
        touched = _reverse_sale_allocations(conn, sale_id)
        conn.execute("DELETE FROM sales WHERE id = ?", (sale_id,))
        for pid in touched:  # returns of capital after this sale now apply to more units
            _rebuild_parcel_costs(conn, pid)
        conn.commit()
    finally:
        conn.close()


def update_sale(db_path, sale_id, sale_date, quantity, price_per_unit,
                brokerage=0.0, cgt_method='fifo', notes='', parcel_ids=None,
                kind=None, allocations=None, cgt_choice=_KEEP):
    conn = get_connection(db_path)
    try:
        existing = conn.execute("SELECT * FROM sales WHERE id = ?", (sale_id,)).fetchone()
        if not existing:
            raise ValueError("Sale not found")
        security_id = existing['security_id']
        _check_date_not_locked(conn, existing['sale_date'], 'sale')
        _check_date_not_locked(conn, sale_date, 'sale')
        old = dict(existing)
        old['code'] = _sec_code(conn, security_id)
        _write_audit(conn, 'edit', 'sales', sale_id, old)

        released = _reverse_sale_allocations(conn, sale_id)

        qty = float(quantity)
        if qty <= 0:
            conn.rollback()
            raise ValueError("Quantity must be greater than zero")
        net_proceeds = qty * float(price_per_unit) - float(brokerage)
        conn.execute(
            """UPDATE sales SET
                   sale_date=?, quantity=?, price_per_unit=?,
                   brokerage=?, net_proceeds=?, cgt_method=?, notes=?, kind=COALESCE(?, kind)
               WHERE id=?""",
            (sale_date, qty, float(price_per_unit),
             float(brokerage), net_proceeds, cgt_method, notes,
             kind if kind in SALE_KINDS else None, sale_id))
        if cgt_choice is not _KEEP:
            conn.execute("UPDATE sales SET cgt_choice = ? WHERE id = ?",
                         (cgt_choice if cgt_choice in CGT_CHOICES else None, sale_id))

        _allocate_sale(conn, sale_id, security_id, sale_date, qty, cgt_method, parcel_ids,
                       allocations)
        for pid in released:
            _rebuild_parcel_costs(conn, pid)

        conn.commit()
    finally:
        conn.close()


# ── Dividend edit / delete ─────────────────────────────────────────────────────

def get_dividend(db_path, div_id):
    conn = get_connection(db_path)
    try:
        r = conn.execute(
            "SELECT d.*, s.code, s.name, s.security_type FROM dividends d "
            "JOIN securities s ON s.id = d.security_id WHERE d.id = ?",
            (div_id,)
        ).fetchone()
        if not r:
            return None
        row = dict(r)
        req = 90 if row.get('security_type') == 'preference' else 45
        row['eligible_45day'] = _check_45_day_rule(conn, row['security_id'], row.get('ex_date'), req)
        return row
    finally:
        conn.close()


def delete_dividend(db_path, div_id):
    conn = get_connection(db_path)
    try:
        div = conn.execute("SELECT * FROM dividends WHERE id = ?", (div_id,)).fetchone()
        if not div:
            return
        _check_date_not_locked(conn, div['payment_date'], 'dividend')
        drp_parcel_id = div['drp_parcel_id']
        # Check before mutating — prevent orphaned DRP parcel
        if drp_parcel_id:
            sold = conn.execute(
                "SELECT COUNT(*) FROM sale_parcels WHERE parcel_id = ?",
                (drp_parcel_id,)
            ).fetchone()[0]
            if sold:
                raise ValueError(
                    "Cannot delete this DRP dividend — its reinvestment parcel has been sold. "
                    "Delete the sale that consumed the DRP shares first, then retry.")
        old = dict(div)
        old['code'] = _sec_code(conn, old['security_id'])
        _write_audit(conn, 'delete', 'dividends', div_id, old)
        conn.execute("DELETE FROM dividends WHERE id = ?", (div_id,))
        if drp_parcel_id:
            _delete_parcel_records(conn, drp_parcel_id)
        conn.commit()
    finally:
        conn.close()


def update_dividend(db_path, div_id, payment_date, quantity_held, amount_per_share,
                    franking_pct=0.0, ex_date=None, notes='', franking_credit=None):
    gross = float(quantity_held) * float(amount_per_share)
    if franking_credit is None:
        franking_credit = 0.0  # from the dividend statement only (Hard Rule 6)
    conn = get_connection(db_path)
    try:
        existing = conn.execute("SELECT * FROM dividends WHERE id = ?", (div_id,)).fetchone()
        if existing:
            _check_date_not_locked(conn, existing['payment_date'], 'dividend')
            old = dict(existing)
            old['code'] = _sec_code(conn, old['security_id'])
            _write_audit(conn, 'edit', 'dividends', div_id, old)
        _check_date_not_locked(conn, payment_date, 'dividend')
        conn.execute(
            """UPDATE dividends SET
                   payment_date=?, ex_date=?, quantity_held=?, amount_per_share=?,
                   gross_amount=?, franking_pct=?, franking_credit=?, net_amount=?, notes=?
               WHERE id=?""",
            (payment_date, ex_date or None, float(quantity_held), float(amount_per_share),
             gross, float(franking_pct), franking_credit, gross, notes, div_id))
        conn.commit()
    finally:
        conn.close()


# ── Audit log ──────────────────────────────────────────────────────────────────

def get_audit_log(db_path, limit=200):
    conn = get_connection(db_path)
    try:
        rows = conn.execute(
            """SELECT id, timestamp, action, table_name, record_id, old_data, new_data
               FROM audit_log ORDER BY id DESC LIMIT ?""",
            (limit,)
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ── Watch list ─────────────────────────────────────────────────────────────────

def get_watchlist(db_path):
    conn = get_connection(db_path)
    try:
        rows = [dict(r) for r in conn.execute(
            """SELECT w.*, s.code, s.name, s.exchange, s.security_type,
                      d.ex_date AS latest_ex_date
               FROM watchlist w
               JOIN securities s ON s.id = w.security_id
               LEFT JOIN (
                   SELECT security_id, MAX(ex_date) AS ex_date
                   FROM dividends
                   WHERE ex_date IS NOT NULL AND ex_date != ''
                   GROUP BY security_id
               ) d ON d.security_id = w.security_id
               ORDER BY s.code"""
        ).fetchall()]
        today = date.today()
        for row in rows:
            ex_str = row.get('latest_ex_date')
            req = 90 if row.get('security_type') == 'preference' else 45
            if ex_str:
                ex = date.fromisoformat(ex_str)
                must_hold = ex + timedelta(days=req)
                alert = (today >= ex - timedelta(days=req)) and (today <= must_hold)
                row['franking_alert']   = alert
                row['must_hold_until']  = str(must_hold) if alert else None
                row['latest_ex_date']   = ex_str if alert else None
            else:
                row['franking_alert']   = False
                row['must_hold_until']  = None
                row['latest_ex_date']   = None
        return rows
    finally:
        conn.close()


def add_watchlist_item(db_path, security_id, target_buy=None, target_sell=None, notes=''):
    conn = get_connection(db_path)
    try:
        item_id = conn.execute(
            """INSERT INTO watchlist (security_id, target_buy, target_sell, notes)
               VALUES (?, ?, ?, ?)""",
            (security_id, target_buy, target_sell, notes)
        ).lastrowid
        conn.commit()
        return item_id
    finally:
        conn.close()


def update_watchlist_item(db_path, item_id, target_buy=None, target_sell=None, notes=''):
    conn = get_connection(db_path)
    try:
        conn.execute(
            "UPDATE watchlist SET target_buy=?, target_sell=?, notes=? WHERE id=?",
            (target_buy, target_sell, notes, item_id)
        )
        conn.commit()
    finally:
        conn.close()


def delete_watchlist_item(db_path, item_id):
    conn = get_connection(db_path)
    try:
        conn.execute("DELETE FROM watchlist WHERE id=?", (item_id,))
        conn.commit()
    finally:
        conn.close()
