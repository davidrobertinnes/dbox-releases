# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Investments — Database Schema and Connection Management
SQLite single-file portfolio database (.stk)
"""
import sqlite3


def get_connection(db_path):
    conn = sqlite3.connect(db_path, timeout=10)
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        conn.execute("PRAGMA journal_mode = WAL")
    except sqlite3.OperationalError:
        pass
    conn.execute("PRAGMA synchronous = NORMAL")
    conn.row_factory = sqlite3.Row
    return conn


def initialise_database(db_path):
    conn = get_connection(db_path)
    c = conn.cursor()

    c.execute("""CREATE TABLE IF NOT EXISTS settings (
        key   TEXT PRIMARY KEY,
        value TEXT)""")

    c.execute("""CREATE TABLE IF NOT EXISTS securities (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        code          TEXT NOT NULL UNIQUE,
        name          TEXT NOT NULL,
        exchange      TEXT DEFAULT 'ASX',
        security_type TEXT DEFAULT 'share',
        currency      TEXT DEFAULT 'AUD',
        notes         TEXT,
        is_active     INTEGER DEFAULT 1,
        created_at    TEXT DEFAULT (datetime('now','localtime')))""")

    # Each purchase lot = one parcel (the CGT unit of account)
    c.execute("""CREATE TABLE IF NOT EXISTS parcels (
        id                 INTEGER PRIMARY KEY AUTOINCREMENT,
        security_id        INTEGER NOT NULL REFERENCES securities(id),
        acquisition_date   TEXT NOT NULL,
        quantity           REAL NOT NULL,
        price_per_unit     REAL NOT NULL,
        brokerage          REAL DEFAULT 0,
        other_costs        REAL DEFAULT 0,
        cost_base          REAL NOT NULL,
        quantity_remaining REAL NOT NULL,
        notes              TEXT,
        created_at         TEXT DEFAULT (datetime('now','localtime')))""")

    c.execute("""CREATE TABLE IF NOT EXISTS sales (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        security_id    INTEGER NOT NULL REFERENCES securities(id),
        sale_date      TEXT NOT NULL,
        quantity       REAL NOT NULL,
        price_per_unit REAL NOT NULL,
        brokerage      REAL DEFAULT 0,
        net_proceeds   REAL NOT NULL,
        cgt_method     TEXT DEFAULT 'fifo',
        notes          TEXT,
        created_at     TEXT DEFAULT (datetime('now','localtime')))""")

    # Which parcels contributed to each sale and the resulting gain/loss
    c.execute("""CREATE TABLE IF NOT EXISTS sale_parcels (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        sale_id          INTEGER NOT NULL REFERENCES sales(id),
        parcel_id        INTEGER NOT NULL REFERENCES parcels(id),
        quantity_sold    REAL NOT NULL,
        cost_base_used   REAL NOT NULL,
        gain_loss        REAL NOT NULL,
        discount_eligible INTEGER DEFAULT 0,
        discounted_gain  REAL)""")

    c.execute("""CREATE TABLE IF NOT EXISTS dividends (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        security_id     INTEGER NOT NULL REFERENCES securities(id),
        payment_date    TEXT NOT NULL,
        ex_date         TEXT,
        quantity_held   REAL NOT NULL,
        amount_per_share REAL NOT NULL,
        gross_amount    REAL NOT NULL,
        franking_pct    REAL DEFAULT 0,
        franking_credit REAL DEFAULT 0,
        net_amount      REAL NOT NULL,
        is_drp          INTEGER DEFAULT 0,
        drp_quantity    REAL,
        drp_price       REAL,
        drp_parcel_id   INTEGER REFERENCES parcels(id),
        notes           TEXT,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    c.execute("""CREATE TABLE IF NOT EXISTS corporate_actions (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        security_id   INTEGER NOT NULL REFERENCES securities(id),
        action_date   TEXT NOT NULL,
        action_type   TEXT NOT NULL,
        description   TEXT,
        ratio_from    REAL,
        ratio_to      REAL,
        notes         TEXT,
        parcel_id     INTEGER REFERENCES parcels(id),
        created_at    TEXT DEFAULT (datetime('now','localtime')))""")

    # Migration: add parcel_id to existing databases
    try:
        c.execute("ALTER TABLE corporate_actions ADD COLUMN parcel_id INTEGER REFERENCES parcels(id)")
        conn.commit()
    except Exception:
        pass

    # Per-parcel record of cost base reductions from return-of-capital actions.
    # Enables accurate reversal and CGT reporting of any excess gain.
    c.execute("""CREATE TABLE IF NOT EXISTS roc_parcels (
        id                  INTEGER PRIMARY KEY AUTOINCREMENT,
        corporate_action_id INTEGER NOT NULL REFERENCES corporate_actions(id),
        parcel_id           INTEGER NOT NULL REFERENCES parcels(id),
        cost_base_reduction REAL NOT NULL,
        excess_cg           REAL DEFAULT 0)""")

    # Per-parcel record of cost base reallocations from demerger actions.
    # original_parcel_id: the parent company parcel whose cost base was reduced.
    # new_parcel_id: the matching parcel created for the demerged entity.
    c.execute("""CREATE TABLE IF NOT EXISTS demerger_parcels (
        id                    INTEGER PRIMARY KEY AUTOINCREMENT,
        corporate_action_id   INTEGER NOT NULL REFERENCES corporate_actions(id),
        original_parcel_id    INTEGER NOT NULL REFERENCES parcels(id),
        new_parcel_id         INTEGER NOT NULL REFERENCES parcels(id),
        cost_base_transferred REAL NOT NULL)""")

    # Migration: add new_security_id to existing databases
    try:
        c.execute("ALTER TABLE corporate_actions ADD COLUMN new_security_id INTEGER REFERENCES securities(id)")
        conn.commit()
    except Exception:
        pass

    # cb_adjust_total: change applied to parcels.cost_base (per-unit reduction × parcel quantity)
    for tbl in ('roc_parcels', 'demerger_parcels'):
        try:
            c.execute(f"ALTER TABLE {tbl} ADD COLUMN cb_adjust_total REAL DEFAULT 0")
            conn.commit()
        except Exception:
            pass

    # kind: 'sale' or 'cancellation' (shares cancelled by the company for a payment —
    # CGT event C2, costed exactly like a sale)
    try:
        c.execute("ALTER TABLE sales ADD COLUMN kind TEXT DEFAULT 'sale'")
        conn.commit()
    except Exception:
        pass

    # 1.1.0 columns:
    #   parcels.label          user's name for a parcel (not unique), used to pick parcels in imports
    #   parcels.entered_total  total cost as typed (excluding brokerage), if a total was entered
    #   parcels.cgt_date       date used for the CGT discount, indexation and pre-CGT status
    #                          (NULL = acquisition_date); set for inherited shares
    #   parcels.origin         'purchase' or 'inherited'
    #   sales.entered_total    total proceeds as typed (before brokerage), if a total was entered
    #   sales.cgt_choice       'discount' / 'indexation' / NULL (portfolio default)
    #   sale_parcels.cgt_basis 'discount' / 'indexation' / 'other' / 'pre_cgt' / 'not_cgt'
    #   sale_parcels.indexed_cost_base  cost base after indexation (indexation basis only)
    for tbl, col in (('parcels', 'label TEXT'), ('parcels', 'entered_total REAL'),
                     ('parcels', 'cgt_date TEXT'), ('parcels', "origin TEXT DEFAULT 'purchase'"),
                     ('sales', 'entered_total REAL'), ('sales', 'cgt_choice TEXT'),
                     ('sale_parcels', 'cgt_basis TEXT'),
                     ('sale_parcels', 'indexed_cost_base REAL')):
        try:
            c.execute(f"ALTER TABLE {tbl} ADD COLUMN {col}")
            conn.commit()
        except Exception:
            pass

    # Dated code/name history (e.g. WPL → WDS). A row applies from effective_date until the
    # next row; the first row has effective_date '' (from the start). No rows = the code and
    # name in securities have never changed. securities.code/name always hold today's.
    c.execute("""CREATE TABLE IF NOT EXISTS security_names (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        security_id    INTEGER NOT NULL REFERENCES securities(id),
        effective_date TEXT NOT NULL,
        code           TEXT NOT NULL,
        name           TEXT NOT NULL,
        UNIQUE (security_id, effective_date))""")

    c.execute("""CREATE TABLE IF NOT EXISTS prices (
        security_id  INTEGER PRIMARY KEY REFERENCES securities(id),
        price        REAL NOT NULL,
        fetched_at   TEXT)""")

    c.execute("""CREATE TABLE IF NOT EXISTS watchlist (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        security_id  INTEGER NOT NULL UNIQUE REFERENCES securities(id),
        target_buy   REAL,
        target_sell  REAL,
        notes        TEXT,
        created_at   TEXT DEFAULT (datetime('now','localtime')))""")

    c.execute("""CREATE TABLE IF NOT EXISTS audit_log (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        action     TEXT NOT NULL,
        table_name TEXT NOT NULL,
        record_id  INTEGER NOT NULL,
        old_data   TEXT NOT NULL,
        new_data   TEXT)""")

    conn.commit()
    conn.close()

    from .portfolio import run_migrations
    run_migrations(db_path)
