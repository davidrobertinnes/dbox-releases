# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Choosing the local port the app's web server runs on.

Each app has a default port (or one set by the user). If another program already has it,
the app tries the next few ports instead of failing, or opening a window onto the other
program. Our own servers answer GET /api/alive with {"app": "<app id>", ...}, which is how
a launch tells a copy of itself apart from anything else.

This file is the same in every Dogbox app repo — change them together.
"""

import json
import socket
from concurrent.futures import ThreadPoolExecutor
import time
import urllib.request

SPAN = 10   # the preferred port and the next 9


def _connect_host(host):
    return '127.0.0.1' if host in ('0.0.0.0', '', '::') else host


def is_listening(host, port, timeout=0.1):
    # Loopback only: a listening server answers in about a millisecond. A port with nothing
    # on it takes the whole timeout on Windows (it retries), so keep this short.
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(timeout)
        try:
            s.connect((_connect_host(host), port))
            return True
        except OSError:
            return False


def can_bind(host, port):
    """True if this process could listen on host:port now (it's free and not reserved)."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind((host, port))
            return True
        except OSError:
            return False


def identify(host, port, timeout=2.0):
    """The data from /api/alive if a server answers there with JSON, else None."""
    url = f"http://{_connect_host(host)}:{port}/api/alive"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            body = json.loads(r.read().decode('utf-8', 'replace') or 'null')
    except Exception:
        return None
    if not isinstance(body, dict) or not body.get('ok'):
        return None
    data = body.get('data')
    return data if isinstance(data, dict) else {}


def choose_port(host, preferred, is_ours, span=SPAN):
    """
    Pick the port to use, starting at `preferred`.
    Returns (port, already_running): already_running is True when one of our own servers
    (is_ours(alive_data) is true) answers on that port — open a window on it instead of
    starting another. Otherwise the port is the first free one. Raises RuntimeError if
    every port in the range is taken.
    """
    last = min(preferred + span - 1, 65535)
    candidates = list(range(preferred, last + 1))
    with ThreadPoolExecutor(max_workers=len(candidates)) as pool:
        listening = dict(zip(candidates, pool.map(lambda p: is_listening(host, p), candidates)))
    free = None
    for port in candidates:
        if listening[port]:
            info = identify(host, port)
            if info is not None and is_ours(info):
                return port, True
        elif free is None and can_bind(host, port):
            free = port
    if free is None:
        raise RuntimeError(f"Ports {preferred}-{last} are all in use by other programs. "
                           f"Start with --port and a different number, e.g. --port {preferred + 1000}")
    return free, False


def wait_until_free(host, port, seconds=10.0):
    """After a restart: wait for the old server to let go of the port. True once it's free."""
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if not is_listening(host, port) and can_bind(host, port):
            return True
        time.sleep(0.2)
    return False


def load_port(conf_path):
    """The port saved in a JSON config file, or None."""
    try:
        with open(conf_path, encoding='utf-8') as f:
            port = json.load(f).get('port')
        return int(port) if port and 1024 <= int(port) <= 65535 else None
    except Exception:
        return None


def save_port(conf_path, port):
    """Save (or with None, clear) the port in a JSON config file, keeping other settings."""
    try:
        with open(conf_path, encoding='utf-8') as f:
            conf = json.load(f)
        if not isinstance(conf, dict):
            conf = {}
    except Exception:
        conf = {}
    if port is None:
        conf.pop('port', None)
    else:
        port = int(port)
        if not 1024 <= port <= 65535:
            raise ValueError("Choose a port from 1024 to 65535")
        conf['port'] = port
    with open(conf_path, 'w', encoding='utf-8') as f:
        json.dump(conf, f, indent=2)


# ── Finding another Dogbox app (e.g. Accounting <-> Mailman) ─────────────────

_found = {}   # app id -> (port, time found)


def find_app(app_id, default_port, span=SPAN, cache_seconds=60.0):
    """The port another Dogbox app answers on (it may have moved off its default port
    because of a clash), or None if it isn't running. Remembered for a minute."""
    hit = _found.get(app_id)
    if hit and time.monotonic() - hit[1] < cache_seconds:
        if is_listening('127.0.0.1', hit[0]):
            return hit[0]
    candidates = list(range(default_port, min(default_port + span - 1, 65535) + 1))
    with ThreadPoolExecutor(max_workers=len(candidates)) as pool:
        listening = list(pool.map(lambda p: is_listening('127.0.0.1', p), candidates))
    for port, up in zip(candidates, listening):
        if up and (identify('127.0.0.1', port) or {}).get('app') == app_id:
            _found[app_id] = (port, time.monotonic())
            return port
    _found.pop(app_id, None)
    return None
