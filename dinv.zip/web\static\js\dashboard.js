// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Securities — Dashboard */

async function pageDashboard() {
  const content = document.getElementById('module-content');

  try {
    const [holdings, dividends, sales, prices, perf, parcels, watchlist] = await Promise.all([
      apiFetch('/api/holdings'),
      apiFetch('/api/dividends'),
      apiFetch('/api/sales'),
      apiFetch('/api/prices'),
      apiFetch('/api/performance'),
      apiFetch('/api/parcels'),
      apiFetch('/api/watchlist'),
    ]);

    // Financial year bounds for "this FY" income
    const today = new Date();
    const fyStart = today.getMonth() >= 6
      ? `${today.getFullYear()}-07-01`
      : `${today.getFullYear() - 1}-07-01`;

    const totalCost  = holdings.reduce((s, h) => s + (h.total_cost_base || 0), 0);
    const incomeAllTime = dividends.reduce((s, d) => s + (d.net_amount || 0), 0);
    const incomeFy   = dividends
      .filter(d => d.payment_date >= fyStart)
      .reduce((s, d) => s + (d.net_amount || 0), 0);

    let totalMktVal = 0, pricedCount = 0;
    holdings.forEach(h => {
      const p = prices[h.security_id];
      if (p) { totalMktVal += p.price * h.total_quantity; pricedCount++; }
    });
    const totalPnl    = pricedCount > 0 ? totalMktVal - totalCost : null;
    const totalPnlPct = totalPnl !== null && totalCost > 0 ? totalPnl / totalCost * 100 : null;

    // Recent activity — merge buys, sells, divs; take last 8
    const secMap = {};
    holdings.forEach(h => { secMap[h.security_id] = h.code; });

    const recent = [
      ...parcels
        .filter(p => secMap[p.security_id])
        .map(p => ({ date: p.acquisition_date, type: 'Buy', code: secMap[p.security_id], desc: `Bought ${fmtNum(p.quantity, 0)} @ ${fmtCurrency(p.price_per_unit)}`, amount: p.cost_base })),
      ...sales.map(s => ({ date: s.sale_date, type: 'Sell', code: s.code, desc: `Sold ${fmtNum(s.quantity, 0)} @ ${fmtCurrency(s.price_per_unit)}`, amount: s.net_proceeds })),
      ...dividends.map(d => ({ date: d.payment_date, type: 'Dividend', code: d.code, desc: `${fmtNum(d.quantity_held, 0)} shares @ ${fmtCurrency(d.amount_per_share, 4)}/sh`, amount: d.net_amount })),
    ].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 8);

    const typeColor = { Buy: 'var(--accent)', Sell: 'var(--amber)', Dividend: 'var(--green)' };
    const typeBadge = { Buy: 'badge-accent', Sell: 'badge-amber', Dividend: 'badge-green' };

    // Watch list signals
    const buySignals      = watchlist.filter(w => { const p = prices[w.security_id]; return p && w.target_buy  !== null && p.price <= w.target_buy; });
    const sellSignals     = watchlist.filter(w => { const p = prices[w.security_id]; return p && w.target_sell !== null && p.price >= w.target_sell; });
    const frankingSignals = watchlist.filter(w => w.franking_alert);
    const watchAlertHtml = (buySignals.length || sellSignals.length || frankingSignals.length) ? `
    <div style="margin-bottom:16px;padding:14px 18px;background:var(--surface2);border:1px solid var(--border);border-radius:10px">
      <div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;color:var(--ink3);margin-bottom:10px">Watch List Alerts</div>
      <div style="display:flex;flex-wrap:wrap;gap:8px">
        ${buySignals.map(w => `
        <div style="display:flex;align-items:center;gap:8px;padding:7px 12px;background:var(--green-dim);border-radius:8px;cursor:pointer" onclick="navigate('watchlist')">
          <span style="font-weight:700;color:var(--accent);font-size:13px">${w.code}</span>
          <span class="badge badge-green" style="font-size:10px">Buy zone</span>
          <span style="font-family:'DM Mono',monospace;font-size:12px;color:var(--green)">${fmtCurrency(prices[w.security_id].price)}</span>
          <span style="font-size:11px;color:var(--ink3)">≤ ${fmtCurrency(w.target_buy)}</span>
        </div>`).join('')}
        ${sellSignals.map(w => `
        <div style="display:flex;align-items:center;gap:8px;padding:7px 12px;background:var(--red-dim);border-radius:8px;cursor:pointer" onclick="navigate('watchlist')">
          <span style="font-weight:700;color:var(--accent);font-size:13px">${w.code}</span>
          <span class="badge badge-red" style="font-size:10px">Sell zone</span>
          <span style="font-family:'DM Mono',monospace;font-size:12px;color:var(--red)">${fmtCurrency(prices[w.security_id].price)}</span>
          <span style="font-size:11px;color:var(--ink3)">≥ ${fmtCurrency(w.target_sell)}</span>
        </div>`).join('')}
        ${frankingSignals.map(w => `
        <div style="display:flex;align-items:center;gap:8px;padding:7px 12px;background:var(--amber-dim);border-radius:8px;cursor:pointer" onclick="navigate('watchlist')">
          <span style="font-weight:700;color:var(--accent);font-size:13px">${w.code}</span>
          <span class="badge badge-amber" style="font-size:10px">Franking</span>
          <span style="font-size:11px;color:var(--amber)">Hold until ${fmtDate(w.must_hold_until)}</span>
          <span style="font-size:11px;color:var(--ink3)">ex-div ${fmtDate(w.latest_ex_date)}</span>
        </div>`).join('')}
      </div>
    </div>` : '';

    content.innerHTML = `
      <div style="display:flex;justify-content:flex-end;margin-bottom:8px">
        <button class="btn btn-secondary btn-sm" id="dash-refresh-btn" onclick="_dashRefreshPrices()">Refresh Prices</button>
      </div>
      ${watchAlertHtml}
      <div class="st-kpi-strip">
        <div class="st-kpi">
          <div class="st-kpi-label">Open Positions</div>
          <div class="st-kpi-value col-accent">${holdings.length}</div>
          <div class="st-kpi-sub">${holdings.length !== 1 ? 'securities' : 'security'} held</div>
        </div>
        <div class="st-kpi">
          <div class="st-kpi-label">Cost Base</div>
          <div class="st-kpi-value col-ink">${fmtCurrency(totalCost)}</div>
          <div class="st-kpi-sub">total invested</div>
        </div>
        ${pricedCount > 0 ? `
        <div class="st-kpi">
          <div class="st-kpi-label">Market Value</div>
          <div class="st-kpi-value col-ink">${fmtCurrency(totalMktVal)}</div>
          <div class="st-kpi-sub">${pricedCount} of ${holdings.length} priced</div>
        </div>
        <div class="st-kpi">
          <div class="st-kpi-label">Unrealised P&amp;L</div>
          <div class="st-kpi-value ${gainClass(totalPnl)}">${fmtCurrency(totalPnl)}</div>
          <div class="st-kpi-sub">${totalPnlPct !== null ? (totalPnlPct >= 0 ? '+' : '') + totalPnlPct.toFixed(2) + '%' : ''}</div>
        </div>` : ''}
        <div class="st-kpi">
          <div class="st-kpi-label">Dividend Income</div>
          <div class="st-kpi-value col-green">${fmtCurrency(incomeFy)}</div>
          <div class="st-kpi-sub">this financial year</div>
        </div>
        ${sales.length ? `
        <div class="st-kpi">
          <div class="st-kpi-label">Disposals</div>
          <div class="st-kpi-value col-ink">${sales.length}</div>
          <div class="st-kpi-sub">${fmtCurrency(sales.reduce((s,x)=>s+x.net_proceeds,0))} proceeds</div>
        </div>` : ''}
      </div>

      ${perf && perf.total_invested > 0 ? `
      <div class="st-section" style="margin-top:4px"><div class="st-section-title">Total Return</div><div class="st-section-line"></div></div>
      <div class="st-list-panel" style="margin-bottom:20px;padding:14px 18px">
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px">
          <div>
            <div style="font-size:11px;color:var(--ink3);font-weight:500;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Total Invested</div>
            <div style="font-family:'DM Mono',monospace;font-size:16px;font-weight:600;color:var(--ink)">${fmtCurrency(perf.total_invested)}</div>
          </div>
          ${perf.unrealized !== null ? `<div>
            <div style="font-size:11px;color:var(--ink3);font-weight:500;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Unrealised P&amp;L</div>
            <div style="font-family:'DM Mono',monospace;font-size:16px;font-weight:600" class="${gainClass(perf.unrealized)}">${fmtCurrency(perf.unrealized)}</div>
          </div>` : ''}
          <div>
            <div style="font-size:11px;color:var(--ink3);font-weight:500;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Realised Gains</div>
            <div style="font-family:'DM Mono',monospace;font-size:16px;font-weight:600" class="${gainClass(perf.realized)}">${fmtCurrency(perf.realized)}</div>
          </div>
          <div>
            <div style="font-size:11px;color:var(--ink3);font-weight:500;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Dividends</div>
            <div style="font-family:'DM Mono',monospace;font-size:16px;font-weight:600;color:var(--green)">${fmtCurrency(perf.dividends)}</div>
          </div>
          <div style="border-left:2px solid var(--border);padding-left:14px">
            <div style="font-size:11px;color:var(--ink3);font-weight:500;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Total Return</div>
            <div style="font-family:'DM Mono',monospace;font-size:20px;font-weight:700" class="${gainClass(perf.total_return)}">${fmtCurrency(perf.total_return)}</div>
            ${perf.return_pct !== null ? `<div style="font-size:12px" class="${gainClass(perf.return_pct)}">${perf.return_pct >= 0 ? '+' : ''}${perf.return_pct.toFixed(2)}%</div>` : ''}
          </div>
        </div>
      </div>` : ''}

      ${holdings.length ? `
      <div style="display:grid;grid-template-columns:1fr 320px;gap:20px;align-items:start">

        <div>
          <div class="st-section"><div class="st-section-title">Holdings</div><div class="st-section-line"></div></div>
          <div class="st-list-panel">
            <div class="tbl-overflow">
              <table class="st-table">
                <thead><tr>
                  <th>Code</th><th>Name</th>
                  <th class="num">Qty</th>
                  <th class="num">Cost Base</th>
                  <th class="num">Mkt Value</th>
                  <th class="num">P&amp;L</th>
                </tr></thead>
                <tbody>
                  ${holdings.map(h => {
                    const p = prices[h.security_id];
                    const mv   = p ? fmtCurrency(p.price * h.total_quantity) : '<span style="color:var(--ink3)">—</span>';
                    const pnl  = p ? h.total_quantity * p.price - h.total_cost_base : null;
                    const pnlHtml = pnl !== null
                      ? `<span class="${gainClass(pnl)}">${fmtCurrency(pnl)}</span>`
                      : '<span style="color:var(--ink3)">—</span>';
                    return `<tr style="cursor:pointer" onclick="navigate('portfolio')">
                      <td class="code-cell">${h.code}</td>
                      <td>${h.name}</td>
                      <td class="num mono">${fmtNum(h.total_quantity, 4)}</td>
                      <td class="num mono">${fmtCurrency(h.total_cost_base)}</td>
                      <td class="num mono">${mv}</td>
                      <td class="num mono">${pnlHtml}</td>
                    </tr>`;
                  }).join('')}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div>
          <div class="st-section"><div class="st-section-title">Recent Activity</div><div class="st-section-line"></div></div>
          ${recent.length ? `
          <div class="st-list-panel">
            ${recent.map(a => `
            <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--border)">
              <span class="badge ${typeBadge[a.type]}" style="flex-shrink:0">${a.type}</span>
              <div style="flex:1;min-width:0">
                <div style="font-weight:600;font-size:13px">${a.code}</div>
                <div style="font-size:11px;color:var(--ink3)">${a.desc}</div>
              </div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-family:'DM Mono',monospace;font-size:12px;font-weight:500;color:${typeColor[a.type]}">${fmtCurrency(a.amount)}</div>
                <div style="font-size:10px;color:var(--ink3)">${fmtDate(a.date)}</div>
              </div>
            </div>`).join('')}
          </div>` : `<div style="padding:20px 14px;color:var(--ink3);font-size:12px">No recent activity</div>`}

          ${pricedCount === 0 && holdings.length > 0 ? `
          <div style="margin-top:16px">
            <div class="st-section"><div class="st-section-title">Prices</div><div class="st-section-line"></div></div>
            <div style="padding:14px;background:var(--accent-dim);border-radius:8px;font-size:12px;color:var(--ink2)">
              No prices loaded. Click <strong>Refresh Prices</strong> above to fetch current prices.
            </div>
          </div>` : ''}
        </div>

      </div>` : `
      <div class="st-empty" style="margin-top:40px">
        <div class="st-empty-icon">📈</div>
        <div class="st-empty-title">Welcome to Dogbox Investments</div>
        <div>Add securities and record your first purchase to get started.</div>
      </div>`}`;

  } catch (e) {
    content.innerHTML = `<div class="st-empty"><div class="st-empty-title">Error</div><div>${e.message}</div></div>`;
  }
}

async function _dashRefreshPrices() {
  const btn = document.getElementById('dash-refresh-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Refreshing…'; }
  try {
    await fetch('/api/prices/refresh', { method: 'POST' }).then(r => r.json());
    toast('Prices updated');
    await pageDashboard();
  } catch (e) {
    toast('Price refresh failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Refresh Prices'; }
  }
}
