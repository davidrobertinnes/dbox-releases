# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Investments — version check and in-app update.

Same model as Dogbox Accounting: dinv_version.json in dbox-releases names the latest
version, its release notes and the zip URL. Updates download that zip, back up every
file about to be replaced into backups/pre-<timestamp>/, copy the new files over the
install folder (portfolio files are never touched), then the app restarts itself.
"""
import os, sys, json, time, shutil, zipfile, tempfile, threading, subprocess, urllib.request

INSTALL_DIR   = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
_VERSION_FILE = os.path.join(INSTALL_DIR, 'version.txt')
APP_VERSION   = open(_VERSION_FILE).read().strip() if os.path.exists(_VERSION_FILE) else 'dev'
UPDATE_URL    = 'https://raw.githubusercontent.com/davidrobertinnes/dbox-releases/main/dinv_version.json'
# Downloads are only ever taken from the release repo, whatever the manifest says
_ALLOWED_PREFIXES = ('https://github.com/davidrobertinnes/dbox-releases/',
                     'https://raw.githubusercontent.com/davidrobertinnes/dbox-releases/')

_SKIP_DIRS  = {'backups', '.git', '__pycache__', '.chrome-profile', 'scratch'}
_SKIP_FILES = {'desktop.ini', 'thumbs.db', 'startup.log', 'restart.log'}

_cache    = {}
progress  = {'state': 'idle', 'pct': 0, 'error': None}


def _vtuple(v):
    return tuple(int(x) for x in (v or '').split('.') if x.isdigit())


def _skip_file(name):
    n = name.lower()
    return n in _SKIP_FILES or n.endswith('.dinv') or n.endswith('.bak') or '.dinv-' in n


def check(force=False):
    """Latest release info, cached for a day. Never raises — offline just means no update."""
    now = time.time()
    if force or not _cache or now - _cache.get('checked_at', 0) > 86400:
        try:
            with urllib.request.urlopen(UPDATE_URL, timeout=5) as r:
                data = json.loads(r.read())
            _cache.clear()
            _cache.update({**data, 'checked_at': now})
        except Exception:
            _cache['checked_at'] = now
    latest = _cache.get('version')
    return {
        'current':          APP_VERSION,
        'latest':           latest,
        'update_available': APP_VERSION != 'dev' and _vtuple(latest) > _vtuple(APP_VERSION),
        'notes':            _cache.get('notes', ''),
    }


def _prune_backups(keep=2):
    root = os.path.join(INSTALL_DIR, 'backups')
    if not os.path.isdir(root):
        return
    for old in sorted((e for e in os.listdir(root) if e.startswith('pre-')), reverse=True)[keep:]:
        shutil.rmtree(os.path.join(root, old), ignore_errors=True)


def _apply(url):
    backup_dir = None
    try:
        with tempfile.TemporaryDirectory() as tmp:
            zip_path = os.path.join(tmp, 'update.zip')

            def _hook(count, block, total):
                if total > 0:
                    progress['pct'] = min(int(count * block * 100 / total), 90)

            urllib.request.urlretrieve(url, zip_path, _hook)
            progress.update({'state': 'applying', 'pct': 91})

            extract_dir = os.path.join(tmp, 'x')
            with zipfile.ZipFile(zip_path) as zf:
                names = zf.namelist()
                # Files may sit at the zip root or inside a single top-level folder
                tops = {n.split('/')[0] for n in names}
                prefix = (tops.pop() + '/') if len(tops) == 1 and 'invest.py' not in names else ''
                if prefix + 'invest.py' not in names:
                    raise ValueError('Downloaded file is not a Dogbox Investments release')
                for m in zf.infolist():
                    rel = m.filename[len(prefix):] if prefix else m.filename
                    parts = rel.split('/')
                    if not rel or any(p in _SKIP_DIRS or p == '..' for p in parts) or os.path.isabs(rel):
                        continue
                    m.filename = rel
                    zf.extract(m, extract_dir)

            new_files = []
            for root, dirs, files in os.walk(extract_dir):
                dirs[:] = [d for d in dirs if d not in _SKIP_DIRS]
                rel_root = os.path.relpath(root, extract_dir)
                new_files += [os.path.join(rel_root, f) for f in files if not _skip_file(f)]

            # Back up only the files about to be replaced, before touching anything
            backup_dir = os.path.join(INSTALL_DIR, 'backups', f'pre-{int(time.time())}')
            os.makedirs(backup_dir, exist_ok=True)
            progress.update({'state': 'applying', 'pct': 93})
            for rel in new_files:
                existing = os.path.join(INSTALL_DIR, rel)
                if os.path.exists(existing):
                    bak = os.path.join(backup_dir, rel)
                    os.makedirs(os.path.dirname(bak), exist_ok=True)
                    shutil.copy2(existing, bak)

            progress.update({'state': 'applying', 'pct': 96})
            for rel in new_files:
                dst = os.path.join(INSTALL_DIR, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(os.path.join(extract_dir, rel), dst)

        _prune_backups()
        progress.update({'state': 'done', 'pct': 100})
    except Exception as e:
        # Best-effort restore before reporting the failure
        if backup_dir and os.path.isdir(backup_dir):
            try:
                for root, _dirs, files in os.walk(backup_dir):
                    rel_root = os.path.relpath(root, backup_dir)
                    for f in files:
                        dst = os.path.join(INSTALL_DIR, rel_root, f)
                        os.makedirs(os.path.dirname(dst), exist_ok=True)
                        shutil.copy2(os.path.join(root, f), dst)
            except Exception:
                pass
        progress.update({'state': 'error', 'error': str(e)})


def start_update():
    """Download and apply the release named in the cached manifest (never a client-supplied URL)."""
    url = _cache.get('url', '')
    if not url.startswith(_ALLOWED_PREFIXES):
        raise ValueError('No update available')
    if progress['state'] in ('downloading', 'applying'):
        raise ValueError('An update is already in progress')
    progress.update({'state': 'downloading', 'pct': 0, 'error': None})
    threading.Thread(target=_apply, args=(url,), daemon=True).start()


def restart(db_path, host, port):
    """Start a fresh invest.py for the same portfolio and port, then exit this process.
    The new process waits for the port to free up and doesn't open another window —
    the existing window reloads itself once the new server answers."""
    def _go():
        time.sleep(0.4)
        cmd = [sys.executable, os.path.join(INSTALL_DIR, 'invest.py'),
               db_path, '--port', str(port), '--host', host]
        env = {**os.environ, 'DINV_RESTART': '1', 'PYTHONUTF8': '1'}
        log_path = os.path.join(INSTALL_DIR, 'restart.log')
        try:
            with open(log_path, 'w') as log:
                log.write(f'cmd: {cmd}\n')
                log.flush()
                kwargs = dict(env=env, cwd=INSTALL_DIR, stdout=log, stderr=log)
                if sys.platform == 'win32':
                    kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP
                else:
                    kwargs['start_new_session'] = True
                subprocess.Popen(cmd, **kwargs)
        except Exception as e:
            with open(log_path, 'a') as log:
                log.write(f'Popen failed: {e}\n')
        time.sleep(0.2)
        os._exit(0)
    threading.Thread(target=_go, daemon=True).start()
