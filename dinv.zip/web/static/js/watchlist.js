// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — Watch List */

async function pageWatchlist() {
  const content = document.getElementById('module-content');
  content.innerHTML = `
    <div class="st-toolbar">
      <button class="btn btn-primary" onclick="_wlOpenForm(null)">+ Add to Watch List</button>
      <button class="btn btn-secondary" id="wl-refresh-btn" onclick="_wlRefreshPrices()">Refresh Prices</button>
    </div>
    <div class="st-list-panel">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Code</th><th>Name</th>
            <th class="num">Current Price</th>
            <th class="num">Target Buy</th>
            <th class="num">Target Sell</th>
            <th>Signal</th><th>Rec.</th><th>Franking Alert</th><th>Notes</th><th></th>
          </tr></thead>
          <tbody id="wl-tbody"></tbody>
        </table>
      </div>
    </div>
    <div class="count-pill" id="wl-count"></div>`;
  await _wlLoad();
}

let _wlRows        = [];
let _wlSecurities  = [];
let _wlPrices      = {};
let _wlHeldIds     = new Set();
let _wlHoldingsMap = {};    // security_id → holding object
let _wlHistories   = {};
let _wlIndexHist   = [];
let _wlScores      = {};
let _wlAnalyseId   = null;  // watchlist item id currently open in analyser

async function _wlLoad() {
  try {
    let holdings;
    [_wlRows, _wlSecurities, _wlPrices, holdings] = await Promise.all([
      apiFetch('/api/watchlist'),
      apiFetch('/api/securities'),
      apiFetch('/api/prices'),
      apiFetch('/api/holdings'),
    ]);
    _wlHeldIds     = new Set(holdings.map(h => h.security_id));
    _wlHoldingsMap = Object.fromEntries(holdings.map(h => [h.security_id, h]));

    // Auto-add any held securities not yet on watchlist
    const watchedSecIds = new Set(_wlRows.map(r => r.security_id));
    const unwatched = holdings.filter(h => !watchedSecIds.has(h.security_id));
    if (unwatched.length) {
      await Promise.all(unwatched.map(h =>
        fetch('/api/watchlist', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ security_id: h.security_id, target_buy: null, target_sell: null, notes: '' }),
        }).then(r => r.json())
      ));
      _wlRows = await apiFetch('/api/watchlist');
    }

    _wlRender();
    _wlFetchAllRecs();
  } catch (e) {
    toast(e.message, 'err');
  }
}

async function _wlRefreshPrices() {
  const btn = document.getElementById('wl-refresh-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Refreshing…'; }
  try {
    await fetch('/api/prices/refresh', { method: 'POST' }).then(r => r.json());
    _wlHistories = {}; _wlIndexHist = []; _wlScores = {};
    toast('Prices updated');
    await pageWatchlist();
  } catch (e) {
    toast('Price refresh failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Refresh Prices'; }
  }
}

// ── Shared scoring ─────────────────────────────────────────────────────────────

function _wlComputeScore(price, targetBuy, targetSell, stockHist, indexHist) {
  if (!stockHist || !stockHist.length) return { score: null, verdict: null, signals: [] };

  function perfPct(hist, days) {
    if (hist.length < 2) return null;
    const latest = hist[hist.length - 1].price;
    const past   = hist[Math.max(0, hist.length - 1 - days)].price;
    return past > 0 ? (latest - past) / past * 100 : null;
  }
  function sma(hist, n) {
    const sl = hist.slice(-n);
    return sl.length >= n ? sl.reduce((s, x) => s + x.price, 0) / sl.length : null;
  }
  function fmtP(n) { return n === null ? 'n/a' : (n >= 0 ? '+' : '') + n.toFixed(1) + '%'; }

  const s1m  = perfPct(stockHist, 21);  const i1m = indexHist.length ? perfPct(indexHist, 21)  : null;
  const s3m  = perfPct(stockHist, 63);  const i3m = indexHist.length ? perfPct(indexHist, 63)  : null;
  const s6m  = perfPct(stockHist, 126); const i6m = indexHist.length ? perfPct(indexHist, 126) : null;
  const ma20 = sma(stockHist, 20);
  const ma50 = sma(stockHist, 50);

  let score = 0;
  const signals = [];

  if (price !== null && targetBuy  !== null && price <= targetBuy)
    { score += 2; signals.push({ label: `Price (${fmtCurrency(price)}) at or below target buy (${fmtCurrency(targetBuy)})`, type: 'pos' }); }
  if (price !== null && targetSell !== null && price >= targetSell)
    { score -= 2; signals.push({ label: `Price (${fmtCurrency(price)}) at or above target sell (${fmtCurrency(targetSell)})`, type: 'neg' }); }

  function evalPeriod(s, i, label) {
    if (s === null) return;
    if (i !== null && s > i + 1.0)      { score += 1; signals.push({ label: `${label}: outperformed All Ords (${fmtP(s)} vs ${fmtP(i)})`, type: 'pos' }); }
    else if (i !== null && s < i - 1.0) { score -= 1; signals.push({ label: `${label}: underperformed All Ords (${fmtP(s)} vs ${fmtP(i)})`, type: 'neg' }); }
    else                                 {             signals.push({ label: `${label}: in line with All Ords (${fmtP(s)}${i !== null ? ' vs ' + fmtP(i) : ''})`, type: 'neu' }); }
  }
  evalPeriod(s1m, i1m, '1 month');
  evalPeriod(s3m, i3m, '3 months');
  evalPeriod(s6m, i6m, '6 months');

  if (ma20 !== null && ma50 !== null) {
    if (ma20 > ma50)      { score += 1; signals.push({ label: `Uptrend — 20-day MA (${fmtCurrency(ma20)}) above 50-day MA (${fmtCurrency(ma50)})`, type: 'pos' }); }
    else if (ma20 < ma50) { score -= 1; signals.push({ label: `Downtrend — 20-day MA (${fmtCurrency(ma20)}) below 50-day MA (${fmtCurrency(ma50)})`, type: 'neg' }); }
  }

  const verdict = score >= 2 ? 'BUY' : score <= -2 ? 'SELL' : 'HOLD';
  return { score, verdict, signals };
}

function _wlRecBadge(verdict) {
  if (!verdict) return '<span style="color:var(--ink3);font-size:11px">…</span>';
  const col = verdict === 'BUY' ? 'var(--green)' : verdict === 'SELL' ? 'var(--red)' : 'var(--amber)';
  return `<span style="font-size:11px;font-weight:700;color:${col}">${verdict}</span>`;
}

function _wlRowBg(verdict) {
  if (verdict === 'BUY')  return 'background:color-mix(in srgb,var(--green) 8%,transparent)';
  if (verdict === 'SELL') return 'background:color-mix(in srgb,var(--red)   8%,transparent)';
  return '';
}

async function _wlFetchAllRecs() {
  if (!_wlRows.length) return;
  const results = await Promise.allSettled([
    apiFetch('/api/prices/index-history?ticker=%5EAORD&period=1y'),
    ..._wlRows.map(w => apiFetch(`/api/prices/history?security_id=${w.security_id}&period=1y`)),
  ]);
  _wlIndexHist = results[0].status === 'fulfilled' ? results[0].value : [];
  _wlRows.forEach((w, i) => {
    const hist  = results[i + 1].status === 'fulfilled' ? results[i + 1].value : [];
    _wlHistories[w.security_id] = hist;
    const price = (_wlPrices[w.security_id] ?? {}).price ?? null;
    _wlScores[w.id] = _wlComputeScore(price, w.target_buy, w.target_sell, hist, _wlIndexHist);
    const { verdict } = _wlScores[w.id];
    const cell = document.getElementById(`wl-rec-${w.id}`);
    if (cell) cell.innerHTML = (!hist.length && price === null)
      ? '<span style="color:var(--ink3);font-size:11px">—</span>'
      : _wlRecBadge(verdict);
    const row = document.getElementById(`wl-row-${w.id}`);
    if (row) row.style.cssText = _wlRowBg(verdict);
  });
}

// ── Render ─────────────────────────────────────────────────────────────────────

function _wlSignal(price, targetBuy, targetSell) {
  if (price === null) return { label: '—', priceStyle: 'color:var(--ink3)' };
  if (targetBuy  !== null && price <= targetBuy)  return { label: 'Buy zone',  priceStyle: 'color:var(--green);font-weight:600' };
  if (targetSell !== null && price >= targetSell) return { label: 'Sell zone', priceStyle: 'color:var(--red);font-weight:600' };
  return { label: 'Watching', priceStyle: '' };
}

function _wlDist(price, target, direction) {
  if (price === null || target === null) return '';
  const diff = direction === 'buy' ? price - target : target - price;
  const pct  = Math.abs(diff / target * 100);
  if (diff <= 0) return `<div style="font-size:10px;color:var(--${direction === 'buy' ? 'green' : 'red'});margin-top:1px">in zone</div>`;
  const sign = direction === 'buy' ? '↓' : '↑';
  const col  = direction === 'buy' ? 'var(--amber)' : 'var(--green)';
  return `<div style="font-size:10px;color:${col};margin-top:1px">${sign} ${fmtCurrency(diff)} (${pct.toFixed(1)}%)</div>`;
}

function _wlRender() {
  const tbody = document.getElementById('wl-tbody');
  if (!_wlRows.length) {
    tbody.innerHTML = `<tr><td colspan="10"><div class="st-empty">
      <div class="st-empty-icon">👁</div>
      <div class="st-empty-title">Watch list is empty</div>
      <div>Add securities to track target buy and sell prices.</div>
    </div></td></tr>`;
    document.getElementById('wl-count').textContent = '0 items';
    return;
  }
  tbody.innerHTML = _wlRows.map(w => {
    const p        = _wlPrices[w.security_id];
    const price    = p ? p.price : null;
    const sig      = _wlSignal(price, w.target_buy, w.target_sell);
    const sigStyle = sig.label === 'Buy zone'  ? 'color:var(--green);font-weight:600'
                   : sig.label === 'Sell zone' ? 'color:var(--red);font-weight:600'
                   :                             'color:var(--ink3)';
    const frankingCell = w.franking_alert
      ? `<span class="badge badge-amber" style="font-size:10px" title="Ex-div ${fmtDate(w.latest_ex_date)} — hold 45 days to claim franking credits">Hold until ${fmtDate(w.must_hold_until)}</span>`
      : `<span style="color:var(--ink3)">—</span>`;
    const cached   = _wlScores[w.id];
    const recCell  = cached ? _wlRecBadge(cached.verdict) : '<span style="color:var(--ink3);font-size:11px">…</span>';
    const rowBg    = cached ? _wlRowBg(cached.verdict) : '';
    const heldBadge = _wlHeldIds.has(w.security_id)
      ? `<div style="margin-top:2px"><span class="badge badge-accent" style="font-size:9px;padding:1px 5px">HELD</span></div>`
      : '';
    return `<tr id="wl-row-${w.id}" style="${rowBg}">
      <td class="code-cell">${w.code}${heldBadge}</td>
      <td>${w.name}</td>
      <td class="num mono" style="${sig.priceStyle}">${price !== null ? fmtCurrency(price) : '—'}</td>
      <td class="num mono">${w.target_buy  !== null ? fmtCurrency(w.target_buy)  + _wlDist(price, w.target_buy,  'buy')  : '—'}</td>
      <td class="num mono">${w.target_sell !== null ? fmtCurrency(w.target_sell) + _wlDist(price, w.target_sell, 'sell') : '—'}</td>
      <td style="font-size:12px;${sigStyle}">${sig.label}</td>
      <td id="wl-rec-${w.id}">${recCell}</td>
      <td style="font-size:12px">${frankingCell}</td>
      <td style="font-size:12px;color:var(--ink3)">${w.notes || ''}</td>
      <td style="white-space:nowrap">
        <button class="btn btn-ghost btn-sm" onclick="_wlAnalyse(${w.id})">Analyse</button>
        <button class="btn btn-ghost btn-sm" onclick="_wlOpenForm(${w.id})">Edit</button>
        <button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="_wlDelete(${w.id})">Del</button>
      </td>
    </tr>`;
  }).join('');
  document.getElementById('wl-count').textContent =
    `${_wlRows.length} item${_wlRows.length !== 1 ? 's' : ''}`;
}

// ── Edit form ──────────────────────────────────────────────────────────────────

function _wlOpenForm(id) {
  const w         = id ? _wlRows.find(r => r.id === id) : null;
  const isEdit    = !!w;
  const available = isEdit
    ? _wlSecurities
    : _wlSecurities.filter(s => s.is_active && !_wlRows.find(r => r.security_id === s.id));
  const secOptions = available.map(s =>
    `<option value="${s.id}" ${w && s.id === w.security_id ? 'selected' : ''}>${s.code} — ${s.name}</option>`
  ).join('');
  openPanel(isEdit ? `Edit Watch — ${w.code}` : 'Add to Watch List', `
    <div class="field">
      <label>Security</label>
      <select id="wl-security" ${isEdit ? 'disabled' : ''}>
        <option value="">Select…</option>${secOptions}
      </select>
    </div>
    <div class="field-row cols-2">
      <div class="field">
        <label>Target Buy ($) <span style="font-weight:400;text-transform:none;letter-spacing:0">signal when price ≤ this</span></label>
        <input type="number" id="wl-buy" min="0" step="any" value="${w?.target_buy ?? ''}" placeholder="optional">
      </div>
      <div class="field">
        <label>Target Sell ($) <span style="font-weight:400;text-transform:none;letter-spacing:0">signal when price ≥ this</span></label>
        <input type="number" id="wl-sell" min="0" step="any" value="${w?.target_sell ?? ''}" placeholder="optional">
      </div>
    </div>
    <div class="field">
      <label>Notes</label>
      <textarea id="wl-notes" placeholder="Optional">${w?.notes || ''}</textarea>
    </div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_wlSave(${id || 'null'})">${isEdit ? 'Save Changes' : 'Add to Watch List'}</button>`
  );
}

async function _wlSave(id) {
  const security_id = id
    ? _wlRows.find(r => r.id === id)?.security_id
    : document.getElementById('wl-security').value;
  const target_buy  = document.getElementById('wl-buy').value  || null;
  const target_sell = document.getElementById('wl-sell').value || null;
  const notes       = document.getElementById('wl-notes').value;
  if (!security_id) return toast('Select a security', 'err');
  const url    = id ? `/api/watchlist/${id}` : '/api/watchlist';
  const method = id ? 'PUT' : 'POST';
  const body   = id ? { target_buy, target_sell, notes } : { security_id, target_buy, target_sell, notes };
  try {
    const r = await fetch(url, {
      method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel(); toast(id ? 'Watch item updated' : 'Added to watch list');
    await _wlLoad();
  } catch (e) { toast(e.message, 'err'); }
}

async function _wlDelete(id) {
  const w = _wlRows.find(r => r.id === id);
  if (!confirm(`Remove ${w?.code || 'this security'} from watch list?`)) return;
  try {
    const r = await fetch(`/api/watchlist/${id}`, { method: 'DELETE' }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    toast('Removed from watch list'); await _wlLoad();
  } catch (e) { toast(e.message, 'err'); }
}

// ── Analyser — entry point ──────────────────────────────────────────────────────

function _wlAnalyse(id) {
  _wlAnalyseId = id;
  const w       = _wlRows.find(r => r.id === id);
  if (!w) return;
  const price   = (_wlPrices[w.security_id] ?? {}).price ?? null;
  const holding = _wlHoldingsMap[w.security_id] || null;
  const held    = !!holding;

  const entryDefault = w.target_buy  !== null ? w.target_buy  : (price ?? '');
  const exitDefault  = w.target_sell !== null ? w.target_sell : '';

  // ── Portfolio market value (for balance tab) ──────────────────────────
  let portfolioMV = 0;
  for (const h of Object.values(_wlHoldingsMap)) {
    const p = (_wlPrices[h.security_id] ?? {}).price;
    if (p) portfolioMV += h.total_quantity * p;
  }

  // ── Divest: holding period ────────────────────────────────────────────
  let daysHeld = 0, holdingPeriodLabel = '';
  if (held && holding.earliest_acquisition) {
    daysHeld = Math.floor((Date.now() - new Date(holding.earliest_acquisition).getTime()) / 86400000);
    const yrs  = Math.floor(daysHeld / 365);
    const mos  = Math.floor((daysHeld % 365) / 30);
    holdingPeriodLabel = yrs > 0 ? `${yrs}y ${mos}m` : `${mos}m`;
  }
  const discountEligible = daysHeld > 365;

  openPanel(`Analyse — ${w.code}`, `
    <div class="wl-scen-tabs">
      <button id="wl-tab-build"   class="wl-scen-tab active" onclick="_wlScenTab('build')">Build / Acquire</button>
      <button id="wl-tab-balance" class="wl-scen-tab" onclick="_wlScenTab('balance')" ${!held ? 'disabled title="No current holding"' : ''}>Balance / Maintain</button>
      <button id="wl-tab-divest"  class="wl-scen-tab" onclick="_wlScenTab('divest')"  ${!held ? 'disabled title="No current holding"' : ''}>Divest / Sell</button>
    </div>

    <!-- ── BUILD ─────────────────────────────────────────────────────── -->
    <div id="wl-scen-build">
      ${held ? `<div class="wl-an-section" style="margin-bottom:12px">
        <div class="wl-an-title">Current Position</div>
        <div class="wl-an-row"><span class="wl-an-label">Quantity held</span><span class="mono">${fmtNum(holding.total_quantity, 0)}</span></div>
        <div class="wl-an-row"><span class="wl-an-label">Avg cost</span><span class="mono">${fmtCurrency(holding.avg_cost)}</span></div>
        <div class="wl-an-row"><span class="wl-an-label">Total cost base</span><span class="mono">${fmtCurrency(holding.total_cost_base)}</span></div>
        ${price !== null ? `<div class="wl-an-row"><span class="wl-an-label">Market value</span>
          <span class="mono" style="color:${price >= holding.avg_cost ? 'var(--green)' : 'var(--red)'}">${fmtCurrency(holding.total_quantity * price)}</span></div>` : ''}
      </div>` : ''}
      <div class="wl-an-section">
        <div class="wl-an-title">New Purchase</div>
        <div class="field-row cols-2">
          <div class="field"><label>Cash Reserve ($)</label>
            <input type="number" id="an-cash" min="0" step="any" value="10000" oninput="_wlBuildUpdate()"></div>
          <div class="field"><label>Entry Price ($)</label>
            <input type="number" id="an-entry" min="0" step="any" value="${entryDefault}" oninput="_wlBuildUpdate()" placeholder="e.g. 1.50"></div>
        </div>
        <div class="field-row cols-2">
          <div class="field"><label>Brokerage — Buy ($)</label>
            <input type="number" id="an-buy-brok" min="0" step="any" value="9.95" oninput="_wlBuildUpdate()"></div>
          <div class="field"><label>Brokerage — Sell ($)</label>
            <input type="number" id="an-sell-brok" min="0" step="any" value="9.95" oninput="_wlBuildUpdate()"></div>
        </div>
        <div class="field"><label>Target Exit Price ($) <span style="font-weight:400;text-transform:none;letter-spacing:0">optional</span></label>
          <input type="number" id="an-exit" min="0" step="any" value="${exitDefault}" oninput="_wlBuildUpdate()" placeholder="optional"></div>
      </div>
      <div id="an-build-results"></div>
    </div>

    <!-- ── BALANCE ───────────────────────────────────────────────────── -->
    <div id="wl-scen-balance" style="display:none">
      ${!held ? '<div style="color:var(--ink3);font-size:13px;padding:20px 0 0">No current position — use Build to plan an entry.</div>' : `
      <div class="wl-an-section">
        <div class="wl-an-title">Portfolio Parameters</div>
        <div class="field-row cols-2">
          <div class="field"><label>Cash Available ($)</label>
            <input type="number" id="an-bal-cash" min="0" step="any" value="0" oninput="_wlBalanceUpdate()"></div>
          <div class="field"><label>Cash Buffer (%)</label>
            <input type="number" id="an-bal-buffer" min="0" max="100" step="any" value="10" oninput="_wlBalanceUpdate()"></div>
        </div>
        <div style="font-size:11px;color:var(--ink3);margin-top:4px">Cash earns nothing and carries no risk — set a buffer to keep as reserve.</div>
      </div>
      <div id="an-balance-results"></div>`}
    </div>

    <!-- ── DIVEST ────────────────────────────────────────────────────── -->
    <div id="wl-scen-divest" style="display:none">
      ${!held ? '<div style="color:var(--ink3);font-size:13px;padding:20px 0 0">No current position to divest.</div>' : `
      <div class="wl-an-section" style="margin-bottom:12px">
        <div class="wl-an-title">Current Position</div>
        <div class="wl-an-row"><span class="wl-an-label">Quantity held</span><span class="mono">${fmtNum(holding.total_quantity, 0)}</span></div>
        <div class="wl-an-row"><span class="wl-an-label">Avg cost</span><span class="mono">${fmtCurrency(holding.avg_cost)}</span></div>
        <div class="wl-an-row"><span class="wl-an-label">Holding period</span>
          <span class="mono">${holdingPeriodLabel} ${discountEligible ? '<span style="color:var(--green);font-size:10px">CGT discount eligible</span>' : '<span style="color:var(--amber);font-size:10px">No CGT discount yet</span>'}</span></div>
      </div>
      <div class="wl-an-section">
        <div class="wl-an-title">Liquidation Plan</div>
        <div class="field-row cols-2">
          <div class="field"><label>Qty to Sell</label>
            <input type="number" id="an-div-qty" min="1" step="1" value="${holding.total_quantity}" oninput="_wlDivestUpdate(${w.security_id},${discountEligible ? 1 : 0})"></div>
          <div class="field"><label>Over (weeks)</label>
            <input type="number" id="an-div-weeks" min="1" step="1" value="4" oninput="_wlDivestUpdate(${w.security_id},${discountEligible ? 1 : 0})"></div>
        </div>
        <div class="field-row cols-2">
          <div class="field"><label>Exit Price ($)</label>
            <input type="number" id="an-div-price" min="0" step="any" value="${price ?? ''}" oninput="_wlDivestUpdate(${w.security_id},${discountEligible ? 1 : 0})" placeholder="current price"></div>
          <div class="field"><label>Brokerage / Trade ($)</label>
            <input type="number" id="an-div-brok" min="0" step="any" value="9.95" oninput="_wlDivestUpdate(${w.security_id},${discountEligible ? 1 : 0})"></div>
        </div>
        <div class="field"><label>Marginal Tax Rate (%)</label>
          <input type="number" id="an-div-rate" min="0" max="100" step="any" value="32.5" oninput="_wlDivestUpdate(${w.security_id},${discountEligible ? 1 : 0})"></div>
      </div>
      <div id="an-divest-results"></div>`}
    </div>

    <!-- ── MARKET ANALYSIS ───────────────────────────────────────────── -->
    <div class="wl-an-section" style="margin-top:20px">
      <div class="wl-an-title">
        Market Analysis
        <span style="font-weight:400;font-size:10px;color:var(--ink3);text-transform:none;letter-spacing:0"> vs All Ords (^AORD)</span>
      </div>
      <div id="an-rec" style="color:var(--ink3);font-size:12px;padding:8px 0">Loading…</div>
    </div>`,
    `<button class="btn btn-ghost" onclick="closePanel()">Close</button>`
  );

  _wlBuildUpdate();
  if (held) { _wlBalanceUpdate(); _wlDivestUpdate(w.security_id, discountEligible); }
  _wlShowRecommendation(w, price);
}

function _wlScenTab(tab) {
  ['build', 'balance', 'divest'].forEach(t => {
    const el  = document.getElementById(`wl-scen-${t}`);
    const btn = document.getElementById(`wl-tab-${t}`);
    if (el)  el.style.display = t === tab ? '' : 'none';
    if (btn) btn.classList.toggle('active', t === tab);
  });
}

// ── Build / Acquire scenario ───────────────────────────────────────────────────

function _wlBuildUpdate() {
  const cash     = parseFloat(document.getElementById('an-cash')?.value)     || 0;
  const entry    = parseFloat(document.getElementById('an-entry')?.value)    || 0;
  const buyBrok  = parseFloat(document.getElementById('an-buy-brok')?.value) || 0;
  const sellBrok = parseFloat(document.getElementById('an-sell-brok')?.value)|| 0;
  const exitVal  = document.getElementById('an-exit')?.value;
  const exitP    = exitVal ? parseFloat(exitVal) : null;
  const out      = document.getElementById('an-build-results');
  if (!out) return;
  if (!cash || !entry) { out.innerHTML = ''; return; }

  const maxQty    = Math.max(0, Math.floor((cash - buyBrok) / entry));
  const totalCost = maxQty * entry + (maxQty > 0 ? buyBrok : 0);
  const remaining = cash - totalCost;
  const breakEven = maxQty > 0 ? (totalCost + sellBrok) / maxQty : 0;
  const beGain    = entry > 0 ? (breakEven - entry) / entry * 100 : 0;
  const utilPct   = cash > 0 ? totalCost / cash * 100 : 0;

  const w       = _wlRows.find(r => r.id === _wlAnalyseId);
  const holding = w ? _wlHoldingsMap[w.security_id] : null;

  let blendHtml = '';
  if (holding && maxQty > 0) {
    const newTotalQty  = holding.total_quantity + maxQty;
    const newTotalCost = holding.total_cost_base + totalCost;
    const newAvg       = newTotalCost / newTotalQty;
    const newBE        = (newTotalCost + sellBrok) / newTotalQty;
    blendHtml = `
      <div class="wl-an-section" style="margin-top:12px">
        <div class="wl-an-title">Blended Position After Purchase</div>
        <div class="wl-an-row"><span class="wl-an-label">New total quantity</span><span class="mono">${fmtNum(newTotalQty, 0)}</span></div>
        <div class="wl-an-row"><span class="wl-an-label">New avg cost</span><span class="mono">${fmtCurrency(newAvg)} <span style="color:var(--ink3);font-size:11px">(was ${fmtCurrency(holding.avg_cost)})</span></span></div>
        <div class="wl-an-row"><span class="wl-an-label">New total cost base</span><span class="mono">${fmtCurrency(newTotalCost)}</span></div>
        <div class="wl-an-row"><span class="wl-an-label">New break-even</span><span class="mono">${fmtCurrency(newBE)}</span></div>
      </div>`;
  }

  let exitHtml = '';
  if (exitP && !isNaN(exitP) && maxQty > 0) {
    const proceeds = maxQty * exitP - sellBrok;
    const profit   = proceeds - totalCost;
    const pct      = profit / totalCost * 100;
    const col      = profit >= 0 ? 'var(--green)' : 'var(--red)';
    const sign     = profit >= 0 ? '+' : '';
    exitHtml = `<div class="wl-an-row" style="border-top:1px solid var(--border);margin-top:6px;padding-top:8px">
      <span class="wl-an-label">P&amp;L at exit target (${fmtCurrency(exitP)})</span>
      <span class="mono" style="color:${col};font-weight:600">${sign}${fmtCurrency(profit)} <span style="font-size:11px">(${sign}${pct.toFixed(2)}%)</span></span>
    </div>`;
  }

  out.innerHTML = `
    <div class="wl-an-section" style="margin-top:12px">
      <div class="wl-an-title">Purchase Plan</div>
      <div class="wl-an-row"><span class="wl-an-label">Max shares to buy</span><span class="mono" style="font-weight:600">${fmtNum(maxQty, 0)}</span></div>
      <div class="wl-an-row"><span class="wl-an-label">Total cost (incl. brokerage)</span><span class="mono">${fmtCurrency(totalCost)}</span></div>
      <div class="wl-an-row"><span class="wl-an-label">Cash remaining</span>
        <span class="mono" style="color:${remaining >= 0 ? 'var(--ink)' : 'var(--red)'}">${fmtCurrency(remaining)} <span style="color:var(--ink3);font-size:11px">(${utilPct.toFixed(1)}% of reserve deployed)</span></span>
      </div>
      <div class="wl-an-row"><span class="wl-an-label">Break-even sell price</span>
        <span class="mono">${fmtCurrency(breakEven)} <span style="color:var(--ink3);font-size:11px">(+${beGain.toFixed(2)}% from entry)</span></span>
      </div>
      ${exitHtml}
    </div>
    ${blendHtml}`;
}

// ── Balance / Maintain scenario ────────────────────────────────────────────────

function _wlBalanceUpdate() {
  const cashInput  = parseFloat(document.getElementById('an-bal-cash')?.value)   || 0;
  const bufferPct  = parseFloat(document.getElementById('an-bal-buffer')?.value) ?? 10;
  const out        = document.getElementById('an-balance-results');
  if (!out) return;

  // Build list of held stocks with current market values
  const heldStocks = Object.values(_wlHoldingsMap).map(h => {
    const price = (_wlPrices[h.security_id] ?? {}).price ?? null;
    return { ...h, price, marketValue: price !== null ? h.total_quantity * price : null };
  });

  const knownMV    = heldStocks.reduce((s, h) => s + (h.marketValue ?? 0), 0);
  const totalPort  = knownMV + cashInput;
  const cashTarget = totalPort * bufferPct / 100;
  const investable = Math.max(0, totalPort - cashTarget);
  const numHeld    = heldStocks.filter(h => h.marketValue !== null).length;
  const targetEach = numHeld > 0 ? investable / numHeld : 0;

  const cashDelta  = cashInput - cashTarget;  // positive = excess cash to deploy, negative = need to raise cash

  const rowsHtml = heldStocks.map(h => {
    if (h.marketValue === null) return '';
    const curr    = h.marketValue;
    const currPct = totalPort > 0 ? curr / totalPort * 100 : 0;
    const targPct = totalPort > 0 ? targetEach / totalPort * 100 : 0;
    const delta   = targetEach - curr;
    const action  = Math.abs(delta) < 1 ? 'Hold'
                  : delta > 0            ? `BUY ${fmtCurrency(delta)}`
                  :                        `SELL ${fmtCurrency(-delta)}`;
    const col     = Math.abs(delta) < 1 ? 'var(--ink3)'
                  : delta > 0            ? 'var(--green)' : 'var(--red)';
    const isFocus = _wlRows.find(r => r.id === _wlAnalyseId)?.security_id === h.security_id;
    return `<tr${isFocus ? ' style="font-weight:600"' : ''}>
      <td style="padding:3px 6px;font-size:12px">${h.code}</td>
      <td class="mono" style="padding:3px 6px;font-size:12px;text-align:right">${fmtCurrency(curr)}</td>
      <td style="padding:3px 6px;font-size:12px;text-align:right;color:var(--ink3)">${currPct.toFixed(1)}%</td>
      <td style="padding:3px 6px;font-size:12px;text-align:right;color:var(--ink3)">${targPct.toFixed(1)}%</td>
      <td style="padding:3px 6px;font-size:12px;text-align:right;color:${col};font-weight:500">${action}</td>
    </tr>`;
  }).join('');

  const cashStatusCol = cashDelta >= 0 ? 'var(--green)' : 'var(--red)';
  const cashStatus    = cashDelta >= 0
    ? `${fmtCurrency(cashDelta)} excess — deploy into stocks`
    : `${fmtCurrency(-cashDelta)} shortfall — raise by selling`;

  out.innerHTML = `
    <div class="wl-an-section" style="margin-top:12px">
      <div class="wl-an-title">Portfolio Summary</div>
      <div class="wl-an-row"><span class="wl-an-label">Holdings at market</span><span class="mono">${fmtCurrency(knownMV)}</span></div>
      <div class="wl-an-row"><span class="wl-an-label">Cash</span><span class="mono">${fmtCurrency(cashInput)}</span></div>
      <div class="wl-an-row" style="border-top:1px solid var(--border);margin-top:4px;padding-top:6px">
        <span class="wl-an-label">Total portfolio</span><span class="mono" style="font-weight:600">${fmtCurrency(totalPort)}</span>
      </div>
      <div class="wl-an-row"><span class="wl-an-label">Cash buffer target (${bufferPct.toFixed(0)}%)</span><span class="mono">${fmtCurrency(cashTarget)}</span></div>
      <div class="wl-an-row"><span class="wl-an-label">Investable</span><span class="mono">${fmtCurrency(investable)}</span></div>
      <div class="wl-an-row"><span class="wl-an-label">Cash status</span><span class="mono" style="color:${cashStatusCol}">${cashStatus}</span></div>
    </div>
    <div class="wl-an-section" style="margin-top:12px">
      <div class="wl-an-title">Equal-Weight Rebalance — target ${targetEach > 0 ? fmtCurrency(targetEach) : '—'} per stock</div>
      <table style="width:100%;border-collapse:collapse">
        <thead><tr style="border-bottom:1px solid var(--border)">
          <th style="padding:3px 6px;font-size:11px;font-weight:600;text-align:left">Stock</th>
          <th style="padding:3px 6px;font-size:11px;font-weight:600;text-align:right">Value</th>
          <th style="padding:3px 6px;font-size:11px;font-weight:600;text-align:right">Current</th>
          <th style="padding:3px 6px;font-size:11px;font-weight:600;text-align:right">Target</th>
          <th style="padding:3px 6px;font-size:11px;font-weight:600;text-align:right">Action</th>
        </tr></thead>
        <tbody>${rowsHtml}</tbody>
      </table>
    </div>`;
}

// ── Divest / Sell scenario ─────────────────────────────────────────────────────

function _wlDivestUpdate(secId, discountEligible) {
  const holding  = _wlHoldingsMap[secId];
  if (!holding) return;
  const qty      = parseInt(document.getElementById('an-div-qty')?.value)    || 0;
  const weeks    = parseInt(document.getElementById('an-div-weeks')?.value)  || 1;
  const exitP    = parseFloat(document.getElementById('an-div-price')?.value)|| 0;
  const brok     = parseFloat(document.getElementById('an-div-brok')?.value) || 0;
  const rate     = parseFloat(document.getElementById('an-div-rate')?.value) ?? 32.5;
  const out      = document.getElementById('an-divest-results');
  if (!out) return;
  if (!qty || !exitP) { out.innerHTML = ''; return; }

  const lotSize      = Math.ceil(qty / weeks);
  const tranches     = [];
  let   remaining    = qty;
  let   totalNet     = 0;
  let   totalBrok    = 0;

  for (let w = 1; w <= weeks && remaining > 0; w++) {
    const sellQty  = Math.min(lotSize, remaining);
    const gross    = sellQty * exitP;
    const net      = gross - brok;
    totalNet      += net;
    totalBrok     += brok;
    remaining     -= sellQty;
    tranches.push({ week: w, qty: sellQty, gross, net });
  }

  const costBaseUsed  = (qty / holding.total_quantity) * holding.total_cost_base;
  const grossGain     = totalNet - costBaseUsed;
  const taxableGain   = discountEligible && grossGain > 0 ? grossGain * 0.5 : grossGain;
  const taxEstimate   = Math.max(0, taxableGain) * rate / 100;
  const netAfterTax   = totalNet - taxEstimate;
  const gainCol       = grossGain >= 0 ? 'var(--green)' : 'var(--red)';

  const scheduleRows = tranches.map(t => `
    <tr>
      <td style="padding:3px 6px;font-size:12px">Week ${t.week}</td>
      <td class="mono" style="padding:3px 6px;font-size:12px;text-align:right">${fmtNum(t.qty, 0)}</td>
      <td class="mono" style="padding:3px 6px;font-size:12px;text-align:right">${fmtCurrency(t.gross)}</td>
      <td class="mono" style="padding:3px 6px;font-size:12px;text-align:right;color:var(--ink3)">${fmtCurrency(brok)}</td>
      <td class="mono" style="padding:3px 6px;font-size:12px;text-align:right">${fmtCurrency(t.net)}</td>
    </tr>`).join('');

  out.innerHTML = `
    <div class="wl-an-section" style="margin-top:12px">
      <div class="wl-an-title">Liquidation Schedule — ${qty} shares over ${weeks} week${weeks !== 1 ? 's' : ''}</div>
      <table style="width:100%;border-collapse:collapse">
        <thead><tr style="border-bottom:1px solid var(--border)">
          <th style="padding:3px 6px;font-size:11px;font-weight:600;text-align:left">Tranche</th>
          <th style="padding:3px 6px;font-size:11px;font-weight:600;text-align:right">Qty</th>
          <th style="padding:3px 6px;font-size:11px;font-weight:600;text-align:right">Gross</th>
          <th style="padding:3px 6px;font-size:11px;font-weight:600;text-align:right">Brok</th>
          <th style="padding:3px 6px;font-size:11px;font-weight:600;text-align:right">Net</th>
        </tr></thead>
        <tbody>${scheduleRows}</tbody>
      </table>
    </div>
    <div class="wl-an-section" style="margin-top:12px">
      <div class="wl-an-title">Summary</div>
      <div class="wl-an-row"><span class="wl-an-label">Total net proceeds</span><span class="mono" style="font-weight:600">${fmtCurrency(totalNet)}</span></div>
      <div class="wl-an-row"><span class="wl-an-label">Total brokerage</span><span class="mono" style="color:var(--ink3)">${fmtCurrency(totalBrok)}</span></div>
      <div class="wl-an-row"><span class="wl-an-label">Cost base returned</span><span class="mono">${fmtCurrency(costBaseUsed)}</span></div>
      <div class="wl-an-row" style="border-top:1px solid var(--border);margin-top:4px;padding-top:6px">
        <span class="wl-an-label">Capital gain</span>
        <span class="mono" style="color:${gainCol}">${fmtCurrency(grossGain)}</span>
      </div>
      ${discountEligible && grossGain > 0 ? `<div class="wl-an-row"><span class="wl-an-label">After 50% CGT discount</span><span class="mono" style="color:var(--green)">${fmtCurrency(taxableGain)}</span></div>` : ''}
      <div class="wl-an-row"><span class="wl-an-label">Estimated tax (${rate.toFixed(0)}%)</span><span class="mono" style="color:var(--red)">${fmtCurrency(taxEstimate)}</span></div>
      <div class="wl-an-row" style="border-top:1px solid var(--border);margin-top:4px;padding-top:6px">
        <span class="wl-an-label" style="font-weight:600">Net cash after tax</span>
        <span class="mono" style="font-weight:700;color:${netAfterTax >= 0 ? 'var(--green)' : 'var(--red)'}">${fmtCurrency(netAfterTax)}</span>
      </div>
    </div>
    <div style="font-size:10px;color:var(--ink3);margin-top:8px;font-style:italic">CGT estimate only — uses proportional cost base and ${discountEligible ? '50% individual discount' : 'no discount (held < 1 year)'}. Consult your tax adviser.</div>`;
}

// ── Market Analysis recommendation ────────────────────────────────────────────

async function _wlShowRecommendation(w, currentPrice) {
  const el = document.getElementById('an-rec');
  if (!el) return;
  let stockHist = _wlHistories[w.security_id];
  let indexHist = _wlIndexHist;
  if (!stockHist) {
    try {
      [stockHist, indexHist] = await Promise.all([
        apiFetch(`/api/prices/history?security_id=${w.security_id}&period=1y`),
        indexHist.length ? Promise.resolve(indexHist) : apiFetch('/api/prices/index-history?ticker=%5EAORD&period=1y'),
      ]);
      _wlHistories[w.security_id] = stockHist;
      if (!_wlIndexHist.length) _wlIndexHist = indexHist;
    } catch (e) {
      const el2 = document.getElementById('an-rec');
      if (el2) el2.innerHTML = `<span style="color:var(--ink3)">Analysis unavailable: ${e.message}</span>`;
      return;
    }
  }
  if (!document.getElementById('an-rec')) return;
  const price  = currentPrice ?? (stockHist.length ? stockHist[stockHist.length - 1].price : null);
  const result = _wlComputeScore(price, w.target_buy, w.target_sell, stockHist, indexHist);
  if (!result.verdict) {
    el.innerHTML = '<span style="color:var(--ink3)">No price history available for this security.</span>';
    return;
  }
  const verdictCol = result.verdict === 'BUY' ? 'var(--green)' : result.verdict === 'SELL' ? 'var(--red)' : 'var(--amber)';
  const signalHtml = result.signals.map(s => {
    const col  = s.type === 'pos' ? 'var(--green)' : s.type === 'neg' ? 'var(--red)' : 'var(--ink3)';
    const icon = s.type === 'pos' ? '▲' : s.type === 'neg' ? '▼' : '–';
    return `<div class="wl-an-signal">
      <span style="color:${col};font-size:10px;flex-shrink:0;margin-top:1px">${icon}</span>
      <span style="font-size:11px;color:var(--ink2)">${s.label}</span>
    </div>`;
  }).join('');
  el.innerHTML = `
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px">
      <span style="font-size:22px;font-weight:700;color:${verdictCol}">${result.verdict}</span>
      <span style="font-size:11px;color:var(--ink3)">Score: ${result.score > 0 ? '+' : ''}${result.score}</span>
    </div>
    ${signalHtml}
    <div style="font-size:10px;color:var(--ink3);margin-top:10px;font-style:italic">
      Rudimentary technical signal only — not financial advice.
    </div>`;
}
