// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — Help: the user guides (docs/guides/source, via /api/help)
   Prefix: _help */

let _helpGuides  = null;
let _helpCurrent = 0;
let _helpQuery   = '';

async function pageHelp() {
  const content = document.getElementById('module-content');
  content.innerHTML = `
    <div class="help-wrap">
      <div class="help-sidebar">
        <input id="help-search" class="help-search-input" type="search"
               placeholder="Search help…" oninput="_helpSearch(this.value)" autocomplete="off">
        <div id="help-nav" class="help-nav"></div>
      </div>
      <div id="help-pane" class="help-pane"><div class="st-empty">Loading…</div></div>
    </div>`;
  if (!_helpGuides) {
    try {
      _helpGuides = await apiFetch('/api/help');
    } catch (e) {
      document.getElementById('help-pane').innerHTML =
        `<div class="st-empty"><div class="st-empty-title">Help couldn't be loaded</div><div>${_helpEsc(e.message)}</div></div>`;
      return;
    }
  }
  if (_helpQuery) {
    document.getElementById('help-search').value = _helpQuery;
    _helpSearch(_helpQuery);
  } else {
    _helpRenderNav(_helpGuides.map((g, i) => i));
    _helpShow(_helpCurrent);
  }
}

function _helpEsc(t) {
  return String(t ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
                        .replace(/"/g, '&quot;');
}

// Escaped text with **bold** and the search term highlighted
function _helpInline(text) {
  let html = _helpEsc(text).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  if (_helpQuery) {
    const re = new RegExp(`(${_helpQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})(?![^<]*>)`, 'gi');
    html = html.replace(re, '<mark class="help-mark">$1</mark>');
  }
  return html;
}

function _helpRenderNav(indexes) {
  const nav = document.getElementById('help-nav');
  if (!nav) return;
  nav.innerHTML = indexes.length
    ? indexes.map(i => `<div class="help-nav-item${i === _helpCurrent ? ' active' : ''}" data-i="${i}"
          onclick="_helpShow(${i})">${_helpEsc(_helpGuides[i].title)}</div>`).join('')
    : '<div class="help-none">No results</div>';
}

const _HELP_CALLOUT = { tip: 'Tip', warn: 'Warning', note: 'Note' };

function _helpBlock(b) {
  if (b.type === 'code')   return `<pre class="help-code">${_helpEsc(b.text)}</pre>`;
  if (b.type === 'bullet') return `<li>${_helpInline(b.text)}</li>`;
  if (b.type === 'step')   return `<li value="${b.n}">${_helpInline(b.text)}</li>`;
  if (_HELP_CALLOUT[b.type]) {
    return `<div class="help-callout help-${b.type}"><strong>${_HELP_CALLOUT[b.type]}:</strong> ${_helpInline(b.text)}</div>`;
  }
  return `<p class="help-para">${_helpInline(b.text)}</p>`;
}

// Bullets and steps in a row go in one list
function _helpBlocks(blocks) {
  let html = '', list = null;
  for (const b of blocks) {
    const want = b.type === 'bullet' ? 'ul' : b.type === 'step' ? 'ol' : null;
    if (list && list !== want) { html += `</${list}>`; list = null; }
    if (want && !list) { html += `<${want} class="help-list">`; list = want; }
    html += _helpBlock(b);
  }
  if (list) html += `</${list}>`;
  return html;
}

function _helpShow(idx) {
  if (!_helpGuides || !_helpGuides[idx]) return;
  _helpCurrent = idx;
  const g = _helpGuides[idx];
  document.querySelectorAll('.help-nav-item').forEach(el =>
    el.classList.toggle('active', +el.dataset.i === idx));
  const pane = document.getElementById('help-pane');
  if (!pane) return;
  pane.innerHTML = `
    <div class="help-guide-hdr">
      <div>
        <div class="help-guide-title">${_helpEsc(g.title)}</div>
        <div class="help-guide-sub">${_helpEsc(g.subtitle)}</div>
      </div>
      ${g.pdf ? `<a class="btn btn-ghost btn-sm" href="/guides/${encodeURIComponent(g.slug)}.pdf" target="_blank"
                   title="This guide as a PDF, to print or save">PDF</a>` : ''}
    </div>
    ${g.sections.map(s => `
      <div class="help-section">
        <div class="help-sec-hdr">${_helpInline(s.heading)}</div>
        ${_helpBlocks(s.blocks)}
      </div>`).join('')}`;
  pane.scrollTop = 0;
}

function _helpMatches(g, q) {
  const has = t => t.toLowerCase().includes(q);
  return has(g.title) || has(g.subtitle) ||
         g.sections.some(s => has(s.heading) || s.blocks.some(b => has(b.text)));
}

function _helpSearch(q) {
  _helpQuery = q.trim();
  if (!_helpGuides) return;
  const ql = _helpQuery.toLowerCase();
  const hits = _helpGuides.map((g, i) => i).filter(i => !ql || _helpMatches(_helpGuides[i], ql));
  if (hits.length && !hits.includes(_helpCurrent)) _helpCurrent = hits[0];
  _helpRenderNav(hits);
  if (hits.length) {
    _helpShow(_helpCurrent);
  } else {
    document.getElementById('help-pane').innerHTML =
      '<div class="st-empty">No help topics match your search.</div>';
  }
}
