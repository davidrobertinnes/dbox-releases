// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Securities — FY Tax Summary */

async function pageTaxSummary() {
  const content = document.getElementById('module-content');

  const today     = new Date();
  const currentFy = today.getMonth() >= 6 ? today.getFullYear() + 1 : today.getFullYear();

  content.innerHTML = `
    <div class="st-toolbar" id="ts-toolbar">
      <label style="font-size:13px;color:var(--ink2);font-weight:500">Financial Year ending 30 June</label>
      <select id="ts-fy" style="padding:7px 12px;border:1px solid var(--border);border-radius:7px;background:var(--surface);font-size:13px;font-family:inherit;color:var(--ink);outline:none">
        ${fyOptions(currentFy)}
      </select>
      <button class="btn btn-secondary" onclick="_tsLoad()">Load</button>
      <button class="btn btn-ghost" id="ts-export-btn" style="margin-left:auto" onclick="_tsExport()">Export CSV</button>
      <button class="btn btn-ghost" onclick="_tsExportPdf()">Export PDF</button>
      <button class="btn btn-ghost" onclick="window.print()">Print Summary</button>
    </div>
    <div id="ts-content"></div>`;

  await _tsLoad();
}

async function _tsLoad() {
  const fy = parseInt(document.getElementById('ts-fy').value);
  const el = document.getElementById('ts-content');
  el.innerHTML = '<div class="st-empty"><div class="st-empty-icon">⏳</div>Loading…</div>';
  try {
    const [cgtRows, divs, rocGains, fyc, inc] = await Promise.all([
      apiFetch(`/api/cgt?fy=${fy}`),
      apiFetch(`/api/dividends?fy=${fy}`),
      apiFetch(`/api/roc-cgt?fy=${fy}`),
      apiFetch(`/api/cgt-fy-summary?fy=${fy}`),
      apiFetch(`/api/income-fy-summary?fy=${fy}`),
    ]);
    _tsRender(cgtRows, divs, rocGains, fy, fyc, inc);
  } catch (e) {
    toast(e.message, 'err');
  }
}

function _tsRender(cgtRows, divs, rocGains, fy, fyc, inc) {
  const el = document.getElementById('ts-content');

  const entityType  = _appSettings?.entity_type || 'individual';
  const discLabel   = { individual: '50%', smsf_accumulation: '1/3', smsf_pension: 'Fully exempt', company: 'None (company)' }[entityType] ?? '50%';
  const entityLabel = {
    individual:        'Individual',
    smsf_accumulation: 'SMSF (Accumulation Phase)',
    smsf_pension:      'SMSF (Pension Phase)',
    company:           'Company',
  }[entityType] ?? 'Individual';
  const carryforward = fyc.carry_forward;

  // ── Dividends — Item 11 figures computed server-side (compute_fy_income) ──
  const ato11J          = inc.unfranked;
  const ato11K          = inc.franked;
  const ato11L          = inc.credits_claimable;
  const frankIneligible = inc.credits_ineligible;
  const frankUnknown    = inc.credits_unverified;
  const divAssessable   = inc.assessable;

  // ── CGT — Item 18 figures computed server-side (ATO method: losses before discount) ──
  const shortGains     = fyc.short_gains;
  const discGrossGains = fyc.disc_gains;
  const rocGrossTotal  = fyc.roc_gross;
  const curLosses      = fyc.current_losses_applied;
  const carryUsed      = fyc.prior_losses_applied;
  const discApplied    = fyc.discount_applied;
  const ato18A         = fyc.net_capital_gain;
  const ato18H         = fyc.total_gains;
  const ato18V         = fyc.carry_forward_remaining;
  const netLossAmt     = fyc.net_capital_loss;

  // ── Division 296 (SMSF accumulation, FY2027+) ─────────────────────────────
  const isDiv296        = entityType === 'smsf_accumulation' && fy >= 2027;
  const div296Pct       = fy === 2027 ? 20 : fy === 2028 ? 40 : fy === 2029 ? 60 : 80;
  const netCGGross      = fyc.total_gains - fyc.total_losses;
  const totalNetDivs    = ato11J + ato11K;
  const div296CG        = Math.max(0, netCGGross) * (div296Pct / 100);
  const div296Earnings  = totalNetDivs + div296CG;

  // ── Overall ────────────────────────────────────────────────────────────────
  const totalAssessable = divAssessable + ato18A;

  el.innerHTML = `
  <div class="ts-wrapper" id="ts-printable">

    <div class="ts-header">
      <div>
        <div class="ts-title">FY Tax Summary — Year Ending 30 June ${fy}</div>
        <div class="ts-subtitle">Entity: ${entityLabel}&nbsp;&nbsp;·&nbsp;&nbsp;${fy-1}–${fy} Financial Year</div>
      </div>
      <div class="ts-disclaimer">Summary only — verify figures with your accountant before lodging.</div>
    </div>

    <!-- ── Dividend Income ─────────────────────────────────────────────── -->
    <div class="ts-section">
      <div class="ts-section-title">
        Dividend Income
        <span class="ts-section-ref">Individual Tax Return — Item 11</span>
      </div>

      ${_tsRow('Unfranked dividend amount', fmtCurrency(ato11J), '11J')}
      ${_tsRow('Franked dividend amount (net received)', fmtCurrency(ato11K), '11K')}
      ${_tsRow('Franking credits (claimable tax offset)', fmtCurrency(ato11L), '11L', 'col-accent')}
      <hr class="ts-sep">
      ${_tsRow('Total dividend income (assessable)', fmtCurrency(divAssessable), null, null, true)}
      <div class="ts-note">Assessable income = net dividends + eligible franking credits (grossed-up). Franking credits are declared separately as a tax offset (Item 11L).</div>

      ${frankIneligible > 0 ? `<div class="ts-alert ts-alert-red">
        ⚠ ${fmtCurrency(frankIneligible)} in franking credits excluded from 11L — 45-day holding period rule not satisfied.
        Review flagged dividends in <strong>CGT Summary</strong>.
      </div>` : ''}
      ${frankUnknown > 0 ? `<div class="ts-alert ts-alert-amber">
        ? ${fmtCurrency(frankUnknown)} in franking credits are unverified — add ex-dividend dates to confirm 45-day eligibility.
        Until verified, these have been excluded from 11L.
      </div>` : ''}
      ${inc.small_shareholder_exempt && inc.credits_total > 0 ? `<div class="ts-note">
        Small shareholder exemption applies — total franking credits are $5,000 or less, so the 45-day holding period rule does not need to be met.
      </div>` : ''}
      ${inc.missing_credit_count ? `<div class="ts-alert ts-alert-amber">
        ? ${inc.missing_credit_count} franked dividend${inc.missing_credit_count !== 1 ? 's have' : ' has'} no franking credit amount — enter it from the dividend statement.
      </div>` : ''}
      ${!divs.length ? `<div class="ts-empty-note">No dividends recorded for FY${fy}.</div>` : ''}
    </div>

    <!-- ── Capital Gains ───────────────────────────────────────────────── -->
    <div class="ts-section">
      <div class="ts-section-title">
        Capital Gains
        <span class="ts-section-ref">Individual Tax Return — Item 18</span>
      </div>

      ${cgtRows.length || rocGains.length ? `
      ${shortGains     > 0 ? _tsRow('Gains — held &lt; 12 months (no discount)', fmtCurrency(shortGains), null, null, false, true) : ''}
      ${discGrossGains > 0 ? _tsRow('Gains — held ≥ 12 months (discount-eligible)', fmtCurrency(discGrossGains), null, null, false, true) : ''}
      ${rocGrossTotal  > 0 ? _tsRow('Return of capital — cost base exceeded', fmtCurrency(rocGrossTotal), null, null, false, true) : ''}
      ${_tsRow('Total current year capital gains (before discount/losses)', fmtCurrency(ato18H), '18H')}
      <hr class="ts-sep">
      ${fyc.exempt ? _tsRow('Less: exempt — pension phase (capital losses disregarded)', '(' + fmtCurrency(fyc.exempt_amount) + ')', null, 'col-green', false, true) : ''}
      ${!fyc.exempt && fyc.total_losses > 0 ? _tsRow('Less: current year capital losses', '(' + fmtCurrency(curLosses) + ')', null, 'col-red', false, true) : ''}
      ${!fyc.exempt && carryforward > 0 ? _tsRow('Less: prior year losses applied', carryUsed > 0 ? '(' + fmtCurrency(carryUsed) + ')' : '—', null, carryUsed > 0 ? 'col-red' : 'col-ink3', false, true) : ''}
      ${!fyc.exempt && discApplied > 0 ? _tsRow(`Less: ${discLabel} CGT discount (applied after losses)`, '(' + fmtCurrency(discApplied) + ')', null, 'col-red', false, true) : ''}
      <hr class="ts-sep">
      ${_tsRow('Net capital gain', fmtCurrency(ato18A), '18A', ato18A > 0 ? '' : 'col-ink3', true)}
      ${ato18V > 0 ? _tsRow('Net capital losses carried forward to later income years', fmtCurrency(ato18V), '18V') : ''}
      <div class="ts-note">Capital losses are applied before the CGT discount; the discount applies only to discount-eligible gains remaining after losses.</div>
      ${netLossAmt > 0 ? `<div class="ts-note">Includes a current-year net capital loss of ${fmtCurrency(netLossAmt)}.</div>` : ''}
      ` : `<div class="ts-empty-note">No disposals recorded for FY${fy}.</div>`}
    </div>

    <!-- ── Division 296 ─────────────────────────────────────────────────── -->
    ${isDiv296 ? `
    <div class="ts-section">
      <div class="ts-section-title">
        Division 296 — Additional Super Tax
        <span class="ts-section-ref">Effective 1 July 2026</span>
      </div>
      <div class="ts-alert ts-alert-amber">
        ⚠ Division 296 applies to SMSF members with Total Superannuation Balance (TSB) over $3M.
        Additional 15% tax on earnings for TSB $3M–$10M; 25% for TSB over $10M.
        The ATO assesses actual liability — provide these figures to your accountant or SMSF administrator.
      </div>
      ${_tsRow('Dividend income (included at 100%)', fmtCurrency(totalNetDivs))}
      ${_tsRow('Net realised capital gains (gross, before 1/3 fund discount)', fmtCurrency(Math.max(0, netCGGross)))}
      ${_tsRow(`Capital gains inclusion rate FY${fy} (transitional)`, div296Pct + '%')}
      ${_tsRow('Capital gains for Division 296 purposes', fmtCurrency(div296CG), null, null, false, true)}
      <hr class="ts-sep">
      ${_tsRow('Total Division 296 earnings', fmtCurrency(div296Earnings), null, null, true)}
      <div class="ts-note">
        Inclusion rates: 20% FY2027 · 40% FY2028 · 60% FY2029 · 80% FY2030+.
        Actual liability depends on your Total Superannuation Balance across all funds.
      </div>
    </div>` : ''}

    <!-- ── Tax Position Summary ────────────────────────────────────────── -->
    <div class="ts-section ts-section-summary">
      <div class="ts-section-title">Tax Position Summary</div>

      <div class="ts-summary-grid">
        <div class="ts-summary-block">
          <div class="ts-summary-label">Assessable Dividend Income</div>
          <div class="ts-summary-value">${fmtCurrency(divAssessable)}</div>
          <div class="ts-summary-sub">net dividends + eligible franking credits</div>
        </div>
        <div class="ts-summary-block">
          <div class="ts-summary-label">Net Capital Gain (Item 18A)</div>
          <div class="ts-summary-value">${fmtCurrency(ato18A)}</div>
          <div class="ts-summary-sub">after discount, losses &amp; carry-forward</div>
        </div>
        <div class="ts-summary-block ts-summary-block-total">
          <div class="ts-summary-label">Total Assessable Investment Income</div>
          <div class="ts-summary-value">${fmtCurrency(totalAssessable)}</div>
          <div class="ts-summary-sub">dividends + capital gains</div>
        </div>
        ${ato11L > 0 ? `
        <div class="ts-summary-block ts-summary-block-offset">
          <div class="ts-summary-label">Franking Credit Tax Offset (Item 11L)</div>
          <div class="ts-summary-value col-accent">${fmtCurrency(ato11L)}</div>
          <div class="ts-summary-sub">reduces tax payable — enter as tax offset in your return</div>
        </div>` : ''}
      </div>
    </div>

    <div class="ts-footer">
      Dogbox Investments &nbsp;·&nbsp; FY${fy} Tax Summary &nbsp;·&nbsp; Generated ${new Date().toLocaleDateString('en-AU')}
      &nbsp;·&nbsp; This is not tax advice.
    </div>
  </div>`;
}

function _tsExport() {
  const fy = document.getElementById('ts-fy').value;
  window.location.href = `/api/export/tax-summary.csv?fy=${fy}`;
}

function _tsExportPdf() {
  const fy = document.getElementById('ts-fy').value;
  window.location.href = `/api/export/tax-summary-fy${fy}.pdf`;
}

function _tsRow(label, value, atoRef, colorClass, isTtl, isIndent) {
  return `<div class="ts-row${isTtl ? ' ts-row-total' : ''}">
    <div class="ts-label${isIndent ? ' ts-label-indent' : ''}">
      ${label}
      ${atoRef ? `<span class="ts-ato-ref">${atoRef}</span>` : ''}
    </div>
    <div class="ts-value${colorClass ? ' ' + colorClass : ''}${isTtl ? ' ts-value-total' : ''}">${value}</div>
  </div>`;
}
