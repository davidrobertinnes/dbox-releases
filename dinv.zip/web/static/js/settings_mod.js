// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — Settings */

async function pageSettings() {
  const content = document.getElementById('module-content');
  let settings = {};
  try {
    settings = await apiFetch('/api/settings');
  } catch (e) { /* new portfolio — empty settings ok */ }

  content.innerHTML = `
    <div style="max-width:480px">
      <div class="st-section"><div class="st-section-title">Portfolio</div><div class="st-section-line"></div></div>
      <div class="field">
        <label>Owner Name</label>
        <input type="text" id="set-owner" value="${settings.owner_name || ''}" placeholder="Your name">
      </div>
      <div class="field">
        <label>Tax File Number (TFN) <span style="font-weight:400;text-transform:none;letter-spacing:0">stored locally only</span></label>
        <input type="text" id="set-tfn" value="${settings.tfn || ''}" placeholder="000 000 000">
      </div>
      <div class="field">
        <label>Default Financial Year End</label>
        <select id="set-fy">
          <option value="june" ${(settings.fy_end || 'june') === 'june' ? 'selected' : ''}>30 June (Australian)</option>
          <option value="december" ${settings.fy_end === 'december' ? 'selected' : ''}>31 December</option>
        </select>
      </div>

      <div class="st-section" style="margin-top:24px"><div class="st-section-title">Transactions</div><div class="st-section-line"></div></div>
      <div class="field">
        <label>Default Brokerage ($) <span style="font-weight:400;text-transform:none;letter-spacing:0">pre-filled on buy/sell forms</span></label>
        <input type="number" id="set-brok" min="0" step="any"
          value="${settings.default_brokerage || ''}" placeholder="e.g. 19.95">
      </div>

      <div class="st-section" style="margin-top:24px"><div class="st-section-title">Tax</div><div class="st-section-line"></div></div>
      <div class="field">
        <label>Entity Type <span style="font-weight:400;text-transform:none;letter-spacing:0">determines CGT discount</span></label>
        <select id="set-entity">
          <option value="individual"        ${ (settings.entity_type || 'individual') === 'individual'        ? 'selected' : ''}>Individual (50% discount after 12 months)</option>
          <option value="smsf_accumulation" ${ settings.entity_type === 'smsf_accumulation'                  ? 'selected' : ''}>SMSF — Accumulation (1/3 discount)</option>
          <option value="smsf_pension"      ${ settings.entity_type === 'smsf_pension'                       ? 'selected' : ''}>SMSF — Pension (fully exempt)</option>
          <option value="company"           ${ settings.entity_type === 'company'                            ? 'selected' : ''}>Company (no CGT discount)</option>
        </select>
      </div>
      <div class="field">
        <label>Your Share of These Holdings (%) <span style="font-weight:400;text-transform:none;letter-spacing:0">for shares held jointly</span></label>
        <input type="number" id="set-ownership" min="0" max="100" step="any" placeholder="100"
          value="${settings.ownership_pct || ''}">
        <div style="font-size:11px;color:var(--ink3);margin-top:4px">For a portfolio of shares held jointly, enter
          your share (e.g. 50) and record everything in full, as on the statements. Tax figures (dividends,
          franking credits, capital gains and losses) show your share. To keep joint and sole holdings in one
          portfolio, set a share for each holding under Holdings below instead — this setting then applies only
          to records with no holding.</div>
      </div>
      <div class="field">
        <label>Shares Acquired Before 21 Sep 1999 <span style="font-weight:400;text-transform:none;letter-spacing:0">default for sales from 21 Sep 1999 — each sale can override it</span></label>
        <select id="set-indexation">
          <option value="discount"   ${ (settings.indexation_default || 'discount') === 'discount' ? 'selected' : ''}>CGT discount</option>
          <option value="indexation" ${ settings.indexation_default === 'indexation' ? 'selected' : ''}>Indexation (cost base indexed to Sep 1999)</option>
          <option value="lower"      ${ settings.indexation_default === 'lower'      ? 'selected' : ''}>Whichever gives the lower gain (each sale on its own)</option>
        </select>
        <div style="font-size:11px;color:var(--ink3);margin-top:4px">Companies always use indexation. Sales before 21 Sep 1999 are always indexed.</div>
      </div>
      <div class="field">
        <label>Marginal Tax Rate (%) <span style="font-weight:400;text-transform:none;letter-spacing:0">used in CGT sale estimator</span></label>
        <select id="set-tax">
          <option value="" ${!settings.marginal_tax_rate ? 'selected' : ''}>— Not set —</option>
          <option value="0"    ${ settings.marginal_tax_rate === '0'    ? 'selected' : ''}>0% (tax-free threshold)</option>
          <option value="15"   ${ settings.marginal_tax_rate === '15'   ? 'selected' : ''}>15% ($18,201–$45,000, 2026–27)</option>
          <option value="16"   ${ settings.marginal_tax_rate === '16'   ? 'selected' : ''}>16% ($18,201–$45,000, 2024–25 and 2025–26)</option>
          <option value="30"   ${ settings.marginal_tax_rate === '30'   ? 'selected' : ''}>30% ($45,001–$135,000)</option>
          <option value="37"   ${ settings.marginal_tax_rate === '37'   ? 'selected' : ''}>37% ($135,001–$190,000)</option>
          <option value="45"   ${ settings.marginal_tax_rate === '45'   ? 'selected' : ''}>45% ($190,001+)</option>
          ${['19', '32.5'].includes(settings.marginal_tax_rate) ? `
          <option value="${settings.marginal_tax_rate}" selected>${settings.marginal_tax_rate}% (pre-2024 rate — please update)</option>` : ''}
        </select>
      </div>
      <div style="font-size:11px;color:var(--ink3);margin-top:-8px;margin-bottom:16px">
        ATO resident rates (Stage 3; 15% bracket from 1 July 2026). Does not include Medicare levy.
      </div>
      <div class="field">
        <label>Opening CGT Loss Balance ($) <span style="font-weight:400;text-transform:none;letter-spacing:0">losses from before your earliest transaction</span></label>
        <input type="number" id="set-carryforward" min="0" step="any"
          value="${settings.cgt_carryforward_loss || ''}" placeholder="0.00">
      </div>
      <div style="font-size:11px;color:var(--ink3);margin-top:-8px;margin-bottom:16px">
        Capital losses from years before your earliest recorded transaction. Leave at zero if you started tracking from your first investment. The app computes carry-forward automatically from your recorded sales.
      </div>

      <div class="st-section" style="margin-top:24px"><div class="st-section-title">Financial Year Lock</div><div class="st-section-line"></div></div>
      <div style="font-size:11px;color:var(--ink3);margin-bottom:12px">
        Lock a financial year after lodging your return. Records in that year and earlier
        become read-only, protecting the integrity of lodged data.
      </div>
      ${settings.locked_fy ? `<div style="margin-bottom:12px;padding:10px 12px;background:var(--row-alt);border-radius:8px;border:1px solid var(--border);display:flex;align-items:center;gap:12px">
        <span style="font-size:12px;color:var(--ink);flex:1">Locked up to: <strong>FY${settings.locked_fy}</strong> (1 Jul ${+settings.locked_fy - 1} – 30 Jun ${settings.locked_fy})</span>
        <button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="_setsRemoveLocks()">Remove All Locks</button>
      </div>` : ''}
      <div style="display:flex;align-items:flex-end;gap:8px">
        <div class="field" style="margin:0;flex:1">
          <label>Lock up to FY</label>
          <select id="set-lockfy">${_setsLockFyOptions(settings.locked_fy)}</select>
        </div>
        <button class="btn btn-primary" onclick="_setsLockFy()">Lock FY</button>
      </div>

      <div style="margin-top:20px">
        <button class="btn btn-primary" onclick="_setsSave()">Save Settings</button>
      </div>

      <div class="st-section" style="margin-top:32px"><div class="st-section-title">Holdings</div><div class="st-section-line"></div></div>
      <div style="font-size:11px;color:var(--ink3);margin-bottom:12px">
        A holding is a HIN, SRN or broker account. Give each one your share of it (100% if it's yours alone,
        50% if held jointly with one other person). Record everything in full, as on the statements: tax figures
        use your share of the holding the shares were in. Sales only use shares in their own holding.
      </div>
      <div id="set-holdings"><div style="color:var(--ink3);font-size:12px">Loading…</div></div>

      <div class="st-section" style="margin-top:32px"><div class="st-section-title">Audit Log</div><div class="st-section-line"></div></div>
      <div style="font-size:11px;color:var(--ink3);margin-bottom:12px">
        Records all edits and deletions. If the ATO queries a lodged return, this shows what the data looked like before any change.
      </div>
      <div id="audit-log-container">
        <button class="btn btn-ghost btn-sm" onclick="_setsLoadAudit()">Show audit log</button>
      </div>
    </div>`;
  _setsLoadHoldings();
}

// ── Holdings ──────────────────────────────────────────────────────────────────

let _setsHold = { holdings: [], moves: [] };

function _setsPct(share) { return Math.round(share * 10000) / 100; }

async function _setsLoadHoldings() {
  const el = document.getElementById('set-holdings');
  if (!el) return;
  try { _setsHold = await apiFetch('/api/holding-accounts'); } catch (e) { el.textContent = e.message; return; }
  await _loadHoldingList();
  const hs = _setsHold.holdings;
  const rows = hs.length ? hs.map(h => `<tr>
      <td class="code-cell">${_setsEsc(h.code)}</td>
      <td>${_setsEsc(h.name || '')}</td>
      <td class="num mono">${_setsPct(h.share)}%${h.share_changes.map(c =>
        ` → ${_setsPct(c.share)}% <span style="color:var(--ink3);font-size:11px">from ${fmtDate(c.effective_date)}</span>
          <button class="btn btn-ghost btn-sm" style="color:var(--red)" title="Delete this joint holder's death"
            onclick="_setsDeathDelete(${c.id})">×</button>`).join('')}</td>
      <td class="num mono">${h.open_parcels}</td>
      <td style="white-space:nowrap">
        <button class="btn btn-ghost btn-sm" onclick="_setsHoldingForm(${h.id})">Edit</button>
        ${h.share_now < 1 ? `<button class="btn btn-ghost btn-sm" onclick="_setsDeathForm(${h.id})">Joint holder died…</button>` : ''}
        <button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="_setsHoldingDelete(${h.id}, '${_setsEsc(h.code)}')">Del</button>
      </td></tr>`).join('')
    : `<tr><td colspan="5" style="text-align:center;padding:16px;color:var(--ink3);font-size:12px">No holdings — every record counts in full (or at the share set above)</td></tr>`;
  const moves = _setsHold.moves.length ? `
      <div style="font-size:12px;font-weight:600;margin:14px 0 6px">Moves between holdings</div>
      <table class="st-table"><thead><tr><th>Date</th><th>From</th><th>To</th><th>Security</th><th class="num">Parcels</th><th></th></tr></thead>
      <tbody>${_setsHold.moves.map(m => `<tr><td class="mono">${fmtDate(m.move_date)}</td>
        <td>${_setsEsc(m.from_code)}</td><td>${_setsEsc(m.to_code)}</td><td>${m.security_code || 'All'}</td>
        <td class="num mono">${m.parcels}</td>
        <td><button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="_setsMoveDelete(${m.id})">Del</button></td></tr>`).join('')}
      </tbody></table>` : '';
  el.innerHTML = `
    <table class="st-table"><thead><tr><th>Code</th><th>Name</th><th class="num">Your Share</th>
      <th class="num" title="Parcels with shares in the holding today">Parcels</th><th></th></tr></thead>
      <tbody>${rows}</tbody></table>
    <div style="margin-top:10px;display:flex;gap:8px">
      <button class="btn btn-secondary btn-sm" onclick="_setsHoldingForm()">Add Holding</button>
      ${hs.length > 1 ? '<button class="btn btn-ghost btn-sm" onclick="_setsMoveForm()">Move Shares…</button>' : ''}
    </div>${moves}`;
}

function _setsEsc(t) {
  return String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

async function _setsPost(url, method, body) {
  const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' },
                               body: body ? JSON.stringify(body) : undefined }).then(r => r.json());
  if (!r.ok) throw new Error(r.error);
  return r.data;
}

function _setsHoldingForm(id = null) {
  const h = _setsHold.holdings.find(x => x.id === id) || {};
  openPanel(id ? 'Edit Holding' : 'Add Holding', `
    <div class="field-row cols-2">
      <div class="field"><label>Code</label><input type="text" id="hold-code" value="${_setsEsc(h.code || '')}" placeholder="e.g. csj"></div>
      <div class="field"><label>Your Share (%)</label><input type="number" id="hold-share" min="0" max="100" step="any"
        value="${h.share != null ? _setsPct(h.share) : 100}"></div>
    </div>
    <div class="field"><label>Name</label><input type="text" id="hold-name" value="${_setsEsc(h.name || '')}"
      placeholder="e.g. CommSec — joint with Mary, HIN 0012345678"></div>
    ${id ? `<div style="font-size:11px;color:var(--ink3);line-height:1.6">Changing the share corrects it for the
      holding's whole history. If a joint holder has died, use <em>Joint holder died…</em> instead.</div>` : ''}`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_setsHoldingSave(${id || 'null'})">Save</button>`);
}

async function _setsHoldingSave(id) {
  const body = { code: document.getElementById('hold-code').value.trim(),
                 name: document.getElementById('hold-name').value.trim(),
                 share: document.getElementById('hold-share').value };
  if (!body.code) return toast('Enter a code', 'err');
  try {
    await _setsPost(id ? `/api/holding-accounts/${id}` : '/api/holding-accounts', id ? 'PUT' : 'POST', body);
    closePanel();
    toast(id ? 'Holding updated' : 'Holding added');
    await _loadAppSettings();
    await _setsLoadHoldings();
  } catch (e) { toast(e.message, 'err'); }
}

async function _setsHoldingDelete(id, code) {
  if (!confirm(`Delete holding ${code}?`)) return;
  try {
    await _setsPost(`/api/holding-accounts/${id}`, 'DELETE');
    toast('Holding deleted');
    await _setsLoadHoldings();
  } catch (e) { toast(e.message, 'err'); }
}

async function _setsMoveForm() {
  let secs = [];
  try { secs = await apiFetch('/api/securities'); } catch (e) {}
  const opts = _setsHold.holdings.map(h => `<option value="${h.id}">${_setsEsc(holdingLabel(h))}</option>`).join('');
  openPanel('Move Shares Between Holdings', `
    <div style="font-size:12px;color:var(--ink2);line-height:1.6;margin-bottom:14px">
      For a transfer between brokers or accounts with the same owners (e.g. CommSec to SelfWealth). It isn't a
      CGT event: the shares keep their cost base and dates. Every parcel of the security (or of every security)
      in the first holding moves.
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>From</label><select id="mv-from">${opts}</select></div>
      <div class="field"><label>To</label><select id="mv-to">${opts}</select></div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Date</label><input type="date" id="mv-date" value="${new Date().toISOString().slice(0,10)}"></div>
      <div class="field"><label>Security</label><select id="mv-sec"><option value="">All securities</option>
        ${secs.map(s => `<option value="${s.id}">${s.code} — ${_setsEsc(s.name)}</option>`).join('')}</select></div>
    </div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_setsMoveSave()">Move</button>`);
}

async function _setsMoveSave() {
  const body = { from_holding_id: document.getElementById('mv-from').value,
                 to_holding_id: document.getElementById('mv-to').value,
                 move_date: document.getElementById('mv-date').value,
                 security_id: document.getElementById('mv-sec').value || null };
  if (body.from_holding_id === body.to_holding_id) return toast('Choose two different holdings', 'err');
  try {
    await _setsPost('/api/holding-moves', 'POST', body);
    closePanel();
    toast('Shares moved');
    await _setsLoadHoldings();
  } catch (e) { toast(e.message, 'err'); }
}

async function _setsMoveDelete(id) {
  if (!confirm('Delete this move? The shares go back to the holding they came from.')) return;
  try {
    await _setsPost(`/api/holding-moves/${id}`, 'DELETE');
    toast('Move deleted');
    await _setsLoadHoldings();
  } catch (e) { toast(e.message, 'err'); }
}

function _setsDeathForm(id) {
  const h = _setsHold.holdings.find(x => x.id === id);
  openPanel("Joint Holder Died — " + h.code, `
    <div style="font-size:12px;color:var(--ink2);line-height:1.6;margin-bottom:14px">
      The deceased's share passes to the surviving joint holder(s), who are taken to acquire it on the date of
      death. For shares bought from 20 September 1985 it keeps the original cost base and purchase date, so
      only your share changes. For shares bought earlier (pre-CGT), the part you inherit costs its market value
      on the date of death — enter it below for each such security.
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Date of Death</label><input type="date" id="dth-date" onchange="_setsDeathPreCgt(${id})"></div>
      <div class="field"><label>Your Share Afterwards (%)</label><input type="number" id="dth-share" min="0" max="100"
        step="any" value="100"></div>
    </div>
    <div id="dth-values"></div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_setsDeathSave(${id})">Save</button>`);
}

async function _setsDeathPreCgt(id) {
  const d = document.getElementById('dth-date').value;
  const el = document.getElementById('dth-values');
  if (!d) { el.innerHTML = ''; return; }
  try {
    const list = await apiFetch(`/api/holding-accounts/${id}/pre-cgt?date=${d}`);
    el.innerHTML = list.length ? `<div style="font-size:12px;font-weight:600;margin-bottom:6px">Pre-CGT shares — market value of one share on ${fmtDate(d)}</div>` +
      list.map(r => `<div class="field"><label>${r.code} <span style="font-weight:400;text-transform:none;letter-spacing:0">${fmtNum(r.units, 4)} shares</span></label>
        <input type="number" min="0" step="any" class="dth-mv" data-sec="${r.security_id}" placeholder="0.00"></div>`).join('')
      : '<div style="font-size:12px;color:var(--ink3)">No pre-CGT shares in this holding then — nothing else to enter.</div>';
  } catch (e) { el.textContent = e.message; }
}

async function _setsDeathSave(id) {
  const death_date = document.getElementById('dth-date').value;
  if (!death_date) return toast('Enter the date of death', 'err');
  const market_values = {};
  document.querySelectorAll('.dth-mv').forEach(i => { if (i.value) market_values[i.dataset.sec] = i.value; });
  try {
    await _setsPost(`/api/holding-accounts/${id}/death`, 'POST',
                    { death_date, share: document.getElementById('dth-share').value, market_values });
    closePanel();
    toast("Joint holder's death recorded");
    await _setsLoadHoldings();
  } catch (e) { toast(e.message, 'err'); }
}

async function _setsDeathDelete(changeId) {
  if (!confirm("Delete this joint holder's death? Your share goes back to what it was, and any pre-CGT parcels split at the death are put back.")) return;
  try {
    await _setsPost(`/api/holding-shares/${changeId}`, 'DELETE');
    toast('Deleted');
    await _setsLoadHoldings();
  } catch (e) { toast(e.message, 'err'); }
}

function _setsLockFyOptions(currentLock) {
  const now = new Date();
  const currentFy = (now.getMonth() + 1) >= 7 ? now.getFullYear() + 1 : now.getFullYear();
  let opts = '';
  const first = Math.min((_appSettings && _appSettings._first_fy) || currentFy, currentFy - 10);
  for (let y = currentFy - 1; y >= first; y--) {
    const sel = currentLock == y ? ' selected' : '';
    opts += `<option value="${y}"${sel}>FY${y} (1 Jul ${y - 1} – 30 Jun ${y})</option>`;
  }
  return opts;
}

async function _setsLockFy() {
  const fy = document.getElementById('set-lockfy')?.value;
  if (!fy) return;
  if (!confirm(`Lock FY${fy} and all earlier years?\n\nAll records dated before 1 July ${fy} will become read-only.`)) return;
  try {
    const r = await fetch('/api/settings/lock-fy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fy: parseInt(fy) }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    await _loadAppSettings();
    toast(`FY${fy} locked`);
    pageSettings();
  } catch (e) {
    toast(e.message, 'err');
  }
}

async function _setsRemoveLocks() {
  if (!confirm('Remove all FY locks? All records will become editable again.')) return;
  try {
    const r = await fetch('/api/settings/lock-fy', { method: 'DELETE' }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    await _loadAppSettings();
    toast('All locks removed');
    pageSettings();
  } catch (e) {
    toast(e.message, 'err');
  }
}

async function _setsSave() {
  const owner_name        = document.getElementById('set-owner').value.trim();
  const tfn               = document.getElementById('set-tfn').value.trim();
  const fy_end            = document.getElementById('set-fy').value;
  const default_brokerage = document.getElementById('set-brok').value.trim();
  const marginal_tax_rate     = document.getElementById('set-tax').value;
  const entity_type           = document.getElementById('set-entity').value;
  const indexation_default    = document.getElementById('set-indexation').value;
  const ownership_pct         = document.getElementById('set-ownership').value.trim();
  const cgt_carryforward_loss = document.getElementById('set-carryforward').value.trim();

  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ owner_name, tfn, fy_end, default_brokerage, marginal_tax_rate,
                             entity_type, indexation_default, ownership_pct, cgt_carryforward_loss }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    // Refresh global settings cache
    if (typeof _appSettings !== 'undefined') {
      _appSettings.default_brokerage = default_brokerage;
      _appSettings.marginal_tax_rate = marginal_tax_rate;
      _appSettings.ownership_pct = ownership_pct === '100' ? '' : ownership_pct;
    }
    toast('Settings saved');
  } catch (e) {
    toast(e.message, 'err');
  }
}

async function _setsLoadAudit() {
  const container = document.getElementById('audit-log-container');
  container.innerHTML = '<span style="font-size:11px;color:var(--ink3)">Loading…</span>';
  try {
    const rows = await apiFetch('/api/audit-log');
    if (!rows.length) {
      container.innerHTML = '<span style="font-size:11px;color:var(--ink3)">No audit entries yet.</span>';
      return;
    }
    const tableLabel = { parcels:'Parcel', sales:'Sale', dividends:'Dividend', corporate_actions:'Corp. Action' };
    container.innerHTML = `<div style="overflow-x:auto">
      <table class="data-table" style="font-size:11px;min-width:560px">
        <thead><tr><th>When</th><th>Action</th><th>Record</th><th>Detail</th></tr></thead>
        <tbody>${rows.map(r => {
          let old = {};
          try { old = JSON.parse(r.old_data || '{}'); } catch (_) {}
          const label = tableLabel[r.table_name] || r.table_name;
          const code  = old.code ? `<strong>${old.code}</strong> ` : '';
          const date  = old.payment_date || old.sale_date || old.acquisition_date || old.action_date || '';
          const badge = r.action === 'delete'
            ? '<span class="badge badge-red">delete</span>'
            : '<span class="badge badge-amber">edit</span>';
          return `<tr>
            <td class="mono" style="white-space:nowrap">${r.timestamp}</td>
            <td>${badge}</td>
            <td>${label} #${r.record_id}</td>
            <td>${code}${date}</td>
          </tr>`;
        }).join('')}</tbody>
      </table></div>`;
  } catch (e) {
    container.innerHTML = `<span style="color:var(--red);font-size:11px">${e.message}</span>`;
  }
}
