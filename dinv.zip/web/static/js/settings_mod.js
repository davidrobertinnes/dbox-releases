// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — Settings */

async function pageSettings() {
  const content = document.getElementById('module-content');
  let settings = {};
  try {
    settings = await apiFetch('/api/settings');
  } catch (e) { /* new portfolio — empty settings ok */ }

  content.innerHTML = `
    <div style="max-width:480px">
      <div class="st-section"><div class="st-section-title">Portfolio</div><div class="st-section-line"></div></div>
      <div class="field">
        <label>Owner Name</label>
        <input type="text" id="set-owner" value="${settings.owner_name || ''}" placeholder="Your name">
      </div>
      <div class="field">
        <label>Tax File Number (TFN) <span style="font-weight:400;text-transform:none;letter-spacing:0">stored locally only</span></label>
        <input type="text" id="set-tfn" value="${settings.tfn || ''}" placeholder="000 000 000">
      </div>
      <div class="field">
        <label>Default Financial Year End</label>
        <select id="set-fy">
          <option value="june" ${(settings.fy_end || 'june') === 'june' ? 'selected' : ''}>30 June (Australian)</option>
          <option value="december" ${settings.fy_end === 'december' ? 'selected' : ''}>31 December</option>
        </select>
      </div>

      <div class="st-section" style="margin-top:24px"><div class="st-section-title">Transactions</div><div class="st-section-line"></div></div>
      <div class="field">
        <label>Default Brokerage ($) <span style="font-weight:400;text-transform:none;letter-spacing:0">pre-filled on buy/sell forms</span></label>
        <input type="number" id="set-brok" min="0" step="any"
          value="${settings.default_brokerage || ''}" placeholder="e.g. 19.95">
      </div>

      <div class="st-section" style="margin-top:24px"><div class="st-section-title">Tax</div><div class="st-section-line"></div></div>
      <div class="field">
        <label>Entity Type <span style="font-weight:400;text-transform:none;letter-spacing:0">determines CGT discount</span></label>
        <select id="set-entity">
          <option value="individual"        ${ (settings.entity_type || 'individual') === 'individual'        ? 'selected' : ''}>Individual (50% discount after 12 months)</option>
          <option value="smsf_accumulation" ${ settings.entity_type === 'smsf_accumulation'                  ? 'selected' : ''}>SMSF — Accumulation (1/3 discount)</option>
          <option value="smsf_pension"      ${ settings.entity_type === 'smsf_pension'                       ? 'selected' : ''}>SMSF — Pension (fully exempt)</option>
          <option value="company"           ${ settings.entity_type === 'company'                            ? 'selected' : ''}>Company (no CGT discount)</option>
        </select>
      </div>
      <div class="field">
        <label>Marginal Tax Rate (%) <span style="font-weight:400;text-transform:none;letter-spacing:0">used in CGT sale estimator</span></label>
        <select id="set-tax">
          <option value="" ${!settings.marginal_tax_rate ? 'selected' : ''}>— Not set —</option>
          <option value="0"    ${ settings.marginal_tax_rate === '0'    ? 'selected' : ''}>0% (tax-free threshold)</option>
          <option value="19"   ${ settings.marginal_tax_rate === '19'   ? 'selected' : ''}>19% ($18,201–$45,000)</option>
          <option value="32.5" ${ settings.marginal_tax_rate === '32.5' ? 'selected' : ''}>32.5% ($45,001–$135,000)</option>
          <option value="37"   ${ settings.marginal_tax_rate === '37'   ? 'selected' : ''}>37% ($135,001–$190,000)</option>
          <option value="45"   ${ settings.marginal_tax_rate === '45'   ? 'selected' : ''}>45% ($190,001+)</option>
        </select>
      </div>
      <div style="font-size:11px;color:var(--ink3);margin-top:-8px;margin-bottom:16px">
        ATO 2024–25 rates. Does not include Medicare levy.
      </div>
      <div class="field">
        <label>Opening CGT Loss Balance ($) <span style="font-weight:400;text-transform:none;letter-spacing:0">losses from before your earliest transaction</span></label>
        <input type="number" id="set-carryforward" min="0" step="any"
          value="${settings.cgt_carryforward_loss || ''}" placeholder="0.00">
      </div>
      <div style="font-size:11px;color:var(--ink3);margin-top:-8px;margin-bottom:16px">
        Capital losses from years before your earliest recorded transaction. Leave at zero if you started tracking from your first investment. The app computes carry-forward automatically from your recorded sales.
      </div>

      <div class="st-section" style="margin-top:24px"><div class="st-section-title">Financial Year Lock</div><div class="st-section-line"></div></div>
      <div style="font-size:11px;color:var(--ink3);margin-bottom:12px">
        Lock a financial year after lodging your return. Records in that year and earlier
        become read-only, protecting the integrity of lodged data.
      </div>
      ${settings.locked_fy ? `<div style="margin-bottom:12px;padding:10px 12px;background:var(--row-alt);border-radius:8px;border:1px solid var(--border);display:flex;align-items:center;gap:12px">
        <span style="font-size:12px;color:var(--ink);flex:1">Locked up to: <strong>FY${settings.locked_fy}</strong> (1 Jul ${+settings.locked_fy - 1} – 30 Jun ${settings.locked_fy})</span>
        <button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="_setsRemoveLocks()">Remove All Locks</button>
      </div>` : ''}
      <div style="display:flex;align-items:flex-end;gap:8px">
        <div class="field" style="margin:0;flex:1">
          <label>Lock up to FY</label>
          <select id="set-lockfy">${_setsLockFyOptions(settings.locked_fy)}</select>
        </div>
        <button class="btn btn-primary" onclick="_setsLockFy()">Lock FY</button>
      </div>

      <div style="margin-top:20px">
        <button class="btn btn-primary" onclick="_setsSave()">Save Settings</button>
      </div>

      <div class="st-section" style="margin-top:32px"><div class="st-section-title">Audit Log</div><div class="st-section-line"></div></div>
      <div style="font-size:11px;color:var(--ink3);margin-bottom:12px">
        Records all edits and deletions. If the ATO queries a lodged return, this shows what the data looked like before any change.
      </div>
      <div id="audit-log-container">
        <button class="btn btn-ghost btn-sm" onclick="_setsLoadAudit()">Show audit log</button>
      </div>
    </div>`;
}

function _setsLockFyOptions(currentLock) {
  const now = new Date();
  const currentFy = (now.getMonth() + 1) >= 7 ? now.getFullYear() + 1 : now.getFullYear();
  let opts = '';
  for (let y = currentFy - 1; y >= currentFy - 10; y--) {
    const sel = currentLock == y ? ' selected' : '';
    opts += `<option value="${y}"${sel}>FY${y} (1 Jul ${y - 1} – 30 Jun ${y})</option>`;
  }
  return opts;
}

async function _setsLockFy() {
  const fy = document.getElementById('set-lockfy')?.value;
  if (!fy) return;
  if (!confirm(`Lock FY${fy} and all earlier years?\n\nAll records dated before 1 July ${fy} will become read-only.`)) return;
  try {
    const r = await fetch('/api/settings/lock-fy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fy: parseInt(fy) }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    await _loadAppSettings();
    toast(`FY${fy} locked`);
    pageSettings();
  } catch (e) {
    toast(e.message, 'err');
  }
}

async function _setsRemoveLocks() {
  if (!confirm('Remove all FY locks? All records will become editable again.')) return;
  try {
    const r = await fetch('/api/settings/lock-fy', { method: 'DELETE' }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    await _loadAppSettings();
    toast('All locks removed');
    pageSettings();
  } catch (e) {
    toast(e.message, 'err');
  }
}

async function _setsSave() {
  const owner_name        = document.getElementById('set-owner').value.trim();
  const tfn               = document.getElementById('set-tfn').value.trim();
  const fy_end            = document.getElementById('set-fy').value;
  const default_brokerage = document.getElementById('set-brok').value.trim();
  const marginal_tax_rate     = document.getElementById('set-tax').value;
  const entity_type           = document.getElementById('set-entity').value;
  const cgt_carryforward_loss = document.getElementById('set-carryforward').value.trim();

  try {
    const r = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ owner_name, tfn, fy_end, default_brokerage, marginal_tax_rate,
                             entity_type, cgt_carryforward_loss }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    // Refresh global settings cache
    if (typeof _appSettings !== 'undefined') {
      _appSettings.default_brokerage = default_brokerage;
      _appSettings.marginal_tax_rate = marginal_tax_rate;
    }
    toast('Settings saved');
  } catch (e) {
    toast(e.message, 'err');
  }
}

async function _setsLoadAudit() {
  const container = document.getElementById('audit-log-container');
  container.innerHTML = '<span style="font-size:11px;color:var(--ink3)">Loading…</span>';
  try {
    const rows = await apiFetch('/api/audit-log');
    if (!rows.length) {
      container.innerHTML = '<span style="font-size:11px;color:var(--ink3)">No audit entries yet.</span>';
      return;
    }
    const tableLabel = { parcels:'Parcel', sales:'Sale', dividends:'Dividend', corporate_actions:'Corp. Action' };
    container.innerHTML = `<div style="overflow-x:auto">
      <table class="data-table" style="font-size:11px;min-width:560px">
        <thead><tr><th>When</th><th>Action</th><th>Record</th><th>Detail</th></tr></thead>
        <tbody>${rows.map(r => {
          let old = {};
          try { old = JSON.parse(r.old_data || '{}'); } catch (_) {}
          const label = tableLabel[r.table_name] || r.table_name;
          const code  = old.code ? `<strong>${old.code}</strong> ` : '';
          const date  = old.payment_date || old.sale_date || old.acquisition_date || old.action_date || '';
          const badge = r.action === 'delete'
            ? '<span class="badge badge-red">delete</span>'
            : '<span class="badge badge-amber">edit</span>';
          return `<tr>
            <td class="mono" style="white-space:nowrap">${r.timestamp}</td>
            <td>${badge}</td>
            <td>${label} #${r.record_id}</td>
            <td>${code}${date}</td>
          </tr>`;
        }).join('')}</tbody>
      </table></div>`;
  } catch (e) {
    container.innerHTML = `<span style="color:var(--red);font-size:11px">${e.message}</span>`;
  }
}
