// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* sharetrack — Cost Base Reconciliation */

let _cbrRows = [];

async function pageCostBaseRecon() {
  const content = document.getElementById('module-content');
  const today = new Date();
  const currentFy = today.getMonth() >= 6 ? today.getFullYear() + 1 : today.getFullYear();

  content.innerHTML = `
    <div class="st-toolbar">
      <label style="font-size:13px;color:var(--ink2);font-weight:500">Financial Year ending 30 June</label>
      <select id="cbr-fy" style="padding:7px 12px;border:1px solid var(--border);border-radius:7px;background:var(--surface);font-size:13px;font-family:inherit;color:var(--ink);outline:none">
        ${[0,1,2,3,4].map(i => {
          const y = currentFy - i;
          return `<option value="${y}" ${i===0?'selected':''}>${y} (${y-1}–${y})</option>`;
        }).join('')}
      </select>
      <button class="btn btn-secondary" onclick="_cbrLoad()">Load</button>
      <button class="btn btn-ghost" style="margin-left:auto" onclick="_cbrExport()">Export CSV</button>
    </div>
    <div id="cbr-content"></div>`;

  await _cbrLoad();
}

function _cbrExport() {
  const fy = document.getElementById('cbr-fy')?.value;
  if (fy) window.location.href = `/api/export/cost-base-recon.csv?fy=${fy}`;
}

async function _cbrLoad() {
  const fy = parseInt(document.getElementById('cbr-fy').value);
  const el = document.getElementById('cbr-content');
  el.innerHTML = '<div class="st-empty"><div class="st-empty-icon">⏳</div>Loading…</div>';
  try {
    _cbrRows = await apiFetch(`/api/cost-base-reconciliation?fy=${fy}`);
    _cbrRender(_cbrRows, fy);
  } catch (e) {
    toast(e.message, 'err');
  }
}

function _cbrRender(rows, fy) {
  const el = document.getElementById('cbr-content');

  if (!rows.length) {
    el.innerHTML = `<div class="st-empty">
      <div class="st-empty-icon">📊</div>
      <div class="st-empty-title">No data for FY${fy}</div>
      <div>No holdings, purchases, or disposals found for this financial year.</div>
    </div>`;
    return;
  }

  const totalOpen  = rows.reduce((s, r) => s + r.opening_cb, 0);
  const totalAdds  = rows.reduce((s, r) => s + r.additions.total, 0);
  const totalReds  = rows.reduce((s, r) => s + r.reductions.total, 0);
  const totalClose = rows.reduce((s, r) => s + r.actual_close, 0);
  const nBad = rows.filter(r => !r.reconciles).length;

  el.innerHTML = `
    <div class="st-kpi-strip">
      <div class="st-kpi">
        <div class="st-kpi-label">Opening CB (1 Jul ${fy-1})</div>
        <div class="st-kpi-value col-ink">${fmtCurrency(totalOpen)}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">+ Additions</div>
        <div class="st-kpi-value col-green">+${fmtCurrency(totalAdds)}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">− Reductions</div>
        <div class="st-kpi-value col-red">−${fmtCurrency(totalReds)}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Closing CB (30 Jun ${fy})</div>
        <div class="st-kpi-value col-ink">${fmtCurrency(totalClose)}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Reconciliation</div>
        <div class="st-kpi-value ${nBad > 0 ? 'col-red' : 'col-green'}">${nBad > 0 ? nBad + ' issue' + (nBad !== 1 ? 's' : '') : 'All clear'}</div>
        <div class="st-kpi-sub">${rows.length} securit${rows.length !== 1 ? 'ies' : 'y'}</div>
      </div>
    </div>

    <div class="st-list-panel">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Code</th>
            <th>Name</th>
            <th class="num">Opening CB</th>
            <th class="num">+ Additions</th>
            <th class="num">− Reductions</th>
            <th class="num">Computed Close</th>
            <th class="num">Actual Close</th>
            <th title="Computed closing cost base matches actual holdings snapshot">✓</th>
          </tr></thead>
          <tbody>
            ${rows.map(r => `<tr style="cursor:pointer" onclick="_cbrDetail(${r.security_id})">
              <td class="code-cell">${r.code}</td>
              <td>${r.name}</td>
              <td class="num mono">${fmtCurrency(r.opening_cb)}</td>
              <td class="num mono ${r.additions.total ? 'col-green' : ''}">${r.additions.total ? '+' + fmtCurrency(r.additions.total) : '—'}</td>
              <td class="num mono ${r.reductions.total ? 'col-red' : ''}">${r.reductions.total ? '−' + fmtCurrency(r.reductions.total) : '—'}</td>
              <td class="num mono">${fmtCurrency(r.computed_close)}</td>
              <td class="num mono">${fmtCurrency(r.actual_close)}</td>
              <td>${r.reconciles
                ? '<span class="badge badge-green" title="Reconciles">✓</span>'
                : '<span class="badge badge-red"   title="Discrepancy — click for details">✗</span>'}</td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>
    <div class="count-pill">${rows.length} securit${rows.length !== 1 ? 'ies' : 'y'} · FY${fy} (1 Jul ${fy-1} – 30 Jun ${fy}) · click a row for breakdown</div>`;
}

function _cbrDetail(securityId) {
  const r = _cbrRows.find(x => x.security_id === securityId);
  if (!r) return;

  const a   = r.additions;
  const red = r.reductions;
  const diff = r.computed_close - r.actual_close;

  const sec = label =>
    `<div style="font-family:'DM Mono',monospace;font-size:9px;font-weight:500;
                 letter-spacing:1.5px;text-transform:uppercase;color:var(--ink3);
                 padding:12px 0 4px">${label}</div>`;

  const line = (label, val, cls = '', indent = false) =>
    `<div style="display:flex;align-items:baseline;padding:5px 0;
                 ${indent ? 'padding-left:14px' : 'border-bottom:1px solid var(--border)'}">
       <span style="flex:1;color:${indent ? 'var(--ink2)' : 'var(--ink)'};font-size:13px">${label}</span>
       <span class="mono ${cls}" style="font-size:13px">${val}</span>
     </div>`;

  openPanel(`${r.code} — Cost Base Movement`, `
    ${line('Opening Cost Base (1 Jul)', fmtCurrency(r.opening_cb))}

    ${sec('Additions')}
    ${line('Purchases',                   fmtCurrency(a.purchases),        a.purchases        ? 'col-green' : '', true)}
    ${line('Dividend Reinvestment (DRP)', fmtCurrency(a.drp),              a.drp              ? 'col-green' : '', true)}
    ${line('Rights Issues',               fmtCurrency(a.rights_issues),    a.rights_issues    ? 'col-green' : '', true)}
    ${line('Bonus Issues',                fmtCurrency(a.bonus_issues),     a.bonus_issues     ? 'col-green' : '', true)}
    ${line('Demerger Receipt',            fmtCurrency(a.demerger_receipt), a.demerger_receipt ? 'col-green' : '', true)}
    ${line('Total Additions',             a.total ? '+' + fmtCurrency(a.total) : fmtCurrency(0), a.total ? 'col-green' : '')}

    ${sec('Reductions')}
    ${line('Disposals (cost base used)',  fmtCurrency(red.disposals),         red.disposals         ? 'col-red' : '', true)}
    ${line('Return of Capital',           fmtCurrency(red.return_of_capital), red.return_of_capital ? 'col-red' : '', true)}
    ${line('Demerger Transfer Out',       fmtCurrency(red.demerger_out),      red.demerger_out      ? 'col-red' : '', true)}
    ${line('Total Reductions',            red.total ? '−' + fmtCurrency(red.total) : fmtCurrency(0), red.total ? 'col-red' : '')}

    <div style="height:8px"></div>
    ${line('Computed Closing CB', fmtCurrency(r.computed_close))}
    ${line('Actual Closing CB',   fmtCurrency(r.actual_close), r.reconciles ? 'col-green' : 'col-red')}
    ${Math.abs(diff) >= 0.02 ? line('Adjustment', (diff >= 0 ? '+' : '') + fmtCurrency(diff), 'col-amber') : ''}

    <div style="margin-top:14px;padding:10px 14px;border-radius:8px;
                background:${r.reconciles ? 'var(--green-dim)' : 'var(--red-dim)'};
                color:${r.reconciles ? 'var(--green)' : 'var(--red)'};
                font-size:13px;font-weight:500">
      ${r.reconciles
        ? '✓ Reconciles — no adjustments required'
        : `✗ Discrepancy of ${fmtCurrency(Math.abs(diff))} — check for missing transactions or corporate actions`}
    </div>
  `, `<button class="btn btn-secondary" onclick="closePanel()">Close</button>`);
}
