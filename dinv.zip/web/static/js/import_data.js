// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — Import Transactions from CSV */

const _IMP_FORMAT_HINTS = {
  commsec_confirmations: `CommSec <strong>ConfirmationDetails.csv</strong> — exported from CommSec &rsaquo; Portfolio &rsaquo; Transactions &rsaquo; Export. Buys and sells only; dividends are not included in this export.`,
  selfwealth: `SelfWealth transaction history CSV — exported from the SelfWealth app. Supports BUY, SELL, and DIVIDEND rows.`,
  generic_flex: `Generic flexible format — any CSV with columns for Date, Code, Type, Quantity, and Price (column names vary by broker).`,
  template: `Dogbox Investments template — the standard import format. Download the template above for exact column names.`,
  unknown: `Format not recognised — falling back to the Dogbox Investments template format. Download the template above for exact column names.`,
};

async function pageImportData() {
  const content = document.getElementById('module-content');
  content.innerHTML = `
    <div class="st-toolbar">
      <span style="font-size:13px;color:var(--ink2);font-weight:500">Import transactions from CSV</span>
      <a class="btn btn-secondary" href="/api/export/template.csv" style="margin-left:auto">Download Template</a>
      <a class="btn btn-ghost" href="/api/export/transactions.csv">Export All Transactions</a>
    </div>

    <div class="st-list-panel" style="padding:20px 24px">
      <div class="field" style="max-width:280px;margin-bottom:12px">
        <label>Format</label>
        <select id="imp-format">
          <option value="">Auto-detect</option>
          <option value="commsec_confirmations">CommSec Trade Confirmations</option>
          <option value="selfwealth">SelfWealth Transaction History</option>
          <option value="generic_flex">Generic (flexible columns)</option>
          <option value="template">Dogbox Investments Template</option>
        </select>
      </div>
      <div id="imp-hint" style="margin-bottom:16px;font-size:12px;color:var(--ink3);font-family:'DM Mono',monospace;line-height:1.8">
        Select a format or leave on Auto-detect, then choose your CSV file.
      </div>
      <div class="field" style="max-width:400px">
        <label>Select CSV file</label>
        <input type="file" id="imp-file" accept=".csv" onchange="_impFileSelected()">
      </div>
    </div>

    <div id="imp-preview"></div>

    <div class="st-section" style="margin-top:28px"><div class="st-section-title">Full export &amp; import</div><div class="st-section-line"></div></div>
    <div class="st-list-panel" style="padding:20px 24px">
      <div style="font-size:13px;color:var(--ink2);line-height:1.6;margin-bottom:14px">
        <strong>Export everything</strong> saves the whole portfolio as one CSV file: securities and their
        code/name changes, purchases, dividends, corporate actions, sales with the parcels they used,
        the watch list and settings (your TFN is left out). Importing it into a new portfolio gives
        exactly the same figures — or edit it in a spreadsheet first and import the result.
        Your own master file can be imported too: total costs instead of prices, a single ratio for
        splits and consolidations, dividend totals, and parcel labels with sales naming the
        parcels to use (e.g. <span class="mono">amp,drp22,MIN</span>).
      </div>
      <a class="btn btn-secondary" href="/api/export/portfolio.csv">Export Everything</a>
      <a class="btn btn-ghost" href="/api/export/master-template.csv"
        title="An example master file with every row type and notes on each — a starting point for your own">Download Master File Template</a>
      ${_impMasterReference()}
      <div class="field-row cols-2" style="margin-top:18px;max-width:640px;align-items:end">
        <div class="field"><label>New portfolio name</label>
          <input type="text" id="imp-full-name" placeholder="e.g. Rebuilt Portfolio"></div>
        <div class="field"><label>Full export file</label>
          <input type="file" id="imp-full-file" accept=".csv"></div>
      </div>
      <button class="btn btn-primary" id="imp-full-btn" onclick="_impFullImport()">Import into New Portfolio</button>
      <div style="font-size:12px;color:var(--ink3);margin-top:8px">
        Your current portfolio isn't changed. If anything in the file can't be imported, nothing is
        created and the problem line is shown.
      </div>
      <div style="border-top:1px solid var(--border);margin:20px 0 16px"></div>
      <div style="font-size:13px;color:var(--ink2);line-height:1.6;margin-bottom:12px;max-width:760px">
        <strong>Add to this portfolio</strong> adds the records in a file — for example older purchases,
        or inherited shares — to the portfolio that's open. The portfolio is rebuilt from its whole
        history in date order, so earlier purchases get later splits and other corporate actions.
        Sales already recorded keep the parcels they used. The file's settings are ignored.
        You'll see which years' tax figures change before anything is saved.
      </div>
      <div class="field" style="max-width:320px"><label>File to add</label>
        <input type="file" id="imp-merge-file" accept=".csv"></div>
      <button class="btn btn-secondary" id="imp-merge-btn" onclick="_impMergePreview()">Preview Changes</button>
      <div id="imp-merge-result" style="margin-top:14px"></div>
    </div>`;

  document.getElementById('imp-format').addEventListener('change', _impFormatChanged);
}

// Master file row types — matches core/full_export.py (_normalise_rows and the template)
const _IMP_MASTER_ROWS = [
  ['Owner, TFN, FYE, Entity, Tax, Loss', 'Settings. Name = owner, TFN, FYE (June30 or Dec31) or entity (individual, smsf, smsf pension, company); Ratio = marginal tax rate; Cost = capital loss carried in.'],
  ['Security', 'Code, Name. Optional: without Security rows, each code is added with its code as its name. Foreign = Yes for a foreign company, or its treaty rate (e.g. 15%).'],
  ['Holding', 'Code, Name, Ratio = your share (1 sole, 0.5 joint). One per HIN/SRN; optional. Again with a Date and a new Ratio = a joint holder died.'],
  ['Buy', 'Date, Code, Quantity, Cost (total) or Price (per share), Brokerage, Parcel = label, Holding.'],
  ['Sell', 'Date, Code, Quantity, Price or Cost, Brokerage, Parcel = labels to sell from, then MIN, MAX or FIFO. Holding.'],
  ['Div', 'Date (paid), Code, Franked, Unfranked, Credit, Record or Ex Date. Withheld = tax withheld. Unfranked and Withheld can be as on the statement (US$50.00) with Ratio = the exchange rate (A$ per US$1). DRP: Quantity and Cost of the shares received.'],
  ['Bonus', 'Ratio = shares after per share before, or Quantity = bonus shares received in the row\'s Holding.'],
  ['Rights', 'Quantity taken up, Price per share: a new parcel.'],
  ['RoC', 'Return of capital: Price per share, or Cost = the total.'],
  ['Con / Split', 'Ratio = shares after per share before, or Quantity = the change in shares. Cost on a Con = a return of capital paid with it.'],
  ['Cancel', 'Shares cancelled for a payment (a disposal): Quantity, Price or Cost; taken from every parcel in proportion.'],
  ['Demerger', 'Code, Code2 = new company, Quantity = new shares per share, Ratio = share of the cost base moving to it.'],
  ['Merger', 'Takeover: Code = received, Code2 = given up, Quantity = new shares in all, Cost = total cash, Price = market value of one new share.'],
  ['Rename', 'Code = the code before, Code2 = new code and/or Name = new name.'],
  ['Transfer', 'Holding = from, To Holding = to, Code = one company only. Not a CGT event.'],
  ['Inherit', 'Date = date of death, Quantity, Cost = deceased\'s cost base, Original Date = their purchase date (pre-CGT: Cost = market value, no Original Date).'],
  ['Value', 'Date, Code, Price = market value of one share, for pre-CGT shares at a joint holder\'s death.'],
];

function _impMasterReference() {
  return `<details style="margin-top:14px;max-width:900px">
    <summary style="cursor:pointer;font-size:13px;font-weight:600;color:var(--ink2)">Master file format</summary>
    <div style="font-size:12px;color:var(--ink2);line-height:1.6;margin:10px 0">
      One row per event, with the row type in the Type column. Dates are YYYY-MM-DD or DD/MM/YYYY, and rows
      can be in any order. A row with text in Type only is a comment. Corporate actions apply to every holding,
      so one row is enough. The template has an example of each.
    </div>
    <table class="st-table" style="font-size:12px"><tbody>
      ${_IMP_MASTER_ROWS.map(([t, d]) => `<tr><td class="mono" style="white-space:nowrap;vertical-align:top">${t}</td><td>${d}</td></tr>`).join('')}
    </tbody></table>
  </details>`;
}

async function _impFullImport() {
  const name = (document.getElementById('imp-full-name').value || '').trim();
  const file = document.getElementById('imp-full-file').files[0];
  if (!name) return toast('Enter a name for the new portfolio', 'err');
  if (!file) return toast('Choose the full export file', 'err');
  const btn = document.getElementById('imp-full-btn');
  btn.disabled = true; btn.textContent = 'Importing…';
  const fd = new FormData();
  fd.append('file', file);
  fd.append('name', name);
  try {
    const r = await fetch('/api/import/portfolio', { method: 'POST', body: fd }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    const c = r.data.counts;
    document.getElementById('portfolio-name').textContent = r.data.name;
    await _loadAppSettings();
    _currentModule = null;
    navigate('dashboard');
    toast(`Imported into ${r.data.name}: ${c.purchases} purchases, ${c.sales} sales, ` +
          `${c.dividends} dividends, ${c.corporate_actions} corporate actions`);
    (c.notes || []).forEach(n => toast(n));
  } catch (e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = 'Import into New Portfolio';
  }
}

// ── Add a file to this portfolio ──────────────────────────────────────────────

let _impMergeFingerprint = null;

async function _impMergePreview() {
  const file = document.getElementById('imp-merge-file').files[0];
  const out = document.getElementById('imp-merge-result');
  if (!file) return toast('Choose the file to add', 'err');
  const btn = document.getElementById('imp-merge-btn');
  btn.disabled = true; btn.textContent = 'Checking…';
  out.innerHTML = '';
  const fd = new FormData();
  fd.append('file', file);
  try {
    const r = await fetch('/api/import/merge/preview', { method: 'POST', body: fd }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    _impMergeFingerprint = r.data.fingerprint;
    out.innerHTML = _impMergeSummary(r.data);
  } catch (e) {
    out.innerHTML = `<div style="color:var(--red);font-size:13px">${e.message}</div>`;
  } finally {
    btn.disabled = false; btn.textContent = 'Preview Changes';
  }
}

function _impMergeSummary(d) {
  const c = d.counts;
  const what = [['purchases', 'purchase', 'purchases'], ['sales', 'sale', 'sales'],
                ['dividends', 'dividend', 'dividends'],
                ['corporate_actions', 'corporate action', 'corporate actions'],
                ['securities', 'new security', 'new securities']]
    .filter(([k]) => c[k]).map(([k, one, many]) => `${c[k]} ${c[k] === 1 ? one : many}`);
  const notes = (d.notes || []).map(n => `<li>${n}</li>`).join('');
  const rows = d.changes.map(ch => ch.figures.map((f, i) => `<tr>
      ${i === 0 ? `<td rowspan="${ch.figures.length}" class="mono">FY${ch.fy}${ch.locked ? ' <span class="badge badge-amber">Locked</span>' : ''}</td>` : ''}
      <td>${f.label}</td>
      <td class="num mono">${fmtCurrency(f.before)}</td>
      <td class="num mono">${fmtCurrency(f.after)}</td>
    </tr>`).join('')).join('');
  const table = d.changes.length ? `
    <div class="tbl-overflow" style="max-width:760px;margin:10px 0">
      <table class="st-table">
        <thead><tr><th>Year</th><th>Figure</th><th class="num">Now</th><th class="num">After adding</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>` : '<div style="font-size:13px;color:var(--ink2);margin:8px 0">No tax figures change in any year.</div>';
  const blocked = d.blocked.length
    ? `<div style="color:var(--red);font-size:13px;margin:8px 0">FY${d.blocked.join(', FY')} ${d.blocked.length === 1 ? 'is' : 'are'}
         locked and ${d.blocked.length === 1 ? 'its' : 'their'} figures would change, so the file can't be added.
         Unlock the year in Settings first if the lodged figures were wrong.</div>`
    : '';
  return `
    <div style="font-size:13px;color:var(--ink2)">Adds ${what.join(', ') || 'nothing new'}.</div>
    ${notes ? `<ul style="font-size:12px;color:var(--ink3);margin:6px 0 0 18px">${notes}</ul>` : ''}
    ${table}${blocked}
    <button class="btn btn-primary" onclick="_impMergeApply()" ${d.blocked.length ? 'disabled' : ''}>Add to This Portfolio</button>
    <button class="btn btn-ghost" onclick="_impMergeCancel()">Cancel</button>
    <div style="font-size:12px;color:var(--ink3);margin-top:6px">A backup copy is saved next to the portfolio file first.</div>`;
}

async function _impMergeApply() {
  try {
    const r = await fetch('/api/import/merge/apply', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fingerprint: _impMergeFingerprint }) }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    _impMergeFingerprint = null;
    await _loadAppSettings();
    _currentModule = null;
    navigate('dashboard');
    toast('Records added. A backup of the portfolio before the change was saved.');
  } catch (e) { toast(e.message, 'err'); }
}

async function _impMergeCancel() {
  await fetch('/api/import/merge/cancel', { method: 'POST' });
  _impMergeFingerprint = null;
  document.getElementById('imp-merge-result').innerHTML = '';
}

function _impFormatChanged() {
  const fmt = document.getElementById('imp-format')?.value;
  const hint = document.getElementById('imp-hint');
  if (!hint) return;
  if (fmt && _IMP_FORMAT_HINTS[fmt]) {
    hint.innerHTML = _IMP_FORMAT_HINTS[fmt];
  } else {
    hint.innerHTML = 'Select a format or leave on Auto-detect, then choose your CSV file.';
  }
  // Re-parse if a file is already loaded
  const file = document.getElementById('imp-file')?.files[0];
  if (file) _impFileSelected();
}

async function _impFileSelected() {
  const file = document.getElementById('imp-file')?.files[0];
  if (!file) return;

  const preview = document.getElementById('imp-preview');
  preview.innerHTML = '<div class="st-empty"><div class="st-empty-icon">⏳</div>Parsing…</div>';

  const fd = new FormData();
  fd.append('file', file);
  const fmt = document.getElementById('imp-format')?.value || '';
  if (fmt) fd.append('format', fmt);

  try {
    const r = await fetch('/api/import/preview', { method: 'POST', body: fd }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    _impRenderPreview(r.data.rows, r.data.errors, r.data.format_label);
  } catch (e) {
    preview.innerHTML = `<div class="st-empty"><div class="st-empty-title">Parse error</div><div>${e.message}</div></div>`;
  }
}

let _impRows = [];

function _impRenderPreview(rows, errors, formatLabel) {
  _impRows = rows;
  const preview = document.getElementById('imp-preview');

  const valid   = rows.filter(r => !r.warning && r.security_id);
  const warned  = rows.filter(r => r.warning);
  const errored = errors;

  const typeColor = { Buy: 'badge-accent', Sell: 'badge-amber', Dividend: 'badge-green' };

  preview.innerHTML = `
    ${formatLabel ? `
    <div style="margin-bottom:12px;font-size:11px;color:var(--ink3)">
      Detected format: <span class="badge badge-ink" style="font-size:10px">${formatLabel}</span>
    </div>` : ''}

    ${errored.length ? `
    <div style="padding:12px 16px;background:var(--red-dim);border-radius:8px;margin-bottom:16px;font-size:12px;color:var(--red)">
      <strong>${errored.length} parse error${errored.length !== 1 ? 's' : ''}:</strong>
      ${errored.map(e => `<div style="margin-top:4px">Row ${e.row}: ${e.error}</div>`).join('')}
    </div>` : ''}

    <div class="st-kpi-strip" style="margin-bottom:16px">
      <div class="st-kpi">
        <div class="st-kpi-label">Ready to import</div>
        <div class="st-kpi-value col-green">${valid.length}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Skipped (unknown code)</div>
        <div class="st-kpi-value col-amber">${warned.length}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Parse errors</div>
        <div class="st-kpi-value ${errored.length ? 'col-red' : 'col-ink3'}">${errored.length}</div>
      </div>
    </div>

    <div class="st-list-panel" style="margin-bottom:16px">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>#</th><th>Type</th><th>Date</th><th>Code</th>
            <th class="num">Qty</th><th class="num">Price</th>
            <th class="num">Brokerage</th><th>Notes</th><th>Status</th>
          </tr></thead>
          <tbody>
            ${rows.map(r => `<tr style="${r.warning ? 'opacity:0.55' : ''}">
              <td class="mono" style="color:var(--ink3)">${r.row}</td>
              <td><span class="badge ${typeColor[r.type] || ''}">${r.type}</span></td>
              <td class="mono">${fmtDate(r.date)}</td>
              <td class="code-cell">${r.code}</td>
              <td class="num mono">${fmtNum(r.quantity, 4)}</td>
              <td class="num mono">${fmtCurrency(r.price, 4)}</td>
              <td class="num mono">${r.brokerage ? fmtCurrency(r.brokerage) : '—'}</td>
              <td style="font-size:11px;color:var(--ink3)">${r.notes || ''}</td>
              <td style="font-size:11px">${r.warning
                ? `<span style="color:var(--amber)">${r.warning}</span>`
                : '<span style="color:var(--green)">✓ Ready</span>'}</td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>

    ${valid.length > 0 ? `
    <div style="display:flex;gap:10px;align-items:center">
      <button class="btn btn-primary" onclick="_impCommit()">Import ${valid.length} transaction${valid.length !== 1 ? 's' : ''}</button>
      <span style="font-size:12px;color:var(--ink3)">${warned.length > 0 ? `${warned.length} row${warned.length !== 1 ? 's' : ''} with unknown securities will be skipped` : ''}</span>
    </div>` : `
    <div style="font-size:13px;color:var(--ink3)">No importable rows found. Check that your security codes match existing securities.</div>`}`;
}

async function _impCommit() {
  const validRows = _impRows.filter(r => r.security_id);
  if (!validRows.length) return;

  try {
    const r = await fetch('/api/import/commit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rows: validRows }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);

    const { imported, skipped, failed } = r.data;
    const preview = document.getElementById('imp-preview');

    if (failed.length) {
      preview.innerHTML += `<div style="margin-top:12px;padding:12px 16px;background:var(--red-dim);border-radius:8px;font-size:12px;color:var(--red)">
        ${failed.length} row${failed.length !== 1 ? 's' : ''} failed:
        ${failed.map(f => `<div>Row ${f.row}: ${f.error}</div>`).join('')}
      </div>`;
    }

    toast(`${imported} transaction${imported !== 1 ? 's' : ''} imported${skipped ? `, ${skipped} skipped` : ''}`);

    // Reset file input and clear preview
    const fi = document.getElementById('imp-file');
    if (fi) fi.value = '';
    _impRows = [];
    document.getElementById('imp-preview').innerHTML = '';
  } catch (e) {
    toast(e.message, 'err');
  }
}
