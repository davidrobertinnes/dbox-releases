// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — Dividends with edit/delete */

async function pageDividends() {
  const content = document.getElementById('module-content');
  content.innerHTML = `
    <div class="st-toolbar">
      <input class="st-search" id="div-search" type="search" placeholder="Search dividends…">
      <span style="font-size:12px;color:var(--ink3)">From</span>
      <input type="date" id="div-from" style="padding:6px 10px;border:1px solid var(--border);border-radius:7px;background:var(--surface);font-size:12px;font-family:inherit;color:var(--ink);outline:none">
      <span style="font-size:12px;color:var(--ink3)">To</span>
      <input type="date" id="div-to" style="padding:6px 10px;border:1px solid var(--border);border-radius:7px;background:var(--surface);font-size:12px;font-family:inherit;color:var(--ink);outline:none">
      <button class="btn btn-ghost btn-sm" onclick="_divClearFilters()">Clear</button>
      <button class="btn btn-primary" onclick="_divOpenForm(null)">+ Dividend</button>
    </div>
    <div class="st-list-panel">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Payment Date</th><th>Code</th><th class="num">Qty Held</th>
            <th class="num">Per Share</th><th class="num">Gross</th>
            <th class="num">Franking %</th><th class="num">Franking Cr.</th>
            <th title="45-day holding period rule eligibility">45d</th>
            <th class="num">Net</th><th>DRP</th><th></th>
          </tr></thead>
          <tbody id="div-tbody"></tbody>
        </table>
      </div>
    </div>
    <div class="count-pill" id="div-count"></div>`;

  document.getElementById('div-search').addEventListener('input', _divFilter);
  document.getElementById('div-from').addEventListener('change', _divFilter);
  document.getElementById('div-to').addEventListener('change', _divFilter);

  await _divLoad();
}

let _divRows = [];
let _divSecurities = [];

async function _divLoad() {
  try {
    [_divRows, _divSecurities] = await Promise.all([
      apiFetch('/api/dividends'),
      apiFetch('/api/securities'),
    ]);
    _divRender();
  } catch (e) {
    toast(e.message, 'err');
  }
}

function _divRender() {
  const tbody = document.getElementById('div-tbody');
  if (!_divRows.length) {
    tbody.innerHTML = `<tr><td colspan="10"><div class="st-empty">
      <div class="st-empty-icon">💰</div>
      <div class="st-empty-title">No dividends recorded</div>
    </div></td></tr>`;
    document.getElementById('div-count').textContent = '0 dividends';
    return;
  }
  tbody.innerHTML = _divRows.map(d => `<tr data-date="${d.payment_date}">
    <td class="mono">${fmtDate(d.payment_date)}</td>
    <td class="code-cell">${d.code}</td>
    <td class="num mono">${fmtNum(d.quantity_held, 4)}</td>
    <td class="num mono">${fmtCurrency(d.amount_per_share, 4)}</td>
    <td class="num mono">${fmtCurrency(d.gross_amount)}</td>
    <td class="num mono">${d.franking_pct ? d.franking_pct + '%' : '—'}</td>
    <td class="num mono">${d.franking_credit ? fmtCurrency(d.franking_credit) : '—'}</td>
    <td>${_div45Badge(d)}</td>
    <td class="num mono">${fmtCurrency(d.net_amount)}</td>
    <td>${d.is_drp ? '<span class="badge badge-accent">DRP</span>' : '—'}</td>
    <td style="white-space:nowrap">${
      _isLocked(d.payment_date)
        ? '<span class="badge badge-amber" title="FY locked — cannot modify after lodgement">Locked</span>'
        : `<button class="btn btn-ghost btn-sm" onclick="_divOpenForm(${d.id})">Edit</button>
           <button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="_divDelete(${d.id})">Del</button>`
    }</td>
  </tr>`).join('');
  document.getElementById('div-count').textContent =
    `${_divRows.length} dividend${_divRows.length !== 1 ? 's' : ''}`;
}

// ── Filter ────────────────────────────────────────────────────────────────────

function _divFilter() {
  const q    = document.getElementById('div-search').value.toLowerCase();
  const from = document.getElementById('div-from').value;
  const to   = document.getElementById('div-to').value;
  let visible = 0;
  document.querySelectorAll('#div-tbody tr').forEach(r => {
    const date    = r.dataset.date || '';
    const inRange = (!from || date >= from) && (!to || date <= to);
    const match   = inRange && r.textContent.toLowerCase().includes(q);
    r.style.display = match ? '' : 'none';
    if (match) visible++;
  });
  document.getElementById('div-count').textContent = `${visible} of ${_divRows.length} dividends`;
}

function _divClearFilters() {
  document.getElementById('div-search').value = '';
  document.getElementById('div-from').value   = '';
  document.getElementById('div-to').value     = '';
  _divFilter();
}

// ── Delete ────────────────────────────────────────────────────────────────────

async function _divDelete(divId) {
  if (!confirm('Delete this dividend? If it has a DRP parcel that has not been sold, that parcel will also be removed.')) return;
  try {
    const r = await fetch(`/api/dividends/${divId}`, { method: 'DELETE' }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    toast('Dividend deleted');
    await _divLoad();
  } catch (e) {
    toast(e.message, 'err');
  }
}

// ── Create / edit form ────────────────────────────────────────────────────────

function _divOpenForm(divId) {
  const d = divId ? _divRows.find(r => r.id === divId) : null;
  const isEdit = !!d;

  const secOptions = _divSecurities.map(s =>
    `<option value="${s.id}" ${d && s.id === d.security_id ? 'selected' : ''}>${s.code} — ${s.name}</option>`
  ).join('');

  const hasDrp = d && d.is_drp;

  openPanel(isEdit ? 'Edit Dividend' : 'Record Dividend', `
    <div class="field">
      <label>Security</label>
      <select id="div-security" ${isEdit ? 'disabled' : ''}>
        <option value="">Select…</option>${secOptions}
      </select>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Payment Date</label>
        <input type="date" id="div-pay-date" value="${d?.payment_date || new Date().toISOString().slice(0,10)}">
      </div>
      <div class="field"><label>Ex-Dividend Date <span style="font-weight:400;text-transform:none;letter-spacing:0;color:var(--amber)">required for 45-day rule</span></label>
        <input type="date" id="div-ex-date" value="${d?.ex_date || ''}">
      </div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Quantity Held</label>
        <input type="number" id="div-qty" min="0" step="any" value="${d?.quantity_held || ''}" placeholder="0" oninput="_divCalcFranking()">
      </div>
      <div class="field"><label>Amount Per Share ($)</label>
        <input type="number" id="div-aps" min="0" step="any" value="${d?.amount_per_share || ''}" placeholder="0.0000" oninput="_divCalcFranking()">
      </div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Franking % <span style="font-weight:400;text-transform:none;letter-spacing:0">(0–100)</span></label>
        <input type="number" id="div-frank" min="0" max="100" step="any" value="${d?.franking_pct ?? 0}" oninput="_divCalcFranking()">
      </div>
      <div class="field"><label>Franking Credit ($) <span style="font-weight:400;text-transform:none;letter-spacing:0">from statement</span></label>
        <input type="number" id="div-frank-amt" min="0" step="any" value="${d?.franking_credit ? d.franking_credit.toFixed(2) : ''}" placeholder="0.00">
      </div>
    </div>
    <div style="font-size:11px;color:var(--ink3);margin-top:-8px;margin-bottom:12px">Franking credit auto-calculates from % as a guide — verify the dollar amount against your dividend statement and correct if needed.</div>
    ${isEdit && hasDrp ? `
    <div style="padding:10px 12px;background:var(--amber-dim);border-radius:7px;font-size:12px;color:var(--amber);margin-bottom:12px">
      This dividend has a DRP parcel. DRP details cannot be edited here — delete and re-enter to change DRP.
    </div>` : !isEdit ? `
    <div class="field"><label>
      <input type="checkbox" id="div-drp" onchange="_divToggleDrp()"> Dividend Reinvestment Plan (DRP)
    </label></div>
    <div id="div-drp-fields" style="display:none">
      <div class="field-row cols-2">
        <div class="field"><label>DRP Shares Issued</label>
          <input type="number" id="div-drp-qty" min="0" step="any" placeholder="0">
        </div>
        <div class="field"><label>DRP Price ($)</label>
          <input type="number" id="div-drp-price" min="0" step="any" placeholder="0.00">
        </div>
      </div>
    </div>` : ''}
    <div class="field"><label>Notes</label>
      <textarea id="div-notes" placeholder="Optional">${d?.notes || ''}</textarea>
    </div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_divSave(${divId || 'null'})">${isEdit ? 'Save Changes' : 'Save Dividend'}</button>`
  );
}

function _div45Badge(d) {
  if (!d.franking_credit) return '—';
  if (d.eligible_45day === true)  return '<span class="badge badge-green" title="45-day rule satisfied — franking credit claimable">✓</span>';
  if (d.eligible_45day === false) return '<span class="badge badge-red"   title="45-day rule NOT satisfied — franking credit cannot be claimed">✗</span>';
  return '<span class="badge badge-amber" title="Add ex-dividend date to check 45-day holding period rule">?</span>';
}

function _divToggleDrp() {
  const checked = document.getElementById('div-drp')?.checked;
  const fields = document.getElementById('div-drp-fields');
  if (fields) fields.style.display = checked ? '' : 'none';
}

function _divCalcFranking() {
  const qty   = parseFloat(document.getElementById('div-qty')?.value) || 0;
  const aps   = parseFloat(document.getElementById('div-aps')?.value) || 0;
  const pct   = parseFloat(document.getElementById('div-frank')?.value) || 0;
  const gross = qty * aps;
  const el    = document.getElementById('div-frank-amt');
  if (!el) return;
  el.value = (pct && gross) ? ((gross * pct / 100) / 0.70 * 0.30).toFixed(2) : '';
}

async function _divSave(divId) {
  const isEdit = !!divId;
  const security_id    = isEdit
    ? _divRows.find(r => r.id === divId)?.security_id
    : document.getElementById('div-security').value;
  const payment_date   = document.getElementById('div-pay-date').value;
  const ex_date        = document.getElementById('div-ex-date').value || null;
  const quantity_held  = document.getElementById('div-qty').value;
  const amount_per_share = document.getElementById('div-aps').value;
  const franking_pct    = document.getElementById('div-frank').value || '0';
  const franking_credit = document.getElementById('div-frank-amt').value || '0';
  const notes           = document.getElementById('div-notes').value;

  if (!security_id)    return toast('Select a security', 'err');
  if (!payment_date)   return toast('Payment date is required', 'err');
  if (!quantity_held || parseFloat(quantity_held) <= 0) return toast('Quantity held must be > 0', 'err');
  if (!amount_per_share || parseFloat(amount_per_share) <= 0) return toast('Amount per share must be > 0', 'err');

  try {
    if (isEdit) {
      const r = await fetch(`/api/dividends/${divId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ payment_date, ex_date, quantity_held, amount_per_share,
                               franking_pct, franking_credit, notes }),
      }).then(r => r.json());
      if (!r.ok) throw new Error(r.error);
      closePanel();
      toast('Dividend updated');
    } else {
      const is_drp    = document.getElementById('div-drp')?.checked ? 1 : 0;
      const drp_quantity = is_drp ? document.getElementById('div-drp-qty')?.value : null;
      const drp_price    = is_drp ? document.getElementById('div-drp-price')?.value : null;
      const r = await fetch('/api/dividends', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ security_id, payment_date, ex_date, quantity_held,
                               amount_per_share, franking_pct, franking_credit,
                               is_drp, drp_quantity, drp_price, notes }),
      }).then(r => r.json());
      if (!r.ok) throw new Error(r.error);
      closePanel();
      toast('Dividend recorded');
    }
    await _divLoad();
  } catch (e) {
    toast(e.message, 'err');
  }
}
