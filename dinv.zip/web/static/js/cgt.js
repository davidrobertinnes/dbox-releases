// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — CGT Summary */

async function pageCgt() {
  const content = document.getElementById('module-content');

  const today = new Date();
  const currentFy = today.getMonth() >= 6 ? today.getFullYear() + 1 : today.getFullYear();

  content.innerHTML = `
    <div class="st-toolbar">
      <label style="font-size:13px;color:var(--ink2);font-weight:500">Financial Year ending 30 June</label>
      <select id="cgt-fy" style="padding:7px 12px;border:1px solid var(--border);border-radius:7px;background:var(--surface);font-size:13px;font-family:inherit;color:var(--ink);outline:none">
        ${fyOptions(currentFy)}
      </select>
      <button class="btn btn-secondary" onclick="_cgtLoad()">Load</button>
      <div style="margin-left:auto;display:flex;gap:8px">
        <button class="btn btn-ghost" onclick="_cgtExportIncome()">Export Income CSV</button>
        <button class="btn btn-ghost" onclick="_cgtExport()">Export CGT Schedule</button>
      </div>
    </div>
    <div id="cgt-content"></div>`;

  await _cgtLoad();
}

function _cgtExport() {
  const fy = document.getElementById('cgt-fy')?.value;
  if (fy) window.location.href = `/api/export/cgt.csv?fy=${fy}`;
}

function _cgtExportIncome() {
  const fy = document.getElementById('cgt-fy')?.value;
  if (fy) window.location.href = `/api/export/income.csv?fy=${fy}`;
}

let _cgtD296 = null;

async function _cgtLoad() {
  const fy = parseInt(document.getElementById('cgt-fy').value);
  const cgtContent = document.getElementById('cgt-content');
  cgtContent.innerHTML = '<div class="st-empty"><div class="st-empty-icon">⏳</div>Loading…</div>';

  try {
    const [rows, divs, rocGains, fyc, inc, d296] = await Promise.all([
      apiFetch(`/api/cgt?fy=${fy}`),
      apiFetch(`/api/dividends?fy=${fy}`),
      apiFetch(`/api/roc-cgt?fy=${fy}`),
      apiFetch(`/api/cgt-fy-summary?fy=${fy}`),
      apiFetch(`/api/income-fy-summary?fy=${fy}`),
      apiFetch(`/api/div296?fy=${fy}`),
    ]);
    _cgtD296 = d296;
    _cgtRender(rows, divs, rocGains, fy, fyc, inc);
    document.getElementById('cgt-content').insertAdjacentHTML('afterbegin', ownershipNote());
  } catch (e) {
    toast(e.message, 'err');
  }
}

function _cgtRender(rows, divs, rocGains, fy, fyc, inc) {
  const cgtContent = document.getElementById('cgt-content');

  // Franking credit summary — split eligible vs ineligible (45-day rule)
  const totalDivIncome     = divs.reduce((s, d) => s + (d.net_amount || 0), 0);
  // Claimable / excluded credits from compute_fy_income (45-day rule + small shareholder exemption)
  const eligibleFranking   = inc.credits_claimable;
  const ineligibleFranking = inc.credits_ineligible;
  const unknownFranking    = inc.credits_unverified;
  const totalFranking      = eligibleFranking + ineligibleFranking + unknownFranking;
  const frankByCode        = {};
  divs.forEach(d => {
    if (!d.franking_credit) return;
    if (!frankByCode[d.code]) frankByCode[d.code] = { code: d.code, name: d.name, credit: 0, income: 0 };
    frankByCode[d.code].credit += d.franking_credit;
    frankByCode[d.code].income += d.net_amount || 0;
  });
  const frankRows = Object.values(frankByCode).sort((a,b) => b.credit - a.credit);

  if (!rows.length && !rocGains.length) {
    cgtContent.innerHTML = `<div class="st-empty" style="margin-bottom:24px">
      <div class="st-empty-icon">📋</div>
      <div class="st-empty-title">No disposals in FY${fy}</div>
      <div>Sales made between 1 July ${fy-1} and 30 June ${fy} will appear here.</div>
    </div>
    ${_cgtIncomeHtml(divs, fy)}
    ${_cgtFrankingHtml(eligibleFranking, ineligibleFranking, unknownFranking, totalDivIncome, frankRows, fy, inc.small_shareholder_exempt)}
    ${_cgtDiv296Html(_cgtD296)}`;
    return;
  }

  const exemptBasis     = b => b === 'pre_cgt' || b === 'not_cgt';
  const totalGain       = rows.filter(r => !exemptBasis(r.cgt_basis)).reduce((s, r) => s + r.gain_loss, 0);
  const eligibleRows    = rows.filter(r => r.discount_eligible);
  const rocTotalGain    = rocGains.reduce((s, r) => s + r.excess_cg, 0);

  // Item 18 figures computed server-side (ATO method: losses applied before the discount)
  const carryforward   = fyc.carry_forward;
  const lossesApplied  = fyc.current_losses_applied + fyc.prior_losses_applied;
  const salesTaxable   = rows.reduce((s, r) => s + r.taxable_gain, 0);

  cgtContent.innerHTML = `
    <div class="st-kpi-strip">
      <div class="st-kpi">
        <div class="st-kpi-label">Total Gross Gain/Loss</div>
        <div class="st-kpi-value ${totalGain >= 0 ? 'col-green' : 'col-red'}">${fmtCurrency(totalGain)}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Net Capital Gain (18A)</div>
        <div class="st-kpi-value ${fyc.net_capital_gain > 0 ? 'col-green' : 'col-ink'}">${fmtCurrency(fyc.net_capital_gain)}</div>
        <div class="st-kpi-sub">${fmtCurrency(lossesApplied)} losses, then ${fmtCurrency(fyc.discount_applied)} discount · ${eligibleRows.length} parcel${eligibleRows.length !== 1 ? 's' : ''} discount-eligible</div>
      </div>
      ${rocTotalGain > 0 ? `
      <div class="st-kpi">
        <div class="st-kpi-label">ROC Capital Gains</div>
        <div class="st-kpi-value col-red">${fmtCurrency(rocTotalGain)}</div>
        <div class="st-kpi-sub">see the Return of Capital section</div>
      </div>` : ''}
      ${carryforward > 0 ? `
      <div class="st-kpi">
        <div class="st-kpi-label">Prior-Year Losses Applied</div>
        <div class="st-kpi-value col-ink">${fmtCurrency(fyc.prior_losses_applied)}</div>
        <div class="st-kpi-sub">of ${fmtCurrency(carryforward)} available · ${fmtCurrency(fyc.carry_forward_remaining)} carried forward</div>
      </div>` : ''}
      <div class="st-kpi">
        <div class="st-kpi-label">Disposals</div>
        <div class="st-kpi-value col-ink">${rows.length}</div>
      </div>
      ${eligibleFranking > 0 ? `
      <div class="st-kpi">
        <div class="st-kpi-label">Franking Credits (Claimable)</div>
        <div class="st-kpi-value col-accent">${fmtCurrency(eligibleFranking)}</div>
        <div class="st-kpi-sub">${ineligibleFranking > 0 ? `<span style="color:var(--red)">${fmtCurrency(ineligibleFranking)} ineligible</span>` : unknownFranking > 0 ? `<span style="color:var(--amber)">${fmtCurrency(unknownFranking)} unverified</span>` : 'income tax offset'}</div>
      </div>` : ''}
    </div>

    ${fyc.needs_value ? `<div class="ts-alert ts-alert-amber" style="margin-bottom:12px">
      <strong>${fyc.needs_value} sale${fyc.needs_value !== 1 ? 's need' : ' needs'} a 30 June 2027 value.</strong>
      Shares held at the end of 30 June 2027 are treated as sold and bought back at their value then. Until you enter
      it, the whole gain is counted without a discount. <a href="#" onclick="navigate('settings');return false">Enter the values in Settings</a>.
    </div>` : ''}
    <div class="st-list-panel">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Sale Date</th><th>Code</th><th>Acquired</th>
            <th class="num">Qty</th><th class="num">Proceeds</th>
            <th class="num">Cost Base</th><th class="num">Gain/Loss</th>
            <th>Method</th><th class="num">Taxable Gain</th>
          </tr></thead>
          <tbody>
            ${rows.map(r => `<tr>
              <td class="mono">${fmtDate(r.sale_date)}${r.kind === 'cancellation' ? ' <span class="badge badge-ink" title="Share cancellation — CGT event C2">Cancelled</span>' : r.kind === 'takeover' ? ' <span class="badge badge-ink" title="Takeover — shares disposed of for cash and/or new shares">Takeover</span>' : ''}</td>
              <td class="code-cell">${r.code}</td>
              <td class="mono">${fmtDate(r.acquisition_date)}</td>
              <td class="num mono">${fmtNum(r.quantity, 4)}</td>
              <td class="num mono">${fmtCurrency(r.net_proceeds)}</td>
              <td class="num mono">${fmtCurrency(r.cost_base_used)}${r.indexed_cost_base != null
                ? `<div style="font-size:11px;color:var(--ink3)" title="Cost base indexed to September 1999">indexed ${fmtCurrency(r.indexed_cost_base)}</div>` : ''}</td>
              <td class="num"><span class="${exemptBasis(r.cgt_basis) ? '' : gainClass(r.gain_loss)}"
                ${exemptBasis(r.cgt_basis) ? 'style="color:var(--ink3);text-decoration:line-through" title="Exempt — not a taxable gain or loss"' : ''}>${fmtCurrency(r.gain_loss)}</span>${cgt2027Parts(r)}</td>
              <td>${cgtBasisBadge(r.cgt_basis)}${r.origin === 'inherited' ? ' <span class="badge badge-accent">Inherited</span>' : r.origin === 'employee' ? ' <span class="badge badge-accent" title="Employee share plan shares">Employee</span>' : ''}</td>
              <td class="num"><span class="${gainClass(r.taxable_gain)}">${fmtCurrency(r.taxable_gain)}</span></td>
            </tr>`).join('')}
            <tr style="font-weight:600;border-top:2px solid var(--border2)">
              <td colspan="6" style="text-align:right;color:var(--ink3);font-size:12px">Totals</td>
              <td class="num"><span class="${gainClass(totalGain)}">${fmtCurrency(totalGain)}</span></td>
              <td></td>
              <td class="num"><span class="${gainClass(salesTaxable)}">${fmtCurrency(salesTaxable)}</span></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="count-pill">${rows.length} disposal row${rows.length !== 1 ? 's' : ''} — FY${fy} (1 Jul ${fy-1} – 30 Jun ${fy}) · Taxable Gain = each row's share of 18A, after losses then discount</div>

    ${_cgtRocHtml(rocGains, fy)}
    ${_cgtIncomeHtml(divs, fy)}
    ${_cgtFrankingHtml(eligibleFranking, ineligibleFranking, unknownFranking, totalDivIncome, frankRows, fy, inc.small_shareholder_exempt)}
    ${_cgtDiv296Html(_cgtD296)}`;

}

function _cgtRocHtml(rocGains, fy) {
  if (!rocGains.length) return '';
  const totExcess = rocGains.reduce((s, r) => s + r.excess_cg, 0);
  const totDisc   = rocGains.reduce((s, r) => s + r.taxable_gain, 0);
  return `
    <div class="st-section" style="margin-top:28px">
      <div class="st-section-title">Return of Capital — Capital Gains FY${fy}</div>
      <div class="st-section-line"></div>
    </div>
    <div style="font-size:11px;color:var(--amber);padding:6px 2px 10px">
      ⚠ For these parcels a return of capital was more than the cost base (the indexed cost base, for the indexation method), or was paid on shares already sold (sold after the ex-date: the payment is still yours, and all of it is a capital gain). These gains must be included in your tax return.
    </div>
    <div class="st-list-panel" style="margin-bottom:8px">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Action Date</th><th>Code</th><th>Acquired</th>
            <th class="num">CB Reduction</th><th class="num">Excess (Capital Gain)</th>
            <th>Method</th><th class="num">Taxable Gain</th>
          </tr></thead>
          <tbody>
            ${rocGains.map(r => `<tr>
              <td class="mono">${fmtDate(r.action_date)}</td>
              <td class="code-cell">${r.code}</td>
              <td class="mono">${fmtDate(r.acquisition_date)}</td>
              <td class="num mono">${r.sold_units ? `<span style="font-family:inherit;color:var(--ink3)" title="Sold between the ex-date and the payment date: the payment is a capital gain (CGT event C2), with no cost base">${fmtNum(r.sold_units, 4)} sold before payment</span>` : fmtCurrency(r.cost_base_reduction)}</td>
              <td class="num mono col-red">${fmtCurrency(r.excess_cg)}</td>
              <td>${cgtBasisBadge(r.cgt_basis)}</td>
              <td class="num mono col-red">${fmtCurrency(r.taxable_gain)}</td>
            </tr>`).join('')}
            <tr style="font-weight:600;border-top:2px solid var(--border2)">
              <td colspan="4" style="text-align:right;color:var(--ink3);font-size:12px">Totals</td>
              <td class="num mono col-red">${fmtCurrency(totExcess)}</td>
              <td></td>
              <td class="num mono col-red">${fmtCurrency(totDisc)}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>`;
}

function _cgt45Badge(d) {
  if (!d.franking_credit) return '';
  if (d.eligible_45day === true)  return `<span class="badge badge-green" title="45-day rule satisfied${div45Note(d)}">✓</span>`;
  if (d.eligible_45day === false) return `<span class="badge badge-red"   title="45-day rule not satisfied — credit not claimable${div45Note(d)}">✗</span>`;
  return '<span class="badge badge-amber" title="Add ex-dividend date to verify 45-day eligibility">?</span>';
}

function _cgtIncomeHtml(divs, fy) {
  const totNet          = divs.reduce((s, d) => s + (d.net_amount || 0), 0);
  const totEligFrank    = divs.reduce((s, d) => d.eligible_45day !== false ? s + (d.franking_credit || 0) : s, 0);
  const totIneligFrank  = divs.reduce((s, d) => d.eligible_45day === false ? s + (d.franking_credit || 0) : s, 0);
  const totFrank        = totEligFrank + totIneligFrank +
                          divs.reduce((s, d) => d.eligible_45day === null ? s + (d.franking_credit || 0) : s, 0);
  const totGross        = totNet + totEligFrank;
  const hasInelig       = totIneligFrank > 0;
  return `
    <div class="st-section" style="margin-top:28px">
      <div class="st-section-title">Dividend Income — FY${fy}</div>
      <div class="st-section-line"></div>
    </div>
    ${divs.length ? `
    <div class="st-list-panel" style="margin-bottom:8px">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Payment Date</th><th>Code</th><th>Name</th>
            <th class="num">Shares</th><th class="num">Per Share</th>
            <th class="num">Net Div</th><th class="num">Franking %</th>
            <th class="num">Franking Cr.</th>
            <th title="45-day holding period rule">45d</th>
            <th class="num">Gross (Assessable)</th>
          </tr></thead>
          <tbody>
            ${divs.map(d => {
              const inelig = d.eligible_45day === false;
              const frank  = inelig ? 0 : (d.franking_credit || 0);
              return `<tr${inelig ? ' style="opacity:0.6"' : ''}>
              <td class="mono">${fmtDate(d.payment_date)}</td>
              <td class="code-cell">${d.code}</td>
              <td>${d.name}</td>
              <td class="num mono">${fmtNum(d.quantity_held, 4)}</td>
              <td class="num mono">${fmtCurrency(d.amount_per_share, 4)}</td>
              <td class="num mono col-green">${fmtCurrency(d.net_amount)}</td>
              <td class="num mono">${fmtPct(d.franking_pct)}</td>
              <td class="num mono ${inelig ? 'col-red' : 'col-accent'}">${d.franking_credit ? fmtCurrency(d.franking_credit) : '—'}</td>
              <td>${_cgt45Badge(d)}</td>
              <td class="num mono">${fmtCurrency((d.net_amount||0) + frank)}</td>
            </tr>`;}).join('')}
            <tr style="font-weight:600;border-top:2px solid var(--border2)">
              <td colspan="5" style="text-align:right;color:var(--ink3);font-size:12px">Totals</td>
              <td class="num mono col-green">${fmtCurrency(totNet)}</td>
              <td></td>
              <td class="num mono col-accent">${fmtCurrency(totFrank)}${hasInelig ? ` <span style="color:var(--red);font-size:10px">(${fmtCurrency(totIneligFrank)} ineligible)</span>` : ''}</td>
              <td></td>
              <td class="num mono">${fmtCurrency(totGross)}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    ${hasInelig ? `<div style="font-size:11px;color:var(--red);padding:4px 2px">⚠ ${fmtCurrency(totIneligFrank)} in franking credits have been excluded from assessable income — 45-day holding period rule not satisfied.</div>` : ''}` : `
    <div style="padding:16px;color:var(--ink3);font-size:12px">No dividends received in FY${fy}.</div>`}`;
}

function _cgtFrankingHtml(eligibleFranking, ineligibleFranking, unknownFranking, totalDivIncome, frankRows, fy, exempt) {
  const totalFranking = eligibleFranking + ineligibleFranking + unknownFranking;
  return `
    <div class="st-section" style="margin-top:28px">
      <div class="st-section-title">Franking Credits — FY${fy}</div>
      <div class="st-section-line"></div>
    </div>
    ${totalFranking > 0 ? `
    <div class="st-kpi-strip" style="margin-bottom:16px">
      <div class="st-kpi">
        <div class="st-kpi-label">Claimable Franking Credits</div>
        <div class="st-kpi-value col-accent">${fmtCurrency(eligibleFranking)}</div>
        <div class="st-kpi-sub">${exempt ? 'small shareholder exemption' : '45-day rule satisfied'}</div>
      </div>
      ${ineligibleFranking > 0 ? `
      <div class="st-kpi">
        <div class="st-kpi-label">Ineligible Credits</div>
        <div class="st-kpi-value col-red">${fmtCurrency(ineligibleFranking)}</div>
        <div class="st-kpi-sub">45-day rule not met — cannot claim</div>
      </div>` : ''}
      ${unknownFranking > 0 ? `
      <div class="st-kpi">
        <div class="st-kpi-label">Unverified Credits</div>
        <div class="st-kpi-value col-amber">${fmtCurrency(unknownFranking)}</div>
        <div class="st-kpi-sub">add ex-dividend date to verify — excluded until then</div>
      </div>` : ''}
      <div class="st-kpi">
        <div class="st-kpi-label">Dividend Income</div>
        <div class="st-kpi-value col-green">${fmtCurrency(totalDivIncome)}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Gross Assessable</div>
        <div class="st-kpi-value col-ink">${fmtCurrency(totalDivIncome + eligibleFranking)}</div>
        <div class="st-kpi-sub">net div + claimable franking</div>
      </div>
    </div>
    <div class="st-list-panel" style="margin-bottom:8px">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Code</th><th>Name</th>
            <th class="num">Net Income</th>
            <th class="num">Franking Credit</th>
            <th class="num">Gross (assessable)</th>
          </tr></thead>
          <tbody>
            ${frankRows.map(r => `<tr>
              <td class="code-cell">${r.code}</td>
              <td>${r.name}</td>
              <td class="num mono">${fmtCurrency(r.income)}</td>
              <td class="num mono col-accent">${fmtCurrency(r.credit)}</td>
              <td class="num mono">${fmtCurrency(r.income + r.credit)}</td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>
    <div style="font-size:11px;color:var(--ink3);padding:4px 2px">
      Only claimable franking credits (45-day rule satisfied) are included in gross assessable income. Claim these as a tax offset on your return; declare gross dividend (net + claimable franking) as assessable income.
    </div>` : `
    <div style="padding:16px;color:var(--ink3);font-size:12px">
      No franked dividends received in FY${fy}.
    </div>`}`;
}

// Division 296 (SMSF accumulation, FY2027+) — figures from /api/div296 (compute_div296)
function _cgtDiv296Html(d) {
  if (!d || !d.applies) return '';
  return `
    <div class="st-section" style="margin-top:28px">
      <div class="st-section-title">Division 296 — Earnings From These Investments</div>
      <div class="st-section-line"></div>
    </div>
    <div style="font-size:11px;color:var(--amber);padding:6px 2px 10px">⚠ Division 296 applies from 1 July 2026 to members whose total super balance is over \$3 million: 15% on their share of the fund's Division 296 earnings, and a further 10% above \$10 million. The fund works out its Division 296 earnings from its taxable income and reports each in-scope member's share (usually worked out by an actuary). These are the figures from the investments recorded here: give them to your accountant or SMSF administrator.</div>
    <div class="st-kpi-strip" style="margin-bottom:16px">
      <div class="st-kpi">
        <div class="st-kpi-label">Dividend Income</div>
        <div class="st-kpi-value col-green">${fmtCurrency(d.income)}</div>
        <div class="st-kpi-sub">assessable, with franking credits</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Net Capital Gain</div>
        <div class="st-kpi-value col-ink">${fmtCurrency(d.reset ? d.capital_gain : d.net_capital_gain)}</div>
        <div class="st-kpi-sub">${d.reset ? `cost bases reset to 30 June 2026 values (fund return: ${fmtCurrency(d.net_capital_gain)})` : 'as in the fund return, after the 1/3 discount'}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Division 296 Earnings</div>
        <div class="st-kpi-value col-ink">${fmtCurrency(d.earnings)}</div>
        <div class="st-kpi-sub">from these investments</div>
      </div>
    </div>
    ${d.missing_values.length ? `<div style="font-size:11px;color:var(--amber);padding:0 2px 8px">No 30 June 2026 value entered for
      ${d.missing_values.join(', ')}: their own cost base was used. Enter the values in Settings → Division 296.</div>` : ''}
    <div style="font-size:11px;color:var(--ink3);padding:4px 2px 20px">No phasing applies to SMSFs. The ATO is drafting a ruling on the other adjustments to the fund's taxable income (contributions, expenses and so on are not recorded here).
      ${d.reset ? '' : ' If the fund has elected to reset its cost bases to 30 June 2026 values, tick it in Settings → Division 296.'}</div>`;
}
