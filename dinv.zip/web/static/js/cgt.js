// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — CGT Summary */

async function pageCgt() {
  const content = document.getElementById('module-content');

  const today = new Date();
  const currentFy = today.getMonth() >= 6 ? today.getFullYear() + 1 : today.getFullYear();

  content.innerHTML = `
    <div class="st-toolbar">
      <label style="font-size:13px;color:var(--ink2);font-weight:500">Financial Year ending 30 June</label>
      <select id="cgt-fy" style="padding:7px 12px;border:1px solid var(--border);border-radius:7px;background:var(--surface);font-size:13px;font-family:inherit;color:var(--ink);outline:none">
        ${[0,1,2,3,4].map(i => {
          const y = currentFy - i;
          return `<option value="${y}" ${i === 0 ? 'selected' : ''}>${y} (${y-1}–${y})</option>`;
        }).join('')}
      </select>
      <button class="btn btn-secondary" onclick="_cgtLoad()">Load</button>
      <div style="margin-left:auto;display:flex;gap:8px">
        <button class="btn btn-ghost" onclick="_cgtExportIncome()">Export Income CSV</button>
        <button class="btn btn-ghost" onclick="_cgtExport()">Export CGT Schedule</button>
      </div>
    </div>
    <div id="cgt-content"></div>`;

  await _cgtLoad();
}

function _cgtExport() {
  const fy = document.getElementById('cgt-fy')?.value;
  if (fy) window.location.href = `/api/export/cgt.csv?fy=${fy}`;
}

function _cgtExportIncome() {
  const fy = document.getElementById('cgt-fy')?.value;
  if (fy) window.location.href = `/api/export/income.csv?fy=${fy}`;
}

async function _cgtLoad() {
  const fy = parseInt(document.getElementById('cgt-fy').value);
  const cgtContent = document.getElementById('cgt-content');
  cgtContent.innerHTML = '<div class="st-empty"><div class="st-empty-icon">⏳</div>Loading…</div>';

  try {
    const [rows, divs, rocGains, cfData] = await Promise.all([
      apiFetch(`/api/cgt?fy=${fy}`),
      apiFetch(`/api/dividends?fy=${fy}`),
      apiFetch(`/api/roc-cgt?fy=${fy}`),
      apiFetch(`/api/cgt-carryforward?fy=${fy}`),
    ]);
    _cgtRender(rows, divs, rocGains, fy, cfData.carry_forward || 0);
  } catch (e) {
    toast(e.message, 'err');
  }
}

function _cgtRender(rows, divs, rocGains, fy, carryforward) {
  const cgtContent = document.getElementById('cgt-content');

  // Franking credit summary — split eligible vs ineligible (45-day rule)
  const totalDivIncome     = divs.reduce((s, d) => s + (d.net_amount || 0), 0);
  const eligibleFranking   = divs.reduce((s, d) => d.eligible_45day !== false ? s + (d.franking_credit || 0) : s, 0);
  const ineligibleFranking = divs.reduce((s, d) => d.eligible_45day === false ? s + (d.franking_credit || 0) : s, 0);
  const unknownFranking    = divs.reduce((s, d) => d.eligible_45day === null  ? s + (d.franking_credit || 0) : s, 0);
  const totalFranking      = eligibleFranking + ineligibleFranking + unknownFranking;
  const frankByCode        = {};
  divs.forEach(d => {
    if (!d.franking_credit) return;
    if (!frankByCode[d.code]) frankByCode[d.code] = { code: d.code, name: d.name, credit: 0, income: 0 };
    frankByCode[d.code].credit += d.franking_credit;
    frankByCode[d.code].income += d.net_amount || 0;
  });
  const frankRows = Object.values(frankByCode).sort((a,b) => b.credit - a.credit);

  if (!rows.length && !rocGains.length) {
    cgtContent.innerHTML = `<div class="st-empty" style="margin-bottom:24px">
      <div class="st-empty-icon">📋</div>
      <div class="st-empty-title">No disposals in FY${fy}</div>
      <div>Sales made between 1 July ${fy-1} and 30 June ${fy} will appear here.</div>
    </div>
    ${_cgtIncomeHtml(divs, fy)}
    ${_cgtFrankingHtml(eligibleFranking, ineligibleFranking, unknownFranking, totalDivIncome, frankRows, fy)}
    ${_cgtDiv296Html(rows, rocGains, divs, fy)}`;
    return;
  }

  const totalGain       = rows.reduce((s, r) => s + r.gain_loss, 0);
  const discountedTotal = rows.reduce((s, r) => s + (r.discounted_gain !== null ? r.discounted_gain : r.gain_loss), 0);
  const eligibleRows    = rows.filter(r => r.discount_eligible);

  // ROC-derived capital gains (cost base exceeded zero)
  const _entityType2    = _appSettings?.entity_type || 'individual';
  const _rocDiscFactor  = { individual: 0.5, smsf_accumulation: 1/3, smsf_pension: 0, company: 1 }[_entityType2] ?? 0.5;
  const rocTotalGain    = rocGains.reduce((s, r) => s + r.excess_cg, 0);
  const rocDiscounted   = rocGains.reduce((s, r) =>
    s + (r.discount_eligible ? r.excess_cg * _rocDiscFactor : r.excess_cg), 0);

  const _entityType = _appSettings?.entity_type || 'individual';
  const _discountLabel = {
    individual:        'After 50% Discount',
    smsf_accumulation: 'After 1/3 Discount',
    smsf_pension:      'Fully Exempt (Pension)',
    company:           'No Discount (Company)',
  }[_entityType] || 'After CGT Discount';

  carryforward = carryforward || 0;
  const combinedDisc   = discountedTotal + rocDiscounted;
  const netGain        = combinedDisc > 0 ? combinedDisc : 0;
  const carryUsed      = Math.min(carryforward, netGain);
  const netTaxable     = netGain - carryUsed;
  const carryRemaining = carryforward - carryUsed;

  cgtContent.innerHTML = `
    <div class="st-kpi-strip">
      <div class="st-kpi">
        <div class="st-kpi-label">Total Gross Gain/Loss</div>
        <div class="st-kpi-value ${totalGain >= 0 ? 'col-green' : 'col-red'}">${fmtCurrency(totalGain)}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">${_discountLabel}</div>
        <div class="st-kpi-value ${combinedDisc >= 0 ? 'col-green' : 'col-red'}">${fmtCurrency(combinedDisc)}</div>
        <div class="st-kpi-sub">${eligibleRows.length} parcel${eligibleRows.length !== 1 ? 's' : ''} discount-eligible${rocGains.length ? ` · incl. ${fmtCurrency(rocDiscounted)} ROC` : ''}</div>
      </div>
      ${rocTotalGain > 0 ? `
      <div class="st-kpi">
        <div class="st-kpi-label">ROC Capital Gains</div>
        <div class="st-kpi-value col-red">${fmtCurrency(rocTotalGain)}</div>
        <div class="st-kpi-sub">cost base exceeded — see ROC section</div>
      </div>` : ''}
      ${carryforward > 0 ? `
      <div class="st-kpi">
        <div class="st-kpi-label">After Carry-Forward Loss</div>
        <div class="st-kpi-value ${netTaxable > 0 ? 'col-green' : 'col-ink'}">${fmtCurrency(netTaxable)}</div>
        <div class="st-kpi-sub">${fmtCurrency(carryUsed)} applied · ${fmtCurrency(carryRemaining)} remaining</div>
      </div>` : ''}
      <div class="st-kpi">
        <div class="st-kpi-label">Disposals</div>
        <div class="st-kpi-value col-ink">${rows.length}</div>
      </div>
      ${eligibleFranking > 0 ? `
      <div class="st-kpi">
        <div class="st-kpi-label">Franking Credits (Claimable)</div>
        <div class="st-kpi-value col-accent">${fmtCurrency(eligibleFranking)}</div>
        <div class="st-kpi-sub">${ineligibleFranking > 0 ? `<span style="color:var(--red)">${fmtCurrency(ineligibleFranking)} ineligible</span>` : unknownFranking > 0 ? `<span style="color:var(--amber)">${fmtCurrency(unknownFranking)} unverified</span>` : 'income tax offset'}</div>
      </div>` : ''}
    </div>

    <div class="st-list-panel">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Sale Date</th><th>Code</th><th>Acquired</th>
            <th class="num">Qty</th><th class="num">Proceeds</th>
            <th class="num">Cost Base</th><th class="num">Gain/Loss</th>
            <th>Disc?</th><th class="num">Taxable Gain</th>
          </tr></thead>
          <tbody>
            ${rows.map(r => `<tr>
              <td class="mono">${fmtDate(r.sale_date)}</td>
              <td class="code-cell">${r.code}</td>
              <td class="mono">${fmtDate(r.acquisition_date)}</td>
              <td class="num mono">${fmtNum(r.quantity, 4)}</td>
              <td class="num mono">${fmtCurrency(r.net_proceeds)}</td>
              <td class="num mono">${fmtCurrency(r.cost_base_used)}</td>
              <td class="num"><span class="${gainClass(r.gain_loss)}">${fmtCurrency(r.gain_loss)}</span></td>
              <td>${r.discount_eligible ? '<span class="badge badge-green">Yes</span>' : '—'}</td>
              <td class="num"><span class="${gainClass(r.discounted_gain !== null ? r.discounted_gain : r.gain_loss)}">${fmtCurrency(r.discounted_gain !== null ? r.discounted_gain : r.gain_loss)}</span></td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>
    <div class="count-pill">${rows.length} disposal row${rows.length !== 1 ? 's' : ''} — FY${fy} (1 Jul ${fy-1} – 30 Jun ${fy})</div>

    ${_cgtRocHtml(rocGains, fy)}
    ${_cgtIncomeHtml(divs, fy)}
    ${_cgtFrankingHtml(eligibleFranking, ineligibleFranking, unknownFranking, totalDivIncome, frankRows, fy)}
    ${_cgtDiv296Html(rows, rocGains, divs, fy)}`;

}

function _cgtRocHtml(rocGains, fy) {
  if (!rocGains.length) return '';
  const _et       = _appSettings?.entity_type || 'individual';
  const _df       = { individual: 0.5, smsf_accumulation: 1/3, smsf_pension: 0, company: 1 }[_et] ?? 0.5;
  const totExcess = rocGains.reduce((s, r) => s + r.excess_cg, 0);
  const totDisc   = rocGains.reduce((s, r) => s + (r.discount_eligible ? r.excess_cg * _df : r.excess_cg), 0);
  return `
    <div class="st-section" style="margin-top:28px">
      <div class="st-section-title">Return of Capital — Capital Gains FY${fy}</div>
      <div class="st-section-line"></div>
    </div>
    <div style="font-size:11px;color:var(--amber);padding:6px 2px 10px">
      ⚠ The following parcels had their cost base reduced to zero by a return of capital. The excess amount is a capital gain and must be included in your tax return.
    </div>
    <div class="st-list-panel" style="margin-bottom:8px">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Action Date</th><th>Code</th><th>Acquired</th>
            <th class="num">CB Reduction</th><th class="num">Excess (Capital Gain)</th>
            <th>Disc?</th><th class="num">Taxable Gain</th>
          </tr></thead>
          <tbody>
            ${rocGains.map(r => {
              const taxable = r.discount_eligible ? r.excess_cg * _df : r.excess_cg;
              return `<tr>
              <td class="mono">${fmtDate(r.action_date)}</td>
              <td class="code-cell">${r.code}</td>
              <td class="mono">${fmtDate(r.acquisition_date)}</td>
              <td class="num mono">${fmtCurrency(r.cost_base_reduction)}</td>
              <td class="num mono col-red">${fmtCurrency(r.excess_cg)}</td>
              <td>${r.discount_eligible ? '<span class="badge badge-green">Yes</span>' : '—'}</td>
              <td class="num mono col-red">${fmtCurrency(taxable)}</td>
            </tr>`;}).join('')}
            <tr style="font-weight:600;border-top:2px solid var(--border2)">
              <td colspan="4" style="text-align:right;color:var(--ink3);font-size:12px">Totals</td>
              <td class="num mono col-red">${fmtCurrency(totExcess)}</td>
              <td></td>
              <td class="num mono col-red">${fmtCurrency(totDisc)}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>`;
}

function _cgt45Badge(d) {
  if (!d.franking_credit) return '';
  if (d.eligible_45day === true)  return '<span class="badge badge-green" title="45-day rule satisfied">✓</span>';
  if (d.eligible_45day === false) return '<span class="badge badge-red"   title="45-day rule not satisfied — credit not claimable">✗</span>';
  return '<span class="badge badge-amber" title="Add ex-dividend date to verify 45-day eligibility">?</span>';
}

function _cgtIncomeHtml(divs, fy) {
  const totNet          = divs.reduce((s, d) => s + (d.net_amount || 0), 0);
  const totEligFrank    = divs.reduce((s, d) => d.eligible_45day !== false ? s + (d.franking_credit || 0) : s, 0);
  const totIneligFrank  = divs.reduce((s, d) => d.eligible_45day === false ? s + (d.franking_credit || 0) : s, 0);
  const totFrank        = totEligFrank + totIneligFrank +
                          divs.reduce((s, d) => d.eligible_45day === null ? s + (d.franking_credit || 0) : s, 0);
  const totGross        = totNet + totEligFrank;
  const hasInelig       = totIneligFrank > 0;
  return `
    <div class="st-section" style="margin-top:28px">
      <div class="st-section-title">Dividend Income — FY${fy}</div>
      <div class="st-section-line"></div>
    </div>
    ${divs.length ? `
    <div class="st-list-panel" style="margin-bottom:8px">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Payment Date</th><th>Code</th><th>Name</th>
            <th class="num">Shares</th><th class="num">Per Share</th>
            <th class="num">Net Div</th><th class="num">Franking %</th>
            <th class="num">Franking Cr.</th>
            <th title="45-day holding period rule">45d</th>
            <th class="num">Gross (Assessable)</th>
          </tr></thead>
          <tbody>
            ${divs.map(d => {
              const inelig = d.eligible_45day === false;
              const frank  = inelig ? 0 : (d.franking_credit || 0);
              return `<tr${inelig ? ' style="opacity:0.6"' : ''}>
              <td class="mono">${fmtDate(d.payment_date)}</td>
              <td class="code-cell">${d.code}</td>
              <td>${d.name}</td>
              <td class="num mono">${fmtNum(d.quantity_held, 4)}</td>
              <td class="num mono">${fmtCurrency(d.amount_per_share, 4)}</td>
              <td class="num mono col-green">${fmtCurrency(d.net_amount)}</td>
              <td class="num mono">${d.franking_pct ? d.franking_pct + '%' : '—'}</td>
              <td class="num mono ${inelig ? 'col-red' : 'col-accent'}">${d.franking_credit ? fmtCurrency(d.franking_credit) : '—'}</td>
              <td>${_cgt45Badge(d)}</td>
              <td class="num mono">${fmtCurrency((d.net_amount||0) + frank)}</td>
            </tr>`;}).join('')}
            <tr style="font-weight:600;border-top:2px solid var(--border2)">
              <td colspan="5" style="text-align:right;color:var(--ink3);font-size:12px">Totals</td>
              <td class="num mono col-green">${fmtCurrency(totNet)}</td>
              <td></td>
              <td class="num mono col-accent">${fmtCurrency(totFrank)}${hasInelig ? ` <span style="color:var(--red);font-size:10px">(${fmtCurrency(totIneligFrank)} ineligible)</span>` : ''}</td>
              <td></td>
              <td class="num mono">${fmtCurrency(totGross)}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    ${hasInelig ? `<div style="font-size:11px;color:var(--red);padding:4px 2px">⚠ ${fmtCurrency(totIneligFrank)} in franking credits have been excluded from assessable income — 45-day holding period rule not satisfied.</div>` : ''}` : `
    <div style="padding:16px;color:var(--ink3);font-size:12px">No dividends received in FY${fy}.</div>`}`;
}

function _cgtFrankingHtml(eligibleFranking, ineligibleFranking, unknownFranking, totalDivIncome, frankRows, fy) {
  const totalFranking = eligibleFranking + ineligibleFranking + unknownFranking;
  return `
    <div class="st-section" style="margin-top:28px">
      <div class="st-section-title">Franking Credits — FY${fy}</div>
      <div class="st-section-line"></div>
    </div>
    ${totalFranking > 0 ? `
    <div class="st-kpi-strip" style="margin-bottom:16px">
      <div class="st-kpi">
        <div class="st-kpi-label">Claimable Franking Credits</div>
        <div class="st-kpi-value col-accent">${fmtCurrency(eligibleFranking)}</div>
        <div class="st-kpi-sub">45-day rule satisfied</div>
      </div>
      ${ineligibleFranking > 0 ? `
      <div class="st-kpi">
        <div class="st-kpi-label">Ineligible Credits</div>
        <div class="st-kpi-value col-red">${fmtCurrency(ineligibleFranking)}</div>
        <div class="st-kpi-sub">45-day rule not met — cannot claim</div>
      </div>` : ''}
      ${unknownFranking > 0 ? `
      <div class="st-kpi">
        <div class="st-kpi-label">Unverified Credits</div>
        <div class="st-kpi-value col-amber">${fmtCurrency(unknownFranking)}</div>
        <div class="st-kpi-sub">add ex-dividend date to verify</div>
      </div>` : ''}
      <div class="st-kpi">
        <div class="st-kpi-label">Dividend Income</div>
        <div class="st-kpi-value col-green">${fmtCurrency(totalDivIncome)}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Gross Assessable</div>
        <div class="st-kpi-value col-ink">${fmtCurrency(totalDivIncome + eligibleFranking)}</div>
        <div class="st-kpi-sub">net div + claimable franking</div>
      </div>
    </div>
    <div class="st-list-panel" style="margin-bottom:8px">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Code</th><th>Name</th>
            <th class="num">Net Income</th>
            <th class="num">Franking Credit</th>
            <th class="num">Gross (assessable)</th>
          </tr></thead>
          <tbody>
            ${frankRows.map(r => `<tr>
              <td class="code-cell">${r.code}</td>
              <td>${r.name}</td>
              <td class="num mono">${fmtCurrency(r.income)}</td>
              <td class="num mono col-accent">${fmtCurrency(r.credit)}</td>
              <td class="num mono">${fmtCurrency(r.income + r.credit)}</td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>
    <div style="font-size:11px;color:var(--ink3);padding:4px 2px">
      Only claimable franking credits (45-day rule satisfied) are included in gross assessable income. Claim these as a tax offset on your return; declare gross dividend (net + claimable franking) as assessable income.
    </div>` : `
    <div style="padding:16px;color:var(--ink3);font-size:12px">
      No franked dividends received in FY${fy}.
    </div>`}`;
}

function _cgtDiv296Html(rows, rocGains, divs, fy) {
  const entityType = _appSettings?.entity_type || 'individual';
  if (entityType !== 'smsf_accumulation') return '';
  if (fy < 2027) return '';

  const inclusionPct    = fy === 2027 ? 20 : fy === 2028 ? 40 : fy === 2029 ? 60 : 80;
  const inclusionFactor = inclusionPct / 100;

  const totalDividends = divs.reduce((s, d) => s + (d.net_amount || 0), 0);
  const grossGains     = rows.reduce((s, r) => r.gain_loss > 0 ? s + r.gain_loss : s, 0);
  const grossLosses    = rows.reduce((s, r) => r.gain_loss < 0 ? s + Math.abs(r.gain_loss) : s, 0);
  const rocGross       = rocGains.reduce((s, r) => s + r.excess_cg, 0);
  const netCGGross     = grossGains - grossLosses + rocGross;
  const div296CG       = Math.max(0, netCGGross) * inclusionFactor;
  const div296Earnings = totalDividends + div296CG;

  return `
    <div class="st-section" style="margin-top:28px">
      <div class="st-section-title">Division 296 — Additional Super Tax</div>
      <div class="st-section-line"></div>
    </div>
    <div style="font-size:11px;color:var(--amber);padding:6px 2px 10px">
      ⚠ Division 296 applies from 1 July 2026 to SMSF members with Total Superannuation Balance (TSB) over $3M.
      An additional 15% tax applies to earnings attributable to TSB between $3M–$10M; 25% for TSB over $10M.
      The ATO assesses actual liability — provide these figures to your accountant or SMSF administrator.
    </div>
    <div class="st-kpi-strip" style="margin-bottom:16px">
      <div class="st-kpi">
        <div class="st-kpi-label">Dividend Income</div>
        <div class="st-kpi-value col-green">${fmtCurrency(totalDividends)}</div>
        <div class="st-kpi-sub">included at 100%</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Net Realised Gains</div>
        <div class="st-kpi-value ${netCGGross > 0 ? 'col-green' : 'col-ink3'}">${fmtCurrency(Math.max(0, netCGGross))}</div>
        <div class="st-kpi-sub">gross gains minus losses</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">CG Inclusion Rate FY${fy}</div>
        <div class="st-kpi-value col-ink">${inclusionPct}%</div>
        <div class="st-kpi-sub">phased — reaches 80% from FY2030</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Capital Gains (Div 296)</div>
        <div class="st-kpi-value">${fmtCurrency(div296CG)}</div>
        <div class="st-kpi-sub">net gains × ${inclusionPct}%</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Total Div 296 Earnings</div>
        <div class="st-kpi-value col-ink">${fmtCurrency(div296Earnings)}</div>
        <div class="st-kpi-sub">dividends + adjusted CG</div>
      </div>
    </div>
    <div style="font-size:11px;color:var(--ink3);padding:4px 2px 20px">
      Capital gains inclusion rates (transitional): 20% FY2027 · 40% FY2028 · 60% FY2029 · 80% FY2030+.
      Actual liability requires your Total Superannuation Balance across all funds — assessed by the ATO.
    </div>`;
}
