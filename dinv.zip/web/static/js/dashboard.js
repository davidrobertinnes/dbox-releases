// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Securities — Dashboard */

async function pageDashboard() {
  const content = document.getElementById('module-content');

  try {
    const [holdings, dividends, sales, prices, perf, parcels, watchlist, checks, fyCgt, fyInc] = await Promise.all([
      apiFetch('/api/holdings'),
      apiFetch('/api/dividends'),
      apiFetch('/api/sales'),
      apiFetch('/api/prices'),
      apiFetch('/api/performance'),
      apiFetch('/api/parcels'),
      apiFetch('/api/watchlist'),
      apiFetch('/api/data-checks'),
      apiFetch('/api/cgt-fy-summary').catch(() => null),
      apiFetch('/api/income-fy-summary').catch(() => null),
    ]);

    // Financial year bounds for "this FY" income
    const today = new Date();
    const fyStart = today.getMonth() >= 6
      ? `${today.getFullYear()}-07-01`
      : `${today.getFullYear() - 1}-07-01`;

    const totalCost  = holdings.reduce((s, h) => s + (h.total_cost_base || 0), 0);
    const incomeAllTime = dividends.reduce((s, d) => s + (d.net_amount || 0), 0);
    const incomeFy   = dividends
      .filter(d => d.payment_date >= fyStart)
      .reduce((s, d) => s + (d.net_amount || 0), 0);

    let totalMktVal = 0, pricedCount = 0;
    holdings.forEach(h => {
      const p = prices[h.security_id];
      if (p) { totalMktVal += p.price * h.total_quantity; pricedCount++; }
    });
    const totalPnl    = pricedCount > 0 ? totalMktVal - totalCost : null;
    const totalPnlPct = totalPnl !== null && totalCost > 0 ? totalPnl / totalCost * 100 : null;

    // Recent activity — merge buys, sells, divs; take last 8. As on Transactions: only shares
    // paid for (or inherited) are listed as acquisitions — demerged, bonus and takeover shares
    // come from a corporate action — in the units and price as traded, at what was paid.
    const bought = { purchase: 'Buy', drp: 'DRP', rights: 'Rights', inherited: 'Inherited' };
    const recent = [
      ...parcels
        .filter(p => bought[p.source])
        .map(p => {
          const qty = p.entered_quantity ?? p.quantity, price = p.entered_price ?? p.price_per_unit;
          const paid = p.quantity * p.price_per_unit + (p.brokerage || 0) + (p.other_costs || 0);   // as paid, before later adjustments
          const verb = p.source === 'inherited' ? 'Inherited' : p.source === 'drp' ? 'Reinvested' : 'Bought';
          return { date: p.acquisition_date, type: bought[p.source], code: codeThen(p) || p.code,
                   desc: `${verb} ${fmtNum(qty, 0)} @ ${fmtCurrency(price)}`, amount: paid };
        }),
      ...sales.filter(s => s.kind !== 'transfer').map(s => ({ date: s.sale_date,
        type: s.kind === 'takeover' ? 'Takeover' : s.kind === 'cancellation' ? 'Cancelled' : 'Sell',
        code: codeThen(s) || s.code, desc: `Sold ${fmtNum(s.quantity, 0)} @ ${fmtCurrency(s.price_per_unit)}`, amount: s.net_proceeds })),
      ...dividends.map(d => ({ date: d.payment_date, type: 'Dividend', code: d.code, desc: `${fmtNum(d.quantity_held, 0)} shares @ ${fmtCurrency(d.amount_per_share, 4)}/sh`, amount: d.net_amount })),
    ].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 8);

    const typeColor = { Buy: 'var(--accent)', DRP: 'var(--accent)', Rights: 'var(--accent)', Inherited: 'var(--accent)',
                        Sell: 'var(--amber)', Takeover: 'var(--amber)', Cancelled: 'var(--amber)', Dividend: 'var(--green)' };
    const typeBadge = { Buy: 'badge-accent', DRP: 'badge-accent', Rights: 'badge-accent', Inherited: 'badge-accent',
                        Sell: 'badge-amber', Takeover: 'badge-amber', Cancelled: 'badge-amber', Dividend: 'badge-green' };

    // This financial year, for decisions before 30 June: capital gains so far (as on the Tax
    // Summary, after losses and the discount), dividends with franking credits, and holdings
    // now at a loss that could be sold against the gains.
    const fyEnd = today.getMonth() >= 6 ? today.getFullYear() + 1 : today.getFullYear();
    const lossHoldings = holdings.map(h => {
      const p = prices[h.security_id];
      return p ? p.price * h.total_quantity - (h.total_cost_base || 0) : 0;
    }).filter(x => x < 0);
    const unrealisedLoss = lossHoldings.reduce((s, x) => s + x, 0);
    const fyLabel = (t) => `<div style="font-size:11px;color:var(--ink3);font-weight:500;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">${t}</div>`;
    const fyValue = (v, cls) => `<div style="font-family:'DM Mono',monospace;font-size:16px;font-weight:600" class="${cls}">${fmtCurrency(v)}</div>`;
    const fySub = (t) => `<div style="font-size:11px;color:var(--ink3);margin-top:2px">${t}</div>`;
    const fyHtml = (fyCgt || fyInc) ? `
      <div class="st-section" style="margin-top:4px"><div class="st-section-title">This Financial Year — FY${fyEnd}</div><div class="st-section-line"></div></div>
      <div class="st-list-panel" style="margin-bottom:20px;padding:14px 18px">
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px">
          ${fyCgt ? `<div title="Item 18A so far: gains less capital losses (this year's and carried forward), then the CGT discount — as on the Tax Summary">
            ${fyLabel(fyCgt.net_capital_loss > 0 ? 'Net capital loss' : 'Net capital gain')}
            ${fyCgt.net_capital_loss > 0 ? fyValue(-fyCgt.net_capital_loss, 'col-red') : fyValue(fyCgt.net_capital_gain, gainClass(fyCgt.net_capital_gain))}
            ${fySub(`gains ${fmtCurrency(fyCgt.total_gains)} · losses ${fmtCurrency(fyCgt.total_losses)}${fyCgt.carry_forward > 0 ? ` · ${fmtCurrency(fyCgt.carry_forward)} carried in` : ''}`)}
          </div>` : ''}
          ${fyInc ? `<div>
            ${fyLabel('Dividends')}
            ${fyValue(fyInc.net_dividends, 'col-green')}
            ${fySub(`plus ${fmtCurrency(fyInc.credits_claimable)} franking credits`)}
          </div>` : ''}
          ${pricedCount > 0 ? `<div title="Priced holdings now worth less than their cost base. Selling makes a capital loss that can be set against this year's gains — check the 45-day rule and wash sale rules first">
            ${fyLabel('Holdings at a loss')}
            ${fyValue(unrealisedLoss, unrealisedLoss < 0 ? 'col-red' : 'col-ink')}
            ${fySub(`${lossHoldings.length} holding${lossHoldings.length !== 1 ? 's' : ''}, unrealised`)}
          </div>` : ''}
        </div>
      </div>` : '';

    // Watch list signals
    const buySignals      = watchlist.filter(w => { const p = prices[w.security_id]; return p && w.target_buy  !== null && p.price <= w.target_buy; });
    const sellSignals     = watchlist.filter(w => { const p = prices[w.security_id]; return p && w.target_sell !== null && p.price >= w.target_sell; });
    const frankingSignals = watchlist.filter(w => w.franking_alert);
    const watchAlertHtml = (buySignals.length || sellSignals.length || frankingSignals.length) ? `
    <div style="margin-bottom:16px;padding:14px 18px;background:var(--surface2);border:1px solid var(--border);border-radius:10px">
      <div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;color:var(--ink3);margin-bottom:10px">Watch List Alerts</div>
      <div style="display:flex;flex-wrap:wrap;gap:8px">
        ${buySignals.map(w => `
        <div style="display:flex;align-items:center;gap:8px;padding:7px 12px;background:var(--green-dim);border-radius:8px;cursor:pointer" onclick="navigate('watchlist')">
          <span style="font-weight:700;color:var(--accent);font-size:13px">${w.code}</span>
          <span class="badge badge-green" style="font-size:10px">Buy zone</span>
          <span style="font-family:'DM Mono',monospace;font-size:12px;color:var(--green)">${fmtCurrency(prices[w.security_id].price)}</span>
          <span style="font-size:11px;color:var(--ink3)">≤ ${fmtCurrency(w.target_buy)}</span>
        </div>`).join('')}
        ${sellSignals.map(w => `
        <div style="display:flex;align-items:center;gap:8px;padding:7px 12px;background:var(--red-dim);border-radius:8px;cursor:pointer" onclick="navigate('watchlist')">
          <span style="font-weight:700;color:var(--accent);font-size:13px">${w.code}</span>
          <span class="badge badge-red" style="font-size:10px">Sell zone</span>
          <span style="font-family:'DM Mono',monospace;font-size:12px;color:var(--red)">${fmtCurrency(prices[w.security_id].price)}</span>
          <span style="font-size:11px;color:var(--ink3)">≥ ${fmtCurrency(w.target_sell)}</span>
        </div>`).join('')}
        ${frankingSignals.map(w => `
        <div style="display:flex;align-items:center;gap:8px;padding:7px 12px;background:var(--amber-dim);border-radius:8px;cursor:pointer" onclick="navigate('watchlist')">
          <span style="font-weight:700;color:var(--accent);font-size:13px">${w.code}</span>
          <span class="badge badge-amber" style="font-size:10px">Franking</span>
          <span style="font-size:11px;color:var(--amber)">Hold until ${fmtDate(w.must_hold_until)}</span>
          <span style="font-size:11px;color:var(--ink3)">ex-div ${fmtDate(w.latest_ex_date)}</span>
        </div>`).join('')}
      </div>
    </div>` : '';

    // Parcels entered after a split dated on/after their purchase (found by the data repair):
    // the quantity may be in pre-split units — ask the user to check.
    const splitReview = checks.split_review || [];
    const checksHtml = splitReview.length ? `
    <div class="ts-alert ts-alert-amber" style="margin-bottom:16px">
      <strong>Please check ${splitReview.length} purchase${splitReview.length !== 1 ? 's' : ''} recorded before a share split.</strong>
      These were entered after the split, so the quantity may be in pre-split units. Holdings are stored in
      post-split units — if a quantity below is the contract-note (pre-split) figure, edit the purchase and
      convert it (quantity × split ratio, price ÷ split ratio).
      <ul style="margin:8px 0 8px 18px">
        ${splitReview.map(r => `<li><strong>${r.code}</strong> bought ${fmtDate(r.acquisition_date)} — ${fmtNum(r.quantity, 4)} shares;
          ${r.ratio} split on ${fmtDate(r.action_date)}</li>`).join('')}
      </ul>
      <button class="btn btn-secondary btn-sm" onclick="_dashDismissChecks()">I've checked these</button>
    </div>` : '';

    // Demerged parcels the 1.1.0 same-day repair couldn't correct because some were sold
    const sameDayReview = checks.same_day_review || [];
    const sameDayHtml = sameDayReview.length ? `
    <div class="ts-alert ts-alert-amber" style="margin-bottom:16px">
      <strong>Please check ${sameDayReview.length} demerged parcel${sameDayReview.length !== 1 ? 's' : ''}.</strong>
      A sale or bonus issue on the day of a demerger now counts in a different order, which changes how many
      demerged shares were received. Some of these shares have been sold, so they weren't changed automatically.
      <ul style="margin:8px 0 8px 18px">
        ${sameDayReview.map(r => `<li><strong>${r.code}</strong> parcel from ${fmtDate(r.acquisition_date)} — ${r.issue}</li>`).join('')}
      </ul>
      <button class="btn btn-secondary btn-sm" onclick="_dashDismissChecks()">I've checked these</button>
    </div>` : '';

    // Bonus issues from earlier versions that 1.1.0 couldn't convert because the shares were sold
    const bonusReview = checks.bonus_review || [];
    const bonusHtml = bonusReview.length ? `
    <div class="ts-alert ts-alert-amber" style="margin-bottom:16px">
      <strong>Please check ${bonusReview.length} bonus issue${bonusReview.length !== 1 ? 's' : ''}.</strong>
      Bonus shares are now recorded by spreading the cost base over the original and bonus shares, which keep
      the original purchase dates (ATO). These were recorded the old way and have been sold, so they weren't
      changed automatically: delete the sale and the bonus issue, re-enter the bonus issue as a ratio, then
      re-enter the sale.
      <ul style="margin:8px 0 8px 18px">
        ${bonusReview.map(r => `<li><strong>${r.code}</strong> bonus shares from ${fmtDate(r.acquisition_date)} — ${r.issue}</li>`).join('')}
      </ul>
      <button class="btn btn-secondary btn-sm" onclick="_dashDismissChecks()">I've checked these</button>
    </div>` : '';

    // Returns of capital whose same-day DRP shares no longer receive them (1.10.1 repair)
    const drpRocReview = checks.drp_roc_review || [];
    const drpRocHtml = drpRocReview.length ? `
    <div class="ts-alert ts-alert-amber" style="margin-bottom:16px">
      <strong>Please check ${drpRocReview.length} return${drpRocReview.length !== 1 ? 's' : ''} of capital.</strong>
      DRP shares issued on the same day as a return of capital weren't held at its record date, so they no longer
      receive it. If you entered the return of capital as a total, its amount per share was worked out over those
      DRP shares too, so it's a little low. Compare it with the company's notice; if it's wrong, delete it on the
      Corporate Actions page and add it again with the right amount per share.
      <ul style="margin:8px 0 8px 18px">
        ${drpRocReview.map(r => `<li><strong>${r.code}</strong> on ${fmtDate(r.action_date)}: now
          ${fmtCurrency(r.per_unit, 4)} per share. Entered as a total, it would be ${fmtCurrency(r.if_total_per_unit, 4)}.</li>`).join('')}
      </ul>
      <button class="btn btn-secondary btn-sm" onclick="_dashDismissChecks()">I've checked these</button>
    </div>` : '';

    // Shares sold between a demerger's ex-date and the demerger (worked out each time)
    const demSales = checks.demerger_sales || [];
    const demSalesHtml = demSales.length ? `
    <div class="ts-alert ts-alert-amber" style="margin-bottom:16px">
      <strong>Please check ${demSales.length} demerger${demSales.length !== 1 ? 's' : ''}: shares sold before ${demSales.length !== 1 ? 'them' : 'it'}.</strong>
      These shares were sold on or after the ex-date, so you were still on the register at the record date and the
      new shares for them are yours. Dogbox Investments gives new shares only for shares held on the demerger date.
      How to treat these depends on the demerger: check the scheme booklet or the ATO's guidance for it, and record
      any new shares you received as a purchase if you need to.
      <ul style="margin:8px 0 8px 18px">
        ${demSales.map(r => `<li><strong>${r.code}</strong> demerger of ${r.new_code || '?'} on ${fmtDate(r.action_date)}:
          ${fmtNum(r.units, 4)} shares sold from ${fmtDate(r.cutoff)}</li>`).join('')}
      </ul>
      <button class="btn btn-secondary btn-sm" onclick="_dashDismissChecks()">I've checked these</button>
    </div>` : '';

    // 2027 CGT rules: values needed for shares held at 30 June 2027 (from 1 July 2027)
    const missing2027 = checks.values_2027_missing || [];
    const values2027Html = missing2027.length ? `
    <div class="ts-alert ts-alert-amber" style="margin-bottom:16px">
      <strong>Record your 30 June 2027 values.</strong>
      From 1 July 2027 shares held at the end of 30 June 2027 are treated as sold and bought back at their value
      then — it splits each later sale's gain between the old rules and the new. Still needed for
      ${missing2027.slice(0, 8).join(', ')}${missing2027.length > 8 ? ` and ${missing2027.length - 8} more` : ''}.
      <a href="#" onclick="navigate('settings');return false">Enter them in Settings</a>.
    </div>` : '';

    content.innerHTML = `
      ${values2027Html}
      ${demSalesHtml}
      ${checksHtml}
      ${sameDayHtml}
      ${bonusHtml}
      ${drpRocHtml}
      <div style="display:flex;justify-content:flex-end;margin-bottom:8px">
        <button class="btn btn-secondary btn-sm" id="dash-refresh-btn" onclick="_dashRefreshPrices()">Refresh Prices</button>
      </div>
      ${watchAlertHtml}
      <div class="st-kpi-strip">
        <div class="st-kpi">
          <div class="st-kpi-label">Open Positions</div>
          <div class="st-kpi-value col-accent">${holdings.length}</div>
          <div class="st-kpi-sub">${holdings.length !== 1 ? 'securities' : 'security'} held</div>
        </div>
        <div class="st-kpi">
          <div class="st-kpi-label">Cost Base</div>
          <div class="st-kpi-value col-ink">${fmtCurrency(totalCost)}</div>
          <div class="st-kpi-sub">total invested</div>
        </div>
        ${pricedCount > 0 ? `
        <div class="st-kpi">
          <div class="st-kpi-label">Market Value</div>
          <div class="st-kpi-value col-ink">${fmtCurrency(totalMktVal)}</div>
          <div class="st-kpi-sub">${pricedCount} of ${holdings.length} priced</div>
        </div>
        <div class="st-kpi">
          <div class="st-kpi-label">Unrealised P&amp;L</div>
          <div class="st-kpi-value ${gainClass(totalPnl)}">${fmtCurrency(totalPnl)}</div>
          <div class="st-kpi-sub">${totalPnlPct !== null ? (totalPnlPct >= 0 ? '+' : '') + totalPnlPct.toFixed(2) + '%' : ''}</div>
        </div>` : ''}
        <div class="st-kpi">
          <div class="st-kpi-label">Dividend Income</div>
          <div class="st-kpi-value col-green">${fmtCurrency(incomeFy)}</div>
          <div class="st-kpi-sub">this financial year</div>
        </div>
        ${perf && perf.disposals ? `
        <div class="st-kpi">
          <div class="st-kpi-label">Disposals</div>
          <div class="st-kpi-value col-ink">${perf.disposals}</div>
          <div class="st-kpi-sub" title="Cash received. A takeover's new shares aren't counted">${fmtCurrency(perf.disposal_cash)} cash received</div>
        </div>` : ''}
      </div>

      ${perf && perf.total_invested > 0 ? `
      <div class="st-section" style="margin-top:4px"><div class="st-section-title">Total Return</div><div class="st-section-line"></div></div>
      <div class="st-list-panel" style="margin-bottom:20px;padding:14px 18px">
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px">
          <div>
            <div style="font-size:11px;color:var(--ink3);font-weight:500;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Total Invested</div>
            <div style="font-family:'DM Mono',monospace;font-size:16px;font-weight:600;color:var(--ink)">${fmtCurrency(perf.total_invested)}</div>
          </div>
          ${perf.unrealized !== null ? `<div>
            <div style="font-size:11px;color:var(--ink3);font-weight:500;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Unrealised P&amp;L</div>
            <div style="font-family:'DM Mono',monospace;font-size:16px;font-weight:600" class="${gainClass(perf.unrealized)}">${fmtCurrency(perf.unrealized)}</div>
          </div>` : ''}
          <div>
            <div style="font-size:11px;color:var(--ink3);font-weight:500;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Realised Gains</div>
            <div style="font-family:'DM Mono',monospace;font-size:16px;font-weight:600" class="${gainClass(perf.realized)}">${fmtCurrency(perf.realized)}</div>
          </div>
          <div>
            <div style="font-size:11px;color:var(--ink3);font-weight:500;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Dividends</div>
            <div style="font-family:'DM Mono',monospace;font-size:16px;font-weight:600;color:var(--green)">${fmtCurrency(perf.dividends)}</div>
          </div>
          <div style="border-left:2px solid var(--border);padding-left:14px">
            <div style="font-size:11px;color:var(--ink3);font-weight:500;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">Total Return</div>
            <div style="font-family:'DM Mono',monospace;font-size:20px;font-weight:700" class="${gainClass(perf.total_return)}">${fmtCurrency(perf.total_return)}</div>
            ${perf.return_pct !== null ? `<div style="font-size:12px" class="${gainClass(perf.return_pct)}">${perf.return_pct >= 0 ? '+' : ''}${perf.return_pct.toFixed(2)}%</div>` : ''}
          </div>
        </div>
      </div>` : ''}

      ${fyHtml}

      ${holdings.length ? `
      <div style="display:grid;grid-template-columns:1fr 320px;gap:20px;align-items:start">

        <div>
          <div class="st-section"><div class="st-section-title">Holdings</div><div class="st-section-line"></div></div>
          <div class="st-list-panel">
            <div class="tbl-overflow">
              <table class="st-table">
                <thead><tr>
                  <th>Code</th><th>Name</th>
                  <th class="num">Qty</th>
                  <th class="num">Cost Base</th>
                  <th class="num">Mkt Value</th>
                  <th class="num">P&amp;L</th>
                </tr></thead>
                <tbody>
                  ${holdings.map(h => {
                    const p = prices[h.security_id];
                    const mv   = p ? fmtCurrency(p.price * h.total_quantity) : '<span style="color:var(--ink3)">—</span>';
                    const pnl  = p ? h.total_quantity * p.price - h.total_cost_base : null;
                    const pnlHtml = pnl !== null
                      ? `<span class="${gainClass(pnl)}">${fmtCurrency(pnl)}</span>`
                      : '<span style="color:var(--ink3)">—</span>';
                    return `<tr style="cursor:pointer" onclick="navigate('portfolio')">
                      <td class="code-cell">${h.code}</td>
                      <td>${h.name}</td>
                      <td class="num mono">${fmtNum(h.total_quantity, 4)}</td>
                      <td class="num mono">${fmtCurrency(h.total_cost_base)}</td>
                      <td class="num mono">${mv}</td>
                      <td class="num mono">${pnlHtml}</td>
                    </tr>`;
                  }).join('')}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div>
          <div class="st-section"><div class="st-section-title">Recent Activity</div><div class="st-section-line"></div></div>
          ${recent.length ? `
          <div class="st-list-panel">
            ${recent.map(a => `
            <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--border)">
              <span class="badge ${typeBadge[a.type]}" style="flex-shrink:0">${a.type}</span>
              <div style="flex:1;min-width:0">
                <div style="font-weight:600;font-size:13px">${a.code}</div>
                <div style="font-size:11px;color:var(--ink3)">${a.desc}</div>
              </div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-family:'DM Mono',monospace;font-size:12px;font-weight:500;color:${typeColor[a.type]}">${fmtCurrency(a.amount)}</div>
                <div style="font-size:10px;color:var(--ink3)">${fmtDate(a.date)}</div>
              </div>
            </div>`).join('')}
          </div>` : `<div style="padding:20px 14px;color:var(--ink3);font-size:12px">No recent activity</div>`}

          ${pricedCount === 0 && holdings.length > 0 ? `
          <div style="margin-top:16px">
            <div class="st-section"><div class="st-section-title">Prices</div><div class="st-section-line"></div></div>
            <div style="padding:14px;background:var(--accent-dim);border-radius:8px;font-size:12px;color:var(--ink2)">
              No prices loaded. Click <strong>Refresh Prices</strong> above to fetch current prices.
            </div>
          </div>` : ''}
        </div>

      </div>` : `
      <div class="st-empty" style="margin-top:40px">
        <div class="st-empty-icon">📈</div>
        <div class="st-empty-title">Welcome to Dogbox Investments</div>
        <div>Add securities and record your first purchase to get started.</div>
      </div>`}`;

  } catch (e) {
    content.innerHTML = `<div class="st-empty"><div class="st-empty-title">Error</div><div>${e.message}</div></div>`;
  }
}

async function _dashRefreshPrices() {
  const btn = document.getElementById('dash-refresh-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Refreshing…'; }
  try {
    await fetch('/api/prices/refresh', { method: 'POST' }).then(r => r.json());
    toast('Prices updated');
    await pageDashboard();
  } catch (e) {
    toast('Price refresh failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Refresh Prices'; }
  }
}


async function _dashDismissChecks() {
  try {
    const r = await fetch('/api/data-checks/dismiss', { method: 'POST' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Request failed');
    pageDashboard();
  } catch (e) {
    toast(e.message, 'err');
  }
}
