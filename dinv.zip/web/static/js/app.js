// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — core utilities and navigation */

// ── API fetch ─────────────────────────────────────────────────────────────────
async function apiFetch(url, opts = {}) {
  const r = await fetch(url, opts);
  const j = await r.json();
  if (!j.ok) throw new Error(j.error || 'Request failed');
  return j.data;
}

// ── Toast ─────────────────────────────────────────────────────────────────────
function toast(msg, type = 'ok') {
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.textContent = msg;
  document.body.appendChild(t);
  requestAnimationFrame(() => t.classList.add('show'));
  setTimeout(() => {
    t.classList.remove('show');
    setTimeout(() => t.remove(), 300);
  }, 3200);
}

// ── Date / number formatting ──────────────────────────────────────────────────
function fmtDate(iso) {
  if (!iso) return '—';
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
}

function fmtCurrency(n, decimals = 2) {
  if (n == null) return '—';
  const v = parseFloat(n);
  if (isNaN(v)) return '—';
  const abs = Math.abs(v).toLocaleString('en-AU', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
  return (v < 0 ? '-' : '') + '$' + abs;
}

// <option>s for financial years ending 30 June: this year back to the portfolio's first
// (at least `minYears` years). selected: the FY to select (default this year).
function fyOptions(selected, minYears = 5) {
  const today = new Date();
  const currentFy = today.getMonth() >= 6 ? today.getFullYear() + 1 : today.getFullYear();
  const first = Math.min((_appSettings && _appSettings._first_fy) || currentFy, currentFy - minYears + 1);
  const sel = selected || currentFy;
  let out = '';
  for (let y = currentFy; y >= first; y--) {
    out += `<option value="${y}" ${y === sel ? 'selected' : ''}>${y} (${y - 1}–${y})</option>`;
  }
  return out;
}

// How a disposal is taxed (sale_parcels.cgt_basis, worked out in core/portfolio.py)
function cgtBasisBadge(basis) {
  return {
    discount:   '<span class="badge badge-green" title="Held more than 12 months — CGT discount">Discount</span>',
    indexation: '<span class="badge badge-accent" title="Cost base indexed to September 1999 — no discount">Indexed</span>',
    pre_cgt:    '<span class="badge badge-ink" title="Acquired before 20 September 1985 — exempt from CGT">Pre-CGT</span>',
    not_cgt:    '<span class="badge badge-ink" title="Before CGT began on 20 September 1985">No CGT</span>',
    rollover:   '<span class="badge badge-ink" title="Takeover with scrip-for-scrip roll-over and no cash — nothing taxed now">Roll-over</span>',
  }[basis] || '—';
}

// Jointly held portfolio: tax figures are the owner's share (Settings → Your Share)
function ownershipNote() {
  const pct = _appSettings && _appSettings.ownership_pct;
  const joint = _appSettings && _appSettings._joint_holdings;
  return pct ? `<div style="font-size:12px;color:var(--ink2);padding:8px 2px 12px">
    Figures are your <strong>${pct}%</strong> share of jointly held shares (Settings).</div>`
    : joint ? `<div style="font-size:12px;color:var(--ink2);padding:8px 2px 12px">
    Figures for jointly held holdings are your share (Settings → Holdings).</div>` : '';
}

function fmtNum(n, decimals = 4) {
  if (n == null) return '—';
  const v = parseFloat(n);
  if (isNaN(v)) return '—';
  return v.toLocaleString('en-AU', {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals,
  });
}

function gainClass(n) {
  const v = parseFloat(n);
  if (v > 0) return 'gain';
  if (v < 0) return 'loss';
  return 'flat';
}

function _isLocked(dateStr) {
  if (!dateStr || !_appSettings?.locked_fy) return false;
  const lockedFy = parseInt(_appSettings.locked_fy);
  if (!lockedFy) return false;
  const d = new Date(dateStr + 'T00:00:00');
  const fy = (d.getMonth() + 1) >= 7 ? d.getFullYear() + 1 : d.getFullYear();
  return fy <= lockedFy;
}

// ── Module loader ─────────────────────────────────────────────────────────────
const _loadedModules = new Set();

async function loadModule(name) {
  if (_loadedModules.has(name)) return;
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = `/static/js/${name}.js`;
    s.onload = () => { _loadedModules.add(name); resolve(); };
    s.onerror = reject;
    document.head.appendChild(s);
  });
}

// ── Navigation ────────────────────────────────────────────────────────────────
const _moduleMap = {
  dashboard:       { js: 'dashboard',       fn: 'pageDashboard' },
  portfolio:       { js: 'portfolio',       fn: 'pagePortfolio' },
  transactions:    { js: 'transactions',    fn: 'pageTransactions' },
  dividends:       { js: 'dividends',       fn: 'pageDividends' },
  cgt:             { js: 'cgt',             fn: 'pageCgt' },
  tax_summary:     { js: 'tax_summary',     fn: 'pageTaxSummary' },
  actions:         { js: 'actions',         fn: 'pageActions' },
  securities:      { js: 'securities',      fn: 'pageSecurities' },
  import_data:     { js: 'import_data',     fn: 'pageImportData' },
  settings:        { js: 'settings_mod',    fn: 'pageSettings' },
  security_detail:  { js: 'security_detail',   fn: null },
  cost_base_recon:  { js: 'cost_base_recon',   fn: 'pageCostBaseRecon' },
  watchlist:        { js: 'watchlist',          fn: 'pageWatchlist' },
};

let _currentModule = null;

async function navigate(module) {
  if (module === _currentModule) return;
  _currentModule = module;

  // Update active nav item
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.module === module);
  });

  // Update page title
  const titles = {
    dashboard: 'Dashboard', portfolio: 'Portfolio', transactions: 'Transactions',
    dividends: 'Dividends', cgt: 'CGT Detail', tax_summary: 'FY Tax Summary',
    cost_base_recon: 'Cost Base Reconciliation',
    watchlist: 'Watch List',
    actions: 'Corporate Actions',
    securities: 'Securities', import_data: 'Import / Export', settings: 'Settings',
  };
  document.getElementById('page-title').textContent = titles[module] || module;

  const content = document.getElementById('module-content');
  content.innerHTML = '<div class="st-empty"><div class="st-empty-icon">⏳</div>Loading…</div>';

  const def = _moduleMap[module];
  if (!def) {
    content.innerHTML = '<div class="st-empty"><div class="st-empty-title">Module not found</div></div>';
    return;
  }

  try {
    await loadModule(def.js);
    if (def.fn) window[def.fn]();
  } catch (e) {
    content.innerHTML = `<div class="st-empty"><div class="st-empty-title">Error loading module</div><div>${e.message}</div></div>`;
  }
}

// ── Slide-over helpers ────────────────────────────────────────────────────────
function openPanel(titleText, bodyHtml, footHtml) {
  document.getElementById('det-title').textContent = titleText;
  document.getElementById('det-body').innerHTML = bodyHtml;
  document.getElementById('det-foot').innerHTML = footHtml;
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
}

function closePanel() {
  document.getElementById('det-overlay').classList.remove('open');
  document.getElementById('det-panel').classList.remove('open');
}

// ── App-wide settings cache ───────────────────────────────────────────────────
let _appSettings = {};

async function _loadAppSettings() {
  try { _appSettings = await apiFetch('/api/settings'); } catch (e) {}
  await _loadHoldingList();
}

// ── Holdings (HIN/SRN/broker accounts) — picker for new records ──────────────
let _appHoldings = [];

async function _loadHoldingList() {
  try { _appHoldings = (await apiFetch('/api/holding-accounts')).holdings || []; } catch (e) { _appHoldings = []; }
}

function holdingLabel(h) {
  const pct = Math.round(h.share_now * 10000) / 100;
  return `${h.code}${h.name ? ' — ' + h.name : ''}${pct < 100 ? ` (your share ${pct}%)` : ''}`;
}

// A Holding select for a new record ('' when the portfolio has no holdings)
function holdingField(id, selected = null, hint = 'the HIN/SRN or broker account') {
  if (!_appHoldings.length) return '';
  return `<div class="field"><label>Holding <span style="font-weight:400;text-transform:none;letter-spacing:0">${hint}</span></label>
    <select id="${id}"><option value="">— None —</option>${_appHoldings.map(h =>
      `<option value="${h.id}" ${h.id === selected || (selected == null && _appHoldings.length === 1) ? 'selected' : ''}>${holdingLabel(h)}</option>`).join('')}
    </select></div>`;
}

// ── Specific-parcel picker for sales: tick parcels, optionally with a quantity from each ──
function parcelPickerHtml(parcels, listId, qtyInputId) {
  if (!parcels.length) return '<div style="color:var(--ink3);font-size:12px">No open parcels</div>';
  const today = new Date();
  return `<div style="font-size:11px;color:var(--ink3);margin-bottom:6px">Tick the parcels to sell from. Leave the
      quantities blank to use them in the order ticked, or enter how many shares come from each.</div>` +
    parcels.map(p => {
      const days = Math.floor((today - new Date(p.acquisition_date)) / 86400000);
      const disc = days > 365 ? '<span class="badge badge-green" style="font-size:10px">Disc</span>' : '';
      return `<div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border);font-size:12px">
        <input type="checkbox" data-parcel-id="${p.id}" style="flex-shrink:0" onchange="parcelPickerTotal('${listId}', '${qtyInputId}')">
        <div style="flex:1;min-width:0">
          <div style="font-family:'DM Mono',monospace">${fmtDate(p.acquisition_date)}${p.label ? ' · ' + p.label : ''}${p.holding_code ? ` <span class="badge badge-ink" style="font-size:10px">${p.holding_code}</span>` : ''} ${disc}</div>
          <div style="color:var(--ink3);font-size:11px">${fmtNum(p.quantity_remaining, 4)} left · ${fmtCurrency(p.cost_base / p.quantity)}/unit · ${days}d</div>
        </div>
        <input type="number" class="pp-qty" data-parcel-id="${p.id}" min="0" step="any"
          placeholder="Qty" style="width:80px;flex-shrink:0" oninput="parcelPickerTyped(this, '${listId}', '${qtyInputId}')">
      </div>`;
    }).join('') + `<div id="${listId}-total" style="font-size:11px;color:var(--ink3);margin-top:6px"></div>`;
}

function parcelPickerTyped(input, listId, qtyInputId) {
  const cb = document.querySelector(`#${listId} input[type=checkbox][data-parcel-id="${input.dataset.parcelId}"]`);
  if (cb && input.value) cb.checked = true;
  parcelPickerTotal(listId, qtyInputId);
}

function parcelPickerTotal(listId, qtyInputId) {
  const el = document.getElementById(`${listId}-total`);
  if (!el) return;
  const qtys = [...document.querySelectorAll(`#${listId} .pp-qty`)].filter(i => i.value);
  if (!qtys.length) { el.textContent = ''; return; }
  const total = qtys.reduce((s, i) => s + (parseFloat(i.value) || 0), 0);
  const want = parseFloat(document.getElementById(qtyInputId)?.value) || 0;
  const ok = Math.abs(total - want) < 0.0001;
  el.innerHTML = `Allocated <strong>${fmtNum(total, 4)}</strong> of ${fmtNum(want, 4)}` +
    (ok ? '' : ' <span style="color:var(--amber)">— must equal the quantity sold</span>');
}

// {parcel_ids, allocations} for a sale, or {error}. With quantities: every ticked parcel
// needs one, and they must add up to the sale quantity (units as at the sale date).
function parcelPickerRead(listId, saleQty) {
  const ticked = [...document.querySelectorAll(`#${listId} input[type=checkbox]:checked`)];
  if (!ticked.length) return { error: 'Select at least one parcel' };
  const qtyOf = id => document.querySelector(`#${listId} .pp-qty[data-parcel-id="${id}"]`)?.value;
  const withQty = ticked.filter(cb => qtyOf(cb.dataset.parcelId));
  if (!withQty.length) return { parcel_ids: ticked.map(cb => parseInt(cb.dataset.parcelId)), allocations: null };
  if (withQty.length !== ticked.length) return { error: 'Enter a quantity for every ticked parcel, or none' };
  const allocations = ticked.map(cb => [parseInt(cb.dataset.parcelId), parseFloat(qtyOf(cb.dataset.parcelId))]);
  if (allocations.some(a => !(a[1] > 0))) return { error: 'Parcel quantities must be more than 0' };
  const total = allocations.reduce((s, a) => s + a[1], 0);
  if (Math.abs(total - parseFloat(saleQty)) > 0.0001)
    return { error: `The parcel quantities add up to ${fmtNum(total, 4)}, not the ${fmtNum(saleQty, 4)} sold` };
  return { parcel_ids: allocations.map(a => a[0]), allocations };
}

function holdingVal(id) {
  const el = document.getElementById(id);
  return el && el.value ? parseInt(el.value) : null;
}

// ── Portfolio switcher ────────────────────────────────────────────────────────
async function _portSwitchOpen() {
  openPanel('Portfolios', '<div style="color:var(--ink3);font-size:12px;padding:8px 0">Loading…</div>',
    `<button class="btn btn-secondary" onclick="_portNewShow()">+ New Portfolio</button>
     <button class="btn btn-ghost" onclick="closePanel()">Close</button>`);
  await _portPanelRefresh();
}

async function _portPanelRefresh() {
  const body = document.getElementById('det-body');
  if (!body) return;
  try {
    const portfolios = await apiFetch('/api/portfolio/list');
    if (!portfolios.length) {
      body.innerHTML = `<div style="color:var(--ink3);font-size:12px;padding:8px 0">No portfolio files found.</div>`;
      return;
    }
    body.innerHTML = portfolios.map(p => {
      const safePath = p.path.replace(/\\/g, '/').replace(/'/g, "\\'");
      return `<div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--border)">
        <div style="flex:1;min-width:0">
          <div style="font-weight:600;font-size:13px;color:var(--ink)">${p.name}</div>
          <div style="font-size:10px;color:var(--ink3);font-family:'DM Mono',monospace;margin-top:2px;word-break:break-all">${p.path}</div>
        </div>
        ${p.active
          ? '<span class="badge badge-accent">Active</span>'
          : `<button class="btn btn-secondary btn-sm" onclick="_portSwitchTo('${safePath}',this)">Open</button>`}
      </div>`;
    }).join('');
  } catch (e) {
    body.innerHTML = `<div style="color:var(--red);font-size:12px">${e.message}</div>`;
  }
}

function _portNewShow() {
  const body = document.getElementById('det-body');
  if (!body) return;
  body.innerHTML = `
    <div style="font-size:12px;color:var(--ink3);margin-bottom:12px">A <code>.dinv</code> file will be created in the same folder as the current portfolio.</div>
    <div class="field"><label>Portfolio Name</label>
      <input id="port-new-name" type="text" placeholder="e.g. Super Fund" onkeydown="if(event.key==='Enter')_portNewCreate()">
    </div>
    <div id="port-new-err" style="color:var(--red);font-size:12px;margin-top:4px;display:none"></div>`;
  document.getElementById('det-foot').innerHTML =
    `<button class="btn btn-secondary" onclick="_portPanelRefresh()">Cancel</button>
     <button class="btn btn-primary" onclick="_portNewCreate()">Create Portfolio</button>`;
  document.getElementById('port-new-name').focus();
}

async function _portNewCreate() {
  const name  = document.getElementById('port-new-name')?.value.trim();
  const errEl = document.getElementById('port-new-err');
  if (!name) { errEl.textContent = 'Enter a portfolio name'; errEl.style.display = ''; return; }
  const btn = document.getElementById('det-foot').querySelector('.btn-primary');
  if (btn) { btn.disabled = true; btn.textContent = 'Creating…'; }
  try {
    const r = await fetch('/api/portfolio/new', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    document.getElementById('portfolio-name').textContent = r.data.name;
    await _loadAppSettings();
    _currentModule = null;
    navigate('dashboard');
    toast(`Created and switched to ${r.data.name}`);
  } catch (e) {
    if (errEl) { errEl.textContent = e.message; errEl.style.display = ''; }
    if (btn) { btn.disabled = false; btn.textContent = 'Create Portfolio'; }
  }
}

async function _portSwitchTo(path, btn) {
  if (btn) { btn.disabled = true; btn.textContent = 'Opening…'; }
  try {
    const r = await fetch('/api/portfolio/switch', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    document.getElementById('portfolio-name').textContent = r.data.name;
    await _loadAppSettings();
    _currentModule = null;
    navigate('dashboard');
    toast(`Switched to ${r.data.name}`);
    await _portPanelRefresh();
  } catch (e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Open'; }
  }
}

// ── Shutdown ──────────────────────────────────────────────────────────────────
async function _shutdown() {
  try { await fetch('/api/shutdown', { method: 'POST' }); } catch (_) {}
  document.body.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100vh;font-family:sans-serif;color:#666"><div style="text-align:center"><div style="font-size:48px;margin-bottom:16px">⏻</div><p>Server stopped.<br>You can close this window.</p></div></div>';
}

// ── Updates (same model as Dogbox Accounting — see web/updater.py) ──────────
let _updInfo = null;

async function _updCheck(force = false) {
  try {
    const d = await apiFetch('/api/system/version' + (force ? '?force=1' : ''));
    _updInfo = d;
    document.getElementById('app-version').textContent = 'v' + d.current;
    const el = document.getElementById('update-banner');
    if (!d.update_available) {
      el.style.display = 'none';
      if (force) toast(d.latest ? `You're up to date (v${d.current})` : "Couldn't check for updates — are you online?",
                       d.latest ? 'ok' : 'err');
      return;
    }
    el.innerHTML = `
      <span>↑</span>
      <span class="upd-msg">Dogbox Investments v${d.latest} is available.</span>
      ${d.notes ? `<button class="btn btn-ghost btn-sm" onclick="_updShowNotes()">What's new</button>` : ''}
      <button class="btn btn-primary btn-sm" onclick="_updApply()">Update</button>
      <span class="upd-close" title="Dismiss" onclick="document.getElementById('update-banner').style.display='none'">✕</span>`;
    el.style.display = '';
  } catch (_) {}
}

function _updNotesHtml(text) {
  const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const inline = s => s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/`([^`]+)`/g, '<code>$1</code>');
  return (text || '').split('\n').map(line => {
    if (/^#{2,3}\s/.test(line)) return `<h4>${inline(esc(line.replace(/^#+\s*/, '')))}</h4>`;
    if (/^[-*]\s/.test(line))   return `<div style="padding-left:14px">• ${inline(esc(line.replace(/^[-*]\s+/, '')))}</div>`;
    if (!line.trim())           return '<div style="height:6px"></div>';
    return `<div>${inline(esc(line))}</div>`;
  }).join('');
}

function _updShowNotes() {
  if (!_updInfo) return;
  openPanel(`What's new in v${_updInfo.latest}`,
    `<div class="upd-notes">${_updNotesHtml(_updInfo.notes) || '<em>No notes provided.</em>'}</div>`,
    `<button class="btn btn-ghost" onclick="closePanel()">Close</button>
     <button class="btn btn-primary" onclick="_updApply()">Update now</button>`);
}

async function _updApply() {
  openPanel('Updating Dogbox Investments', `
    <div id="upd-status" style="font-size:13px">Downloading…</div>
    <div class="upd-bar-track"><div class="upd-bar-fill" id="upd-bar"></div></div>
    <div style="font-size:11px;color:var(--ink3);margin-top:12px">Your portfolio files are not touched. The files being replaced are backed up in the app's <code>backups</code> folder.</div>`,
    '');
  try {
    const r = await fetch('/api/system/apply-update', { method: 'POST' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Update failed');
  } catch (e) {
    document.getElementById('upd-status').textContent = 'Update failed: ' + e.message;
    document.getElementById('det-foot').innerHTML = `<button class="btn btn-ghost" onclick="closePanel()">Close</button>`;
    return;
  }
  const poll = setInterval(async () => {
    try {
      const p = await apiFetch('/api/system/update-progress');
      document.getElementById('upd-bar').style.width = p.pct + '%';
      if (p.state === 'applying') {
        document.getElementById('upd-status').textContent = 'Applying update…';
      } else if (p.state === 'done') {
        clearInterval(poll);
        document.getElementById('upd-status').textContent = 'Update installed — restarting…';
        document.getElementById('update-banner').style.display = 'none';
        _updRestart();
      } else if (p.state === 'error') {
        clearInterval(poll);
        document.getElementById('upd-status').textContent = 'Update failed: ' + p.error + ' — nothing was changed.';
        document.getElementById('det-foot').innerHTML = `<button class="btn btn-ghost" onclick="closePanel()">Close</button>`;
      }
    } catch (_) {}
  }, 600);
}

async function _updRestart() {
  try { await fetch('/api/system/restart', { method: 'POST' }); } catch (_) {}
  // Wait for the old server to exit, then reload once the new one answers
  setTimeout(() => {
    const poll = setInterval(async () => {
      try {
        const r = await fetch('/api/alive', { cache: 'no-store' });
        if (r.ok) { clearInterval(poll); window.location.reload(); }
      } catch (_) {}
    }, 1500);
  }, 2500);
}

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  // Nav clicks
  document.querySelectorAll('.nav-item[data-module]').forEach(el => {
    el.addEventListener('click', () => navigate(el.dataset.module));
  });

  // Panel close
  document.getElementById('det-overlay').addEventListener('click', closePanel);
  document.getElementById('det-close').addEventListener('click', closePanel);

  // Portfolio name in footer
  try {
    const portfolios = await apiFetch('/api/portfolio/list');
    const active = portfolios.find(p => p.active);
    if (active) document.getElementById('portfolio-name').textContent = active.name;
  } catch (e) {}

  // Load settings into global cache
  await _loadAppSettings();

  // Land on dashboard
  navigate('dashboard');

  // Version label + update check (daily, cached server-side)
  _updCheck();
});
