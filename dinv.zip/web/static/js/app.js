// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — core utilities and navigation */

// ── API fetch ─────────────────────────────────────────────────────────────────
async function apiFetch(url, opts = {}) {
  const r = await fetch(url, opts);
  const j = await r.json();
  if (!j.ok) throw new Error(j.error || 'Request failed');
  return j.data;
}

// ── Toast ─────────────────────────────────────────────────────────────────────
// Errors stay until OK is clicked (they're often long, e.g. an import's line number and problem)
function toast(msg, type = 'ok') {
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.textContent = msg;
  const close = () => { t.classList.remove('show'); setTimeout(() => t.remove(), 300); };
  if (type === 'err') {
    const ok = document.createElement('button');
    ok.className = 'toast-ok-btn';
    ok.textContent = 'OK';
    ok.onclick = close;
    t.appendChild(ok);
  } else {
    setTimeout(close, 3200);
  }
  document.body.appendChild(t);
  requestAnimationFrame(() => t.classList.add('show'));
}

// ── Date / number formatting ──────────────────────────────────────────────────
function fmtDate(iso) {
  if (!iso) return '—';
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
}

function fmtCurrency(n, decimals = 2) {
  if (n == null) return '—';
  const v = parseFloat(n);
  if (isNaN(v)) return '—';
  const abs = Math.abs(v).toLocaleString('en-AU', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
  return (v < 0 ? '-' : '') + '$' + abs;
}

// <option>s for financial years ending 30 June: this year back to the portfolio's first
// (at least `minYears` years). selected: the FY to select (default this year).
function fyOptions(selected, minYears = 5) {
  const today = new Date();
  const currentFy = today.getMonth() >= 6 ? today.getFullYear() + 1 : today.getFullYear();
  const first = Math.min((_appSettings && _appSettings._first_fy) || currentFy, currentFy - minYears + 1);
  const sel = selected || currentFy;
  let out = '';
  for (let y = currentFy; y >= first; y--) {
    out += `<option value="${y}" ${y === sel ? 'selected' : ''}>${y} (${y - 1}–${y})</option>`;
  }
  return out;
}

// How a disposal is taxed (sale_parcels.cgt_basis, worked out in core/portfolio.py)
function cgtBasisBadge(basis) {
  return {
    discount:   '<span class="badge badge-green" title="Held more than 12 months — CGT discount">Discount</span>',
    indexation: '<span class="badge badge-accent" title="Cost base indexed to September 1999 — no discount">Indexed</span>',
    pre_cgt:    '<span class="badge badge-ink" title="Acquired before 20 September 1985 — exempt from CGT">Pre-CGT</span>',
    not_cgt:    '<span class="badge badge-ink" title="Before CGT began on 20 September 1985">No CGT</span>',
    rollover:   '<span class="badge badge-ink" title="Takeover with scrip-for-scrip roll-over and no cash — nothing taxed now">Roll-over</span>',
    '2027':     '<span class="badge badge-accent" title="Sold from 1 July 2027: the gain up to 30 June 2027 keeps the old rules; the gain since is on the 30 June 2027 value, indexed if held 12 months">2027 rules</span>',
    needs_value:'<span class="badge badge-amber" title="Held at 30 June 2027 — enter its 30 June 2027 value in Settings. Until then the whole gain is counted without a discount">Value needed</span>',
    indexed:    '<span class="badge badge-accent" title="From 1 July 2027: the cost base indexed by CPI — no discount">Indexed</span>',
  }[basis] || '—';
}

// Under the gain of a sale costed under the 2027 rules: its two parts
function cgt2027Parts(r) {
  if (r.rules !== '2027') return '';
  const line = (label, amount, note, title) => `<div style="font-size:11px;color:var(--ink3);white-space:nowrap" title="${title}">
    ${label} <span class="${gainClass(amount)}">${fmtCurrency(amount)}</span>${note ? ` · ${note}` : ''}</div>`;
  return (r.pre_gain != null ? line('to 30 Jun 2027', r.pre_gain,
            r.pre_basis === 'discount' ? 'discount' : r.pre_basis === 'pre_cgt' ? 'pre-CGT, exempt' : '',
            `30 June 2027 value ${fmtCurrency(r.value_2027)} less the cost base then`) : '') +
         line('from 1 Jul 2027', r.post_gain,
            r.index_factor > 1 ? `indexed ×${Number(r.index_factor).toFixed(3)}${r.cpi_provisional ? ' (latest CPI)' : ''}`
              : r.cpi_provisional ? 'not indexed yet — CPI not out' : '',
            `Cost base ${fmtCurrency(r.post_cost_base)}${r.post_indexed_cb != null ? `, indexed ${fmtCurrency(r.post_indexed_cb)}` : ''}`);
}

// Jointly held portfolio: tax figures are the owner's share (Settings → Your Share)
function ownershipNote() {
  const pct = _appSettings && _appSettings.ownership_pct;
  const joint = _appSettings && _appSettings._joint_holdings;
  return pct ? `<div style="font-size:12px;color:var(--ink2);padding:8px 2px 12px">
    Figures are your <strong>${pct}%</strong> share of jointly held shares (Settings).</div>`
    : joint ? `<div style="font-size:12px;color:var(--ink2);padding:8px 2px 12px">
    Figures for jointly held holdings are your share (Settings → Holdings).</div>` : '';
}

function fmtNum(n, decimals = 4) {
  if (n == null) return '—';
  const v = parseFloat(n);
  if (isNaN(v)) return '—';
  return v.toLocaleString('en-AU', {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals,
  });
}

// A percentage to at most 2 decimals, e.g. 90.47619047619048 → "90.48%", 100 → "100%".
// 0 / empty → "—" (the dividend tables' "no franking").
function fmtPct(n, decimals = 2) {
  const v = parseFloat(n);
  return v ? fmtNum(v, decimals) + '%' : '—';
}

// A unit change as "4-for-5" when both sides are small whole numbers, as announced.
// Otherwise (a ratio imported as a decimal, e.g. 1.41232518 → 1,411,571-for-999,466)
// as the multiplier, "×1.41233". Bonus issues pass sep ' for ' and bonus true: new shares
// per share held, "0.41233 per share".
function fmtRatio(to, from, sep = '-for-', bonus = false) {
  const t = parseFloat(to), f = parseFloat(from);
  if (isNaN(t) || isNaN(f) || !f) return '—';
  const whole = x => Math.abs(x - Math.round(x)) < 1e-9 && Math.round(x) < 10000;
  if (whole(t) && whole(f)) return `${Math.round(t)}${sep}${Math.round(f)}`;
  const r = parseFloat((t / f).toPrecision(6)).toLocaleString('en-AU', { maximumFractionDigits: 6 });
  return bonus ? `${r} per share` : '×' + r;
}

function gainClass(n) {
  const v = parseFloat(n);
  if (v > 0) return 'gain';
  if (v < 0) return 'loss';
  return 'flat';
}

function _isLocked(dateStr) {
  if (!dateStr || !_appSettings?.locked_fy) return false;
  const lockedFy = parseInt(_appSettings.locked_fy);
  if (!lockedFy) return false;
  const d = new Date(dateStr + 'T00:00:00');
  const fy = (d.getMonth() + 1) >= 7 ? d.getFullYear() + 1 : d.getFullYear();
  return fy <= lockedFy;
}

// ── Module loader ─────────────────────────────────────────────────────────────
const _loadedModules = new Set();

async function loadModule(name) {
  if (_loadedModules.has(name)) return;
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = `/static/js/${name}.js`;
    s.onload = () => { _loadedModules.add(name); resolve(); };
    s.onerror = reject;
    document.head.appendChild(s);
  });
}

// ── Navigation ────────────────────────────────────────────────────────────────
const _moduleMap = {
  dashboard:       { js: 'dashboard',       fn: 'pageDashboard' },
  portfolio:       { js: 'portfolio',       fn: 'pagePortfolio' },
  transactions:    { js: 'transactions',    fn: 'pageTransactions' },
  dividends:       { js: 'dividends',       fn: 'pageDividends' },
  cgt:             { js: 'cgt',             fn: 'pageCgt' },
  tax_summary:     { js: 'tax_summary',     fn: 'pageTaxSummary' },
  actions:         { js: 'actions',         fn: 'pageActions' },
  securities:      { js: 'securities',      fn: 'pageSecurities' },
  import_data:     { js: 'import_data',     fn: 'pageImportData' },
  settings:        { js: 'settings_mod',    fn: 'pageSettings' },
  security_detail:  { js: 'security_detail',   fn: null },
  cost_base_recon:  { js: 'cost_base_recon',   fn: 'pageCostBaseRecon' },
  watchlist:        { js: 'watchlist',          fn: 'pageWatchlist' },
  help:             { js: 'help',               fn: 'pageHelp' },
};

let _currentModule = null;

async function navigate(module) {
  if (module === _currentModule) return;
  _currentModule = module;

  // Update active nav item
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.module === module);
  });

  // Update page title
  const titles = {
    dashboard: 'Dashboard', portfolio: 'Portfolio', transactions: 'Transactions',
    dividends: 'Dividends', cgt: 'CGT Detail', tax_summary: 'FY Tax Summary',
    cost_base_recon: 'Cost Base Reconciliation',
    watchlist: 'Watch List',
    actions: 'Corporate Actions',
    securities: 'Securities', import_data: 'Import / Export', settings: 'Settings',
    help: 'Help',
  };
  document.getElementById('page-title').textContent = titles[module] || module;

  const content = document.getElementById('module-content');
  content.innerHTML = '<div class="st-empty"><div class="st-empty-icon">⏳</div>Loading…</div>';

  const def = _moduleMap[module];
  if (!def) {
    content.innerHTML = '<div class="st-empty"><div class="st-empty-title">Module not found</div></div>';
    return;
  }

  try {
    await loadModule(def.js);
    if (def.fn) window[def.fn]();
  } catch (e) {
    content.innerHTML = `<div class="st-empty"><div class="st-empty-title">Error loading module</div><div>${e.message}</div></div>`;
  }
}

// ── Slide-over helpers ────────────────────────────────────────────────────────
function openPanel(titleText, bodyHtml, footHtml) {
  document.getElementById('det-title').textContent = titleText;
  document.getElementById('det-body').innerHTML = bodyHtml;
  document.getElementById('det-foot').innerHTML = footHtml;
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
}

function closePanel() {
  document.getElementById('det-overlay').classList.remove('open');
  document.getElementById('det-panel').classList.remove('open', 'wide');
}

// ── Attachments: source documents on purchases, sales, dividends, actions ─────
// attBtn() goes in a list row; it opens the Documents panel for that record. Records made
// by another record (DRP parcels, takeover disposals, ...) have attachable false: their
// documents go on the dividend or corporate action.
function _attEsc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// ── Code at the time ──────────────────────────────────────────────────────────
// List rows carry code (today's) and, when the code has changed, code_then (the code on
// the row's date, as on its paperwork). codeThen() is the code to show; codeCellHtml()
// shows it with today's code in a tooltip, plus a hidden copy so a search for today's code
// still finds the row (searches read the row's text).
function codeThen(row, key = 'code') {
  return row[key + '_then'] || row[key];
}

function codeCellHtml(row, extra = '') {
  const then = codeThen(row);
  if (then === row.code) return `<td class="code-cell">${row.code}${extra}</td>`;
  return `<td class="code-cell" title="Now ${_attEsc(row.code)}">${then}<span hidden> ${row.code}</span>${extra}</td>`;
}

function attBtn(type, row, title) {
  if (row.attachable === false) return '';
  const n = row.att_count || 0;
  const t = _attEsc(title).replace(/&#39;/g, "\\'");
  return `<button class="btn btn-ghost btn-sm att-btn${n ? ' has' : ''}" data-att="${type}-${row.id}"
    title="${n ? `${n} document${n === 1 ? '' : 's'}` : 'Attach a contract note, statement or notice'}"
    onclick="attOpen('${type}',${row.id},'${t}')">📎${n ? `<span>${n}</span>` : ''}</button>`;
}

let _att = null;   // {type, id, title}

function attOpen(type, id, title) {
  _att = {type, id, title};
  openPanel(`Documents — ${title}`,
    `<label class="att-drop" id="att-drop">
       <input type="file" multiple style="display:none" onchange="_attUpload(this.files); this.value=''">
       <div style="font-weight:600;color:var(--ink)">Drop files here, or click to choose</div>
       <div style="font-size:11.5px;color:var(--ink3);margin-top:4px">Contract notes, dividend statements, company notices — PDFs, photos or scans, up to 10 MB each</div>
     </label>
     <div id="att-list" style="margin-top:14px"><div style="font-size:12px;color:var(--ink3)">Loading…</div></div>
     <div style="font-size:11.5px;color:var(--ink3);line-height:1.5;margin-top:16px">
       Documents are kept inside the portfolio file, so backups and copies include them.
       Deleting this record deletes its documents too.</div>`,
    `<button class="btn btn-outline" onclick="closePanel()">Close</button>`);
  const drop = document.getElementById('att-drop');
  drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('over'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('over'));
  drop.addEventListener('drop', e => { e.preventDefault(); drop.classList.remove('over'); _attUpload(e.dataTransfer.files); });
  _attRender();
}

async function _attRender() {
  const el = document.getElementById('att-list');
  if (!el || !_att) return;
  try {
    const rows = await apiFetch(`/api/attachments/${_att.type}/${_att.id}`);
    _attSetCount(rows.length);
    el.innerHTML = rows.length ? rows.map(a => {
      const icon = (a.mime_type || '').startsWith('image/') ? '🖼' : (a.mime_type || '').includes('pdf') ? '📄' : '📎';
      const size = a.file_size >= 1048576 ? (a.file_size / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(a.file_size / 1024)) + ' KB';
      return `<div class="att-row">
        <span class="att-icon">${icon}</span>
        <div class="att-info">
          <a class="att-name" href="/api/attachments/${a.id}/file?inline=1" target="_blank" title="Open">${_attEsc(a.filename)}</a>
          <div class="att-meta">${size} · added ${fmtDate((a.uploaded_at || '').slice(0, 10))}</div>
        </div>
        <a class="btn btn-ghost btn-sm" href="/api/attachments/${a.id}/file" title="Save a copy">Save</a>
        <button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="_attDelete(${a.id})" title="Delete">✕</button>
      </div>`;
    }).join('') : `<div style="font-size:12px;color:var(--ink3)">No documents yet</div>`;
  } catch (e) {
    el.innerHTML = `<div style="font-size:12px;color:var(--red)">${_attEsc(e.message)}</div>`;
  }
}

async function _attUpload(files) {
  files = Array.from(files || []);
  if (!files.length || !_att) return;
  const fd = new FormData();
  for (const f of files) {
    if (f.size > 10 * 1024 * 1024) { toast(`${f.name} is over the 10 MB limit`, 'err'); continue; }
    fd.append('file', f);
  }
  if (!fd.has('file')) return;
  try {
    const r = await fetch(`/api/attachments/${_att.type}/${_att.id}`, {method: 'POST', body: fd});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Upload failed');
    (j.data.problems || []).forEach(p => toast(p, 'err'));
  } catch (e) { toast(e.message, 'err'); }
  _attRender();
}

async function _attDelete(attId) {
  if (!confirm('Delete this document? It is removed from the portfolio file.')) return;
  try {
    const r = await fetch(`/api/attachments/${attId}`, {method: 'DELETE'});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Delete failed');
  } catch (e) { toast(e.message, 'err'); }
  _attRender();
}

// For a delete confirmation: the record's documents go with it (count from its 📎 button)
function attDeleteNote(type, id) {
  const n = parseInt(document.querySelector(`[data-att="${type}-${id}"] span`)?.textContent || '0');
  return n ? `

Its ${n} attached document${n === 1 ? '' : 's'} will be deleted too.` : '';
}

// Update the record's 📎 button(s) on the page without reloading the list
function _attSetCount(n) {
  document.querySelectorAll(`[data-att="${_att.type}-${_att.id}"]`).forEach(b => {
    b.classList.toggle('has', n > 0);
    b.innerHTML = '📎' + (n ? `<span>${n}</span>` : '');
    b.title = n ? `${n} document${n === 1 ? '' : 's'}` : 'Attach a contract note, statement or notice';
  });
}

// ── App-wide settings cache ───────────────────────────────────────────────────
let _appSettings = {};

async function _loadAppSettings() {
  try { _appSettings = await apiFetch('/api/settings'); } catch (e) {}
  await _loadHoldingList();
}

// ── Holdings (HIN/SRN/broker accounts) — picker for new records ──────────────
let _appHoldings = [];

async function _loadHoldingList() {
  try { _appHoldings = (await apiFetch('/api/holding-accounts')).holdings || []; } catch (e) { _appHoldings = []; }
}

function holdingLabel(h) {
  const pct = Math.round(h.share_now * 10000) / 100;
  return `${h.code}${h.name ? ' — ' + h.name : ''}${pct < 100 ? ` (your share ${pct}%)` : ''}`;
}

// A Holding select for a new record ('' when the portfolio has no holdings)
function holdingField(id, selected = null, hint = 'the HIN/SRN or broker account') {
  if (!_appHoldings.length) return '';
  return `<div class="field"><label>Holding <span style="font-weight:400;text-transform:none;letter-spacing:0">${hint}</span></label>
    <select id="${id}"><option value="">— None —</option>${_appHoldings.map(h =>
      `<option value="${h.id}" ${h.id === selected || (selected == null && _appHoldings.length === 1) ? 'selected' : ''}>${holdingLabel(h)}</option>`).join('')}
    </select></div>`;
}

// CGT discount hint — same rule as _held_12_months() in core/portfolio.py: the sale must fall
// after the first anniversary of acquisition (29 Feb → 28 Feb). Dates are ISO strings.
function heldOver12Months(acqIso, saleIso) {
  if (!acqIso || !saleIso) return false;
  let [y, m, d] = acqIso.slice(0, 10).split('-');
  if (m === '02' && d === '29') d = '28';
  return saleIso > `${+y + 1}-${m}-${d}`;
}

// Show/hide the "Disc" and "Restricted" badges in a parcel picker for the sale date entered
function parcelPickerDisc(listId, saleIso) {
  document.querySelectorAll(`#${listId} [data-cgt-acq]`).forEach(b => {
    b.style.display = heldOver12Months(b.dataset.cgtAcq, saleIso) ? '' : 'none';
  });
  document.querySelectorAll(`#${listId} [data-restricted-until]`).forEach(b => {
    b.style.display = saleIso && saleIso < b.dataset.restrictedUntil ? '' : 'none';
  });
}

// ── Specific-parcel picker for sales: tick parcels, optionally with a quantity from each ──
function parcelPickerHtml(parcels, listId, qtyInputId, saleIso) {
  if (!parcels.length) return '<div style="color:var(--ink3);font-size:12px">No open parcels</div>';
  saleIso = saleIso || new Date().toISOString().slice(0, 10);
  return `<div style="font-size:11px;color:var(--ink3);margin-bottom:6px">Tick the parcels to sell from. Leave the
      quantities blank to use them in the order ticked, or enter how many shares come from each.</div>` +
    parcels.map(p => {
      const days = Math.floor((new Date() - new Date(p.acquisition_date)) / 86400000);  // days held to today
      const acq  = p.cgt_date || p.acquisition_date;
      const disc = `<span class="badge badge-green" style="font-size:10px${heldOver12Months(acq, saleIso) ? '' : ';display:none'}"
        data-cgt-acq="${acq}" title="Held more than 12 months at the sale date — CGT discount">Disc</span>`;
      const restr = p.restricted_until ? `<span class="badge badge-amber" style="font-size:10px${saleIso < p.restricted_until ? '' : ';display:none'}"
        data-restricted-until="${p.restricted_until}" title="Employee shares: the plan's restriction period hasn't ended at the sale date. Only tick them if it ended early (for example you left the employer)">Restricted until ${fmtDate(p.restricted_until)}</span>` : '';
      return `<div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border);font-size:12px">
        <input type="checkbox" data-parcel-id="${p.id}" style="flex-shrink:0" onchange="parcelPickerTotal('${listId}', '${qtyInputId}')">
        <div style="flex:1;min-width:0">
          <div style="font-family:'DM Mono',monospace">${fmtDate(p.acquisition_date)}${p.label ? ' · ' + p.label : ''}${p.holding_code ? ` <span class="badge badge-ink" style="font-size:10px">${p.holding_code}</span>` : ''} ${disc} ${restr}</div>
          <div style="color:var(--ink3);font-size:11px">${fmtNum(p.quantity_remaining, 4)} left · ${fmtCurrency(p.cost_base / p.quantity)}/unit · ${days}d</div>
        </div>
        <input type="number" class="pp-qty" data-parcel-id="${p.id}" min="0" step="any"
          placeholder="Qty" style="width:80px;flex-shrink:0" oninput="parcelPickerTyped(this, '${listId}', '${qtyInputId}')">
      </div>`;
    }).join('') + `<div id="${listId}-total" style="font-size:11px;color:var(--ink3);margin-top:6px"></div>`;
}

function parcelPickerTyped(input, listId, qtyInputId) {
  const cb = document.querySelector(`#${listId} input[type=checkbox][data-parcel-id="${input.dataset.parcelId}"]`);
  if (cb && input.value) cb.checked = true;
  parcelPickerTotal(listId, qtyInputId);
}

function parcelPickerTotal(listId, qtyInputId) {
  const el = document.getElementById(`${listId}-total`);
  if (!el) return;
  const qtys = [...document.querySelectorAll(`#${listId} .pp-qty`)].filter(i => i.value);
  if (!qtys.length) { el.textContent = ''; return; }
  const total = qtys.reduce((s, i) => s + (parseFloat(i.value) || 0), 0);
  const want = parseFloat(document.getElementById(qtyInputId)?.value) || 0;
  const ok = Math.abs(total - want) < 0.0001;
  el.innerHTML = `Allocated <strong>${fmtNum(total, 4)}</strong> of ${fmtNum(want, 4)}` +
    (ok ? '' : ' <span style="color:var(--amber)">— must equal the quantity sold</span>');
}

// {parcel_ids, allocations} for a sale, or {error}. With quantities: every ticked parcel
// needs one, and they must add up to the sale quantity (units as at the sale date).
function parcelPickerRead(listId, saleQty) {
  const ticked = [...document.querySelectorAll(`#${listId} input[type=checkbox]:checked`)];
  if (!ticked.length) return { error: 'Select at least one parcel' };
  const qtyOf = id => document.querySelector(`#${listId} .pp-qty[data-parcel-id="${id}"]`)?.value;
  const withQty = ticked.filter(cb => qtyOf(cb.dataset.parcelId));
  if (!withQty.length) return { parcel_ids: ticked.map(cb => parseInt(cb.dataset.parcelId)), allocations: null };
  if (withQty.length !== ticked.length) return { error: 'Enter a quantity for every ticked parcel, or none' };
  const allocations = ticked.map(cb => [parseInt(cb.dataset.parcelId), parseFloat(qtyOf(cb.dataset.parcelId))]);
  if (allocations.some(a => !(a[1] > 0))) return { error: 'Parcel quantities must be more than 0' };
  const total = allocations.reduce((s, a) => s + a[1], 0);
  if (Math.abs(total - parseFloat(saleQty)) > 0.0001)
    return { error: `The parcel quantities add up to ${fmtNum(total, 4)}, not the ${fmtNum(saleQty, 4)} sold` };
  return { parcel_ids: allocations.map(a => a[0]), allocations };
}

// The 45-day badge's note on how the answer was reached (core/portfolio.py _eligible_45day)
function div45Note(d) {
  if (d.eligible_45day_inferred) return ' (no ex-date or record date: the answer is the same for any ex-date before the payment date)';
  return d.ex_date_estimated ? ' (ex-date estimated from the record date)' : '';
}

// ── Purchases after a split or consolidation ─────────────────────────────────
// Parcels hold today's units; entered_quantity / entered_price (core/portfolio.py
// _with_entered_units) are the contract note's. Lists and edit forms show the contract note's.
function unitChangesText(p) {
  if (!p.unit_changes || !p.unit_changes.length) return '';
  const what = p.unit_changes.map(a =>
    `the ${fmtNum(a.ratio_from)}:${fmtNum(a.ratio_to)} ${a.action_type.replace('_', ' ')} on ${fmtDate(a.action_date)}`
  ).join(' and ');
  return `Now ${fmtNum(p.quantity, 4)} units after ${what}.`;
}

function unitChangesNote(p) {
  const t = unitChangesText(p);
  return t ? `<div style="font-size:12px;color:var(--ink3);margin:-4px 0 12px">
    Quantity and price are as on the contract note. ${t}</div>` : '';
}

// ── Dividend: tax withheld and foreign-currency amounts ──────────────────────
// Amount per share and tax withheld can be typed as on a foreign statement (US$0.25): the
// server converts them with the exchange rate (core/portfolio.py dividend_amounts).
// divAmountValue: what to show in the Amount per share box when editing.
function divAmountValue(d) {
  if (!d) return '';
  return d.amount_entered || (d.amount_per_share != null ? numInputValue(d.amount_per_share) : '');
}

// A stored number for an input box, without floating-point noise: 9337.999999999 → 9338,
// 0.0300000000000321 → 0.03. dp: decimal places to keep; omitted, 10 significant digits
// (removes only the noise, so a real fraction like 0.0123456 is kept).
function numInputValue(x, dp) {
  if (x == null || x === '' || isNaN(x)) return '';
  const n = Number(x);
  return String(Number(dp == null ? n.toPrecision(10) : n.toFixed(dp)));
}

// The Tax Withheld / Exchange Rate fields. p = the form's id prefix (e.g. 'div').
function divTaxFields(p, d) {
  const hint = 'font-weight:400;text-transform:none;letter-spacing:0';
  const wh = d ? (d.tax_withheld_entered || (d.tax_withheld ? String(d.tax_withheld) : '')) : '';
  return `
    <div class="field-row cols-2">
      <div class="field"><label>Tax Withheld <span style="${hint}">from statement</span></label>
        <input type="text" inputmode="decimal" id="${p}-wh" value="${wh}" placeholder="0.00 or US$0.00">
      </div>
      <div class="field"><label>Exchange Rate <span style="${hint}">A$ per 1 unit — for US$ etc.</span></label>
        <input type="number" id="${p}-fx" min="0" step="any" value="${d?.fx_rate ?? ''}" placeholder="e.g. 1.53">
      </div>
    </div>
    <div style="font-size:11px;color:var(--ink3);margin-top:-8px;margin-bottom:12px">
      Amounts can be typed as on the statement, e.g. US$0.25 — they're converted with the exchange rate and kept in A$.
      For a foreign company, tax withheld is foreign tax (Item 20O); for an Australian company, it's tax withheld because no TFN was given (Item 11M).
    </div>
    <div id="${p}-net" style="font-size:12px;margin:-4px 0 12px">${d ? divNetText(p, d) : ''}</div>`;
}

// What was paid after tax withheld, so a net amount typed as the amount per share stands out.
// Mirrors core/portfolio.py parse_amount: '0.25', '$0.25', 'A$0.25' → A$; 'US$0.25' → US.
function _divParseAmount(text) {
  const m = String(text || '').trim().match(/^([A-Za-z]{1,3})?\s*(\$)?\s*([-+]?[\d,]*\.?\d+)$/);
  if (!m || (m[1] && !m[2] && m[1].length !== 3)) return null;
  let cur = (m[1] || '').toUpperCase();
  cur = ['', 'A', 'AU', 'AUD'].includes(cur) ? '' : (cur === 'USD' ? 'US' : cur);
  return { value: parseFloat(m[3].replace(/,/g, '')), cur };
}

// d (optional): the saved dividend, used before the form is filled in
function divNetText(p, d) {
  const val = id => document.getElementById(`${p}-${id}`)?.value;
  const qty = parseFloat(d ? d.quantity_held : val('qty'));
  const aps = _divParseAmount(d ? divAmountValue(d) : val('aps'));
  const wh  = _divParseAmount(d ? (d.tax_withheld_entered || d.tax_withheld) : val('wh'));
  const fx  = parseFloat(d ? d.fx_rate : val('fx'));
  if (!(qty > 0) || !aps || !wh || !(wh.value > 0)) return '';
  let cur = aps.cur, gross = qty * aps.value, tax = wh.value;
  if (aps.cur !== wh.cur) {                // mixed A$ and foreign: show A$ if there's a rate
    if (!(fx > 0) || (aps.cur && wh.cur)) return '';
    if (aps.cur) gross *= fx; else tax *= fx;
    cur = '';
  }
  const money = v => `${cur ? cur : 'A'}$${v.toLocaleString('en-AU', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  if (tax >= gross)
    return `<span style="color:var(--red)">The tax withheld (${money(tax)}) is more than the dividend (${money(gross)}):
      Amount Per Share should be the amount before tax.</span>`;
  return `Paid to you: <strong>${money(gross - tax)}</strong> (${money(gross)} before tax, less ${money(tax)} withheld).
    <span style="color:var(--ink3)">This should match the amount paid on the statement. If it's less, Amount Per Share is probably the amount after tax: enter it before tax.</span>`;
}

document.addEventListener('input', e => {
  const m = (e.target.id || '').match(/^(.*)-(qty|aps|wh|fx)$/);
  const out = m && document.getElementById(`${m[1]}-net`);
  if (out) out.innerHTML = divNetText(m[1]);
});

function divTaxValues(p) {
  return {
    tax_withheld: (document.getElementById(`${p}-wh`)?.value || '').trim(),
    fx_rate:      (document.getElementById(`${p}-fx`)?.value || '').trim(),
  };
}

// Tax withheld as a table cell: A$, with the typed foreign amount as a tooltip
function divWithheldCell(d) {
  if (!d.tax_withheld) return '—';
  const t = d.tax_withheld_entered ? ` title="${d.tax_withheld_entered} at ${d.fx_rate}"` : '';
  return `<span${t}>${fmtCurrency(d.tax_withheld)}</span>`;
}

function holdingVal(id) {
  const el = document.getElementById(id);
  return el && el.value ? parseInt(el.value) : null;
}

// ── Portfolio switcher ────────────────────────────────────────────────────────
async function _portSwitchOpen() {
  openPanel('Portfolios', '<div style="color:var(--ink3);font-size:12px;padding:8px 0">Loading…</div>',
    `<button class="btn btn-secondary" onclick="_portNewShow()">+ New Portfolio</button>
     <button class="btn btn-ghost" onclick="closePanel()">Close</button>`);
  await _portPanelRefresh();
}

async function _portPanelRefresh() {
  const body = document.getElementById('det-body');
  if (!body) return;
  try {
    const portfolios = await apiFetch('/api/portfolio/list');
    if (!portfolios.length) {
      body.innerHTML = `<div style="color:var(--ink3);font-size:12px;padding:8px 0">No portfolio files found.</div>`;
      return;
    }
    body.innerHTML = portfolios.map(p => {
      const safePath = p.path.replace(/\\/g, '/').replace(/'/g, "\\'");
      return `<div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--border)">
        <div style="flex:1;min-width:0">
          <div style="font-weight:600;font-size:13px;color:var(--ink)">${p.name}</div>
          <div style="font-size:10px;color:var(--ink3);font-family:'DM Mono',monospace;margin-top:2px;word-break:break-all">${p.path}</div>
        </div>
        ${p.active
          ? '<span class="badge badge-accent">Active</span>'
          : `<button class="btn btn-secondary btn-sm" onclick="_portSwitchTo('${safePath}',this)">Open</button>`}
      </div>`;
    }).join('');
  } catch (e) {
    body.innerHTML = `<div style="color:var(--red);font-size:12px">${e.message}</div>`;
  }
}

function _portNewShow() {
  const body = document.getElementById('det-body');
  if (!body) return;
  body.innerHTML = `
    <div style="font-size:12px;color:var(--ink3);margin-bottom:12px">A <code>.dinv</code> file will be created in the same folder as the current portfolio.</div>
    <div class="field"><label>Portfolio Name</label>
      <input id="port-new-name" type="text" placeholder="e.g. Super Fund" onkeydown="if(event.key==='Enter')_portNewCreate()">
    </div>
    <div id="port-new-err" style="color:var(--red);font-size:12px;margin-top:4px;display:none"></div>`;
  document.getElementById('det-foot').innerHTML =
    `<button class="btn btn-secondary" onclick="_portPanelRefresh()">Cancel</button>
     <button class="btn btn-primary" onclick="_portNewCreate()">Create Portfolio</button>`;
  document.getElementById('port-new-name').focus();
}

async function _portNewCreate() {
  const name  = document.getElementById('port-new-name')?.value.trim();
  const errEl = document.getElementById('port-new-err');
  if (!name) { errEl.textContent = 'Enter a portfolio name'; errEl.style.display = ''; return; }
  const btn = document.getElementById('det-foot').querySelector('.btn-primary');
  if (btn) { btn.disabled = true; btn.textContent = 'Creating…'; }
  try {
    const r = await fetch('/api/portfolio/new', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    document.getElementById('portfolio-name').textContent = r.data.name;
    await _loadAppSettings();
    _currentModule = null;
    navigate('dashboard');
    toast(`Created and switched to ${r.data.name}`);
  } catch (e) {
    if (errEl) { errEl.textContent = e.message; errEl.style.display = ''; }
    if (btn) { btn.disabled = false; btn.textContent = 'Create Portfolio'; }
  }
}

async function _portSwitchTo(path, btn) {
  if (btn) { btn.disabled = true; btn.textContent = 'Opening…'; }
  try {
    const r = await fetch('/api/portfolio/switch', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    document.getElementById('portfolio-name').textContent = r.data.name;
    await _loadAppSettings();
    _currentModule = null;
    navigate('dashboard');
    toast(`Switched to ${r.data.name}`);
    await _portPanelRefresh();
  } catch (e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Open'; }
  }
}

// ── Shutdown ──────────────────────────────────────────────────────────────────
async function _shutdown() {
  try { await fetch('/api/shutdown', { method: 'POST' }); } catch (_) {}
  document.body.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100vh;font-family:sans-serif;color:#666"><div style="text-align:center"><div style="font-size:48px;margin-bottom:16px">⏻</div><p>Server stopped.<br>You can close this window.</p></div></div>';
}

// ── Updates (same model as Dogbox Accounting — see web/updater.py) ──────────
let _updInfo = null;

async function _updCheck(force = false) {
  try {
    const d = await apiFetch('/api/system/version' + (force ? '?force=1' : ''));
    _updInfo = d;
    document.getElementById('app-version').textContent = 'v' + d.current;
    const el = document.getElementById('update-banner');
    if (!d.update_available) {
      el.style.display = 'none';
      if (force) toast(d.latest ? `You're up to date (v${d.current})` : "Couldn't check for updates — are you online?",
                       d.latest ? 'ok' : 'err');
      return;
    }
    el.innerHTML = `
      <span>↑</span>
      <span class="upd-msg">Dogbox Investments v${d.latest} is available.</span>
      ${d.notes ? `<button class="btn btn-ghost btn-sm" onclick="_updShowNotes()">What's new</button>` : ''}
      <button class="btn btn-primary btn-sm" onclick="_updApply()">Update</button>
      <span class="upd-close" title="Dismiss" onclick="document.getElementById('update-banner').style.display='none'">✕</span>`;
    el.style.display = '';
  } catch (_) {}
}

function _updNotesHtml(text) {
  const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const inline = s => s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/`([^`]+)`/g, '<code>$1</code>');
  return (text || '').split('\n').map(line => {
    if (/^#{2,3}\s/.test(line)) return `<h4>${inline(esc(line.replace(/^#+\s*/, '')))}</h4>`;
    if (/^[-*]\s/.test(line))   return `<div style="padding-left:14px">• ${inline(esc(line.replace(/^[-*]\s+/, '')))}</div>`;
    if (!line.trim())           return '<div style="height:6px"></div>';
    return `<div>${inline(esc(line))}</div>`;
  }).join('');
}

function _updShowNotes() {
  if (!_updInfo) return;
  openPanel(`What's new in v${_updInfo.latest}`,
    `<div class="upd-notes">${_updNotesHtml(_updInfo.notes) || '<em>No notes provided.</em>'}</div>`,
    `<button class="btn btn-ghost" onclick="closePanel()">Close</button>
     <button class="btn btn-primary" onclick="_updApply()">Update now</button>`);
}

async function _updApply() {
  openPanel('Updating Dogbox Investments', `
    <div id="upd-status" style="font-size:13px">Downloading…</div>
    <div class="upd-bar-track"><div class="upd-bar-fill" id="upd-bar"></div></div>
    <div style="font-size:11px;color:var(--ink3);margin-top:12px">Your portfolio files are not touched. The files being replaced are backed up in the app's <code>backups</code> folder.</div>`,
    '');
  try {
    const r = await fetch('/api/system/apply-update', { method: 'POST' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Update failed');
  } catch (e) {
    document.getElementById('upd-status').textContent = 'Update failed: ' + e.message;
    document.getElementById('det-foot').innerHTML = `<button class="btn btn-ghost" onclick="closePanel()">Close</button>`;
    return;
  }
  const poll = setInterval(async () => {
    try {
      const p = await apiFetch('/api/system/update-progress');
      document.getElementById('upd-bar').style.width = p.pct + '%';
      if (p.state === 'applying') {
        document.getElementById('upd-status').textContent = 'Applying update…';
      } else if (p.state === 'done') {
        clearInterval(poll);
        document.getElementById('upd-status').textContent = 'Update installed — restarting…';
        document.getElementById('update-banner').style.display = 'none';
        _updRestart();
      } else if (p.state === 'error') {
        clearInterval(poll);
        document.getElementById('upd-status').textContent = 'Update failed: ' + p.error + ' — nothing was changed.';
        document.getElementById('det-foot').innerHTML = `<button class="btn btn-ghost" onclick="closePanel()">Close</button>`;
      }
    } catch (_) {}
  }, 600);
}

async function _updRestart() {
  try { await fetch('/api/system/restart', { method: 'POST' }); } catch (_) {}
  // Wait for the old server to exit, then reload once the new one answers
  setTimeout(() => {
    const poll = setInterval(async () => {
      try {
        const r = await fetch('/api/alive', { cache: 'no-store' });
        if (r.ok) { clearInterval(poll); window.location.reload(); }
      } catch (_) {}
    }, 1500);
  }, 2500);
}

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  // Nav clicks
  document.querySelectorAll('.nav-item[data-module]').forEach(el => {
    el.addEventListener('click', () => navigate(el.dataset.module));
  });

  // Panel close
  document.getElementById('det-overlay').addEventListener('click', closePanel);
  document.getElementById('det-close').addEventListener('click', closePanel);

  // Portfolio name in footer
  try {
    const portfolios = await apiFetch('/api/portfolio/list');
    const active = portfolios.find(p => p.active);
    if (active) document.getElementById('portfolio-name').textContent = active.name;
  } catch (e) {}

  // Load settings into global cache
  await _loadAppSettings();

  // Land on dashboard
  navigate('dashboard');

  // Version label + update check (daily, cached server-side)
  _updCheck();
});
