// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — core utilities and navigation */

// ── API fetch ─────────────────────────────────────────────────────────────────
async function apiFetch(url, opts = {}) {
  const r = await fetch(url, opts);
  const j = await r.json();
  if (!j.ok) throw new Error(j.error || 'Request failed');
  return j.data;
}

// ── Toast ─────────────────────────────────────────────────────────────────────
function toast(msg, type = 'ok') {
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.textContent = msg;
  document.body.appendChild(t);
  requestAnimationFrame(() => t.classList.add('show'));
  setTimeout(() => {
    t.classList.remove('show');
    setTimeout(() => t.remove(), 300);
  }, 3200);
}

// ── Date / number formatting ──────────────────────────────────────────────────
function fmtDate(iso) {
  if (!iso) return '—';
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
}

function fmtCurrency(n, decimals = 2) {
  if (n == null) return '—';
  const v = parseFloat(n);
  if (isNaN(v)) return '—';
  const abs = Math.abs(v).toLocaleString('en-AU', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
  return (v < 0 ? '-' : '') + '$' + abs;
}

function fmtNum(n, decimals = 4) {
  if (n == null) return '—';
  const v = parseFloat(n);
  if (isNaN(v)) return '—';
  return v.toLocaleString('en-AU', {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals,
  });
}

function gainClass(n) {
  const v = parseFloat(n);
  if (v > 0) return 'gain';
  if (v < 0) return 'loss';
  return 'flat';
}

function _isLocked(dateStr) {
  if (!dateStr || !_appSettings?.locked_fy) return false;
  const lockedFy = parseInt(_appSettings.locked_fy);
  if (!lockedFy) return false;
  const d = new Date(dateStr + 'T00:00:00');
  const fy = (d.getMonth() + 1) >= 7 ? d.getFullYear() + 1 : d.getFullYear();
  return fy <= lockedFy;
}

// ── Module loader ─────────────────────────────────────────────────────────────
const _loadedModules = new Set();

async function loadModule(name) {
  if (_loadedModules.has(name)) return;
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = `/static/js/${name}.js`;
    s.onload = () => { _loadedModules.add(name); resolve(); };
    s.onerror = reject;
    document.head.appendChild(s);
  });
}

// ── Navigation ────────────────────────────────────────────────────────────────
const _moduleMap = {
  dashboard:       { js: 'dashboard',       fn: 'pageDashboard' },
  portfolio:       { js: 'portfolio',       fn: 'pagePortfolio' },
  transactions:    { js: 'transactions',    fn: 'pageTransactions' },
  dividends:       { js: 'dividends',       fn: 'pageDividends' },
  cgt:             { js: 'cgt',             fn: 'pageCgt' },
  tax_summary:     { js: 'tax_summary',     fn: 'pageTaxSummary' },
  actions:         { js: 'actions',         fn: 'pageActions' },
  securities:      { js: 'securities',      fn: 'pageSecurities' },
  import_data:     { js: 'import_data',     fn: 'pageImportData' },
  settings:        { js: 'settings_mod',    fn: 'pageSettings' },
  security_detail:  { js: 'security_detail',   fn: null },
  cost_base_recon:  { js: 'cost_base_recon',   fn: 'pageCostBaseRecon' },
  watchlist:        { js: 'watchlist',          fn: 'pageWatchlist' },
};

let _currentModule = null;

async function navigate(module) {
  if (module === _currentModule) return;
  _currentModule = module;

  // Update active nav item
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.module === module);
  });

  // Update page title
  const titles = {
    dashboard: 'Dashboard', portfolio: 'Portfolio', transactions: 'Transactions',
    dividends: 'Dividends', cgt: 'CGT Detail', tax_summary: 'FY Tax Summary',
    cost_base_recon: 'Cost Base Reconciliation',
    watchlist: 'Watch List',
    actions: 'Corporate Actions',
    securities: 'Securities', import_data: 'Import / Export', settings: 'Settings',
  };
  document.getElementById('page-title').textContent = titles[module] || module;

  const content = document.getElementById('module-content');
  content.innerHTML = '<div class="st-empty"><div class="st-empty-icon">⏳</div>Loading…</div>';

  const def = _moduleMap[module];
  if (!def) {
    content.innerHTML = '<div class="st-empty"><div class="st-empty-title">Module not found</div></div>';
    return;
  }

  try {
    await loadModule(def.js);
    if (def.fn) window[def.fn]();
  } catch (e) {
    content.innerHTML = `<div class="st-empty"><div class="st-empty-title">Error loading module</div><div>${e.message}</div></div>`;
  }
}

// ── Slide-over helpers ────────────────────────────────────────────────────────
function openPanel(titleText, bodyHtml, footHtml) {
  document.getElementById('det-title').textContent = titleText;
  document.getElementById('det-body').innerHTML = bodyHtml;
  document.getElementById('det-foot').innerHTML = footHtml;
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
}

function closePanel() {
  document.getElementById('det-overlay').classList.remove('open');
  document.getElementById('det-panel').classList.remove('open');
}

// ── App-wide settings cache ───────────────────────────────────────────────────
let _appSettings = {};

async function _loadAppSettings() {
  try { _appSettings = await apiFetch('/api/settings'); } catch (e) {}
}

// ── Portfolio switcher ────────────────────────────────────────────────────────
async function _portSwitchOpen() {
  openPanel('Portfolios', '<div style="color:var(--ink3);font-size:12px;padding:8px 0">Loading…</div>',
    `<button class="btn btn-secondary" onclick="_portNewShow()">+ New Portfolio</button>
     <button class="btn btn-ghost" onclick="closePanel()">Close</button>`);
  await _portPanelRefresh();
}

async function _portPanelRefresh() {
  const body = document.getElementById('det-body');
  if (!body) return;
  try {
    const portfolios = await apiFetch('/api/portfolio/list');
    if (!portfolios.length) {
      body.innerHTML = `<div style="color:var(--ink3);font-size:12px;padding:8px 0">No portfolio files found.</div>`;
      return;
    }
    body.innerHTML = portfolios.map(p => {
      const safePath = p.path.replace(/\\/g, '/').replace(/'/g, "\\'");
      return `<div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--border)">
        <div style="flex:1;min-width:0">
          <div style="font-weight:600;font-size:13px;color:var(--ink)">${p.name}</div>
          <div style="font-size:10px;color:var(--ink3);font-family:'DM Mono',monospace;margin-top:2px;word-break:break-all">${p.path}</div>
        </div>
        ${p.active
          ? '<span class="badge badge-accent">Active</span>'
          : `<button class="btn btn-secondary btn-sm" onclick="_portSwitchTo('${safePath}',this)">Open</button>`}
      </div>`;
    }).join('');
  } catch (e) {
    body.innerHTML = `<div style="color:var(--red);font-size:12px">${e.message}</div>`;
  }
}

function _portNewShow() {
  const body = document.getElementById('det-body');
  if (!body) return;
  body.innerHTML = `
    <div style="font-size:12px;color:var(--ink3);margin-bottom:12px">A <code>.dinv</code> file will be created in the same folder as the current portfolio.</div>
    <div class="field"><label>Portfolio Name</label>
      <input id="port-new-name" type="text" placeholder="e.g. Super Fund" onkeydown="if(event.key==='Enter')_portNewCreate()">
    </div>
    <div id="port-new-err" style="color:var(--red);font-size:12px;margin-top:4px;display:none"></div>`;
  document.getElementById('det-foot').innerHTML =
    `<button class="btn btn-secondary" onclick="_portPanelRefresh()">Cancel</button>
     <button class="btn btn-primary" onclick="_portNewCreate()">Create Portfolio</button>`;
  document.getElementById('port-new-name').focus();
}

async function _portNewCreate() {
  const name  = document.getElementById('port-new-name')?.value.trim();
  const errEl = document.getElementById('port-new-err');
  if (!name) { errEl.textContent = 'Enter a portfolio name'; errEl.style.display = ''; return; }
  const btn = document.getElementById('det-foot').querySelector('.btn-primary');
  if (btn) { btn.disabled = true; btn.textContent = 'Creating…'; }
  try {
    const r = await fetch('/api/portfolio/new', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    document.getElementById('portfolio-name').textContent = r.data.name;
    await _loadAppSettings();
    _currentModule = null;
    navigate('dashboard');
    toast(`Created and switched to ${r.data.name}`);
  } catch (e) {
    if (errEl) { errEl.textContent = e.message; errEl.style.display = ''; }
    if (btn) { btn.disabled = false; btn.textContent = 'Create Portfolio'; }
  }
}

async function _portSwitchTo(path, btn) {
  if (btn) { btn.disabled = true; btn.textContent = 'Opening…'; }
  try {
    const r = await fetch('/api/portfolio/switch', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    document.getElementById('portfolio-name').textContent = r.data.name;
    await _loadAppSettings();
    _currentModule = null;
    navigate('dashboard');
    toast(`Switched to ${r.data.name}`);
    await _portPanelRefresh();
  } catch (e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Open'; }
  }
}

// ── Shutdown ──────────────────────────────────────────────────────────────────
async function _shutdown() {
  try { await fetch('/api/shutdown', { method: 'POST' }); } catch (_) {}
  document.body.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100vh;font-family:sans-serif;color:#666"><div style="text-align:center"><div style="font-size:48px;margin-bottom:16px">⏻</div><p>Server stopped.<br>You can close this window.</p></div></div>';
}

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  // Nav clicks
  document.querySelectorAll('.nav-item[data-module]').forEach(el => {
    el.addEventListener('click', () => navigate(el.dataset.module));
  });

  // Panel close
  document.getElementById('det-overlay').addEventListener('click', closePanel);
  document.getElementById('det-close').addEventListener('click', closePanel);

  // Portfolio name in footer
  try {
    const portfolios = await apiFetch('/api/portfolio/list');
    const active = portfolios.find(p => p.active);
    if (active) document.getElementById('portfolio-name').textContent = active.name;
  } catch (e) {}

  // Load settings into global cache
  await _loadAppSettings();

  // Land on dashboard
  navigate('dashboard');
});
