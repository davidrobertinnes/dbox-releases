// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — Per-security detail view */

let _sd = {
  security:     null,
  parcels:      [],
  sales:        [],
  divs:         [],
  actions:      [],
  price:        null,
  back:         'portfolio',
  watchlistItem: null,
};

// ── Entry point ────────────────────────────────────────────────────────────────

async function viewSecurity(securityId, backModule = 'portfolio') {
  _sd.back = backModule;
  _currentModule = 'security_detail';
  document.getElementById('module-content').innerHTML =
    '<div class="st-empty"><div class="st-empty-icon">⏳</div>Loading…</div>';
  await _sdFetch(securityId);
  _sdRender();
}

async function _sdFetch(securityId) {
  const [securities, parcels, sales, divs, actions, prices, watchlist] = await Promise.all([
    apiFetch('/api/securities'),
    apiFetch(`/api/parcels?security_id=${securityId}`),
    apiFetch(`/api/sales?security_id=${securityId}`),
    apiFetch(`/api/dividends?security_id=${securityId}`),
    apiFetch(`/api/actions?security_id=${securityId}`),
    apiFetch('/api/prices'),
    apiFetch('/api/watchlist'),
  ]);
  _sd.security      = securities.find(s => s.id === securityId) || { id: securityId, code: '?', name: 'Unknown' };
  _sd.parcels       = parcels;
  _sd.sales         = sales;
  _sd.divs          = divs;
  _sd.actions       = actions;
  _sd.price         = prices[securityId]?.price ?? null;
  _sd.watchlistItem = watchlist.find(w => w.security_id === securityId) || null;
}

function _sdLoadChart(securityId) {
  const el = document.getElementById('sd-chart');
  if (!el) return;
  apiFetch(`/api/prices/history?security_id=${securityId}`)
    .then(data => { el.innerHTML = _sdDrawChart(data); })
    .catch(() => { el.innerHTML = ''; });
}

function _sdDrawChart(data) {
  if (!data || data.length < 5) return '';
  const prices = data.map(d => d.price);
  const W = 520, H = 72, pad = { t:8, b:18, l:4, r:4 };
  const iw = W - pad.l - pad.r, ih = H - pad.t - pad.b;
  const min = Math.min(...prices), max = Math.max(...prices);
  const range = max - min || 1;
  const n = prices.length;
  const pts = prices.map((p, i) => [
    pad.l + (i / (n - 1)) * iw,
    pad.t + ih - ((p - min) / range) * ih,
  ]);
  const isUp = prices[n-1] >= prices[0];
  const col  = isUp ? 'var(--green)' : 'var(--red)';
  const line = pts.map(([x,y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  const area = [
    `${pts[0][0].toFixed(1)},${(pad.t+ih).toFixed(1)}`,
    ...pts.map(([x,y]) => `${x.toFixed(1)},${y.toFixed(1)}`),
    `${pts[n-1][0].toFixed(1)},${(pad.t+ih).toFixed(1)}`,
  ].join(' ');
  const uid = `cg${Date.now()}`;
  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:${H}px;display:block">
    <defs>
      <linearGradient id="${uid}" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${col}" stop-opacity="0.18"/>
        <stop offset="100%" stop-color="${col}" stop-opacity="0"/>
      </linearGradient>
    </defs>
    <polygon points="${area}" fill="url(#${uid})"/>
    <polyline points="${line}" fill="none" stroke="${col}" stroke-width="1.5"/>
    <text x="${pad.l+1}" y="${H-3}" font-size="9" fill="var(--ink3)" font-family="'DM Mono',monospace">${fmtCurrency(prices[0])}</text>
    <text x="${W-pad.r-1}" y="${H-3}" text-anchor="end" font-size="9" fill="var(--ink3)" font-family="'DM Mono',monospace">${fmtCurrency(prices[n-1])}</text>
    <text x="${W/2}" y="${H-3}" text-anchor="middle" font-size="9" fill="var(--ink3)" font-family="'DM Mono',monospace">6 months</text>
  </svg>`;
}

async function _sdRefresh() {
  await _sdFetch(_sd.security.id);
  _sdRender();
}

// ── Main render ────────────────────────────────────────────────────────────────

function _sdRender() {
  const sec = _sd.security;
  const openParcels  = _sd.parcels.filter(p => p.quantity_remaining > 1e-9);
  const totalQty     = openParcels.reduce((s, p) => s + p.quantity_remaining, 0);
  const totalCB      = openParcels.reduce((s, p) => s + p.cost_base * (p.quantity_remaining / p.quantity), 0);
  const avgCost      = totalQty > 0 ? totalCB / totalQty : 0;
  const divIncome    = _sd.divs.reduce((s, d) => s + (d.net_amount || 0), 0);
  const saleProceeds = _sd.sales.reduce((s, sa) => s + (sa.net_proceeds || 0), 0);
  const typeLabel    = { share:'Share', etf:'ETF', lpt:'LPT/REIT', bond:'Bond', preference:'Preference Share', other:'Other' };

  const currentPrice = _sd.price;
  const mktVal       = currentPrice !== null && totalQty > 0 ? currentPrice * totalQty : null;
  const unrealisedPnl = mktVal !== null ? mktVal - totalCB : null;
  const oneYearAgo   = new Date(); oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
  const annualDPS    = _sd.divs
    .filter(d => new Date(d.payment_date) >= oneYearAgo)
    .reduce((s, d) => s + (d.amount_per_share || 0), 0);
  const yieldPct     = currentPrice > 0 && annualDPS > 0 ? annualDPS / currentPrice * 100 : null;

  document.getElementById('module-content').innerHTML = `
    <div style="margin-bottom:16px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <button class="btn btn-ghost btn-sm" onclick="navigate('${_sd.back}')">&larr; Back</button>
        ${_sd.watchlistItem
          ? `<button class="btn btn-ghost btn-sm" style="color:var(--ink3)" onclick="_sdToggleWatch()" id="sd-watch-btn">👁 Watching</button>`
          : `<button class="btn btn-ghost btn-sm" onclick="_sdToggleWatch()" id="sd-watch-btn">+ Watch</button>`}
      </div>
      <div style="display:flex;align-items:baseline;gap:12px;flex-wrap:wrap">
        <span style="font-family:'Syne',sans-serif;font-size:24px;font-weight:800;letter-spacing:-0.5px;color:var(--accent)">${sec.code}</span>
        <span style="font-size:16px;font-weight:600;color:var(--ink)">${sec.name}</span>
        <span style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3)">${sec.exchange} &middot; ${typeLabel[sec.security_type] || sec.security_type} &middot; ${sec.currency}${sec.is_foreign ? ` &middot; Foreign company${sec.treaty_rate != null ? ` (treaty ${fmtNum(sec.treaty_rate, 2)}%)` : ''}` : ''}</span>
      </div>
    </div>

    <div class="st-kpi-strip">
      <div class="st-kpi">
        <div class="st-kpi-label">Qty Held</div>
        <div class="st-kpi-value col-ink">${totalQty > 0 ? fmtNum(totalQty, 4) : '—'}</div>
        <div class="st-kpi-sub">${openParcels.length} open parcel${openParcels.length !== 1 ? 's' : ''}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Avg Cost</div>
        <div class="st-kpi-value col-ink">${totalQty > 0 ? fmtCurrency(avgCost) : '—'}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Total Cost Base</div>
        <div class="st-kpi-value col-ink">${totalQty > 0 ? fmtCurrency(totalCB) : '—'}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Dividend Income</div>
        <div class="st-kpi-value col-green">${fmtCurrency(divIncome)}</div>
        <div class="st-kpi-sub">${_sd.divs.length} payment${_sd.divs.length !== 1 ? 's' : ''}</div>
      </div>
      ${_sd.sales.length ? `
      <div class="st-kpi">
        <div class="st-kpi-label">Sale Proceeds</div>
        <div class="st-kpi-value col-amber">${fmtCurrency(saleProceeds)}</div>
        <div class="st-kpi-sub">${_sd.sales.length} disposal${_sd.sales.length !== 1 ? 's' : ''}</div>
      </div>` : ''}
      ${currentPrice !== null ? `
      <div class="st-kpi">
        <div class="st-kpi-label">Current Price</div>
        <div class="st-kpi-value col-ink">${fmtCurrency(currentPrice)}</div>
        ${yieldPct !== null ? `<div class="st-kpi-sub">${yieldPct.toFixed(2)}% trailing yield</div>` : ''}
      </div>` : ''}
      ${mktVal !== null ? `
      <div class="st-kpi">
        <div class="st-kpi-label">Market Value</div>
        <div class="st-kpi-value col-ink">${fmtCurrency(mktVal)}</div>
        <div class="st-kpi-sub ${gainClass(unrealisedPnl)}">${unrealisedPnl >= 0 ? '+' : ''}${fmtCurrency(unrealisedPnl)} P&amp;L</div>
      </div>` : ''}
    </div>

    <div id="sd-chart" style="margin:8px 0 16px;border-radius:8px;overflow:hidden"></div>

    ${_sdParcelsSection()}
    ${_sdSalesSection()}
    ${_sdDivsSection()}
    ${_sdActionsSection()}`;

  _sdLoadChart(_sd.security.id);
}

// ── Parcels section ────────────────────────────────────────────────────────────

function _sdParcelsSection() {
  const rows = _sd.parcels.length ? _sd.parcels.map(p => {
    const pctSold = p.quantity - p.quantity_remaining;
    const status = p.quantity_remaining <= 0
      ? '<span class="badge badge-red">Closed</span>'
      : pctSold > 0
        ? '<span class="badge badge-amber">Partial</span>'
        : '<span class="badge badge-green">Open</span>';
    const locked = pctSold > 0
      ? 'title="Partially sold — quantity locked"' : '';
    const qtyTitle = p.unit_changes && p.unit_changes.length
      ? `title="${fmtNum(p.entered_quantity, 4)} on the contract note"` : '';
    return `<tr>
      <td class="mono">${fmtDate(p.acquisition_date)}</td>
      <td style="font-size:12px">${_sdEsc(p.label || '')}${p.holding_code ? ` <span class="badge badge-ink" title="Holding">${_sdEsc(p.holding_code)}</span>` : ''}${_sdParcelBadges(p)}</td>
      <td class="num mono" ${qtyTitle}>${fmtNum(p.quantity, 4)}</td>
      <td class="num mono">${fmtCurrency(p.price_per_unit)}</td>
      <td class="num mono">${fmtCurrency(p.brokerage)}</td>
      <td class="num mono">${fmtCurrency(p.cost_base)}</td>
      <td class="num mono">${fmtNum(p.quantity_remaining, 4)}</td>
      <td>${status}</td>
      <td class="row-actions"><button class="btn btn-ghost btn-sm" onclick="_sdOpenHistory(${p.id})"
          title="How this parcel's cost base changed, event by event">History</button>${
        _sdParcelCanIndex(p) && !p.demerged
          ? `<button class="btn btn-ghost btn-sm" onclick="_sdOpenMethod(${p.id})"
               title="CGT discount or indexation for this parcel">Method</button>` : ''}${
        attBtn('parcel', p, `${_sd.security.code} purchase ${fmtDate(p.acquisition_date)}`)}${
        _isLocked(p.acquisition_date)
          ? '<span class="badge badge-amber" title="FY locked — cannot modify after lodgement">Locked</span>'
          : `<button class="btn btn-ghost btn-sm" onclick="_sdEditParcel(${p.id})">Edit</button>
             <button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="_sdDeleteParcel(${p.id})">Del</button>`
      }</td>
    </tr>`;
  }).join('') : `<tr><td colspan="9" style="text-align:center;padding:24px;color:var(--ink3);font-size:12px">No purchases recorded</td></tr>`;

  return `
    <div class="st-section">
      <div class="st-section-title">Parcels</div>
      <div class="st-section-line"></div>
      <button class="btn btn-secondary btn-sm" onclick="_sdOpenBuy()">+ Buy</button>
      <button class="btn btn-ghost btn-sm" onclick="_sdOpenInherit()" style="margin-left:6px"
        title="Shares inherited from a deceased estate">+ Inherited</button>
      <button class="btn btn-ghost btn-sm" onclick="_sdOpenEmployee()" style="margin-left:6px"
        title="Shares from an employee share plan">+ Employee Shares</button>
    </div>
    <div class="st-list-panel" style="margin-bottom:20px">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Acquired</th><th>Label</th><th class="num" title="Today's units">Qty</th><th class="num">Price</th>
            <th class="num">Brokerage</th><th class="num">Cost Base</th>
            <th class="num">Remaining</th><th>Status</th><th></th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>`;
}

// ── Sales section ──────────────────────────────────────────────────────────────

function _sdSalesSection() {
  const rows = _sd.sales.length ? _sd.sales.map(s => `<tr>
    <td class="mono">${fmtDate(s.sale_date)}</td>
    <td class="num mono">${fmtNum(s.quantity, 4)}</td>
    <td class="num mono">${fmtCurrency(s.price_per_unit)}</td>
    <td class="num mono">${fmtCurrency(s.brokerage)}</td>
    <td class="num mono">${fmtCurrency(s.net_proceeds)}</td>
    <td style="font-size:12px;color:var(--ink3)">${s.kind === 'cancellation' ? '<span class="badge badge-ink" title="Share cancellation — CGT event C2">Cancellation</span> ' : s.kind === 'takeover' ? '<span class="badge badge-ink" title="Takeover — change or delete it under Corporate Actions">Takeover</span> ' : s.kind === 'transfer' ? '<span class="badge badge-ink" title="Pre-CGT shares split at a joint holder&#39;s death — not a CGT event">Joint holder died</span> ' : ''}${s.holding_code ? `<span class="badge badge-ink" title="Holding">${_sdEsc(s.holding_code)}</span> ` : ''}${s.notes || ''}</td>
    <td class="row-actions">${attBtn('sale', s, `${_sd.security.code} sale ${fmtDate(s.sale_date)}`)}${
      _isLocked(s.sale_date)
        ? '<span class="badge badge-amber" title="FY locked — cannot modify after lodgement">Locked</span>'
        : `<button class="btn btn-ghost btn-sm" onclick="_sdEditSale(${s.id})">Edit</button>
           <button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="_sdDeleteSale(${s.id})">Del</button>`
    }</td>
  </tr>`).join('') : `<tr><td colspan="7" style="text-align:center;padding:24px;color:var(--ink3);font-size:12px">No sales recorded</td></tr>`;

  return `
    <div class="st-section">
      <div class="st-section-title">Sales</div>
      <div class="st-section-line"></div>
      <button class="btn btn-secondary btn-sm" onclick="_sdOpenSell()">Record Sale</button>
      <button class="btn btn-ghost btn-sm" onclick="_sdEstimateSale()" style="margin-left:6px">Estimate Sale</button>
    </div>
    <div class="st-list-panel" style="margin-bottom:20px">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Date</th><th class="num">Qty</th><th class="num">Price</th>
            <th class="num">Brokerage</th><th class="num">Net Proceeds</th><th>Notes</th><th></th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>`;
}

// ── Dividends section ──────────────────────────────────────────────────────────

function _sd45Badge(d) {
  if (!d.franking_credit) return '';
  const est = div45Note(d);
  if (d.eligible_45day === true)  return `<span class="badge badge-green" title="45-day rule satisfied${est}">✓</span>`;
  if (d.eligible_45day === false) return `<span class="badge badge-red"   title="45-day rule not satisfied — credit not claimable${est}">✗</span>`;
  return '<span class="badge badge-amber" title="Add ex-dividend date to verify 45-day eligibility">?</span>';
}

function _sdDivsSection() {
  const rows = _sd.divs.length ? _sd.divs.map(d => `<tr>
    <td class="mono">${fmtDate(d.payment_date)}</td>
    <td class="num mono">${fmtNum(d.quantity_held, 4)}</td>
    <td class="num mono">${fmtCurrency(d.amount_per_share, 4)}</td>
    <td class="num mono">${fmtCurrency(d.gross_amount)}</td>
    <td class="num mono">${fmtPct(d.franking_pct)}</td>
    <td class="num mono">${d.franking_credit ? fmtCurrency(d.franking_credit) : '—'}</td>
    <td>${_sd45Badge(d)}</td>
    <td class="num mono">${divWithheldCell(d)}</td>
    <td class="num mono">${fmtCurrency(d.net_amount)}</td>
    <td>${d.is_drp ? '<span class="badge badge-accent">DRP</span>' : '—'}</td>
    <td class="row-actions">${attBtn('dividend', d, `${_sd.security.code} dividend ${fmtDate(d.payment_date)}`)}${
      _isLocked(d.payment_date)
        ? '<span class="badge badge-amber" title="FY locked — cannot modify after lodgement">Locked</span>'
        : `<button class="btn btn-ghost btn-sm" onclick="_sdEditDiv(${d.id})">Edit</button>
           <button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="_sdDeleteDiv(${d.id})">Del</button>`
    }</td>
  </tr>`).join('') : `<tr><td colspan="11" style="text-align:center;padding:24px;color:var(--ink3);font-size:12px">No dividends recorded</td></tr>`;

  return `
    <div class="st-section">
      <div class="st-section-title">Dividends</div>
      <div class="st-section-line"></div>
      <button class="btn btn-secondary btn-sm" onclick="_sdOpenDiv()">+ Dividend</button>
    </div>
    <div class="st-list-panel">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Date</th><th class="num">Qty Held</th><th class="num">Per Share</th>
            <th class="num">Gross</th><th class="num">Franking %</th>
            <th class="num">Franking Cr.</th>
            <th title="45-day holding period rule">45d</th>
            <th class="num" title="Tax withheld (foreign tax, or no-TFN withholding)">Tax W/H</th>
            <th class="num">Net</th><th>DRP</th><th></th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>`;
}

// ── Buy form ───────────────────────────────────────────────────────────────────

// ── Cost base history of a parcel ────────────────────────────────────────────
// The parcel's events (from /api/parcels/<id>/history), preceded by the history of the
// parcel it came from (takeover/redomicile roll-over, demerger, joint holder's death).
async function _sdOpenHistory(id, asAt) {
  let h;
  try {
    h = await apiFetch(`/api/parcels/${id}/history${asAt ? `?as_at=${asAt}` : ''}`);
  } catch (e) {
    return toast(e.message, 'err');
  }
  const chain = [];
  for (let x = h; x; x = x.earlier) chain.unshift(x);
  const part = (x, i) => {
    const last = i === chain.length - 1;
    const rows = x.events.map(e => `<tr>
        <td class="mono" style="white-space:nowrap">${fmtDate(e.date)}</td>
        <td style="font-size:12px">${_sdEsc(e.event)}</td>
        <td class="num mono">${fmtNum(e.units, 4)}</td>
        <td class="num mono">${fmtCurrency(e.per_unit, 4)}</td>
        <td class="num mono">${fmtCurrency(e.cost_base)}</td>
      </tr>`).join('');
    return `
      <div style="font-size:12px;font-weight:600;color:var(--ink);margin:${i ? 18 : 0}px 0 6px">
        ${last ? 'This parcel' : 'Earlier'}: ${_sdEsc(x.code)} — ${_sdEsc(x.acquired_how)}, ${fmtDate(x.acquired)}${x.cgt_acquired !== x.acquired
          ? ` <span style="font-weight:400;color:var(--ink3)">(acquired ${fmtDate(x.cgt_acquired)} for CGT)</span>` : ''}
        ${x.code_now !== x.code ? `<span style="font-weight:400;color:var(--ink3)">(now ${_sdEsc(x.code_now)})</span>` : ''}
      </div>
      <div class="tbl-overflow"><table class="st-table">
        <thead><tr><th>Date</th><th>Event</th><th class="num" title="Units held after the event, as at that date">Units</th>
          <th class="num">Per share</th><th class="num">Cost base</th></tr></thead>
        <tbody>${rows || `<tr><td colspan="5" style="text-align:center;color:var(--ink3);font-size:12px">Not yet acquired on this date</td></tr>`}</tbody>
      </table></div>`;
  };
  document.getElementById('det-panel').classList.add('wide');
  openPanel('Cost Base History', `
    <div style="font-size:12px;color:var(--ink2);line-height:1.6;margin-bottom:12px">
      How the parcel's cost base changed with each event. Units and per-share figures are as at the
      event, before any later splits or consolidations. Cost base is for the units still held.
      ${chain.length > 1 ? 'The parcel came from an earlier one, shown first.' : ''}
    </div>
    <div class="field" style="max-width:200px"><label>As at</label>
      <input type="date" id="sd-hist-asat" value="${asAt || ''}" onchange="_sdHistAsAtChanged(${id}, this.value)"></div>
    ${chain.map(part).join('')}`,
    `<button class="btn btn-secondary" onclick="closePanel()">Close</button>`);
}

// A typed date is "changed" as soon as the year's first digit makes it valid (year 0002), and
// reopening the history rebuilds the field mid-typing, so wait until the year is a real one.
function _sdHistAsAtChanged(id, value) {
  if (value && Number(value.slice(0, 4)) < 1900) return;
  _sdOpenHistory(id, value);
}

function _sdEsc(t) {
  return String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

function _sdParcelBadges(p) {
  let b = '';
  if (p.origin === 'inherited') b += ' <span class="badge badge-accent" title="Inherited shares">Inherited</span>';
  if (p.origin === 'employee') {
    const today = new Date().toISOString().slice(0, 10);
    const restricted = p.restricted_until && today < p.restricted_until;
    b += ` <span class="badge ${restricted ? 'badge-amber' : 'badge-accent'}" style="cursor:pointer"
      onclick="_sdOpenRestriction(${p.id})" title="Employee share plan shares${p.restricted_until
        ? ` — restricted until ${fmtDate(p.restricted_until)}` : ''}. Click to change the restriction date"
      >${restricted ? `Restricted until ${fmtDate(p.restricted_until)}` : 'Employee'}</span>`;
  }
  if (p.pre_cgt) b += ' <span class="badge badge-ink" title="Acquired before 20 September 1985 — exempt from CGT">Pre-CGT</span>';
  const method = p.cgt_fixed || p.cgt_choice;
  if (method && _sdParcelCanIndex(p)) {
    const why = p.cgt_fixed ? `Fixed by the return of capital on ${fmtDate(p.cgt_fixed_date)}` : 'Chosen for this parcel';
    b += ` <span class="badge badge-ink" title="${why}">${method === 'indexation' ? 'Indexation' : 'Discount'}</span>`;
  }
  return b;
}

// Discount or indexation can apply: acquired from 20 Sep 1985 and before 21 Sep 1999
function _sdParcelCanIndex(p) {
  return !p.pre_cgt && p.cgt_acquired < '1999-09-21';
}

function _sdOpenMethod(id) {
  const p = _sd.parcels.find(x => x.id === id) || {};
  const fixed = p.cgt_fixed
    ? `<div style="font-size:12px;color:var(--ink2);line-height:1.6;margin-bottom:14px">
         The return of capital on ${fmtDate(p.cgt_fixed_date)} made a capital gain using
         <strong>${p.cgt_fixed === 'indexation' ? 'indexation' : 'the CGT discount'}</strong>, so later sales of
         this parcel must use the same method. Changing the choice below re-works that return of capital too.</div>`
    : '';
  openPanel('Capital Gain Method', `
    <div style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3);margin-bottom:14px">
      ${_sd.security.code} — parcel acquired ${fmtDate(p.cgt_acquired)}
    </div>
    <div style="font-size:12px;color:var(--ink2);line-height:1.6;margin-bottom:14px">
      Shares acquired before 21 September 1999 can use the CGT discount or indexation (cost base indexed to
      September 1999, no discount). This choice is used for the parcel's returns of capital, and for its sales
      that don't make their own choice. Once a return of capital makes a gain with one method, the ATO
      requires the same method for every later event on these shares.
    </div>
    ${fixed}
    <div class="field"><label>Method for this parcel</label>
      <select id="sd-method-choice">
        <option value="" ${!p.cgt_choice ? 'selected' : ''}>Portfolio default (Settings)</option>
        <option value="discount" ${p.cgt_choice === 'discount' ? 'selected' : ''}>CGT discount</option>
        <option value="indexation" ${p.cgt_choice === 'indexation' ? 'selected' : ''}>Indexation</option>
      </select></div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_sdSaveMethod(${id})">Save</button>`);
}

async function _sdSaveMethod(id) {
  const cgt_choice = document.getElementById('sd-method-choice').value || null;
  try {
    const r = await fetch(`/api/parcels/${id}/cgt-choice`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cgt_choice }) }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    toast('Method saved');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

function _sdUnitChangesNote(p) { return unitChangesNote(p); }

function _sdBuyTotalChanged(from) {
  // Price and total cost (excluding brokerage) fill each other in; the one typed last is kept
  const q = parseFloat(document.getElementById('sd-buy-qty').value);
  const price = document.getElementById('sd-buy-price');
  const total = document.getElementById('sd-buy-total');
  if (!q) return;
  if (from === 'total' && total.value) price.value = +(parseFloat(total.value) / q).toFixed(10);
  if (from === 'price' && price.value) total.value = +(parseFloat(price.value) * q).toFixed(2);
  total.dataset.typed = from === 'total' ? '1' : '';
}

function _sdOpenBuy(p = {}) {
  const isEdit = !!p.id;
  const qtyLocked = isEdit && (p.quantity - p.quantity_remaining) > 0;
  const defBrok = p.brokerage != null ? p.brokerage : ((_appSettings && _appSettings.default_brokerage) || '');
  const qty = isEdit ? p.entered_quantity : '';
  const price = isEdit ? p.entered_price : '';
  const total = isEdit ? (p.entered_total != null ? p.entered_total
                                                  : +(p.entered_quantity * p.entered_price).toFixed(2)) : '';
  openPanel(isEdit ? 'Edit Purchase' : 'Record Purchase', `
    <div style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3);margin-bottom:14px">
      ${_sd.security.code} — ${_sd.security.name}
    </div>
    ${isEdit ? _sdUnitChangesNote(p) : ''}
    <div class="field-row cols-2">
      <div class="field"><label>Acquisition Date</label>
        <input type="date" id="sd-buy-date" value="${p.acquisition_date || new Date().toISOString().slice(0,10)}">
      </div>
      <div class="field"><label>Quantity</label>
        <input type="number" id="sd-buy-qty" min="0" step="any" value="${qty}" placeholder="0"
          oninput="_sdBuyTotalChanged(document.getElementById('sd-buy-total').dataset.typed ? 'total' : 'price')"
          ${qtyLocked ? 'readonly style="background:var(--row-alt)" title="Partially sold — locked"' : ''}>
      </div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Price Per Unit ($)</label>
        <input type="number" id="sd-buy-price" min="0" step="any" value="${price}" placeholder="0.00"
          oninput="_sdBuyTotalChanged('price')">
      </div>
      <div class="field"><label title="Excluding brokerage">Or Total Cost ($)</label>
        <input type="number" id="sd-buy-total" min="0" step="any" value="${total}" placeholder="0.00"
          data-typed="${p.entered_total != null ? '1' : ''}" oninput="_sdBuyTotalChanged('total')">
      </div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Brokerage ($)</label>
        <input type="number" id="sd-buy-brok" min="0" step="any" value="${defBrok}" placeholder="0.00">
      </div>
      <div class="field"><label>Other Costs ($)</label>
        <input type="number" id="sd-buy-other" min="0" step="any" value="${p.other_costs || ''}" placeholder="0.00">
      </div>
    </div>
    <div class="field"><label>Label</label>
      <input type="text" id="sd-buy-label" value="${_sdEsc(p.label || '')}" placeholder="Optional — e.g. amp, drp22">
    </div>
    ${isEdit ? (p.holding_code ? `<div style="font-size:11px;color:var(--ink3);margin:-6px 0 12px">Holding: ${p.holding_code} (move shares under Settings → Holdings)</div>` : '') : holdingField('sd-buy-holding')}
    <div class="field"><label>Notes</label>
      <textarea id="sd-buy-notes" placeholder="Optional">${p.notes || ''}</textarea>
    </div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_sdSaveBuy(${p.id || 'null'})">${isEdit ? 'Save Changes' : 'Save Purchase'}</button>`
  );
}

function _sdEditParcel(id) { _sdOpenBuy(_sd.parcels.find(p => p.id === id) || {}); }

async function _sdSaveBuy(parcelId) {
  const acquisition_date = document.getElementById('sd-buy-date').value;
  const quantity         = document.getElementById('sd-buy-qty').value;
  const price_per_unit   = document.getElementById('sd-buy-price').value;
  const brokerage        = document.getElementById('sd-buy-brok').value || '0';
  const other_costs      = document.getElementById('sd-buy-other').value || '0';
  const notes            = document.getElementById('sd-buy-notes').value;
  const label            = document.getElementById('sd-buy-label').value.trim();
  const totalEl          = document.getElementById('sd-buy-total');
  const entered_total    = totalEl.dataset.typed && totalEl.value ? totalEl.value : null;

  if (!acquisition_date) return toast('Acquisition date is required', 'err');
  if (!quantity || parseFloat(quantity) <= 0) return toast('Quantity must be > 0', 'err');
  if (!price_per_unit || parseFloat(price_per_unit) <= 0) return toast('Price must be > 0', 'err');

  const url    = parcelId ? `/api/parcels/${parcelId}` : '/api/parcels';
  const method = parcelId ? 'PUT' : 'POST';
  const body   = parcelId
    ? { acquisition_date, quantity, price_per_unit, brokerage, other_costs, notes, label, entered_total }
    : { security_id: _sd.security.id, acquisition_date, quantity, price_per_unit, brokerage, other_costs, notes,
        label, entered_total, holding_id: holdingVal('sd-buy-holding') };
  try {
    const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify(body) }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    toast(parcelId ? 'Purchase updated' : 'Purchase recorded');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

async function _sdDeleteParcel(id) {
  if (!confirm('Delete this purchase parcel? Cannot be undone.' + attDeleteNote('parcel', id))) return;
  try {
    const r = await fetch(`/api/parcels/${id}`, { method: 'DELETE' }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    toast('Parcel deleted');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

// ── Inherited shares ─────────────────────────────────────────────────────────

function _sdOpenInherit() {
  openPanel('Inherited Shares', `
    <div style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3);margin-bottom:14px">
      ${_sd.security.code} — ${_sd.security.name}
    </div>
    <div style="font-size:12px;color:var(--ink2);line-height:1.6;margin-bottom:14px">
      If the deceased acquired the shares on or after 20 September 1985, you take over their cost base and
      their purchase date counts for the CGT discount. If they acquired them earlier, your cost base is the
      market value on the date of death, and you acquired them on that date.
      For a whole portfolio, use <em>Holdings at Date → Export as Inherited</em> in the deceased's portfolio,
      then <em>Import / Export → Add to this portfolio</em> here.
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Date of Death</label><input type="date" id="sd-inh-date"></div>
      <div class="field"><label>Quantity</label><input type="number" id="sd-inh-qty" min="0" step="any"></div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Deceased's Purchase Date</label><input type="date" id="sd-inh-orig"></div>
      <div class="field"><label>Cost Base ($)</label><input type="number" id="sd-inh-cost" min="0" step="any"
        placeholder="Deceased's cost base, or market value"></div>
    </div>
    <div class="field"><label>Label</label><input type="text" id="sd-inh-label" placeholder="Optional"></div>
    ${holdingField('sd-inh-holding')}
    <div class="field"><label>Notes</label><textarea id="sd-inh-notes" placeholder="Optional"></textarea></div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_sdSaveInherit()">Save</button>`);
}

async function _sdSaveInherit() {
  const v = id => document.getElementById(id).value.trim();
  const body = { security_id: _sd.security.id, death_date: v('sd-inh-date'), quantity: v('sd-inh-qty'),
                 cost_base: v('sd-inh-cost'), original_date: v('sd-inh-orig') || null,
                 label: v('sd-inh-label'), notes: v('sd-inh-notes'), holding_id: holdingVal('sd-inh-holding') };
  if (!body.death_date) return toast('Enter the date of death', 'err');
  if (!(parseFloat(body.quantity) > 0)) return toast('Quantity must be > 0', 'err');
  if (body.cost_base === '') return toast('Enter the cost base', 'err');
  try {
    const r = await fetch('/api/parcels/inherited', { method: 'POST', headers: { 'Content-Type': 'application/json' },
                                                       body: JSON.stringify(body) }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    toast('Inherited shares recorded');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

// ── Employee share plan shares ───────────────────────────────────────────────

function _sdOpenEmployee() {
  openPanel('Employee Shares', `
    <div style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3);margin-bottom:14px">
      ${_sd.security.code} — ${_sd.security.name}
    </div>
    <div style="font-size:12px;color:var(--ink2);line-height:1.6;margin-bottom:14px">
      For plans taxed upfront, such as the $1,000 tax-free employee share plans. Your cost base is the shares'
      market value on the date you acquired them, even if you paid nothing, and the 12 months for the CGT
      discount start on that date. Both are on your employee share scheme (ESS) statement. The ESS amount
      itself goes in your tax return from that statement. It isn't worked out here.
      Sales don't use the shares before the restriction period ends unless you choose them.
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Date Acquired</label><input type="date" id="sd-ess-date"></div>
      <div class="field"><label>Quantity</label><input type="number" id="sd-ess-qty" min="0" step="any"></div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Market Value ($)</label><input type="number" id="sd-ess-value" min="0" step="any"
        placeholder="Total, from the ESS statement"></div>
      <div class="field"><label>Restricted Until</label><input type="date" id="sd-ess-until"
        title="The end of the plan's restriction period (blank if none)"></div>
    </div>
    <div class="field"><label>Label</label><input type="text" id="sd-ess-label" placeholder="Optional"></div>
    ${holdingField('sd-ess-holding')}
    <div class="field"><label>Notes</label><textarea id="sd-ess-notes" placeholder="Optional"></textarea></div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_sdSaveEmployee()">Save</button>`);
}

async function _sdSaveEmployee() {
  const v = id => document.getElementById(id).value.trim();
  const body = { security_id: _sd.security.id, acquisition_date: v('sd-ess-date'), quantity: v('sd-ess-qty'),
                 market_value: v('sd-ess-value'), restricted_until: v('sd-ess-until') || null,
                 label: v('sd-ess-label'), notes: v('sd-ess-notes'), holding_id: holdingVal('sd-ess-holding') };
  if (!body.acquisition_date) return toast('Enter the date you acquired the shares', 'err');
  if (!(parseFloat(body.quantity) > 0)) return toast('Quantity must be > 0', 'err');
  if (body.market_value === '') return toast('Enter the market value', 'err');
  try {
    const r = await fetch('/api/parcels/employee', { method: 'POST', headers: { 'Content-Type': 'application/json' },
                                                      body: JSON.stringify(body) }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    toast('Employee shares recorded');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

function _sdOpenRestriction(id) {
  const p = _sd.parcels.find(x => x.id === id) || {};
  openPanel('Restriction Period', `
    <div style="font-size:12px;color:var(--ink2);line-height:1.6;margin-bottom:14px">
      Employee shares acquired ${fmtDate(p.acquisition_date)}. Sales don't use them before this date unless you
      choose them. If the restriction ended early (for example you left the employer), change the date or clear it.
    </div>
    <div class="field"><label>Restricted Until</label>
      <input type="date" id="sd-restr-until" value="${p.restricted_until || ''}"></div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_sdSaveRestriction(${id})">Save</button>`);
}

async function _sdSaveRestriction(id) {
  const until = document.getElementById('sd-restr-until').value || null;
  try {
    const r = await fetch(`/api/parcels/${id}/restriction`, { method: 'PUT', headers: { 'Content-Type': 'application/json' },
                                                            body: JSON.stringify({ restricted_until: until }) }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    toast(until ? 'Restriction date saved' : 'Restriction cleared');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

// ── Sell form ──────────────────────────────────────────────────────────────────

function _sdOpenSell(s = {}) {
  const isEdit = !!s.id;
  const defBrok = s.brokerage != null ? s.brokerage : ((_appSettings && _appSettings.default_brokerage) || '');
  openPanel(isEdit ? 'Edit Sale' : 'Record Sale', `
    <div style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3);margin-bottom:14px">
      ${_sd.security.code} — ${_sd.security.name}
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Sale Date</label>
        <input type="date" id="sd-sell-date" onchange="parcelPickerDisc('sd-parcel-list', this.value)" value="${s.sale_date || new Date().toISOString().slice(0,10)}">
      </div>
      <div class="field"><label>Quantity</label>
        <input type="number" id="sd-sell-qty" min="0" step="any" value="${s.quantity || ''}" placeholder="0">
      </div>
    </div>
    ${isEdit ? (s.holding_code ? `<div style="font-size:11px;color:var(--ink3);margin:-6px 0 12px">Holding: ${s.holding_code}</div>` : '') : holdingField('sd-sell-holding', null, 'shares are sold from this holding')}
    <div class="field-row cols-2">
      <div class="field"><label>Price Per Unit ($)</label>
        <input type="number" id="sd-sell-price" min="0" step="any" value="${s.price_per_unit || ''}" placeholder="0.00">
      </div>
      <div class="field"><label>Brokerage ($)</label>
        <input type="number" id="sd-sell-brok" min="0" step="any" value="${defBrok}" placeholder="0.00">
      </div>
    </div>
    <div class="field"><label>CGT Method</label>
      <select id="sd-sell-method" onchange="_sdSellMethodChanged()">
        <option value="fifo"     ${(s.cgt_method||'fifo')==='fifo'     ? 'selected':''}>FIFO — First In, First Out</option>
        <option value="mingain"  ${s.cgt_method==='mingain'  ? 'selected':''}>Min Gain — Highest Cost Base First</option>
        <option value="maxgain"  ${s.cgt_method==='maxgain'  ? 'selected':''}>Max Gain — Lowest Cost Base First</option>
        <option value="prorata"  ${s.cgt_method==='prorata'  ? 'selected':''}>Pro rata — Same Proportion From Every Parcel</option>
        <option value="specific" ${s.cgt_method==='specific' ? 'selected':''}>Specific Parcels</option>
      </select>
    </div>
    <div id="sd-parcel-picker" style="display:none">
      <div id="sd-parcel-list"></div>
    </div>
    ${_sdChoiceField('sd-sell-choice', s.cgt_choice)}
    <div class="field"><label>Notes</label>
      <textarea id="sd-sell-notes" placeholder="Optional">${s.notes || ''}</textarea>
    </div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_sdSaveSell(${s.id || 'null'})">${isEdit ? 'Save Changes' : 'Record Sale'}</button>`
  );
}

async function _sdSellMethodChanged() {
  const method = document.getElementById('sd-sell-method')?.value;
  const picker = document.getElementById('sd-parcel-picker');
  if (!picker) return;
  if (method !== 'specific') { picker.style.display = 'none'; return; }
  picker.style.display = '';
  document.getElementById('sd-parcel-list').innerHTML = '<div style="color:var(--ink3);font-size:12px">Loading…</div>';
  try {
    const parcels = await apiFetch(`/api/parcels?security_id=${_sd.security.id}&open_only=1`);
    if (!parcels.length) {
      document.getElementById('sd-parcel-list').innerHTML = '<div style="color:var(--ink3);font-size:12px">No open parcels</div>';
      return;
    }
    document.getElementById('sd-parcel-list').innerHTML = parcelPickerHtml(parcels, 'sd-parcel-list', 'sd-sell-qty', document.getElementById('sd-sell-date')?.value);
  } catch (e) {
    document.getElementById('sd-parcel-list').innerHTML = `<div style="color:var(--red);font-size:12px">${e.message}</div>`;
  }
}

// Discount or indexation: offered only when a parcel was acquired before 21 Sep 1999
function _sdCanIndex() {
  return _sd.parcels.some(p => p.quantity_remaining > 1e-9 && !p.pre_cgt && p.cgt_acquired < '1999-09-21');
}

function _sdChoiceField(id, value, onchange = '') {
  if (!_sdCanIndex()) return '';
  return `<div class="field"><label>Capital gain method
      <span style="font-weight:400;text-transform:none;letter-spacing:0">for shares acquired before 21 Sep 1999</span></label>
    <select id="${id}" ${onchange ? `onchange="${onchange}"` : ''}>
      <option value="" ${!value ? 'selected' : ''}>Portfolio default (Settings)</option>
      <option value="discount" ${value === 'discount' ? 'selected' : ''}>CGT discount</option>
      <option value="indexation" ${value === 'indexation' ? 'selected' : ''}>Indexation (cost base indexed to Sep 1999, no discount)</option>
    </select></div>`;
}

function _sdEditSale(id) { _sdOpenSell(_sd.sales.find(s => s.id === id) || {}); }

async function _sdSaveSell(saleId) {
  const sale_date      = document.getElementById('sd-sell-date').value;
  const quantity       = document.getElementById('sd-sell-qty').value;
  const price_per_unit = document.getElementById('sd-sell-price').value;
  const brokerage      = document.getElementById('sd-sell-brok').value || '0';
  const cgt_method     = document.getElementById('sd-sell-method').value;
  const notes          = document.getElementById('sd-sell-notes').value;
  const cgt_choice     = document.getElementById('sd-sell-choice')?.value || null;

  if (!sale_date) return toast('Sale date is required', 'err');
  if (!quantity || parseFloat(quantity) <= 0) return toast('Quantity must be > 0', 'err');
  if (!price_per_unit || parseFloat(price_per_unit) <= 0) return toast('Price must be > 0', 'err');

  let parcel_ids = null, allocations = null;
  if (cgt_method === 'specific') {
    const pick = parcelPickerRead('sd-parcel-list', quantity);
    if (pick.error) return toast(pick.error, 'err');
    ({ parcel_ids, allocations } = pick);
  }

  const url    = saleId ? `/api/sales/${saleId}` : '/api/sales';
  const method = saleId ? 'PUT' : 'POST';
  const body   = saleId
    ? { sale_date, quantity, price_per_unit, brokerage, cgt_method, notes, parcel_ids, allocations, cgt_choice }
    : { security_id: _sd.security.id, sale_date, quantity, price_per_unit, brokerage, cgt_method, notes, parcel_ids,
        allocations, cgt_choice, holding_id: holdingVal('sd-sell-holding') };
  try {
    const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify(body) }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    toast(saleId ? 'Sale updated' : 'Sale recorded');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

async function _sdDeleteSale(id) {
  if (!confirm('Delete this sale? Parcel allocations will be reversed.' + attDeleteNote('sale', id))) return;
  try {
    const r = await fetch(`/api/sales/${id}`, { method: 'DELETE' }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    toast('Sale deleted');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

// ── Dividend form ──────────────────────────────────────────────────────────────

function _sdOpenDiv(d = {}) {
  const isEdit = !!d.id;
  const hasDrp = isEdit && d.is_drp;
  openPanel(isEdit ? 'Edit Dividend' : 'Record Dividend', `
    <div style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3);margin-bottom:14px">
      ${_sd.security.code} — ${_sd.security.name}
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Payment Date</label>
        <input type="date" id="sd-div-pay" value="${d.payment_date || new Date().toISOString().slice(0,10)}">
      </div>
      <div class="field"><label>Ex-Dividend Date <span style="font-weight:400;text-transform:none;letter-spacing:0;color:var(--amber)">required for 45-day rule</span></label>
        <input type="date" id="sd-div-ex" value="${d.ex_date_estimated ? '' : d.ex_date || ''}">
      </div>
    </div>
    <div class="field"><label>Record Date <span style="font-weight:400;text-transform:none;letter-spacing:0">optional — from 9 Mar 2016, a blank ex-date is taken as the business day before</span></label>
      <input type="date" id="sd-div-rec" value="${d.record_date || ''}">
    </div>
    ${isEdit ? (d.holding_code ? `<div style="font-size:11px;color:var(--ink3);margin:-6px 0 12px">Holding: ${d.holding_code}</div>` : '') : holdingField('sd-div-holding')}
    <div class="field-row cols-2">
      <div class="field"><label>Quantity Held</label>
        <input type="number" id="sd-div-qty" min="0" step="any" value="${d.quantity_held || ''}" placeholder="0">
      </div>
      <div class="field"><label>Amount Per Share <span style="font-weight:400;text-transform:none;letter-spacing:0">before tax</span></label>
        <input type="text" inputmode="decimal" id="sd-div-aps" value="${d.id ? divAmountValue(d) : ''}" placeholder="0.0000 or US$0.0000">
      </div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Franking % <span style="font-weight:400;text-transform:none;letter-spacing:0">(0–100)</span></label>
        <input type="number" id="sd-div-frank" min="0" max="100" step="any" value="${d.franking_pct ?? 0}">
      </div>
      <div class="field"><label>Franking Credit ($) <span style="font-weight:400;text-transform:none;letter-spacing:0">from statement</span></label>
        <input type="number" id="sd-div-frank-amt" min="0" step="any" value="${d.franking_credit ? d.franking_credit.toFixed(2) : ''}" placeholder="0.00">
      </div>
    </div>
    <div style="font-size:11px;color:var(--ink3);margin-top:-8px;margin-bottom:12px">Enter the franking credit dollar amount shown on your dividend statement — it isn't calculated from the franking %, because the company tax rate varies (25% base-rate entities, 30% others).</div>
    ${divTaxFields('sd-div', d.id ? d : null)}
    ${hasDrp ? `
    <div style="padding:10px 12px;background:var(--amber-dim);border-radius:7px;font-size:12px;color:var(--amber)">
      DRP details cannot be edited. Delete and re-enter to change DRP.
    </div>` : !isEdit ? `
    <div class="field"><label>
      <input type="checkbox" id="sd-div-drp" onchange="_sdToggleDrp()"> Dividend Reinvestment Plan (DRP)
    </label></div>
    <div id="sd-div-drp-fields" style="display:none">
      <div class="field-row cols-2">
        <div class="field"><label>DRP Shares Issued</label>
          <input type="number" id="sd-div-drp-qty" min="0" step="any" placeholder="0">
        </div>
        <div class="field"><label>DRP Price ($)</label>
          <input type="number" id="sd-div-drp-price" min="0" step="any" placeholder="0.00">
        </div>
      </div>
    </div>` : ''}
    <div class="field"><label>Notes</label>
      <textarea id="sd-div-notes" placeholder="Optional">${d.notes || ''}</textarea>
    </div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_sdSaveDiv(${d.id || 'null'})">${isEdit ? 'Save Changes' : 'Save Dividend'}</button>`
  );
}

function _sdToggleDrp() {
  const f = document.getElementById('sd-div-drp-fields');
  if (f) f.style.display = document.getElementById('sd-div-drp').checked ? '' : 'none';
}

function _sdEditDiv(id) { _sdOpenDiv(_sd.divs.find(d => d.id === id) || {}); }

async function _sdSaveDiv(divId) {
  const payment_date     = document.getElementById('sd-div-pay').value;
  const ex_date          = document.getElementById('sd-div-ex').value || null;
  const record_date      = document.getElementById('sd-div-rec').value || null;
  const quantity_held    = document.getElementById('sd-div-qty').value;
  const amount_per_share = document.getElementById('sd-div-aps').value.trim();
  const tax              = divTaxValues('sd-div');
  const franking_pct     = document.getElementById('sd-div-frank').value || '0';
  const franking_credit  = document.getElementById('sd-div-frank-amt').value || '0';
  const notes            = document.getElementById('sd-div-notes').value;

  if (!payment_date) return toast('Payment date is required', 'err');
  if (!quantity_held || parseFloat(quantity_held) <= 0) return toast('Quantity held must be > 0', 'err');
  if (!amount_per_share) return toast('Amount per share is required', 'err');

  try {
    if (divId) {
      const r = await fetch(`/api/dividends/${divId}`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ payment_date, ex_date, record_date, quantity_held, amount_per_share, franking_pct, franking_credit, notes, ...tax }),
      }).then(r => r.json());
      if (!r.ok) throw new Error(r.error);
      toast('Dividend updated');
    } else {
      const is_drp      = document.getElementById('sd-div-drp')?.checked ? 1 : 0;
      const drp_quantity = is_drp ? document.getElementById('sd-div-drp-qty')?.value : null;
      const drp_price    = is_drp ? document.getElementById('sd-div-drp-price')?.value : null;
      const r = await fetch('/api/dividends', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ security_id: _sd.security.id, payment_date, ex_date, record_date,
                               holding_id: holdingVal('sd-div-holding'),
                               quantity_held, amount_per_share, franking_pct, franking_credit,
                               is_drp, drp_quantity, drp_price, notes, ...tax }),
      }).then(r => r.json());
      if (!r.ok) throw new Error(r.error);
      toast('Dividend recorded');
    }
    closePanel();
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

async function _sdDeleteDiv(id) {
  if (!confirm('Delete this dividend? DRP parcel will also be removed if unsold.' + attDeleteNote('dividend', id))) return;
  try {
    const r = await fetch(`/api/dividends/${id}`, { method: 'DELETE' }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    toast('Dividend deleted');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

// ── CGT Sale Estimator ────────────────────────────────────────────────────────

function _sdEstimateSale() {
  openPanel('Estimate Sale — ' + _sd.security.code, `
    <div style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3);margin-bottom:14px">
      FIFO estimate only — not financial advice
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Quantity to Sell</label>
        <input type="number" id="est-qty" min="0" step="any" placeholder="0" oninput="_sdCalcEstimate()">
      </div>
      <div class="field"><label>Sale Price ($)</label>
        <input type="number" id="est-price" min="0" step="any" placeholder="0.00" oninput="_sdCalcEstimate()">
      </div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Brokerage ($)</label>
        <input type="number" id="est-brok" min="0" step="any" value="0" placeholder="0.00" oninput="_sdCalcEstimate()">
      </div>
      <div class="field"><label>Sale Date</label>
        <input type="date" id="est-date" value="${new Date().toISOString().slice(0,10)}" onchange="_sdCalcEstimate()">
      </div>
    </div>
    ${_sdChoiceField('est-choice', '', '_sdCalcEstimate()')}
    ${holdingField('est-holding', null, 'sell from this holding').replace('<select ', '<select onchange="_sdCalcEstimate()" ')}
    <div id="est-result"></div>`,
    `<button class="btn btn-primary" onclick="closePanel()">Close</button>`
  );
}

let _sdEstSeq = 0;

async function _sdCalcEstimate() {
  const qty   = parseFloat(document.getElementById('est-qty')?.value)   || 0;
  const price = parseFloat(document.getElementById('est-price')?.value) || 0;
  const brok  = parseFloat(document.getElementById('est-brok')?.value)  || 0;
  const saleDate = document.getElementById('est-date')?.value || new Date().toISOString().slice(0,10);
  const el    = document.getElementById('est-result');
  if (!el) return;
  if (qty <= 0 || price <= 0) { el.innerHTML = ''; return; }

  // CGT maths lives in core/portfolio.py (estimate_sale) — same parcel matching,
  // 12-month rule and losses-before-discount netting as a real sale.
  const seq = ++_sdEstSeq;
  let e;
  try {
    const choice = document.getElementById('est-choice')?.value || '';
    e = await apiFetch(`/api/cgt-estimate?security_id=${_sd.security.id}&date=${saleDate}` +
                       `&quantity=${qty}&price=${price}&brokerage=${brok}&cgt_choice=${choice}` +
                       `&holding_id=${holdingVal('est-holding') || ''}`);
  } catch (err) {
    el.innerHTML = '';
    toast(err.message, 'err');
    return;
  }
  if (seq !== _sdEstSeq) return;  // a newer keystroke has superseded this request

  if (e.insufficient) {
    el.innerHTML = `<div style="padding:10px 14px;background:var(--red-dim);border-radius:8px;font-size:12px;color:var(--red)">
      Insufficient shares held on ${fmtDate(saleDate)} — ${fmtNum(e.available, 4)} available, selling ${fmtNum(qty, 4)}</div>`;
    return;
  }

  const entityType = (_appSettings && _appSettings.entity_type) || 'individual';
  const discountLabel = { individual: 'losses, then 50% discount', smsf_accumulation: 'losses, then 1/3 discount',
                          smsf_pension: 'fully exempt (pension)', company: 'no CGT discount' }[entityType] || 'after CGT discount';
  const totalTaxable = e.taxable_gain;
  const taxRate = parseFloat((_appSettings && _appSettings.marginal_tax_rate) || 0);
  const estTax  = taxRate > 0 && totalTaxable > 0 ? totalTaxable * taxRate / 100 : null;

  el.innerHTML = `
    <div style="margin-top:14px;padding:12px 14px;background:var(--surface2);border-radius:8px;border:1px solid var(--border)">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 24px;font-size:12px;margin-bottom:12px">
        <div style="color:var(--ink3)">Net Proceeds</div><div class="mono" style="text-align:right">${fmtCurrency(e.proceeds)}</div>
        <div style="color:var(--ink3)">Cost Base (FIFO)</div><div class="mono" style="text-align:right">${fmtCurrency(e.cost_base)}</div>
        <div style="color:var(--ink3);border-top:1px solid var(--border);padding-top:4px">Gross Gain/Loss</div>
        <div class="mono ${gainClass(e.gross_gain)}" style="text-align:right;border-top:1px solid var(--border);padding-top:4px">${fmtCurrency(e.gross_gain)}</div>
        <div style="color:var(--ink3)">Taxable Gain (${discountLabel})</div>
        <div class="mono ${gainClass(totalTaxable)}" style="text-align:right;font-weight:700">${fmtCurrency(totalTaxable)}</div>
        ${e.net_loss > 0 ? `
        <div style="color:var(--ink3)">Capital loss from this sale</div>
        <div class="mono col-red" style="text-align:right">${fmtCurrency(-e.net_loss)}</div>` : ''}
        ${estTax !== null ? `
        <div style="color:var(--ink3)">Est. Tax @ ${taxRate}%</div>
        <div class="mono col-red" style="text-align:right">${fmtCurrency(estTax)}</div>
        <div style="color:var(--ink3)">Est. After-Tax Gain</div>
        <div class="mono ${gainClass(totalTaxable - estTax)}" style="text-align:right;font-weight:700">${fmtCurrency(totalTaxable - estTax)}</div>` : ''}
      </div>
      <table class="st-table" style="font-size:11px">
        <thead><tr><th>Parcel Acquired</th><th class="num">Qty</th><th class="num">Cost Base</th>
          <th class="num">Gain</th><th>Method</th><th class="num">Taxable</th></tr></thead>
        <tbody>
          ${e.parcels.map(a => `<tr>
            <td class="mono">${fmtDate(a.acquisition_date)}</td>
            <td class="num mono">${fmtNum(a.quantity, 4)}</td>
            <td class="num mono">${fmtCurrency(a.cost_base_used)}</td>
            <td class="num mono"><span class="${gainClass(a.gain_loss)}">${fmtCurrency(a.gain_loss)}</span></td>
            <td>${cgtBasisBadge(a.cgt_basis)}</td>
            <td class="num mono"><span class="${gainClass(a.taxable_gain)}">${fmtCurrency(a.taxable_gain)}</span></td>
          </tr>`).join('')}
        </tbody>
      </table>
      <div style="font-size:10px;color:var(--ink3);margin-top:8px;font-style:italic">Considers this sale only — other gains and losses in the year, and carried-forward losses, are applied in the CGT Summary.</div>
    </div>`;
}

// ── Corporate actions section ─────────────────────────────────────────────────

function _sdActBadge(a) {
  if (a.action_type === 'rights_issue')     return '<span class="badge badge-green">Rights Issue</span>';
  if (a.action_type === 'bonus')            return '<span class="badge badge-green">Bonus</span>';
  if (a.action_type === 'return_of_capital') return '<span class="badge badge-red">Return of Capital</span>';
  return a.ratio_to > a.ratio_from
    ? '<span class="badge badge-accent">Split</span>'
    : '<span class="badge badge-amber">Consolidation</span>';
}

function _sdActionsSection() {
  const rows = _sd.actions.length ? _sd.actions.map(a => {
    return `<tr>
      <td class="mono">${fmtDate(a.action_date)}</td>
      <td>${_sdActBadge(a)}</td>
      <td class="mono">${
        a.action_type === 'rights_issue'      ? `${fmtNum(a.ratio_from, 0)} @ ${fmtCurrency(a.ratio_to, 4)}`
        : a.action_type === 'bonus'           ? `${fmtNum(a.ratio_from, 0)} @ $0.00`
        : a.action_type === 'return_of_capital' ? `${fmtCurrency(a.ratio_from, 4)}/unit`
        : fmtRatio(a.ratio_to, a.ratio_from)
      }</td>
      <td style="font-size:12px;color:var(--ink2)">${a.description || ''}</td>
      <td class="row-actions">${attBtn('action', a, `${_sd.security.code} ${fmtDate(a.action_date)}`)}${
        _isLocked(a.action_date)
          ? '<span class="badge badge-amber" title="FY locked — cannot modify after lodgement">Locked</span>'
          : `<button class="btn btn-ghost btn-sm" style="color:var(--red)"
              onclick="_sdDeleteAction(${a.id}, ${a.ratio_from}, ${a.ratio_to}, '${a.action_type}')">Del</button>`
      }</td>
    </tr>`;
  }).join('') : `<tr><td colspan="5" style="text-align:center;padding:24px;color:var(--ink3);font-size:12px">No corporate actions recorded</td></tr>`;

  return `
    <div class="st-section" style="margin-top:28px">
      <div class="st-section-title">Corporate Actions</div>
      <div class="st-section-line"></div>
      <button class="btn btn-secondary btn-sm" onclick="_sdOpenAction()">+ Action</button>
    </div>
    <div class="st-list-panel">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Date</th><th>Type</th><th>Ratio</th><th>Description</th><th></th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>`;
}

async function _sdOpenAction() {
  // Same form as the Corporate Actions page (all action types), with this security preset
  try {
    await loadModule('actions');
    _actSecurities = await apiFetch('/api/securities');
  } catch (e) { return toast(e.message, 'err'); }
  _actOpenForm(_sd.security.id, _sdRefresh);
}

async function _sdToggleWatch() {
  const btn = document.getElementById('sd-watch-btn');
  if (btn) { btn.disabled = true; }
  try {
    if (_sd.watchlistItem) {
      const r = await fetch(`/api/watchlist/${_sd.watchlistItem.id}`, { method: 'DELETE' }).then(r => r.json());
      if (!r.ok) throw new Error(r.error);
      _sd.watchlistItem = null;
      toast('Removed from watch list');
    } else {
      const r = await fetch('/api/watchlist', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ security_id: _sd.security.id }),
      }).then(r => r.json());
      if (!r.ok) throw new Error(r.error);
      _sd.watchlistItem = { id: r.data.id, security_id: _sd.security.id };
      toast('Added to watch list');
    }
    if (btn) {
      btn.disabled = false;
      if (_sd.watchlistItem) {
        btn.textContent = '👁 Watching';
        btn.style.color = 'var(--ink3)';
      } else {
        btn.textContent = '+ Watch';
        btn.style.color = '';
      }
    }
  } catch (e) {
    toast(e.message, 'err');
    if (btn) btn.disabled = false;
  }
}

async function _sdDeleteAction(id, ratioFrom, ratioTo, actionType) {
  const msg = (actionType === 'rights_issue' || actionType === 'bonus')
    ? `Delete this ${actionType === 'bonus' ? 'bonus issue' : 'rights issue'}?\n\nThe created parcel will be removed (if not yet sold). This cannot be undone.`
    : actionType === 'return_of_capital'
    ? `Reverse and delete this return of capital ($${parseFloat(ratioFrom).toFixed(4)}/unit)?\n\nCost bases on all affected parcels will be restored. Any CGT reported from this action will no longer appear. This cannot be undone.`
    : actionType === 'demerger'
    ? `Reverse and delete this demerger?\n\nCost bases on the original parcels will be restored, and the parcels created for the demerged entity will be removed (if not yet sold). This cannot be undone.`
    : `Reverse and delete this ${fmtRatio(ratioTo, ratioFrom)} action?\n\nAll affected parcels will revert to their pre-action quantities.`;
  if (!confirm(msg + attDeleteNote('action', id))) return;
  try {
    const r = await fetch(`/api/actions/${id}`, { method: 'DELETE' }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    toast('Action reversed and deleted');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}
