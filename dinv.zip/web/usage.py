# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Daily check-in, so we know roughly how many copies are in use.

Once a day (when the app checks for updates) it posts to the Dogbox licence
server: a random install number made the first time it runs, the app version
and the operating system. Nothing about the person or their portfolio is sent,
and the server doesn't keep IP addresses. Same as Dogbox Accounting's core/usage.py.

No check-in from a git checkout (development and tests), or when
DOGBOX_NO_USAGE is set.
"""
import os
import sys
import json
import time
import uuid
import platform
import threading
import urllib.request

PING_URL = 'https://license.dogboxsoftware.com.au/api/ping'
_INSTALL_DIR = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
_last = {'at': 0.0}
_lock = threading.Lock()


def _id_dir():
    if sys.platform == 'win32':
        base = os.environ.get('LOCALAPPDATA') or os.path.join(os.path.expanduser('~'), 'AppData', 'Local')
        return os.path.join(base, 'Dogbox Investments')
    if sys.platform == 'darwin':
        return os.path.join(os.path.expanduser('~'), 'Library', 'Application Support', 'Dogbox Investments')
    base = os.environ.get('XDG_DATA_HOME') or os.path.join(os.path.expanduser('~'), '.local', 'share')
    return os.path.join(base, 'dogbox-investments')


def _install_id(id_dir):
    path = os.path.join(id_dir, 'install_id')
    try:
        with open(path) as f:
            v = f.read().strip()
        if len(v) == 32:
            return v
    except OSError:
        pass
    v = uuid.uuid4().hex
    os.makedirs(id_dir, exist_ok=True)
    with open(path, 'w') as f:
        f.write(v)
    return v


def enabled(install_dir=_INSTALL_DIR):
    return not os.environ.get('DOGBOX_NO_USAGE') and not os.path.exists(os.path.join(install_dir, '.git'))


def ping(version, id_dir=None, install_dir=_INSTALL_DIR):
    """Check in at most once a day per running app, in the background. Never raises."""
    if not enabled(install_dir):
        return
    with _lock:
        now = time.time()
        if now - _last['at'] < 86400:
            return
        _last['at'] = now

    def _send():
        try:
            body = {'app': 'dinv', 'install_id': _install_id(id_dir or _id_dir()),
                    'version': version,
                    'os': {'win32': 'Windows', 'darwin': 'macOS'}.get(sys.platform, platform.system() or 'Other')}
            req = urllib.request.Request(PING_URL, data=json.dumps(body).encode(),
                                         headers={'Content-Type': 'application/json'},
                                         method='POST')
            urllib.request.urlopen(req, timeout=10).close()
        except Exception:
            pass
    threading.Thread(target=_send, daemon=True).start()
