# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Investments — Web Interface
Run: python web_server.py [portfolio.stk]
"""
import sys, os, io, csv, threading
from flask import Flask, request, session, jsonify, render_template, redirect, Response

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.portfolio import (
    get_securities, add_security, get_security_by_code, update_security,
    get_parcels, add_parcel, get_parcel, update_parcel, delete_parcel,
    get_holdings, get_holdings_at_date, get_performance,
    get_sales, add_sale, get_sale, update_sale, delete_sale,
    get_dividends, add_dividend, get_dividend, update_dividend, delete_dividend,
    get_corporate_actions, apply_corporate_action, delete_corporate_action,
    get_cgt_summary, get_roc_cgt, compute_cgt_carryforward,
    get_settings, set_setting,
    get_watchlist, add_watchlist_item, update_watchlist_item, delete_watchlist_item,
    get_cost_base_reconciliation,
    get_audit_log,
)
from core.prices import fetch_prices, get_prices, get_price_history
from core.broker_parsers import parse as parse_broker_csv, FORMAT_LABELS

app = Flask(__name__,
            static_folder=os.path.join(os.path.dirname(__file__), "static"),
            static_url_path="/static",
            template_folder=os.path.join(os.path.dirname(__file__), "templates"))

app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SEND_FILE_MAX_AGE_DEFAULT=0,
)
app.secret_key = b"placeholder-overwritten-by-launcher"

DB_PATH = None
_browser_proc = None


def _kill_browser():
    if not _browser_proc or _browser_proc.poll() is not None:
        return
    try:
        import subprocess as _sp
        if sys.platform == "win32":
            _sp.call(['taskkill', '/F', '/T', '/PID', str(_browser_proc.pid)],
                     stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)
        else:
            _browser_proc.terminate()
    except Exception:
        pass


def db():
    if not DB_PATH:
        raise RuntimeError("No portfolio file open")
    return DB_PATH


def ok(data=None):
    if data is None:
        return jsonify({"ok": True})
    return jsonify({"ok": True, "data": data})


def err(msg, code=400):
    return jsonify({"ok": False, "error": msg}), code


# ── Pages ──────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("app.html")


# ── Securities ─────────────────────────────────────────────────────────────────

@app.route("/api/securities", methods=["GET"])
def api_securities_list():
    active_only = request.args.get("active_only", "1") != "0"
    return ok(get_securities(db(), active_only=active_only))


@app.route("/api/securities/<int:sec_id>", methods=["PUT"])
def api_security_update(sec_id):
    d = request.json or {}
    try:
        update_security(
            db(), sec_id,
            name=d.get("name", "").strip(),
            exchange=d.get("exchange", "ASX"),
            security_type=d.get("security_type", "share"),
            currency=d.get("currency", "AUD"),
            notes=d.get("notes", ""),
            is_active=d.get("is_active", 1),
        )
        return ok()
    except (KeyError, ValueError) as e:
        return err(str(e))


@app.route("/api/securities", methods=["POST"])
def api_securities_create():
    d = request.json or {}
    code = (d.get("code") or "").strip()
    name = (d.get("name") or "").strip()
    if not code or not name:
        return err("Code and name are required")
    if get_security_by_code(db(), code):
        return err(f"{code} already exists")
    sid = add_security(
        db(), code, name,
        exchange=d.get("exchange", "ASX"),
        security_type=d.get("security_type", "share"),
        currency=d.get("currency", "AUD"),
        notes=d.get("notes", ""),
    )
    return ok({"id": sid})


# ── Holdings ───────────────────────────────────────────────────────────────────

@app.route("/api/holdings", methods=["GET"])
def api_holdings():
    return ok(get_holdings(db()))


@app.route("/api/holdings-at-date", methods=["GET"])
def api_holdings_at_date():
    from datetime import date
    snap_date = request.args.get("date", "")
    if not snap_date:
        today = date.today()
        yr = today.year if today.month >= 7 else today.year - 1
        snap_date = f"{yr}-06-30"
    return ok(get_holdings_at_date(db(), snap_date))


@app.route("/api/export/holdings-at-date.csv")
def api_export_holdings_at_date_csv():
    from datetime import date as _d
    snap_date = request.args.get("date", "")
    if not snap_date:
        today = _d.today()
        yr = today.year if today.month >= 7 else today.year - 1
        snap_date = f"{yr}-06-30"
    rows = get_holdings_at_date(db(), snap_date)
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(['sharetrack — Holdings at Date'])
    w.writerow([f'As at: {snap_date}'])
    w.writerow([f'Generated: {_d.today().strftime("%d/%m/%Y")}'])
    w.writerow([])
    w.writerow(['Code', 'Security Name', 'Exchange', 'Date Acquired',
                'Quantity', 'Cost Base ($)', 'Avg Cost/Unit ($)'])
    total_cb = 0.0
    for r in rows:
        avg = r['cost_base_at_date'] / r['qty_at_date'] if r['qty_at_date'] else 0.0
        total_cb += r['cost_base_at_date']
        w.writerow([
            r['code'], r['name'], r['exchange'],
            r['acquisition_date'],
            f"{r['qty_at_date']:.4f}",
            f"{r['cost_base_at_date']:.2f}",
            f"{avg:.4f}",
        ])
    w.writerow([])
    w.writerow(['Total', '', '', '', '', f"{total_cb:.2f}", ''])
    return Response(out.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition': f'attachment; filename=holdings_{snap_date}.csv'})


# ── Parcels (purchases) ────────────────────────────────────────────────────────

@app.route("/api/parcels", methods=["GET"])
def api_parcels_list():
    sid = request.args.get("security_id", type=int)
    open_only = request.args.get("open_only", "0") == "1"
    return ok(get_parcels(db(), security_id=sid, open_only=open_only))


@app.route("/api/parcels", methods=["POST"])
def api_parcels_create():
    d = request.json or {}
    try:
        pid = add_parcel(
            db(),
            security_id=int(d["security_id"]),
            acquisition_date=d["acquisition_date"],
            quantity=float(d["quantity"]),
            price_per_unit=float(d["price_per_unit"]),
            brokerage=float(d.get("brokerage", 0)),
            other_costs=float(d.get("other_costs", 0)),
            notes=d.get("notes", ""),
        )
        return ok({"id": pid})
    except (KeyError, ValueError) as e:
        return err(str(e))


@app.route("/api/parcels/<int:parcel_id>", methods=["GET"])
def api_parcel_get(parcel_id):
    p = get_parcel(db(), parcel_id)
    return ok(p) if p else err("Not found", 404)


@app.route("/api/parcels/<int:parcel_id>", methods=["PUT"])
def api_parcel_update(parcel_id):
    d = request.json or {}
    try:
        update_parcel(
            db(), parcel_id,
            acquisition_date=d["acquisition_date"],
            quantity=float(d["quantity"]),
            price_per_unit=float(d["price_per_unit"]),
            brokerage=float(d.get("brokerage", 0)),
            other_costs=float(d.get("other_costs", 0)),
            notes=d.get("notes", ""),
        )
        return ok()
    except (KeyError, ValueError) as e:
        return err(str(e))


@app.route("/api/parcels/<int:parcel_id>", methods=["DELETE"])
def api_parcel_delete(parcel_id):
    try:
        delete_parcel(db(), parcel_id)
        return ok()
    except ValueError as e:
        return err(str(e))


# ── Sales ──────────────────────────────────────────────────────────────────────

@app.route("/api/sales", methods=["GET"])
def api_sales_list():
    sid = request.args.get("security_id", type=int)
    return ok(get_sales(db(), security_id=sid))


@app.route("/api/sales", methods=["POST"])
def api_sales_create():
    d = request.json or {}
    try:
        sale_id = add_sale(
            db(),
            security_id=int(d["security_id"]),
            sale_date=d["sale_date"],
            quantity=float(d["quantity"]),
            price_per_unit=float(d["price_per_unit"]),
            brokerage=float(d.get("brokerage", 0)),
            cgt_method=d.get("cgt_method", "fifo"),
            notes=d.get("notes", ""),
            parcel_ids=d.get("parcel_ids") or None,
        )
        return ok({"id": sale_id})
    except (KeyError, ValueError) as e:
        return err(str(e))


@app.route("/api/sales/<int:sale_id>", methods=["GET"])
def api_sale_get(sale_id):
    s = get_sale(db(), sale_id)
    return ok(s) if s else err("Not found", 404)


@app.route("/api/sales/<int:sale_id>", methods=["PUT"])
def api_sale_update(sale_id):
    d = request.json or {}
    try:
        update_sale(
            db(), sale_id,
            sale_date=d["sale_date"],
            quantity=float(d["quantity"]),
            price_per_unit=float(d["price_per_unit"]),
            brokerage=float(d.get("brokerage", 0)),
            cgt_method=d.get("cgt_method", "fifo"),
            notes=d.get("notes", ""),
            parcel_ids=d.get("parcel_ids") or None,
        )
        return ok()
    except (KeyError, ValueError) as e:
        return err(str(e))


@app.route("/api/sales/<int:sale_id>", methods=["DELETE"])
def api_sale_delete(sale_id):
    try:
        delete_sale(db(), sale_id)
        return ok()
    except ValueError as e:
        return err(str(e))


# ── Dividends ──────────────────────────────────────────────────────────────────

@app.route("/api/dividends", methods=["GET"])
def api_dividends_list():
    sid = request.args.get("security_id", type=int)
    fy  = request.args.get("fy", type=int)
    divs = get_dividends(db(), security_id=sid)
    if fy:
        fy_start = f"{fy - 1}-07-01"
        fy_end   = f"{fy}-06-30"
        divs = [d for d in divs if fy_start <= d['payment_date'] <= fy_end]
    return ok(divs)


@app.route("/api/dividends", methods=["POST"])
def api_dividends_create():
    d = request.json or {}
    try:
        fc = d.get("franking_credit")
        div_id = add_dividend(
            db(),
            security_id=int(d["security_id"]),
            payment_date=d["payment_date"],
            quantity_held=float(d["quantity_held"]),
            amount_per_share=float(d["amount_per_share"]),
            franking_pct=float(d.get("franking_pct", 0)),
            ex_date=d.get("ex_date"),
            is_drp=int(d.get("is_drp", 0)),
            drp_quantity=float(d["drp_quantity"]) if d.get("drp_quantity") else None,
            drp_price=float(d["drp_price"]) if d.get("drp_price") else None,
            notes=d.get("notes", ""),
            franking_credit=float(fc) if fc is not None and str(fc).strip() != '' else None,
        )
        return ok({"id": div_id})
    except (KeyError, ValueError) as e:
        return err(str(e))


@app.route("/api/dividends/<int:div_id>", methods=["GET"])
def api_dividend_get(div_id):
    d = get_dividend(db(), div_id)
    return ok(d) if d else err("Not found", 404)


@app.route("/api/dividends/<int:div_id>", methods=["PUT"])
def api_dividend_update(div_id):
    d = request.json or {}
    try:
        fc = d.get("franking_credit")
        update_dividend(
            db(), div_id,
            payment_date=d["payment_date"],
            quantity_held=float(d["quantity_held"]),
            amount_per_share=float(d["amount_per_share"]),
            franking_pct=float(d.get("franking_pct", 0)),
            ex_date=d.get("ex_date") or None,
            notes=d.get("notes", ""),
            franking_credit=float(fc) if fc is not None and str(fc).strip() != '' else None,
        )
        return ok()
    except (KeyError, ValueError) as e:
        return err(str(e))


@app.route("/api/dividends/<int:div_id>", methods=["DELETE"])
def api_dividend_delete(div_id):
    try:
        delete_dividend(db(), div_id)
        return ok()
    except ValueError as e:
        return err(str(e))


# ── Corporate actions ──────────────────────────────────────────────────────────

@app.route("/api/actions", methods=["GET"])
def api_actions_list():
    sid = request.args.get("security_id", type=int)
    return ok(get_corporate_actions(db(), security_id=sid))


@app.route("/api/actions", methods=["POST"])
def api_actions_create():
    d = request.json or {}
    try:
        action_id = apply_corporate_action(
            db(),
            security_id=int(d["security_id"]),
            action_date=d["action_date"],
            action_type=d["action_type"],
            ratio_from=float(d["ratio_from"]),
            ratio_to=float(d.get("ratio_to") or 0),
            description=d.get("description", ""),
            notes=d.get("notes", ""),
            new_security_id=int(d["new_security_id"]) if d.get("new_security_id") else None,
        )
        return ok({"id": action_id})
    except (KeyError, ValueError) as e:
        return err(str(e))


@app.route("/api/actions/<int:action_id>", methods=["DELETE"])
def api_action_delete(action_id):
    try:
        delete_corporate_action(db(), action_id)
        return ok()
    except ValueError as e:
        return err(str(e))


# ── Prices ─────────────────────────────────────────────────────────────────────

@app.route("/api/prices", methods=["GET"])
def api_prices_get():
    return ok(get_prices(db()))


@app.route("/api/prices/refresh", methods=["POST"])
def api_prices_refresh():
    securities = get_securities(db())
    prices = fetch_prices(db(), securities)
    return ok({str(k): v for k, v in prices.items()})


@app.route("/api/prices/history", methods=["GET"])
def api_prices_history():
    sid    = request.args.get("security_id", type=int)
    period = request.args.get("period", "6mo")
    if not sid:
        return err("security_id required")
    return ok(get_price_history(db(), sid, period))


# ── Performance ─────────────────────────────────────────────────────────────────

@app.route("/api/performance", methods=["GET"])
def api_performance():
    return ok(get_performance(db()))


# ── Portfolio switcher ─────────────────────────────────────────────────────────

@app.route("/api/portfolio/list", methods=["GET"])
def api_portfolio_list():
    import glob as _glob
    base = os.path.dirname(os.path.abspath(DB_PATH))
    files = sorted(_glob.glob(os.path.join(base, "*.dinv")))
    return ok([{
        'path': f,
        'name': os.path.basename(f),
        'active': os.path.abspath(f) == os.path.abspath(DB_PATH),
    } for f in files])


@app.route("/api/portfolio/switch", methods=["POST"])
def api_portfolio_switch():
    global DB_PATH
    d    = request.json or {}
    path = d.get('path', '')
    if not path or not os.path.exists(path):
        return err("Portfolio file not found")
    if not path.endswith('.dinv'):
        return err("Not a .dinv file")
    base = os.path.dirname(os.path.abspath(DB_PATH))
    if os.path.dirname(os.path.abspath(path)) != base:
        return err("Can only switch to portfolios in the same directory")
    DB_PATH = os.path.abspath(path)
    app.config['DB_PATH'] = DB_PATH
    from core.database import initialise_database
    initialise_database(DB_PATH)
    return ok({'name': os.path.basename(DB_PATH)})


@app.route("/api/portfolio/new", methods=["POST"])
def api_portfolio_new():
    global DB_PATH
    d    = request.json or {}
    name = d.get('name', '').strip()
    if not name:
        return err("Portfolio name is required")
    safe = ''.join(c for c in name if c.isalnum() or c in ' _-').strip()
    if not safe:
        return err("Invalid portfolio name — use letters, numbers, spaces, hyphens")
    base     = os.path.dirname(os.path.abspath(DB_PATH))
    filename = safe.replace(' ', '_') + '.dinv'
    path     = os.path.join(base, filename)
    if os.path.exists(path):
        return err(f"{filename} already exists")
    from core.database import initialise_database
    initialise_database(path)
    DB_PATH = path
    app.config['DB_PATH'] = path
    return ok({'name': filename, 'path': path})


# ── CSV Export ──────────────────────────────────────────────────────────────────

@app.route("/api/export/cgt.csv")
def api_export_cgt_csv():
    from datetime import date as _d
    fy = request.args.get("fy", type=int, default=0)
    if not fy:
        t = _d.today()
        fy = t.year if t.month >= 7 else t.year
    rows = get_cgt_summary(db(), fy)
    roc_rows = get_roc_cgt(db(), fy)
    carryforward = compute_cgt_carryforward(db(), fy)['carry_forward']
    settings = get_settings(db())
    entity_type = settings.get('entity_type', 'individual')
    disc_label = {
        'individual':        'CGT discount (50%)',
        'smsf_accumulation': 'CGT discount (1/3)',
        'smsf_pension':      'CGT discount (100% pension exempt)',
        'company':           'CGT discount (none — company)',
    }.get(entity_type, 'CGT discount (50%)')
    disc_factor = {'individual': 0.5, 'smsf_accumulation': 1/3, 'smsf_pension': 1.0, 'company': 0.0}[entity_type]
    today_str = _d.today().strftime('%d/%m/%Y')
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(['sharetrack — Capital Gains Tax Schedule'])
    w.writerow([f'Financial Year: FY{fy} (1 July {fy-1} – 30 June {fy})'])
    w.writerow([f'Generated: {today_str}'])
    w.writerow([])
    w.writerow(['Asset Description', 'Date Acquired', 'Date Disposed',
                'Capital Proceeds', 'Cost Base',
                'Capital Gain', 'Capital Loss',
                'Discount Eligible', 'Taxable Amount'])
    total_gains = 0.0
    total_losses = 0.0
    total_discount = 0.0
    for r in rows:
        gain  = r['gain_loss'] if r['gain_loss'] > 0 else 0.0
        loss  = abs(r['gain_loss']) if r['gain_loss'] < 0 else 0.0
        taxable = r['discounted_gain'] if r['discounted_gain'] is not None else r['gain_loss']
        disc_amt = gain - taxable if r['discount_eligible'] and gain > 0 else 0.0
        total_gains   += gain
        total_losses  += loss
        total_discount += disc_amt
        w.writerow([
            f"{r['quantity']} {r['code']} ordinary shares acquired {r['acquisition_date']}",
            r['acquisition_date'], r['sale_date'],
            f"{r['net_proceeds']:.2f}", f"{r['cost_base_used']:.2f}",
            f"{gain:.2f}" if gain else '',
            f"{loss:.2f}" if loss else '',
            'Yes' if r['discount_eligible'] else 'No',
            f"{taxable:.2f}",
        ])
    # ROC capital gains
    roc_gross = 0.0
    roc_disc  = 0.0
    if roc_rows:
        w.writerow([])
        w.writerow(['Return of Capital — Cost Base Exceeded'])
        w.writerow(['Asset', 'Action Date', 'Acquired', '', '', 'Excess CG', '', 'Discount Eligible', 'Taxable Amount'])
        for r in roc_rows:
            roc_gross += r['excess_cg']
            disc = r['excess_cg'] * disc_factor if r['discount_eligible'] else 0.0
            roc_disc  += disc
            taxable = r['excess_cg'] - disc
            w.writerow([
                f"{r['code']} — {r['description'] or 'Return of capital'}",
                r['action_date'], r['acquisition_date'], '', '',
                f"{r['excess_cg']:.2f}", '',
                'Yes' if r['discount_eligible'] else 'No',
                f"{taxable:.2f}",
            ])
    net_sales = total_gains - total_losses - total_discount
    net_roc   = roc_gross - roc_disc
    net_gain  = net_sales + net_roc
    carry_used   = min(carryforward, max(net_gain, 0))
    net_taxable  = max(net_gain - carry_used, 0)
    ato_18h      = total_gains + roc_gross
    w.writerow([])
    w.writerow(['SUMMARY'])
    w.writerow(['Total current year capital gains (disposals)', f"{total_gains:.2f}"])
    if roc_gross > 0:
        w.writerow(['Return of capital gains (gross)', f"{roc_gross:.2f}"])
    w.writerow(['Total capital losses', f"{total_losses:.2f}"])
    w.writerow([disc_label, f"{total_discount + roc_disc:.2f}"])
    w.writerow(['Net capital gain (before carry-forward)', f"{max(net_gain, 0):.2f}"])
    if net_gain < 0:
        w.writerow(['Current year net capital loss', f"{abs(net_gain):.2f}"])
    if carryforward > 0:
        w.writerow(['Prior year carry-forward loss applied', f"{carry_used:.2f}"])
    w.writerow([])
    w.writerow(['ATO Individual Tax Return — Item 18'])
    w.writerow(['18H — Total current year capital gains (before discount and losses)', f"{ato_18h:.2f}"])
    w.writerow(['18A — Net capital gain (assessable)', f"{net_taxable:.2f}"])
    if carryforward > carry_used:
        w.writerow(['    Carry-forward loss remaining', f"{carryforward - carry_used:.2f}"])
    if net_gain < 0:
        w.writerow(['    Current year loss added to carry-forward', f"{abs(net_gain):.2f}"])
    return Response(out.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition': f'attachment; filename=cgt_schedule_fy{fy}.csv'})


@app.route("/api/export/income.csv")
def api_export_income_csv():
    from datetime import date as _d
    fy = request.args.get("fy", type=int, default=0)
    if not fy:
        t = _d.today()
        fy = t.year if t.month >= 7 else t.year
    fy_start = f"{fy - 1}-07-01"
    fy_end   = f"{fy}-06-30"
    divs = [d for d in get_dividends(db()) if fy_start <= d['payment_date'] <= fy_end]
    divs.sort(key=lambda d: d['payment_date'])
    today_str = _d.today().strftime('%d/%m/%Y')
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(['sharetrack — Dividend Income Report'])
    w.writerow([f'Financial Year: FY{fy} (1 July {fy-1} – 30 June {fy})'])
    w.writerow([f'Generated: {today_str}'])
    w.writerow([])
    w.writerow(['Payment Date', 'Code', 'Security Name', 'Shares Held',
                'Amount Per Share', 'Net Dividend', 'Franking %',
                'Franking Credit', '45-Day Eligible', 'Gross Income (Assessable)'])
    tot_net = 0.0; tot_frank = 0.0; tot_gross = 0.0
    for d in divs:
        net   = d['net_amount'] or 0.0
        frank = d['franking_credit'] or 0.0
        gross = net + frank
        tot_net += net; tot_frank += frank; tot_gross += gross
        eligible = d.get('eligible_45day')
        eligible_str = 'Yes' if eligible is True else ('No' if eligible is False else 'Unverified')
        w.writerow([
            d['payment_date'], d['code'], d['name'],
            d['quantity_held'], f"{d['amount_per_share']:.4f}",
            f"{net:.2f}", f"{d['franking_pct'] or 0:.0f}%",
            f"{frank:.2f}", eligible_str, f"{gross:.2f}",
        ])
    # ATO Item 11 totals
    is_franked = lambda d: (d.get('franking_pct') or 0) > 0 or (d.get('franking_credit') or 0) > 0
    ato_11j = sum((d.get('net_amount') or 0) for d in divs if not is_franked(d))
    ato_11k = sum((d.get('net_amount') or 0) for d in divs if is_franked(d))
    frank_eligible   = sum((d.get('franking_credit') or 0) for d in divs if d.get('eligible_45day') is True)
    frank_ineligible = sum((d.get('franking_credit') or 0) for d in divs if d.get('eligible_45day') is False)
    frank_unknown    = sum((d.get('franking_credit') or 0) for d in divs if d.get('eligible_45day') is None)
    w.writerow([])
    w.writerow(['TOTALS', '', '', '', '', f"{tot_net:.2f}", '',
                f"{tot_frank:.2f}", '', f"{tot_gross:.2f}"])
    w.writerow([])
    w.writerow(['ATO Individual Tax Return — Item 11'])
    w.writerow(['11J — Unfranked dividend amount', f"{ato_11j:.2f}"])
    w.writerow(['11K — Franked dividend amount', f"{ato_11k:.2f}"])
    w.writerow(['11L — Franking credit tax offset (eligible only)', f"{frank_eligible:.2f}"])
    if frank_ineligible > 0:
        w.writerow(['    Excluded — 45-day rule not satisfied', f"{frank_ineligible:.2f}"])
    if frank_unknown > 0:
        w.writerow(['    Unverified — no ex-dividend date recorded', f"{frank_unknown:.2f}"])
    w.writerow(['    Assessable income (11J + 11K + 11L)', f"{ato_11j + ato_11k + frank_eligible:.2f}"])
    return Response(out.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition': f'attachment; filename=income_fy{fy}.csv'})


@app.route("/api/export/tax-summary.csv")
def api_export_tax_summary_csv():
    from datetime import date as _d
    fy = request.args.get("fy", type=int, default=0)
    if not fy:
        t = _d.today()
        fy = t.year if t.month >= 7 else t.year
    fy_start = f"{fy - 1}-07-01"
    fy_end   = f"{fy}-06-30"

    divs     = [d for d in get_dividends(db()) if fy_start <= d['payment_date'] <= fy_end]
    cgt_rows = get_cgt_summary(db(), fy)
    roc_rows = get_roc_cgt(db(), fy)
    cf_data  = compute_cgt_carryforward(db(), fy)
    carryforward = cf_data['carry_forward'] or 0.0
    settings     = get_settings(db())
    entity_type  = settings.get('entity_type', 'individual')
    entity_label = {
        'individual':        'Individual',
        'smsf_accumulation': 'SMSF (Accumulation Phase)',
        'smsf_pension':      'SMSF (Pension Phase)',
        'company':           'Company',
    }.get(entity_type, 'Individual')
    disc_factor = {'individual': 0.5, 'smsf_accumulation': 1/3, 'smsf_pension': 1.0, 'company': 0.0}[entity_type]
    is_exempt   = entity_type == 'smsf_pension'
    today_str   = _d.today().strftime('%d/%m/%Y')

    # ── Item 11 calcs ──────────────────────────────────────────────────────────
    is_franked = lambda d: (d.get('franking_pct') or 0) > 0 or (d.get('franking_credit') or 0) > 0
    ato_11j          = sum((d.get('net_amount') or 0) for d in divs if not is_franked(d))
    ato_11k          = sum((d.get('net_amount') or 0) for d in divs if is_franked(d))
    frank_eligible   = sum((d.get('franking_credit') or 0) for d in divs if d.get('eligible_45day') is True)
    frank_ineligible = sum((d.get('franking_credit') or 0) for d in divs if d.get('eligible_45day') is False)
    frank_unknown    = sum((d.get('franking_credit') or 0) for d in divs if d.get('eligible_45day') is None)
    ato_11l          = frank_eligible
    div_assessable   = ato_11j + ato_11k + ato_11l

    # ── Item 18 calcs ──────────────────────────────────────────────────────────
    total_gains = total_losses = total_discount = 0.0
    for r in cgt_rows:
        gain  = r['gain_loss'] if r['gain_loss'] > 0 else 0.0
        loss  = abs(r['gain_loss']) if r['gain_loss'] < 0 else 0.0
        taxable = r['discounted_gain'] if r['discounted_gain'] is not None else r['gain_loss']
        disc_amt = gain - taxable if r['discount_eligible'] and gain > 0 else 0.0
        total_gains    += gain
        total_losses   += loss
        total_discount += disc_amt
    roc_gross = sum(r['excess_cg'] for r in roc_rows)
    roc_disc  = sum(r['excess_cg'] * disc_factor for r in roc_rows if r['discount_eligible'])
    net_sales    = total_gains - total_losses - total_discount
    net_roc      = roc_gross - roc_disc
    combined     = net_sales + net_roc
    carry_used   = min(carryforward, max(combined, 0))
    ato_18a      = max(combined - carry_used, 0)
    ato_18h      = total_gains + roc_gross
    net_loss_amt = max(-combined, 0)
    total_assessable = div_assessable + ato_18a

    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(['sharetrack — FY Tax Summary'])
    w.writerow([f'Financial Year: FY{fy} (1 July {fy-1} – 30 June {fy})'])
    w.writerow([f'Entity: {entity_label}'])
    w.writerow([f'Generated: {today_str}'])
    w.writerow(['Summary only — verify figures with your accountant before lodging.'])
    w.writerow([])

    # Item 11
    w.writerow(['DIVIDEND INCOME — ATO Individual Tax Return Item 11'])
    w.writerow(['11J — Unfranked dividend amount', f"{ato_11j:.2f}"])
    w.writerow(['11K — Franked dividend amount', f"{ato_11k:.2f}"])
    w.writerow(['11L — Franking credit tax offset', f"{ato_11l:.2f}"])
    if frank_ineligible > 0:
        w.writerow(['    Excluded (45-day rule not satisfied)', f"{frank_ineligible:.2f}"])
    if frank_unknown > 0:
        w.writerow(['    Unverified (no ex-dividend date — excluded from 11L)', f"{frank_unknown:.2f}"])
    w.writerow(['    Assessable dividend income (11J + 11K + 11L)', f"{div_assessable:.2f}"])
    w.writerow([])

    # Item 18
    w.writerow(['CAPITAL GAINS — ATO Individual Tax Return Item 18'])
    if not cgt_rows and not roc_rows:
        w.writerow(['No disposals recorded for this financial year.'])
    else:
        if total_gains > 0:
            w.writerow(['Gross gains from disposals', f"{total_gains:.2f}"])
        if total_losses > 0:
            w.writerow(['Capital losses from disposals', f"{total_losses:.2f}"])
        if total_discount > 0:
            w.writerow(['CGT discount applied', f"{total_discount:.2f}"])
        if roc_gross > 0:
            w.writerow(['Return of capital gains (gross)', f"{roc_gross:.2f}"])
            if roc_disc > 0:
                w.writerow(['    Less CGT discount', f"{roc_disc:.2f}"])
        if carryforward > 0:
            w.writerow(['Prior year carry-forward loss applied', f"{carry_used:.2f}"])
        w.writerow(['18H — Total current year capital gains (before discount/losses)', f"{ato_18h:.2f}"])
        w.writerow(['18A — Net capital gain (assessable)', f"{ato_18a:.2f}"])
        if net_loss_amt > 0:
            w.writerow(['    Current year net capital loss (carried forward)', f"{net_loss_amt:.2f}"])
        if carryforward > carry_used:
            w.writerow(['    Prior year carry-forward loss remaining', f"{carryforward - carry_used:.2f}"])
    w.writerow([])

    # Combined
    w.writerow(['TOTAL ASSESSABLE INVESTMENT INCOME'])
    w.writerow(['Assessable dividend income', f"{div_assessable:.2f}"])
    w.writerow(['Net capital gain (Item 18A)', f"{ato_18a:.2f}"])
    w.writerow(['Total', f"{total_assessable:.2f}"])
    if ato_11l > 0:
        w.writerow(['Franking credit tax offset (Item 11L)', f"{ato_11l:.2f}"])
        w.writerow(['    Enter as a tax offset in your return — reduces tax payable.'])
    return Response(out.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition': f'attachment; filename=tax_summary_fy{fy}.csv'})


@app.route("/api/cost-base-reconciliation", methods=["GET"])
def api_cb_reconciliation():
    fy = request.args.get('fy', type=int)
    if not fy:
        return err("fy parameter required")
    return ok(get_cost_base_reconciliation(db(), fy))


@app.route("/api/export/cost-base-recon.csv", methods=["GET"])
def api_export_cb_recon_csv():
    fy = request.args.get('fy', type=int)
    if not fy:
        return err("fy parameter required")
    rows = get_cost_base_reconciliation(db(), fy)
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow([f'Cost Base Reconciliation — FY{fy} (1 Jul {fy-1} – 30 Jun {fy})'])
    w.writerow([])
    w.writerow([
        'Code', 'Name',
        'Opening CB',
        'Purchases', 'DRP', 'Rights Issues', 'Bonus Issues', 'Demerger Receipt',
        'Total Additions',
        'Disposals', 'Return of Capital', 'Demerger Out',
        'Total Reductions',
        'Computed Closing CB', 'Actual Closing CB', 'Reconciles',
    ])
    for r in rows:
        a, red = r['additions'], r['reductions']
        w.writerow([
            r['code'], r['name'],
            f"{r['opening_cb']:.2f}",
            f"{a['purchases']:.2f}", f"{a['drp']:.2f}", f"{a['rights_issues']:.2f}",
            f"{a['bonus_issues']:.2f}", f"{a['demerger_receipt']:.2f}",
            f"{a['total']:.2f}",
            f"{red['disposals']:.2f}", f"{red['return_of_capital']:.2f}",
            f"{red['demerger_out']:.2f}",
            f"{red['total']:.2f}",
            f"{r['computed_close']:.2f}", f"{r['actual_close']:.2f}",
            'Yes' if r['reconciles'] else 'No',
        ])
    return Response(out.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition': f'attachment; filename=cost_base_recon_fy{fy}.csv'})


@app.route("/api/export/transactions.csv")
def api_export_transactions_csv():
    parcels = get_parcels(db())
    sales   = get_sales(db())
    divs    = get_dividends(db())
    rows = []
    for p in parcels:
        rows.append(('Buy', p['acquisition_date'], p['code'], p['quantity'],
                     p['price_per_unit'], p['brokerage'], '', p['cost_base'], p['notes'] or ''))
    for s in sales:
        rows.append(('Sell', s['sale_date'], s['code'], s['quantity'],
                     s['price_per_unit'], s['brokerage'], '', s['net_proceeds'], s['notes'] or ''))
    for d in divs:
        rows.append(('Dividend', d['payment_date'], d['code'], d['quantity_held'],
                     d['amount_per_share'], 0, d['franking_pct'], d['gross_amount'], d['notes'] or ''))
    rows.sort(key=lambda r: r[1])
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(['Type', 'Date', 'Code', 'Quantity', 'Price', 'Brokerage', 'Franking%', 'Amount', 'Notes'])
    w.writerows(rows)
    return Response(out.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition': 'attachment; filename=transactions.csv'})


@app.route("/api/export/template.csv")
def api_export_template_csv():
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(['Date', 'Code', 'Type', 'Quantity', 'Price', 'Brokerage', 'Franking%', 'Notes'])
    w.writerow(['2024-01-15', 'CBA', 'Buy',      '100', '95.50', '19.95', '0',   'Initial purchase'])
    w.writerow(['2024-03-01', 'CBA', 'Dividend',  '100', '0.42',  '0',    '100', 'Q3 dividend'])
    w.writerow(['2024-06-15', 'CBA', 'Sell',       '50', '105.00','19.95', '0',   'Partial sale'])
    return Response(out.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition': 'attachment; filename=dogbox_securities_template.csv'})


# ── Import ──────────────────────────────────────────────────────────────────────

@app.route("/api/import/preview", methods=["POST"])
def api_import_preview():
    if 'file' not in request.files:
        return err("No file uploaded")
    content = request.files['file'].read().decode('utf-8-sig')
    securities = {s['code'].upper(): s for s in get_securities(db())}
    force_fmt = request.form.get('format') or None
    try:
        parsed, errors, fmt = parse_broker_csv(content, securities, force_format=force_fmt)
    except Exception as e:
        return err(str(e))
    return ok({
        'rows': parsed,
        'errors': errors,
        'format': fmt,
        'format_label': FORMAT_LABELS.get(fmt, fmt),
    })


@app.route("/api/import/commit", methods=["POST"])
def api_import_commit():
    rows = (request.json or {}).get('rows', [])
    done, skipped, failed = 0, 0, []
    for r in rows:
        if not r.get('security_id'):
            skipped += 1
            continue
        try:
            if r['type'] == 'Buy':
                add_parcel(db(), security_id=r['security_id'], acquisition_date=r['date'],
                           quantity=r['quantity'], price_per_unit=r['price'],
                           brokerage=r['brokerage'], notes=r['notes'])
            elif r['type'] == 'Sell':
                add_sale(db(), security_id=r['security_id'], sale_date=r['date'],
                         quantity=r['quantity'], price_per_unit=r['price'],
                         brokerage=r['brokerage'], notes=r['notes'])
            elif r['type'] == 'Dividend':
                add_dividend(db(), security_id=r['security_id'], payment_date=r['date'],
                             quantity_held=r['quantity'], amount_per_share=r['price'],
                             franking_pct=r['franking_pct'], notes=r['notes'])
            done += 1
        except Exception as e:
            failed.append({'row': r.get('row'), 'error': str(e)})
    return ok({'imported': done, 'skipped': skipped, 'failed': failed})


# ── CGT ────────────────────────────────────────────────────────────────────────

@app.route("/api/cgt", methods=["GET"])
def api_cgt():
    try:
        fy = int(request.args.get("fy", 0))
        if not fy:
            from datetime import date
            today = date.today()
            fy = today.year if today.month >= 7 else today.year
        return ok(get_cgt_summary(db(), fy))
    except ValueError as e:
        return err(str(e))


@app.route("/api/roc-cgt", methods=["GET"])
def api_roc_cgt():
    try:
        fy = int(request.args.get("fy", 0))
        if not fy:
            from datetime import date
            today = date.today()
            fy = today.year if today.month >= 7 else today.year
        return ok(get_roc_cgt(db(), fy))
    except ValueError as e:
        return err(str(e))


@app.route("/api/cgt-carryforward", methods=["GET"])
def api_cgt_carryforward():
    try:
        fy = int(request.args.get("fy", 0))
        if not fy:
            from datetime import date
            today = date.today()
            fy = today.year + 1 if today.month >= 7 else today.year
        return ok(compute_cgt_carryforward(db(), fy))
    except ValueError as e:
        return err(str(e))


# ── Settings ───────────────────────────────────────────────────────────────────

@app.route("/api/settings", methods=["GET"])
def api_settings_get():
    return ok(get_settings(db()))


@app.route("/api/settings", methods=["POST"])
def api_settings_set():
    d = request.json or {}
    for k, v in d.items():
        set_setting(db(), k, v)
    return ok()


@app.route("/api/settings/lock-fy", methods=["POST"])
def api_lock_fy():
    d = request.json or {}
    fy = d.get("fy")
    if not fy:
        return err("fy is required")
    try:
        fy_int = int(fy)
    except (TypeError, ValueError):
        return err("fy must be an integer year")
    set_setting(db(), "locked_fy", str(fy_int))
    return ok({"locked_fy": fy_int})


@app.route("/api/settings/lock-fy", methods=["DELETE"])
def api_unlock_fy():
    set_setting(db(), "locked_fy", "")
    return ok()


# ── Watch list ─────────────────────────────────────────────────────────────────

@app.route("/api/watchlist", methods=["GET"])
def api_watchlist_list():
    return ok(get_watchlist(db()))


@app.route("/api/watchlist", methods=["POST"])
def api_watchlist_create():
    d = request.json or {}
    try:
        item_id = add_watchlist_item(
            db(),
            security_id=int(d["security_id"]),
            target_buy=float(d["target_buy"]) if d.get("target_buy") else None,
            target_sell=float(d["target_sell"]) if d.get("target_sell") else None,
            notes=d.get("notes", ""),
        )
        return ok({"id": item_id})
    except (KeyError, ValueError) as e:
        return err(str(e))


@app.route("/api/watchlist/<int:item_id>", methods=["PUT"])
def api_watchlist_update(item_id):
    d = request.json or {}
    try:
        update_watchlist_item(
            db(), item_id,
            target_buy=float(d["target_buy"]) if d.get("target_buy") else None,
            target_sell=float(d["target_sell"]) if d.get("target_sell") else None,
            notes=d.get("notes", ""),
        )
        return ok()
    except (KeyError, ValueError) as e:
        return err(str(e))


@app.route("/api/watchlist/<int:item_id>", methods=["DELETE"])
def api_watchlist_delete(item_id):
    delete_watchlist_item(db(), item_id)
    return ok()


@app.route("/api/export/tax-summary-fy<int:fy>.pdf")
def api_export_tax_summary_pdf(fy):
    from core.pdf_export import build_tax_summary_pdf
    from datetime import date as _d
    fy_start = f"{fy - 1}-07-01"
    fy_end   = f"{fy}-06-30"
    divs     = [d for d in get_dividends(db()) if fy_start <= d['payment_date'] <= fy_end]
    cgt_rows = get_cgt_summary(db(), fy)
    roc_rows = get_roc_cgt(db(), fy)
    cf_data  = compute_cgt_carryforward(db(), fy)
    settings = get_settings(db())
    buf = build_tax_summary_pdf(fy, divs, cgt_rows, roc_rows, cf_data, settings)
    return Response(
        buf.getvalue(),
        mimetype='application/pdf',
        headers={'Content-Disposition': f'attachment; filename="tax-summary-fy{fy}.pdf"'},
    )


@app.route("/api/audit-log", methods=["GET"])
def api_audit_log():
    limit = int(request.args.get("limit", 200))
    return ok(get_audit_log(db(), limit))


@app.route("/api/shutdown", methods=["POST"])
def api_shutdown():
    def _exit():
        import time; time.sleep(0.4)
        _kill_browser()
        os._exit(0)
    threading.Thread(target=_exit, daemon=True).start()
    return ok()
