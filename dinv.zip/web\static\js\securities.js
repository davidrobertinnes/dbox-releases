// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — Securities master list */

async function pageSecurities() {
  const content = document.getElementById('module-content');
  content.innerHTML = `
    <div class="st-toolbar">
      <input class="st-search" id="sec-search" type="search" placeholder="Search securities…">
      <button class="btn btn-primary" onclick="_secOpenForm()">+ Add Security</button>
    </div>
    <div class="st-list-panel">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Code</th><th>Name</th><th>Exchange</th><th>Type</th><th>Currency</th><th>Status</th><th></th>
          </tr></thead>
          <tbody id="sec-tbody"></tbody>
        </table>
      </div>
    </div>
    <div class="count-pill" id="sec-count"></div>`;

  document.getElementById('sec-search').addEventListener('input', () => {
    const q = document.getElementById('sec-search').value.toLowerCase();
    let v = 0;
    document.querySelectorAll('#sec-tbody tr').forEach(r => {
      const show = r.textContent.toLowerCase().includes(q);
      r.style.display = show ? '' : 'none';
      if (show) v++;
    });
    document.getElementById('sec-count').textContent = `${v} of ${_secRows.length} securities`;
  });

  await _secLoad();
}

let _secRows = [];

async function _secLoad() {
  try {
    _secRows = await apiFetch('/api/securities?active_only=0');
    _secRender();
  } catch (e) {
    toast(e.message, 'err');
  }
}

function _secRender() {
  const tbody = document.getElementById('sec-tbody');
  if (!_secRows.length) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="st-empty">
      <div class="st-empty-icon">🏢</div>
      <div class="st-empty-title">No securities added</div>
      <div>Add an ASX code or other security to get started.</div>
    </div></td></tr>`;
    document.getElementById('sec-count').textContent = '0 securities';
    return;
  }
  const typeLabel = { share:'Share', etf:'ETF', lpt:'LPT/REIT', bond:'Bond', preference:'Preference Share', other:'Other' };
  // Active first, then inactive
  const sorted = [..._secRows].sort((a, b) => b.is_active - a.is_active || a.code.localeCompare(b.code));
  tbody.innerHTML = sorted.map(s => {
    const inactive = !s.is_active;
    return `<tr style="${inactive ? 'opacity:0.55' : 'cursor:pointer'}" ${inactive ? '' : `onclick="_secViewDetail(${s.id})"`}>
      <td class="code-cell">${s.code}</td>
      <td>${s.name}</td>
      <td class="mono">${s.exchange}</td>
      <td><span class="badge badge-ink">${typeLabel[s.security_type] || s.security_type}</span></td>
      <td class="mono">${s.currency}</td>
      <td>${inactive ? '<span class="badge badge-amber">Inactive</span>' : '<span class="badge badge-green">Active</span>'}</td>
      <td style="white-space:nowrap" onclick="event.stopPropagation()">
        <button class="btn btn-ghost btn-sm" onclick="_secOpenEditForm(${s.id})">Edit</button>
        <button class="btn btn-ghost btn-sm" style="color:${inactive ? 'var(--accent)' : 'var(--red)'}"
          onclick="_secToggleActive(${s.id}, ${s.is_active})">${inactive ? 'Activate' : 'Deactivate'}</button>
      </td>
    </tr>`;
  }).join('');
  document.getElementById('sec-count').textContent =
    `${_secRows.length} securit${_secRows.length !== 1 ? 'ies' : 'y'}`;
}

async function _secViewDetail(securityId) {
  await loadModule('security_detail');
  viewSecurity(securityId, 'securities');
}

// ── Toggle active ─────────────────────────────────────────────────────────────

async function _secToggleActive(id, currentActive) {
  const s = _secRows.find(r => r.id === id);
  if (!s) return;
  if (currentActive && !confirm(`Deactivate ${s.code}?\n\nIt will be hidden from transaction forms but all history is kept.`)) return;
  try {
    const r = await fetch(`/api/securities/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: s.name, exchange: s.exchange, security_type: s.security_type,
        currency: s.currency, notes: s.notes || '', is_active: currentActive ? 0 : 1,
      }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    toast(currentActive ? `${s.code} deactivated` : `${s.code} activated`);
    await _secLoad();
  } catch (e) {
    toast(e.message, 'err');
  }
}

// ── Add form ──────────────────────────────────────────────────────────────────

function _secOpenForm() {
  openPanel('Add Security', _secFormHtml(null),
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_secSave(null)">Add Security</button>`
  );
}

// ── Edit form ─────────────────────────────────────────────────────────────────

function _secOpenEditForm(id) {
  const s = _secRows.find(r => r.id === id);
  if (!s) return;
  openPanel(`Edit ${s.code}`, _secFormHtml(s),
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_secSave(${id})">Save Changes</button>`
  );
}

function _secFormHtml(s) {
  const isEdit = !!s;
  return `
    <div class="field-row cols-2">
      <div class="field">
        <label>Code</label>
        <input type="text" id="sec-code" value="${s?.code || ''}" placeholder="e.g. CBA"
          style="text-transform:uppercase" ${isEdit ? 'disabled' : ''}>
      </div>
      <div class="field">
        <label>Exchange</label>
        <select id="sec-exchange">
          ${['ASX','NYSE','NASDAQ','LSE','OTHER'].map(ex =>
            `<option ${(s?.exchange || 'ASX') === ex ? 'selected' : ''}>${ex}</option>`
          ).join('')}
        </select>
      </div>
    </div>
    <div class="field">
      <label>Name</label>
      <input type="text" id="sec-name" value="${s?.name || ''}" placeholder="Commonwealth Bank of Australia">
    </div>
    <div class="field-row cols-2">
      <div class="field">
        <label>Type</label>
        <select id="sec-type">
          ${[['share','Share'],['etf','ETF'],['lpt','LPT / REIT'],['bond','Bond'],['preference','Preference Share'],['other','Other']].map(([v,l]) =>
            `<option value="${v}" ${(s?.security_type || 'share') === v ? 'selected' : ''}>${l}</option>`
          ).join('')}
        </select>
      </div>
      <div class="field">
        <label>Currency</label>
        <select id="sec-currency">
          ${['AUD','USD','GBP','EUR'].map(c =>
            `<option ${(s?.currency || 'AUD') === c ? 'selected' : ''}>${c}</option>`
          ).join('')}
        </select>
      </div>
    </div>
    <div class="field">
      <label>Notes</label>
      <textarea id="sec-notes" placeholder="Optional">${s?.notes || ''}</textarea>
    </div>`;
}

async function _secSave(id) {
  const isEdit = id !== null;
  const code     = isEdit ? null : (document.getElementById('sec-code').value || '').trim().toUpperCase();
  const name     = (document.getElementById('sec-name').value || '').trim();
  const exchange = document.getElementById('sec-exchange').value;
  const security_type = document.getElementById('sec-type').value;
  const currency = document.getElementById('sec-currency').value;
  const notes    = document.getElementById('sec-notes').value;

  if (!isEdit && !code) return toast('Code is required', 'err');
  if (!name)            return toast('Name is required', 'err');

  try {
    if (isEdit) {
      const r = await fetch(`/api/securities/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, exchange, security_type, currency, notes }),
      }).then(r => r.json());
      if (!r.ok) throw new Error(r.error);
      closePanel();
      toast('Security updated');
    } else {
      const r = await fetch('/api/securities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, name, exchange, security_type, currency, notes }),
      }).then(r => r.json());
      if (!r.ok) throw new Error(r.error);
      closePanel();
      toast(`${code} added`);
    }
    await _secLoad();
  } catch (e) {
    toast(e.message, 'err');
  }
}
