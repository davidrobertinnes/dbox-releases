// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — Per-security detail view */

let _sd = {
  security:     null,
  parcels:      [],
  sales:        [],
  divs:         [],
  actions:      [],
  price:        null,
  back:         'portfolio',
  watchlistItem: null,
};

// ── Entry point ────────────────────────────────────────────────────────────────

async function viewSecurity(securityId, backModule = 'portfolio') {
  _sd.back = backModule;
  _currentModule = 'security_detail';
  document.getElementById('module-content').innerHTML =
    '<div class="st-empty"><div class="st-empty-icon">⏳</div>Loading…</div>';
  await _sdFetch(securityId);
  _sdRender();
}

async function _sdFetch(securityId) {
  const [securities, parcels, sales, divs, actions, prices, watchlist] = await Promise.all([
    apiFetch('/api/securities'),
    apiFetch(`/api/parcels?security_id=${securityId}`),
    apiFetch(`/api/sales?security_id=${securityId}`),
    apiFetch(`/api/dividends?security_id=${securityId}`),
    apiFetch(`/api/actions?security_id=${securityId}`),
    apiFetch('/api/prices'),
    apiFetch('/api/watchlist'),
  ]);
  _sd.security      = securities.find(s => s.id === securityId) || { id: securityId, code: '?', name: 'Unknown' };
  _sd.parcels       = parcels;
  _sd.sales         = sales;
  _sd.divs          = divs;
  _sd.actions       = actions;
  _sd.price         = prices[securityId]?.price ?? null;
  _sd.watchlistItem = watchlist.find(w => w.security_id === securityId) || null;
}

function _sdLoadChart(securityId) {
  const el = document.getElementById('sd-chart');
  if (!el) return;
  apiFetch(`/api/prices/history?security_id=${securityId}`)
    .then(data => { el.innerHTML = _sdDrawChart(data); })
    .catch(() => { el.innerHTML = ''; });
}

function _sdDrawChart(data) {
  if (!data || data.length < 5) return '';
  const prices = data.map(d => d.price);
  const W = 520, H = 72, pad = { t:8, b:18, l:4, r:4 };
  const iw = W - pad.l - pad.r, ih = H - pad.t - pad.b;
  const min = Math.min(...prices), max = Math.max(...prices);
  const range = max - min || 1;
  const n = prices.length;
  const pts = prices.map((p, i) => [
    pad.l + (i / (n - 1)) * iw,
    pad.t + ih - ((p - min) / range) * ih,
  ]);
  const isUp = prices[n-1] >= prices[0];
  const col  = isUp ? 'var(--green)' : 'var(--red)';
  const line = pts.map(([x,y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  const area = [
    `${pts[0][0].toFixed(1)},${(pad.t+ih).toFixed(1)}`,
    ...pts.map(([x,y]) => `${x.toFixed(1)},${y.toFixed(1)}`),
    `${pts[n-1][0].toFixed(1)},${(pad.t+ih).toFixed(1)}`,
  ].join(' ');
  const uid = `cg${Date.now()}`;
  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:${H}px;display:block">
    <defs>
      <linearGradient id="${uid}" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${col}" stop-opacity="0.18"/>
        <stop offset="100%" stop-color="${col}" stop-opacity="0"/>
      </linearGradient>
    </defs>
    <polygon points="${area}" fill="url(#${uid})"/>
    <polyline points="${line}" fill="none" stroke="${col}" stroke-width="1.5"/>
    <text x="${pad.l+1}" y="${H-3}" font-size="9" fill="var(--ink3)" font-family="'DM Mono',monospace">${fmtCurrency(prices[0])}</text>
    <text x="${W-pad.r-1}" y="${H-3}" text-anchor="end" font-size="9" fill="var(--ink3)" font-family="'DM Mono',monospace">${fmtCurrency(prices[n-1])}</text>
    <text x="${W/2}" y="${H-3}" text-anchor="middle" font-size="9" fill="var(--ink3)" font-family="'DM Mono',monospace">6 months</text>
  </svg>`;
}

async function _sdRefresh() {
  await _sdFetch(_sd.security.id);
  _sdRender();
}

// ── Main render ────────────────────────────────────────────────────────────────

function _sdRender() {
  const sec = _sd.security;
  const openParcels  = _sd.parcels.filter(p => p.quantity_remaining > 0);
  const totalQty     = openParcels.reduce((s, p) => s + p.quantity_remaining, 0);
  const totalCB      = openParcels.reduce((s, p) => s + p.cost_base * (p.quantity_remaining / p.quantity), 0);
  const avgCost      = totalQty > 0 ? totalCB / totalQty : 0;
  const divIncome    = _sd.divs.reduce((s, d) => s + (d.net_amount || 0), 0);
  const saleProceeds = _sd.sales.reduce((s, sa) => s + (sa.net_proceeds || 0), 0);
  const typeLabel    = { share:'Share', etf:'ETF', lpt:'LPT/REIT', bond:'Bond', preference:'Preference Share', other:'Other' };

  const currentPrice = _sd.price;
  const mktVal       = currentPrice !== null && totalQty > 0 ? currentPrice * totalQty : null;
  const unrealisedPnl = mktVal !== null ? mktVal - totalCB : null;
  const oneYearAgo   = new Date(); oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
  const annualDPS    = _sd.divs
    .filter(d => new Date(d.payment_date) >= oneYearAgo)
    .reduce((s, d) => s + (d.amount_per_share || 0), 0);
  const yieldPct     = currentPrice > 0 && annualDPS > 0 ? annualDPS / currentPrice * 100 : null;

  document.getElementById('module-content').innerHTML = `
    <div style="margin-bottom:16px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <button class="btn btn-ghost btn-sm" onclick="navigate('${_sd.back}')">&larr; Back</button>
        ${_sd.watchlistItem
          ? `<button class="btn btn-ghost btn-sm" style="color:var(--ink3)" onclick="_sdToggleWatch()" id="sd-watch-btn">👁 Watching</button>`
          : `<button class="btn btn-ghost btn-sm" onclick="_sdToggleWatch()" id="sd-watch-btn">+ Watch</button>`}
      </div>
      <div style="display:flex;align-items:baseline;gap:12px;flex-wrap:wrap">
        <span style="font-family:'Syne',sans-serif;font-size:24px;font-weight:800;letter-spacing:-0.5px;color:var(--accent)">${sec.code}</span>
        <span style="font-size:16px;font-weight:600;color:var(--ink)">${sec.name}</span>
        <span style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3)">${sec.exchange} &middot; ${typeLabel[sec.security_type] || sec.security_type} &middot; ${sec.currency}</span>
      </div>
    </div>

    <div class="st-kpi-strip">
      <div class="st-kpi">
        <div class="st-kpi-label">Qty Held</div>
        <div class="st-kpi-value col-ink">${totalQty > 0 ? fmtNum(totalQty, 4) : '—'}</div>
        <div class="st-kpi-sub">${openParcels.length} open parcel${openParcels.length !== 1 ? 's' : ''}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Avg Cost</div>
        <div class="st-kpi-value col-ink">${totalQty > 0 ? fmtCurrency(avgCost) : '—'}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Total Cost Base</div>
        <div class="st-kpi-value col-ink">${totalQty > 0 ? fmtCurrency(totalCB) : '—'}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Dividend Income</div>
        <div class="st-kpi-value col-green">${fmtCurrency(divIncome)}</div>
        <div class="st-kpi-sub">${_sd.divs.length} payment${_sd.divs.length !== 1 ? 's' : ''}</div>
      </div>
      ${_sd.sales.length ? `
      <div class="st-kpi">
        <div class="st-kpi-label">Sale Proceeds</div>
        <div class="st-kpi-value col-amber">${fmtCurrency(saleProceeds)}</div>
        <div class="st-kpi-sub">${_sd.sales.length} disposal${_sd.sales.length !== 1 ? 's' : ''}</div>
      </div>` : ''}
      ${currentPrice !== null ? `
      <div class="st-kpi">
        <div class="st-kpi-label">Current Price</div>
        <div class="st-kpi-value col-ink">${fmtCurrency(currentPrice)}</div>
        ${yieldPct !== null ? `<div class="st-kpi-sub">${yieldPct.toFixed(2)}% trailing yield</div>` : ''}
      </div>` : ''}
      ${mktVal !== null ? `
      <div class="st-kpi">
        <div class="st-kpi-label">Market Value</div>
        <div class="st-kpi-value col-ink">${fmtCurrency(mktVal)}</div>
        <div class="st-kpi-sub ${gainClass(unrealisedPnl)}">${unrealisedPnl >= 0 ? '+' : ''}${fmtCurrency(unrealisedPnl)} P&amp;L</div>
      </div>` : ''}
    </div>

    <div id="sd-chart" style="margin:8px 0 16px;border-radius:8px;overflow:hidden"></div>

    ${_sdParcelsSection()}
    ${_sdSalesSection()}
    ${_sdDivsSection()}
    ${_sdActionsSection()}`;

  _sdLoadChart(_sd.security.id);
}

// ── Parcels section ────────────────────────────────────────────────────────────

function _sdParcelsSection() {
  const rows = _sd.parcels.length ? _sd.parcels.map(p => {
    const pctSold = p.quantity - p.quantity_remaining;
    const status = p.quantity_remaining <= 0
      ? '<span class="badge badge-red">Closed</span>'
      : pctSold > 0
        ? '<span class="badge badge-amber">Partial</span>'
        : '<span class="badge badge-green">Open</span>';
    const locked = pctSold > 0
      ? 'title="Partially sold — quantity locked"' : '';
    return `<tr>
      <td class="mono">${fmtDate(p.acquisition_date)}</td>
      <td class="num mono">${fmtNum(p.quantity, 4)}</td>
      <td class="num mono">${fmtCurrency(p.price_per_unit)}</td>
      <td class="num mono">${fmtCurrency(p.brokerage)}</td>
      <td class="num mono">${fmtCurrency(p.cost_base)}</td>
      <td class="num mono">${fmtNum(p.quantity_remaining, 4)}</td>
      <td>${status}</td>
      <td style="white-space:nowrap">${
        _isLocked(p.acquisition_date)
          ? '<span class="badge badge-amber" title="FY locked — cannot modify after lodgement">Locked</span>'
          : `<button class="btn btn-ghost btn-sm" onclick="_sdEditParcel(${p.id})">Edit</button>
             <button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="_sdDeleteParcel(${p.id})">Del</button>`
      }</td>
    </tr>`;
  }).join('') : `<tr><td colspan="8" style="text-align:center;padding:24px;color:var(--ink3);font-size:12px">No purchases recorded</td></tr>`;

  return `
    <div class="st-section">
      <div class="st-section-title">Parcels</div>
      <div class="st-section-line"></div>
      <button class="btn btn-secondary btn-sm" onclick="_sdOpenBuy()">+ Buy</button>
    </div>
    <div class="st-list-panel" style="margin-bottom:20px">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Acquired</th><th class="num">Qty</th><th class="num">Price</th>
            <th class="num">Brokerage</th><th class="num">Cost Base</th>
            <th class="num">Remaining</th><th>Status</th><th></th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>`;
}

// ── Sales section ──────────────────────────────────────────────────────────────

function _sdSalesSection() {
  const rows = _sd.sales.length ? _sd.sales.map(s => `<tr>
    <td class="mono">${fmtDate(s.sale_date)}</td>
    <td class="num mono">${fmtNum(s.quantity, 4)}</td>
    <td class="num mono">${fmtCurrency(s.price_per_unit)}</td>
    <td class="num mono">${fmtCurrency(s.brokerage)}</td>
    <td class="num mono">${fmtCurrency(s.net_proceeds)}</td>
    <td style="font-size:12px;color:var(--ink3)">${s.notes || ''}</td>
    <td style="white-space:nowrap">${
      _isLocked(s.sale_date)
        ? '<span class="badge badge-amber" title="FY locked — cannot modify after lodgement">Locked</span>'
        : `<button class="btn btn-ghost btn-sm" onclick="_sdEditSale(${s.id})">Edit</button>
           <button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="_sdDeleteSale(${s.id})">Del</button>`
    }</td>
  </tr>`).join('') : `<tr><td colspan="7" style="text-align:center;padding:24px;color:var(--ink3);font-size:12px">No sales recorded</td></tr>`;

  return `
    <div class="st-section">
      <div class="st-section-title">Sales</div>
      <div class="st-section-line"></div>
      <button class="btn btn-secondary btn-sm" onclick="_sdOpenSell()">Record Sale</button>
      <button class="btn btn-ghost btn-sm" onclick="_sdEstimateSale()" style="margin-left:6px">Estimate Sale</button>
    </div>
    <div class="st-list-panel" style="margin-bottom:20px">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Date</th><th class="num">Qty</th><th class="num">Price</th>
            <th class="num">Brokerage</th><th class="num">Net Proceeds</th><th>Notes</th><th></th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>`;
}

// ── Dividends section ──────────────────────────────────────────────────────────

function _sd45Badge(d) {
  if (!d.franking_credit) return '';
  if (d.eligible_45day === true)  return '<span class="badge badge-green" title="45-day rule satisfied">✓</span>';
  if (d.eligible_45day === false) return '<span class="badge badge-red"   title="45-day rule not satisfied — credit not claimable">✗</span>';
  return '<span class="badge badge-amber" title="Add ex-dividend date to verify 45-day eligibility">?</span>';
}

function _sdDivsSection() {
  const rows = _sd.divs.length ? _sd.divs.map(d => `<tr>
    <td class="mono">${fmtDate(d.payment_date)}</td>
    <td class="num mono">${fmtNum(d.quantity_held, 4)}</td>
    <td class="num mono">${fmtCurrency(d.amount_per_share, 4)}</td>
    <td class="num mono">${fmtCurrency(d.gross_amount)}</td>
    <td class="num mono">${d.franking_pct ? d.franking_pct + '%' : '—'}</td>
    <td class="num mono">${d.franking_credit ? fmtCurrency(d.franking_credit) : '—'}</td>
    <td>${_sd45Badge(d)}</td>
    <td class="num mono">${fmtCurrency(d.net_amount)}</td>
    <td>${d.is_drp ? '<span class="badge badge-accent">DRP</span>' : '—'}</td>
    <td style="white-space:nowrap">${
      _isLocked(d.payment_date)
        ? '<span class="badge badge-amber" title="FY locked — cannot modify after lodgement">Locked</span>'
        : `<button class="btn btn-ghost btn-sm" onclick="_sdEditDiv(${d.id})">Edit</button>
           <button class="btn btn-ghost btn-sm" style="color:var(--red)" onclick="_sdDeleteDiv(${d.id})">Del</button>`
    }</td>
  </tr>`).join('') : `<tr><td colspan="10" style="text-align:center;padding:24px;color:var(--ink3);font-size:12px">No dividends recorded</td></tr>`;

  return `
    <div class="st-section">
      <div class="st-section-title">Dividends</div>
      <div class="st-section-line"></div>
      <button class="btn btn-secondary btn-sm" onclick="_sdOpenDiv()">+ Dividend</button>
    </div>
    <div class="st-list-panel">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Date</th><th class="num">Qty Held</th><th class="num">Per Share</th>
            <th class="num">Gross</th><th class="num">Franking %</th>
            <th class="num">Franking Cr.</th>
            <th title="45-day holding period rule">45d</th>
            <th class="num">Net</th><th>DRP</th><th></th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>`;
}

// ── Buy form ───────────────────────────────────────────────────────────────────

function _sdOpenBuy(p = {}) {
  const isEdit = !!p.id;
  const qtyLocked = isEdit && (p.quantity - p.quantity_remaining) > 0;
  const defBrok = p.brokerage != null ? p.brokerage : ((_appSettings && _appSettings.default_brokerage) || '');
  openPanel(isEdit ? 'Edit Purchase' : 'Record Purchase', `
    <div style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3);margin-bottom:14px">
      ${_sd.security.code} — ${_sd.security.name}
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Acquisition Date</label>
        <input type="date" id="sd-buy-date" value="${p.acquisition_date || new Date().toISOString().slice(0,10)}">
      </div>
      <div class="field"><label>Quantity</label>
        <input type="number" id="sd-buy-qty" min="0" step="any" value="${p.quantity || ''}" placeholder="0"
          ${qtyLocked ? 'readonly style="background:var(--row-alt)" title="Partially sold — locked"' : ''}>
      </div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Price Per Unit ($)</label>
        <input type="number" id="sd-buy-price" min="0" step="any" value="${p.price_per_unit || ''}" placeholder="0.00">
      </div>
      <div class="field"><label>Brokerage ($)</label>
        <input type="number" id="sd-buy-brok" min="0" step="any" value="${defBrok}" placeholder="0.00">
      </div>
    </div>
    <div class="field"><label>Other Costs ($)</label>
      <input type="number" id="sd-buy-other" min="0" step="any" value="${p.other_costs || ''}" placeholder="0.00">
    </div>
    <div class="field"><label>Notes</label>
      <textarea id="sd-buy-notes" placeholder="Optional">${p.notes || ''}</textarea>
    </div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_sdSaveBuy(${p.id || 'null'})">${isEdit ? 'Save Changes' : 'Save Purchase'}</button>`
  );
}

function _sdEditParcel(id) { _sdOpenBuy(_sd.parcels.find(p => p.id === id) || {}); }

async function _sdSaveBuy(parcelId) {
  const acquisition_date = document.getElementById('sd-buy-date').value;
  const quantity         = document.getElementById('sd-buy-qty').value;
  const price_per_unit   = document.getElementById('sd-buy-price').value;
  const brokerage        = document.getElementById('sd-buy-brok').value || '0';
  const other_costs      = document.getElementById('sd-buy-other').value || '0';
  const notes            = document.getElementById('sd-buy-notes').value;

  if (!acquisition_date) return toast('Acquisition date is required', 'err');
  if (!quantity || parseFloat(quantity) <= 0) return toast('Quantity must be > 0', 'err');
  if (!price_per_unit || parseFloat(price_per_unit) <= 0) return toast('Price must be > 0', 'err');

  const url    = parcelId ? `/api/parcels/${parcelId}` : '/api/parcels';
  const method = parcelId ? 'PUT' : 'POST';
  const body   = parcelId
    ? { acquisition_date, quantity, price_per_unit, brokerage, other_costs, notes }
    : { security_id: _sd.security.id, acquisition_date, quantity, price_per_unit, brokerage, other_costs, notes };
  try {
    const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify(body) }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    toast(parcelId ? 'Purchase updated' : 'Purchase recorded');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

async function _sdDeleteParcel(id) {
  if (!confirm('Delete this purchase parcel? Cannot be undone.')) return;
  try {
    const r = await fetch(`/api/parcels/${id}`, { method: 'DELETE' }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    toast('Parcel deleted');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

// ── Sell form ──────────────────────────────────────────────────────────────────

function _sdOpenSell(s = {}) {
  const isEdit = !!s.id;
  const defBrok = s.brokerage != null ? s.brokerage : ((_appSettings && _appSettings.default_brokerage) || '');
  openPanel(isEdit ? 'Edit Sale' : 'Record Sale', `
    <div style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3);margin-bottom:14px">
      ${_sd.security.code} — ${_sd.security.name}
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Sale Date</label>
        <input type="date" id="sd-sell-date" value="${s.sale_date || new Date().toISOString().slice(0,10)}">
      </div>
      <div class="field"><label>Quantity</label>
        <input type="number" id="sd-sell-qty" min="0" step="any" value="${s.quantity || ''}" placeholder="0">
      </div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Price Per Unit ($)</label>
        <input type="number" id="sd-sell-price" min="0" step="any" value="${s.price_per_unit || ''}" placeholder="0.00">
      </div>
      <div class="field"><label>Brokerage ($)</label>
        <input type="number" id="sd-sell-brok" min="0" step="any" value="${defBrok}" placeholder="0.00">
      </div>
    </div>
    <div class="field"><label>CGT Method</label>
      <select id="sd-sell-method" onchange="_sdSellMethodChanged()">
        <option value="fifo"     ${(s.cgt_method||'fifo')==='fifo'     ? 'selected':''}>FIFO — First In, First Out</option>
        <option value="mingain"  ${s.cgt_method==='mingain'  ? 'selected':''}>Min Gain — Highest Cost Base First</option>
        <option value="maxgain"  ${s.cgt_method==='maxgain'  ? 'selected':''}>Max Gain — Lowest Cost Base First</option>
        <option value="specific" ${s.cgt_method==='specific' ? 'selected':''}>Specific Parcels</option>
      </select>
    </div>
    <div id="sd-parcel-picker" style="display:none">
      <div style="font-size:11px;color:var(--ink3);margin-bottom:6px">Select parcels to sell from (consumed in order checked):</div>
      <div id="sd-parcel-list"></div>
    </div>
    <div class="field"><label>Notes</label>
      <textarea id="sd-sell-notes" placeholder="Optional">${s.notes || ''}</textarea>
    </div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_sdSaveSell(${s.id || 'null'})">${isEdit ? 'Save Changes' : 'Record Sale'}</button>`
  );
}

async function _sdSellMethodChanged() {
  const method = document.getElementById('sd-sell-method')?.value;
  const picker = document.getElementById('sd-parcel-picker');
  if (!picker) return;
  if (method !== 'specific') { picker.style.display = 'none'; return; }
  picker.style.display = '';
  document.getElementById('sd-parcel-list').innerHTML = '<div style="color:var(--ink3);font-size:12px">Loading…</div>';
  try {
    const parcels = await apiFetch(`/api/parcels?security_id=${_sd.security.id}&open_only=1`);
    if (!parcels.length) {
      document.getElementById('sd-parcel-list').innerHTML = '<div style="color:var(--ink3);font-size:12px">No open parcels</div>';
      return;
    }
    const today = new Date();
    document.getElementById('sd-parcel-list').innerHTML = parcels.map(p => {
      const days = Math.floor((today - new Date(p.acquisition_date)) / 86400000);
      const disc = days > 365 ? '<span class="badge badge-green" style="font-size:10px">Disc</span>' : '';
      return `<label style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border);cursor:pointer;font-size:12px">
        <input type="checkbox" data-parcel-id="${p.id}" style="flex-shrink:0">
        <span style="flex:1;font-family:'DM Mono',monospace">${fmtDate(p.acquisition_date)}</span>
        <span style="color:var(--ink2)">${fmtNum(p.quantity_remaining, 4)} units</span>
        <span style="color:var(--ink3)">${fmtCurrency(p.cost_base / p.quantity)}/unit</span>
        <span style="color:var(--ink3);min-width:32px;text-align:right">${days}d</span>
        ${disc}
      </label>`;
    }).join('');
  } catch (e) {
    document.getElementById('sd-parcel-list').innerHTML = `<div style="color:var(--red);font-size:12px">${e.message}</div>`;
  }
}

function _sdEditSale(id) { _sdOpenSell(_sd.sales.find(s => s.id === id) || {}); }

async function _sdSaveSell(saleId) {
  const sale_date      = document.getElementById('sd-sell-date').value;
  const quantity       = document.getElementById('sd-sell-qty').value;
  const price_per_unit = document.getElementById('sd-sell-price').value;
  const brokerage      = document.getElementById('sd-sell-brok').value || '0';
  const cgt_method     = document.getElementById('sd-sell-method').value;
  const notes          = document.getElementById('sd-sell-notes').value;

  if (!sale_date) return toast('Sale date is required', 'err');
  if (!quantity || parseFloat(quantity) <= 0) return toast('Quantity must be > 0', 'err');
  if (!price_per_unit || parseFloat(price_per_unit) <= 0) return toast('Price must be > 0', 'err');

  let parcel_ids = null;
  if (cgt_method === 'specific') {
    parcel_ids = [...document.querySelectorAll('#sd-parcel-list input[type=checkbox]:checked')]
      .map(cb => parseInt(cb.dataset.parcelId));
    if (!parcel_ids.length) return toast('Select at least one parcel', 'err');
  }

  const url    = saleId ? `/api/sales/${saleId}` : '/api/sales';
  const method = saleId ? 'PUT' : 'POST';
  const body   = saleId
    ? { sale_date, quantity, price_per_unit, brokerage, cgt_method, notes, parcel_ids }
    : { security_id: _sd.security.id, sale_date, quantity, price_per_unit, brokerage, cgt_method, notes, parcel_ids };
  try {
    const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify(body) }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    toast(saleId ? 'Sale updated' : 'Sale recorded');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

async function _sdDeleteSale(id) {
  if (!confirm('Delete this sale? Parcel allocations will be reversed.')) return;
  try {
    const r = await fetch(`/api/sales/${id}`, { method: 'DELETE' }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    toast('Sale deleted');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

// ── Dividend form ──────────────────────────────────────────────────────────────

function _sdOpenDiv(d = {}) {
  const isEdit = !!d.id;
  const hasDrp = isEdit && d.is_drp;
  openPanel(isEdit ? 'Edit Dividend' : 'Record Dividend', `
    <div style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3);margin-bottom:14px">
      ${_sd.security.code} — ${_sd.security.name}
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Payment Date</label>
        <input type="date" id="sd-div-pay" value="${d.payment_date || new Date().toISOString().slice(0,10)}">
      </div>
      <div class="field"><label>Ex-Dividend Date <span style="font-weight:400;text-transform:none;letter-spacing:0;color:var(--amber)">required for 45-day rule</span></label>
        <input type="date" id="sd-div-ex" value="${d.ex_date || ''}">
      </div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Quantity Held</label>
        <input type="number" id="sd-div-qty" min="0" step="any" value="${d.quantity_held || ''}" placeholder="0" oninput="_sdDivCalcFranking()">
      </div>
      <div class="field"><label>Amount Per Share ($)</label>
        <input type="number" id="sd-div-aps" min="0" step="any" value="${d.amount_per_share || ''}" placeholder="0.0000" oninput="_sdDivCalcFranking()">
      </div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Franking % <span style="font-weight:400;text-transform:none;letter-spacing:0">(0–100)</span></label>
        <input type="number" id="sd-div-frank" min="0" max="100" step="any" value="${d.franking_pct ?? 0}" oninput="_sdDivCalcFranking()">
      </div>
      <div class="field"><label>Franking Credit ($) <span style="font-weight:400;text-transform:none;letter-spacing:0">from statement</span></label>
        <input type="number" id="sd-div-frank-amt" min="0" step="any" value="${d.franking_credit ? d.franking_credit.toFixed(2) : ''}" placeholder="0.00">
      </div>
    </div>
    <div style="font-size:11px;color:var(--ink3);margin-top:-8px;margin-bottom:12px">Franking credit auto-calculates from % as a guide — verify the dollar amount against your dividend statement and correct if needed.</div>
    ${hasDrp ? `
    <div style="padding:10px 12px;background:var(--amber-dim);border-radius:7px;font-size:12px;color:var(--amber)">
      DRP details cannot be edited. Delete and re-enter to change DRP.
    </div>` : !isEdit ? `
    <div class="field"><label>
      <input type="checkbox" id="sd-div-drp" onchange="_sdToggleDrp()"> Dividend Reinvestment Plan (DRP)
    </label></div>
    <div id="sd-div-drp-fields" style="display:none">
      <div class="field-row cols-2">
        <div class="field"><label>DRP Shares Issued</label>
          <input type="number" id="sd-div-drp-qty" min="0" step="any" placeholder="0">
        </div>
        <div class="field"><label>DRP Price ($)</label>
          <input type="number" id="sd-div-drp-price" min="0" step="any" placeholder="0.00">
        </div>
      </div>
    </div>` : ''}
    <div class="field"><label>Notes</label>
      <textarea id="sd-div-notes" placeholder="Optional">${d.notes || ''}</textarea>
    </div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_sdSaveDiv(${d.id || 'null'})">${isEdit ? 'Save Changes' : 'Save Dividend'}</button>`
  );
}

function _sdToggleDrp() {
  const f = document.getElementById('sd-div-drp-fields');
  if (f) f.style.display = document.getElementById('sd-div-drp').checked ? '' : 'none';
}

function _sdDivCalcFranking() {
  const qty   = parseFloat(document.getElementById('sd-div-qty')?.value) || 0;
  const aps   = parseFloat(document.getElementById('sd-div-aps')?.value) || 0;
  const pct   = parseFloat(document.getElementById('sd-div-frank')?.value) || 0;
  const gross = qty * aps;
  const el    = document.getElementById('sd-div-frank-amt');
  if (!el) return;
  el.value = (pct && gross) ? ((gross * pct / 100) / 0.70 * 0.30).toFixed(2) : '';
}

function _sdEditDiv(id) { _sdOpenDiv(_sd.divs.find(d => d.id === id) || {}); }

async function _sdSaveDiv(divId) {
  const payment_date     = document.getElementById('sd-div-pay').value;
  const ex_date          = document.getElementById('sd-div-ex').value || null;
  const quantity_held    = document.getElementById('sd-div-qty').value;
  const amount_per_share = document.getElementById('sd-div-aps').value;
  const franking_pct     = document.getElementById('sd-div-frank').value || '0';
  const franking_credit  = document.getElementById('sd-div-frank-amt').value || '0';
  const notes            = document.getElementById('sd-div-notes').value;

  if (!payment_date) return toast('Payment date is required', 'err');
  if (!quantity_held || parseFloat(quantity_held) <= 0) return toast('Quantity held must be > 0', 'err');
  if (!amount_per_share || parseFloat(amount_per_share) <= 0) return toast('Amount per share must be > 0', 'err');

  try {
    if (divId) {
      const r = await fetch(`/api/dividends/${divId}`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ payment_date, ex_date, quantity_held, amount_per_share, franking_pct, franking_credit, notes }),
      }).then(r => r.json());
      if (!r.ok) throw new Error(r.error);
      toast('Dividend updated');
    } else {
      const is_drp      = document.getElementById('sd-div-drp')?.checked ? 1 : 0;
      const drp_quantity = is_drp ? document.getElementById('sd-div-drp-qty')?.value : null;
      const drp_price    = is_drp ? document.getElementById('sd-div-drp-price')?.value : null;
      const r = await fetch('/api/dividends', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ security_id: _sd.security.id, payment_date, ex_date,
                               quantity_held, amount_per_share, franking_pct, franking_credit,
                               is_drp, drp_quantity, drp_price, notes }),
      }).then(r => r.json());
      if (!r.ok) throw new Error(r.error);
      toast('Dividend recorded');
    }
    closePanel();
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

async function _sdDeleteDiv(id) {
  if (!confirm('Delete this dividend? DRP parcel will also be removed if unsold.')) return;
  try {
    const r = await fetch(`/api/dividends/${id}`, { method: 'DELETE' }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    toast('Dividend deleted');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

// ── CGT Sale Estimator ────────────────────────────────────────────────────────

function _sdEstimateSale() {
  openPanel('Estimate Sale — ' + _sd.security.code, `
    <div style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3);margin-bottom:14px">
      FIFO estimate only — not financial advice
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Quantity to Sell</label>
        <input type="number" id="est-qty" min="0" step="any" placeholder="0" oninput="_sdCalcEstimate()">
      </div>
      <div class="field"><label>Sale Price ($)</label>
        <input type="number" id="est-price" min="0" step="any" placeholder="0.00" oninput="_sdCalcEstimate()">
      </div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Brokerage ($)</label>
        <input type="number" id="est-brok" min="0" step="any" value="0" placeholder="0.00" oninput="_sdCalcEstimate()">
      </div>
      <div class="field"><label>Sale Date</label>
        <input type="date" id="est-date" value="${new Date().toISOString().slice(0,10)}" onchange="_sdCalcEstimate()">
      </div>
    </div>
    <div id="est-result"></div>`,
    `<button class="btn btn-primary" onclick="closePanel()">Close</button>`
  );
}

function _sdCalcEstimate() {
  const qty   = parseFloat(document.getElementById('est-qty')?.value)   || 0;
  const price = parseFloat(document.getElementById('est-price')?.value) || 0;
  const brok  = parseFloat(document.getElementById('est-brok')?.value)  || 0;
  const saleDate = document.getElementById('est-date')?.value || new Date().toISOString().slice(0,10);
  const el    = document.getElementById('est-result');
  if (!el) return;
  if (qty <= 0 || price <= 0) { el.innerHTML = ''; return; }

  const open = _sd.parcels
    .filter(p => p.quantity_remaining > 0)
    .sort((a, b) => a.acquisition_date.localeCompare(b.acquisition_date));
  const totalAvail = open.reduce((s, p) => s + p.quantity_remaining, 0);

  if (qty > totalAvail + 0.0001) {
    el.innerHTML = `<div style="padding:10px 14px;background:var(--red-dim);border-radius:8px;font-size:12px;color:var(--red)">
      Insufficient shares — ${fmtNum(totalAvail, 4)} available, selling ${fmtNum(qty, 4)}</div>`;
    return;
  }

  const entityType = (_appSettings && _appSettings.entity_type) || 'individual';
  const discountFactor = { individual: 0.5, smsf_accumulation: 1/3, smsf_pension: 1.0, company: 0 }[entityType] ?? 0.5;
  const discountLabel  = { individual: 'after 50% discount', smsf_accumulation: 'after 1/3 discount',
                            smsf_pension: 'fully exempt (pension)', company: 'no CGT discount' }[entityType] || 'after CGT discount';

  const proceeds = qty * price - brok;
  const procPerUnit = proceeds / qty;
  let remaining = qty;
  let totalCB = 0, totalGross = 0, totalTaxable = 0;
  const allocs = [];

  for (const p of open) {
    if (remaining <= 0) break;
    const sellQty  = Math.min(remaining, p.quantity_remaining);
    const cbUsed   = (p.cost_base / p.quantity) * sellQty;
    const procAlloc = procPerUnit * sellQty;
    const gain     = procAlloc - cbUsed;
    const days     = (new Date(saleDate) - new Date(p.acquisition_date)) / 86400000;
    const eligible = days > 365 && gain > 0;
    const taxable  = eligible ? gain * (1 - discountFactor) : gain;
    totalCB      += cbUsed;
    totalGross   += gain;
    totalTaxable += taxable;
    allocs.push({ date: p.acquisition_date, qty: sellQty, cbUsed, gain, eligible, taxable });
    remaining -= sellQty;
  }

  const taxRate = parseFloat((_appSettings && _appSettings.marginal_tax_rate) || 0);
  const estTax  = taxRate > 0 && totalTaxable > 0 ? totalTaxable * taxRate / 100 : null;

  el.innerHTML = `
    <div style="margin-top:14px;padding:12px 14px;background:var(--surface2);border-radius:8px;border:1px solid var(--border)">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 24px;font-size:12px;margin-bottom:12px">
        <div style="color:var(--ink3)">Net Proceeds</div><div class="mono" style="text-align:right">${fmtCurrency(proceeds)}</div>
        <div style="color:var(--ink3)">Cost Base (FIFO)</div><div class="mono" style="text-align:right">${fmtCurrency(totalCB)}</div>
        <div style="color:var(--ink3);border-top:1px solid var(--border);padding-top:4px">Gross Gain/Loss</div>
        <div class="mono ${gainClass(totalGross)}" style="text-align:right;border-top:1px solid var(--border);padding-top:4px">${fmtCurrency(totalGross)}</div>
        <div style="color:var(--ink3)">Taxable Gain (${discountLabel})</div>
        <div class="mono ${gainClass(totalTaxable)}" style="text-align:right;font-weight:700">${fmtCurrency(totalTaxable)}</div>
        ${estTax !== null ? `
        <div style="color:var(--ink3)">Est. Tax @ ${taxRate}%</div>
        <div class="mono col-red" style="text-align:right">${fmtCurrency(estTax)}</div>
        <div style="color:var(--ink3)">Est. After-Tax Gain</div>
        <div class="mono ${gainClass(totalTaxable - estTax)}" style="text-align:right;font-weight:700">${fmtCurrency(totalTaxable - estTax)}</div>` : ''}
      </div>
      <table class="st-table" style="font-size:11px">
        <thead><tr><th>Parcel Acquired</th><th class="num">Qty</th><th class="num">Cost Base</th>
          <th class="num">Gain</th><th>Disc?</th><th class="num">Taxable</th></tr></thead>
        <tbody>
          ${allocs.map(a => `<tr>
            <td class="mono">${fmtDate(a.date)}</td>
            <td class="num mono">${fmtNum(a.qty, 4)}</td>
            <td class="num mono">${fmtCurrency(a.cbUsed)}</td>
            <td class="num mono"><span class="${gainClass(a.gain)}">${fmtCurrency(a.gain)}</span></td>
            <td>${a.eligible ? '<span class="badge badge-green">Yes</span>' : '—'}</td>
            <td class="num mono"><span class="${gainClass(a.taxable)}">${fmtCurrency(a.taxable)}</span></td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
}

// ── Corporate actions section ─────────────────────────────────────────────────

function _sdActBadge(a) {
  if (a.action_type === 'rights_issue')     return '<span class="badge badge-green">Rights Issue</span>';
  if (a.action_type === 'bonus')            return '<span class="badge badge-green">Bonus</span>';
  if (a.action_type === 'return_of_capital') return '<span class="badge badge-red">Return of Capital</span>';
  return a.ratio_to > a.ratio_from
    ? '<span class="badge badge-accent">Split</span>'
    : '<span class="badge badge-amber">Consolidation</span>';
}

function _sdActionsSection() {
  const rows = _sd.actions.length ? _sd.actions.map(a => {
    return `<tr>
      <td class="mono">${fmtDate(a.action_date)}</td>
      <td>${_sdActBadge(a)}</td>
      <td class="mono">${
        a.action_type === 'rights_issue'      ? `${fmtNum(a.ratio_from, 0)} @ ${fmtCurrency(a.ratio_to, 4)}`
        : a.action_type === 'bonus'           ? `${fmtNum(a.ratio_from, 0)} @ $0.00`
        : a.action_type === 'return_of_capital' ? `${fmtCurrency(a.ratio_from, 4)}/unit`
        : `${a.ratio_to}-for-${a.ratio_from}`
      }</td>
      <td style="font-size:12px;color:var(--ink2)">${a.description || ''}</td>
      <td>${
        _isLocked(a.action_date)
          ? '<span class="badge badge-amber" title="FY locked — cannot modify after lodgement">Locked</span>'
          : `<button class="btn btn-ghost btn-sm" style="color:var(--red)"
              onclick="_sdDeleteAction(${a.id}, ${a.ratio_from}, ${a.ratio_to}, '${a.action_type}')">Del</button>`
      }</td>
    </tr>`;
  }).join('') : `<tr><td colspan="5" style="text-align:center;padding:24px;color:var(--ink3);font-size:12px">No corporate actions recorded</td></tr>`;

  return `
    <div class="st-section" style="margin-top:28px">
      <div class="st-section-title">Corporate Actions</div>
      <div class="st-section-line"></div>
      <button class="btn btn-secondary btn-sm" onclick="_sdOpenAction()">+ Action</button>
    </div>
    <div class="st-list-panel">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>Date</th><th>Type</th><th>Ratio</th><th>Description</th><th></th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    </div>`;
}

function _sdOpenAction() {
  openPanel('Record Corporate Action', `
    <div style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3);margin-bottom:14px">
      ${_sd.security.code} — ${_sd.security.name}
    </div>
    <div class="field-row cols-2">
      <div class="field"><label>Action Date</label>
        <input type="date" id="sd-act-date" value="${new Date().toISOString().slice(0,10)}">
      </div>
      <div class="field"><label>Type</label>
        <select id="sd-act-type" onchange="_sdActTypeChanged()">
          <option value="split">Split</option>
          <option value="consolidation">Consolidation</option>
          <option value="bonus">Bonus Issue</option>
          <option value="rights_issue">Rights Issue</option>
        </select>
      </div>
    </div>
    <div class="field-row cols-2">
      <div class="field"><label id="sd-act-lbl-from">From (existing shares)</label>
        <input type="number" id="sd-act-from" min="0.0001" step="1" value="1" oninput="_sdActUpdatePreview()">
      </div>
      <div class="field" id="sd-act-to-wrap"><label id="sd-act-lbl-to">To (shares received)</label>
        <input type="number" id="sd-act-to" min="0.0001" step="1" value="2" oninput="_sdActUpdatePreview()">
      </div>
    </div>
    <div id="sd-act-preview" style="padding:10px 14px;background:var(--accent-dim);border-radius:8px;font-size:12px;color:var(--ink2);margin-bottom:14px;font-family:'DM Mono',monospace">
      2-for-1 split — quantity &times;2 &middot; price &divide;2 &middot; cost base unchanged
    </div>
    <div class="field"><label>Description</label>
      <input type="text" id="sd-act-desc" placeholder="e.g. 2-for-1 share split">
    </div>
    <div class="field"><label>Notes</label>
      <textarea id="sd-act-notes" placeholder="Optional"></textarea>
    </div>`,
    `<button class="btn btn-secondary" onclick="closePanel()">Cancel</button>
     <button class="btn btn-primary" onclick="_sdSaveAction()">Apply Action</button>`
  );
  _sdActUpdatePreview();
}

function _sdActTypeChanged() {
  const type    = document.getElementById('sd-act-type')?.value;
  const lblFrom = document.getElementById('sd-act-lbl-from');
  const lblTo   = document.getElementById('sd-act-lbl-to');
  const toWrap  = document.getElementById('sd-act-to-wrap');
  if (!lblFrom || !lblTo) return;
  if (type === 'rights_issue') {
    lblFrom.textContent = 'Quantity subscribed';
    lblTo.textContent   = 'Subscription price ($ per share)';
    document.getElementById('sd-act-to').step = 'any';
    if (toWrap) toWrap.style.display = '';
  } else if (type === 'bonus') {
    lblFrom.textContent = 'Bonus shares received';
    if (toWrap) toWrap.style.display = 'none';
  } else {
    lblFrom.textContent = 'From (existing shares)';
    lblTo.textContent   = 'To (shares received)';
    document.getElementById('sd-act-to').step = '1';
    if (toWrap) toWrap.style.display = '';
  }
  _sdActUpdatePreview();
}

function _sdActUpdatePreview() {
  const from = parseFloat(document.getElementById('sd-act-from')?.value) || 0;
  const to   = parseFloat(document.getElementById('sd-act-to')?.value)   || 0;
  const type = document.getElementById('sd-act-type')?.value;
  const el   = document.getElementById('sd-act-preview');
  if (!el) return;

  if (type === 'rights_issue') {
    if (from <= 0 || to <= 0) { el.textContent = 'Enter quantity and price'; return; }
    el.innerHTML = `<strong>Rights Issue</strong> &mdash; ` +
      `${fmtNum(from, 0)} shares subscribed @ ${fmtCurrency(to, 4)} each &rarr; ` +
      `new parcel cost base ${fmtCurrency(from * to)}`;
    el.style.background = 'var(--green-dim)';
    el.style.color       = 'var(--green)';
    return;
  }
  if (type === 'bonus') {
    if (from <= 0) { el.textContent = 'Enter number of bonus shares received'; return; }
    el.innerHTML = `<strong>Bonus Issue</strong> &mdash; ` +
      `${fmtNum(from, 0)} new shares &rarr; $0.00 cost base &middot; ` +
      `original parcel cost base unchanged (ATO treatment)`;
    el.style.background = 'var(--green-dim)';
    el.style.color       = 'var(--green)';
    return;
  }
  if (from <= 0 || to <= 0) { el.textContent = 'Enter valid ratios'; return; }
  if (Math.abs(from - to) < 0.0001) { el.textContent = 'From and To must be different'; return; }
  const isSplit = to > from;
  const mult = to / from;
  el.innerHTML = `<strong>${to}-for-${from} ${isSplit ? 'split' : 'consolidation'}</strong> &mdash; ` +
    `quantity &times;${+mult.toFixed(6)} &middot; price &divide;${+mult.toFixed(6)} &middot; cost base unchanged`;
  el.style.background = isSplit ? 'var(--accent-dim)' : 'var(--amber-dim)';
  el.style.color       = isSplit ? 'var(--ink2)' : 'var(--amber)';
}

async function _sdSaveAction() {
  const action_date = document.getElementById('sd-act-date').value;
  const action_type = document.getElementById('sd-act-type').value;
  const ratio_from  = document.getElementById('sd-act-from').value;
  let   ratio_to    = document.getElementById('sd-act-to').value;
  const description = document.getElementById('sd-act-desc').value;
  const notes       = document.getElementById('sd-act-notes').value;

  if (!action_date) return toast('Date is required', 'err');
  if (action_type === 'rights_issue') {
    if (!ratio_from || parseFloat(ratio_from) <= 0) return toast('Quantity must be > 0', 'err');
    if (!ratio_to   || parseFloat(ratio_to)   <= 0) return toast('Subscription price must be > 0', 'err');
  } else if (action_type === 'bonus') {
    if (!ratio_from || parseFloat(ratio_from) <= 0) return toast('Bonus shares must be > 0', 'err');
    ratio_to = '0';
  } else {
    if (!ratio_from || parseFloat(ratio_from) <= 0) return toast('From ratio must be > 0', 'err');
    if (!ratio_to   || parseFloat(ratio_to)   <= 0) return toast('To ratio must be > 0', 'err');
    if (Math.abs(parseFloat(ratio_from) - parseFloat(ratio_to)) < 0.0001)
      return toast('From and To must be different', 'err');
  }

  try {
    const r = await fetch('/api/actions', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        security_id: _sd.security.id,
        action_date, action_type, ratio_from, ratio_to, description, notes,
      }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    closePanel();
    toast('Corporate action applied');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}

async function _sdToggleWatch() {
  const btn = document.getElementById('sd-watch-btn');
  if (btn) { btn.disabled = true; }
  try {
    if (_sd.watchlistItem) {
      const r = await fetch(`/api/watchlist/${_sd.watchlistItem.id}`, { method: 'DELETE' }).then(r => r.json());
      if (!r.ok) throw new Error(r.error);
      _sd.watchlistItem = null;
      toast('Removed from watch list');
    } else {
      const r = await fetch('/api/watchlist', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ security_id: _sd.security.id }),
      }).then(r => r.json());
      if (!r.ok) throw new Error(r.error);
      _sd.watchlistItem = { id: r.data.id, security_id: _sd.security.id };
      toast('Added to watch list');
    }
    if (btn) {
      btn.disabled = false;
      if (_sd.watchlistItem) {
        btn.textContent = '👁 Watching';
        btn.style.color = 'var(--ink3)';
      } else {
        btn.textContent = '+ Watch';
        btn.style.color = '';
      }
    }
  } catch (e) {
    toast(e.message, 'err');
    if (btn) btn.disabled = false;
  }
}

async function _sdDeleteAction(id, ratioFrom, ratioTo, actionType) {
  const msg = (actionType === 'rights_issue' || actionType === 'bonus')
    ? `Delete this ${actionType === 'bonus' ? 'bonus issue' : 'rights issue'}?\n\nThe created parcel will be removed (if not yet sold). This cannot be undone.`
    : actionType === 'return_of_capital'
    ? `Reverse and delete this return of capital ($${parseFloat(ratioFrom).toFixed(4)}/unit)?\n\nCost bases on all affected parcels will be restored. Any CGT reported from this action will no longer appear. This cannot be undone.`
    : `Reverse and delete this ${ratioTo}-for-${ratioFrom} action?\n\nAll affected parcels will revert to their pre-action quantities.`;
  if (!confirm(msg)) return;
  try {
    const r = await fetch(`/api/actions/${id}`, { method: 'DELETE' }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    toast('Action reversed and deleted');
    await _sdRefresh();
  } catch (e) { toast(e.message, 'err'); }
}
