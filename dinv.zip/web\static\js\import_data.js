// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

/* Dogbox Investments — Import Transactions from CSV */

const _IMP_FORMAT_HINTS = {
  commsec_confirmations: `CommSec <strong>ConfirmationDetails.csv</strong> — exported from CommSec &rsaquo; Portfolio &rsaquo; Transactions &rsaquo; Export. Buys and sells only; dividends are not included in this export.`,
  selfwealth: `SelfWealth transaction history CSV — exported from the SelfWealth app. Supports BUY, SELL, and DIVIDEND rows.`,
  generic_flex: `Generic flexible format — any CSV with columns for Date, Code, Type, Quantity, and Price (column names vary by broker).`,
  template: `sharetrack template — the standard import format. Download the template above for exact column names.`,
  unknown: `Format not recognised — falling back to sharetrack template format. Download the template above for exact column names.`,
};

async function pageImportData() {
  const content = document.getElementById('module-content');
  content.innerHTML = `
    <div class="st-toolbar">
      <span style="font-size:13px;color:var(--ink2);font-weight:500">Import transactions from CSV</span>
      <a class="btn btn-secondary" href="/api/export/template.csv" style="margin-left:auto">Download Template</a>
      <a class="btn btn-ghost" href="/api/export/transactions.csv">Export All Transactions</a>
    </div>

    <div class="st-list-panel" style="padding:20px 24px">
      <div class="field" style="max-width:280px;margin-bottom:12px">
        <label>Format</label>
        <select id="imp-format">
          <option value="">Auto-detect</option>
          <option value="commsec_confirmations">CommSec Trade Confirmations</option>
          <option value="selfwealth">SelfWealth Transaction History</option>
          <option value="generic_flex">Generic (flexible columns)</option>
          <option value="template">sharetrack Template</option>
        </select>
      </div>
      <div id="imp-hint" style="margin-bottom:16px;font-size:12px;color:var(--ink3);font-family:'DM Mono',monospace;line-height:1.8">
        Select a format or leave on Auto-detect, then choose your CSV file.
      </div>
      <div class="field" style="max-width:400px">
        <label>Select CSV file</label>
        <input type="file" id="imp-file" accept=".csv" onchange="_impFileSelected()">
      </div>
    </div>

    <div id="imp-preview"></div>`;

  document.getElementById('imp-format').addEventListener('change', _impFormatChanged);
}

function _impFormatChanged() {
  const fmt = document.getElementById('imp-format')?.value;
  const hint = document.getElementById('imp-hint');
  if (!hint) return;
  if (fmt && _IMP_FORMAT_HINTS[fmt]) {
    hint.innerHTML = _IMP_FORMAT_HINTS[fmt];
  } else {
    hint.innerHTML = 'Select a format or leave on Auto-detect, then choose your CSV file.';
  }
  // Re-parse if a file is already loaded
  const file = document.getElementById('imp-file')?.files[0];
  if (file) _impFileSelected();
}

async function _impFileSelected() {
  const file = document.getElementById('imp-file')?.files[0];
  if (!file) return;

  const preview = document.getElementById('imp-preview');
  preview.innerHTML = '<div class="st-empty"><div class="st-empty-icon">⏳</div>Parsing…</div>';

  const fd = new FormData();
  fd.append('file', file);
  const fmt = document.getElementById('imp-format')?.value || '';
  if (fmt) fd.append('format', fmt);

  try {
    const r = await fetch('/api/import/preview', { method: 'POST', body: fd }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);
    _impRenderPreview(r.data.rows, r.data.errors, r.data.format_label);
  } catch (e) {
    preview.innerHTML = `<div class="st-empty"><div class="st-empty-title">Parse error</div><div>${e.message}</div></div>`;
  }
}

let _impRows = [];

function _impRenderPreview(rows, errors, formatLabel) {
  _impRows = rows;
  const preview = document.getElementById('imp-preview');

  const valid   = rows.filter(r => !r.warning && r.security_id);
  const warned  = rows.filter(r => r.warning);
  const errored = errors;

  const typeColor = { Buy: 'badge-accent', Sell: 'badge-amber', Dividend: 'badge-green' };

  preview.innerHTML = `
    ${formatLabel ? `
    <div style="margin-bottom:12px;font-size:11px;color:var(--ink3)">
      Detected format: <span class="badge badge-ink" style="font-size:10px">${formatLabel}</span>
    </div>` : ''}

    ${errored.length ? `
    <div style="padding:12px 16px;background:var(--red-dim);border-radius:8px;margin-bottom:16px;font-size:12px;color:var(--red)">
      <strong>${errored.length} parse error${errored.length !== 1 ? 's' : ''}:</strong>
      ${errored.map(e => `<div style="margin-top:4px">Row ${e.row}: ${e.error}</div>`).join('')}
    </div>` : ''}

    <div class="st-kpi-strip" style="margin-bottom:16px">
      <div class="st-kpi">
        <div class="st-kpi-label">Ready to import</div>
        <div class="st-kpi-value col-green">${valid.length}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Skipped (unknown code)</div>
        <div class="st-kpi-value col-amber">${warned.length}</div>
      </div>
      <div class="st-kpi">
        <div class="st-kpi-label">Parse errors</div>
        <div class="st-kpi-value ${errored.length ? 'col-red' : 'col-ink3'}">${errored.length}</div>
      </div>
    </div>

    <div class="st-list-panel" style="margin-bottom:16px">
      <div class="tbl-overflow">
        <table class="st-table">
          <thead><tr>
            <th>#</th><th>Type</th><th>Date</th><th>Code</th>
            <th class="num">Qty</th><th class="num">Price</th>
            <th class="num">Brokerage</th><th>Notes</th><th>Status</th>
          </tr></thead>
          <tbody>
            ${rows.map(r => `<tr style="${r.warning ? 'opacity:0.55' : ''}">
              <td class="mono" style="color:var(--ink3)">${r.row}</td>
              <td><span class="badge ${typeColor[r.type] || ''}">${r.type}</span></td>
              <td class="mono">${fmtDate(r.date)}</td>
              <td class="code-cell">${r.code}</td>
              <td class="num mono">${fmtNum(r.quantity, 4)}</td>
              <td class="num mono">${fmtCurrency(r.price, 4)}</td>
              <td class="num mono">${r.brokerage ? fmtCurrency(r.brokerage) : '—'}</td>
              <td style="font-size:11px;color:var(--ink3)">${r.notes || ''}</td>
              <td style="font-size:11px">${r.warning
                ? `<span style="color:var(--amber)">${r.warning}</span>`
                : '<span style="color:var(--green)">✓ Ready</span>'}</td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>

    ${valid.length > 0 ? `
    <div style="display:flex;gap:10px;align-items:center">
      <button class="btn btn-primary" onclick="_impCommit()">Import ${valid.length} transaction${valid.length !== 1 ? 's' : ''}</button>
      <span style="font-size:12px;color:var(--ink3)">${warned.length > 0 ? `${warned.length} row${warned.length !== 1 ? 's' : ''} with unknown securities will be skipped` : ''}</span>
    </div>` : `
    <div style="font-size:13px;color:var(--ink3)">No importable rows found. Check that your security codes match existing securities.</div>`}`;
}

async function _impCommit() {
  const validRows = _impRows.filter(r => r.security_id);
  if (!validRows.length) return;

  try {
    const r = await fetch('/api/import/commit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rows: validRows }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error);

    const { imported, skipped, failed } = r.data;
    const preview = document.getElementById('imp-preview');

    if (failed.length) {
      preview.innerHTML += `<div style="margin-top:12px;padding:12px 16px;background:var(--red-dim);border-radius:8px;font-size:12px;color:var(--red)">
        ${failed.length} row${failed.length !== 1 ? 's' : ''} failed:
        ${failed.map(f => `<div>Row ${f.row}: ${f.error}</div>`).join('')}
      </div>`;
    }

    toast(`${imported} transaction${imported !== 1 ? 's' : ''} imported${skipped ? `, ${skipped} skipped` : ''}`);

    // Reset file input and clear preview
    const fi = document.getElementById('imp-file');
    if (fi) fi.value = '';
    _impRows = [];
    document.getElementById('imp-preview').innerHTML = '';
  } catch (e) {
    toast(e.message, 'err');
  }
}
