# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import os
import uuid as _uuid
from flask import Blueprint, request
from web.shared import db, ok, err, login_required, tier_required

bp = Blueprint('pos', __name__)


# ── Item catalogue ────────────────────────────────────────────────────────────

@bp.route("/api/pos/items")
@login_required
@tier_required("pos")
def api_pos_items():
    from core.pos import get_pos_items
    search = request.args.get("q") or None
    return ok(get_pos_items(db(), search=search))


# ── Sales ─────────────────────────────────────────────────────────────────────

@bp.route("/api/pos/sale", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_sale():
    from core.pos import create_pos_sale
    data = request.get_json() or {}
    try:
        result = create_pos_sale(
            db(),
            lines=data.get("lines", []),
            tender=data.get("tender", "cash"),
            tendered_amount=data.get("tendered"),
            terminal_tx_id=data.get("terminal_tx_id"),
            terminal_provider=data.get("terminal_provider"),
            terminal_rfn=data.get("terminal_rfn"),
            note=data.get("note", ""),
            session_id=data.get("session_id"),
            contact_id=data.get("contact_id"),
            gst=data.get("gst", 0.0),
            split_tenders=data.get("split_tenders"),
            basket_discount=float(data.get("basket_discount") or 0),
            tyro_surcharge_cents=data.get("tyro_surcharge_cents"),
        )
        return ok(result)
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/sales")
@login_required
@tier_required("pos")
def api_pos_sales():
    from core.pos import get_pos_sales
    limit = int(request.args.get("limit", 50))
    return ok(get_pos_sales(db(), limit=limit))


# ── Terminal payments ─────────────────────────────────────────────────────────

@bp.route("/api/pos/terminal/charge", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_terminal_charge():
    from core.pos import charge_terminal
    data = request.get_json() or {}
    amount_cents = int(round(float(data.get("amount", 0)) * 100))
    reference    = data.get("reference", "POS")
    idempotency  = str(_uuid.uuid4())
    try:
        result = charge_terminal(db(), amount_cents, reference, idempotency)
        return ok(result)
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/terminal/pair", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_terminal_pair():
    from core.pos import pair_linkly_terminal
    data      = request.get_json() or {}
    username  = (data.get("username") or "").strip()
    password  = data.get("password") or ""
    pair_code = (data.get("pair_code") or "").strip()
    if not username or not password or not pair_code:
        return err("username, password, and pair_code are required", 400)
    try:
        return ok(pair_linkly_terminal(db(), username, password, pair_code))
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/terminal/charge/<checkout_id>")
@login_required
@tier_required("pos")
def api_pos_terminal_status(checkout_id):
    from core.pos import get_terminal_status
    provider = request.args.get("provider", "")
    try:
        return ok(get_terminal_status(db(), provider, checkout_id))
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/terminal/recover")
@login_required
@tier_required("pos")
def api_pos_terminal_recover():
    from core.pos import recover_linkly_startup
    try:
        return ok(recover_linkly_startup(db()))
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/terminal/print-recovery", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_terminal_print_recovery():
    from core.pos import print_recovery_receipt
    data = request.get_json() or {}
    amount_cents = int(data.get("amount") or 0)
    rfn          = data.get("rfn") or ""
    tx_id        = data.get("tx_id") or ""
    response_text = data.get("response_text") or "Approved"
    try:
        success, msg = print_recovery_receipt(db(), amount_cents, rfn, tx_id, response_text)
        if success:
            return ok()
        return err(msg)
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/terminal/refund", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_terminal_refund():
    from core.pos import refund_linkly_terminal
    data        = request.get_json() or {}
    invoice_id  = data.get("invoice_id")
    amount_cents = int(round(float(data.get("amount", 0)) * 100))
    if not invoice_id:
        return err("invoice_id is missing or null", 400)
    if not amount_cents:
        return err("amount is missing or zero", 400)
    try:
        return ok(refund_linkly_terminal(db(), invoice_id, amount_cents))
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/terminal/cancel", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_terminal_cancel():
    from core.pos import cancel_linkly_transaction
    try:
        return ok(cancel_linkly_transaction(db()))
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/terminal/settle", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_terminal_settle():
    from core.pos import settle_linkly
    try:
        return ok(settle_linkly(db()))
    except Exception as e:
        return err(str(e))


# ── Session management ────────────────────────────────────────────────────────

@bp.route("/api/pos/session")
@login_required
@tier_required("pos")
def api_pos_session_get():
    from core.pos import get_active_pos_session, get_last_pos_float
    session = get_active_pos_session(db())
    return ok({"session": session, "last_float": get_last_pos_float(db())})


@bp.route("/api/pos/session", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_session_open():
    from core.pos import open_pos_session
    data = request.get_json() or {}
    try:
        return ok(open_pos_session(
            db(),
            note=data.get("note", ""),
            opening_float=float(data.get("opening_float") or 0),
            opened_by_user_id=data.get("opened_by_user_id"),
            opened_by_name=data.get("opened_by_name"),
        ))
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/session/<int:session_id>/report")
@login_required
@tier_required("pos")
def api_pos_session_report(session_id):
    from core.pos import get_pos_session_report
    try:
        return ok(get_pos_session_report(db(), session_id))
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/session/<int:session_id>/close", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_session_close(session_id):
    from core.pos import close_pos_session
    data = request.get_json() or {}
    cash_counted = data.get("cash_counted")
    if cash_counted is not None:
        cash_counted = float(cash_counted)
    try:
        return ok(close_pos_session(
            db(), session_id,
            cash_counted=cash_counted,
            banked=float(data.get("banked") or 0),
            float_kept=float(data.get("float_kept") or 0),
            banking_account_id=data.get("banking_account_id"),
        ))
    except Exception as e:
        return err(str(e))


# ── POS register users / PIN auth ─────────────────────────────────────────────

@bp.route("/api/pos/users")
@login_required
def api_pos_users():
    from core.auth import get_pos_users
    return ok(get_pos_users(db()))


@bp.route("/api/pos/auth", methods=["POST"])
@login_required
def api_pos_auth():
    from core.auth import authenticate_pos_pin
    data = request.get_json() or {}
    pin = data.get("pin", "")
    user = authenticate_pos_pin(db(), pin)
    if not user:
        return err("Incorrect PIN", 401)
    return ok(user)


# ── Settings ──────────────────────────────────────────────────────────────────

@bp.route("/api/pos/settings")
@login_required
def api_pos_settings_get():
    from core.pos_settings import get_pos_settings
    s = get_pos_settings(db())
    api_key = s.pop("api_key", "")
    s["api_key_configured"] = bool(api_key)
    if s.get("provider") == "tyro":
        # Tyro API key is never stored in DB — read from env var set at deploy time
        tyro_key = os.environ.get("TYRO_API_KEY") or None
        s["tyro_api_key"] = tyro_key
    return ok(s)


@bp.route("/api/pos/print-raw", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_print_raw():
    from core.pos import print_raw_text
    data = request.get_json() or {}
    text = data.get("text", "")
    if not text:
        return err("text is required", 400)
    try:
        success, msg = print_raw_text(db(), text)
        if success:
            return ok()
        return err(msg)
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/print-receipt", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_print_receipt():
    from core.pos import print_receipt
    data       = request.get_json() or {}
    invoice_id = data.get("invoice_id")
    if not invoice_id:
        return err("invoice_id required", 400)
    tender               = data.get("tender", "cash")
    tendered             = float(data.get("tendered") or 0)
    change               = float(data.get("change") or 0)
    split_tenders        = data.get("split_tenders")
    tyro_surcharge_cents = int(data.get("tyro_surcharge_cents") or 0)
    tyro_receipt_text    = data.get("tyro_receipt_text") or None
    try:
        success, msg = print_receipt(db(), invoice_id, tender, tendered, change, split_tenders,
                                     tyro_surcharge_cents=tyro_surcharge_cents,
                                     tyro_receipt_text=tyro_receipt_text)
        if success:
            return ok()
        return err(msg)
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/sessions")
@login_required
@tier_required("pos")
def api_pos_sessions():
    from core.pos import get_pos_sessions
    limit = int(request.args.get("limit", 30))
    return ok(get_pos_sessions(db(), limit=limit))


@bp.route("/api/pos/summary-report")
@login_required
@tier_required("pos")
def api_pos_summary_report():
    from core.pos import get_pos_summary_report
    date_from = request.args.get("from", "")
    date_to   = request.args.get("to",   "")
    if not date_from or not date_to:
        return err("from and to dates required")
    return ok(get_pos_summary_report(db(), date_from, date_to))


@bp.route("/api/pos/open-drawer", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_open_drawer():
    from core.pos import open_cash_drawer
    success, msg = open_cash_drawer(db())
    if success:
        return ok()
    return err(msg)


@bp.route("/api/pos/print-refund-receipt", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_print_refund_receipt():
    from core.pos import print_refund_receipt
    data = request.get_json() or {}
    cn_id = data.get("cn_id")
    if not cn_id:
        return err("cn_id required", 400)
    tender = data.get("tender", "cash")
    amount = float(data.get("amount") or 0)
    try:
        success, msg = print_refund_receipt(db(), int(cn_id), tender, amount)
        if success:
            return ok()
        return err(msg)
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/store-credit", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_store_credit():
    from core.pos import create_pos_store_credit
    data = request.get_json() or {}
    invoice_id = data.get("invoice_id")
    lines = data.get("lines", [])
    if not invoice_id or not lines:
        return err("invoice_id and lines are required", 400)
    try:
        return ok(create_pos_store_credit(db(), int(invoice_id), lines))
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/print-credit-note", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_print_credit_note():
    from core.pos import print_credit_note_receipt
    data = request.get_json() or {}
    cn_id = data.get("cn_id")
    if not cn_id:
        return err("cn_id required", 400)
    amount = float(data.get("amount") or 0)
    try:
        success, msg = print_credit_note_receipt(db(), int(cn_id), amount)
        if success:
            return ok()
        return err(msg)
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/refund", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_refund():
    from core.pos import create_pos_refund
    data = request.get_json() or {}
    invoice_id = data.get("invoice_id")
    lines = data.get("lines", [])
    tender = data.get("tender", "cash")
    if not invoice_id or not lines:
        return err("invoice_id and lines are required", 400)
    try:
        return ok(create_pos_refund(db(), int(invoice_id), lines, tender))
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/analytics")
@login_required
@tier_required("pos")
def api_pos_analytics():
    from core.pos import get_pos_analytics
    date_from = request.args.get("from", "")
    date_to   = request.args.get("to",   "")
    if not date_from or not date_to:
        return err("from and to dates required")
    return ok(get_pos_analytics(db(), date_from, date_to))


@bp.route("/api/pos/staff-report")
@login_required
@tier_required("pos")
def api_pos_staff_report():
    from core.pos import get_pos_staff_report
    date_from = request.args.get("from", "")
    date_to   = request.args.get("to",   "")
    if not date_from or not date_to:
        return err("from and to dates required")
    return ok(get_pos_staff_report(db(), date_from, date_to))


@bp.route("/api/pos/settings", methods=["POST"])
@login_required
def api_pos_settings_save():
    from core.pos_settings import get_pos_settings, save_pos_settings
    data = request.get_json() or {}
    if data.get("provider") == "tyro":
        # Tyro API key lives in TYRO_API_KEY env var — never touch DB api_key for Tyro
        existing = get_pos_settings(db())
        data["api_key"] = existing.get("api_key", "")
    elif not data.get("api_key"):
        # Non-Tyro providers: preserve stored key if browser sent blank
        existing = get_pos_settings(db())
        data["api_key"] = existing.get("api_key", "")
    save_pos_settings(db(), data)
    return ok()
