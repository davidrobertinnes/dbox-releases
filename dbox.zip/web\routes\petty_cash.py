# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from flask import Blueprint, request
from web.shared import db, ok, err, login_required
from core.petty_cash import (
    get_petty_cash_accounts, get_petty_cash_balance,
    get_petty_cash_transactions, record_disbursement,
    record_replenishment, void_pc_transaction,
    create_petty_cash_float, petty_cash_report,
)
from core.ledger import get_accounts

bp = Blueprint('petty_cash', __name__)


@bp.route("/api/petty-cash")
@login_required
def api_petty_cash_list():
    accounts = get_petty_cash_accounts(db())
    result = []
    for a in accounts:
        d = dict(a)
        d["balance"] = get_petty_cash_balance(db(), a["id"])
        result.append(d)
    return ok(result)


@bp.route("/api/petty-cash/<int:aid>/transactions")
@login_required
def api_pc_transactions(aid):
    date_from = request.args.get("date_from")
    date_to   = request.args.get("date_to")
    txns = get_petty_cash_transactions(db(), aid, date_from, date_to)
    return ok(txns)


@bp.route("/api/petty-cash/<int:aid>/disburse", methods=["POST"])
@login_required
def api_pc_disburse(aid):
    d = request.get_json() or {}
    try:
        amount      = float(d.get("amount") or 0)
        gst_amount  = float(d.get("gst_amount") or 0)
        exp_acc_id  = int(d.get("expense_account_id") or 0)
        disburse_date = d.get("date")
        description = (d.get("description") or "").strip()
        if not amount:
            raise ValueError("Amount is required")
        if not exp_acc_id:
            raise ValueError("Expense account is required")
        if not disburse_date:
            raise ValueError("Date is required")
        if not description:
            raise ValueError("Description is required")
        jid = record_disbursement(
            db(), aid, disburse_date, description,
            amount, gst_amount, exp_acc_id,
            d.get("reference", ""), d.get("contact_id"))
        return ok({"journal_id": jid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/petty-cash/<int:aid>/replenish", methods=["POST"])
@login_required
def api_pc_replenish(aid):
    d = request.get_json() or {}
    try:
        amount       = float(d.get("amount") or 0)
        bank_acc_id  = int(d.get("bank_account_id") or 0)
        replen_date  = d.get("date")
        if not amount:
            raise ValueError("Amount is required")
        if not bank_acc_id:
            raise ValueError("Bank account is required")
        if not replen_date:
            raise ValueError("Date is required")
        jid = record_replenishment(
            db(), aid, replen_date, amount, bank_acc_id,
            d.get("description", ""), d.get("reference", ""))
        return ok({"journal_id": jid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/petty-cash/void", methods=["POST"])
@login_required
def api_pc_void():
    d = request.get_json() or {}
    try:
        jid = int(d.get("journal_id") or 0)
        if not jid:
            raise ValueError("journal_id required")
        void_pc_transaction(db(), jid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/petty-cash/new-float", methods=["POST"])
@login_required
def api_pc_new_float():
    d = request.get_json() or {}
    try:
        name    = (d.get("name") or "").strip()
        code    = (d.get("code") or "").strip()
        opening = float(d.get("opening_balance") or 0)
        if not name:
            raise ValueError("Name is required")
        if not code:
            raise ValueError("Account code is required")
        create_petty_cash_float(db(), name, code, opening)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/petty-cash/bank-accounts")
@login_required
def api_pc_bank_accounts():
    accounts = get_accounts(db(), is_bank=1, is_credit_card=0)
    return ok(accounts)


@bp.route("/api/reports/petty-cash")
@login_required
def api_pc_report():
    account_id = request.args.get("account_id", type=int)
    date_from  = request.args.get("from")
    date_to    = request.args.get("to")
    if not account_id:
        return err("account_id required")
    if not date_from or not date_to:
        return err("from and to dates required")
    try:
        data = petty_cash_report(db(), account_id, date_from, date_to)
        return ok(data)
    except Exception as e:
        return err(str(e))
