@echo off
setlocal EnableDelayedExpansion
title Dogbox Accounting — Uninstaller

cd /d "%~dp0"

echo.
echo  ============================================================
echo   Dogbox Accounting — Uninstaller
echo  ============================================================
echo.
echo  This will remove Dogbox Accounting from your computer.
echo.

REM ── Confirm ───────────────────────────────────────────────────────────────────

set /p CONFIRM="  Are you sure you want to uninstall? [y/N] "
if /i not "%CONFIRM%"=="y" (
    echo.
    echo  Uninstall cancelled.
    pause
    exit /b 0
)

REM ── Stop any running instance ─────────────────────────────────────────────────

echo.
echo  Stopping any running Dogbox instance...

REM Kill python processes running dbox.py (best-effort, ignore if not running)
wmic process where "name='python.exe' and commandline like '%%dbox.py%%'" delete >nul 2>&1
wmic process where "name='pythonw.exe' and commandline like '%%dbox.py%%'" delete >nul 2>&1
if exist "%~dp0dbox.exe" (
    taskkill /f /im dbox.exe >nul 2>&1
)
echo  [  OK  ] Done.

REM ── Remove desktop shortcut ───────────────────────────────────────────────────

echo.
echo  Removing desktop shortcut...

powershell -NoProfile -Command ^
    "$lnk = [Environment]::GetFolderPath('Desktop') + '\Dogbox Accounting.lnk'; if (Test-Path $lnk) { Remove-Item $lnk -Force; Write-Host '  [  OK  ] Shortcut removed.' } else { Write-Host '  [ INFO ] No shortcut found.' }"

REM ── Data files ────────────────────────────────────────────────────────────────

echo.
echo  Your accounting data is stored in .dbox files.
echo.

REM Find any .dbox files in the install folder
set FOUND_DATA=0
for /r "%~dp0" %%f in (*.dbox) do (
    if not defined FOUND_LISTED (
        echo  Found data file(s^):
        set FOUND_LISTED=1
    )
    echo    %%f
    set FOUND_DATA=1
)

if %FOUND_DATA% == 1 (
    echo.
    echo  Do you want to keep your data files?
    echo  (Choose N only if you are certain you no longer need them.)
    echo.
    set /p KEEPDATA="  Keep data files? [Y/n] "
) else (
    echo  No .dbox data files found in this folder.
    set KEEPDATA=n
)

REM ── Remove app folder ─────────────────────────────────────────────────────────

echo.

set INSTALL_DIR=%~dp0
REM Strip trailing backslash for display
set DISPLAY_DIR=%INSTALL_DIR:~0,-1%

if /i "%KEEPDATA%"=="n" (
    echo  Removing %DISPLAY_DIR% ...
    REM Self-delete: copy this script to TEMP, delete the folder from there
    copy "%~f0" "%TEMP%\dbox_uninstall_final.bat" >nul 2>&1
    REM Schedule folder deletion via a detached cmd that waits 1 second for this script to exit
    start "" /b cmd /c "ping 127.0.0.1 -n 2 >nul && rd /s /q ""%DISPLAY_DIR%"""
    echo  [  OK  ] Folder will be removed momentarily.
) else (
    REM Keep data — remove everything except .dbox files
    echo  Removing app files (keeping .dbox data files)...
    echo.

    REM Delete known app files and folders, leave .dbox files in place
    for %%d in (core web assets docs dist ui) do (
        if exist "%INSTALL_DIR%%%d" (
            rd /s /q "%INSTALL_DIR%%%d" >nul 2>&1
        )
    )
    for %%f in (
        dbox.py dbox.bat dbox.sh dbox.pyw dbox.exe
        wininstall.bat winuninstall.bat macinstall.sh lininstall.sh
        dbox.conf requirements.txt README.md RELEASE_NOTES.txt
        EULA.txt LICENSE.txt version.txt CHANGELOG.md NOTES.md
        CLAUDE.md main.py
    ) do (
        if exist "%INSTALL_DIR%%%f" del /f /q "%INSTALL_DIR%%%f" >nul 2>&1
    )

    echo  [  OK  ] App files removed.
    echo.
    echo  Your data files remain in:
    echo    %DISPLAY_DIR%
    echo.
    echo  You can move them to another location and open them with
    echo  a fresh Dogbox install at any time.
)

REM ── Done ─────────────────────────────────────────────────────────────────────

echo.
echo  ============================================================
echo   Dogbox Accounting has been uninstalled.
echo   Thank you for using Dogbox.
echo  ============================================================
echo.
pause
exit /b 0
