@echo off
:: dbox Windows Launcher (fallback - shows console window)
:: Use dbox.pyw for silent launch (no console window)
cd /d "%~dp0"
python dbox.pyw
if %ERRORLEVEL% neq 0 (
    echo.
    echo dbox failed to start. Check that Python 3.10+ is installed.
    echo Run: python --version
    pause
)
