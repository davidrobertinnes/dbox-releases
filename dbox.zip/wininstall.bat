@echo off
setlocal EnableDelayedExpansion
title Dogbox Accounting — Windows Installer

REM ─────────────────────────────────────────────────────────────────────────────
REM  wininstall.bat  —  Dogbox Accounting Windows Installer
REM  Drop this file in the dbox folder and double-click to run.
REM ─────────────────────────────────────────────────────────────────────────────

cd /d "%~dp0"

echo.
echo  ============================================================
echo   Dogbox Accounting — Windows Installer
echo  ============================================================
echo.

REM ── Binary mode: if dbox.exe is present, skip Python entirely ─────────────────
if exist "%~dp0dbox.exe" goto :binary_install

REM ── Step 1: Find Python ───────────────────────────────────────────────────────

set PYTHON_EXE=

REM Check known install locations first (never the Windows Store stub)
if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" (
    set PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python313\python.exe& goto :verify_python)
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe& goto :verify_python)
if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
    set PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe& goto :verify_python)
if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" (
    set PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python310\python.exe& goto :verify_python)
if exist "%ProgramFiles%\Python313\python.exe" (
    set PYTHON_EXE=%ProgramFiles%\Python313\python.exe& goto :verify_python)
if exist "%ProgramFiles%\Python312\python.exe" (
    set PYTHON_EXE=%ProgramFiles%\Python312\python.exe& goto :verify_python)
if exist "%ProgramFiles%\Python311\python.exe" (
    set PYTHON_EXE=%ProgramFiles%\Python311\python.exe& goto :verify_python)
if exist "%ProgramFiles%\Python310\python.exe" (
    set PYTHON_EXE=%ProgramFiles%\Python310\python.exe& goto :verify_python)
if exist "C:\Python313\python.exe" (
    set PYTHON_EXE=C:\Python313\python.exe& goto :verify_python)
if exist "C:\Python312\python.exe" (
    set PYTHON_EXE=C:\Python312\python.exe& goto :verify_python)
if exist "C:\Python311\python.exe" (
    set PYTHON_EXE=C:\Python311\python.exe& goto :verify_python)
if exist "C:\Python310\python.exe" (
    set PYTHON_EXE=C:\Python310\python.exe& goto :verify_python)

REM Try py launcher
where py >nul 2>&1
if %errorlevel% == 0 (
    set PYTHON_EXE=py& goto :verify_python)

REM Last resort: 'where python' but skip the Windows Store stub
for /f "delims=" %%i in ('where python 2^>nul') do (
    echo %%i | findstr /i "WindowsApps" >nul
    if errorlevel 1 (
        set PYTHON_EXE=%%i& goto :verify_python)
)

REM Nothing found — offer to download
goto :download_python

:verify_python
"%PYTHON_EXE%" -c "import sys; sys.exit(0)" >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ WARN ] Found Python but it did not run. Trying download...
    set PYTHON_EXE=
    goto :download_python
)
goto :found_python

:download_python
echo  [ WARN ] Python 3.10 or later is required but was not found.
echo.
echo  Python is free and takes about 2 minutes to install.
echo  Download it from:  https://www.python.org/downloads/
echo.
echo  IMPORTANT: On the installer's first screen, tick:
echo    "Add python.exe to PATH"
echo.
echo  After installing Python, close this window and
echo  double-click wininstall.bat again.
echo.
set /p DOWNLOAD="  Open the Python download page now? [Y/n] "
if /i not "%DOWNLOAD%"=="n" (
    start https://www.python.org/downloads/
)
echo.
pause
exit /b 1

:found_python
for /f "tokens=*" %%v in ('"%PYTHON_EXE%" --version 2^>^&1') do set PY_VER=%%v
echo  [  OK  ] Found %PY_VER%
echo.

REM ── Step 2: Install required packages ────────────────────────────────────────

echo  Checking required packages...
echo.

set MISSING=0

"%PYTHON_EXE%" -c "import flask" >nul 2>&1
if %errorlevel% neq 0 set MISSING=1

"%PYTHON_EXE%" -c "import reportlab" >nul 2>&1
if %errorlevel% neq 0 set MISSING=1

"%PYTHON_EXE%" -c "from PIL import Image" >nul 2>&1
if %errorlevel% neq 0 set MISSING=1

if %MISSING% == 0 (
    echo  [  OK  ] Required packages already installed.
    goto :shortcut
)

echo  [ WARN ] Some required packages are missing ^(flask, reportlab, pillow^).
echo.
set /p INSTALLPKG="  Install them now? [Y/n] "
if /i "%INSTALLPKG%"=="n" (
    echo.
    echo  [ WARN ] Skipping. Some features will not work until these are installed.
    echo           Run:  pip install flask reportlab pillow
    goto :shortcut
)

echo.
echo  Installing packages...
"%PYTHON_EXE%" -m pip install --upgrade pip -q
"%PYTHON_EXE%" -m pip install flask reportlab pillow -q

if %errorlevel% neq 0 (
    echo.
    echo  [ERROR ] pip install failed. Check your internet connection and try again.
    echo           Or run manually:  pip install flask reportlab pillow
    pause
    exit /b 1
)
echo  [  OK  ] Packages installed.

REM ── Step 3: Create desktop shortcut with icon ─────────────────────────────────

:shortcut
echo.
echo  Creating desktop shortcut...

REM Resolve full path to web_server.py and the icon
set DBOX_PYW=%~dp0web_server.py
set DBOX_ICON=%~dp0assets\dogbox_icon.ico

REM Fall back to PNG if no .ico — VBScript will handle it gracefully
if not exist "%DBOX_ICON%" (
    set DBOX_ICON=%~dp0assets\dogbox_icon.png
)

REM Use PowerShell to create the shortcut — resolve Desktop via shell (handles OneDrive redirection)
powershell -NoProfile -Command "$desktop = [Environment]::GetFolderPath('Desktop'); $ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut($desktop + '\Dogbox Accounting.lnk'); $s.TargetPath = '%PYTHON_EXE%'; $s.Arguments = '\"%DBOX_PYW%\"'; $s.WorkingDirectory = '%~dp0'; $s.WindowStyle = 1; $s.Description = 'Dogbox Accounting - Australian Small Business Accounting'; if (Test-Path '%DBOX_ICON%') { $s.IconLocation = '%DBOX_ICON%' }; $s.Save()"

if %errorlevel% == 0 (
    echo  [  OK  ] Desktop shortcut created: "Dogbox Accounting"
) else (
    echo  [ WARN ] Could not create desktop shortcut automatically.
    echo           You can create one manually by right-clicking web_server.py.
)

REM ── Done ─────────────────────────────────────────────────────────────────────

echo.
echo  ============================================================
echo   Installation complete!
echo.
echo   Dogbox opens in your browser - double-click the desktop
echo   shortcut and it will launch automatically.
echo.
echo   Or run from a terminal:
echo     python web_server.py
echo  ============================================================
echo.

set /p LAUNCH="  Launch Dogbox Accounting now? [Y/n] "
if /i not "%LAUNCH%"=="n" (
    start "" "%PYTHON_EXE%" "%DBOX_PYW%"
)

echo.
pause
exit /b 0

REM ── Binary install (dbox.exe present — no Python required) ───────────────────
:binary_install
echo  Found dbox.exe — no Python installation required.
echo.
echo  Creating desktop shortcut...

set DBOX_EXE=%~dp0dbox.exe
set DBOX_ICON=%~dp0assets\dogbox_icon.ico
if not exist "%DBOX_ICON%" set DBOX_ICON=%~dp0assets\icon.ico

powershell -NoProfile -Command "$desktop = [Environment]::GetFolderPath('Desktop'); $ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut($desktop + '\Dogbox Accounting.lnk'); $s.TargetPath = '%DBOX_EXE%'; $s.WorkingDirectory = '%~dp0'; $s.WindowStyle = 1; $s.Description = 'Dogbox Accounting - Australian Small Business Accounting'; if (Test-Path '%DBOX_ICON%') { $s.IconLocation = '%DBOX_ICON%' }; $s.Save()"

if %errorlevel% == 0 (
    echo  [  OK  ] Desktop shortcut created: "Dogbox Accounting"
) else (
    echo  [ WARN ] Could not create shortcut automatically. Right-click dbox.exe to pin or create one manually.
)

echo.
echo  ============================================================
echo   Installation complete!
echo.
echo   Double-click the desktop shortcut or dbox.exe to launch.
echo  ============================================================
echo.

set /p LAUNCH="  Launch Dogbox Accounting now? [Y/n] "
if /i not "%LAUNCH%"=="n" (
    start "" "%DBOX_EXE%"
)

echo.
pause
exit /b 0
