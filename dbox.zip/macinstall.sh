#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
#  macinstall.sh  —  Dogbox Accounting macOS Installer
#  Usage:  chmod +x macinstall.sh && ./macinstall.sh
#  Or right-click → Open With → Terminal
# ─────────────────────────────────────────────────────────────────────────────

# NOTE: Do NOT use 'set -e' here — we handle errors explicitly so that a pip
# failure in one package doesn't silently kill the whole installer.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'
info()  { echo -e "${CYAN}[dbox]${RESET} $*"; }
ok()    { echo -e "${GREEN}[  OK  ]${RESET} $*"; }
warn()  { echo -e "${YELLOW}[ WARN ]${RESET} $*"; }
error() { echo -e "${RED}[ERROR ]${RESET} $*"; }

echo -e "${BOLD}Dogbox Accounting — macOS Installer${RESET}"
echo "────────────────────────────────────"
echo ""

# ── 1. Find Python 3.9+ ──────────────────────────────────────────────────────
PYTHON=""
for cmd in python3 python3.13 python3.12 python3.11 python3.10 python3.9; do
    if command -v "$cmd" &>/dev/null; then
        VER=$("$cmd" -c "import sys; print(sys.version_info >= (3,9))" 2>/dev/null)
        if [ "$VER" = "True" ]; then
            PYTHON="$cmd"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    error "Python 3.9 or later is required but was not found."
    echo ""
    echo "  Download it from:  https://www.python.org/downloads/"
    echo "  Or via Homebrew:   brew install python3"
    echo ""
    read -r -p "  Open python.org now? [Y/n] " REPLY
    if [[ ! "$REPLY" =~ ^[Nn]$ ]]; then
        open "https://www.python.org/downloads/"
    fi
    exit 1
fi

PY_VER=$("$PYTHON" --version 2>&1)
ok "Found $PY_VER  ($PYTHON)"

# ── 2. Install required packages ──────────────────────────────────────────────
MISSING_PKGS=()
"$PYTHON" -c "import flask"          2>/dev/null || MISSING_PKGS+=("flask")
"$PYTHON" -c "import reportlab"      2>/dev/null || MISSING_PKGS+=("reportlab")
"$PYTHON" -c "from PIL import Image" 2>/dev/null || MISSING_PKGS+=("pillow")

if [ ${#MISSING_PKGS[@]} -gt 0 ]; then
    warn "Missing packages: ${MISSING_PKGS[*]}"
    echo ""
    read -r -p "  Install them now with pip? [Y/n] " REPLY
    echo ""
    if [[ ! "$REPLY" =~ ^[Nn]$ ]]; then
        for pkg in "${MISSING_PKGS[@]}"; do
            info "Installing $pkg..."
            if "$PYTHON" -m pip install "$pkg" --quiet; then
                ok "$pkg installed."
            else
                warn "Could not install $pkg. Try:  pip3 install $pkg"
            fi
        done
    else
        warn "Skipping. Some features will not work until these are installed."
    fi
else
    ok "Required packages already installed."
fi

# ── 3. Create desktop shortcut (.command file) ────────────────────────────────
echo ""
info "Creating desktop shortcut..."

DESKTOP_DIR="$HOME/Desktop"
SHORTCUT="$DESKTOP_DIR/Dogbox Accounting.command"

cat > "$SHORTCUT" <<EOF
#!/usr/bin/env bash
cd "$SCRIPT_DIR"
exec "$PYTHON" dbox.py
EOF

chmod +x "$SHORTCUT"
ok "Desktop shortcut created: ~/Desktop/Dogbox Accounting.command"
echo ""
echo "  Double-click the shortcut to launch — Dogbox opens in your browser."
echo "  macOS may ask you to confirm on first run — click Open."

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}============================================================${RESET}"
echo -e " Installation complete!"
echo ""
echo "  Dogbox runs in your browser — it will open automatically"
echo "  when you launch from the desktop shortcut."
echo ""
echo "  Or run from Terminal:"
echo "    python3 dbox.py"
echo -e "${BOLD}============================================================${RESET}"
echo ""

read -r -p "  Launch Dogbox Accounting now? [Y/n] " REPLY
echo ""
if [[ ! "$REPLY" =~ ^[Nn]$ ]]; then
    exec "$PYTHON" dbox.py
fi
