// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ═══════════════════════════════════════════════════════════════════════════
// PETTY CASH
// ═══════════════════════════════════════════════════════════════════════════
let _pcFloats=[], _pcSelectedFloat=null, _pcTxns=[], _pcAccounts=[];
let _pcDateFrom='', _pcDateTo='';

async function pagePettyCash() {
  try {
    [_pcFloats, _pcAccounts] = await Promise.all([
      apiFetch('/api/petty-cash').then(r=>r||[]),
      apiFetch('/api/accounts').then(r=>r||[]),
    ]);
    if (!_pcSelectedFloat && _pcFloats.length)
      _pcSelectedFloat = _pcFloats[0].id;
    _pcRenderPage();
    if (_pcSelectedFloat) await _pcLoadTxns();
  } catch(e) {
    document.getElementById('module-content').innerHTML=
      `<div class="state-error">Failed to load petty cash: ${esc(e.message)}</div>`;
  }
}

function _pcRenderPage() {
  const mc = document.getElementById('module-content');
  if (!_pcFloats.length) {
    mc.innerHTML=`
      <div class="pc-empty-wrap">
        <div class="state-empty">
          <div style="font-size:36px;margin-bottom:12px">💰</div>
          <div style="font-size:16px;font-weight:600;margin-bottom:6px">No petty cash floats</div>
          <div style="color:var(--ink2);margin-bottom:18px">Create a float to start tracking petty cash</div>
          <button class="btn btn-primary" onclick="_pcNewFloat()">+ New Float</button>
        </div>
      </div>`;
    return;
  }

  const float = _pcFloats.find(f=>f.id===_pcSelectedFloat);

  mc.innerHTML=`
    <div class="pc-float-bar">
      ${_pcFloats.map(f=>`
        <button class="pc-float-btn${f.id===_pcSelectedFloat?' active':''}"
          onclick="_pcSelectFloat(${f.id})">
          ${esc(f.name)}
          <span class="pc-float-bal">$${(f.balance||0).toFixed(2)}</span>
        </button>`).join('')}
      <button class="btn btn-outline pc-new-float-btn" onclick="_pcNewFloat()">+ New Float</button>
    </div>
    <div class="inv-toolbar" style="margin-top:14px">
      <div style="display:flex;gap:8px;align-items:center">
        <label class="edt-lbl" style="margin:0">From</label>
        <input type="date" class="edt-inp" id="pc-from" value="${_pcDateFrom}"
          onchange="_pcDateFrom=this.value;_pcLoadTxns()">
        <label class="edt-lbl" style="margin:0">To</label>
        <input type="date" class="edt-inp" id="pc-to" value="${_pcDateTo}"
          onchange="_pcDateTo=this.value;_pcLoadTxns()">
        <button class="btn btn-outline" onclick="_pcClearDates()">Clear</button>
      </div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-primary" onclick="_pcNewDisburse()">+ Disbursement</button>
        <button class="btn btn-outline" onclick="_pcNewReplenish()">Replenish Float</button>
        <button class="btn btn-outline" onclick="_pcReconcile()">Reconcile</button>
      </div>
    </div>
    <div class="inv-list-panel" style="margin-top:12px"><div class="tbl-overflow-x">
      <table class="inv-list-table">
        <thead><tr>
          <th>Date</th><th>Reference</th><th>Description</th>
          <th>Type</th><th class="th-r">Amount</th><th class="th-r">Balance</th>
          <th></th>
        </tr></thead>
        <tbody id="pc-txn-body">
          <tr><td colspan="7" class="tbl-empty-row">Loading…</td></tr>
        </tbody>
      </table>
    </div></div>
    <div class="list-count-row" id="pc-count-row"></div>`;
}

async function _pcLoadTxns() {
  if (!_pcSelectedFloat) return;
  const body = document.getElementById('pc-txn-body');
  if (body) body.innerHTML='<tr><td colspan="7" class="tbl-empty-row">Loading…</td></tr>';
  let url = `/api/petty-cash/${_pcSelectedFloat}/transactions`;
  const qs = [];
  if (_pcDateFrom) qs.push(`date_from=${_pcDateFrom}`);
  if (_pcDateTo)   qs.push(`date_to=${_pcDateTo}`);
  if (qs.length) url += '?' + qs.join('&');
  try {
    _pcTxns = await apiFetch(url) || [];
    _pcRenderTxns();
  } catch(e) {
    if (body) body.innerHTML=`<tr><td colspan="7" class="tbl-empty-row">${esc(e.message)}</td></tr>`;
  }
}

function _pcRenderTxns() {
  const body = document.getElementById('pc-txn-body');
  if (!body) return;
  const float = _pcFloats.find(f=>f.id===_pcSelectedFloat);
  const opening = float?.opening_balance || 0;

  if (!_pcTxns.length) {
    body.innerHTML='<tr><td colspan="7" class="tbl-empty-row">No transactions</td></tr>';
    document.getElementById('pc-count-row').innerHTML='<span class="count-pill">0 transactions</span>';
    return;
  }

  let runBal = opening;
  const rows = _pcTxns.map(t => {
    runBal += (t.movement || 0);
    const voided = (t.journal_desc||'').startsWith('[VOIDED]');
    const isVoid  = (t.entry_type||'').startsWith('VOID') ||
                    (t.journal_desc||'').startsWith('VOID:');
    const typeBadge = voided
      ? `<span class="badge badge-draft">Voided</span>`
      : isVoid
        ? `<span class="badge badge-draft">Reversal</span>`
        : t.entry_type==='PC Disbursement'
          ? `<span class="badge badge-amber">Disbursement</span>`
          : t.entry_type==='PC Replenishment'
            ? `<span class="badge badge-blue">Replenishment</span>`
            : `<span class="badge badge-draft">${esc(t.entry_type||'—')}</span>`;
    const amt = t.movement;
    const amtClass = amt < 0 ? 'pc-amt-out' : 'pc-amt-in';
    const amtStr = (amt < 0 ? '-' : '+') + '$' + Math.abs(amt).toFixed(2);
    const desc = t.line_desc || t.journal_desc || '—';
    const canVoid = !voided && !isVoid;
    return `<tr class="${voided||isVoid?'pc-row-voided':''}">
      <td class="inv-mono">${fmtDate(t.entry_date)}</td>
      <td class="inv-mono itm-sm-muted">${esc(t.reference||'—')}</td>
      <td>${esc(desc)}</td>
      <td>${typeBadge}</td>
      <td class="td-r-mono ${amtClass}">${amtStr}</td>
      <td class="td-r-mono">${runBal<0?'<span style="color:var(--red)">':''}$${runBal.toFixed(2)}${runBal<0?'</span>':''}</td>
      <td>${canVoid?`<button class="btn-link-sm" onclick="_pcVoid(${t.journal_id})">Void</button>`:''}</td>
    </tr>`;
  });
  body.innerHTML = rows.join('');
  document.getElementById('pc-count-row').innerHTML=
    `<span class="count-pill">${_pcTxns.length} transaction${_pcTxns.length!==1?'s':''}</span>`;
}

async function _pcSelectFloat(id) {
  _pcSelectedFloat = id;
  _pcRenderPage();
  await _pcLoadTxns();
}

function _pcClearDates() {
  _pcDateFrom=''; _pcDateTo='';
  _pcRenderPage();
  _pcLoadTxns();
}

// ── Disbursement form ─────────────────────────────────────────────────────
function _pcNewDisburse() {
  const expenseAccs = _pcAccounts.filter(a=>
    ['Expense','COGS','Cost of Goods Sold'].includes(a.account_type) && a.is_active);
  const today = new Date().toISOString().slice(0,10);
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = 'New Disbursement';
  document.getElementById('det-body').innerHTML=`
    <div class="edt-grid">
      <div class="edt-field"><label class="edt-lbl">Date *</label>
        <input type="date" class="edt-inp" id="pc-d-date" value="${today}"></div>
      <div class="edt-field"><label class="edt-lbl">Reference</label>
        <input class="edt-inp" id="pc-d-ref" placeholder="e.g. Receipt #"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Description *</label>
        <input class="edt-inp" id="pc-d-desc" placeholder="What was purchased?"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Expense Account *</label>
        <select class="edt-sel" id="pc-d-acc">
          <option value=""></option>
          ${expenseAccs.map(a=>`<option value="${a.id}">${esc(a.code+' '+a.name)}</option>`).join('')}
        </select></div>
      <div class="edt-field"><label class="edt-lbl">Amount (excl. GST) *</label>
        <input class="edt-inp" id="pc-d-amt" type="number" step="0.01" min="0"
          oninput="_pcCalcTotal()"></div>
      <div class="edt-field"><label class="edt-lbl">GST Amount</label>
        <input class="edt-inp" id="pc-d-gst" type="number" step="0.01" min="0"
          oninput="_pcCalcTotal()"></div>
      <div class="edt-field edt-span">
        <div class="pc-total-row">
          Total: <span id="pc-d-total" class="pc-total-val">$0.00</span>
          <button class="btn-link-sm" onclick="_pcFillGst()" style="margin-left:12px">Fill GST (10%)</button>
        </div>
      </div>
    </div>`;
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="pc-d-save" onclick="_pcSaveDisburse()">Save</button>
    <button class="btn btn-outline" onclick="detClose()">Cancel</button>`;
  setTimeout(()=>document.getElementById('pc-d-date')?.focus(), 50);
}

function _pcCalcTotal() {
  const amt = parseFloat(document.getElementById('pc-d-amt')?.value)||0;
  const gst = parseFloat(document.getElementById('pc-d-gst')?.value)||0;
  const el = document.getElementById('pc-d-total');
  if (el) el.textContent = '$' + (amt+gst).toFixed(2);
}

function _pcFillGst() {
  const amt = parseFloat(document.getElementById('pc-d-amt')?.value)||0;
  const gstEl = document.getElementById('pc-d-gst');
  if (gstEl) { gstEl.value = (amt/10).toFixed(2); _pcCalcTotal(); }
}

async function _pcSaveDisburse() {
  const date    = document.getElementById('pc-d-date')?.value;
  const desc    = document.getElementById('pc-d-desc')?.value.trim();
  const acc_id  = parseInt(document.getElementById('pc-d-acc')?.value)||0;
  const amount  = parseFloat(document.getElementById('pc-d-amt')?.value)||0;
  const gst     = parseFloat(document.getElementById('pc-d-gst')?.value)||0;
  const ref     = document.getElementById('pc-d-ref')?.value.trim()||'';
  if (!date)    { toast('Date is required','err'); return; }
  if (!desc)    { toast('Description is required','err'); return; }
  if (!acc_id)  { toast('Expense account is required','err'); return; }
  if (!amount)  { toast('Amount is required','err'); return; }
  const btn = document.getElementById('pc-d-save');
  btn.disabled=true; btn.textContent='Saving…';
  try {
    await fetch(`/api/petty-cash/${_pcSelectedFloat}/disburse`,
      {method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',
       body:JSON.stringify({date,description:desc,amount,gst_amount:gst,
                            expense_account_id:acc_id,reference:ref})})
      .then(r=>r.json()).then(j=>{if(!j.ok)throw new Error(j.error||'Failed');});
    toast('Disbursement recorded');
    detClose();
    await _pcRefresh();
  } catch(e) { toast(e.message,'err'); btn.disabled=false; btn.textContent='Save'; }
}

// ── Replenishment form ────────────────────────────────────────────────────
function _pcNewReplenish() {
  const bankAccs = _pcAccounts.filter(a=>a.is_bank && !a.is_credit_card && a.is_active);
  const today = new Date().toISOString().slice(0,10);
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = 'Replenish Float';
  document.getElementById('det-body').innerHTML=`
    <div class="edt-grid">
      <div class="edt-field"><label class="edt-lbl">Date *</label>
        <input type="date" class="edt-inp" id="pc-r-date" value="${today}"></div>
      <div class="edt-field"><label class="edt-lbl">Amount *</label>
        <input class="edt-inp" id="pc-r-amt" type="number" step="0.01" min="0"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">From Bank Account *</label>
        <select class="edt-sel" id="pc-r-bank">
          <option value=""></option>
          ${bankAccs.map(a=>`<option value="${a.id}">${esc(a.code+' '+a.name)}</option>`).join('')}
        </select></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Description</label>
        <input class="edt-inp" id="pc-r-desc" value="Petty Cash Replenishment"></div>
      <div class="edt-field"><label class="edt-lbl">Reference</label>
        <input class="edt-inp" id="pc-r-ref"></div>
    </div>`;
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="pc-r-save" onclick="_pcSaveReplenish()">Replenish</button>
    <button class="btn btn-outline" onclick="detClose()">Cancel</button>`;
  setTimeout(()=>document.getElementById('pc-r-amt')?.focus(), 50);
}

async function _pcSaveReplenish() {
  const date     = document.getElementById('pc-r-date')?.value;
  const amount   = parseFloat(document.getElementById('pc-r-amt')?.value)||0;
  const bank_id  = parseInt(document.getElementById('pc-r-bank')?.value)||0;
  const desc     = document.getElementById('pc-r-desc')?.value.trim()||'';
  const ref      = document.getElementById('pc-r-ref')?.value.trim()||'';
  if (!date)    { toast('Date is required','err'); return; }
  if (!amount)  { toast('Amount is required','err'); return; }
  if (!bank_id) { toast('Bank account is required','err'); return; }
  const btn = document.getElementById('pc-r-save');
  btn.disabled=true; btn.textContent='Saving…';
  try {
    await fetch(`/api/petty-cash/${_pcSelectedFloat}/replenish`,
      {method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',
       body:JSON.stringify({date,amount,bank_account_id:bank_id,description:desc,reference:ref})})
      .then(r=>r.json()).then(j=>{if(!j.ok)throw new Error(j.error||'Failed');});
    toast('Float replenished');
    detClose();
    await _pcRefresh();
  } catch(e) { toast(e.message,'err'); btn.disabled=false; btn.textContent='Replenish'; }
}

// ── Void ──────────────────────────────────────────────────────────────────
async function _pcVoid(journalId) {
  if (!confirm('Void this transaction? A reversal journal entry will be posted.')) return;
  try {
    const r = await fetch('/api/petty-cash/void',
      {method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',
       body:JSON.stringify({journal_id:journalId})});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error||'Failed');
    toast('Transaction voided');
    await _pcRefresh();
  } catch(e) { toast(e.message,'err'); }
}

// ── Reconciliation wizard ─────────────────────────────────────────────────
let _pcWizRows=[], _pcWizBd=null, _pcWizFloat=null, _pcWizPosted=[];
let _pcWizExpAccOpts='', _pcWizBankAccOpts='';

function _pcReconcile() {
  _pcWizFloat = _pcFloats.find(f=>f.id===_pcSelectedFloat);
  if (!_pcWizFloat) return;
  const today = new Date().toISOString().slice(0,10);
  _pcWizRows = [{ date:today, desc:'', acc_id:0, amount:'', gst:'' }];
  _pcWizPosted = [];
  _pcWizExpAccOpts = _pcAccounts
    .filter(a=>['Expense','COGS','Cost of Goods Sold'].includes(a.account_type) && a.is_active)
    .map(a=>`<option value="${a.id}">${esc(a.code+' '+a.name)}</option>`).join('');
  _pcWizBankAccOpts = _pcAccounts
    .filter(a=>a.is_bank && !a.is_credit_card && a.is_active)
    .map(a=>`<option value="${a.id}">${esc(a.code+' '+a.name)}</option>`).join('');
  _pcWizBd = document.createElement('div');
  _pcWizBd.className='modal-bd'; _pcWizBd.style.display='flex';
  document.body.appendChild(_pcWizBd);
  _pcWizBd.addEventListener('click', e=>{ if(e.target===_pcWizBd) _pcWizBd.remove(); });
  _pcWizStep1();
}

function _pcWizStep1() {
  _pcWizBd.innerHTML=`<div class="modal-box pc-wiz-box">
    <div class="modal-hdr">Reconcile — ${esc(_pcWizFloat.name)}<span class="pc-wiz-step-lbl">Step 1 of 2 — Enter receipts</span></div>
    <div class="modal-body pc-wiz-scroll">
      <table class="pc-wiz-tbl">
        <thead><tr>
          <th style="width:118px">Date</th><th>Description</th>
          <th style="width:200px">Account</th>
          <th class="th-r" style="width:95px">Net $</th>
          <th class="th-r" style="width:88px">GST $</th>
          <th style="width:44px"></th>
        </tr></thead>
        <tbody id="pc-wiz-tbody"></tbody>
      </table>
      <div class="pc-wiz-footer-row">
        <button class="btn btn-outline" onclick="_pcWizAddRow()">+ Add Row</button>
        <span class="pc-wiz-running">Total: <strong id="pc-wiz-total">$0.00</strong></span>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-primary" id="pc-wiz-post-btn" onclick="_pcWizPost()">Post & Continue →</button>
      <button class="btn btn-outline" onclick="_pcWizBd.remove()">Cancel</button>
    </div>
  </div>`;
  _pcWizRenderRows();
}

function _pcWizRenderRows() {
  const tbody = document.getElementById('pc-wiz-tbody');
  if (!tbody) return;
  tbody.innerHTML = _pcWizRows.map((r,i)=>`<tr>
    <td><input type="date" class="edt-inp pc-wiz-inp" value="${r.date}"
      onchange="_pcWizRows[${i}].date=this.value"></td>
    <td><input class="edt-inp pc-wiz-inp" value="${esc(r.desc)}" placeholder="What was purchased?"
      oninput="_pcWizRows[${i}].desc=this.value"></td>
    <td><select class="edt-sel pc-wiz-inp" onchange="_pcWizRows[${i}].acc_id=+this.value">
      <option value="0"></option>${_pcWizExpAccOpts}
    </select></td>
    <td><input type="number" class="edt-inp pc-wiz-inp pc-wiz-num" step="0.01" min="0"
      value="${r.amount}" placeholder="0.00"
      oninput="_pcWizRows[${i}].amount=this.value;_pcWizCalcTotal()"
      onfocus="this.select()"></td>
    <td><div class="pc-wiz-gst-cell">
      <input type="number" class="edt-inp pc-wiz-inp pc-wiz-num" step="0.01" min="0"
        value="${r.gst}" placeholder="0.00"
        oninput="_pcWizRows[${i}].gst=this.value;_pcWizCalcTotal()"
        onfocus="this.select()">
      <button class="btn-link-sm pc-wiz-10pct" onclick="_pcWizFillGst(${i})" title="Fill 10%">10%</button>
    </div></td>
    <td>${_pcWizRows.length>1
      ?`<button class="btn-link-sm" onclick="_pcWizRemoveRow(${i})" style="color:var(--red)">✕</button>`
      :''}</td>
  </tr>`).join('');
  const sels = tbody.querySelectorAll('select');
  _pcWizRows.forEach((r,i)=>{ if(sels[i]) sels[i].value = r.acc_id||0; });
  _pcWizCalcTotal();
}

function _pcWizSaveDom() {
  const tbody = document.getElementById('pc-wiz-tbody');
  if (!tbody) return;
  tbody.querySelectorAll('tr').forEach((tr,i)=>{
    if (!_pcWizRows[i]) return;
    const inp = tr.querySelectorAll('input');
    const sel = tr.querySelector('select');
    if (inp[0]) _pcWizRows[i].date   = inp[0].value;
    if (inp[1]) _pcWizRows[i].desc   = inp[1].value;
    if (sel)    _pcWizRows[i].acc_id = +sel.value||0;
    if (inp[2]) _pcWizRows[i].amount = inp[2].value;
    if (inp[3]) _pcWizRows[i].gst    = inp[3].value;
  });
}

function _pcWizAddRow() {
  _pcWizSaveDom();
  const lastDate = _pcWizRows.length ? _pcWizRows[_pcWizRows.length-1].date : new Date().toISOString().slice(0,10);
  _pcWizRows.push({ date:lastDate, desc:'', acc_id:0, amount:'', gst:'' });
  _pcWizRenderRows();
  setTimeout(()=>{
    const rows = document.querySelectorAll('#pc-wiz-tbody tr');
    const last = rows[rows.length-1];
    if (last) { const inp = last.querySelectorAll('input'); if(inp[1]) inp[1].focus(); }
  }, 30);
}

function _pcWizRemoveRow(i) {
  _pcWizSaveDom();
  _pcWizRows.splice(i,1);
  _pcWizRenderRows();
}

function _pcWizFillGst(i) {
  _pcWizSaveDom();
  _pcWizRows[i].gst = ((parseFloat(_pcWizRows[i].amount)||0)/10).toFixed(2);
  _pcWizRenderRows();
}

function _pcWizCalcTotal() {
  const total = _pcWizRows.reduce((s,r)=>s+(parseFloat(r.amount)||0)+(parseFloat(r.gst)||0),0);
  const el = document.getElementById('pc-wiz-total');
  if (el) el.textContent = '$'+total.toFixed(2);
}

async function _pcWizPost() {
  _pcWizSaveDom();
  const valid = _pcWizRows.filter(r=>r.desc.trim() && r.acc_id && parseFloat(r.amount)>0);
  if (!valid.length) { toast('Enter at least one receipt with description, account, and amount','err'); return; }
  const btn = document.getElementById('pc-wiz-post-btn');
  btn.disabled=true; btn.textContent='Posting…';
  try {
    const posted = [];
    for (const r of valid) {
      const j = await fetch(`/api/petty-cash/${_pcSelectedFloat}/disburse`,{
        method:'POST', headers:{'Content-Type':'application/json'}, credentials:'include',
        body:JSON.stringify({ date:r.date, description:r.desc.trim(),
          amount:parseFloat(r.amount)||0, gst_amount:parseFloat(r.gst)||0,
          expense_account_id:r.acc_id })
      }).then(r=>r.json());
      if (!j.ok) throw new Error(j.error||'Post failed');
      posted.push({...r, journal_id:j.data.journal_id});
    }
    _pcWizPosted = posted;
    _pcFloats = await apiFetch('/api/petty-cash').then(r=>r||[]);
    _pcWizFloat = _pcFloats.find(f=>f.id===_pcSelectedFloat);
    _pcWizStep2();
  } catch(e) {
    toast(e.message,'err'); btn.disabled=false; btn.textContent='Post & Continue →';
  }
}

function _pcWizStep2() {
  const expected = _pcWizFloat?.balance||0;
  const sessionTotal = _pcWizPosted.reduce((s,r)=>s+(parseFloat(r.amount)||0)+(parseFloat(r.gst)||0),0);
  const today = new Date().toISOString().slice(0,10);
  _pcWizBd.innerHTML=`<div class="modal-box pc-wiz-box">
    <div class="modal-hdr">Reconcile — ${esc(_pcWizFloat.name)}<span class="pc-wiz-step-lbl">Step 2 of 2 — Count &amp; balance</span></div>
    <div class="modal-body">
      <div class="pc-recon-row" style="padding:10px 0;border-bottom:1px solid var(--border);margin-bottom:16px">
        <span>${_pcWizPosted.length} receipt${_pcWizPosted.length!==1?'s':''} posted — $${sessionTotal.toFixed(2)}</span>
        <span>GL balance: <strong>$${expected.toFixed(2)}</strong></span>
      </div>
      <div class="edt-field">
        <label class="edt-lbl">Physical count ($)</label>
        <input class="edt-inp" id="pc-wiz-count" type="number" step="0.01" placeholder="0.00"
          oninput="_pcWizVarianceCalc(${expected})">
      </div>
      <div id="pc-wiz-variance" style="margin-top:10px"></div>
      <div style="margin-top:20px;padding-top:16px;border-top:1px solid var(--border)">
        <div class="pc-wiz-section-lbl">Replenish Float</div>
        <div class="edt-grid">
          <div class="edt-field"><label class="edt-lbl">Date</label>
            <input type="date" class="edt-inp" id="pc-wiz-rpl-date" value="${today}"></div>
          <div class="edt-field"><label class="edt-lbl">Amount ($)</label>
            <input type="number" class="edt-inp" id="pc-wiz-rpl-amt" step="0.01" min="0"
              value="${sessionTotal.toFixed(2)}"></div>
          <div class="edt-field edt-span"><label class="edt-lbl">From Bank Account</label>
            <select class="edt-sel" id="pc-wiz-rpl-bank">
              <option value="0"></option>${_pcWizBankAccOpts}
            </select></div>
        </div>
        <button class="btn btn-primary" id="pc-wiz-rpl-btn" onclick="_pcWizDoReplenish()">Replenish →</button>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-outline" onclick="_pcWizPrintSlips()">Print Slips</button>
      <button class="btn btn-outline" onclick="_pcWizViewReport()">View Report</button>
      <button class="btn btn-primary" onclick="_pcWizDone()">Done</button>
    </div>
  </div>`;
  setTimeout(()=>document.getElementById('pc-wiz-count')?.focus(), 50);
}

function _pcWizVarianceCalc(expected) {
  const count = parseFloat(document.getElementById('pc-wiz-count')?.value)||0;
  const v = count - expected;
  const el = document.getElementById('pc-wiz-variance');
  if (!el) return;
  if (Math.abs(v)<0.005)
    el.innerHTML=`<div class="pc-recon-variance pc-recon-ok">Balanced ✓</div>`;
  else if (v<0)
    el.innerHTML=`<div class="pc-recon-variance pc-recon-short">Short $${Math.abs(v).toFixed(2)}</div>`;
  else
    el.innerHTML=`<div class="pc-recon-variance pc-recon-over">Over $${Math.abs(v).toFixed(2)}</div>`;
}

async function _pcWizDoReplenish() {
  const date   = document.getElementById('pc-wiz-rpl-date')?.value;
  const amount = parseFloat(document.getElementById('pc-wiz-rpl-amt')?.value)||0;
  const bank   = parseInt(document.getElementById('pc-wiz-rpl-bank')?.value)||0;
  if (!date)   { toast('Date required','err'); return; }
  if (!amount) { toast('Amount required','err'); return; }
  if (!bank)   { toast('Select a bank account','err'); return; }
  const btn = document.getElementById('pc-wiz-rpl-btn');
  btn.disabled=true; btn.textContent='Replenishing…';
  try {
    const j = await fetch(`/api/petty-cash/${_pcSelectedFloat}/replenish`,{
      method:'POST', headers:{'Content-Type':'application/json'}, credentials:'include',
      body:JSON.stringify({ date, amount, bank_account_id:bank })
    }).then(r=>r.json());
    if (!j.ok) throw new Error(j.error||'Failed');
    toast('Float replenished');
    btn.textContent='Replenished ✓'; btn.className='btn btn-outline';
    _pcFloats = await apiFetch('/api/petty-cash').then(r=>r||[]);
    _pcWizFloat = _pcFloats.find(f=>f.id===_pcSelectedFloat);
  } catch(e) { toast(e.message,'err'); btn.disabled=false; btn.textContent='Replenish →'; }
}

function _pcWizPrintSlips() {
  if (!_pcWizPosted.length) { toast('No receipts to print','err'); return; }
  const floatName = _pcWizFloat?.name||'Petty Cash';
  const today = new Date().toLocaleDateString('en-AU');
  const slips = _pcWizPosted.map(r=>{
    const acc = _pcAccounts.find(a=>a.id===r.acc_id);
    const net = parseFloat(r.amount)||0;
    const gst = parseFloat(r.gst)||0;
    return `<div class="slip">
      <div class="slip-hdr">${esc(floatName)}</div>
      <table class="slip-tbl">
        <tr><td>Date</td><td>${fmtDate(r.date)}</td></tr>
        <tr><td>Description</td><td>${esc(r.desc)}</td></tr>
        <tr><td>Account</td><td>${esc(acc?acc.code+' '+acc.name:'—')}</td></tr>
        ${gst?`<tr><td>Net</td><td>$${net.toFixed(2)}</td></tr>
        <tr><td>GST</td><td>$${gst.toFixed(2)}</td></tr>`:''}
        <tr class="slip-total"><td>Total</td><td>$${(net+gst).toFixed(2)}</td></tr>
      </table>
      <div class="slip-foot">Attach to receipt — ${today}</div>
    </div>`;
  }).join('');
  const win = window.open('','_blank','width=750,height=900');
  win.document.write(`<!DOCTYPE html><html><head><title>Petty Cash Slips</title><style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:Arial,sans-serif;font-size:12px;padding:20px;background:#fff;color:#222}
  .page-hdr{font-size:11px;color:#777;margin-bottom:16px}
  .slips{display:flex;flex-wrap:wrap;gap:14px}
  .slip{border:1px solid #bbb;border-radius:4px;padding:12px;width:220px;page-break-inside:avoid}
  .slip-hdr{font-weight:700;font-size:13px;border-bottom:1px solid #ccc;padding-bottom:6px;margin-bottom:8px}
  .slip-tbl{width:100%;border-collapse:collapse;font-size:11px}
  .slip-tbl td{padding:2px 4px;vertical-align:top}
  .slip-tbl td:first-child{color:#666;width:70px;white-space:nowrap}
  .slip-total td{font-weight:700;border-top:1px solid #ccc;padding-top:4px}
  .slip-foot{margin-top:10px;font-size:10px;color:#999;border-top:1px dashed #ccc;padding-top:6px}
  @media print{body{padding:6px}.page-hdr{display:none}}
  </style></head><body>
  <div class="page-hdr">${esc(floatName)} — Petty Cash Reconciliation — ${today}</div>
  <div class="slips">${slips}</div>
  <script>window.onload=function(){window.print();}<\/script>
  </body></html>`);
  win.document.close();
}

function _pcWizViewReport() {
  _pcWizBd.remove();
  // Pre-set reports module state so it opens straight to this float's report
  _rptActiveType  = 'pettycash';
  _rptPcFloatId   = _pcSelectedFloat;
  _rptPcFloats    = _pcFloats.length ? _pcFloats : null;
  _rptDateFrom    = _pcDateFrom || _rptFyStart();
  _rptDateTo      = _pcDateTo   || _rptToday();
  navigate('reports');
}

async function _pcWizDone() {
  _pcWizBd.remove();
  await _pcRefresh();
}

// ── New Float modal ───────────────────────────────────────────────────────
function _pcNewFloat() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display='flex';
  bd.innerHTML=`<div class="modal-box" style="max-width:400px">
    <div class="modal-hdr">New Petty Cash Float</div>
    <div class="modal-body">
      <div class="edt-grid">
        <div class="edt-field edt-span">
          <label class="edt-lbl">Float Name *</label>
          <input class="edt-inp" id="pc-nf-name" placeholder="e.g. Office Petty Cash">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Account Code * <span class="con-field-hint">(Asset — start with 1-)</span></label>
          <input class="edt-inp" id="pc-nf-code" placeholder="e.g. 1-0900">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Opening Balance ($)</label>
          <input class="edt-inp" id="pc-nf-ob" type="number" step="0.01" min="0" placeholder="0.00">
        </div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-primary" id="pc-nf-save" onclick="_pcSaveNewFloat(this)">Create</button>
      <button class="btn btn-outline" onclick="this.closest('.modal-bd').remove()">Cancel</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  bd.addEventListener('click', e=>{ if(e.target===bd) bd.remove(); });
  setTimeout(()=>document.getElementById('pc-nf-name')?.focus(), 50);
}

async function _pcSaveNewFloat(btn) {
  const name = document.getElementById('pc-nf-name')?.value.trim();
  const code = document.getElementById('pc-nf-code')?.value.trim();
  const ob   = parseFloat(document.getElementById('pc-nf-ob')?.value)||0;
  if (!name) { toast('Name is required','err'); return; }
  if (!code) { toast('Account code is required','err'); return; }
  btn.disabled=true; btn.textContent='Creating…';
  try {
    const r = await fetch('/api/petty-cash/new-float',
      {method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',
       body:JSON.stringify({name,code,opening_balance:ob})});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error||'Failed');
    toast('Float created');
    btn.closest('.modal-bd').remove();
    await _pcRefresh();
  } catch(e) { toast(e.message,'err'); btn.disabled=false; btn.textContent='Create'; }
}

// ── Helpers ───────────────────────────────────────────────────────────────
async function _pcRefresh() {
  _pcFloats = await apiFetch('/api/petty-cash').then(r=>r||[]);
  _pcRenderPage();
  await _pcLoadTxns();
}
