#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
#  lininstall.sh  —  Dogbox Accounting Linux Installer
#  Supports: Ubuntu, Debian, Linux Mint, Pop!_OS, and any apt-based distro.
#  Usage:  chmod +x lininstall.sh && ./lininstall.sh
# ─────────────────────────────────────────────────────────────────────────────

# NOTE: Do NOT use 'set -e' here — we handle errors explicitly so that a pip
# failure in one package doesn't silently kill the whole installer.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'
info()  { echo -e "${CYAN}[dbox]${RESET} $*"; }
ok()    { echo -e "${GREEN}[  OK  ]${RESET} $*"; }
warn()  { echo -e "${YELLOW}[ WARN ]${RESET} $*"; }
error() { echo -e "${RED}[ERROR ]${RESET} $*"; }

echo -e "${BOLD}Dogbox Accounting — Linux Installer${RESET}"
echo "────────────────────────────────────"
echo ""

# ── 1. Fix CRLF line endings on all shell scripts ────────────────────────────
for f in lininstall.sh dbox.sh; do
    if [ -f "$f" ]; then
        sed -i 's/\r//' "$f"
    fi
done

# ── 2. Set execute permissions ────────────────────────────────────────────────
chmod +x dbox.sh 2>/dev/null || true

# ── 3. Find Python 3.9+ ──────────────────────────────────────────────────────
PYTHON=""
for cmd in python3 python3.13 python3.12 python3.11 python3.10 python3.9; do
    if command -v "$cmd" &>/dev/null; then
        VER=$("$cmd" -c "import sys; print(sys.version_info >= (3,9))" 2>/dev/null)
        if [ "$VER" = "True" ]; then
            PYTHON="$cmd"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    error "Python 3.9 or later is required but was not found."
    echo ""
    if command -v apt-get &>/dev/null; then
        read -r -p "  Install Python 3 now? (requires sudo) [Y/n] " REPLY
        echo ""
        if [[ ! "$REPLY" =~ ^[Nn]$ ]]; then
            sudo apt-get update 2>/dev/null || warn "apt-get update had errors — trying install anyway"
            if sudo apt-get install -y --fix-missing python3 python3-pip; then
                for cmd in python3 python3.12 python3.11 python3.10 python3.9; do
                    if command -v "$cmd" &>/dev/null; then
                        VER=$("$cmd" -c "import sys; print(sys.version_info >= (3,9))" 2>/dev/null)
                        if [ "$VER" = "True" ]; then
                            PYTHON="$cmd"
                            break
                        fi
                    fi
                done
                if [ -z "$PYTHON" ]; then
                    error "Python installed but still not detected. Please re-run lininstall.sh."
                    exit 1
                fi
                ok "Python installed successfully."
            else
                error "Auto-install failed. Run:  sudo apt install python3 python3-pip"
                exit 1
            fi
        else
            echo "  Install it with:  sudo apt install python3 python3-pip"
            exit 1
        fi
    else
        echo "  Fedora/RHEL:  sudo dnf install python3 python3-pip"
        echo "  Arch:         sudo pacman -S python python-pip"
        exit 1
    fi
fi

PY_VER=$("$PYTHON" --version 2>&1)
ok "Found $PY_VER  ($PYTHON)"

# ── 4. Ensure pip is available ────────────────────────────────────────────────
if ! "$PYTHON" -m pip --version &>/dev/null; then
    warn "pip is not installed for $PYTHON."
    echo ""
    if command -v apt-get &>/dev/null; then
        read -r -p "  Install python3-pip now? (requires sudo) [Y/n] " REPLY
        echo ""
        if [[ ! "$REPLY" =~ ^[Nn]$ ]]; then
            sudo apt-get update 2>/dev/null || warn "apt-get update had errors — trying install anyway"
            if sudo apt-get install -y --fix-missing python3-pip; then
                ok "python3-pip installed."
            else
                error "Auto-install failed. Run:  sudo apt install python3-pip"
                exit 1
            fi
        else
            error "pip is required to install packages. Please install it and re-run lininstall.sh."
            exit 1
        fi
    else
        error "pip is required but not installed."
        echo "  Fedora/RHEL:  sudo dnf install python3-pip"
        echo "  Arch:         sudo pacman -S python-pip"
        exit 1
    fi
fi
ok "pip is available."

# ── 5. Install required packages ──────────────────────────────────────────────
# Check all required packages, collect all missing ones before prompting —
# so the user gets one prompt for all, not one per package.
MISSING_PKGS=()
"$PYTHON" -c "import flask"          2>/dev/null || MISSING_PKGS+=("flask")
"$PYTHON" -c "import reportlab"      2>/dev/null || MISSING_PKGS+=("reportlab")
"$PYTHON" -c "from PIL import Image" 2>/dev/null || MISSING_PKGS+=("pillow")

if [ ${#MISSING_PKGS[@]} -gt 0 ]; then
    warn "Missing packages: ${MISSING_PKGS[*]}"
    echo ""
    read -r -p "  Install them now with pip? [Y/n] " REPLY
    echo ""
    if [[ ! "$REPLY" =~ ^[Nn]$ ]]; then

        # Detect externally-managed environments (PEP 668) by checking for the
        # marker file directly — safer than running a --dry-run that can itself fail.
        PIP_FLAGS=""
        PY_LIB=$("$PYTHON" -c "import sysconfig; print(sysconfig.get_path('stdlib'))" 2>/dev/null)
        if [ -f "${PY_LIB}/EXTERNALLY-MANAGED" ]; then
            warn "System Python is externally managed — using --break-system-packages"
            PIP_FLAGS="--break-system-packages"
        fi

        INSTALL_FAILED=()
        for pkg in "${MISSING_PKGS[@]}"; do
            info "Installing $pkg..."
            if "$PYTHON" -m pip install $PIP_FLAGS "$pkg" --quiet; then
                ok "$pkg installed."
            else
                warn "Could not install $pkg."
                INSTALL_FAILED+=("$pkg")
            fi
        done

        if [ ${#INSTALL_FAILED[@]} -gt 0 ]; then
            echo ""
            warn "The following packages could not be installed automatically:"
            for pkg in "${INSTALL_FAILED[@]}"; do
                echo "    pip3 install $pkg"
            done
            echo ""
            warn "Some features will not work until these are installed."
        fi
    else
        warn "Skipping. Some features will not work until these are installed."
    fi
else
    ok "Required packages already installed."
fi

# ── 6. Create desktop shortcut ────────────────────────────────────────────────
echo ""
info "Creating desktop shortcut..."

DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")"
ICON_PATH="$SCRIPT_DIR/assets/dogbox_icon.png"
SHORTCUT="$DESKTOP_DIR/Dogbox Accounting.desktop"

cat > "$SHORTCUT" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Dogbox Accounting
Comment=Australian Small Business Accounting
Exec=bash "$SCRIPT_DIR/dbox.sh"
Icon=$ICON_PATH
Terminal=false
Categories=Office;Finance;
Keywords=accounting;invoices;payroll;GST;BAS;
EOF

chmod +x "$SHORTCUT"

# Trust the shortcut on GNOME (suppresses "Untrusted application" prompt)
if command -v gio &>/dev/null; then
    gio set "$SHORTCUT" metadata::trusted true 2>/dev/null || true
fi

ok "Desktop shortcut created."

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}============================================================${RESET}"
echo -e " Installation complete!"
echo ""
echo "  Dogbox runs in your browser — no separate browser needed,"
echo "  it will open automatically when you launch."
echo ""
echo "  Launch from your desktop shortcut, or run:"
echo "    bash dbox.sh"
echo -e "${BOLD}============================================================${RESET}"
echo ""

read -r -p "  Launch Dogbox Accounting now? [Y/n] " REPLY
echo ""
if [[ ! "$REPLY" =~ ^[Nn]$ ]]; then
    exec "$PYTHON" dbox.py
fi
