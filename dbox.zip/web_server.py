# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

#!/usr/bin/env python3
"""
dbox Web Interface — launcher
Usage: python web_server.py [your_file.dbox] [--port 5000]
       python web_server.py          (shows file picker)

If the server is already running on the port, this script just opens
the browser to the existing session instead of starting a second instance.
"""
import sys, os, argparse, threading, webbrowser, subprocess, logging

# Running under pythonw.exe (no console): stdout/stderr are None — redirect to
# devnull so print() doesn't raise, and suppress Flask's request log.
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
logging.getLogger('werkzeug').setLevel(logging.ERROR)

# Add project root to path so 'core' package resolves
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import web.server as _srv
from core.database import initialise_database, seed_defaults
from core.budget   import ensure_default_admin


# ── Already-running check ──────────────────────────────────────────────────────
def _server_already_running(host: str, port: int) -> bool:
    """
    Returns True if something is already listening on host:port.
    If so, the launcher just opens the browser rather than starting again.
    """
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        try:
            s.connect((host, port))
            return True
        except (ConnectionRefusedError, OSError):
            return False



# ── App-mode browser launcher ──────────────────────────────────────────────────
def _open_app_browser(url: str) -> bool:
    """
    Open the URL in Chromium app mode (no URL bar, no tabs — looks like a
    native desktop application).

    Strategy:
      1. Check the OS default browser via the Windows registry.
         If it is Chromium-based (Chrome, Edge, Brave, Opera, Vivaldi, Arc)
         use that browser with --app flag.
      2. If the default is Firefox, IE, Safari, or unknown, fall back to
         Edge (always present on Windows 10/11), then Chrome.
      3. If no Chromium browser is found at all, open a normal browser tab
         via webbrowser.open() so nothing ever silently fails.

    Returns True if app-mode was launched, False if fell back to normal tab.
    """

    # ── Candidate executable paths (platform-specific) ───────────────────────
    if sys.platform == "win32":
        _CHROME_PATHS = [
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%PROGRAMFILES%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%PROGRAMFILES(X86)%\Google\Chrome\Application\chrome.exe"),
        ]
        _EDGE_PATHS = [
            os.path.expandvars(r"%PROGRAMFILES(X86)%\Microsoft\Edge\Application\msedge.exe"),
            os.path.expandvars(r"%PROGRAMFILES%\Microsoft\Edge\Application\msedge.exe"),
            os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
        ]
        _BRAVE_PATHS = [
            os.path.expandvars(r"%LOCALAPPDATA%\BraveSoftware\Brave-Browser\Application\brave.exe"),
            os.path.expandvars(r"%PROGRAMFILES%\BraveSoftware\Brave-Browser\Application\brave.exe"),
        ]
        _CHROMIUM_PATHS = [
            os.path.expandvars(r"%LOCALAPPDATA%\Chromium\Application\chrome.exe"),
        ]
    elif sys.platform == "darwin":
        _CHROME_PATHS = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            os.path.expanduser("~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
        ]
        _EDGE_PATHS = [
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        ]
        _BRAVE_PATHS = [
            "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
        ]
        _CHROMIUM_PATHS = [
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
        ]
    else:  # Linux / other Unix
        _CHROME_PATHS = [
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
        ]
        _EDGE_PATHS = [
            "/usr/bin/microsoft-edge",
            "/usr/bin/microsoft-edge-stable",
        ]
        _BRAVE_PATHS = [
            "/usr/bin/brave-browser",
        ]
        _CHROMIUM_PATHS = [
            "/usr/bin/chromium-browser",
            "/usr/bin/chromium",
        ]

    def _find_exe(paths):
        for p in paths:
            if p and os.path.isfile(p):
                return p
        return None

    def _launch(exe, url):
        """Launch exe in --app mode, detached from this process."""
        try:
            subprocess.Popen(
                [exe, f"--app={url}"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                close_fds=True,
            )
            return True
        except Exception:
            return False

    # ── Step 1: detect default browser on Windows ─────────────────────────────
    default_is_chromium = False
    default_exe = None

    if sys.platform == "win32":
        try:
            import winreg
            # ProgID for the default HTTP handler
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice") as k:
                prog_id = winreg.QueryValueEx(k, "ProgId")[0].lower()

            # Map known Chromium-based ProgIDs
            _CHROMIUM_PROGIDS = (
                "chromehtml", "chromiumhtm",
                "msedgehtm",
                "bravehtml",
                "operastable", "operahtml",
                "vivaldhtml",
                "archtml",
            )
            if any(prog_id.startswith(p) for p in _CHROMIUM_PROGIDS):
                default_is_chromium = True
                # Find the actual executable for the default browser
                if "chrome" in prog_id:
                    default_exe = _find_exe(_CHROME_PATHS)
                elif "edge" in prog_id:
                    default_exe = _find_exe(_EDGE_PATHS)
                elif "brave" in prog_id:
                    default_exe = _find_exe(_BRAVE_PATHS)
                # Opera/Vivaldi/Arc: fall through to generic chromium search
                if not default_exe:
                    default_exe = _find_exe(_CHROME_PATHS + _EDGE_PATHS + _BRAVE_PATHS + _CHROMIUM_PATHS)
        except Exception:
            pass  # registry unavailable or key not found — continue to fallback

    # ── Step 2: launch in app mode ────────────────────────────────────────────
    if default_is_chromium and default_exe:
        # User's preferred browser is Chromium-based — use it
        if _launch(default_exe, url):
            return True

    # Default was Firefox/unknown — try Edge (guaranteed on Win10/11), then Chrome
    for paths in (_EDGE_PATHS, _CHROME_PATHS, _BRAVE_PATHS, _CHROMIUM_PATHS):
        exe = _find_exe(paths)
        if exe and _launch(exe, url):
            return True

    # ── Step 3: no Chromium browser found — open normal browser tab ───────────
    webbrowser.open(url)
    return False


# ── Main ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="dbox Web Interface")
    parser.add_argument("db_file", nargs="?", default=None,
                        help="Path to .dbox file (optional — shows file picker if omitted)")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--host", default="127.0.0.1")
    args = parser.parse_args()

    url = f"http://{args.host}:{args.port}"

    # ── If server already running, just re-open the browser and exit ──────────
    if _server_already_running(args.host, args.port):
        print(f"\n  dbox: server already running at {url}")
        print(f"  Opening browser...\n")
        _open_app_browser(url)
        sys.exit(0)

    # ── Initialise DB now only when a file is supplied as a CLI argument ─────
    if args.db_file:
        db_path = os.path.abspath(args.db_file)
        _srv.DB_PATH = db_path
        import hashlib, time as _time
        _seed = f"dbox-web-{db_path}-{_time.time()}"
        _srv.app.secret_key = hashlib.sha256(_seed.encode()).digest()
        print(f"\n  dbox Web Interface")
        print(f"  {'─' * 37}")
        print(f"  Database : {db_path}")
        initialise_database(db_path)
        seed_defaults(db_path)
        ensure_default_admin(db_path)
        print(f"  Login    : admin / admin  (change after first login)")
        print(f"  Open     : {url}")
        _open_url = url
    else:
        # No file supplied — the browser startup page handles file selection.
        print(f"\n  dbox Web Interface")
        print(f"  {'─' * 37}")
        print(f"  No file specified — select or create one in the browser.")
        print(f"  Open     : {url}/startup")
        _open_url = f"{url}/startup"

    print(f"  Locks automatically after 10 minutes of inactivity.\n")

    # ── Open browser automatically after server starts ────────────────────────
    def _open_browser():
        import time; time.sleep(1.2)
        launched = _open_app_browser(_open_url)
        if not launched:
            print("  Note: no Chromium browser found — opened in default browser (tab mode)")
    threading.Thread(target=_open_browser, daemon=True).start()

    # The inactivity timer starts on first heartbeat ping from the browser,
    # not at launch — so the startup period does not count toward the timeout.
    _srv.app.run(host=args.host, port=args.port, debug=False)
