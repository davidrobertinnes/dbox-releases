# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

#!/usr/bin/env python3
"""
dbox Web Interface — launcher
Usage: python web_server.py [your_file.dbox] [--port 5000]
       python web_server.py          (shows file picker)
       python web_server.py --lan    (LAN server — advertises via mDNS)

If the server is already running on the port, this script just opens
the browser to the existing session instead of starting a second instance.
On a LAN: run with --lan on the server machine; run with no args on the
client machine and it will auto-discover the server via mDNS (dogbox.local).
"""
import sys, os, json, argparse, threading, webbrowser, subprocess, logging, atexit

# Running under pythonw.exe (no console): stdout/stderr are None — redirect to
# devnull so print() doesn't raise, and suppress Flask's request log.
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
logging.getLogger('werkzeug').setLevel(logging.ERROR)

# Add project root to path so 'core' package resolves
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Fixed Chrome profile dir — gives us a real, trackable process (not delegated to
# an existing Chrome instance), without creating a new temp dir on every launch.
# When compiled with Nuitka --onefile, __file__ lands in a temp extraction dir that
# is wiped on shutdown. Detect this by checking if the executable name is Python itself;
# if not, we're a compiled binary and persistent user data must live next to the .exe.
_exe = sys.executable
_is_compiled = not os.path.basename(_exe).lower().startswith(('python', 'py.', 'pypy'))
_DATA_DIR = (os.path.dirname(os.path.realpath(_exe)) if _is_compiled
             else os.path.dirname(os.path.abspath(__file__)))

_CHROME_PROFILE = os.path.join(_DATA_DIR, '.chrome-profile')
_CONF_PATH     = os.path.join(_DATA_DIR, 'dbox.conf')
_browser_proc  = None


def _load_conf() -> dict:
    try:
        with open(_CONF_PATH) as _f:
            return json.load(_f)
    except Exception:
        return {}


def _save_conf(conf: dict) -> None:
    try:
        import json as _json
        with open(_CONF_PATH, 'w') as _f:
            _json.dump(conf, _f, indent=2)
    except Exception:
        pass


def _close_browser():
    """Kill the browser process tree on server exit (e.g. Ctrl+C in terminal)."""
    if not _browser_proc or _browser_proc.poll() is not None:
        return
    try:
        if sys.platform == "win32":
            subprocess.call(
                ['taskkill', '/F', '/T', '/PID', str(_browser_proc.pid)],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        else:
            _browser_proc.terminate()
    except Exception:
        pass

atexit.register(_close_browser)


import web.server as _srv
from core.database import initialise_database, seed_defaults
from core.budget   import ensure_default_admin


# ── mDNS service name ─────────────────────────────────────────────────────────
_MDNS_TYPE = "_dogbox._tcp.local."
_MDNS_NAME = "Dogbox Accounting._dogbox._tcp.local."
_zeroconf_instance = None   # kept alive for duration of server process


def _lan_ip() -> str:
    """Return the machine's outbound LAN IP (not 127.0.0.1)."""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return socket.gethostbyname(socket.gethostname())


def _mdns_advertise(port: int) -> None:
    """Register a _dogbox._tcp mDNS service so LAN clients can discover this server."""
    global _zeroconf_instance
    try:
        from zeroconf import Zeroconf, ServiceInfo
        import socket
        ip = _lan_ip()
        info = ServiceInfo(
            _MDNS_TYPE,
            _MDNS_NAME,
            addresses=[socket.inet_aton(ip)],
            port=port,
            properties={b"version": b"1"},
        )
        zc = Zeroconf()
        zc.register_service(info)
        _zeroconf_instance = zc
        atexit.register(_mdns_unregister)
        print(f"  mDNS    : advertising as dogbox.local:{port}")
    except ImportError:
        print("  mDNS    : zeroconf not installed — run: pip install zeroconf")
    except Exception as e:
        print(f"  mDNS    : could not advertise ({e})")


def _mdns_unregister() -> None:
    """Unregister the mDNS service on server shutdown."""
    global _zeroconf_instance
    if _zeroconf_instance:
        try:
            _zeroconf_instance.unregister_all_services()
            _zeroconf_instance.close()
        except Exception:
            pass
        _zeroconf_instance = None


def _mdns_discover(timeout: float = 3.0) -> str | None:
    """
    Browse for a _dogbox._tcp service on the LAN.
    Returns the server URL (e.g. 'http://192.168.1.5:5000') or None if not found.
    """
    try:
        from zeroconf import Zeroconf, ServiceBrowser, ServiceStateChange
        import socket, time
        found: list[str] = []

        def _on_change(zeroconf, service_type, name, state_change):
            if state_change == ServiceStateChange.Added:
                info = zeroconf.get_service_info(service_type, name)
                if info and info.addresses:
                    addr = socket.inet_ntoa(info.addresses[0])
                    found.append(f"http://{addr}:{info.port}")

        zc = Zeroconf()
        ServiceBrowser(zc, _MDNS_TYPE, handlers=[_on_change])
        deadline = time.time() + timeout
        while not found and time.time() < deadline:
            time.sleep(0.1)
        zc.close()
        return found[0] if found else None
    except ImportError:
        return None   # zeroconf not installed — silent skip
    except Exception:
        return None


# ── Already-running check ──────────────────────────────────────────────────────
def _server_already_running(host: str, port: int) -> bool:
    """
    Returns True if something is already listening on host:port.
    If so, the launcher just opens the browser rather than starting again.
    """
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        try:
            s.connect((host, port))
            return True
        except (ConnectionRefusedError, OSError):
            return False



# ── App-mode browser launcher ──────────────────────────────────────────────────
def _open_app_browser(url: str) -> bool:
    """
    Open the URL in Chromium app mode (no URL bar, no tabs — looks like a
    native desktop application).

    Strategy:
      1. Check the OS default browser via the Windows registry.
         If it is Chromium-based (Chrome, Edge, Brave, Opera, Vivaldi, Arc)
         use that browser with --app flag.
      2. If the default is Firefox, IE, Safari, or unknown, fall back to
         Edge (always present on Windows 10/11), then Chrome.
      3. If no Chromium browser is found at all, open a normal browser tab
         via webbrowser.open() so nothing ever silently fails.

    Returns True if app-mode was launched, False if fell back to normal tab.
    """

    # ── Candidate executable paths (platform-specific) ───────────────────────
    if sys.platform == "win32":
        _CHROME_PATHS = [
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%PROGRAMFILES%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%PROGRAMFILES(X86)%\Google\Chrome\Application\chrome.exe"),
        ]
        _EDGE_PATHS = [
            os.path.expandvars(r"%PROGRAMFILES(X86)%\Microsoft\Edge\Application\msedge.exe"),
            os.path.expandvars(r"%PROGRAMFILES%\Microsoft\Edge\Application\msedge.exe"),
            os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
        ]
        _BRAVE_PATHS = [
            os.path.expandvars(r"%LOCALAPPDATA%\BraveSoftware\Brave-Browser\Application\brave.exe"),
            os.path.expandvars(r"%PROGRAMFILES%\BraveSoftware\Brave-Browser\Application\brave.exe"),
        ]
        _CHROMIUM_PATHS = [
            os.path.expandvars(r"%LOCALAPPDATA%\Chromium\Application\chrome.exe"),
        ]
    elif sys.platform == "darwin":
        _CHROME_PATHS = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            os.path.expanduser("~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
        ]
        _EDGE_PATHS = [
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        ]
        _BRAVE_PATHS = [
            "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
        ]
        _CHROMIUM_PATHS = [
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
        ]
    else:  # Linux / other Unix
        _CHROME_PATHS = [
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
        ]
        _EDGE_PATHS = [
            "/usr/bin/microsoft-edge",
            "/usr/bin/microsoft-edge-stable",
        ]
        _BRAVE_PATHS = [
            "/usr/bin/brave-browser",
        ]
        _CHROMIUM_PATHS = [
            "/usr/bin/chromium-browser",
            "/usr/bin/chromium",
        ]

    def _find_exe(paths):
        for p in paths:
            if p and os.path.isfile(p):
                return p
        return None

    def _launch(exe, url):
        """Launch exe in --app mode; --user-data-dir keeps it as a real trackable process."""
        try:
            return subprocess.Popen(
                [exe, f"--app={url}", f"--user-data-dir={_CHROME_PROFILE}",
                 "--no-first-run", "--no-default-browser-check",
                 "--disable-session-crashed-bubble"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception:
            return None

    def _store_proc(proc):
        global _browser_proc
        _browser_proc = proc
        try:
            import web.routes.system as _sys
            _sys._browser_proc = proc
        except Exception:
            pass

    # ── Step 1: detect default browser on Windows ─────────────────────────────
    default_is_chromium = False
    default_exe = None

    if sys.platform == "win32":
        try:
            import winreg
            # ProgID for the default HTTP handler
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\http\UserChoice") as k:
                prog_id = winreg.QueryValueEx(k, "ProgId")[0].lower()

            # Map known Chromium-based ProgIDs
            _CHROMIUM_PROGIDS = (
                "chromehtml", "chromiumhtm",
                "msedgehtm",
                "bravehtml",
                "operastable", "operahtml",
                "vivaldhtml",
                "archtml",
            )
            if any(prog_id.startswith(p) for p in _CHROMIUM_PROGIDS):
                default_is_chromium = True
                # Find the actual executable for the default browser
                if "chrome" in prog_id:
                    default_exe = _find_exe(_CHROME_PATHS)
                elif "edge" in prog_id:
                    default_exe = _find_exe(_EDGE_PATHS)
                elif "brave" in prog_id:
                    default_exe = _find_exe(_BRAVE_PATHS)
                # Opera/Vivaldi/Arc: fall through to generic chromium search
                if not default_exe:
                    default_exe = _find_exe(_CHROME_PATHS + _EDGE_PATHS + _BRAVE_PATHS + _CHROMIUM_PATHS)
        except Exception:
            pass  # registry unavailable or key not found — continue to fallback

    # ── Step 2: launch in app mode ────────────────────────────────────────────
    if default_is_chromium and default_exe:
        # User's preferred browser is Chromium-based — use it
        proc = _launch(default_exe, url)
        if proc:
            _store_proc(proc)
            return True

    # Default was Firefox/unknown — try Edge (guaranteed on Win10/11), then Chrome
    for paths in (_EDGE_PATHS, _CHROME_PATHS, _BRAVE_PATHS, _CHROMIUM_PATHS):
        exe = _find_exe(paths)
        if exe:
            proc = _launch(exe, url)
            if proc:
                _store_proc(proc)
                return True

    # ── Step 3: no Chromium browser found — open normal browser tab ───────────
    webbrowser.open(url)
    return False


# ── Main ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="dbox Web Interface")
    parser.add_argument("db_file", nargs="?", default=None,
                        help="Path to .dbox file (optional — shows file picker if omitted)")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--lan", action="store_true",
                        help="Bind to 0.0.0.0 so other machines on the LAN can connect")
    args = parser.parse_args()

    # Apply LAN mode from persistent config if not explicitly passed on CLI
    _conf = _load_conf()
    if not args.lan and _conf.get('lan'):
        args.lan = True

    if args.lan and args.host == "127.0.0.1":
        # Check licence before allowing LAN mode
        try:
            _app_dir = os.path.dirname(os.path.abspath(__file__))
            from core.licence import get_licence_status, has_feature
            _lic = get_licence_status(_app_dir)
            if not has_feature(_lic, "lan"):
                print("\n  dbox: LAN server mode is not enabled on this licence.")
                print("  Contact support to enable multi-user / LAN access.\n")
                sys.exit(1)
        except SystemExit:
            raise
        except Exception as e:
            print(f"\n  dbox: could not verify licence for LAN mode ({e})\n")
            sys.exit(1)
        args.host = "0.0.0.0"
        # Persist so future restarts keep LAN mode without --lan flag
        if not _conf.get('lan'):
            _conf['lan'] = True
            _save_conf(_conf)

    url = f"http://{args.host}:{args.port}"
    # Browser on this machine always uses 127.0.0.1 — 0.0.0.0 is a bind address, not a valid URL
    _local_url = f"http://127.0.0.1:{args.port}" if args.host == "0.0.0.0" else url

    # ── Restart-after-update: wait for old server to release the port ─────────
    _restart_delay = int(os.environ.get('DBOX_RESTART_DELAY', '0'))
    if _restart_delay:
        import time as _t; _t.sleep(_restart_delay)

    # ── If server already running locally, just re-open the browser and exit ──
    _check_host = "127.0.0.1" if args.host == "0.0.0.0" else args.host
    if _server_already_running(_check_host, args.port):
        print(f"\n  dbox: server already running at {url}")
        print(f"  Opening browser...\n")
        _open_app_browser(url)
        sys.exit(0)

    # ── mDNS discovery (client mode — no --lan, no db file) ───────────────────
    # If the user runs web_server.py with no arguments on a second machine,
    # scan the LAN for a dogbox server before starting one locally.
    if not args.lan and not args.db_file:
        print(f"\n  dbox Web Interface")
        print(f"  {'-' * 37}")
        print(f"  Scanning LAN for dogbox server…", end="", flush=True)
        _remote_url = _mdns_discover(timeout=3.0)
        if _remote_url:
            print(f" found!\n  Server   : {_remote_url}\n")
            _open_app_browser(_remote_url)
            sys.exit(0)
        print(f" none found — starting locally.")

    # ── Initialise DB now only when a file is supplied as a CLI argument ─────
    if args.db_file:
        db_path = os.path.abspath(args.db_file)
        _srv.DB_PATH = db_path
        _srv.app.config['DB_PATH'] = db_path
        import hashlib, time as _time
        _seed = f"dbox-web-{db_path}-{_time.time()}"
        _srv.app.secret_key = hashlib.sha256(_seed.encode()).digest()
        print(f"\n  dbox Web Interface")
        print(f"  {'-' * 37}")
        print(f"  Database : {db_path}")
        initialise_database(db_path)
        seed_defaults(db_path)
        ensure_default_admin(db_path)
        print(f"  Login    : admin / admin  (change after first login)")
        print(f"  Open     : {_local_url}")
        _open_url = _local_url
    else:
        # No file supplied — the browser startup page handles file selection.
        # (Header already printed by the mDNS discovery block above if it ran.)
        if args.lan:
            print(f"\n  dbox Web Interface")
            print(f"  {'-' * 37}")
        print(f"  No file specified — select or create one in the browser.")
        print(f"  Open     : {_local_url}/startup")
        _open_url = f"{_local_url}/startup"

    if args.host == "0.0.0.0":
        _lip = _lan_ip()
        print(f"  LAN URL  : http://{_lip}:{args.port}  (share with other users on this network)")
        threading.Thread(target=_mdns_advertise, args=(args.port,), daemon=True).start()

    print(f"  Locks automatically after 10 minutes of inactivity.\n")

    # ── Open browser automatically after server starts ────────────────────────
    # On restart the existing browser window polls /api/alive and reloads itself
    # once the new server is up — no need to open a new browser instance.
    if not _restart_delay:
        def _open_browser():
            import time; time.sleep(1.2)
            launched = _open_app_browser(_open_url)
            if not launched:
                print("  Note: no Chromium browser found — opened in default browser (tab mode)")
        threading.Thread(target=_open_browser, daemon=True).start()

    # The inactivity timer starts on first heartbeat ping from the browser,
    # not at launch — so the startup period does not count toward the timeout.
    _srv.app.config['LAN_MODE'] = (args.host == "0.0.0.0")
    _srv.app.run(host=args.host, port=args.port, debug=False, threaded=True)
