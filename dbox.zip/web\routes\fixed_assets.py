# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from datetime import date
from flask import Blueprint, request, jsonify, send_file

from web.shared import db, ok, err, login_required, current_user
from web.shared import _get_pdf_watermark, _get_combined_pdf_footer
from core.fixed_assets import (
    get_fixed_assets, get_fixed_asset, save_fixed_asset, delete_fixed_asset,
    get_depn_schedule, regenerate_schedule, post_depreciation_journal,
    post_all_fy_depreciation, dispose_asset, asset_register_report,
    lookup_ato_life, get_class_defaults, ASSET_CLASS_BY_KEY, ASSET_CLASSES,
)
from core.database import get_connection
from core.warranty import (
    get_warranties, get_warranty, save_warranty, delete_warranty,
    lodge_claim, get_linked_attachments, set_linked_attachments, CLAIM_OUTCOMES,
)
from core.ledger import get_invoices, get_bills, get_payments

bp = Blueprint('fixed_assets', __name__)


@bp.before_request
def _check_pro_tier():
    from flask import request as _req
    user = current_user()
    if not user:
        return None
    caps = set(user.get("tier_caps") or [])
    path = _req.path
    if path.startswith("/api/fixed-assets") and "fixed_assets" not in caps:
        return err("Fixed Assets requires the Trades pack — visit dogboxsoftware.com.au to upgrade.", 403)
    if path.startswith("/api/warranties") and "warranties" not in caps:
        return err("Warranties requires the Trades pack — visit dogboxsoftware.com.au to upgrade.", 403)


@bp.route("/api/fixed-assets")
@login_required
def api_fa_list():
    status = request.args.get("status")
    rows = asset_register_report(db())
    if status and status != "All":
        rows = [r for r in rows if r.get("status") == status]
    for r in rows:
        cat = r.get("category") or ""
        cls = ASSET_CLASS_BY_KEY.get(cat)
        r["category_label"] = cls["label"] if cls else cat
    return ok(rows)


@bp.route("/api/fixed-assets/<int:aid>")
@login_required
def api_fa_get(aid):
    a = get_fixed_asset(db(), aid)
    if not a:
        return err("Asset not found", 404)
    cat = a.get("category") or ""
    cls = ASSET_CLASS_BY_KEY.get(cat)
    a["category_label"] = cls["label"] if cls else cat
    conn = get_connection(db())
    def _acc(acc_id):
        if not acc_id:
            return None, None
        r = conn.execute("SELECT code, name FROM accounts WHERE id=?", (acc_id,)).fetchone()
        return (r["code"], r["name"]) if r else (None, None)
    a["asset_account_code"],     a["asset_account_name"]     = _acc(a.get("asset_account_id"))
    a["accum_depn_account_code"], a["accum_depn_account_name"] = _acc(a.get("accum_depn_account_id"))
    a["depn_expense_account_code"], a["depn_expense_account_name"] = _acc(a.get("depn_expense_account_id"))
    conn.close()
    return ok(a)


@bp.route("/api/fixed-assets", methods=["POST"])
@login_required
def api_fa_create():
    data = request.get_json(force=True)
    if not data.get("description"):
        return err("Description is required")
    if not data.get("acquisition_date"):
        return err("Acquisition date is required")
    if not data.get("cost_excl_gst") and not data.get("cost_price"):
        return err("Cost is required")
    data.pop("id", None)
    aid = save_fixed_asset(db(), data)
    try:
        regenerate_schedule(db(), aid)
    except Exception:
        pass
    return ok({"id": aid})


@bp.route("/api/fixed-assets/<int:aid>", methods=["PUT"])
@login_required
def api_fa_update(aid):
    data = request.get_json(force=True)
    data["id"] = aid
    try:
        save_fixed_asset(db(), data)
    except Exception as e:
        return err(str(e))
    try:
        regenerate_schedule(db(), aid)
    except Exception:
        pass
    return ok()


@bp.route("/api/fixed-assets/<int:aid>", methods=["DELETE"])
@login_required
def api_fa_delete(aid):
    try:
        delete_fixed_asset(db(), aid)
        return ok()
    except ValueError as e:
        return err(str(e))


@bp.route("/api/fixed-assets/<int:aid>/schedule")
@login_required
def api_fa_schedule(aid):
    rows = get_depn_schedule(db(), aid)
    return ok(rows)


@bp.route("/api/fixed-assets/<int:aid>/regenerate-schedule", methods=["POST"])
@login_required
def api_fa_regenerate_schedule(aid):
    try:
        rows = regenerate_schedule(db(), aid)
        return ok({"rows": len(rows)})
    except ValueError as e:
        return err(str(e))


@bp.route("/api/fixed-assets/<int:aid>/post-depreciation", methods=["POST"])
@login_required
def api_fa_post_depn(aid):
    data    = request.get_json(force=True) or {}
    fy_year = int(data.get("fy_year", 0))
    if not fy_year:
        return err("fy_year is required")
    try:
        jid = post_depreciation_journal(db(), aid, fy_year)
        asset = get_fixed_asset(db(), aid)
        conn = get_connection(db())
        row  = conn.execute(
            "SELECT depn_amount FROM fixed_asset_depn WHERE asset_id=? AND fy_year=?",
            (aid, fy_year)).fetchone()
        conn.close()
        return ok({"journal_id": jid, "depn_amount": row["depn_amount"] if row else 0})
    except ValueError as e:
        return err(str(e))


@bp.route("/api/fixed-assets/post-fy-preview")
@login_required
def api_fa_post_fy_preview():
    fy_year   = int(request.args.get("fy_year", 0))
    asset_id  = request.args.get("asset_id")
    if not fy_year:
        return err("fy_year is required")
    assets = (get_fixed_assets(db(), status="Active")
              if not asset_id
              else [get_fixed_asset(db(), int(asset_id))] if get_fixed_asset(db(), int(asset_id)) else [])
    rows = []
    for a in assets:
        conn = get_connection(db())
        srow = conn.execute(
            "SELECT depn_amount, posted FROM fixed_asset_depn WHERE asset_id=? AND fy_year=?",
            (a["id"], fy_year)).fetchone()
        conn.close()
        if not srow:
            continue
        already = bool(srow["posted"])
        has_accs = bool(a.get("depn_expense_account_id") and a.get("accum_depn_account_id"))
        if already:
            status = "Already posted"
        elif not has_accs:
            status = "⚠ Missing GL accounts"
        else:
            status = "Ready to post"
        rows.append({
            "asset_id":     a["id"],
            "asset_number": a.get("asset_number"),
            "description":  a.get("description"),
            "depn_amount":  srow["depn_amount"],
            "already_posted": already,
            "ready":        not already and has_accs,
            "status":       status,
        })
    return ok(rows)


@bp.route("/api/fixed-assets/post-all-depreciation", methods=["POST"])
@login_required
def api_fa_post_all_depn():
    data    = request.get_json(force=True) or {}
    fy_year = int(data.get("fy_year", 0))
    if not fy_year:
        return err("fy_year is required")
    results = post_all_fy_depreciation(db(), fy_year)
    return ok({"results": results})


@bp.route("/api/fixed-assets/<int:aid>/dispose", methods=["POST"])
@login_required
def api_fa_dispose(aid):
    data = request.get_json(force=True) or {}
    try:
        result = dispose_asset(
            db(),
            aid,
            data.get("disposal_date"),
            float(data.get("proceeds", 0)),
            data.get("method", "Sale"),
            data.get("notes", ""),
        )
        return ok(result)
    except (ValueError, Exception) as e:
        return err(str(e))


@bp.route("/api/fixed-assets/class-defaults")
@login_required
def api_fa_class_defaults():
    cat = request.args.get("category", "")
    if cat not in ASSET_CLASS_BY_KEY:
        match = next((c["key"] for c in ASSET_CLASSES if c["label"] == cat), None)
        if match:
            cat = match
    d = get_class_defaults(db(), cat)
    return ok(d)


@bp.route("/api/fixed-assets/ato-lookup")
@login_required
def api_fa_ato_lookup():
    desc = request.args.get("description", "")
    life = lookup_ato_life(desc)
    return ok({"life": life})


@bp.route("/api/fixed-assets/register-pdf")
@login_required
def api_fa_register_pdf():
    import io, tempfile, os
    from core.reports_pdf import render_fa_register_pdf
    theme = request.args.get("theme")
    try:
        path = render_fa_register_pdf(
            db(),
            theme=theme,
            watermark=_get_pdf_watermark(),
            footer=_get_combined_pdf_footer(db()),
        )
        with open(path, "rb") as f:
            buf = io.BytesIO(f.read())
        return send_file(buf, mimetype="application/pdf",
                         as_attachment=False,
                         download_name="asset_register.pdf")
    except Exception as e:
        return err(f"PDF generation failed: {e}")


@bp.route("/api/fixed-assets/schedule-csv")
@login_required
def api_fa_schedule_csv():
    import csv, io
    try:
        rows = asset_register_report(db())
        buf  = io.StringIO()
        w    = csv.writer(buf)
        w.writerow(["Asset No", "Description", "Category", "Acquired",
                    "Cost (ex GST)", "Residual Value", "Method", "Life (yrs)",
                    "Accum Depr", "Net WDV", "Next FY Depr", "Status"])
        for a in rows:
            cost  = a.get("cost_excl_gst") or a.get("cost_price") or 0
            resid = a.get("residual_value") or 0
            life  = a.get("effective_life_years") or ""
            w.writerow([
                a.get("asset_number") or f"#{a['id']}",
                a.get("description", ""),
                a.get("category") or "",
                a.get("acquisition_date", ""),
                f"{float(cost):.2f}",
                f"{float(resid):.2f}",
                a.get("depn_method", ""),
                life,
                f"{float(a.get('accum_depn', 0)):.2f}",
                f"{float(a.get('current_wdv', 0)):.2f}",
                f"{float(a.get('next_depn', 0)):.2f}",
                a.get("status", ""),
            ])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"fixed_asset_schedule_{date.today()}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))


# ── Warranties ────────────────────────────────────────────────────────────────

@bp.route("/api/warranties")
@login_required
def api_warranties_list():
    search      = request.args.get("search", "")
    status      = request.args.get("status", "all")
    source_type = request.args.get("source_type", "")
    date_from   = request.args.get("date_from", "")
    date_to     = request.args.get("date_to", "")
    rows = get_warranties(db(), search=search, status=status,
                          source_type=source_type,
                          date_from=date_from, date_to=date_to)
    return ok(rows)


@bp.route("/api/warranties/txn_options")
@login_required
def api_warranty_txn_options():
    options = []
    try:
        for inv in (get_invoices(db()) or [])[:50]:
            ref = inv.get("invoice_number") or f"#{inv['id']}"
            options.append({
                "key":   f"invoice:{inv['id']}",
                "label": f"Invoice {ref} — {inv.get('contact_name','')} ({(inv.get('invoice_date') or '')[:7]})",
            })
    except Exception:
        pass
    try:
        for b in (get_bills(db()) or [])[:50]:
            ref = b.get("bill_number") or f"#{b['id']}"
            options.append({
                "key":   f"bill:{b['id']}",
                "label": f"Bill {ref} — {b.get('contact_name','')} ({(b.get('bill_date') or '')[:7]})",
            })
    except Exception:
        pass
    try:
        for p in (get_payments(db()) or [])[:50]:
            options.append({
                "key":   f"payment:{p['id']}",
                "label": (f"Payment #{p['id']} — {p.get('contact_name','')} "
                          f"{p.get('payment_type','')} "
                          f"${float(p.get('amount') or 0):,.2f} "
                          f"({(p.get('payment_date') or '')[:7]})"),
            })
    except Exception:
        pass
    return ok(options)


@bp.route("/api/warranties/<int:wid>")
@login_required
def api_warranty_get(wid):
    w = get_warranty(db(), wid)
    if not w:
        return err("Warranty not found", 404)
    return ok(w)


@bp.route("/api/warranties", methods=["POST"])
@login_required
def api_warranty_save():
    d = request.get_json(force=True)
    try:
        new_id = save_warranty(
            db(),
            source_type      = d.get("source_type", "invoice"),
            source_id        = int(d.get("source_id") or 0),
            item_description = d.get("item_description", ""),
            warranty_expiry  = d.get("warranty_expiry", ""),
            serial_number    = d.get("serial_number", ""),
            provider         = d.get("provider", ""),
            purchase_date    = d.get("purchase_date") or "",
            notes            = d.get("notes", ""),
            warranty_id      = d.get("warranty_id") or None,
        )
        return ok({"id": new_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/warranties/<int:wid>", methods=["DELETE"])
@login_required
def api_warranty_delete(wid):
    try:
        delete_warranty(db(), wid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/warranties/<int:wid>/claim", methods=["POST"])
@login_required
def api_warranty_claim(wid):
    d = request.get_json(force=True)
    outcome = d.get("outcome", "")
    if outcome not in CLAIM_OUTCOMES:
        return err(f"Unknown outcome: {outcome}")
    try:
        result = lodge_claim(
            db(),
            warranty_id          = wid,
            outcome              = outcome,
            claim_date           = d.get("claim_date", ""),
            claim_notes          = d.get("claim_notes", ""),
            claim_amount         = d.get("claim_amount"),
            new_serial           = d.get("new_serial", ""),
            new_item_description = d.get("new_item_description", ""),
            new_expiry           = d.get("new_expiry", ""),
            new_notes            = d.get("new_notes", ""),
        )
        return ok(result)
    except ValueError as e:
        return err(str(e), 404)
    except Exception as e:
        return err(str(e))


@bp.route("/api/warranties/outcomes")
@login_required
def api_warranty_outcomes():
    return ok(CLAIM_OUTCOMES)


@bp.route("/api/warranties/<int:wid>/linked_attachments")
@login_required
def api_warranty_linked_attachments_get(wid):
    return ok(get_linked_attachments(db(), wid))


@bp.route("/api/warranties/<int:wid>/linked_attachments", methods=["POST"])
@login_required
def api_warranty_linked_attachments_set(wid):
    d = request.get_json(force=True)
    ids = [int(x) for x in (d.get("attachment_ids") or [])]
    try:
        set_linked_attachments(db(), wid, ids)
        return ok()
    except Exception as e:
        return err(str(e))
