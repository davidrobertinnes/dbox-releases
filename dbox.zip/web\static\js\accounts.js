// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ═══════════════════════════════════════════════════════════════════════════
// ACCOUNTS PAGE  (Chart of Accounts)
// ═══════════════════════════════════════════════════════════════════════════
let _acctAll=[], _acctBalances={}, _acctSearch='', _acctSelected=null, _acctTypeFilter='All';
const ACCT_TYPES=['All','Asset','Liability','Equity','Income','Expense'];
const ACCT_TYPE_COLOR={Asset:'badge-pending',Liability:'badge-overdue',Equity:'badge-partial',Income:'badge-paid',Expense:'badge-draft'};
const _TYPE_CLASS={Asset:'1',Liability:'2',Equity:'3',Income:'4',Expense:'5'};
const _CODE_RE=/^[1-5]-\d{4}$/;

async function pageAccounts() {
  try {
    _acctAll = await apiFetch('/api/accounts') || [];
    const ids = _acctAll.map(a=>a.id);
    if (ids.length) {
      try {
        const bals = await fetch('/api/accounts/balances',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(ids)});
        const j = await bals.json();
        if (j.ok) _acctBalances = j.data;
      } catch(e) { _acctBalances={}; }
    }
    renderAccountsPage();
  } catch(e) {
    document.getElementById('module-content').innerHTML=`<div class="state-error">Failed to load accounts: ${esc(e.message)}</div>`;
  }
}

// ── Filtering ──────────────────────────────────────────────────────────────

function _acctFiltered() {
  const q=_acctSearch.toLowerCase();
  return _acctAll.filter(a=>{
    if (_acctTypeFilter!=='All' && a.account_type!==_acctTypeFilter) return false;
    if (q && ![a.code,a.name,a.account_type,a.account_subtype].some(v=>(v||'').toLowerCase().includes(q))) return false;
    return true;
  });
}

// ── Page render ────────────────────────────────────────────────────────────

function renderAccountsPage() {
  document.getElementById('module-content').innerHTML='<div id="acct-coa-pane"></div>';
  _renderCoaPane();
}

// ── Chart of Accounts pane ─────────────────────────────────────────────────

function _renderCoaPane(restoreFocus) {
  const all=_acctFiltered();
  const counts={All:_acctAll.length};
  ACCT_TYPES.slice(1).forEach(t=>{ counts[t]=_acctAll.filter(a=>a.account_type===t).length; });

  const order=['Asset','Liability','Equity','Income','Expense'];
  const groups={};
  order.forEach(t=>{ groups[t]=[]; });
  all.forEach(a=>{ if(groups[a.account_type]) groups[a.account_type].push(a); });

  document.getElementById('acct-coa-pane').innerHTML=`
    <div class="inv-toolbar">
      <input class="inv-search" id="acct-q" placeholder="Search code, name\u2026" value="${esc(_acctSearch)}">
      <div class="inv-filter-group">
        ${ACCT_TYPES.map(t=>`<button class="filter-btn${_acctTypeFilter===t?' active':''}" onclick="acctSetFilter('${t}')">
          ${t}${counts[t]?`<span class="filter-count">(${counts[t]})</span>`:''}</button>`).join('')}
      </div>
      <button class="btn btn-primary" onclick="acctNew()">+ New Account</button>
    </div>
    ${order.filter(t=>groups[t]&&groups[t].length).map(type=>`
    <div class="acct-type-group">
      <div class="acct-type-hdr">
        <span class="badge ${ACCT_TYPE_COLOR[type]||'badge-draft'}">${type}</span>
        <span class="acct-type-count">${groups[type].length} account${groups[type].length!==1?'s':''}</span>
        <span class="acct-type-total">Total: <span class="inv-mono">${fmt(_acctGroupTotal(type,groups[type]))}</span></span>
      </div>
      <div class="inv-list-panel acct-list-panel-flush"><div class="tbl-overflow-x">
        <table class="inv-list-table"><thead><tr>
          <th class="acct-th-code">Code</th>
          <th>Name</th>
          <th>Subtype</th>
          <th class="acct-th-bank">Bank</th>
          <th class="th-r acct-th-bal">Balance</th>
          <th class="acct-th-active">Active</th>
        </tr></thead><tbody>
          ${groups[type].map(a=>acctRow(a)).join('')}
        </tbody></table>
      </div></div>
    </div>`).join('')}
    <div class="mt-8"><span class="count-pill">${all.length} of ${_acctAll.length} account${_acctAll.length!==1?'s':''}</span></div>`;

  const q=document.getElementById('acct-q');
  if(q){
    q.addEventListener('input',e=>{ _acctSearch=e.target.value; _renderCoaPane(true); });
    if(restoreFocus){q.focus();q.setSelectionRange(q.value.length,q.value.length);}
  }
}

function _acctGroupTotal(type, accts) {
  return accts.reduce((s,a)=>s+(_acctBalances[String(a.id)]||0),0);
}

function acctRow(a) {
  const bal=_acctBalances[String(a.id)];
  const balFmt=bal!=null?fmt(bal):'—';
  // Balance colour is JS-driven (runtime sign check) — inline style is correct here
  const balColor=bal==null?'':(bal<-0.005?'color:var(--red)':bal>0.005?'color:var(--green)':'color:var(--ink3)');
  const sel=_acctSelected===a.id;
  return `<tr class="inv-row${sel?' acct-row-selected':''}" onclick="acctOpen(${a.id})">
    <td><span class="inv-mono">${esc(a.code||'')}</span></td>
    <td><span class="inv-contact">${esc(a.name)}</span>${a.is_bank?'<span class="acct-bank-icon">🏦</span>':''}</td>
    <td><span class="acct-subtype-cell">${esc(a.account_subtype||'—')}</span></td>
    <td class="td-c-mono">${a.is_bank?'<span class="col-green">\u2713</span>':'—'}</td>
    <td class="td-r-mono" style="${balColor}">${balFmt}</td>
    <td class="td-c-mono">${a.is_active!==0?'<span class="col-green">\u2713</span>':'<span class="col-red">\u2715</span>'}</td>
  </tr>`;
}

function acctSetFilter(t){ _acctTypeFilter=t; _renderCoaPane(); }

// ── CoA detail ─────────────────────────────────────────────────────────────

async function acctOpen(id) {
  _acctSelected=id;
  document.querySelectorAll('.acct-row-selected').forEach(r=>r.classList.remove('acct-row-selected'));
  const row=document.querySelector(`[onclick="acctOpen(${id})"]`);
  if (row) row.classList.add('acct-row-selected');

  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent='Account';
  document.getElementById('det-body').innerHTML='<div class="state-loading">Loading\u2026</div>';
  document.getElementById('det-foot').innerHTML='';
  try {
    const a=await apiFetch(`/api/accounts/${id}`);
    renderAcctDetail(a);
  } catch(e) {
    document.getElementById('det-body').innerHTML=`<div class="state-error">${esc(e.message)}</div>`;
  }
}

function renderAcctDetail(a) {
  document.getElementById('det-title').textContent=`${a.code} \u2014 ${a.name}`;
  const bal=a.balance??_acctBalances[String(a.id)];
  const balColor=bal==null?'':(bal<-0.005?'color:var(--red)':bal>0.005?'color:var(--green)':'color:var(--ink3)');
  document.getElementById('det-body').innerHTML=`
    <div class="acct-det-badges">
      <span class="badge ${ACCT_TYPE_COLOR[a.account_type]||'badge-draft'}">${esc(a.account_type||'—')}</span>
      ${a.account_subtype?`<span class="badge badge-draft badge-sm-inline">${esc(a.account_subtype)}</span>`:''}
      ${a.is_active===0?'<span class="badge badge-overdue badge-sm-inline">Inactive</span>':''}
    </div>
    ${bal!=null?`
    <div class="acct-det-bal-card">
      <div class="acct-det-bal-lbl">Current Balance</div>
      <div class="acct-det-bal-val" style="${balColor}">${fmt(bal)}</div>
    </div>`:''}
    <div class="det-meta">
      <div><div class="det-lbl">Account Code</div><div class="det-val mono">${esc(a.code||'—')}</div></div>
      <div><div class="det-lbl">Tax Code</div><div class="det-val mono">${esc(a.tax_code||'—')}</div></div>
      <div><div class="det-lbl">Opening Balance</div><div class="det-val mono">${a.opening_balance!=null?fmt(a.opening_balance):'—'}</div></div>
      <div><div class="det-lbl">Is Bank Account</div><div class="det-val">${a.is_bank?'<span class="col-green">Yes</span>':'No'}</div></div>
      ${a.is_bank&&(a.bsb||a.account_number)?`
      <div><div class="det-lbl">BSB</div><div class="det-val mono">${esc(a.bsb||'—')}</div></div>
      <div><div class="det-lbl">Account No.</div><div class="det-val mono">${esc(a.account_number||'—')}</div></div>`:''}
    </div>`;
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" onclick="acctEdit(${a.id})">\u270f Edit</button>
    <button class="btn btn-outline" onclick="detClose()">Close</button>`;
}

// ── CoA new / edit form ────────────────────────────────────────────────────

function acctNew() {
  _acctEditId=null;
  _showAcctForm(null);
}

function acctEdit(id) {
  _acctEditId=id;
  apiFetch(`/api/accounts/${id}`).then(a=>_showAcctForm(a)).catch(e=>toast(e.message,'err'));
}

let _acctEditId=null;
function _showAcctForm(a) {
  const v=(f,fb='')=>esc(a?String(a[f]??fb):fb);
  const sel=(f,opts,fb='')=>opts.map(o=>`<option${(a?a[f]:fb)===o?' selected':''}>${o}</option>`).join('');
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent=a?`Edit \u2014 ${a.code} ${a.name}`:'New Account';
  document.getElementById('det-body').innerHTML=`
    <div class="edt-body-pad">
    <div class="edt-grid">
      <div class="edt-field"><label class="edt-lbl">Code *</label><input class="edt-inp" id="af-code" value="${v('code')}" placeholder="${_TYPE_CLASS[a?.account_type||'Asset']}-0000" maxlength="6"></div>
      <div class="edt-field"><label class="edt-lbl">Tax Code</label>
        <select class="edt-sel" id="af-tax">${sel('tax_code',['GST','FRE','INP','N-T','CAP'],'GST')}</select></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Name *</label><input class="edt-inp" id="af-name" value="${v('name')}"></div>
      <div class="edt-field"><label class="edt-lbl">Type *</label>
        <select class="edt-sel" id="af-type" onchange="acctTypeChange()">${sel('account_type',['Asset','Liability','Equity','Income','Expense'],'Asset')}</select></div>
      <div class="edt-field"><label class="edt-lbl">Subtype</label>
        <select class="edt-sel" id="af-subtype">${_acctSubtypeOpts(a?.account_type||'Asset',a?.account_subtype)}</select></div>
      <div class="edt-field"><label class="edt-lbl">Opening Balance ($)</label><input class="edt-inp" id="af-ob" type="number" step="0.01" value="${v('opening_balance','0')}"></div>
      <div class="edt-field acct-ck-field">
        <input type="checkbox" id="af-isbank" ${a?.is_bank?'checked':''} onchange="acctBankToggle()">
        <label for="af-isbank" class="acct-ck-lbl">Is Bank Account</label>
      </div>
    </div>
    <div id="af-bank-fields" style="${a?.is_bank?'':'display:none'}">
      <div class="acct-bank-sep"><span class="acct-bank-sep-lbl">Bank Details</span></div>
      <div class="edt-grid">
        <div class="edt-field"><label class="edt-lbl">BSB</label><input class="edt-inp" id="af-bsb" value="${v('bsb')}"></div>
        <div class="edt-field"><label class="edt-lbl">Account Number</label><input class="edt-inp" id="af-accnum" value="${v('account_number')}"></div>
      </div>
    </div>
    </div>`;
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="acct-save-btn" onclick="saveAccount()">Save</button>
    <button class="btn btn-outline" onclick="${_acctEditId?`acctOpen(${_acctEditId})`:'detClose()'}">Cancel</button>`;
  setTimeout(()=>{ document.getElementById('af-code')?.focus(); },50);
}

function _acctSubtypeOpts(type, current) {
  const map={
    Asset:['Bank','Current Asset','Fixed Asset',''],
    Liability:['Credit Card','Current Liability','Non-Current Liability',''],
    Equity:['Equity',''],
    Income:['Income',''],
    Expense:['Direct Cost','Overhead','Header',''],
  };
  return (map[type]||['']).map(o=>`<option${current===o?' selected':''}>${o}</option>`).join('');
}

function acctTypeChange() {
  const typeEl=document.getElementById('af-type');
  const sub=document.getElementById('af-subtype');
  if(sub) sub.innerHTML=_acctSubtypeOpts(typeEl?.value);
  const codeEl=document.getElementById('af-code');
  if(!typeEl||!codeEl) return;
  const cls=_TYPE_CLASS[typeEl.value]||'';
  codeEl.placeholder=`${cls}-0000`;
  const cur=codeEl.value.trim();
  if(cur && /^[1-5]-/.test(cur)) codeEl.value=cls+'-'+cur.slice(2);
}

function acctBankToggle() {
  const bf=document.getElementById('af-bank-fields');
  if(bf) bf.style.display=document.getElementById('af-isbank')?.checked?'':'none';
}

async function saveAccount() {
  const code=(document.getElementById('af-code')?.value||'').trim();
  const name=(document.getElementById('af-name')?.value||'').trim();
  if(!code||!name){ toast('Code and Name are required','err'); return; }
  if(!_CODE_RE.test(code)){ toast('Code must be in format C-HXXX — e.g. 1-1100','err'); return; }
  const _atype=document.getElementById('af-type')?.value;
  if(_TYPE_CLASS[_atype]&&code[0]!==_TYPE_CLASS[_atype]){
    toast(`${_atype} accounts must start with ${_TYPE_CLASS[_atype]}- (e.g. ${_TYPE_CLASS[_atype]}-1100)`,'err'); return;
  }
  const btn=document.getElementById('acct-save-btn');
  btn.disabled=true; btn.textContent='Saving\u2026';
  const payload={
    code, name,
    account_type:    document.getElementById('af-type').value,
    account_subtype: document.getElementById('af-subtype').value||null,
    tax_code:        document.getElementById('af-tax').value,
    opening_balance: parseFloat(document.getElementById('af-ob').value||0),
    is_bank:         document.getElementById('af-isbank').checked?1:0,
    bsb:             document.getElementById('af-bsb')?.value.trim()||'',
    account_number:  document.getElementById('af-accnum')?.value.trim()||'',
    is_active: 1,
  };
  try {
    const savedId=_acctEditId;
    if (_acctEditId) {
      const r=await fetch(`/api/accounts/${_acctEditId}`,{method:'PUT',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
    } else {
      const r=await fetch('/api/accounts',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
    }
    // Invalidate caches used by invoice/bill/journal editors if they exist
    if (typeof _bankAccts     !== 'undefined') _bankAccts=[];
    if (typeof _editAccts     !== 'undefined') _editAccts=[];
    if (typeof _billEditAccts !== 'undefined') _billEditAccts=[];
    toast('Account saved');
    _acctAll=await apiFetch('/api/accounts')||[];
    const ids=_acctAll.map(a=>a.id);
    if(ids.length){
      const bals=await fetch('/api/accounts/balances',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(ids)});
      const bj=await bals.json(); if(bj.ok) _acctBalances=bj.data;
    }
    if(savedId){ _acctSelected=savedId; await acctOpen(savedId); }
    else { detClose(); renderAccountsPage(); }
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent='Save';
  }
}

