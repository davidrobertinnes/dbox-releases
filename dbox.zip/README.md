# Dogbox Accounting — Australian Small Business Accounting

A portable, offline desktop accounting application for Australian small businesses.
Built with Python, tkinter, and SQLite. No subscription. No cloud. Your data stays
in a single file on your own machine.

---

## Requirements

| Requirement | Details |
|---|---|
| Python | 3.10 or later — [python.org](https://python.org) |
| tkinter | Included with Python on Windows and macOS |
| reportlab | PDF invoice and report generation |
| Pillow | Logo upload and brand colour extraction |
| Flask | Web interface only (optional) |

Install required packages:
```
pip install reportlab pillow
```

> **Linux (Ubuntu/Debian):** `sudo apt install python3-tk`
> **macOS (if missing):** `brew install python-tk`

---

## Launching

| Platform | Method |
|---|---|
| Windows | Double-click **dbox.pyw** (no console window) |
| Windows fallback | Double-click **dbox.bat** |
| All platforms | `python main.py` in a terminal |

Errors are written to `dbox_error.log` in the application folder.

---

## Getting Started

1. Launch the app
2. **File → New Company File** — enter a company name, choose a folder, select Blank or Demo
3. **File → Company Details** — enter ABN, address, and upload your logo
4. Default login: **admin / admin** — you will be prompted to change this immediately
5. Add contacts, then create invoices or bills

### Demo / Sample Data

Selecting "Demo / sample data" creates a pre-populated test company with contacts,
invoices, bills, payments, and a sample bank statement CSV for testing bank
reconciliation. Ideal for training and evaluation.

---

## Modules

### Dashboard
Live snapshot: bank balance, projected balance (Bank + AR − AP), overdue invoices,
overdue bills, AR/AP/GST totals, open CRM tasks, quotes pipeline, and recent invoices.

### Contacts
Customer and supplier records. ABN, contact person, payment terms, default tax code,
BSB/account for ABA files. Protected system contact "Cash" cannot be deleted
(required by bank reconciliation).

### Invoices
Full accounts receivable workflow:
- Statuses: Draft → Sent/Approved → Partial → Paid / Overdue / Void
- Posting creates: DR Accounts Receivable, CR Income, CR GST Collected
- PDF generation with company logo and brand colours (k-means extraction)
- Email via SMTP with PDF attachment
- File attachments stored inside the database
- Job linking for project costing

### Bills
Accounts payable mirror of Invoices:
- Posting creates: DR Expense, DR GST Paid, CR Accounts Payable
- Same line-item structure, tax codes, and journal behaviour

### Payments
- Customer receipts and supplier payments
- Allocate one payment across multiple invoices/bills (partial allocations supported)
- Void payments (journal reversal, balances restored)
- ABA direct-entry file generation for batch supplier payments

### Accounts
Full chart of accounts with Australian defaults pre-loaded (codes 1-1100 – 5-3700).
Types: Asset, Liability, Equity, Income, Expense. Bank and credit card accounts flagged
separately. Opening balances supported.

File → Compact & Optimise Database runs VACUUM + ANALYZE.

### Bank Reconciliation
- Import CSV bank statements with a flexible column-mapping wizard
- Auto-detects columns by data content (no header names required)
- Save/load column mapping schemas per bank account
- Duplicate detection: highlights transactions appearing in both CSV and journal
- Multi-select reconcile / unreconcile / reject / categorise
- Categorisation dialog: Cash/Contact tab, Invoice tab, Bill tab
  - Confirmation dialog with "Don't ask again this session" option
  - Double-click to edit or delete any existing categorisation
- Finalise reconciliation: closing balance carries forward as next opening balance
- Sortable columns, date/search filter, show/hide reconciled rows

### Reports
All reports generated as PDF (ReportLab, no browser required). Accrual and cash basis.

| Report | Description |
|---|---|
| Profit & Loss | Income vs expenses for any date range |
| Balance Sheet | Assets, liabilities, equity at a point in time |
| Trial Balance | All accounts with debit/credit totals |
| BAS | G1, G11, 1A, 1B — GST Activity Statement |
| IAS | PAYG withholding for the period |
| Budget vs Actual | Variance analysis against a budget period |

### Budget
Annual, quarterly, or monthly budgets by account. Import/export via CSV template.
Budget vs Actual report shows variance in dollars and percentage.

### Users
Role-based access: Admin · Accountant · Staff · ReadOnly.
Full audit log (create, edit, void, delete) with username and timestamp.
Passwords hashed with PBKDF2-SHA256 at 260,000 iterations.

### Payroll
STP Phase 2 compliant:
- Employee records: TFN, employment type, pay rate, super rate override
- Pay frequencies: Weekly, Fortnightly, Monthly
- PAYG withholding: ATO NAT 1008 marginal rates (2024-25)
- Superannuation Guarantee: 11.5% for 2024-25, auto-updated by FY
- Allowances, overtime, leave, salary sacrifice, deductions
- Payslip PDF with YTD figures
- STP Phase 2 XML payload generation (lodge via agent or ATO Business Portal)

### Journal
Manual double-entry adjustments. Balanced debit/credit enforced. Void creates a
full reversing entry for audit trail.

### Credit Cards
Dedicated view for credit card accounts. Record charges (DR Expense, CR Card) and
payments (DR Card, CR Bank). Statement view per card.

### Jobs / Projects
Link invoices, bills, payments, and journal entries to a job. Per-job P&L report.
Status tracking: Active, On Hold, Complete, Cancelled.

### Items (Product Catalogue)
Reusable products/services with code, price, tax code, and income account.
Auto-fills invoice line items on selection.

### Recurring Transactions
Templates for repeating invoices and bills. Frequencies: Weekly, Fortnightly, Monthly,
Quarterly, Annual. Run all due templates in one click.

### CRM
Full sales pipeline:
- Stages: Lead → Qualified → Quoted → Accepted → In Progress → On Hold → Complete → Invoiced → Won/Lost
- Per-opportunity: communications log, tasks, quotes, progress claims
- Global tasks and global quotes views
- Convert quote → Draft Invoice in one click
- Convert progress claim → Draft Invoice in one click

---

## Data File

All data is stored in a single `.dbox` file (SQLite, WAL mode). Copy to USB,
network share, or cloud folder for backup. Open on any machine with Python + packages.

Schema migrations run automatically on open — upgrading is safe and non-destructive.

### Backup, Restore, Export

| Action | Menu |
|---|---|
| Backup | File → Backup Company File (timestamped copy) |
| Restore | File → Restore from Backup |
| Export to CSV | File → Export Data to CSV (ZIP of all tables) |
| Import from CSV | File → Import Data from CSV |

---

## Web Interface

```bash
python dbox.py                             # creates dbox_data.db
python dbox.py your_company.dbox       # opens existing file
python dbox.py company.dbox --port 8080 --host 0.0.0.0
```

Open: http://localhost:5000  ·  Default login: admin / admin

Reads and writes the same `.dbox` file as the desktop app.
Security: HttpOnly session cookies, SameSite=Lax, 8-hour timeout, 10-attempt lockout.

---

## Colour Themes

Seven built-in themes: Dark (Default) · Midnight Blue · Forest · Warm Slate ·
Light · Ocean Deep · Purple Haze.

**View → Colour Scheme** — switch theme or build a custom palette. Saved per file.
**File → Company Details** — upload logo; brand colours extracted automatically.

---

## User Guides

Detailed user guides for every module are in `docs/guides/`:

| Guide | File |
|---|---|
| Getting Started | 01_getting_started.pdf / .docx |
| Dashboard | 02_dashboard.pdf / .docx |
| Contacts | 03_contacts.pdf / .docx |
| Invoices | 04_invoices.pdf / .docx |
| Bills | 05_bills.pdf / .docx |
| Payments | 06_payments.pdf / .docx |
| Bank Reconciliation | 07_bank_reconciliation.pdf / .docx |
| Reports | 08_reports.pdf / .docx |
| Accounts | 09_accounts.pdf / .docx |
| Budget | 10_budget.pdf / .docx |
| Payroll | 11_payroll.pdf / .docx |
| Journal | 12_journal.pdf / .docx |
| Credit Cards | 13_credit_cards.pdf / .docx |
| Jobs / Projects | 14_jobs.pdf / .docx |
| Items / Catalogue | 15_items.pdf / .docx |
| Recurring Transactions | 16_recurring.pdf / .docx |
| CRM | 17_crm.pdf / .docx |
| Users and Security | 18_users.pdf / .docx |
| Backup and Data Management | 19_backup.pdf / .docx |

Regenerate all guides:
```
python docs/build_guides.py
```

---

## File Structure

```
Dogbox_Accounting/
├── main.py              Command-line entry point
├── dbox.pyw         Windows launcher (no console)
├── dbox.bat         Windows batch fallback
├── dbox.py        Flask web interface
├── README.md            This file
├── docs/
│   ├── build_guides.py  Regenerates all user guides
│   └── guides/          Generated PDF and ODT guides (one per module)
├── core/
│   ├── database.py      Schema, migrations, seed_demo
│   ├── ledger.py        Double-entry accounting engine
│   ├── budget.py        Budget management, user auth, audit log
│   ├── payroll.py       STP Phase 2 payroll engine
│   ├── jobs.py          Job and project costing
│   ├── crm.py           CRM pipeline, quotes, progress claims
│   ├── recurring.py     Recurring transaction templates
│   ├── invoice_pdf.py   Invoice PDF (ReportLab)
│   ├── reports_pdf.py   Financial report PDF (ReportLab)
│   ├── email_invoice.py SMTP email with PDF attachment
│   ├── attachments.py   File attachment storage (BLOB)
│   └── logo_colours.py  Logo colour extraction (k-means + WCAG)
├── ui/
│   ├── app.py           Main window and all desktop UI
│   └── crm_ui.py        CRM module UI
└── web/
    └── server.py        Flask REST API and HTML templates
```

---

## Default Chart of Accounts

| Range | Type |
|---|---|
| 1-1100 – 1-1500 | Current Assets (Bank, AR, GST, Inventory, Prepayments) |
| 1-2100 – 1-2210 | Fixed Assets (Plant, Vehicles + Accum. Depreciation) |
| 2-1100 – 2-1500 | Current Liabilities (AP, GST, PAYG, Super, Credit Card) |
| 2-2100 | Non-Current Liabilities (Bank Loan) |
| 3-1100 – 3-1300 | Equity (Capital, Drawings, Retained Earnings) |
| 4-1100 – 4-1400 | Income (Sales Goods, Sales Services, Other, Interest) |
| 5-1100 | Cost of Goods Sold |
| 5-2100 – 5-3700 | Overhead Expenses (16 accounts) |

Key system accounts used by the accounting engine:

| Code | Account | Used For |
|---|---|---|
| 1-1200 | Accounts Receivable | Invoice posting |
| 1-1300 | GST Paid (Input Credits) | Bill GST |
| 2-1100 | Accounts Payable | Bill posting |
| 2-1200 | GST Collected | Invoice GST |
| 2-1300 | PAYG Withholding Payable | Payroll |
| 2-1400 | Superannuation Payable | Payroll |
| 5-3500 | Superannuation Expense | Payroll |
| 5-3700 | Wages & Salaries | Payroll |

---

## Australian Tax Codes

| Code | Description | Rate |
|---|---|---|
| GST | GST on Income/Expenses | 10% |
| FRE | GST Free | 0% |
| INP | Input Taxed | 0% |
| N-T | Not Reportable | 0% |
| CAP | Capital Acquisitions | 10% |
| EXP | Export Sales | 0% |

---

## Known Limitations

- **TFN storage** — Tax File Numbers are in plaintext. Use BitLocker (Windows) or
  FileVault (macOS) to encrypt the `.dbox` file.
- **SMTP passwords** — stored as base64 (obfuscated, not encrypted). Secure the file
  at the OS level.
- **STP lodgement** — generates STP Phase 2 XML but does not lodge directly. Submit
  via your registered tax agent or ATO Business Portal.
- **Quote PDFs** — quotes can be managed in CRM but cannot yet be printed as
  formatted PDFs.
- **CRM → Jobs UI link** — schema supports it (job_id column exists) but UI wiring
  is not yet built.
- **Web interface CRM** — Flask interface covers accounting modules; CRM endpoints
  not yet exposed.

---

## Security Notes

- Passwords: PBKDF2-SHA256, 260,000 iterations, timing-safe comparison
- Legacy hashes upgraded automatically on next login
- Session cookies: HttpOnly, SameSite=Lax, 8-hour expiry (web interface)
- Login lockout: 10 failed attempts → 5-minute block per IP (web interface)
- Database: WAL mode, foreign key constraints enforced
