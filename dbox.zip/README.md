# Dogbox Accounting
### Australian Small Business Accounting

A portable, offline desktop accounting application for Australian small businesses.
Built with Python, tkinter, and SQLite. No subscription. No cloud. Your data stays
in a single `.dbox` file on your own machine.

**Current version: 1.0-alpha**

> ⚠️ **Alpha Release** — This is an early test version. You may encounter bugs or
> incomplete features. Please report anything unusual to us at **dogboxsoftware@gmail.com**.

---

## Quick Start

### Windows
Double-click **dbox.pyw** (no console window) or **dbox.bat**

### macOS
Open Terminal, navigate to the dbox folder, and run:
```
bash dbox.sh
```
Or right-click `dbox.sh` in Finder → Open With → Terminal.

### Linux
Open a terminal, navigate to the dbox folder, and run:
```
bash install.sh
```
This installs all dependencies and creates a desktop shortcut automatically.
After that, launch from the desktop icon or run:
```
bash dbox.sh
```

### Universal fallback (all platforms)
```
python main.py
```

---

## Requirements

| Requirement | Details |
|---|---|
| Python | 3.10 or later — [python.org](https://python.org) |
| tkinter | Ships with Python on Windows and most Linux distros. macOS: included with python.org installer. |
| reportlab | PDF generation — `pip install reportlab` |
| Pillow | Logo display and brand colour extraction — `pip install pillow` |

Install required packages by opening a terminal and running:
```
pip install reportlab pillow
```

---

## Getting Started

1. Launch the app using the method for your platform (see Quick Start above)
2. Select **New Company File**, enter your company name and choose a save location
3. Go to **File → Company Details** to enter your ABN, address, and upload your logo
4. Default login: **admin / admin** — you will be prompted to change this on first login
5. Start adding contacts, then create invoices or bills

### Demo / Sample Data
When creating a new company file, select **Demo / sample data** to get a
pre-populated test company with sample contacts, invoices, bills, payments,
and a ready-to-import bank CSV for testing bank reconciliation.

---

## Modules

- **Dashboard** — live snapshot of bank balance, cash position, overdue invoices and bills
- **Contacts** — customers and suppliers with ABN, payment terms, bank details, and employee designation
- **Invoices & Quotes** — create, send, and track invoices and quotes with GST
- **Bills** — manage supplier bills and track what you owe
- **Payments** — record payments in and out, generate ABA payment files
- **Bank Reconciliation** — import bank CSV and match transactions
- **Journal** — manual journal entries and general ledger
- **Credit Cards** — track credit card charges and payments
- **Payroll** — employee pay runs, STP lodgement, leave management, Modern Awards and Enterprise Agreements with classification-based pay rates, superannuation payments
- **Awards** — Modern Award and Enterprise Agreement register, classifications, pay rate schedules, allowances, and penalty rates
- **Jobs** — job costing, allocate transactions to jobs
- **CRM** — contacts pipeline, tasks, and quotes
- **Items & Inventory** — product catalogue, stock levels, reorder alerts
- **Fixed Assets** — asset register and depreciation
- **Recurring Transactions** — automated recurring invoices and bills
- **Warranties** — warranty register and claims tracking
- **Purchase Orders** — create and track supplier purchase orders
- **Reports** — P&L, Balance Sheet, BAS, Aged Receivables/Payables, Budget vs Actual
- **Budget** — set budgets by period and compare against actuals
- **Users** — multi-user access with role-based permissions

---

## User Guides

PDF guides for each module are included in the `docs/guides/` folder.

---

## Reporting Issues

This is an alpha release and your feedback is invaluable.

If you find a bug or something doesn't work as expected, please email:
**dogboxsoftware@gmail.com**

When reporting an issue, it helps to include:
- What you were trying to do
- What happened instead
- Any error message that appeared
- Your operating system and Python version

---

## Data & Privacy

All your accounting data is stored locally in a `.dbox` file on your own computer.
Dogbox Accounting does not connect to the internet or send any data externally.

Your licence is validated locally from the `dbox.lic` file in the application folder —
no internet connection is required or used for licence checking.

---

## Licence

Copyright © 2026 David Robert Innes trading as Dogbox Software
ABN 40 986 160 328 — All rights reserved.

This software is licenced for use by registered users only.
Unauthorised copying, modification, or distribution is not permitted.

Licence enquiries: dogboxsoftware@gmail.com
