# Dogbox Accounting — Australian Small Business Accounting

Business management for Australian sole traders and small businesses, with
accounting at its core. Raise invoices, pay bills, reconcile the bank, run a
BAS, manage jobs and quotes, and more — with all your data in a single file you
control. No cloud account required.

It runs as a local web app: `dbox.py` starts it and opens it in a Chromium
browser window (Chrome, Edge or Brave) in app mode, so it looks and behaves like
a desktop application.

---

## Requirements

| Requirement | Details |
|---|---|
| Python | 3.9 or later — [python.org](https://python.org) |
| Browser | A Chromium browser (Chrome, Edge, Brave); falls back to a normal tab |
| Packages | Flask, ReportLab, Pillow, pypdf — see `requirements.txt` |

The installers set everything up. For a source install:
```
python -m pip install -r requirements.txt
```

---

## Installing and Launching

Download the installer for Windows or Mac from
[dogboxsoftware.com.au](https://dogboxsoftware.com.au) and run it. It installs
the packages and creates a desktop shortcut.

From a source folder:
```bash
python dbox.py                              # choose or create a company file
python dbox.py mycompany.dbox               # open a company file
python dbox.py mycompany.dbox --port 8080   # different port
python dbox.py mycompany.dbox --lan         # allow other computers on the network (Pro)
```

On first run the Setup Wizard walks through the company name, identity,
address and tax settings. Default login: **admin / admin** — you are asked to
change it straight away.

---

## Licence Tiers

| Tier | What's included |
|---|---|
| Free | Invoices, bills, payments, contacts, bank reconciliation, chart of accounts, journal, credit cards, aged receivables/payables, BAS/GST and other reports. No registration, no expiry. |
| Pro Trial | Register free to unlock everything for 6 months: Jobs & Quotes, purchase orders, fixed assets, warranties, POS, table service, inventory, items, promotions, budget, recurring, expense claims, petty cash, email delivery, LAN mode. |
| Pro | Subscription to keep Pro features after the trial. |
| Payroll | Licensed separately. |

See `EULA.txt` for the full terms.

---

## Modules

Navigation is by hub — Business Overview plus seven hubs, each a grid of tiles.

**Billing** — Invoices, Bills, Payments, Credit Notes, Expenses (expense claims),
Purchase Orders, Recurring, Contacts.
Double-entry throughout: invoices post DR Accounts Receivable / CR Income /
CR GST Collected; bills post DR Expense / DR GST Paid / CR Accounts Payable.
PDFs with your logo and brand colours, email delivery, attachments, discounts,
credit notes, ABA payment files.

**Jobs & Quotes** — Jobs, Schedule, Quotes, Tasks, Warranties, Work Diary, Contacts.
- Jobs: pipeline (Lead → … → Invoiced / Won / Lost) with list and Kanban views;
  a detail panel with Overview, Comms, Tasks, Visits, Quotes, Claims, Materials
  (bill of materials), Purchasing, Financials (job P&L) and Time.
- Visits: each trip to site with date, time and hours; plan a visit's tasks,
  print a one-page visit worksheet, and record what got done.
- Tasks: fixed-price or hourly; fixed-price tasks can be billed in parts
  ("8 of 24"), always adding up exactly to the contract price.
- Claim builder: one progress claim + draft invoice from visits, tasks,
  labour (visit hours × rate, or marked "not charged") and materials.
  Voiding the invoice releases everything it billed.
- Schedule: month/week/list calendar of jobs, visits and events with
  drag-and-drop, and optional two-way Google Calendar sync.
- Work Diary: daily employee time across all jobs, with approval.

**Sales Floor** — Point of Sale, Table Service, Inventory, Items, Contacts.

**Financials** — Bank Rec (CSV import, rules, reconcile), Petty Cash, Credit
Cards, Chart of Accounts, Fixed Assets (depreciation), Journal, Budget.

**Payroll** — employees, pay runs, PAYG withholding, super, leave, payslips,
STP Phase 2 payloads.

**Reports** — Profit & Loss, Balance Sheet, Trial Balance, BAS / IAS, Cash Flow,
Aged Receivables, Aged Payables, Budget vs Actual, Jobs Report, Tax Return.
PDF and CSV.

**Admin** — Users (role-based access, audit log), Company Setup (settings,
Google Calendar, email, licence, backup), Recurring, Items, Dashboard Config.

---

## Your Data

Everything is stored in one `.dbox` file (SQLite, WAL mode, foreign keys
enforced). Back it up, copy it, or keep it in a synced folder. Schema changes
are applied automatically when a file is opened — upgrading is safe and
non-destructive. Backups and restores are under Admin → Company Setup (Backup and Auto-Backup).

---

## User Guides

A guide for every module is built into the app (the **Help** button at the
bottom of the sidebar), and as PDFs in `docs/guides/`:

| # | Guide | # | Guide |
|---|---|---|---|
| 01 | Getting Started | 15 | Items (Product Catalogue) |
| 02 | Dashboard | 16 | Recurring Transactions |
| 03 | Contacts | 17 | CRM — Now Part of Jobs |
| 04 | Invoices | 18 | Schedule |
| 05 | Bills | 19 | Purchase Orders |
| 06 | Payments | 20 | Fixed Assets |
| 07 | Bank Reconciliation | 21 | Warranties |
| 08 | Reports | 22 | Inventory |
| 09 | Accounts (Chart of Accounts) | 23 | Users and Security |
| 10 | Budget | 24 | Backup, Restore and Data Management |
| 11 | Payroll | 25 | Expense Claims |
| 12 | Journal | 25b | Petty Cash |
| 13 | Credit Cards | 26 | Point of Sale |
| 14 | Jobs and Projects | 27 | Table Service |
| 14b | Visits and Progress Claims | 28 | Quotes |
| 14c | Work Tasks | 29 | Promotions |
| 14d | Work Diary | 30 | Import from Software |

Regenerate the PDFs and this README, then the in-app help:
```
python tools/build_guides.py
python tools/build_guides.py --json
```

---

## Project Layout

```
dbox.py          Launcher — starts the web app and opens the browser window
core/            Business logic (pure Python; never imports web/ or ui/)
web/server.py    Flask app; routes in web/routes/, JS in web/static/js/
web/static/      dbox.css, JavaScript modules, help_content.json
tools/           build_guides.py and release tooling
docs/guides/     Generated PDF user guides
ui/              Legacy tkinter desktop UI (not distributed)
```

---

## Australian Tax Codes

| Code | Description | Rate |
|---|---|---|
| GST | GST on Income/Expenses | 10% |
| FRE | GST Free | 0% |
| INP | Input Taxed | 0% |
| N-T | Not Reportable | 0% |
| CAP | Capital Acquisitions | 10% |
| EXP | Export Sales | 0% |

---

## Security Notes

- Passwords: PBKDF2-SHA256, 260,000 iterations, timing-safe comparison
- Session cookies: HttpOnly, SameSite=Lax; login lockout after repeated failures
- Tax File Numbers and SMTP passwords are stored in the company file — protect
  it with disk encryption (BitLocker / FileVault)
- STP Phase 2 payloads are generated, not lodged directly — lodge via your
  registered tax agent or the ATO Business Portal
