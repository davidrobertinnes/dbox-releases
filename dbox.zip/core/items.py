# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
dbox Item Catalogue.

Items are reusable line-item templates — description, unit price, tax code,
and default account — that can be quickly added to invoices and bills.
"""

from core.database import get_connection


def migrate_items(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS items (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        code        TEXT,
        name        TEXT NOT NULL,
        description TEXT,
        unit_price  REAL NOT NULL DEFAULT 0.0,
        tax_code    TEXT NOT NULL DEFAULT 'GST',
        account_id  INTEGER REFERENCES accounts(id),
        is_active   INTEGER NOT NULL DEFAULT 1,
        created_at  TEXT DEFAULT (datetime('now','localtime')))""")
    # Unique index on code where code is not null/empty
    conn.execute("""CREATE UNIQUE INDEX IF NOT EXISTS idx_items_code
        ON items(code) WHERE code IS NOT NULL AND code != ''""")

    # ── Add inventory columns to existing databases (safe to run repeatedly) ──
    inventory_columns = [
        ("is_inventoried",   "INTEGER NOT NULL DEFAULT 0"),
        ("qty_on_hand",      "REAL NOT NULL DEFAULT 0.0"),
        ("reorder_level",    "REAL NOT NULL DEFAULT 0.0"),
        ("reorder_qty",      "REAL NOT NULL DEFAULT 0.0"),
        ("unit_cost",        "REAL NOT NULL DEFAULT 0.0"),
        ("cogs_account_id",  "INTEGER REFERENCES accounts(id)"),
        ("stock_account_id", "INTEGER REFERENCES accounts(id)"),
        ("location",         "TEXT"),
        ("barcode",          "TEXT"),
        ("pricing_mode",     "TEXT NOT NULL DEFAULT 'fixed'"),
        ("markup_value",     "REAL NOT NULL DEFAULT 0.0"),
        ("is_livestock",          "INTEGER NOT NULL DEFAULT 0"),
        ("livestock_category",    "TEXT"),
        ("livestock_ni_method",   "TEXT NOT NULL DEFAULT 'prescribed'"),
        ("livestock_pu_method",   "TEXT NOT NULL DEFAULT 'market'"),
        ("pos_visible",           "INTEGER NOT NULL DEFAULT 1"),
        ("pos_category",          "TEXT"),
    ]
    existing = {row[1] for row in
                conn.execute("PRAGMA table_info(items)").fetchall()}
    for col_name, col_def in inventory_columns:
        if col_name not in existing:
            conn.execute(
                f"ALTER TABLE items ADD COLUMN {col_name} {col_def}")


def get_items(db_path, active_only=True):
    conn = get_connection(db_path)
    q = """SELECT i.*, a.name as account_name, a.code as account_code
           FROM items i LEFT JOIN accounts a ON i.account_id = a.id
           WHERE 1=1"""
    if active_only:
        q += " AND i.is_active = 1"
    q += " ORDER BY i.name COLLATE NOCASE"
    rows = conn.execute(q).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_item(db_path, item_id):
    conn = get_connection(db_path)
    row = conn.execute(
        """SELECT i.*, a.name as account_name, a.code as account_code
           FROM items i LEFT JOIN accounts a ON i.account_id = a.id
           WHERE i.id = ?""", (item_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_item(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    item_id = data.get("id")
    # Apply defaults for NOT NULL columns
    defaults = {
        "is_active":    1,
        "is_inventoried": 0,
        "is_livestock": 0,
        "livestock_ni_method": "prescribed",
        "livestock_pu_method": "market",
        "qty_on_hand":  0.0,
        "reorder_level":0.0,
        "reorder_qty":  0.0,
        "unit_cost":    0.0,
        "tax_code":     "GST",
        "unit_price":   0.0,
        "pricing_mode": "fixed",
        "markup_value": 0.0,
        "pos_visible":  1,
    }
    for k, v in defaults.items():
        if data.get(k) is None:
            data[k] = v
    # Map income_account_id -> account_id if caller used the alias
    if "income_account_id" in data and "account_id" not in data:
        data["account_id"] = data["income_account_id"]
    fields = ["code", "name", "description", "unit_price",
              "tax_code", "account_id", "is_active",
              "is_inventoried", "is_livestock",
              "livestock_category", "livestock_ni_method", "livestock_pu_method",
              "qty_on_hand", "reorder_level",
              "reorder_qty", "unit_cost", "cogs_account_id",
              "stock_account_id", "location", "barcode",
              "pricing_mode", "markup_value",
              "pos_visible", "pos_category",
              "is_available", "prompt_modifiers"]
    vals = [data.get(f) for f in fields]
    if item_id:
        sets = ", ".join(f"{f}=?" for f in fields)
        conn.execute(f"UPDATE items SET {sets} WHERE id=?", vals + [item_id])
    else:
        cols = ", ".join(fields)
        ph   = ", ".join("?" for _ in fields)
        conn.execute(f"INSERT INTO items ({cols}) VALUES ({ph})", vals)
        item_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit()
    conn.close()
    return item_id


def delete_item(db_path, item_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM items WHERE id=?", (item_id,))
    conn.commit()
    conn.close()
