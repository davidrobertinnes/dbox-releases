"""
dbox CRM Module
===========================
Full sales pipeline: Lead → Quoted → Accepted → In Progress → Complete → Invoiced

Tables:
  crm_opportunities   — the pipeline deal / engagement record
  crm_communications  — log of every contact (call, email, meeting, note)
  crm_tasks           — timeline tasks / follow-ups attached to an opportunity
  crm_quotes          — formal quote with line items
  crm_quote_lines     — line items for a quote
  crm_progress_claims — progress payment claims (partial invoicing)
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.


from datetime import date as _date, timedelta as _td
from core.database import get_connection

# ── Pipeline Stages ────────────────────────────────────────────────────────────
PIPELINE_STAGES = [
    "Lead",
    "Qualified",
    "Quoted",
    "Accepted",
    "In Progress",
    "On Hold",
    "Complete",
    "Invoiced",
    "Won",
    "Lost",
]

COMM_TYPES  = ["Call", "Email", "Meeting", "Site Visit", "Note", "SMS", "Other"]
TASK_TYPES  = ["Follow Up", "Send Quote", "Schedule Meeting",
               "Site Inspection", "Internal Review", "Other"]
PRIORITY    = ["Low", "Normal", "High", "Urgent"]
QUOTE_STATUS = ["Draft", "Sent", "Accepted", "Declined", "Superseded"]


# ── Schema Migration ───────────────────────────────────────────────────────────

def migrate_crm(conn):
    """Create all CRM tables. Safe to call on existing databases."""

    # Core opportunity / deal record
    conn.execute("""CREATE TABLE IF NOT EXISTS crm_opportunities (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        opp_number      TEXT NOT NULL UNIQUE,
        title           TEXT NOT NULL,
        contact_id      INTEGER REFERENCES contacts(id),
        stage           TEXT NOT NULL DEFAULT 'Lead',
        source          TEXT,          -- Referral, Website, Cold Call, etc.
        value           REAL,          -- estimated deal value
        probability     INTEGER DEFAULT 50,  -- 0-100 %
        owner           TEXT,          -- salesperson / account manager
        start_date      TEXT,
        target_close    TEXT,
        actual_close    TEXT,
        job_id          INTEGER REFERENCES jobs(id),  -- linked job when accepted
        description     TEXT,
        notes           TEXT,
        created_by      INTEGER,
        created_at      TEXT DEFAULT (datetime('now','localtime')),
        updated_at      TEXT DEFAULT (datetime('now','localtime')))""")

    # Communication log
    conn.execute("""CREATE TABLE IF NOT EXISTS crm_communications (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        opp_id          INTEGER REFERENCES crm_opportunities(id) ON DELETE CASCADE,
        contact_id      INTEGER REFERENCES contacts(id),
        comm_date       TEXT NOT NULL,
        comm_type       TEXT NOT NULL DEFAULT 'Note',
        subject         TEXT,
        body            TEXT,
        outcome         TEXT,
        next_action     TEXT,
        next_action_date TEXT,
        logged_by       INTEGER,
        logged_at       TEXT DEFAULT (datetime('now','localtime')))""")

    # Tasks / follow-ups
    conn.execute("""CREATE TABLE IF NOT EXISTS crm_tasks (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        opp_id          INTEGER REFERENCES crm_opportunities(id) ON DELETE CASCADE,
        task_type       TEXT NOT NULL DEFAULT 'Follow Up',
        title           TEXT NOT NULL,
        description     TEXT,
        due_date        TEXT,
        priority        TEXT NOT NULL DEFAULT 'Normal',
        assigned_to     TEXT,
        is_done         INTEGER NOT NULL DEFAULT 0,
        done_at         TEXT,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    # Quotes
    conn.execute("""CREATE TABLE IF NOT EXISTS crm_quotes (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        quote_number    TEXT NOT NULL UNIQUE,
        opp_id          INTEGER REFERENCES crm_opportunities(id) ON DELETE CASCADE,
        contact_id      INTEGER REFERENCES contacts(id),
        quote_date      TEXT NOT NULL,
        expiry_date     TEXT,
        status          TEXT NOT NULL DEFAULT 'Draft',
        subtotal        REAL DEFAULT 0,
        gst_total       REAL DEFAULT 0,
        total           REAL DEFAULT 0,
        intro_text      TEXT,
        terms_text      TEXT,
        internal_notes  TEXT,
        accepted_date   TEXT,
        accepted_by     TEXT,
        invoice_id      INTEGER REFERENCES invoices(id),
        created_by      INTEGER,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    # Quote line items
    conn.execute("""CREATE TABLE IF NOT EXISTS crm_quote_lines (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        quote_id        INTEGER NOT NULL REFERENCES crm_quotes(id) ON DELETE CASCADE,
        sort_order      INTEGER DEFAULT 0,
        description     TEXT NOT NULL,
        quantity        REAL DEFAULT 1,
        unit_price      REAL DEFAULT 0,
        tax_code        TEXT DEFAULT 'GST',
        gst_amount      REAL DEFAULT 0,
        line_total      REAL DEFAULT 0,
        account_id      INTEGER REFERENCES accounts(id),
        item_id         INTEGER REFERENCES items(id))""")

    # Progress payment claims
    conn.execute("""CREATE TABLE IF NOT EXISTS crm_progress_claims (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        claim_number    TEXT NOT NULL UNIQUE,
        opp_id          INTEGER REFERENCES crm_opportunities(id),
        job_id          INTEGER REFERENCES jobs(id),
        contact_id      INTEGER REFERENCES contacts(id),
        claim_date      TEXT NOT NULL,
        description     TEXT,
        amount_ex_gst   REAL NOT NULL DEFAULT 0,
        gst_amount      REAL DEFAULT 0,
        amount_inc_gst  REAL NOT NULL DEFAULT 0,
        cumulative_pct  REAL DEFAULT 0,     -- % of contract claimed so far
        invoice_id      INTEGER REFERENCES invoices(id),
        status          TEXT NOT NULL DEFAULT 'Draft',  -- Draft/Claimed/Invoiced/Paid
        created_by      INTEGER,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    # Migration: add item_id to crm_quote_lines for existing databases
    try:
        conn.execute("ALTER TABLE crm_quote_lines ADD COLUMN item_id INTEGER REFERENCES items(id)")
    except Exception:
        pass  # column already exists

    # Indexes
    for name, defn in [
        ("idx_crm_opp_contact",   "crm_opportunities(contact_id)"),
        ("idx_crm_opp_stage",     "crm_opportunities(stage)"),
        ("idx_crm_comm_opp",      "crm_communications(opp_id)"),
        ("idx_crm_task_opp",      "crm_tasks(opp_id)"),
        ("idx_crm_task_due",      "crm_tasks(due_date, is_done)"),
        ("idx_crm_quote_opp",     "crm_quotes(opp_id)"),
        ("idx_crm_claim_opp",     "crm_progress_claims(opp_id)"),
    ]:
        try:
            conn.execute(f"CREATE INDEX IF NOT EXISTS {name} ON {defn}")
        except Exception:
            pass


# ── Opportunity Number ─────────────────────────────────────────────────────────

def next_opp_number(db_path):
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT opp_number FROM crm_opportunities ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    if row:
        try:
            return f"OPP-{int(row[0].split('-')[-1]) + 1:04d}"
        except Exception:
            pass
    return "OPP-0001"


def next_quote_number(db_path):
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT quote_number FROM crm_quotes ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    if row:
        try:
            return f"QTE-{int(row[0].split('-')[-1]) + 1:04d}"
        except Exception:
            pass
    return "QTE-0001"


def next_claim_number(db_path):
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT claim_number FROM crm_progress_claims ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    if row:
        try:
            return f"CLM-{int(row[0].split('-')[-1]) + 1:04d}"
        except Exception:
            pass
    return "CLM-0001"


# ── Opportunities ──────────────────────────────────────────────────────────────

def get_opportunities(db_path, stage=None, contact_id=None, search=None):
    conn = get_connection(db_path)
    q = """SELECT o.*, c.name as contact_name,
                  (SELECT COUNT(*) FROM crm_communications WHERE opp_id=o.id) as comm_count,
                  (SELECT COUNT(*) FROM crm_tasks WHERE opp_id=o.id AND is_done=0) as open_tasks,
                  (SELECT COUNT(*) FROM crm_quotes WHERE opp_id=o.id) as quote_count
           FROM crm_opportunities o
           LEFT JOIN contacts c ON o.contact_id=c.id
           WHERE 1=1"""
    params = []
    if stage and stage != "All":
        q += " AND o.stage=?"
        params.append(stage)
    if contact_id:
        q += " AND o.contact_id=?"
        params.append(contact_id)
    if search:
        q += " AND (o.title LIKE ? OR c.name LIKE ? OR o.opp_number LIKE ?)"
        s = f"%{search}%"
        params += [s, s, s]
    q += " ORDER BY o.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_opportunity(db_path, opp_id):
    conn = get_connection(db_path)
    row = conn.execute("""SELECT o.*, c.name as contact_name
                          FROM crm_opportunities o
                          LEFT JOIN contacts c ON o.contact_id=c.id
                          WHERE o.id=?""", (opp_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_opportunity(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    oid = data.get("id")
    now = str(_date.today())
    if oid:
        conn.execute("""UPDATE crm_opportunities SET
            title=?, contact_id=?, stage=?, source=?, value=?,
            probability=?, owner=?, start_date=?, target_close=?,
            actual_close=?, job_id=?, description=?, notes=?, updated_at=?
            WHERE id=?""",
            (data["title"], data.get("contact_id"), data.get("stage","Lead"),
             data.get("source"), data.get("value"), data.get("probability", 50),
             data.get("owner"), data.get("start_date"), data.get("target_close"),
             data.get("actual_close"), data.get("job_id"),
             data.get("description"), data.get("notes"), now, oid))
    else:
        conn.execute("""INSERT INTO crm_opportunities
            (opp_number,title,contact_id,stage,source,value,probability,
             owner,start_date,target_close,description,notes,created_by,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (data.get("opp_number", next_opp_number(db_path)),
             data["title"], data.get("contact_id"), data.get("stage","Lead"),
             data.get("source"), data.get("value"), data.get("probability", 50),
             data.get("owner"), data.get("start_date"), data.get("target_close"),
             data.get("description"), data.get("notes"),
             data.get("created_by"), now))
        oid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit()
    conn.close()
    return oid


def delete_opportunity(db_path, opp_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM crm_opportunities WHERE id=?", (opp_id,))
    conn.commit()
    conn.close()


# ── Pipeline summary ──────────────────────────────────────────────────────────

def get_pipeline_summary(db_path):
    """Returns {stage: {count, value}} for dashboard."""
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT stage,
               COUNT(*) as cnt,
               COALESCE(SUM(value),0) as total_value
        FROM crm_opportunities
        GROUP BY stage""").fetchall()
    conn.close()
    return {r["stage"]: {"count": r["cnt"], "value": r["total_value"]} for r in rows}


# ── Communications ─────────────────────────────────────────────────────────────

def get_communications(db_path, opp_id=None, contact_id=None, limit=200):
    conn = get_connection(db_path)
    q = """SELECT cm.*, c.name as contact_name
           FROM crm_communications cm
           LEFT JOIN contacts c ON cm.contact_id=c.id
           WHERE 1=1"""
    params = []
    if opp_id:
        q += " AND cm.opp_id=?"
        params.append(opp_id)
    if contact_id:
        q += " AND cm.contact_id=?"
        params.append(contact_id)
    q += " ORDER BY cm.comm_date DESC, cm.id DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_communication(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    cid = data.get("id")
    if cid:
        conn.execute("""UPDATE crm_communications SET
            opp_id=?, contact_id=?, comm_date=?, comm_type=?,
            subject=?, body=?, outcome=?, next_action=?, next_action_date=?
            WHERE id=?""",
            (data.get("opp_id"), data.get("contact_id"), data["comm_date"],
             data.get("comm_type","Note"), data.get("subject"),
             data.get("body"), data.get("outcome"),
             data.get("next_action"), data.get("next_action_date"), cid))
    else:
        conn.execute("""INSERT INTO crm_communications
            (opp_id,contact_id,comm_date,comm_type,subject,body,
             outcome,next_action,next_action_date,logged_by)
            VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (data.get("opp_id"), data.get("contact_id"), data["comm_date"],
             data.get("comm_type","Note"), data.get("subject"),
             data.get("body"), data.get("outcome"),
             data.get("next_action"), data.get("next_action_date"),
             data.get("logged_by")))
        cid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit()
    conn.close()
    return cid


def delete_communication(db_path, comm_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM crm_communications WHERE id=?", (comm_id,))
    conn.commit()
    conn.close()


# ── Tasks ─────────────────────────────────────────────────────────────────────

def get_tasks(db_path, opp_id=None, overdue_only=False, open_only=True):
    conn = get_connection(db_path)
    q = "SELECT * FROM crm_tasks WHERE 1=1"
    params = []
    if opp_id:
        q += " AND opp_id=?"
        params.append(opp_id)
    if open_only:
        q += " AND is_done=0"
    if overdue_only:
        q += " AND due_date < date('now')"
    q += " ORDER BY due_date, priority DESC, id"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_task(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    tid = data.get("id")
    if tid:
        conn.execute("""UPDATE crm_tasks SET
            opp_id=?, task_type=?, title=?, description=?,
            due_date=?, priority=?, assigned_to=?, is_done=?, done_at=?
            WHERE id=?""",
            (data.get("opp_id"), data.get("task_type","Follow Up"),
             data["title"], data.get("description"),
             data.get("due_date"), data.get("priority","Normal"),
             data.get("assigned_to"), int(data.get("is_done",0)),
             data.get("done_at"), tid))
    else:
        conn.execute("""INSERT INTO crm_tasks
            (opp_id,task_type,title,description,due_date,priority,assigned_to)
            VALUES (?,?,?,?,?,?,?)""",
            (data.get("opp_id"), data.get("task_type","Follow Up"),
             data["title"], data.get("description"),
             data.get("due_date"), data.get("priority","Normal"),
             data.get("assigned_to")))
        tid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit()
    conn.close()
    return tid


def complete_task(db_path, task_id):
    conn = get_connection(db_path)
    conn.execute("""UPDATE crm_tasks SET is_done=1, done_at=datetime('now','localtime')
                    WHERE id=?""", (task_id,))
    conn.commit()
    conn.close()


def delete_task(db_path, task_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM crm_tasks WHERE id=?", (task_id,))
    conn.commit()
    conn.close()


# ── Quotes ────────────────────────────────────────────────────────────────────

def get_quotes(db_path, opp_id=None):
    conn = get_connection(db_path)
    q = """SELECT q.*, c.name as contact_name,
                  o.title as opp_title, o.opp_number as opp_number
           FROM crm_quotes q
           LEFT JOIN contacts c ON q.contact_id=c.id
           LEFT JOIN crm_opportunities o ON q.opp_id=o.id
           WHERE 1=1"""
    params = []
    if opp_id:
        q += " AND q.opp_id=?"
        params.append(opp_id)
    q += " ORDER BY q.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_quote(db_path, quote_id):
    conn = get_connection(db_path)
    q = conn.execute("""SELECT q.*, c.name as contact_name
                        FROM crm_quotes q
                        LEFT JOIN contacts c ON q.contact_id=c.id
                        WHERE q.id=?""", (quote_id,)).fetchone()
    lines = conn.execute("""SELECT ql.*, a.name as account_name
                            FROM crm_quote_lines ql
                            LEFT JOIN accounts a ON ql.account_id=a.id
                            WHERE ql.quote_id=? ORDER BY ql.sort_order, ql.id""",
                         (quote_id,)).fetchall()
    conn.close()
    if not q:
        return None, []
    return dict(q), [dict(l) for l in lines]


def save_quote(db_path, qdata: dict, lines: list) -> int:
    """Save quote + recalculate totals. Returns quote_id."""
    conn = get_connection(db_path)
    gst_rate = 0.10
    subtotal = gst_total = 0.0
    for l in lines:
        ex = round(float(l.get("quantity", 1)) * float(l.get("unit_price", 0)), 2)
        gst = round(ex * gst_rate, 2) if l.get("tax_code","GST") == "GST" else 0.0
        l["gst_amount"] = gst
        l["line_total"] = round(ex + gst, 2)
        subtotal += ex
        gst_total += gst
    total = round(subtotal + gst_total, 2)

    qid = qdata.get("id")
    if qid:
        conn.execute("""UPDATE crm_quotes SET
            opp_id=?, contact_id=?, quote_date=?, expiry_date=?,
            status=?, subtotal=?, gst_total=?, total=?,
            intro_text=?, terms_text=?, internal_notes=?,
            accepted_date=?, accepted_by=?
            WHERE id=?""",
            (qdata.get("opp_id"), qdata.get("contact_id"),
             qdata["quote_date"], qdata.get("expiry_date"),
             qdata.get("status","Draft"), subtotal, gst_total, total,
             qdata.get("intro_text"), qdata.get("terms_text"),
             qdata.get("internal_notes"), qdata.get("accepted_date"),
             qdata.get("accepted_by"), qid))
        conn.execute("DELETE FROM crm_quote_lines WHERE quote_id=?", (qid,))
    else:
        conn.execute("""INSERT INTO crm_quotes
            (quote_number,opp_id,contact_id,quote_date,expiry_date,
             status,subtotal,gst_total,total,intro_text,terms_text,
             internal_notes,created_by)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (qdata.get("quote_number", next_quote_number(db_path)),
             qdata.get("opp_id"), qdata.get("contact_id"),
             qdata["quote_date"], qdata.get("expiry_date"),
             qdata.get("status","Draft"), subtotal, gst_total, total,
             qdata.get("intro_text"), qdata.get("terms_text"),
             qdata.get("internal_notes"), qdata.get("created_by")))
        qid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    for i, l in enumerate(lines):
        conn.execute("""INSERT INTO crm_quote_lines
            (quote_id,sort_order,description,quantity,unit_price,
             tax_code,gst_amount,line_total,account_id,item_id)
            VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (qid, i, l["description"], l.get("quantity", 1),
             l.get("unit_price", 0), l.get("tax_code","GST"),
             l["gst_amount"], l["line_total"], l.get("account_id"),
             l.get("item_id")))

    conn.commit()
    conn.close()
    return qid


def accept_quote(db_path, quote_id, accepted_by="") -> int:
    """Mark quote Accepted, set opportunity to Accepted stage. Returns opp_id."""
    conn = get_connection(db_path)
    conn.execute("""UPDATE crm_quotes SET status='Accepted',
                    accepted_date=date('now'), accepted_by=?
                    WHERE id=?""", (accepted_by, quote_id))
    # Mark other quotes on same opp as Superseded
    row = conn.execute("SELECT opp_id FROM crm_quotes WHERE id=?", (quote_id,)).fetchone()
    opp_id = row["opp_id"] if row else None
    if opp_id:
        conn.execute("""UPDATE crm_quotes SET status='Superseded'
                        WHERE opp_id=? AND id!=? AND status='Draft'""",
                     (opp_id, quote_id))
        conn.execute("""UPDATE crm_opportunities SET stage='Accepted', updated_at=date('now')
                        WHERE id=?""", (opp_id,))
    conn.commit()
    conn.close()
    return opp_id


def convert_quote_to_invoice(db_path, quote_id, created_by=None) -> int:
    """Convert an accepted quote into a formal invoice. Returns invoice_id."""
    from core.ledger import save_invoice
    quote, lines = get_quote(db_path, quote_id)
    if not quote:
        raise ValueError("Quote not found")

    inv_lines = []
    for l in lines:
        inv_lines.append({
            "description": l["description"],
            "quantity":    l["quantity"],
            "unit_price":  l["unit_price"],
            "tax_code":    l["tax_code"],
            "account_id":  l.get("account_id"),
            "item_id":     l.get("item_id"),
        })
    inv_data = {
        "contact_id":   quote["contact_id"],
        "invoice_date": str(_date.today()),
        "due_date":     str(_date.today() + _td(days=30)),
        "status":       "Draft",
        "notes":        f"From Quote {quote['quote_number']}",
    }
    inv_id = save_invoice(db_path, inv_data, inv_lines)

    conn = get_connection(db_path)
    conn.execute("UPDATE crm_quotes SET invoice_id=?, status='Invoiced' WHERE id=?", (inv_id, quote_id))
    if quote.get("opp_id"):
        conn.execute("""UPDATE crm_opportunities SET stage='Invoiced', updated_at=date('now')
                        WHERE id=?""", (quote["opp_id"],))
    conn.commit()
    conn.close()
    return inv_id


def delete_quote(db_path, quote_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM crm_quotes WHERE id=?", (quote_id,))
    conn.commit()
    conn.close()


# ── Progress Claims ───────────────────────────────────────────────────────────

def get_progress_claims(db_path, opp_id=None, job_id=None):
    conn = get_connection(db_path)
    q = """SELECT pc.*, c.name as contact_name
           FROM crm_progress_claims pc
           LEFT JOIN contacts c ON pc.contact_id=c.id
           WHERE 1=1"""
    params = []
    if opp_id:
        q += " AND pc.opp_id=?"
        params.append(opp_id)
    if job_id:
        q += " AND pc.job_id=?"
        params.append(job_id)
    q += " ORDER BY pc.id"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_progress_claim(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    cid = data.get("id")
    ex  = float(data.get("amount_ex_gst", 0))
    gst = round(ex * 0.10, 2) if data.get("tax_code","GST") == "GST" else 0.0
    inc = round(ex + gst, 2)

    if cid:
        conn.execute("""UPDATE crm_progress_claims SET
            opp_id=?, job_id=?, contact_id=?, claim_date=?,
            description=?, amount_ex_gst=?, gst_amount=?,
            amount_inc_gst=?, cumulative_pct=?, status=?
            WHERE id=?""",
            (data.get("opp_id"), data.get("job_id"), data.get("contact_id"),
             data["claim_date"], data.get("description"),
             ex, gst, inc, data.get("cumulative_pct", 0),
             data.get("status","Draft"), cid))
    else:
        conn.execute("""INSERT INTO crm_progress_claims
            (claim_number,opp_id,job_id,contact_id,claim_date,
             description,amount_ex_gst,gst_amount,amount_inc_gst,
             cumulative_pct,status,created_by)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (data.get("claim_number", next_claim_number(db_path)),
             data.get("opp_id"), data.get("job_id"), data.get("contact_id"),
             data["claim_date"], data.get("description"),
             ex, gst, inc, data.get("cumulative_pct", 0),
             data.get("status","Draft"), data.get("created_by")))
        cid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit()
    conn.close()
    return cid


def claim_to_invoice(db_path, claim_id, created_by=None) -> int:
    """Convert a progress claim to a real invoice. Returns invoice_id."""
    from core.ledger import save_invoice
    conn = get_connection(db_path)
    claim = conn.execute("SELECT * FROM crm_progress_claims WHERE id=?",
                         (claim_id,)).fetchone()
    conn.close()
    if not claim:
        raise ValueError("Claim not found")
    claim = dict(claim)

    inv_lines = [{
        "description": claim["description"] or f"Progress Claim {claim['claim_number']}",
        "quantity":    1,
        "unit_price":  claim["amount_ex_gst"],
        "tax_code":    "GST",
        "account_id":  None,
    }]
    inv_data = {
        "contact_id":   claim["contact_id"],
        "invoice_date": str(_date.today()),
        "due_date":     str(_date.today() + _td(days=14)),
        "status":       "Draft",
        "notes":        f"Progress Claim {claim['claim_number']}",
    }
    inv_id = save_invoice(db_path, inv_data, inv_lines)

    conn = get_connection(db_path)
    conn.execute("""UPDATE crm_progress_claims SET invoice_id=?, status='Invoiced'
                    WHERE id=?""", (inv_id, claim_id))
    conn.commit()
    conn.close()
    return inv_id


def delete_progress_claim(db_path, claim_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM crm_progress_claims WHERE id=?", (claim_id,))
    conn.commit()
    conn.close()


# ── Dashboard helpers ─────────────────────────────────────────────────────────

def get_crm_dashboard(db_path):
    """Single-query dashboard snapshot."""
    conn = get_connection(db_path)
    pipeline = {r["stage"]: {"count": r["cnt"], "value": r["total_value"]}
                for r in conn.execute("""
                    SELECT stage, COUNT(*) cnt, COALESCE(SUM(value),0) total_value
                    FROM crm_opportunities GROUP BY stage""").fetchall()}
    overdue_tasks = conn.execute("""
        SELECT t.*, o.title as opp_title
        FROM crm_tasks t
        LEFT JOIN crm_opportunities o ON t.opp_id=o.id
        WHERE t.is_done=0 AND t.due_date < date('now')
        ORDER BY t.due_date LIMIT 10""").fetchall()
    recent_comms = conn.execute("""
        SELECT cm.*, c.name as contact_name, o.title as opp_title
        FROM crm_communications cm
        LEFT JOIN contacts c ON cm.contact_id=c.id
        LEFT JOIN crm_opportunities o ON cm.opp_id=o.id
        ORDER BY cm.comm_date DESC, cm.id DESC LIMIT 10""").fetchall()
    upcoming_tasks = conn.execute("""
        SELECT t.*, o.title as opp_title
        FROM crm_tasks t
        LEFT JOIN crm_opportunities o ON t.opp_id=o.id
        WHERE t.is_done=0 AND (t.due_date >= date('now') OR t.due_date IS NULL)
        ORDER BY t.due_date LIMIT 10""").fetchall()
    conn.close()
    return {
        "pipeline":       pipeline,
        "overdue_tasks":  [dict(r) for r in overdue_tasks],
        "recent_comms":   [dict(r) for r in recent_comms],
        "upcoming_tasks": [dict(r) for r in upcoming_tasks],
    }
