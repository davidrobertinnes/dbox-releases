# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Accounting — Schedule Events

Freeform calendar items that aren't a Job or a CRM/work task — personal
appointments, reminders, meetings. Optionally linked to a contact and/or an
existing job for context. An unlinked event can be converted into a new Job.

A 'Visit' is an event linked to a job that records a trip to do that job's
work — a job can have many. Visits carry the time of day, hours worked, and
(once billed) the invoice they were billed on. They sync with Google Calendar
like any other event; a job with visits no longer pushes its own all-day
span (see core/gcal.py: push_job).
"""

from __future__ import annotations
from core.database import get_connection

EVENT_TYPES = ['Personal', 'Appointment', 'Meeting', 'Reminder', 'Visit', 'Other']


# ─────────────────────────────────────────────────────────────────────────────
#  MIGRATION
# ─────────────────────────────────────────────────────────────────────────────

def migrate_schedule_events(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS schedule_events (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        title         TEXT NOT NULL,
        description   TEXT,
        event_type    TEXT NOT NULL DEFAULT 'Personal',
        event_date    TEXT NOT NULL,
        end_date      TEXT,
        all_day       INTEGER NOT NULL DEFAULT 1,
        start_time    TEXT,
        end_time      TEXT,
        contact_id    INTEGER REFERENCES contacts(id),
        job_id        INTEGER REFERENCES jobs(id),
        created_by    INTEGER,
        created_at    TEXT DEFAULT (datetime('now','localtime')))""")
    # Google Calendar sync bookkeeping (phase 2b) — added via ALTER TABLE,
    # the established evolve-in-place pattern in this codebase.
    #   updated_at    — bumped on every save_event() call, local clock.
    #   gcal_event_id — Google's event id; NULL means local-only.
    #   gcal_updated  — Google's own `updated` field verbatim, used only to
    #                   detect a content change on Google's side (compared
    #                   against Google's own values, never mixed with local
    #                   timestamps).
    #   synced_at     — local clock, set exactly alongside updated_at
    #                   whenever a sync-driven write happens. Comparing
    #                   updated_at > synced_at (both local clock, always
    #                   comparable) is how a pending, un-pushed local edit
    #                   is detected — see core/gcal.py: pull_events().
    for col, defn in [
        ('updated_at',    'TEXT'),
        ('gcal_event_id', 'TEXT'),
        ('gcal_updated',  'TEXT'),
        ('synced_at',     'TEXT'),
        # Job visits — hours worked (billable) and the invoice they were
        # billed on. Never touched by Google sync (see save_event).
        ('hours',         'REAL'),
        ('invoice_id',    'INTEGER REFERENCES invoices(id)'),
        # Superseded by worker_contact_id (2.6.0 only); kept for the move below.
        ('employee_id',   'INTEGER REFERENCES employees(id)'),
        # Who does the visit: a contact (Employee type, or linked to a payroll
        # employee). NULL = unassigned.
        ('worker_contact_id', 'INTEGER REFERENCES contacts(id)'),
    ]:
        try:
            conn.execute(f"ALTER TABLE schedule_events ADD COLUMN {col} {defn}")
        except Exception:
            pass
    # 2.6.0 stored payroll employee ids; move them to the employee's contact.
    try:
        conn.execute("""UPDATE schedule_events SET worker_contact_id =
                (SELECT em.contact_id FROM employees em WHERE em.id = schedule_events.employee_id),
                employee_id = NULL
            WHERE employee_id IS NOT NULL AND worker_contact_id IS NULL""")
    except Exception:
        pass   # no payroll tables in this file
    try:
        conn.execute("""CREATE UNIQUE INDEX IF NOT EXISTS idx_schedule_events_gcal_id
            ON schedule_events(gcal_event_id) WHERE gcal_event_id IS NOT NULL""")
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
#  CRUD
# ─────────────────────────────────────────────────────────────────────────────

# The assigned worker's name
_WORKER_SQL = "(SELECT w.name FROM contacts w WHERE w.id = e.worker_contact_id)"

_CURRENT_EMP = "(termination_date IS NULL OR termination_date = '' OR termination_date >= date('now','localtime'))"


def list_workers(db_path) -> list:
    """Who can be put on a visit: [{id, name}] of contacts. Active contacts marked
    Employee or Contractor, plus contacts linked to a current payroll employee; a contact
    linked only to employees who have left is not offered. Works without Payroll."""
    conn = get_connection(db_path)
    try:
        rows = conn.execute(f"""SELECT c.id, c.name FROM contacts c
            WHERE c.is_active = 1 AND (
              c.id IN (SELECT contact_id FROM employees WHERE contact_id IS NOT NULL AND {_CURRENT_EMP})
              OR (c.worker_type IN ('Employee','Contractor') AND c.id NOT IN
                  (SELECT contact_id FROM employees WHERE contact_id IS NOT NULL AND NOT {_CURRENT_EMP})))
            ORDER BY c.name COLLATE NOCASE""").fetchall()
    except Exception:   # no payroll tables in this file
        rows = conn.execute("""SELECT id, name FROM contacts
            WHERE is_active = 1 AND worker_type IN ('Employee','Contractor')
            ORDER BY name COLLATE NOCASE""").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def list_events(db_path) -> list:
    conn = get_connection(db_path)
    rows = conn.execute(f"""SELECT e.*, c.name as contact_name,
        j.job_number as job_number, j.name as job_name, j.site_address as site_address,
        {_WORKER_SQL} as worker_name
        FROM schedule_events e
        LEFT JOIN contacts c ON e.contact_id = c.id
        LEFT JOIN jobs j ON e.job_id = j.id
        ORDER BY e.event_date, e.id""").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_event(db_path, event_id: int) -> dict | None:
    conn = get_connection(db_path)
    row = conn.execute(f"""SELECT e.*, c.name as contact_name,
        j.job_number as job_number, j.name as job_name, j.site_address as site_address,
        {_WORKER_SQL} as worker_name
        FROM schedule_events e
        LEFT JOIN contacts c ON e.contact_id = c.id
        LEFT JOIN jobs j ON e.job_id = j.id
        WHERE e.id=?""", (event_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_event(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    eid = data.get('id')
    all_day = 1 if data.get('all_day', True) else 0
    fields = ['title', 'description', 'event_type', 'event_date', 'end_date',
              'all_day', 'start_time', 'end_time', 'contact_id', 'job_id',
              'created_by']
    vals = [data.get(f) for f in fields]
    vals[fields.index('all_day')] = all_day

    # gcal_event_id/gcal_updated are sync-only fields — only ever written
    # when core/gcal.py explicitly supplies them (signalled by the presence
    # of 'gcal_updated' in data), so a plain UI-driven edit never blanks out
    # an event's link to Google. synced_at is bumped in lockstep, using the
    # same NOW() as updated_at, so "local edit since last sync" can later be
    # detected with a plain updated_at > synced_at comparison.
    from_sync   = 'gcal_updated' in data
    sync_fields = ['gcal_event_id', 'gcal_updated'] if from_sync else []
    # hours/invoice_id are dbox-only — written only when the caller supplies
    # them, so Google sync (which rebuilds the row from its own field list)
    # and older callers never blank them out.
    # worker_contact_id likewise (Google has no idea who's assigned).
    opt_fields  = [f for f in ('hours', 'invoice_id', 'worker_contact_id') if f in data]
    if 'worker_contact_id' in data:
        w = data.get('worker_contact_id')
        data['worker_contact_id'] = int(w) if w not in (None, '', 0, '0') else None
    all_fields  = fields + sync_fields + opt_fields
    all_vals    = vals + [data.get(f) for f in sync_fields + opt_fields]

    # Millisecond precision (not plain datetime()'s 1-second resolution) —
    # updated_at/synced_at need to stay orderable even when a sync and a
    # follow-up edit land in the same second.
    now_sql    = "strftime('%Y-%m-%d %H:%M:%f','now','localtime')"
    extra_sets = f", updated_at={now_sql}" + (f", synced_at={now_sql}" if from_sync else "")

    if eid:
        sets = ", ".join(f"{f}=?" for f in all_fields) + extra_sets
        conn.execute(f"UPDATE schedule_events SET {sets} WHERE id=?", all_vals + [eid])
    else:
        extra_cols = "updated_at" + (", synced_at" if from_sync else "")
        extra_ph   = now_sql + (f", {now_sql}" if from_sync else "")
        cols = ", ".join(all_fields) + f", {extra_cols}"
        ph   = ", ".join("?" for _ in all_fields) + f", {extra_ph}"
        conn.execute(f"INSERT INTO schedule_events ({cols}) VALUES ({ph})", all_vals)
        eid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit(); conn.close()
    return eid


def get_event_by_gcal_id(db_path, gcal_event_id: str) -> dict | None:
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT * FROM schedule_events WHERE gcal_event_id=?", (gcal_event_id,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def delete_event(db_path, event_id: int):
    # A visit's task progress goes with it — re-derive those tasks' status
    # (a task only a deleted visit had completed reopens).
    from core.visit_tasks import delete_visit_progress
    delete_visit_progress(db_path, event_id)
    conn = get_connection(db_path)
    conn.execute("DELETE FROM schedule_events WHERE id=?", (event_id,))
    conn.commit(); conn.close()


def list_job_visits(db_path, job_id: int) -> list:
    """All events linked to a job (visits first-class, plus any meeting etc.
    linked for context), in date/time order."""
    conn = get_connection(db_path)
    rows = conn.execute(f"""SELECT e.*, {_WORKER_SQL} as worker_name FROM schedule_events e
        WHERE e.job_id=? ORDER BY e.event_date, COALESCE(e.start_time, ''), e.id""", (job_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def job_has_visits(db_path, job_id: int) -> bool:
    conn = get_connection(db_path)
    row = conn.execute("""SELECT 1 FROM schedule_events
        WHERE job_id=? AND event_type='Visit' LIMIT 1""", (job_id,)).fetchone()
    conn.close()
    return bool(row)


def unlink_event_gcal(db_path, event_id: int):
    """Drop an event's link to Google without deleting the local row — for
    a billed visit whose Google event was deleted on the phone: the billing
    record must survive, but pushing to a dead Google id must stop."""
    conn = get_connection(db_path)
    conn.execute("""UPDATE schedule_events SET gcal_event_id=NULL, gcal_updated=NULL
        WHERE id=?""", (event_id,))
    conn.commit(); conn.close()


def convert_event_to_job(db_path, event_id: int) -> int:
    """Turn an unlinked schedule event into a new Job. The event itself is
    kept and becomes the job's first Visit, so its time of day survives."""
    from core.jobs import save_job, next_job_number

    event = get_event(db_path, event_id)
    if not event:
        raise ValueError(f"Event {event_id} not found")
    if event.get('job_id'):
        raise ValueError("Event is already linked to a job")

    job_data = {
        'job_number':  next_job_number(db_path),
        'name':        event['title'],
        'description': event.get('description'),
        'contact_id':  event.get('contact_id'),
        'start_date':  event['event_date'],
        'end_date':    event.get('end_date'),
        'stage':       'Lead',
    }
    jid = save_job(db_path, job_data)
    # Without gcal_updated in the dict this is an ordinary local edit, so
    # save_event() leaves the Google link untouched.
    keep = {k: v for k, v in event.items() if k != 'gcal_updated'}
    save_event(db_path, {**keep, 'job_id': jid, 'event_type': 'Visit'})
    return jid
