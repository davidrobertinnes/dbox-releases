"""
Dogbox Accounting — Awards & Agreements Backend

Supports Modern Awards (Fair Work Act), Enterprise Agreements (EAs),
and individual Workplace Agreements.

Tables:
  awards                — instrument on file (award/EA/IWA)
  award_classifications — pay levels/grades within an instrument
  award_pay_rates       — base pay rates per classification (with effective dates)
  award_allowances      — allowances defined in the instrument
  award_penalty_rates   — penalty/loading multipliers

Employee linkage:
  employees.award_id            → which instrument applies
  employees.classification_id   → their current level/grade
  employees.pay_point           → within-level pay point (if applicable)

Pay rate resolution order (highest specificity wins):
  1. employees.hourly_rate (manually overridden)
  2. award_pay_rates for (classification_id, effective_date ≤ today)
  3. employees.annual_salary / hours_per_week
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.


import json
from datetime import date
from .database import get_connection


# ── Instrument types ──────────────────────────────────────────────────────────

INSTRUMENT_TYPES = [
    "Modern Award",
    "Enterprise Agreement",
    "Individual Flexibility Arrangement",
    "Workplace Determination",
    "Greenfields Agreement",
    "Common Law Contract",
]

# Common Australian Modern Award examples for seeding hints
COMMON_AWARDS = [
    ("MA000002", "Clerks — Private Sector Award 2020"),
    ("MA000003", "Commercial Sales Award 2020"),
    ("MA000009", "Hospitality Industry (General) Award 2020"),
    ("MA000010", "Manufacturing and Associated Industries Award 2020"),
    ("MA000020", "Retail Industry Award 2020"),
    ("MA000022", "Building and Construction General On-Site Award 2020"),
    ("MA000023", "Joinery and Building Trades Award 2020"),
    ("MA000025", "Electrical, Electronic and Communications Contracting Award 2020"),
    ("MA000029", "General Retail Industry Award 2020"),
    ("MA000034", "Health Professionals and Support Services Award 2020"),
    ("MA000041", "Legal Services Award 2020"),
    ("MA000050", "Professional Employees Award 2020"),
    ("MA000065", "Social, Community, Home Care and Disability Services Industry Award 2020"),
    ("MA000074", "Aged Care Industry Award 2020"),
    ("MA000100", "Miscellaneous Award 2020"),
]

ALLOWANCE_TYPES = [
    "Meal allowance",
    "Travel allowance",
    "Vehicle / kilometre allowance",
    "Tool allowance",
    "Uniform / laundry allowance",
    "First aid allowance",
    "Leading hand allowance",
    "Shift allowance",
    "On-call allowance",
    "Remote area allowance",
    "Cold / height / dirt allowance",
    "Safety / protective clothing",
    "Phone allowance",
    "Other",
]

PENALTY_TYPES = [
    ("Saturday",           "Saturday loading"),
    ("Sunday",             "Sunday loading"),
    ("PublicHoliday",      "Public holiday loading"),
    ("AfternoonShift",     "Afternoon shift loading"),
    ("NightShift",         "Night shift loading"),
    ("ContinuousNight",    "Continuous night shift loading"),
    ("Overtime_1_5",       "Overtime (first 2 hours) × 1.5"),
    ("Overtime_2_0",       "Overtime (after 2 hours) × 2.0"),
    ("CasualLoading",      "Casual loading"),
    ("EarlyMorning",       "Early morning shift loading"),
    ("BrokenShift",        "Broken shift loading"),
]


# ── Schema migration ───────────────────────────────────────────────────────────

def migrate_awards(conn):
    """Create award/agreement tables. Safe to call multiple times."""

    conn.execute("""CREATE TABLE IF NOT EXISTS awards (
        id                  INTEGER PRIMARY KEY AUTOINCREMENT,
        instrument_type     TEXT NOT NULL DEFAULT 'Modern Award',
        code                TEXT,                   -- e.g. MA000020
        name                TEXT NOT NULL,
        industry            TEXT,
        effective_date      TEXT,                   -- ISO date
        expiry_date         TEXT,                   -- ISO date (EAs expire)
        nominal_expiry      TEXT,                   -- EA nominal expiry
        employer_name       TEXT,                   -- for EAs
        bargaining_agent    TEXT,
        fwc_reference       TEXT,                   -- Fair Work Commission reference
        file_data           BLOB,                   -- PDF of the instrument
        file_name           TEXT,
        mime_type           TEXT,
        notes               TEXT,
        is_active           INTEGER NOT NULL DEFAULT 1,
        created_at          TEXT DEFAULT (datetime('now','localtime')),
        updated_at          TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS award_classifications (
        id                  INTEGER PRIMARY KEY AUTOINCREMENT,
        award_id            INTEGER NOT NULL REFERENCES awards(id) ON DELETE CASCADE,
        code                TEXT,                   -- e.g. 'L1', 'Grade A', 'BW1'
        name                TEXT NOT NULL,          -- e.g. 'Level 1 — Grade 1'
        description         TEXT,                   -- duties/responsibilities summary
        minimum_qualifications TEXT,
        sort_order          INTEGER NOT NULL DEFAULT 0,
        is_active           INTEGER NOT NULL DEFAULT 1)""")

    conn.execute("""CREATE TABLE IF NOT EXISTS award_pay_rates (
        id                  INTEGER PRIMARY KEY AUTOINCREMENT,
        classification_id   INTEGER NOT NULL REFERENCES award_classifications(id) ON DELETE CASCADE,
        pay_point           INTEGER NOT NULL DEFAULT 1,   -- within-level increment
        effective_date      TEXT NOT NULL,                -- ISO date (wage review date)
        weekly_rate         REAL,                         -- standard 38hr week rate
        hourly_rate         REAL NOT NULL,
        casual_rate         REAL,                         -- hourly incl. casual loading
        overtime_rate_1_5   REAL,                         -- pre-calculated or NULL
        overtime_rate_2_0   REAL,
        annual_equivalent   REAL GENERATED ALWAYS AS
                                (hourly_rate * 38 * 52) VIRTUAL,
        source_note         TEXT,                         -- e.g. 'Annual Wage Review 2024'
        UNIQUE(classification_id, pay_point, effective_date))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS award_allowances (
        id                  INTEGER PRIMARY KEY AUTOINCREMENT,
        award_id            INTEGER NOT NULL REFERENCES awards(id) ON DELETE CASCADE,
        allowance_type      TEXT NOT NULL,
        name                TEXT NOT NULL,
        description         TEXT,
        amount              REAL,                         -- $ amount (if fixed)
        rate_per_km         REAL,                         -- for travel
        rate_per_hour       REAL,                         -- for hourly allowances
        calculation_basis   TEXT NOT NULL DEFAULT 'fixed', -- fixed/per_km/per_hour/percent_ordinary
        percent_ordinary    REAL,                         -- % of ordinary rate
        taxable             INTEGER NOT NULL DEFAULT 1,
        stp_allowance_type  TEXT DEFAULT 'OD',            -- STP reporting code
        effective_date      TEXT,
        is_active           INTEGER NOT NULL DEFAULT 1)""")

    conn.execute("""CREATE TABLE IF NOT EXISTS award_penalty_rates (
        id                  INTEGER PRIMARY KEY AUTOINCREMENT,
        award_id            INTEGER NOT NULL REFERENCES awards(id) ON DELETE CASCADE,
        classification_id   INTEGER REFERENCES award_classifications(id),  -- NULL = all
        penalty_type        TEXT NOT NULL,
        multiplier          REAL NOT NULL,                -- e.g. 1.5, 2.0, 1.25
        description         TEXT,
        effective_date      TEXT,
        is_active           INTEGER NOT NULL DEFAULT 1)""")

    # Migrate existing employees table to add award linkage columns
    for _col, _def in [
        ("award_id",                "INTEGER REFERENCES awards(id)"),
        ("classification_id",       "INTEGER REFERENCES award_classifications(id)"),
        ("pay_point",               "INTEGER DEFAULT 1"),
        ("pay_rate_modifier",       "REAL DEFAULT 0"),
        ("pay_rate_modifier_type",  "TEXT DEFAULT '%'"),   # '%' or '$'
    ]:
        try:
            conn.execute(f"ALTER TABLE employees ADD COLUMN {_col} {_def}")
        except Exception:
            pass

    # Indexes
    for name, defn in [
        ("idx_award_class_award",  "award_classifications(award_id)"),
        ("idx_award_rate_class",   "award_pay_rates(classification_id, effective_date)"),
        ("idx_award_allow_award",  "award_allowances(award_id)"),
        ("idx_award_penalty_award","award_penalty_rates(award_id)"),
    ]:
        try:
            conn.execute(f"CREATE INDEX IF NOT EXISTS {name} ON {defn}")
        except Exception:
            pass

    conn.commit()


# ── Award CRUD ────────────────────────────────────────────────────────────────

def get_awards(db_path, active_only=True) -> list:
    conn = get_connection(db_path)
    q = """SELECT a.*, COUNT(e.id) as employee_count
           FROM awards a
           LEFT JOIN employees e ON e.award_id = a.id"""
    if active_only:
        q += " WHERE a.is_active=1"
    q += " GROUP BY a.id ORDER BY a.instrument_type, a.name"
    rows = conn.execute(q).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_award(db_path, award_id) -> dict | None:
    conn = get_connection(db_path)
    row = conn.execute("SELECT * FROM awards WHERE id=?", (award_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_award(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    award_id = data.get("id")
    fields = ["instrument_type","code","name","industry","effective_date",
              "expiry_date","nominal_expiry","employer_name","bargaining_agent",
              "fwc_reference","file_data","file_name","mime_type","notes","is_active"]
    vals = [data.get(f) for f in fields]
    if award_id:
        sets = ", ".join(f"{f}=?" for f in fields)
        sets += ", updated_at=datetime('now','localtime')"
        conn.execute(f"UPDATE awards SET {sets} WHERE id=?", vals + [award_id])
        conn.commit(); conn.close()
        return award_id
    cur = conn.execute(
        f"INSERT INTO awards ({','.join(fields)}) VALUES ({','.join('?'*len(fields))})", vals)
    new_id = cur.lastrowid
    conn.commit(); conn.close()
    return new_id


def delete_award(db_path, award_id: int) -> None:
    conn = get_connection(db_path)
    conn.execute("UPDATE awards SET is_active=0 WHERE id=?", (award_id,))
    conn.commit(); conn.close()


# ── Classification CRUD ────────────────────────────────────────────────────────

def get_classifications(db_path, award_id: int) -> list:
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT ac.*, a.name AS award_name
        FROM award_classifications ac
        JOIN awards a ON a.id=ac.award_id
        WHERE ac.award_id=? AND ac.is_active=1
        ORDER BY ac.sort_order, ac.code""", (award_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_classification(db_path, classification_id: int) -> dict | None:
    conn = get_connection(db_path)
    row = conn.execute("SELECT * FROM award_classifications WHERE id=?",
                       (classification_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_classification(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    cid = data.get("id")
    fields = ["award_id","code","name","description","minimum_qualifications",
              "sort_order","is_active"]
    vals = [data.get(f) for f in fields]
    if cid:
        sets = ", ".join(f"{f}=?" for f in fields)
        conn.execute(f"UPDATE award_classifications SET {sets} WHERE id=?", vals + [cid])
        conn.commit(); conn.close()
        return cid
    cur = conn.execute(
        f"INSERT INTO award_classifications ({','.join(fields)}) VALUES ({','.join('?'*len(fields))})",
        vals)
    new_id = cur.lastrowid
    conn.commit(); conn.close()
    return new_id


def delete_classification(db_path, classification_id: int) -> None:
    conn = get_connection(db_path)
    conn.execute("UPDATE award_classifications SET is_active=0 WHERE id=?",
                 (classification_id,))
    conn.commit(); conn.close()


# ── Pay Rates ─────────────────────────────────────────────────────────────────

def get_pay_rates(db_path, classification_id: int) -> list:
    """All pay rate rows for a classification, newest first."""
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT * FROM award_pay_rates
        WHERE classification_id=?
        ORDER BY effective_date DESC, pay_point""",
        (classification_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_current_rate(db_path, classification_id: int,
                     pay_point: int = 1,
                     as_of: str = None) -> dict | None:
    """Return the most recent pay rate row effective on or before as_of date."""
    as_of = as_of or str(date.today())
    conn = get_connection(db_path)
    row = conn.execute("""SELECT * FROM award_pay_rates
        WHERE classification_id=? AND pay_point=? AND effective_date<=?
        ORDER BY effective_date DESC LIMIT 1""",
        (classification_id, pay_point, as_of)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_pay_rate(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    rate_id = data.get("id")
    fields = ["classification_id","pay_point","effective_date","weekly_rate",
              "hourly_rate","casual_rate","overtime_rate_1_5","overtime_rate_2_0",
              "source_note"]
    vals = [data.get(f) for f in fields]
    if rate_id:
        sets = ", ".join(f"{f}=?" for f in fields)
        conn.execute(f"UPDATE award_pay_rates SET {sets} WHERE id=?", vals + [rate_id])
        conn.commit(); conn.close()
        return rate_id
    cur = conn.execute(
        f"INSERT INTO award_pay_rates ({','.join(fields)}) VALUES ({','.join('?'*len(fields))})",
        vals)
    new_id = cur.lastrowid
    conn.commit(); conn.close()
    return new_id


def delete_pay_rate(db_path, rate_id: int) -> None:
    conn = get_connection(db_path)
    conn.execute("DELETE FROM award_pay_rates WHERE id=?", (rate_id,))
    conn.commit(); conn.close()


# ── Allowances ────────────────────────────────────────────────────────────────

def get_award_allowances(db_path, award_id: int) -> list:
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT * FROM award_allowances
        WHERE award_id=? AND is_active=1
        ORDER BY allowance_type, name""", (award_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_award_allowance(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    aid = data.get("id")
    fields = ["award_id","allowance_type","name","description","amount",
              "rate_per_km","rate_per_hour","calculation_basis","percent_ordinary",
              "taxable","stp_allowance_type","effective_date","is_active"]
    vals = [data.get(f) for f in fields]
    if aid:
        sets = ", ".join(f"{f}=?" for f in fields)
        conn.execute(f"UPDATE award_allowances SET {sets} WHERE id=?", vals + [aid])
        conn.commit(); conn.close()
        return aid
    cur = conn.execute(
        f"INSERT INTO award_allowances ({','.join(fields)}) VALUES ({','.join('?'*len(fields))})",
        vals)
    new_id = cur.lastrowid
    conn.commit(); conn.close()
    return new_id


def delete_award_allowance(db_path, allowance_id: int) -> None:
    conn = get_connection(db_path)
    conn.execute("UPDATE award_allowances SET is_active=0 WHERE id=?", (allowance_id,))
    conn.commit(); conn.close()


# ── Penalty Rates ─────────────────────────────────────────────────────────────

def get_penalty_rates(db_path, award_id: int) -> list:
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT pr.*, ac.name AS classification_name
        FROM award_penalty_rates pr
        LEFT JOIN award_classifications ac ON ac.id=pr.classification_id
        WHERE pr.award_id=? AND pr.is_active=1
        ORDER BY pr.penalty_type, ac.sort_order""", (award_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_penalty_rate(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    pid = data.get("id")
    fields = ["award_id","classification_id","penalty_type","multiplier",
              "description","effective_date","is_active"]
    vals = [data.get(f) for f in fields]
    if pid:
        sets = ", ".join(f"{f}=?" for f in fields)
        conn.execute(f"UPDATE award_penalty_rates SET {sets} WHERE id=?", vals + [pid])
        conn.commit(); conn.close()
        return pid
    cur = conn.execute(
        f"INSERT INTO award_penalty_rates ({','.join(fields)}) VALUES ({','.join('?'*len(fields))})",
        vals)
    new_id = cur.lastrowid
    conn.commit(); conn.close()
    return new_id


def delete_penalty_rate(db_path, penalty_id: int) -> None:
    conn = get_connection(db_path)
    conn.execute("UPDATE award_penalty_rates SET is_active=0 WHERE id=?", (penalty_id,))
    conn.commit(); conn.close()


# ── Employee pay rate resolution ──────────────────────────────────────────────

def resolve_rate_from_classification(db_path, classification_id: int,
                                      pay_point: int = 1,
                                      as_of: str = None) -> dict:
    """
    Resolve the award pay rate for a classification directly (no employee needed).
    Used for live preview in the employee dialog before saving.
    """
    as_of = as_of or str(date.today())
    conn = get_connection(db_path)
    rate_row = conn.execute("""SELECT apr.*, ac.name AS classification_name,
            a.name AS award_name
        FROM award_pay_rates apr
        JOIN award_classifications ac ON ac.id=apr.classification_id
        JOIN awards a ON a.id=ac.award_id
        WHERE apr.classification_id=? AND apr.pay_point=? AND apr.effective_date<=?
        ORDER BY apr.effective_date DESC LIMIT 1""",
        (classification_id, pay_point, as_of)).fetchone()
    conn.close()
    if not rate_row:
        return {}
    r = dict(rate_row)
    return {
        "hourly_rate":         r["hourly_rate"],
        "source":              "award_classification",
        "classification_name": r["classification_name"],
        "award_name":          r["award_name"],
        "casual_rate":         r.get("casual_rate"),
        "weekly_rate":         r.get("weekly_rate"),
        "annual_equivalent":   r.get("annual_equivalent"),
        "pay_point":           pay_point,
    }


def apply_modifier(base_hourly: float, modifier: float,
                   modifier_type: str) -> float:
    """Apply a pay modifier to a base hourly rate. Returns final hourly rate."""
    if not modifier or not base_hourly:
        return base_hourly
    if modifier_type == "%":
        return round(base_hourly * (1 + modifier / 100), 4)
    elif modifier_type == "$":
        return round(base_hourly + modifier, 4)
    return base_hourly


def resolve_employee_rate(db_path, employee_id: int,
                          as_of: str = None) -> dict:
    """
    Resolve an employee's effective hourly rate, applying any pay modifier.
    Returns dict with keys:
      hourly_rate, source, classification_name, award_name, pay_point,
      casual_rate, weekly_rate, annual_equivalent,
      base_hourly_rate, modifier, modifier_type
    """
    as_of = as_of or str(date.today())
    conn = get_connection(db_path)
    emp = conn.execute("SELECT * FROM employees WHERE id=?", (employee_id,)).fetchone()
    if not emp:
        conn.close()
        return {}
    emp = dict(emp)

    modifier      = emp.get("pay_rate_modifier") or 0
    modifier_type = emp.get("pay_rate_modifier_type") or "%"

    result = {
        "hourly_rate":         None,
        "base_hourly_rate":    None,
        "modifier":            modifier,
        "modifier_type":       modifier_type,
        "source":              "none",
        "classification_name": None,
        "award_name":          None,
        "pay_point":           emp.get("pay_point") or 1,
        "casual_rate":         None,
        "weekly_rate":         None,
        "annual_equivalent":   None,
    }

    # 1. Manual override on employee record (modifier still applied)
    if emp.get("hourly_rate"):
        base = emp["hourly_rate"]
        final = apply_modifier(base, modifier, modifier_type)
        result["base_hourly_rate"]  = base
        result["hourly_rate"]       = final
        result["source"]            = "manual_override"
        result["annual_equivalent"] = round(final * 38 * 52, 2)
        conn.close()
        return result

    # 2. Award classification rate
    if emp.get("classification_id"):
        pay_point = emp.get("pay_point") or 1
        rate_row = conn.execute("""SELECT apr.*, ac.name AS classification_name,
                a.name AS award_name
            FROM award_pay_rates apr
            JOIN award_classifications ac ON ac.id=apr.classification_id
            JOIN awards a ON a.id=ac.award_id
            WHERE apr.classification_id=? AND apr.pay_point=? AND apr.effective_date<=?
            ORDER BY apr.effective_date DESC LIMIT 1""",
            (emp["classification_id"], pay_point, as_of)).fetchone()
        if rate_row:
            rate_row = dict(rate_row)
            base  = rate_row["hourly_rate"]
            final = apply_modifier(base, modifier, modifier_type)
            result.update({
                "base_hourly_rate":    base,
                "hourly_rate":         final,
                "source":              "award_classification",
                "classification_name": rate_row["classification_name"],
                "award_name":          rate_row["award_name"],
                "casual_rate":         rate_row.get("casual_rate"),
                "weekly_rate":         rate_row.get("weekly_rate"),
                "annual_equivalent":   round(final * 38 * 52, 2),
            })
            conn.close()
            return result

    # 3. Annual salary fallback
    if emp.get("annual_salary") and emp.get("hours_per_week"):
        base  = round(emp["annual_salary"] / (emp["hours_per_week"] * 52), 4)
        final = apply_modifier(base, modifier, modifier_type)
        result["base_hourly_rate"]  = base
        result["hourly_rate"]       = final
        result["source"]            = "annual_salary"
        result["annual_equivalent"] = emp["annual_salary"]

    conn.close()
    return result


def get_employees_by_award(db_path, award_id: int) -> list:
    """Return all employees assigned to a given award."""
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT e.*, ac.name AS classification_name, ac.code AS classification_code
        FROM employees e
        LEFT JOIN award_classifications ac ON ac.id=e.classification_id
        WHERE e.award_id=? AND e.is_active=1
        ORDER BY e.last_name, e.first_name""", (award_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def bulk_apply_wage_increase(db_path, award_id: int,
                              effective_date: str,
                              increase_percent: float,
                              source_note: str = "") -> int:
    """
    Apply an annual wage review increase to all classifications in an award.
    Creates new award_pay_rates rows based on the most recent existing rate.
    Returns count of new rows created.
    """
    conn = get_connection(db_path)
    classifications = conn.execute("""SELECT id FROM award_classifications
        WHERE award_id=? AND is_active=1""", (award_id,)).fetchall()
    count = 0
    multiplier = 1 + (increase_percent / 100)
    for cls in classifications:
        cid = cls["id"]
        # Get all distinct pay points for this classification
        pay_points = conn.execute("""SELECT DISTINCT pay_point FROM award_pay_rates
            WHERE classification_id=?""", (cid,)).fetchall()
        if not pay_points:
            pay_points = [{"pay_point": 1}]
        for pp_row in pay_points:
            pp = pp_row["pay_point"]
            last = conn.execute("""SELECT * FROM award_pay_rates
                WHERE classification_id=? AND pay_point=?
                ORDER BY effective_date DESC LIMIT 1""", (cid, pp)).fetchone()
            if not last:
                continue
            last = dict(last)
            new_hourly = round(last["hourly_rate"] * multiplier, 4)
            new_weekly = round(last["weekly_rate"] * multiplier, 4) if last.get("weekly_rate") else None
            new_casual = round(last["casual_rate"] * multiplier, 4) if last.get("casual_rate") else None
            try:
                conn.execute("""INSERT OR IGNORE INTO award_pay_rates
                    (classification_id, pay_point, effective_date,
                     hourly_rate, weekly_rate, casual_rate,
                     overtime_rate_1_5, overtime_rate_2_0, source_note)
                    VALUES (?,?,?,?,?,?,?,?,?)""",
                    (cid, pp, effective_date, new_hourly, new_weekly, new_casual,
                     round(new_hourly * 1.5, 4),
                     round(new_hourly * 2.0, 4),
                     source_note or f"Wage review {increase_percent:.2f}% from {effective_date}"))
                count += 1
            except Exception:
                pass
    conn.commit(); conn.close()
    return count
