# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Stock valuation PDF renderer.
Extracted from ui/items_ui.py so web/server.py can call it without importing tkinter.
"""

from __future__ import annotations
import io


def render_stock_valuation_pdf(data: dict, db_path: str = None) -> bytes:
    """
    Render a stock valuation report as PDF bytes.

    data — output of core.inventory.stock_valuation_report()
    db_path — optional, used to fetch company details and theme for the header.
              If None the header will show a generic company name.

    Returns raw PDF bytes.
    """
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors as rl_colors
    from reportlab.lib.units import mm
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_RIGHT
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                    Table, TableStyle, HRFlowable)
    from core.invoice_pdf import (
        DEFAULT_DOC_THEME, _resolve_theme, _c, _load_doc_theme,
        _logo_image, _build_header, _build_footer, _s, WHITE, PAGE_W,
    )

    # ── Company details ────────────────────────────────────────────────────────
    co = {}
    if db_path:
        try:
            from core.database import get_connection as _gc
            conn = _gc(db_path)
            co   = dict(conn.execute("SELECT * FROM company").fetchone() or {})
            conn.close()
        except Exception:
            pass

    # ── Theme ──────────────────────────────────────────────────────────────────
    th = _resolve_theme(_load_doc_theme(co) if co else None)
    s  = _s(th)

    # Semantic status colours — not chrome, keep fixed
    GREEN = rl_colors.HexColor("#27ae60")
    AMBER = rl_colors.HexColor("#e67e22")
    RED   = rl_colors.HexColor("#e74c3c")

    NAVY  = _c(th["header_bg"])
    LTGR  = _c(th["row_alt"])
    DIM   = _c(th["dim_text"])
    RULE  = _c(th["rule_colour"])

    # ── Document ───────────────────────────────────────────────────────────────
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                            leftMargin=18*mm, rightMargin=18*mm,
                            topMargin=14*mm, bottomMargin=14*mm)
    story = []

    # ── Header ────────────────────────────────────────────────────────────────
    co_name, co_abn, co_addr, co_phone, co_email, co_web = \
        _build_header(story, co, "STOCK VALUATION REPORT", s, th)

    # Summary banner
    ban = Table([[
        Paragraph(f"<b>{data['total_items']}</b><br/>Tracked Items", s["body_b"]),
        Paragraph(f"<b>${data['total_value']:,.2f}</b><br/>Total Value",
                  ParagraphStyle("sv_rbold", fontName="Helvetica-Bold",
                                 fontSize=9, leading=13, textColor=_c(th["body_text"]),
                                 alignment=TA_RIGHT)),
    ]], colWidths=[PAGE_W * 0.5, PAGE_W * 0.5])
    ban.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, -1), LTGR),
        ("TOPPADDING",    (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING",   (0, 0), (-1, -1), 10),
        ("BOX",           (0, 0), (-1, -1), 0.5, RULE),
    ]))
    story.append(ban)
    story.append(Spacer(1, 4*mm))

    # ── Main table ─────────────────────────────────────────────────────────────
    col_w = [PAGE_W*0.10, PAGE_W*0.32, PAGE_W*0.12, PAGE_W*0.13,
             PAGE_W*0.13, PAGE_W*0.10, PAGE_W*0.10]

    def _hdr(txt):
        return Paragraph(txt, ParagraphStyle(
            "sv_hdr", fontName="Helvetica-Bold", fontSize=7.5,
            textColor=WHITE, leading=10, textTransform="uppercase"))

    def _cell(txt, align="left", bold=False, colour=None):
        st = ParagraphStyle(
            "sv_cell", fontName="Helvetica-Bold" if bold else "Helvetica",
            fontSize=8, leading=11,
            textColor=colour if colour else _c(th["body_text"]),
            alignment=TA_RIGHT if align == "right" else 0)
        return Paragraph(str(txt or ""), st)

    hdr_row = [_hdr("Code"), _hdr("Name"), _hdr("On Hand"), _hdr("Avg Cost"),
               _hdr("Total Value"), _hdr("Reorder Lvl"), _hdr("Status")]
    rows_data = [hdr_row]

    for i, row in enumerate(data["rows"]):
        qty    = row["qty_on_hand"]
        status = "OK"
        bg     = WHITE if i % 2 == 0 else LTGR
        if qty < 0:
            status = "NEGATIVE"
            bg     = rl_colors.HexColor("#fde8e8")
        elif row.get("is_low_stock"):
            status = "LOW STOCK"
            bg     = rl_colors.HexColor("#fff3cd")

        rows_data.append([
            _cell(row["code"]),
            _cell(row["name"]),
            _cell(f"{qty:,.2f}", "right"),
            _cell(f"${row['unit_cost']:,.4f}", "right"),
            _cell(f"${row['total_value']:,.2f}", "right", bold=True),
            _cell(f"{row['reorder_level']:,.2f}" if row.get("reorder_level") else "—", "right"),
            _cell(status, colour=(RED if qty < 0 else AMBER if row.get("is_low_stock") else GREEN)),
        ])

    rows_data.append([
        _cell(""), _cell("TOTAL", bold=True), _cell(""), _cell(""),
        _cell(f"${data['total_value']:,.2f}", "right", bold=True),
        _cell(""), _cell(""),
    ])

    tbl = Table(rows_data, colWidths=col_w, repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0),  (-1, 0),  NAVY),
        ("ROWBACKGROUNDS",(0, 1),  (-1, -2), [WHITE, LTGR]),
        ("BACKGROUND",    (0, -1), (-1, -1), _c(th["payment_box_bg"])),
        ("LINEABOVE",     (0, -1), (-1, -1), 1, NAVY),
        ("TOPPADDING",    (0, 0),  (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0),  (-1, -1), 4),
        ("LEFTPADDING",   (0, 0),  (-1, -1), 5),
        ("RIGHTPADDING",  (0, 0),  (-1, -1), 5),
        ("BOX",           (0, 0),  (-1, -1), 0.5, RULE),
        ("INNERGRID",     (0, 0),  (-1, -1), 0.25, RULE),
    ]))
    story.append(tbl)

    # ── Footer ────────────────────────────────────────────────────────────────
    _build_footer(story, co_name, co_abn, co_email, co_phone,
                  f"Stock Valuation Report  —  As at {data['as_at']}", th, s)

    doc.build(story)
    return buf.getvalue()
