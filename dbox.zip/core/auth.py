"""
dbox - Authentication and User Management
Password hashing, user CRUD, and session authentication.
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import hashlib
import secrets

from core.database import get_connection


# ── Password hashing: PBKDF2-SHA256 (260k iterations) + timing-safe compare ──
# Format v2: pbkdf2:<salt_hex>:<hash_hex>   (new)
# Format v1: <salt_hex>:<sha256_hex>         (legacy, auto-upgraded on login)

_PBKDF2_ITERS = 260_000


def _hash_password(password: str, salt: str = None) -> str:
    if salt is None:
        salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), _PBKDF2_ITERS)
    return f"pbkdf2:{salt}:{dk.hex()}"


def _hash_password_legacy(password: str, salt: str) -> str:
    return hashlib.sha256(f"{salt}{password}".encode()).hexdigest()


def verify_password(password: str, stored: str) -> bool:
    """Timing-safe verify. Supports legacy SHA-256 (v1) and PBKDF2 (v2)."""
    import hmac
    if stored.startswith("pbkdf2:"):
        _, salt, expected = stored.split(":", 2)
        dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), _PBKDF2_ITERS)
        return hmac.compare_digest(dk.hex(), expected)
    else:
        if ":" not in stored:
            return False
        salt, expected = stored.split(":", 1)
        actual = _hash_password_legacy(password, salt)
        return hmac.compare_digest(actual, expected)


# ── User CRUD ─────────────────────────────────────────────────────────────────

def get_users(db_path, active_only=True):
    conn = get_connection(db_path)
    q = "SELECT id,username,display_name,role,is_active,created_at,last_login FROM users"
    if active_only:
        q += " WHERE is_active=1"
    rows = conn.execute(q + " ORDER BY username").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_user(db_path, user_id):
    conn = get_connection(db_path)
    row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_user_by_username(db_path, username):
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT * FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone()
    conn.close()
    return dict(row) if row else None


def create_user(db_path, username, display_name, password, role="Staff"):
    """Returns new user id, or raises ValueError on duplicate username."""
    if get_user_by_username(db_path, username):
        raise ValueError(f"Username '{username}' already exists")
    stored = _hash_password(password)
    conn = get_connection(db_path)
    conn.execute("""INSERT INTO users (username,display_name,password_hash,role)
        VALUES (?,?,?,?)""", (username, display_name, stored, role))
    uid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit(); conn.close()
    return uid


def update_user(db_path, user_id, display_name=None, role=None,
                is_active=None, new_password=None):
    conn = get_connection(db_path)
    if display_name is not None:
        conn.execute("UPDATE users SET display_name=? WHERE id=?",
                     (display_name, user_id))
    if role is not None:
        conn.execute("UPDATE users SET role=? WHERE id=?", (role, user_id))
    if is_active is not None:
        conn.execute("UPDATE users SET is_active=? WHERE id=?",
                     (1 if is_active else 0, user_id))
    if new_password is not None:
        conn.execute("UPDATE users SET password_hash=? WHERE id=?",
                     (_hash_password(new_password), user_id))
    conn.commit(); conn.close()


def authenticate_user(db_path, username, password):
    """Returns user dict on success, None on failure. Auto-upgrades legacy hashes."""
    user = get_user_by_username(db_path, username)
    if not user or not user["is_active"]:
        return None
    stored = user["password_hash"]
    if not stored or ":" not in stored:
        return None
    if not verify_password(password, stored):
        return None
    conn = get_connection(db_path)
    if not stored.startswith("pbkdf2:"):
        new_hash = _hash_password(password)
        conn.execute("UPDATE users SET password_hash=? WHERE id=?", (new_hash, user["id"]))
    conn.execute("UPDATE users SET last_login=datetime('now','localtime') WHERE id=?",
                 (user["id"],))
    conn.commit(); conn.close()
    return user


def has_any_users(db_path):
    conn = get_connection(db_path)
    n = conn.execute("SELECT COUNT(*) FROM users WHERE is_active=1").fetchone()[0]
    conn.close()
    return n > 0


def ensure_default_admin(db_path):
    """Create default admin if no users exist."""
    if not has_any_users(db_path):
        uid = create_user(db_path, "admin", "Administrator", "admin", role="Admin")
        conn = get_connection(db_path)
        conn.execute("UPDATE users SET force_password_change=1 WHERE id=?", (uid,))
        conn.commit(); conn.close()
        return True
    return False


def set_own_password(db_path, user_id, new_password):
    """Change a user's own password and clear any force_password_change flag."""
    conn = get_connection(db_path)
    conn.execute(
        "UPDATE users SET password_hash=?, force_password_change=0 WHERE id=?",
        (_hash_password(new_password), user_id),
    )
    conn.commit(); conn.close()
