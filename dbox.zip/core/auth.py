# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
dbox - Authentication and User Management
Password hashing, user CRUD, and session authentication.
"""

import hashlib
import secrets

from core.database import get_connection


# ── Role-based module access ───────────────────────────────────────────────────
# None = unrestricted (Admin / legacy Staff). frozenset = allowed module keys.
ROLE_MODULES: dict = {
    "Admin":  None,
    "Staff":  None,  # legacy — treat as unrestricted until admin reassigns role
    "Accountant": frozenset({
        "dashboard", "contacts", "accounts", "journal", "payments",
        "bankrec", "reports", "invoices", "bills", "credit_cards",
        "budget", "recurring", "fixed_assets", "petty_cash", "expense_claims",
        "items", "warranties", "purchase_orders",
    }),
    "Trades": frozenset({
        "dashboard", "contacts", "invoices", "bills", "payments", "bankrec",
        "jobs", "quotes", "schedule", "purchase_orders", "warranties", "items",
        "expense_claims",
    }),
    "Retail": frozenset({
        "dashboard", "contacts", "invoices", "bills", "payments",
        "pos", "table_service", "inventory", "items", "expense_claims",
    }),
    "ReadOnly": frozenset({
        "dashboard", "contacts", "reports", "invoices", "bills",
    }),
}

# ── Password hashing: PBKDF2-SHA256 (260k iterations) + timing-safe compare ──
# Format v2: pbkdf2:<salt_hex>:<hash_hex>   (new)
# Format v1: <salt_hex>:<sha256_hex>         (legacy, auto-upgraded on login)

_PBKDF2_ITERS = 260_000


def _hash_password(password: str, salt: str = None) -> str:
    if salt is None:
        salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), _PBKDF2_ITERS)
    return f"pbkdf2:{salt}:{dk.hex()}"


def _hash_password_legacy(password: str, salt: str) -> str:
    return hashlib.sha256(f"{salt}{password}".encode()).hexdigest()


def verify_password(password: str, stored: str) -> bool:
    """Timing-safe verify. Supports legacy SHA-256 (v1) and PBKDF2 (v2)."""
    import hmac
    if stored.startswith("pbkdf2:"):
        _, salt, expected = stored.split(":", 2)
        dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), _PBKDF2_ITERS)
        return hmac.compare_digest(dk.hex(), expected)
    else:
        if ":" not in stored:
            return False
        salt, expected = stored.split(":", 1)
        actual = _hash_password_legacy(password, salt)
        return hmac.compare_digest(actual, expected)


# ── User CRUD ─────────────────────────────────────────────────────────────────

def _ensure_pos_pin_column(conn):
    try:
        conn.execute("ALTER TABLE users ADD COLUMN pos_pin_hash TEXT")
        conn.commit()
    except Exception:
        pass


def get_users(db_path, active_only=True):
    conn = get_connection(db_path)
    _ensure_pos_pin_column(conn)
    q = ("SELECT id,username,display_name,role,is_active,created_at,last_login,"
         "pos_pin_hash IS NOT NULL AS has_pos_pin FROM users")
    if active_only:
        q += " WHERE is_active=1"
    rows = conn.execute(q + " ORDER BY username").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_user(db_path, user_id):
    conn = get_connection(db_path)
    row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_user_by_username(db_path, username):
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT * FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone()
    conn.close()
    return dict(row) if row else None


def create_user(db_path, username, display_name, password, role="Staff"):
    """Returns new user id, or raises ValueError on duplicate username."""
    if get_user_by_username(db_path, username):
        raise ValueError(f"Username '{username}' already exists")
    stored = _hash_password(password)
    conn = get_connection(db_path)
    conn.execute("""INSERT INTO users (username,display_name,password_hash,role)
        VALUES (?,?,?,?)""", (username, display_name, stored, role))
    uid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit(); conn.close()
    return uid


def update_user(db_path, user_id, display_name=None, role=None,
                is_active=None, new_password=None):
    conn = get_connection(db_path)
    if display_name is not None:
        conn.execute("UPDATE users SET display_name=? WHERE id=?",
                     (display_name, user_id))
    if role is not None:
        conn.execute("UPDATE users SET role=? WHERE id=?", (role, user_id))
    if is_active is not None:
        conn.execute("UPDATE users SET is_active=? WHERE id=?",
                     (1 if is_active else 0, user_id))
    if new_password is not None:
        conn.execute("UPDATE users SET password_hash=? WHERE id=?",
                     (_hash_password(new_password), user_id))
    conn.commit(); conn.close()


def authenticate_user(db_path, username, password):
    """Returns user dict on success, None on failure. Auto-upgrades legacy hashes."""
    user = get_user_by_username(db_path, username)
    if not user or not user["is_active"]:
        return None
    stored = user["password_hash"]
    if not stored or ":" not in stored:
        return None
    if not verify_password(password, stored):
        return None
    conn = get_connection(db_path)
    if not stored.startswith("pbkdf2:"):
        new_hash = _hash_password(password)
        conn.execute("UPDATE users SET password_hash=? WHERE id=?", (new_hash, user["id"]))
    conn.execute("UPDATE users SET last_login=datetime('now','localtime') WHERE id=?",
                 (user["id"],))
    conn.commit(); conn.close()
    return user


def has_any_users(db_path):
    conn = get_connection(db_path)
    n = conn.execute("SELECT COUNT(*) FROM users WHERE is_active=1").fetchone()[0]
    conn.close()
    return n > 0


def ensure_default_admin(db_path):
    """Create default admin if no users exist."""
    if not has_any_users(db_path):
        uid = create_user(db_path, "admin", "Administrator", "admin", role="Admin")
        conn = get_connection(db_path)
        conn.execute("UPDATE users SET force_password_change=1 WHERE id=?", (uid,))
        conn.commit(); conn.close()
        return True
    return False


def set_own_password(db_path, user_id, new_password):
    """Change a user's own password and clear any force_password_change flag."""
    conn = get_connection(db_path)
    conn.execute(
        "UPDATE users SET password_hash=?, force_password_change=0 WHERE id=?",
        (_hash_password(new_password), user_id),
    )
    conn.commit(); conn.close()


# ── POS PIN management ────────────────────────────────────────────────────────

def set_pos_pin(db_path, user_id: int, pin: str):
    """Set a 4-6 digit numeric PIN for POS register sign-on."""
    pin = pin.strip()
    if not pin.isdigit() or not (4 <= len(pin) <= 6):
        raise ValueError("PIN must be 4–6 digits")
    conn = get_connection(db_path)
    _ensure_pos_pin_column(conn)
    conn.execute("UPDATE users SET pos_pin_hash=? WHERE id=?",
                 (_hash_password(pin), user_id))
    conn.commit(); conn.close()


def clear_pos_pin(db_path, user_id: int):
    """Remove a user's POS PIN."""
    conn = get_connection(db_path)
    _ensure_pos_pin_column(conn)
    conn.execute("UPDATE users SET pos_pin_hash=NULL WHERE id=?", (user_id,))
    conn.commit(); conn.close()


def get_pos_users(db_path) -> list:
    """Return active users with their POS PIN status."""
    conn = get_connection(db_path)
    _ensure_pos_pin_column(conn)
    rows = conn.execute(
        "SELECT id, display_name, pos_pin_hash IS NOT NULL AS has_pin "
        "FROM users WHERE is_active=1 ORDER BY display_name"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def authenticate_pos_pin(db_path, pin: str):
    """Verify a POS PIN against all active users. Returns user dict or None."""
    pin = (pin or "").strip()
    if not pin:
        return None
    conn = get_connection(db_path)
    _ensure_pos_pin_column(conn)
    rows = conn.execute(
        "SELECT id, display_name, pos_pin_hash FROM users "
        "WHERE is_active=1 AND pos_pin_hash IS NOT NULL"
    ).fetchall()
    conn.close()
    for row in rows:
        if row["pos_pin_hash"] and verify_password(pin, row["pos_pin_hash"]):
            return {"id": row["id"], "display_name": row["display_name"]}
    return None
