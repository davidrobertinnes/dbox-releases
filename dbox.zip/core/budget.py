"""
dbox - Budget Manager
Create, edit, import/export budgets. Generate Actual vs Budget reports.
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.


import csv
import io
import os
from datetime import date, datetime
from core.database import get_connection

# Auth and user management live in core/auth.py — re-exported for backward compat
from core.auth import (
    verify_password, get_users, get_user, get_user_by_username,
    create_user, update_user, authenticate_user, has_any_users,
    ensure_default_admin, set_own_password,
)


# ══════════════════════════════════════════════════════════════════════════════
# AUDIT LOG
# ══════════════════════════════════════════════════════════════════════════════

def audit(db_path, user_id, username, action, target_type=None,
          target_id=None, detail=None):
    try:
        conn = get_connection(db_path)
        conn.execute("""INSERT INTO audit_log
            (user_id,username,action,target_type,target_id,detail)
            VALUES (?,?,?,?,?,?)""",
            (user_id, username, action, target_type, target_id, detail))
        conn.commit(); conn.close()
    except Exception:
        pass


def get_audit_log(db_path, limit=200):
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT * FROM audit_log
        ORDER BY logged_at DESC LIMIT ?""", (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ══════════════════════════════════════════════════════════════════════════════
# BUDGET MANAGEMENT
# ══════════════════════════════════════════════════════════════════════════════

MONTH_NAMES = ["Jan","Feb","Mar","Apr","May","Jun",
               "Jul","Aug","Sep","Oct","Nov","Dec"]


def get_budget_periods(db_path):
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT * FROM budget_periods ORDER BY fy_year DESC, name""").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_budget_period(db_path, period_id):
    conn = get_connection(db_path)
    row = conn.execute("SELECT * FROM budget_periods WHERE id=?", (period_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def create_budget_period(db_path, name, fy_year, period_type="Annual",
                          start_date=None, end_date=None, created_by=None):
    if start_date is None:
        start_date = f"{fy_year-1}-07-01"
    if end_date is None:
        end_date = f"{fy_year}-06-30"
    conn = get_connection(db_path)
    conn.execute("""INSERT INTO budget_periods
        (name,period_type,fy_year,start_date,end_date,created_by)
        VALUES (?,?,?,?,?,?)""",
        (name, period_type, fy_year, start_date, end_date, created_by))
    pid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit(); conn.close()
    return pid


def get_budget_lines(db_path, period_id):
    """Returns {account_id: {month: amount}} and account details."""
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT bl.*, a.code, a.name, a.account_type, a.account_subtype as subtype
        FROM budget_lines bl JOIN accounts a ON bl.account_id=a.id
        WHERE bl.period_id=?
        ORDER BY a.code, bl.month""", (period_id,)).fetchall()
    conn.close()
    result = {}
    for r in rows:
        r = dict(r)
        aid = r["account_id"]
        if aid not in result:
            result[aid] = {
                "account_id": aid, "code": r["code"],
                "name": r["name"], "account_type": r["account_type"],
                "subtype": r["subtype"],
                "months": {m: 0.0 for m in range(1, 13)}
            }
        result[aid]["months"][r["month"]] = r["amount"]
    return list(result.values())


def save_budget_lines(db_path, period_id, lines):
    """
    lines = list of {account_id, month, amount}
    Upserts all lines, deletes zeros to keep table clean.
    """
    conn = get_connection(db_path)
    for l in lines:
        amt = float(l.get("amount", 0) or 0)
        if amt == 0:
            conn.execute("""DELETE FROM budget_lines
                WHERE period_id=? AND account_id=? AND month=?""",
                (period_id, l["account_id"], l["month"]))
        else:
            conn.execute("""INSERT INTO budget_lines
                (period_id,account_id,month,amount)
                VALUES (?,?,?,?)
                ON CONFLICT(period_id,account_id,month)
                DO UPDATE SET amount=excluded.amount""",
                (period_id, l["account_id"], l["month"], amt))
    conn.commit(); conn.close()


def delete_budget_period(db_path, period_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM budget_lines WHERE period_id=?", (period_id,))
    conn.execute("DELETE FROM budget_periods WHERE id=?", (period_id,))
    conn.commit(); conn.close()


# ── CSV Template ──────────────────────────────────────────────────────────────

def generate_budget_csv_template(db_path, period_id=None):
    """
    Generate a CSV template string.
    Columns: Account Code, Account Name, Type, Jan, Feb, ..., Dec, Annual Total
    """
    from core.ledger import get_accounts
    accounts = [a for a in get_accounts(db_path)
                if a["account_type"] in ("Revenue","Income","Expense","Cost of Sales")]
    accounts.sort(key=lambda a: a["code"])

    # Load existing budget if period given
    existing = {}
    if period_id:
        for line in get_budget_lines(db_path, period_id):
            existing[line["account_id"]] = line["months"]

    buf = io.StringIO()
    w = csv.writer(buf)
    header = ["Account Code", "Account Name", "Type"] + MONTH_NAMES + ["Annual Total"]
    w.writerow(header)

    for acc in accounts:
        months = existing.get(acc["id"], {m: 0.0 for m in range(1, 13)})
        row = [acc["code"], acc["name"], acc["account_type"]]
        row += [f"{months.get(m, 0):.2f}" for m in range(1, 13)]
        row.append(f"{sum(months.get(m,0) for m in range(1,13)):.2f}")
        w.writerow(row)

    return buf.getvalue()


def import_budget_csv(db_path, period_id, csv_content):
    """
    Parse CSV content and save budget lines.
    Returns (lines_imported, errors_list).
    """
    from core.ledger import get_accounts
    accounts = get_accounts(db_path)
    acc_by_code = {a["code"]: a for a in accounts}

    reader = csv.DictReader(io.StringIO(csv_content))
    lines = []
    errors = []

    for i, row in enumerate(reader, 2):
        code = (row.get("Account Code") or "").strip()
        if not code:
            continue
        acc = acc_by_code.get(code)
        if not acc:
            errors.append(f"Row {i}: Account code '{code}' not found")
            continue
        for m, mname in enumerate(MONTH_NAMES, 1):
            val_str = (row.get(mname) or "0").strip()
            try:
                val = float(val_str)
            except ValueError:
                errors.append(f"Row {i} {mname}: '{val_str}' is not a number")
                val = 0.0
            lines.append({"account_id": acc["id"], "month": m, "amount": val})

    if not errors:
        save_budget_lines(db_path, period_id, lines)
    return len(lines) // 12, errors


# ── Actual vs Budget Report ────────────────────────────────────────────────────

def get_actuals_by_account_month(db_path, start_date, end_date):
    """
    Returns {account_id: {month_int: actual_amount}}
    Based on posted journal lines within the date range.
    Only Revenue & Expense account types.
    """
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT a.id as account_id, a.account_type,
               CAST(strftime('%m', je.entry_date) AS INTEGER) as month,
               SUM(jl.credit - jl.debit) as net_amount
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id=je.id
        JOIN accounts a ON jl.account_id=a.id
        WHERE je.entry_date BETWEEN ? AND ?
          AND a.account_type IN ('Revenue','Income','Cost of Sales','Expense')
        GROUP BY a.id, month
        ORDER BY a.id, month""",
        (start_date, end_date)).fetchall()
    conn.close()

    result = {}
    for r in rows:
        aid = r["account_id"]
        if aid not in result:
            result[aid] = {}
        # For Revenue: credit > debit = positive income
        # For Expense: debit > credit = positive cost → we negate
        amt = r["net_amount"] or 0.0
        if r["account_type"] in ("Expense", "Cost of Sales"):
            amt = -amt
        result[aid][r["month"]] = amt
    return result


def _calendar_months_in_range(date_from, date_to):
    """
    Returns the set of calendar month numbers (1–12) that appear within
    date_from..date_to. If the span covers ≥12 months, returns all months.
    """
    try:
        from datetime import date as _d
        d1 = _d.fromisoformat(date_from)
        d2 = _d.fromisoformat(date_to)
    except Exception:
        return set(range(1, 13))
    months = set()
    y, m = d1.year, d1.month
    while (y < d2.year) or (y == d2.year and m <= d2.month):
        months.add(m)
        if len(months) == 12:
            return set(range(1, 13))
        m += 1
        if m > 12:
            m = 1; y += 1
    return months


def build_actual_vs_budget_report(db_path, period_id, date_from=None, date_to=None):
    """
    Returns a list of report rows.
    Each row: {account_id, code, name, type, months:{m: {budget,actual,variance}}, totals}
    date_from/date_to filter both actuals and the budget months included in totals
    so the two figures are always comparable.
    """
    period = get_budget_period(db_path, period_id)
    if not period:
        return [], None

    budget_lines = get_budget_lines(db_path, period_id)
    actual_from = date_from or period["start_date"]
    actual_to   = date_to   or period["end_date"]
    actuals = get_actuals_by_account_month(db_path, actual_from, actual_to)

    included_months = _calendar_months_in_range(actual_from, actual_to)

    # Build set of all account IDs in budget OR actuals
    from core.ledger import get_accounts
    budget_accs = {bl["account_id"]: bl for bl in budget_lines}

    # Add actuals-only accounts
    all_acc_ids = set(budget_accs.keys()) | set(actuals.keys())
    if not all_acc_ids:
        return [], period

    conn = get_connection(db_path)
    acc_rows = conn.execute(
        f"SELECT * FROM accounts WHERE id IN ({','.join('?'*len(all_acc_ids))})",
        list(all_acc_ids)).fetchall()
    conn.close()
    acc_map = {a["id"]: dict(a) for a in acc_rows}

    report = []
    for aid in sorted(all_acc_ids, key=lambda x: acc_map.get(x,{}).get("code","")):
        acc = acc_map.get(aid, {})
        if not acc:
            continue
        if acc.get("account_type") not in ("Revenue","Income","Cost of Sales","Expense"):
            continue

        bline = budget_accs.get(aid, {})
        bmonths = bline.get("months", {m: 0.0 for m in range(1,13)})
        amonths = actuals.get(aid, {})

        months = {}
        for m in range(1, 13):
            bud = float(bmonths.get(m, 0)) if m in included_months else 0.0
            act = float(amonths.get(m, 0))
            var = act - bud
            var_pct = ((act / bud - 1) * 100) if bud != 0 else (100.0 if act > 0 else 0.0)
            months[m] = {"budget": bud, "actual": act,
                         "variance": var, "variance_pct": var_pct}

        total_bud = sum(months[m]["budget"]  for m in range(1,13))
        total_act = sum(months[m]["actual"]  for m in range(1,13))
        total_var = total_act - total_bud
        total_pct = ((total_act/total_bud - 1)*100) if total_bud != 0 else (
                     100.0 if total_act > 0 else 0.0)

        report.append({
            "account_id":   aid,
            "code":         acc.get("code",""),
            "name":         acc.get("name",""),
            "account_type": acc.get("account_type",""),
            "months":       months,
            "total_budget": total_bud,
            "total_actual": total_act,
            "total_variance": total_var,
            "total_variance_pct": total_pct,
        })

    return report, period
