# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Accounting — Bank statement matching (Xero-style)

Links an imported bank statement line (bank_transactions) to ledger lines
already in dbox (journal_lines on the same bank account), e.g. an invoice
receipt, a bill payment, POS banking or a pay run. Nothing is posted:
matching only records the link, so the same money isn't entered twice.

One statement line can match several ledger lines (a deposit that banks
several receipts). A ledger line can belong to only one statement line.

Matching mirrors allocation (core.ledger.allocate_bank_transaction): the
statement line is marked done (is_reconciled=1, alloc_mode='match'); the
ledger lines are reconciled when the period is finalised.

Sign convention — "effect on the account balance", positive = balance goes up:
  statement line (asset or liability): credit - debit
      asset: credit = money in; liability: credit = charge (owed goes up)
  ledger line: asset debit - credit; liability credit - debit
"""

from datetime import date, timedelta

from core.database import get_connection

# How far a ledger date may sit from the statement date and still be suggested.
# Payments usually clear after they're recorded, so look further back.
_DAYS_BEFORE = 45
_DAYS_AFTER  = 10
# Deposits combining several receipts: receipts dated up to this many days earlier.
_COMBO_DAYS_BEFORE = 14
_COMBO_MAX_LINES   = 6
_COMBO_POOL        = 20
_COMBO_MAX_STEPS   = 20000

CONF_AUTO = 85   # a suggestion this strong, clearly ahead of the next, can be auto-accepted
CONF_SHOW = 50


def migrate_bank_matches(conn):
    """Create the bank_matches link table and its clean-up trigger."""
    conn.execute("""CREATE TABLE IF NOT EXISTS bank_matches (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        bank_txn_id     INTEGER NOT NULL REFERENCES bank_transactions(id) ON DELETE CASCADE,
        journal_line_id INTEGER NOT NULL UNIQUE REFERENCES journal_lines(id) ON DELETE CASCADE,
        matched_at      TEXT DEFAULT (datetime('now','localtime')))""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_bank_matches_txn ON bank_matches(bank_txn_id)")
    # If a matched ledger line is deleted (payment deleted or re-posted), and it
    # was the statement line's last link, put the statement line back to
    # unmatched so it shows up to be dealt with again.
    conn.execute("""CREATE TRIGGER IF NOT EXISTS trg_bank_matches_orphan
        AFTER DELETE ON bank_matches
        WHEN NOT EXISTS (SELECT 1 FROM bank_matches WHERE bank_txn_id = OLD.bank_txn_id)
        BEGIN
            UPDATE bank_transactions
               SET is_reconciled = 0, reconciled_date = NULL, alloc_mode = NULL
             WHERE id = OLD.bank_txn_id AND alloc_mode = 'match' AND journal_id IS NULL;
        END""")
    conn.commit()


# ── Helpers ───────────────────────────────────────────────────────────────────

def _is_liability(conn, account_id):
    row = conn.execute("SELECT account_type FROM accounts WHERE id=?", (account_id,)).fetchone()
    if not row:
        raise ValueError(f"Account {account_id} not found")
    return row["account_type"] == "Liability"


def statement_amount(txn):
    """Signed effect of a statement line on the account balance."""
    return round(float(txn["credit"] or 0) - float(txn["debit"] or 0), 2)


def ledger_amount(line, is_liability):
    """Signed effect of a ledger line on the account balance."""
    d, c = float(line["debit"] or 0), float(line["credit"] or 0)
    return round((c - d) if is_liability else (d - c), 2)


def _words(*texts):
    out = set()
    for t in texts:
        for w in (t or "").lower().replace("-", " ").replace("/", " ").split():
            w = w.strip(".,:;#()")
            if len(w) > 2 and not w.replace(".", "").isdigit():
                out.add(w)
    return out


def _days_between(a, b):
    try:
        return (date.fromisoformat(a) - date.fromisoformat(b)).days
    except (TypeError, ValueError):
        return 999


# ── Queries ───────────────────────────────────────────────────────────────────

def get_unmatched_ledger_lines(db_path, account_id, conn=None):
    """Ledger lines on the account that a statement line could still match.

    Excludes lines that are rejected, already reconciled in a past period,
    already matched, or that were created by allocating a statement line.
    """
    own = conn is None
    conn = conn or get_connection(db_path)
    try:
        liab = _is_liability(conn, account_id)
        rows = conn.execute("""
            SELECT jl.id, jl.debit, jl.credit, je.entry_date AS date,
                   COALESCE(NULLIF(jl.description, ''), je.description, '') AS description,
                   COALESCE(je.reference, '') AS reference,
                   je.source_type, je.id AS journal_id,
                   COALESCE(c1.name, c2.name, '') AS contact_name
            FROM journal_lines jl
            JOIN journal_entries je ON je.id = jl.journal_id
            LEFT JOIN contacts c1 ON c1.id = jl.contact_id
            LEFT JOIN payments p  ON p.journal_id = je.id
            LEFT JOIN contacts c2 ON c2.id = p.contact_id
            WHERE jl.account_id = ?
              AND COALESCE(jl.is_rejected, 0) = 0
              AND COALESCE(jl.is_reconciled, 0) = 0
              AND jl.id NOT IN (SELECT journal_line_id FROM bank_matches)
              AND je.id NOT IN (SELECT journal_id FROM bank_transactions
                                WHERE journal_id IS NOT NULL AND account_id = ?)
            GROUP BY jl.id
            ORDER BY je.entry_date, jl.id
        """, (account_id, account_id)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["amount"] = ledger_amount(r, liab)
            if abs(d["amount"]) >= 0.005:
                out.append(d)
        return out
    finally:
        if own:
            conn.close()


def get_unmatched_statement_lines(db_path, account_id, conn=None):
    """Statement lines not yet matched, allocated or rejected."""
    own = conn is None
    conn = conn or get_connection(db_path)
    try:
        rows = conn.execute("""
            SELECT * FROM bank_transactions
            WHERE account_id = ? AND journal_id IS NULL
              AND COALESCE(is_reconciled, 0) = 0
              AND COALESCE(is_rejected, 0) = 0
              AND alloc_mode IS NULL
            ORDER BY transaction_date, id
        """, (account_id,)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["amount"] = statement_amount(r)
            out.append(d)
        return out
    finally:
        if own:
            conn.close()


def get_matches(db_path, bank_txn_id):
    """Ledger lines matched to a statement line."""
    conn = get_connection(db_path)
    try:
        rows = conn.execute("""
            SELECT jl.id, jl.debit, jl.credit, je.entry_date AS date,
                   COALESCE(NULLIF(jl.description, ''), je.description, '') AS description,
                   COALESCE(je.reference, '') AS reference
            FROM bank_matches m
            JOIN journal_lines jl ON jl.id = m.journal_line_id
            JOIN journal_entries je ON je.id = jl.journal_id
            WHERE m.bank_txn_id = ?
            ORDER BY je.entry_date, jl.id
        """, (bank_txn_id,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ── Match / unmatch ───────────────────────────────────────────────────────────

def match_statement_line(db_path, bank_txn_id, journal_line_ids):
    """Link a statement line to one or more existing ledger lines.

    The ledger lines must be on the same account, still unmatched, and add up
    to the statement amount to the cent. Raises ValueError otherwise.
    """
    ids = [int(i) for i in (journal_line_ids or [])]
    if not ids:
        raise ValueError("Choose at least one transaction to match")
    if len(set(ids)) != len(ids):
        raise ValueError("The same transaction was chosen twice")

    conn = get_connection(db_path)
    try:
        txn = conn.execute("SELECT * FROM bank_transactions WHERE id=?",
                           (bank_txn_id,)).fetchone()
        if not txn:
            raise ValueError(f"Bank statement line {bank_txn_id} not found")
        if txn["journal_id"] or txn["alloc_mode"] or txn["is_reconciled"]:
            raise ValueError("This statement line is already dealt with — undo it first")
        if txn["is_rejected"]:
            raise ValueError("This statement line is rejected — unreject it first")

        acc_id = txn["account_id"]
        available = {l["id"]: l for l in get_unmatched_ledger_lines(db_path, acc_id, conn)}
        missing = [i for i in ids if i not in available]
        if missing:
            raise ValueError("Some of the chosen transactions aren't available to match "
                             "(already matched or reconciled, or on another account)")

        total = round(sum(available[i]["amount"] for i in ids), 2)
        want  = statement_amount(txn)
        if abs(total - want) >= 0.005:
            raise ValueError(f"The chosen transactions total {total:,.2f} but the statement "
                             f"line is {want:,.2f}")

        for i in ids:
            conn.execute("INSERT INTO bank_matches (bank_txn_id, journal_line_id) VALUES (?,?)",
                         (bank_txn_id, i))
        conn.execute("""UPDATE bank_transactions
            SET is_reconciled=1, reconciled_date=?, alloc_mode='match'
            WHERE id=?""", (str(date.today()), bank_txn_id))
        # Receipts on the statement line go to the matched transaction, if it's one
        # entry; matched to several, they stay on the statement line.
        jids = {r[0] for r in conn.execute(
            f"SELECT DISTINCT journal_id FROM journal_lines WHERE id IN ({','.join('?' * len(ids))})", ids)}
        if len(jids) == 1:
            from core.attachments import move_attachments
            move_attachments(conn, "bank_txn", bank_txn_id, "journal", jids.pop())
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def unmatch_statement_line(db_path, bank_txn_id):
    """Remove a statement line's matches. The ledger lines are left untouched."""
    conn = get_connection(db_path)
    try:
        txn = conn.execute("SELECT * FROM bank_transactions WHERE id=?",
                           (bank_txn_id,)).fetchone()
        if not txn:
            raise ValueError(f"Bank statement line {bank_txn_id} not found")
        if txn["alloc_mode"] != "match":
            raise ValueError("This statement line isn't matched")
        conn.execute("DELETE FROM bank_matches WHERE bank_txn_id=?", (bank_txn_id,))
        conn.execute("""UPDATE bank_transactions
            SET is_reconciled=0, reconciled_date=NULL, alloc_mode=NULL
            WHERE id=?""", (bank_txn_id,))
        conn.commit()
    finally:
        conn.close()


# ── Suggestions ───────────────────────────────────────────────────────────────

def _score_single(stmt, line, stmt_words):
    days = _days_between(line["date"], stmt["transaction_date"])  # negative = ledger earlier
    if days < -_DAYS_BEFORE or days > _DAYS_AFTER:
        return 0
    s = 60
    ad = abs(days)
    if ad == 0:
        s += 30
    elif ad <= 3:
        s += 20
    elif ad <= 7:
        s += 10
    elif ad <= 14:
        s += 5
    hits = len(stmt_words & _words(line["description"], line["reference"], line["contact_name"]))
    if hits:
        s += min(10, hits * 4)
    return min(s, 100)


def _find_combo(target, pool):
    """Find 2.._COMBO_MAX_LINES lines from pool summing exactly to target.
    pool: lines with the same sign as target. Returns a list of lines or None."""
    cents = int(round(abs(target) * 100))
    items = sorted(pool, key=lambda l: -abs(l["amount"]))
    vals  = [int(round(abs(l["amount"]) * 100)) for l in items]
    steps = 0
    pick  = []

    def dfs(start, remaining):
        nonlocal steps
        steps += 1
        if steps > _COMBO_MAX_STEPS:
            return False
        if remaining == 0:
            return len(pick) >= 2
        if len(pick) >= _COMBO_MAX_LINES:
            return False
        for i in range(start, len(items)):
            if vals[i] > remaining:
                continue
            pick.append(i)
            if dfs(i + 1, remaining - vals[i]):
                return True
            pick.pop()
        return False

    return [items[i] for i in pick] if dfs(0, cents) else None


def suggest_matches(db_path, account_id):
    """Suggest ledger matches for every unmatched statement line on the account.

    Returns a list, one entry per statement line that has at least one
    suggestion:
      { bank_txn_id, amount, auto, candidates: [
          { journal_line_ids, score, kind: "single" | "combined", lines: [...] } ] }
    `auto` is True when the top candidate is strong, clearly ahead of the
    next, and not the top pick for any other statement line, so a UI may
    accept it without asking.
    """
    conn = get_connection(db_path)
    try:
        stmts  = get_unmatched_statement_lines(db_path, account_id, conn)
        ledger = get_unmatched_ledger_lines(db_path, account_id, conn)
    finally:
        conn.close()

    by_amount = {}
    for l in ledger:
        by_amount.setdefault(l["amount"], []).append(l)

    results = []
    for st in stmts:
        amt = st["amount"]
        if abs(amt) < 0.005:
            continue
        sw = _words(st.get("description"), st.get("reference"))
        cands = []
        for l in by_amount.get(amt, []):
            sc = _score_single(st, l, sw)
            if sc >= CONF_SHOW:
                cands.append({"journal_line_ids": [l["id"]], "score": sc,
                              "kind": "single", "lines": [l]})
        cands.sort(key=lambda c: (-c["score"], c["lines"][0]["date"]))

        if not cands:
            pool = [l for l in ledger
                    if (l["amount"] > 0) == (amt > 0)
                    and abs(l["amount"]) < abs(amt)
                    and -_COMBO_DAYS_BEFORE <= _days_between(l["date"], st["transaction_date"]) <= 0]
            pool.sort(key=lambda l: abs(_days_between(l["date"], st["transaction_date"])))
            combo = _find_combo(amt, pool[:_COMBO_POOL])
            if combo:
                cands.append({"journal_line_ids": [l["id"] for l in combo], "score": 55,
                              "kind": "combined",
                              "lines": sorted(combo, key=lambda l: (l["date"], l["id"]))})

        if cands:
            results.append({"bank_txn_id": st["id"], "amount": amt,
                            "auto": False, "candidates": cands[:3]})

    # Auto-accept only unambiguous picks: strong, well ahead of the runner-up,
    # and no other statement line wants the same ledger line as its top pick.
    top_users = {}
    for r in results:
        for lid in r["candidates"][0]["journal_line_ids"]:
            top_users[lid] = top_users.get(lid, 0) + 1
    for r in results:
        c = r["candidates"]
        top = c[0]
        clear = len(c) == 1 or top["score"] - c[1]["score"] >= 20
        unique = all(top_users[lid] == 1 for lid in top["journal_line_ids"])
        r["auto"] = (top["kind"] == "single" and top["score"] >= CONF_AUTO
                     and clear and unique)
    return results


# ── Screen data ───────────────────────────────────────────────────────────────

def statement_balance(db_path, account_id):
    """Closing balance from the latest imported statement line, or None when the
    imported files had no balance column (every stored balance is 0).
    Returns (balance, date)."""
    conn = get_connection(db_path)
    try:
        has = conn.execute("""SELECT 1 FROM bank_transactions
            WHERE account_id=? AND COALESCE(balance, 0) <> 0 LIMIT 1""",
            (account_id,)).fetchone()
        if not has:
            return None, None
        r = conn.execute("""SELECT balance, transaction_date FROM bank_transactions
            WHERE account_id=? AND COALESCE(is_rejected, 0) = 0
            ORDER BY transaction_date DESC, id DESC LIMIT 1""", (account_id,)).fetchone()
        return (round(float(r["balance"] or 0), 2), r["transaction_date"]) if r else (None, None)
    finally:
        conn.close()


def get_account_transactions(db_path, account_id):
    """Every ledger line on the account with its bank rec status:
    'reconciled' (ticked off in a finalised period), 'statement' (created
    from a statement line), 'matched' (matched to a statement line) or
    'unreconciled'."""
    conn = get_connection(db_path)
    try:
        liab = _is_liability(conn, account_id)
        rows = conn.execute("""
            SELECT jl.id, jl.debit, jl.credit, je.entry_date AS date, je.id AS journal_id,
                   COALESCE(NULLIF(jl.description, ''), je.description, '') AS description,
                   COALESCE(je.reference, '') AS reference,
                   COALESCE(jl.is_reconciled, 0) AS is_reconciled,
                   COALESCE(jl.is_rejected, 0) AS is_rejected,
                   (SELECT bank_txn_id FROM bank_matches m WHERE m.journal_line_id = jl.id) AS matched_to,
                   (SELECT b.id FROM bank_transactions b
                     WHERE b.journal_id = je.id AND b.account_id = jl.account_id LIMIT 1) AS from_statement
            FROM journal_lines jl
            JOIN journal_entries je ON je.id = jl.journal_id
            WHERE jl.account_id = ?
            ORDER BY je.entry_date DESC, jl.id DESC
        """, (account_id,)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["amount"] = ledger_amount(r, liab)
            if d["is_rejected"]:
                d["status"] = "rejected"
            elif d["is_reconciled"]:
                d["status"] = "reconciled"
            elif d["from_statement"]:
                d["status"] = "statement"
            elif d["matched_to"]:
                d["status"] = "matched"
            else:
                d["status"] = "unreconciled"
            out.append(d)
        return out
    finally:
        conn.close()


# ── Apply rules (create in bulk) ──────────────────────────────────────────────

def default_tax_code(conn, account_id):
    """GST code to use when recording to an account: none if the business
    isn't GST-registered or the account isn't income/expense; otherwise the
    account's own code (falling back to GST)."""
    co = conn.execute("SELECT gst_registered FROM company WHERE id=1").fetchone()
    if co is not None and not co["gst_registered"]:
        return "N-T"
    a = conn.execute("SELECT account_type, tax_code FROM accounts WHERE id=?",
                     (account_id,)).fetchone()
    if not a or a["account_type"] not in ("Income", "Expense"):
        return "N-T"
    code = a["tax_code"] or "GST"
    known = conn.execute("SELECT 1 FROM tax_codes WHERE code=?", (code,)).fetchone()
    return code if known else "GST"


def allocate_by_rule(db_path, line, rule, conn=None, taxes=None):
    """Record a statement line the way a bank rule says: to its account (with the
    rule's GST code or the account's default) or split by its percentages."""
    from core.bank_rules import rule_splits, split_amounts
    from core.ledger import allocate_bank_transaction, allocate_bank_transaction_multi
    own = conn is None
    conn = conn or get_connection(db_path)
    taxes = {} if taxes is None else taxes
    try:
        def tax_for(acc, code):
            if code:
                return code
            if acc not in taxes:
                taxes[acc] = default_tax_code(conn, acc)
            return taxes[acc]
        text = (line.get("description") or "").strip() or (line.get("reference") or "").strip()
        splits = rule_splits(rule)
        if splits:
            amounts = split_amounts(float(line.get("credit") or 0) - float(line.get("debit") or 0), splits)
            return allocate_bank_transaction_multi(db_path, line["id"], [
                {"mode": "account", "amount": a, "account_id": s["account_id"],
                 "tax_code": tax_for(s["account_id"], s.get("tax_code")),
                 "description": text, "contact_id": rule.get("contact_id")}
                for s, a in zip(splits, amounts)])
        acc = rule["account_id"]
        return allocate_bank_transaction(db_path, line["id"], "account", {
            "account_id": acc, "tax_code": tax_for(acc, rule.get("tax_code")),
            "description": text, "contact_id": rule.get("contact_id")})
    finally:
        if own:
            conn.close()


def apply_rules_create(db_path, account_id):
    """Record every unmatched statement line that a bank rule covers.

    Lines with a possible match to something already in dbox are skipped,
    because creating them could enter the same money twice. Returns
    {applied, skipped_match, errors}.
    """
    from core.bank_rules import get_rules, match_rule
    from core.ledger import allocate_bank_transaction

    rules = [r for r in get_rules(db_path) if r.get("account_id")]
    lines = get_unmatched_statement_lines(db_path, account_id)
    has_sugg = {s["bank_txn_id"] for s in suggest_matches(db_path, account_id)}
    applied, skipped, errors = 0, 0, []
    conn = get_connection(db_path)
    try:
        taxes = {}
        for l in lines:
            rule = next((r for r in rules if match_rule(r, l)), None)
            if not rule:
                continue
            if l["id"] in has_sugg:
                skipped += 1
                continue
            text = (l.get("description") or "").strip() or (l.get("reference") or "").strip()
            try:
                allocate_by_rule(db_path, l, rule, conn, taxes)
                applied += 1
            except Exception as e:
                errors.append(f"{l['transaction_date']} {text}: {e}")
    finally:
        conn.close()
    return {"applied": applied, "skipped_match": skipped, "errors": errors}


# ── Finish a statement (reconcile up to a date) ───────────────────────────────

def _finish_items(conn, account_id, as_at):
    """Statement lines up to `as_at` that are dealt with (created or matched)
    but not yet in a finished period, and their ledger lines."""
    rows = conn.execute("""
        SELECT b.id, b.debit, b.credit, b.journal_id, b.alloc_mode
        FROM bank_transactions b
        WHERE b.account_id = ? AND b.transaction_date <= ?
          AND COALESCE(b.is_rejected, 0) = 0
          AND (b.journal_id IS NOT NULL OR b.alloc_mode = 'match')
    """, (account_id, as_at)).fetchall()
    txn_ids, line_ids, movement = [], [], 0.0
    for b in rows:
        if b["journal_id"]:
            lids = [r[0] for r in conn.execute(
                "SELECT id FROM journal_lines WHERE journal_id=? AND account_id=? "
                "AND COALESCE(is_reconciled,0)=0", (b["journal_id"], account_id))]
        else:
            lids = [r[0] for r in conn.execute("""
                SELECT jl.id FROM bank_matches m JOIN journal_lines jl ON jl.id = m.journal_line_id
                WHERE m.bank_txn_id=? AND COALESCE(jl.is_reconciled,0)=0""", (b["id"],))]
        if not lids:
            continue          # already in a finished period
        txn_ids.append(b["id"])
        line_ids.extend(lids)
        movement += statement_amount(b)
    return txn_ids, line_ids, round(movement, 2)


def finish_preview(db_path, account_id, as_at):
    """Numbers for the Finish statement dialog, reconciling up to `as_at`."""
    conn = get_connection(db_path)
    try:
        acc = conn.execute("SELECT opening_balance FROM accounts WHERE id=?",
                           (account_id,)).fetchone()
        last = conn.execute("""SELECT reconcile_date, closing_balance FROM bank_reconciliations
            WHERE account_id=? AND status='Completed'
            ORDER BY reconcile_date DESC, id DESC LIMIT 1""", (account_id,)).fetchone()
        txn_ids, _, movement = _finish_items(conn, account_id, as_at)
        outstanding = conn.execute("""SELECT COUNT(*) FROM bank_transactions
            WHERE account_id=? AND transaction_date <= ? AND journal_id IS NULL
              AND alloc_mode IS NULL AND COALESCE(is_rejected,0)=0
              AND COALESCE(is_reconciled,0)=0""", (account_id, as_at)).fetchone()[0]
        bal = conn.execute("""SELECT balance FROM bank_transactions
            WHERE account_id=? AND transaction_date <= ? AND COALESCE(is_rejected,0)=0
            ORDER BY transaction_date DESC, id DESC LIMIT 1""", (account_id, as_at)).fetchone()
        has_bal = conn.execute("""SELECT 1 FROM bank_transactions
            WHERE account_id=? AND COALESCE(balance,0) <> 0 LIMIT 1""", (account_id,)).fetchone()
        if last:
            opening = round(float(last["closing_balance"]), 2)
        else:
            opening = round(float(acc["opening_balance"] or 0), 2) if acc else 0.0
        return {
            "as_at":             as_at,
            "last_rec_date":     last["reconcile_date"] if last else None,
            "opening":           opening,
            "opening_locked":    bool(last),
            "movement":          movement,
            "line_count":        len(txn_ids),
            "outstanding":       outstanding,
            "statement_balance": round(float(bal["balance"] or 0), 2) if (bal and has_bal) else None,
        }
    finally:
        conn.close()


def finish_statement(db_path, account_id, as_at, closing, opening=None,
                     adjust_account_id=None):
    """Reconcile the account up to `as_at` (the reconcile date) against the
    statement's closing balance. Every statement line up to that date must be
    dealt with, and opening + movement must equal `closing` to the cent —
    unless `adjust_account_id` is given, in which case the difference is
    posted to that account as a reconciliation adjustment and reconciled too.
    Marks the statement lines and their ledger lines reconciled on that date
    and records the reconciliation. Returns the bank_reconciliations id."""
    closing = round(float(closing), 2)
    p = finish_preview(db_path, account_id, as_at)
    if p["last_rec_date"] and as_at <= p["last_rec_date"]:
        raise ValueError(f"Already reconciled to {p['last_rec_date']}. Choose a later date.")
    if p["outstanding"]:
        raise ValueError(f"{p['outstanding']} statement line(s) up to this date still need "
                         f"matching or creating")
    open_bal = p["opening"] if (p["opening_locked"] or opening in (None, "")) \
        else round(float(opening), 2)
    diff = round(closing - (open_bal + p["movement"]), 2)
    adjusting = bool(adjust_account_id) and abs(diff) >= 0.005
    if not p["line_count"] and not adjusting:
        raise ValueError("Nothing new to reconcile up to this date")
    if abs(diff) >= 0.005 and not adjusting:
        raise ValueError(f"Out by {diff:,.2f}: opening {open_bal:,.2f} + transactions "
                         f"{p['movement']:,.2f} doesn't equal the statement balance {closing:,.2f}")
    adj_line = None
    if adjusting:
        from core.ledger import create_rec_adjustment_journal
        adj_id = int(adjust_account_id)
        if adj_id == int(account_id):
            raise ValueError("Choose a different account for the adjustment")
        c0 = get_connection(db_path)
        try:
            if not c0.execute("SELECT 1 FROM accounts WHERE id=?", (adj_id,)).fetchone():
                raise ValueError("Adjustment account not found")
            liab = _is_liability(c0, account_id)
        finally:
            c0.close()
        adj_line = create_rec_adjustment_journal(
            db_path, account_id, adj_id, diff, as_at,
            f"Bank rec adjustment to {as_at}", not liab)
    conn = get_connection(db_path)
    try:
        txn_ids, line_ids, _ = _finish_items(conn, account_id, as_at)
        if adj_line:
            line_ids.append(adj_line)
        cur = conn.execute("""INSERT INTO bank_reconciliations
            (account_id, reconcile_date, closing_balance, opening_balance, status)
            VALUES (?,?,?,?,'Completed')""", (account_id, as_at, closing, open_bal))
        rec_id = cur.lastrowid
        for table, ids in (("journal_lines", line_ids), ("bank_transactions", txn_ids)):
            for i in range(0, len(ids), 500):
                chunk = ids[i:i + 500]
                conn.execute(f"UPDATE {table} SET is_reconciled=1, reconciled_date=? "
                             f"WHERE id IN ({','.join('?' * len(chunk))})", [as_at] + chunk)
        conn.commit()
        return rec_id
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
