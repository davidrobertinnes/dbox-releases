# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
dbox Recurring Transactions module.

Templates can auto-generate invoices, bills, or journal entries
on weekly / fortnightly / monthly / quarterly / annual schedules.

Workflow:
  1. Create a recurring_template (with frequency, next_due, optional end_date)
  2. Call process_due_templates() — typically run on app startup or daily
  3. Each due template generates the target document and advances next_due
"""

from datetime import date as _date, timedelta
import calendar
import json
from core.database import get_connection


# ── Schema ────────────────────────────────────────────────────────────────────

FREQUENCIES = ["Weekly", "Fortnightly", "Monthly", "Quarterly", "Annual"]
TEMPLATE_TYPES = ["Journal", "Invoice", "Bill"]

def migrate_recurring(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS recurring_templates (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        name            TEXT NOT NULL,
        template_type   TEXT NOT NULL DEFAULT 'Journal',
        frequency       TEXT NOT NULL DEFAULT 'Monthly',
        next_due        TEXT NOT NULL,
        end_date        TEXT,
        is_active       INTEGER NOT NULL DEFAULT 1,
        -- shared fields
        description     TEXT,
        reference       TEXT,
        contact_id      INTEGER REFERENCES contacts(id),
        job_id          INTEGER REFERENCES jobs(id),
        amount          REAL,
        tax_code        TEXT,
        -- journal-specific: lines as JSON
        lines_json      TEXT,
        -- invoice/bill-specific
        account_id      INTEGER REFERENCES accounts(id),
        -- tracking
        last_generated  TEXT,
        run_count       INTEGER NOT NULL DEFAULT 0,
        created_by      INTEGER,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS recurring_runs (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        template_id     INTEGER NOT NULL REFERENCES recurring_templates(id),
        run_date        TEXT NOT NULL,
        generated_type  TEXT NOT NULL,
        generated_id    INTEGER,
        status          TEXT NOT NULL DEFAULT 'OK',
        message         TEXT,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")


# ── Date arithmetic ───────────────────────────────────────────────────────────

def advance_date(from_date: str, frequency: str) -> str:
    """Return the next due date after from_date for the given frequency."""
    d = _date.fromisoformat(from_date)
    if frequency == "Weekly":
        return str(d + timedelta(weeks=1))
    elif frequency == "Fortnightly":
        return str(d + timedelta(weeks=2))
    elif frequency == "Monthly":
        month = d.month + 1
        year  = d.year + (month - 1) // 12
        month = (month - 1) % 12 + 1
        day   = min(d.day, calendar.monthrange(year, month)[1])
        return str(_date(year, month, day))
    elif frequency == "Quarterly":
        month = d.month + 3
        year  = d.year + (month - 1) // 12
        month = (month - 1) % 12 + 1
        day   = min(d.day, calendar.monthrange(year, month)[1])
        return str(_date(year, month, day))
    elif frequency == "Annual":
        year  = d.year + 1
        day   = min(d.day, calendar.monthrange(year, d.month)[1])
        return str(_date(year, d.month, day))
    return from_date


# ── CRUD ──────────────────────────────────────────────────────────────────────

def get_templates(db_path, active_only=False):
    conn = get_connection(db_path)
    q = """SELECT rt.*, c.name as contact_name, a.name as account_name,
        j.name as job_name
        FROM recurring_templates rt
        LEFT JOIN contacts c ON rt.contact_id=c.id
        LEFT JOIN accounts  a ON rt.account_id=a.id
        LEFT JOIN jobs      j ON rt.job_id=j.id
        WHERE 1=1"""
    if active_only:
        q += " AND rt.is_active=1"
    q += " ORDER BY rt.next_due"
    rows = conn.execute(q).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_template(db_path, tmpl_id):
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT * FROM recurring_templates WHERE id=?", (tmpl_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_template(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    # Auto-serialize lines_json if client sends a list instead of a JSON string
    if isinstance(data.get("lines_json"), list):
        data = dict(data)
        data["lines_json"] = json.dumps(data["lines_json"])
    tid = data.get("id")
    fields = ["name","template_type","frequency","next_due","end_date",
              "is_active","description","reference","contact_id","job_id",
              "amount","tax_code","lines_json","account_id","created_by"]
    vals = [data.get(f) for f in fields]
    if tid:
        sets = ", ".join(f"{f}=?" for f in fields)
        conn.execute(f"UPDATE recurring_templates SET {sets} WHERE id=?", vals+[tid])
    else:
        cols = ", ".join(fields)
        ph   = ", ".join("?" for _ in fields)
        conn.execute(f"INSERT INTO recurring_templates ({cols}) VALUES ({ph})", vals)
        tid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit(); conn.close()
    return tid


def delete_template(db_path, tmpl_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM recurring_templates WHERE id=?", (tmpl_id,))
    conn.commit(); conn.close()


def get_runs(db_path, tmpl_id=None, limit=100):
    conn = get_connection(db_path)
    q = """SELECT rr.*, rt.name as template_name
        FROM recurring_runs rr
        JOIN recurring_templates rt ON rr.template_id=rt.id
        WHERE 1=1"""
    params = []
    if tmpl_id:
        q += " AND rr.template_id=?"
        params.append(tmpl_id)
    q += " ORDER BY rr.created_at DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ── Processing engine ─────────────────────────────────────────────────────────

def process_due_templates(db_path, as_of: str = None, dry_run: bool = False):
    """
    Find all active templates with next_due <= as_of and generate transactions.
    Returns list of result dicts.
    """
    as_of = as_of or str(_date.today())
    conn  = get_connection(db_path)
    due   = conn.execute("""SELECT * FROM recurring_templates
        WHERE is_active=1 AND next_due<=?
        AND (end_date IS NULL OR end_date>=?)
        ORDER BY next_due""", (as_of, as_of)).fetchall()
    conn.close()

    results = []
    for t in due:
        t = dict(t)
        try:
            if dry_run:
                results.append({"template": t["name"], "due": t["next_due"],
                                 "status": "Would generate", "dry_run": True})
                continue
            gtype, gid = _generate_from_template(db_path, t)
            _advance_template(db_path, t)
            _log_run(db_path, t["id"], as_of, gtype, gid, "OK")
            results.append({"template": t["name"], "type": gtype,
                             "id": gid, "status": "OK"})
        except Exception as ex:
            _log_run(db_path, t["id"], as_of, t["template_type"], None,
                     "Error", str(ex))
            results.append({"template": t["name"], "status": "Error", "error": str(ex)})
    return results


def _generate_from_template(db_path, t: dict):
    """Generate a single transaction from a template dict. Returns (type, id)."""
    ttype = t["template_type"]

    if ttype == "Journal":
        from core.ledger import post_journal
        lines = json.loads(t["lines_json"] or "[]")
        if not lines:
            raise ValueError("Journal template has no lines")
        jid = post_journal(
            db_path, t["next_due"],
            t["description"] or t["name"],
            t["reference"] or f"REC-{t['id']}",
            lines)
        return "journal", jid

    elif ttype == "Invoice":
        from core.ledger import save_invoice
        from datetime import date as _d, timedelta as _td
        if not t.get("contact_id"):
            raise ValueError("Invoice template requires a contact")
        due_date = str(_d.fromisoformat(t["next_due"]) + _td(days=30))
        # Use multi-line lines_json if present, else fall back to single-line
        raw_lines = json.loads(t["lines_json"] or "[]")
        if raw_lines:
            lines = [{"description": l.get("description", ""),
                      "quantity":    float(l.get("quantity", 1)),
                      "unit_price":  float(l.get("unit_price", 0)),
                      "tax_code":    l.get("tax_code", "GST"),
                      "account_id":  l.get("account_id")} for l in raw_lines]
        else:
            if not t.get("account_id"):
                raise ValueError("Invoice template requires an income account or line items")
            amount = t.get("amount") or 0
            lines = [{"description": t["description"] or t["name"],
                      "quantity": 1, "unit_price": amount,
                      "account_id": t["account_id"],
                      "tax_code": t.get("tax_code") or "GST"}]
        inv_data = {
            "contact_id":   t["contact_id"],
            "invoice_date": t["next_due"],
            "due_date":     due_date,
            "status":       "Draft",
            "notes":        t.get("description") or "",
        }
        iid = save_invoice(db_path, inv_data, lines)
        return "invoice", iid

    elif ttype == "Bill":
        from core.ledger import save_bill
        from datetime import date as _d, timedelta as _td
        if not t.get("contact_id"):
            raise ValueError("Bill template requires a contact")
        due_date = str(_d.fromisoformat(t["next_due"]) + _td(days=30))
        raw_lines = json.loads(t["lines_json"] or "[]")
        if raw_lines:
            lines = [{"description": l.get("description", ""),
                      "quantity":    float(l.get("quantity", 1)),
                      "unit_price":  float(l.get("unit_price", 0)),
                      "tax_code":    l.get("tax_code", "GST"),
                      "account_id":  l.get("account_id")} for l in raw_lines]
        else:
            if not t.get("account_id"):
                raise ValueError("Bill template requires an expense account or line items")
            amount = t.get("amount") or 0
            lines = [{"description": t["description"] or t["name"],
                      "quantity": 1, "unit_price": amount,
                      "account_id": t["account_id"],
                      "tax_code": t.get("tax_code") or "GST"}]
        bill_data = {
            "contact_id": t["contact_id"],
            "bill_date":  t["next_due"],
            "due_date":   due_date,
            "status":     "Draft",
            "notes":      t.get("description") or "",
        }
        bid = save_bill(db_path, bill_data, lines)
        return "bill", bid

    raise ValueError(f"Unknown template type: {ttype}")


def _advance_template(db_path, t: dict):
    next_due = advance_date(t["next_due"], t["frequency"])
    conn = get_connection(db_path)
    # Deactivate if past end_date
    active = 1
    if t.get("end_date") and next_due > t["end_date"]:
        active = 0
    conn.execute("""UPDATE recurring_templates
        SET next_due=?, last_generated=?, run_count=run_count+1, is_active=?
        WHERE id=?""", (next_due, t["next_due"], active, t["id"]))
    conn.commit(); conn.close()


def _log_run(db_path, tmpl_id, run_date, gtype, gid, status, message=None):
    conn = get_connection(db_path)
    conn.execute("""INSERT INTO recurring_runs
        (template_id, run_date, generated_type, generated_id, status, message)
        VALUES (?,?,?,?,?,?)""",
        (tmpl_id, run_date, gtype, gid, status, message))
    conn.commit(); conn.close()


def get_upcoming(db_path, days: int = 30):
    """Return templates due in the next N days."""
    conn = get_connection(db_path)
    from datetime import date as _d, timedelta as _td
    cutoff = str(_d.today() + _td(days=days))
    rows = conn.execute("""SELECT rt.*, c.name as contact_name
        FROM recurring_templates rt
        LEFT JOIN contacts c ON rt.contact_id=c.id
        WHERE rt.is_active=1 AND rt.next_due<=?
        ORDER BY rt.next_due""", (cutoff,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]
