# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Petty Cash — float-based cash management.

GL flows:
  Disbursement:   DR Expense (net) + DR GST Paid (1-1300) → CR Petty Cash
  Replenishment:  DR Petty Cash → CR Bank
"""

from core.database import get_connection
from core.ledger import post_journal, get_journal_entry, save_account


def get_petty_cash_accounts(db_path):
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT * FROM accounts
        WHERE account_subtype='Petty Cash' AND is_active=1
        ORDER BY code""").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_petty_cash_balance(db_path, account_id):
    conn = get_connection(db_path)
    acc = conn.execute(
        "SELECT opening_balance FROM accounts WHERE id=?",
        (account_id,)).fetchone()
    row = conn.execute("""
        SELECT COALESCE(SUM(jl.debit),0) - COALESCE(SUM(jl.credit),0)
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id=je.id
        WHERE jl.account_id=?""", (account_id,)).fetchone()
    conn.close()
    opening = (acc["opening_balance"] or 0.0) if acc else 0.0
    journal = row[0] if row else 0.0
    return round(opening + journal, 2)


def get_petty_cash_transactions(db_path, account_id, date_from=None, date_to=None):
    conn = get_connection(db_path)
    q = """SELECT je.id as journal_id, je.entry_date, je.reference,
        je.description as journal_desc, je.entry_type,
        je.contact_id, c.name as contact_name,
        jl.debit, jl.credit, jl.description as line_desc,
        (jl.debit - jl.credit) as movement
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id=je.id
        LEFT JOIN contacts c ON je.contact_id=c.id
        WHERE jl.account_id=?"""
    params = [account_id]
    if date_from:
        q += " AND je.entry_date>=?"; params.append(date_from)
    if date_to:
        q += " AND je.entry_date<=?"; params.append(date_to)
    q += " ORDER BY je.entry_date, je.id"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def record_disbursement(db_path, account_id, disburse_date, description,
                        amount, gst_amount, expense_account_id,
                        reference="", contact_id=None):
    """
    DR Expense           amount (net)
    DR GST Paid 1-1300   gst_amount (if applicable)
    CR Petty Cash        total
    """
    conn = get_connection(db_path)
    gst_acc = conn.execute(
        "SELECT id FROM accounts WHERE code='1-1300'").fetchone()
    conn.close()

    gst_amount = gst_amount or 0.0
    total = amount + gst_amount
    ref = reference or f"PC-{disburse_date}"

    lines = [
        {"account_id": expense_account_id, "debit": amount, "credit": 0,
         "description": description},
    ]
    if gst_amount and gst_acc:
        lines.append({"account_id": gst_acc["id"], "debit": gst_amount, "credit": 0,
                      "description": f"GST: {description}"})
    lines.append({"account_id": account_id, "debit": 0, "credit": total,
                  "description": description})

    jid = post_journal(db_path, disburse_date, description, ref, lines)
    conn = get_connection(db_path)
    conn.execute(
        "UPDATE journal_entries SET entry_type='PC Disbursement', contact_id=? WHERE id=?",
        (contact_id, jid))
    conn.commit()
    conn.close()
    return jid


def record_replenishment(db_path, account_id, replenish_date, amount,
                         bank_account_id, description="", reference=""):
    """
    DR Petty Cash   amount
    CR Bank         amount
    """
    description = description or "Petty Cash Replenishment"
    ref = reference or f"PC-RPL-{replenish_date}"
    lines = [
        {"account_id": account_id, "debit": amount, "credit": 0,
         "description": description},
        {"account_id": bank_account_id, "debit": 0, "credit": amount,
         "description": description},
    ]
    jid = post_journal(db_path, replenish_date, description, ref, lines)
    conn = get_connection(db_path)
    conn.execute(
        "UPDATE journal_entries SET entry_type='PC Replenishment' WHERE id=?", (jid,))
    conn.commit()
    conn.close()
    return jid


def void_pc_transaction(db_path, journal_id):
    """Reverse a petty cash transaction by posting a reversal journal."""
    entry, lines = get_journal_entry(db_path, journal_id)
    if not entry:
        raise ValueError("Journal entry not found")
    if str(entry.get("description", "")).startswith("[VOIDED]"):
        raise ValueError("Entry is already voided")

    rev_lines = [{"account_id": l["account_id"],
                  "debit": l["credit"], "credit": l["debit"],
                  "description": f"Reversal: {l.get('description','')}"
                  } for l in lines]
    post_journal(db_path, entry["entry_date"],
                 f"VOID: {entry['description']}",
                 f"VOID-{entry['reference'] or entry['id']}",
                 rev_lines)
    conn = get_connection(db_path)
    conn.execute(
        "UPDATE journal_entries SET description=?, reference=? WHERE id=?",
        (f"[VOIDED] {entry['description']}",
         f"VOID-{entry['reference'] or entry['id']}",
         journal_id))
    conn.commit()
    conn.close()


def petty_cash_report(db_path, account_id, date_from, date_to):
    """
    Returns opening balance, disbursements, replenishments, and closing balance
    for a petty cash float over a date range.
    """
    conn = get_connection(db_path)
    acc = conn.execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
    if not acc:
        conn.close()
        raise ValueError("Account not found")

    ob_row = conn.execute("""
        SELECT COALESCE(SUM(jl.debit),0) - COALESCE(SUM(jl.credit),0)
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id=je.id
        WHERE jl.account_id=? AND je.entry_date<?
    """, (account_id, date_from)).fetchone()
    opening = (acc["opening_balance"] or 0.0) + (ob_row[0] if ob_row else 0.0)

    rows = conn.execute("""
        SELECT je.id as journal_id, je.entry_date, je.reference,
               je.description as journal_desc, je.entry_type,
               jl.description as line_desc,
               (jl.debit - jl.credit) as movement
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id=je.id
        WHERE jl.account_id=? AND je.entry_date>=? AND je.entry_date<=?
        ORDER BY je.entry_date, je.id
    """, (account_id, date_from, date_to)).fetchall()

    disbursements = []
    replenishments = []
    for r in rows:
        t = dict(r)
        t["description"] = t["line_desc"] or t["journal_desc"] or ""
        if t["entry_type"] == "PC Disbursement":
            exp = conn.execute("""
                SELECT a.code, a.name FROM journal_lines jl
                JOIN accounts a ON jl.account_id=a.id
                WHERE jl.journal_id=? AND jl.account_id!=?
                  AND a.account_type IN ('Expense','Cost of Goods Sold')
                ORDER BY jl.debit DESC LIMIT 1
            """, (t["journal_id"], account_id)).fetchone()
            t["expense_account"] = (exp["code"] + " " + exp["name"]) if exp else ""
            disbursements.append(t)
        elif t["entry_type"] == "PC Replenishment":
            replenishments.append(t)

    total_disbursed    = round(sum(t["movement"] for t in disbursements), 2)
    total_replenished  = round(sum(t["movement"] for t in replenishments), 2)
    closing = round(opening + total_disbursed + total_replenished, 2)
    conn.close()

    return {
        "account":          dict(acc),
        "date_from":        date_from,
        "date_to":          date_to,
        "opening_balance":  round(opening, 2),
        "disbursements":    disbursements,
        "replenishments":   replenishments,
        "total_disbursed":  total_disbursed,
        "total_replenished": total_replenished,
        "closing_balance":  closing,
    }


def create_petty_cash_float(db_path, name, code, opening_balance=0.0):
    save_account(db_path, {
        "code":            code,
        "name":            name,
        "account_type":    "Asset",
        "account_subtype": "Petty Cash",
        "is_bank":         0,
        "opening_balance": opening_balance,
    })
