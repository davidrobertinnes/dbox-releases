# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Accounting — Google Calendar sync (Schedule phase 2)

Two-way sync between `schedule_events` and a Google Calendar. OAuth2
Authorization Code + PKCE flow and the Calendar REST v3 API, built with
stdlib `urllib.request` only (matches core/licence.py's outbound-call
pattern) — no google-auth/google-api-python-client dependency.

Phase 2a: OAuth connect/disconnect + calendar selection.
Phase 2b: on-demand pull sync (Google → dbox), via `pull_events()`.
Phase 2c (this module now also covers): push sync (dbox → Google), via
`push_event()`/`push_delete()`, called from web/routes/schedule.py's
create/update/delete handlers after a successful local save.

The OAuth client is a "Desktop app" type client registered once by Dogbox
Software in Google Cloud Console; the same client_id/secret is used by every
installation, the same way the licence HMAC secret in core/licence.py is
embedded once for all installs. Individual dbox users never touch Google
Cloud Console — they just see Google's normal consent screen.

Unlike the licence HMAC secret, the client_id/secret pair here is a live
third-party credential, so it is NOT committed to git: it's read at runtime
from `gcal_client.json` at the repo root (gitignored — see .gitignore).
A source install or build needs that file present; `_client_creds()` raises
a clear error if it's missing rather than silently failing.
"""

from __future__ import annotations
import base64 as _b64
import hashlib
import json as _json
import os
import secrets
import urllib.error
import urllib.request
from datetime import date as _date, datetime as _datetime, timedelta as _timedelta, timezone as _timezone
from urllib.parse import urlencode, quote as _urlquote

from core.database import get_connection


class GcalApiError(RuntimeError):
    """Google API error with the HTTP status code attached, so callers can
    branch on it (e.g. 410 Gone = expired sync token) without string-
    matching the message."""
    def __init__(self, code: int, message: str):
        super().__init__(f"Google API error {code}: {message}")
        self.code = code


def _call(req: urllib.request.Request, timeout: int = 10) -> dict:
    """Run a urllib request and return the parsed JSON body. On an HTTP
    error, raises GcalApiError with Google's actual error detail instead of
    urllib's bare 'HTTP Error 403: Forbidden' — needed to tell apart e.g. a
    missing OAuth scope from a disabled API from an expired token."""
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return _json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        try:
            msg = _json.loads(body).get("error", {})
            msg = msg.get("message") if isinstance(msg, dict) else msg
        except Exception:
            msg = body
        raise GcalApiError(e.code, msg or e.reason) from e

_CLIENT_CONFIG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "gcal_client.json")
_client_creds_cache: tuple[str, str] | None = None


def _client_creds() -> tuple[str, str]:
    """Return (client_id, client_secret), loaded once from gcal_client.json."""
    global _client_creds_cache
    if _client_creds_cache is None:
        try:
            with open(_CLIENT_CONFIG_PATH, encoding="utf-8") as f:
                cfg = _json.load(f)
            _client_creds_cache = (cfg["client_id"], cfg["client_secret"])
        except Exception as e:
            raise RuntimeError(
                "Google Calendar isn't configured on this installation "
                f"(missing or invalid {_CLIENT_CONFIG_PATH})") from e
    return _client_creds_cache


_AUTH_URL     = "https://accounts.google.com/o/oauth2/v2/auth"
_TOKEN_URL    = "https://oauth2.googleapis.com/token"
_REVOKE_URL   = "https://oauth2.googleapis.com/revoke"
_USERINFO_URL = "https://www.googleapis.com/oauth2/v2/userinfo"
_CALENDAR_API = "https://www.googleapis.com/calendar/v3"

# openid+email are non-sensitive scopes (just for the connected-account
# label). calendar.events is the sensitive scope for event CRUD, but it does
# NOT cover the CalendarList resource (/users/me/calendarList) used by the
# calendar picker — that needs its own (still minimal, read-only) scope.
_SCOPES = ("openid email "
           "https://www.googleapis.com/auth/calendar.events "
           "https://www.googleapis.com/auth/calendar.calendarlist.readonly")

# In-memory PKCE state, cleared on use. Single-user local desktop app —
# no persistence or expiry needed beyond the process lifetime.
_pending: dict[str, str] = {}


def _enc(val: str) -> str:
    """Minimal obfuscation for tokens in the local SQLite file — matches
    core/email_invoice.py's _enc_pw."""
    return _b64.b64encode(val.encode()).decode() if val else ""


def _dec(stored: str) -> str:
    if not stored:
        return ""
    try:
        return _b64.b64decode(stored.encode()).decode()
    except Exception:
        return stored


# ── Settings CRUD ────────────────────────────────────────────────────────────

def migrate_gcal_settings(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS gcal_settings (
        id                   INTEGER PRIMARY KEY CHECK (id=1),
        connected            INTEGER NOT NULL DEFAULT 0,
        google_account_email TEXT,
        calendar_id          TEXT,
        refresh_token        TEXT,
        sync_token           TEXT,
        last_synced_at       TEXT)""")


def get_gcal_settings(db_path) -> dict:
    conn = get_connection(db_path)
    migrate_gcal_settings(conn)
    conn.commit()
    row = conn.execute("SELECT * FROM gcal_settings WHERE id=1").fetchone()
    conn.close()
    if not row:
        return {"connected": 0, "google_account_email": None,
                 "calendar_id": None, "last_synced_at": None}
    d = dict(row)
    d.pop("refresh_token", None)  # never send the token to the frontend
    d.pop("sync_token", None)
    return d


def _get_refresh_token(db_path) -> str | None:
    conn = get_connection(db_path)
    migrate_gcal_settings(conn)
    row = conn.execute("SELECT refresh_token FROM gcal_settings WHERE id=1").fetchone()
    conn.close()
    return _dec(row["refresh_token"]) if row and row["refresh_token"] else None


def save_connection(db_path, email: str, refresh_token: str):
    conn = get_connection(db_path)
    migrate_gcal_settings(conn)
    conn.execute("""INSERT INTO gcal_settings (id, connected, google_account_email, refresh_token)
        VALUES (1, 1, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
            connected=1, google_account_email=excluded.google_account_email,
            refresh_token=excluded.refresh_token""",
        (email, _enc(refresh_token)))
    conn.commit()
    conn.close()


def set_calendar(db_path, calendar_id: str):
    conn = get_connection(db_path)
    migrate_gcal_settings(conn)
    conn.execute("UPDATE gcal_settings SET calendar_id=? WHERE id=1", (calendar_id,))
    conn.commit()
    conn.close()


def _get_sync_token(db_path) -> str | None:
    conn = get_connection(db_path)
    migrate_gcal_settings(conn)
    row = conn.execute("SELECT sync_token FROM gcal_settings WHERE id=1").fetchone()
    conn.close()
    return row["sync_token"] if row else None


def _save_sync_state(db_path, sync_token: str | None):
    conn = get_connection(db_path)
    migrate_gcal_settings(conn)
    conn.execute("""UPDATE gcal_settings SET sync_token=?,
        last_synced_at=datetime('now','localtime') WHERE id=1""", (sync_token,))
    conn.commit()
    conn.close()


def disconnect(db_path):
    token = _get_refresh_token(db_path)
    if token:
        revoke(token)
    conn = get_connection(db_path)
    migrate_gcal_settings(conn)
    conn.execute("""UPDATE gcal_settings SET connected=0, google_account_email=NULL,
        calendar_id=NULL, refresh_token=NULL, sync_token=NULL WHERE id=1""")
    conn.commit()
    conn.close()


# ── OAuth2 (Authorization Code + PKCE) ───────────────────────────────────────

def _new_pkce() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(64)[:128]
    challenge = _b64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode()).digest()
    ).decode().rstrip("=")
    return verifier, challenge


def start_auth(redirect_uri: str) -> str:
    """Generate PKCE + state, stash the verifier, return the consent URL."""
    client_id, _ = _client_creds()
    state = secrets.token_urlsafe(24)
    verifier, challenge = _new_pkce()
    _pending[state] = verifier
    params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": _SCOPES,
        "access_type": "offline",
        "prompt": "consent",  # force re-issue of a refresh token every time
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "state": state,
    }
    return f"{_AUTH_URL}?{urlencode(params)}"


def exchange_code(code: str, state: str, redirect_uri: str) -> dict:
    """Exchange an authorization code for tokens. Raises ValueError if the
    state doesn't match a pending request (expired/replayed/forged)."""
    verifier = _pending.pop(state, None)
    if not verifier:
        raise ValueError("This sign-in link has expired — try connecting again.")
    client_id, client_secret = _client_creds()
    data = urlencode({
        "client_id": client_id,
        "client_secret": client_secret,
        "code": code,
        "code_verifier": verifier,
        "grant_type": "authorization_code",
        "redirect_uri": redirect_uri,
    }).encode()
    req = urllib.request.Request(_TOKEN_URL, data=data, method="POST")
    return _call(req)


def refresh_access_token(refresh_token: str) -> dict:
    client_id, client_secret = _client_creds()
    data = urlencode({
        "client_id": client_id,
        "client_secret": client_secret,
        "refresh_token": refresh_token,
        "grant_type": "refresh_token",
    }).encode()
    req = urllib.request.Request(_TOKEN_URL, data=data, method="POST")
    return _call(req)


def get_access_token(db_path) -> str | None:
    """Fresh access token via the stored refresh token, or None if not
    connected / refresh failed (e.g. the user revoked access on Google's
    side) — never raises."""
    refresh_token = _get_refresh_token(db_path)
    if not refresh_token:
        return None
    try:
        return refresh_access_token(refresh_token).get("access_token")
    except Exception:
        return None


def revoke(token: str):
    try:
        data = urlencode({"token": token}).encode()
        req = urllib.request.Request(_REVOKE_URL, data=data, method="POST")
        urllib.request.urlopen(req, timeout=10)
    except Exception:
        pass  # best-effort — local settings are cleared regardless


def get_user_email(access_token: str) -> str:
    req = urllib.request.Request(
        _USERINFO_URL, headers={"Authorization": f"Bearer {access_token}"})
    return _call(req).get("email", "")


# ── Calendar REST ─────────────────────────────────────────────────────────────

def list_calendars(access_token: str) -> list:
    req = urllib.request.Request(
        f"{_CALENDAR_API}/users/me/calendarList",
        headers={"Authorization": f"Bearer {access_token}"})
    items = _call(req).get("items", [])
    return [{"id": c["id"], "summary": c.get("summary", c["id"]),
              "primary": bool(c.get("primary"))} for c in items]


def list_events(access_token: str, calendar_id: str, sync_token: str | None = None) -> dict:
    """Fetch all changed events, following pagination internally.

    Returns {'events': [...], 'next_sync_token': str|None, 'expired': bool}.
    'expired' True means the given sync_token was rejected (410 Gone) —
    the caller should clear it and call again with sync_token=None for a
    fresh full sync.
    """
    events = []
    page_token = None
    cal_id_q = _urlquote(calendar_id, safe='')
    while True:
        params = {'maxResults': 250}
        if sync_token:
            # syncToken and timeMin/singleEvents are mutually exclusive —
            # once incremental syncing has started, Google tracks the
            # window itself.
            params['syncToken'] = sync_token
        else:
            params['singleEvents'] = 'true'
            params['orderBy'] = 'startTime'
            # 2 days back covers same-day items regardless of timezone skew
            # between this machine and Google's UTC clock, without pulling
            # a user's entire calendar history on first connect.
            time_min = (_datetime.now(_timezone.utc) - _timedelta(days=2)) \
                .strftime('%Y-%m-%dT00:00:00Z')
            params['timeMin'] = time_min
        if page_token:
            params['pageToken'] = page_token
        url = f"{_CALENDAR_API}/calendars/{cal_id_q}/events?{urlencode(params)}"
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {access_token}"})
        try:
            data = _call(req)
        except GcalApiError as e:
            if e.code == 410:
                return {'events': [], 'next_sync_token': None, 'expired': True}
            raise
        events.extend(data.get('items', []))
        page_token = data.get('nextPageToken')
        if not page_token:
            return {'events': events, 'next_sync_token': data.get('nextSyncToken'), 'expired': False}


def _from_gcal_event(event: dict) -> dict:
    """Map a Google Calendar API event resource to schedule_events fields."""
    start = event.get('start', {})
    end   = event.get('end', {})
    all_day = 'date' in start

    if all_day:
        sd = _date.fromisoformat(start['date'])
        # Google's all-day end.date is exclusive (day after the last day);
        # dbox's end_date is inclusive, and NULL for a single-day event.
        ed = _date.fromisoformat(end['date']) - _timedelta(days=1)
        event_date = sd.isoformat()
        end_date   = ed.isoformat() if ed != sd else None
        start_time = end_time = None
    else:
        # Google returns dateTime with whatever offset the event/calendar's
        # own timeZone is set to — not necessarily this machine's local
        # timezone. Naively slicing the date out of the raw string is only
        # correct if those happen to match; otherwise a same-day event can
        # come out shifted onto the wrong calendar date entirely. Parse as
        # timezone-aware and convert to local (matching push's
        # _local_utc_offset() convention — dbox has no per-event timezone
        # concept, local-machine-time is the reference frame throughout).
        start_local = _datetime.fromisoformat(start['dateTime']).astimezone()
        end_local   = _datetime.fromisoformat(end['dateTime']).astimezone()
        event_date = start_local.strftime('%Y-%m-%d')
        end_date_d = end_local.strftime('%Y-%m-%d')
        end_date   = end_date_d if end_date_d != event_date else None
        start_time = start_local.strftime('%H:%M')
        end_time   = end_local.strftime('%H:%M')

    return {
        'title':         event.get('summary') or '(untitled)',
        'description':   event.get('description'),
        'event_date':    event_date,
        'end_date':      end_date,
        'all_day':       all_day,
        'start_time':    start_time,
        'end_time':      end_time,
        'gcal_event_id': event['id'],
        'gcal_updated':  event.get('updated'),
    }


def pull_events(db_path) -> dict:
    """On-demand pull sync: Google → dbox. No push yet (phase 2c) — a local
    edit made to an event since its last sync is left untouched rather than
    overwritten (detected via updated_at > synced_at, see core/schedule.py),
    since there is currently no way to carry that edit back out to Google.

    Jobs (phase 3) push into this same connected calendar, so every
    incoming event is also checked against jobs.gcal_event_id — a job's
    own calendar entry must never be imported as a second, separate
    schedule_events row. If one was already wrongly imported by an earlier
    sync (before this check existed), it's cleaned up here too.
    """
    from core.jobs import get_job_by_gcal_id
    from core.schedule import (get_event_by_gcal_id, save_event, delete_event,
                               unlink_event_gcal)

    settings = get_gcal_settings(db_path)
    if not settings.get('connected'):
        return {'ok': False, 'error': 'Not connected to Google Calendar'}
    calendar_id = settings.get('calendar_id')
    if not calendar_id:
        return {'ok': False, 'error': 'No calendar selected'}

    access_token = get_access_token(db_path)
    if not access_token:
        return {'ok': False, 'error': 'Could not refresh Google access — try reconnecting'}

    sync_token = _get_sync_token(db_path)
    result = list_events(access_token, calendar_id, sync_token=sync_token)
    if result['expired']:
        result = list_events(access_token, calendar_id, sync_token=None)

    created = updated = deleted = skipped = 0
    touched_jobs = set()  # jobs that lost a visit — their span may need to return
    for ev in result['events']:
        gid = ev.get('id')
        if not gid:
            continue

        if ev.get('status') == 'cancelled':
            local = get_event_by_gcal_id(db_path, gid)
            if not local:
                continue
            from core.visit_tasks import visit_has_progress
            from core.database import get_connection as _gc
            _c = _gc(db_path)
            try:
                has_progress = visit_has_progress(_c, local['id'])
            finally:
                _c.close()
            if local.get('invoice_id') or has_progress:
                # A billed visit is the record behind an invoice line, and a
                # visit with task progress is the record of work done — keep
                # it, just stop pointing at the now-deleted Google event.
                unlink_event_gcal(db_path, local['id'])
                continue
            delete_event(db_path, local['id'])
            deleted += 1
            if local.get('job_id'):
                touched_jobs.add(local['job_id'])
            continue

        if get_job_by_gcal_id(db_path, gid):
            # This Google event was pushed by a Job — never a personal
            # schedule_events item, regardless of what pull sees. Clean up
            # a stale duplicate if an earlier sync (before this check
            # existed) already wrongly imported it — local delete only,
            # never push_delete: this is the job's real Google event, not
            # ours to remove from the calendar.
            stale = get_event_by_gcal_id(db_path, gid)
            if stale:
                delete_event(db_path, stale['id'])
                deleted += 1
            continue

        mapped = _from_gcal_event(ev)
        local = get_event_by_gcal_id(db_path, gid)
        if local:
            if local.get('gcal_updated') == mapped['gcal_updated']:
                continue  # nothing changed since the last pull
            if (local.get('updated_at') and local.get('synced_at')
                    and local['updated_at'] > local['synced_at']):
                # Locally edited since the last sync, never pushed — leave
                # it alone rather than clobber the edit. Phase 2c (push)
                # will reconcile this properly.
                skipped += 1
                continue
            # Google only owns title/description/dates/times — preserve
            # dbox-only fields the user may have set (contact/job link,
            # event_type) rather than blanking them out on every update.
            mapped['id']         = local['id']
            mapped['event_type'] = local.get('event_type') or 'Personal'
            mapped['contact_id'] = local.get('contact_id')
            mapped['job_id']     = local.get('job_id')
            mapped['created_by'] = local.get('created_by')
            save_event(db_path, mapped)
            updated += 1
        else:
            mapped['event_type'] = 'Personal'
            save_event(db_path, mapped)
            created += 1

    _save_sync_state(db_path, result.get('next_sync_token'))
    for jid in touched_jobs:
        push_job(db_path, jid)
    return {'ok': True, 'created': created, 'updated': updated,
            'deleted': deleted, 'skipped': skipped}


# ── Push (dbox → Google) ──────────────────────────────────────────────────────

def _local_utc_offset() -> str:
    """This machine's current UTC offset as '+10:00' / '-05:00' — dbox has
    no per-event timezone concept, so a pushed event's wall-clock time is
    assumed to be whatever timezone the local machine is in right now."""
    off = _datetime.now().astimezone().utcoffset()
    total_minutes = int(off.total_seconds() // 60)
    sign = '+' if total_minutes >= 0 else '-'
    h, m = divmod(abs(total_minutes), 60)
    return f"{sign}{h:02d}:{m:02d}"


def _to_gcal_body(event: dict) -> dict:
    """Map a schedule_events row to a Google Calendar event resource body —
    the inverse of _from_gcal_event()."""
    body = {'summary': event['title'], 'description': event.get('description') or None}
    if event.get('all_day'):
        end_date = event.get('end_date') or event['event_date']
        # dbox's end_date is inclusive; Google's all-day end.date is exclusive.
        end_exclusive = (_date.fromisoformat(end_date) + _timedelta(days=1)).isoformat()
        body['start'] = {'date': event['event_date']}
        body['end']   = {'date': end_exclusive}
    else:
        offset     = _local_utc_offset()
        start_time = event.get('start_time') or '00:00'
        end_time   = event.get('end_time') or start_time
        end_date   = event.get('end_date') or event['event_date']
        start_dt = _datetime.strptime(f"{event['event_date']} {start_time}", '%Y-%m-%d %H:%M')
        end_dt   = _datetime.strptime(f"{end_date} {end_time}", '%Y-%m-%d %H:%M')
        if end_dt <= start_dt:
            # Google rejects a zero/negative-duration timed event outright.
            # The route layer requires both times for new saves — this only
            # guards rows from before that validation existed.
            end_dt = start_dt + _timedelta(minutes=30)
        body['start'] = {'dateTime': f"{start_dt.strftime('%Y-%m-%dT%H:%M:%S')}{offset}"}
        body['end']   = {'dateTime': f"{end_dt.strftime('%Y-%m-%dT%H:%M:%S')}{offset}"}
    return body


def insert_event(access_token: str, calendar_id: str, body: dict) -> dict:
    cal_id_q = _urlquote(calendar_id, safe='')
    req = urllib.request.Request(
        f"{_CALENDAR_API}/calendars/{cal_id_q}/events",
        data=_json.dumps(body).encode('utf-8'),
        headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"},
        method="POST")
    return _call(req)


def update_event(access_token: str, calendar_id: str, event_id: str, body: dict) -> dict:
    cal_id_q = _urlquote(calendar_id, safe='')
    evt_id_q = _urlquote(event_id, safe='')
    req = urllib.request.Request(
        f"{_CALENDAR_API}/calendars/{cal_id_q}/events/{evt_id_q}",
        data=_json.dumps(body).encode('utf-8'),
        headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"},
        method="PUT")
    return _call(req)


def delete_event_remote(access_token: str, calendar_id: str, event_id: str):
    """204 on success. 404/410 (already gone) are treated as success too —
    the end state (event absent from Google) is what matters."""
    cal_id_q = _urlquote(calendar_id, safe='')
    evt_id_q = _urlquote(event_id, safe='')
    req = urllib.request.Request(
        f"{_CALENDAR_API}/calendars/{cal_id_q}/events/{evt_id_q}",
        headers={"Authorization": f"Bearer {access_token}"},
        method="DELETE")
    try:
        with urllib.request.urlopen(req, timeout=10):
            pass
    except urllib.error.HTTPError as e:
        if e.code in (404, 410):
            return
        body = e.read().decode('utf-8', errors='replace')
        raise GcalApiError(e.code, body)


_EVENT_FIELDS = ('title', 'description', 'event_type', 'event_date', 'end_date',
                  'all_day', 'start_time', 'end_time', 'contact_id', 'job_id', 'created_by')


def push_event(db_path, event_id: int):
    """Best-effort push of a local event to Google Calendar — create if
    never synced, update if it already has a gcal_event_id. Never raises:
    a network hiccup must never block the local save that triggered this
    (same philosophy as core/licence.py's phone-home calls)."""
    from core.schedule import get_event, save_event

    try:
        settings = get_gcal_settings(db_path)
        if not settings.get('connected') or not settings.get('calendar_id'):
            return
        access_token = get_access_token(db_path)
        if not access_token:
            return
        event = get_event(db_path, event_id)
        if not event:
            return

        calendar_id = settings['calendar_id']
        body = _to_gcal_body(event)
        if event.get('gcal_event_id'):
            result = update_event(access_token, calendar_id, event['gcal_event_id'], body)
        else:
            result = insert_event(access_token, calendar_id, body)

        save_event(db_path, {
            **{k: event.get(k) for k in _EVENT_FIELDS},
            'id': event_id,
            'gcal_event_id': result['id'],
            'gcal_updated': result.get('updated'),
        })
    except Exception as e:
        # Best-effort — never re-raise (the local save this follows already
        # succeeded and must not be blocked) — but still log it, or a
        # silently-failing push is undiagnosable.
        from core.logger import log_error
        log_error(f"gcal push_event failed for schedule_events id={event_id}", e)


def push_delete(db_path, gcal_event_id: str | None):
    """Best-effort removal of a Google-linked event, called before the
    local row is deleted (so the caller still has gcal_event_id in hand)."""
    if not gcal_event_id:
        return
    try:
        settings = get_gcal_settings(db_path)
        if not settings.get('connected') or not settings.get('calendar_id'):
            return
        access_token = get_access_token(db_path)
        if not access_token:
            return
        delete_event_remote(access_token, settings['calendar_id'], gcal_event_id)
    except Exception as e:
        from core.logger import log_error
        log_error(f"gcal push_delete failed for gcal_event_id={gcal_event_id}", e)


# ── Jobs (phase 3) ────────────────────────────────────────────────────────────
# One-way push only (dbox → Google) — dbox is the source of truth for Jobs
# (it already has the full edit UI: financials, tasks, contact); Google
# Calendar is a read-only mirror for visibility on the phone. Jobs have no
# time-of-day field, so they push as all-day events. Once a job has Visits
# (schedule_events linked to it with event_type 'Visit', which carry their
# own times and sync on their own), the visits are what appear on the
# calendar and the job's all-day span is removed — otherwise a multi-week
# job shows as one long bar on top of its visits.

_JOB_ELIGIBLE_STATUSES = ('Active', 'On Hold')


def push_job(db_path, job_id: int):
    """Best-effort push of a Job to the single connected Google Calendar.
    Eligible = status Active/On Hold (excludes Lost→Cancelled and
    Complete/Invoiced/Won→Completed), start_date set, and no Visits. A job
    that becomes ineligible (status changed, start_date cleared, first visit
    added) after already being synced has its Google event removed. Callers
    that add/remove a job's visit must call this too. Never raises."""
    from core.jobs import get_job, set_job_gcal_link
    from core.schedule import job_has_visits

    try:
        job = get_job(db_path, job_id)
        if not job:
            return
        eligible = (job.get('status') in _JOB_ELIGIBLE_STATUSES
                    and bool(job.get('start_date'))
                    and not job_has_visits(db_path, job_id))

        if not eligible:
            if job.get('gcal_event_id'):
                push_delete(db_path, job['gcal_event_id'])
                set_job_gcal_link(db_path, job_id, None, None)
            return

        settings = get_gcal_settings(db_path)
        if not settings.get('connected') or not settings.get('calendar_id'):
            return
        access_token = get_access_token(db_path)
        if not access_token:
            return

        body = _to_gcal_body({
            'title':       f"{job['job_number']} – {job['name']}",
            'description': job.get('description'),
            'event_date':  job['start_date'],
            'end_date':    job.get('end_date'),
            'all_day':     True,
        })
        calendar_id = settings['calendar_id']
        if job.get('gcal_event_id'):
            result = update_event(access_token, calendar_id, job['gcal_event_id'], body)
        else:
            result = insert_event(access_token, calendar_id, body)

        set_job_gcal_link(db_path, job_id, result['id'], result.get('updated'))
    except Exception as e:
        from core.logger import log_error
        log_error(f"gcal push_job failed for job id={job_id}", e)
