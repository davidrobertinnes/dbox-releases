"""
dbox Promotional Pricing.

A promotion sets a time-limited sale price on an item.
When the item is added to an invoice/bill via the catalogue picker,
the active promo price is used instead of the standard unit_price.

Table: promotions
  id            — primary key
  item_id       — FK → items(id)
  promo_name    — display label (e.g. "Easter Sale", "Clearance")
  promo_price   — override sale price (ex-GST)
  start_date    — inclusive (YYYY-MM-DD)
  end_date      — inclusive (YYYY-MM-DD)
  is_active     — soft disable without deleting
  notes         — internal notes
  created_by    — username
  created_at    — timestamp
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from core.database import get_connection


def migrate_promotions(conn):
    """Create promotions table. Safe to call on existing databases."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS promotions (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            item_id     INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
            promo_name  TEXT NOT NULL,
            promo_price REAL NOT NULL,
            start_date  TEXT NOT NULL,
            end_date    TEXT NOT NULL,
            is_active   INTEGER NOT NULL DEFAULT 1,
            notes       TEXT,
            created_by  TEXT,
            created_at  TEXT DEFAULT (datetime('now','localtime'))
        )
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_promotions_item_date
        ON promotions(item_id, start_date, end_date)
    """)


def get_active_promotion(db_path, item_id: int, check_date: str = None) -> dict | None:
    """
    Return the active promotion for item_id on check_date (defaults to today).
    If multiple promotions overlap, returns the one with the lowest price.
    Returns None if no active promotion exists.
    """
    import datetime
    if check_date is None:
        check_date = str(datetime.date.today())

    conn = get_connection(db_path)
    row = conn.execute("""
        SELECT p.*, i.name as item_name, i.unit_price as standard_price
        FROM   promotions p
        JOIN   items i ON p.item_id = i.id
        WHERE  p.item_id   = ?
          AND  p.is_active = 1
          AND  p.start_date <= ?
          AND  p.end_date   >= ?
        ORDER  BY p.promo_price ASC
        LIMIT  1
    """, (item_id, check_date, check_date)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_promotions(db_path, item_id: int = None, active_only: bool = False,
                   include_expired: bool = True) -> list:
    """Return promotions, optionally filtered by item and/or active status."""
    import datetime
    conn = get_connection(db_path)
    where = ["1=1"]
    params = []
    if item_id is not None:
        where.append("p.item_id = ?")
        params.append(item_id)
    if active_only:
        today = str(datetime.date.today())
        where.append("p.is_active = 1")
        where.append("p.start_date <= ?")
        where.append("p.end_date   >= ?")
        params += [today, today]
    elif not include_expired:
        today = str(datetime.date.today())
        where.append("p.end_date >= ?")
        params.append(today)

    rows = conn.execute(f"""
        SELECT p.*, i.name as item_name, i.code as item_code,
               i.unit_price as standard_price
        FROM   promotions p
        JOIN   items i ON p.item_id = i.id
        WHERE  {' AND '.join(where)}
        ORDER  BY p.end_date ASC, p.item_id
    """, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_all_promotions_with_status(db_path) -> list:
    """Return all promotions with a computed status field for display."""
    import datetime
    today = str(datetime.date.today())
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT p.*, i.name as item_name, i.code as item_code,
               i.unit_price as standard_price
        FROM   promotions p
        JOIN   items i ON p.item_id = i.id
        ORDER  BY p.end_date DESC, p.start_date DESC
    """).fetchall()
    conn.close()
    result = []
    for r in rows:
        d = dict(r)
        if not d["is_active"]:
            d["_status"] = "Disabled"
        elif d["end_date"] < today:
            d["_status"] = "Expired"
        elif d["start_date"] > today:
            d["_status"] = "Scheduled"
        else:
            d["_status"] = "Active"
        # Discount %
        std = float(d.get("standard_price") or 0)
        prc = float(d.get("promo_price") or 0)
        d["_discount_pct"] = round((std - prc) / std * 100, 1) if std > 0 else 0.0
        result.append(d)
    return result


def save_promotion(db_path, data: dict) -> int:
    """Insert or update a promotion. Returns the promotion id."""
    conn = get_connection(db_path)
    pid = data.get("id")
    fields = ["item_id", "promo_name", "promo_price", "start_date",
              "end_date", "is_active", "notes", "created_by"]
    vals   = [data.get(f) for f in fields]
    if pid:
        sets = ", ".join(f"{f}=?" for f in fields)
        conn.execute(f"UPDATE promotions SET {sets} WHERE id=?", vals + [pid])
    else:
        cols = ", ".join(fields)
        ph   = ", ".join("?" for _ in fields)
        conn.execute(f"INSERT INTO promotions ({cols}) VALUES ({ph})", vals)
        pid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit()
    conn.close()
    return pid


def delete_promotion(db_path, promo_id: int):
    """Hard-delete a promotion."""
    conn = get_connection(db_path)
    conn.execute("DELETE FROM promotions WHERE id=?", (promo_id,))
    conn.commit()
    conn.close()
