# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
dbox Payroll — Australian STP Phase 2 compliant payroll engine.

Covers:
  • Employee management (TFN, bank, super fund, YTD tracking)
  • Pay runs (weekly/fortnightly/monthly) with PAYG withholding via ATO NAT1008 tax tables
  • Superannuation guarantee (11.5% FY2025-26, rising schedule built in)
  • Allowances: ordinary hours, overtime, leave (annual, personal, long-service)
  • STP Phase 2 XML payload generation (JobKeeper removed, compliant with ATO 2024 spec)
  • Payslip PDF generation via reportlab
  • Journal posting to GL
"""


import hashlib
import io
import json
import os
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP

from core.database import get_connection


# ══════════════════════════════════════════════════════════════════════════════
#  CONSTANTS & TAX TABLES
# ══════════════════════════════════════════════════════════════════════════════

# Super Guarantee rate schedule (FY -> rate)
SUPER_RATES = {
    2023: 0.1050, 2024: 0.1100, 2025: 0.1150,
    2026: 0.1150, 2027: 0.1200, 2028: 0.1200,
}

def super_rate(fy_year: int) -> float:
    return SUPER_RATES.get(fy_year, 0.115)

def current_fy() -> int:
    today = date.today()
    return today.year if today.month >= 7 else today.year - 1

PAY_FREQUENCIES = ["Weekly", "Fortnightly", "Monthly"]
MONTH_NAMES = ["Jan","Feb","Mar","Apr","May","Jun",
               "Jul","Aug","Sep","Oct","Nov","Dec"]
EMPLOYMENT_TYPES = ["Full-time", "Part-time", "Casual"]
LEAVE_TYPES = ["Annual Leave", "Personal/Carer's Leave", "Long Service Leave",
               "Unpaid Leave", "Parental Leave"]
ALLOWANCE_TYPES = ["Tool Allowance", "Car Allowance", "Meal Allowance",
                   "Uniform Allowance", "Other Allowance"]

# ── ATO 2024-25 PAYG Withholding — Marginal Rates Method ─────────────────────
# Based on ATO Schedule 1 (2024-25), including Medicare Levy (2%) and
# Low Income Tax Offset (LITO). Medicare Levy Surcharge not included.
# Source: ATO Tax Withheld Calculator methodology, 2024-25 rates.

# ── PAYG rate loader ──────────────────────────────────────────────────────────

_PAYG_TABLE_DDL = """CREATE TABLE IF NOT EXISTS payg_tax_rates (
    fy_year                 INTEGER PRIMARY KEY,
    label                   TEXT NOT NULL,
    brackets_json           TEXT NOT NULL,
    brackets_no_thresh_json TEXT NOT NULL DEFAULT '[]',
    medicare_json           TEXT NOT NULL,
    lito_json               TEXT NOT NULL,
    lito_no_thresh_json     TEXT NOT NULL DEFAULT '[]',
    help_json               TEXT NOT NULL DEFAULT '[]',
    help_method             TEXT NOT NULL DEFAULT 'whole',
    sapto_json              TEXT NOT NULL DEFAULT '{}',
    no_tfn_rate             REAL NOT NULL DEFAULT 0.47,
    notes                   TEXT,
    updated_at              TEXT DEFAULT (datetime('now','localtime')))"""


def _ensure_payg_table(conn) -> None:
    """Create payg_tax_rates if it doesn't exist. Safe to call on every access."""
    conn.execute(_PAYG_TABLE_DDL)


def load_payg_rates(db_path: str, fy_year: int) -> dict | None:
    """
    Load all PAYG withholding parameters for a financial year from the database.
    Returns keys: brackets, brackets_no_thresh, medicare, lito, lito_no_thresh,
                  help, help_method, sapto, no_tfn_rate, label.
    Returns None if not found.
    """
    import json as _json
    try:
        conn = get_connection(db_path)
        row = conn.execute(
            "SELECT * FROM payg_tax_rates WHERE fy_year=?", (fy_year,)).fetchone()
        conn.close()
        if not row:
            return None
        keys = row.keys()
        return {
            "brackets":           _json.loads(row["brackets_json"]),
            "brackets_no_thresh": _json.loads(row["brackets_no_thresh_json"] if "brackets_no_thresh_json" in keys else "[]"),
            "medicare":           _json.loads(row["medicare_json"]),
            "lito":               _json.loads(row["lito_json"]),
            "lito_no_thresh":     _json.loads(row["lito_no_thresh_json"] or "[]"),
            "help":               _json.loads(row["help_json"] or "[]"),
            "help_method":        row["help_method"] if "help_method" in keys else "whole",
            "sapto":              _json.loads(row["sapto_json"] or "{}"),
            "no_tfn_rate":        row["no_tfn_rate"],
            "label":              row["label"],
        }
    except Exception:
        return None


def save_payg_rates(db_path: str, fy_year: int, label: str,
                    brackets: list, brackets_no_thresh: list,
                    medicare: dict,
                    lito: list, lito_no_thresh: list,
                    help_table: list, sapto: dict,
                    no_tfn_rate: float = 0.47,
                    help_method: str = "whole",
                    notes: str = "") -> None:
    """Save or update all PAYG rates for a financial year."""
    import json as _json
    conn = get_connection(db_path)
    _ensure_payg_table(conn)
    conn.execute("""INSERT INTO payg_tax_rates
        (fy_year, label, brackets_json, brackets_no_thresh_json, medicare_json, lito_json,
         lito_no_thresh_json, help_json, help_method, sapto_json,
         no_tfn_rate, notes, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?, datetime('now','localtime'))
        ON CONFLICT(fy_year) DO UPDATE SET
            label=excluded.label,
            brackets_json=excluded.brackets_json,
            brackets_no_thresh_json=excluded.brackets_no_thresh_json,
            medicare_json=excluded.medicare_json,
            lito_json=excluded.lito_json,
            lito_no_thresh_json=excluded.lito_no_thresh_json,
            help_json=excluded.help_json,
            help_method=excluded.help_method,
            sapto_json=excluded.sapto_json,
            no_tfn_rate=excluded.no_tfn_rate,
            notes=excluded.notes,
            updated_at=excluded.updated_at""",
        (fy_year, label,
         _json.dumps(brackets), _json.dumps(brackets_no_thresh),
         _json.dumps(medicare),
         _json.dumps(lito), _json.dumps(lito_no_thresh),
         _json.dumps(help_table), help_method,
         _json.dumps(sapto), no_tfn_rate, notes))
    conn.commit()
    conn.close()


def list_payg_rate_years(db_path: str) -> list:
    """Return list of dicts (fy_year, label, notes, updated_at) from DB."""
    try:
        conn = get_connection(db_path)
        _ensure_payg_table(conn)
        rows = conn.execute(
            "SELECT fy_year, label, notes, updated_at FROM payg_tax_rates "
            "ORDER BY fy_year").fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except Exception:
        return []


# ── ATO Schedule 1 coefficient tables (2024-25, NAT 1004) ─────────────────────
#
# Formula:  y = a × x − b
#   y = weekly withholding (dollars, rounded to nearest dollar, 0.5 rounds up)
#   x = int(weekly_earnings) + 0.99
#
# For fortnightly/monthly earnings, convert to weekly equivalent first:
#   weekly_equiv = period_earnings / periods_per_week   (fortnightly ÷ 2, monthly ÷ (52/12))
# Then multiply result by periods_per_week.
#
# Source: ATO "Coefficients to use in formulas for withholding from weekly payments"
#         https://www.ato.gov.au/tax-rates-and-codes/payg-withholding-schedule-1-...
#         Published 17 June 2024.  Same tables apply for 2025-26 (no change to Sched 1).
#
# Each row: (weekly_earnings_upper_bound, a, b)
# Last row has upper_bound = inf.  None means no withholding in that range.

import math as _math

_SCHED1_SCALE1 = [   # No tax-free threshold
    (150,      0.1600,   0.1600),
    (371,      0.2117,   7.7550),
    (515,      0.1890,  -0.6702),  # negative b is intentional (ATO note)
    (932,      0.3227,  68.2367),
    (2246,     0.3200,  65.7202),
    (3303,     0.3900, 222.9510),
    (_math.inf, 0.4700, 487.2587),
]
_SCHED1_SCALE2 = [   # Tax-free threshold claimed
    (361,      None,      None),   # no withholding
    (500,      0.1600,   57.8462),
    (625,      0.2600,  107.8462),
    (721,      0.1800,   57.8462),
    (865,      0.1890,   64.3365),
    (1282,     0.3227,  180.0385),
    (2596,     0.3200,  176.5769),
    (3653,     0.3900,  358.3077),
    (_math.inf, 0.4700, 650.6154),
]
_SCHED1_SCALE3 = [   # Foreign residents
    (2596,     0.3000,   0.3000),
    (3653,     0.3700, 181.7308),
    (_math.inf, 0.4500, 474.0385),
]
_SCHED1_SCALE5 = [   # Full Medicare levy exemption
    (361,      None,      None),
    (721,      0.1600,   57.8462),
    (865,      0.1690,   64.3365),
    (1282,     0.3027,  180.0385),
    (2596,     0.3000,  176.5769),
    (3653,     0.3700,  358.3077),
    (_math.inf, 0.4500, 650.6154),
]
_SCHED1_SCALE6 = [   # Half Medicare levy exemption
    (361,      None,      None),
    (721,      0.1600,   57.8462),
    (843,      0.1690,   64.3365),
    (865,      0.2190,  106.4962),
    (1053,     0.3527,  222.1981),
    (1282,     0.3127,  180.0385),
    (2596,     0.3100,  176.5769),
    (3653,     0.3800,  358.3077),
    (_math.inf, 0.4600, 650.6154),
]
# Scale 4 (no TFN): flat rate, no coefficient table needed.
# Resident 47%, foreign resident 45%.  Cents ignored.


def _payg_schedule1(weekly_earnings: float, scale: list) -> int:
    """
    ATO Schedule 1 weekly withholding using coefficient table.
    y = a × (int(e) + 0.99) − b, rounded to nearest dollar (0.5 → up).
    Returns 0 for earnings in a no-withholding band (a is None).
    """
    e = int(weekly_earnings)   # truncate cents per ATO spec
    x = e + 0.99
    for upper, a, b in scale:
        if e < upper:
            if a is None:
                return 0
            y = a * x - b
            return max(0, _math.floor(y + 0.5))  # round half-up
    return 0                   # shouldn't reach here if table has inf row


# ── Core tax computation ──────────────────────────────────────────────────────

def _calc_gross_tax(income: float, brackets: list) -> float:
    """Income tax before any offsets. brackets sorted ascending by threshold."""
    active_thresh = 0.0
    active_base   = 0.0
    active_rate   = 0.0
    for threshold, base, rate in brackets:
        if income >= threshold:
            active_thresh = threshold
            active_base   = base
            active_rate   = rate
        else:
            break
    return active_base + (income - active_thresh) * active_rate


def _calc_medicare(income: float, m: dict) -> float:
    """Medicare levy with phase-in for low incomes."""
    full_start  = m.get("full_start",     26000.0)
    full_rate   = m.get("full_rate",      0.020)
    shade_start = m.get("shade_in_start", 22801.0)
    shade_rate  = m.get("shade_in_rate",  0.100)
    if income >= full_start:
        return income * full_rate
    elif income >= shade_start:
        return (income - shade_start) * shade_rate
    return 0.0


def _calc_lito(income: float, lito_bands: list) -> float:
    """
    Low Income Tax Offset.
    lito_bands: [[income_up_to, max_offset, reduction_rate_above_prev_ceiling], ...]
    Returns offset amount (always >= 0).
    """
    if not lito_bands:
        return 0.0
    prev = 0.0
    for up_to, max_off, red_rate in lito_bands:
        if income <= up_to:
            return max(0.0, max_off - (income - prev) * red_rate)
        prev = up_to
    return 0.0


def _calc_sapto(income: float, sapto: dict, couple: bool = False) -> float:
    """
    Senior Australians and Pensioners Tax Offset.
    Shades out at 12.5c per $1 over the shade-in threshold.
    Returns offset amount (>= 0).
    """
    if not sapto:
        return 0.0
    shade_rate = sapto.get("shade_rate", 0.125)
    if couple:
        max_off    = sapto.get("couple_max", 1602.0)
        shade_start = sapto.get("couple_shade_start", 28974.0)
    else:
        max_off    = sapto.get("single_max", 2230.0)
        shade_start = sapto.get("single_shade_start", 32279.0)
    reduction = max(0.0, (income - shade_start) * shade_rate) if income > shade_start else 0.0
    return max(0.0, max_off - reduction)


def _calc_help_repayment(income: float, help_table: list,
                          method: str = "whole") -> float:
    """
    HELP/VSL/SSL/ABSTUDY SSL/AASL annual compulsory repayment.

    method='whole' (2024-25 and earlier):
        help_table: [[income_from, rate], ...] — rate × entire income.

    method='marginal' (2025-26+, Universities Accord Act 2025):
        help_table: [[threshold, marginal_rate_above], ...]
        Negative rate sentinel (-0.10) = whole-income 10% above that threshold.
    """
    if not help_table or income <= 0:
        return 0.0

    if method == "marginal":
        cumulative = 0.0
        for i, (thresh, rate) in enumerate(help_table):
            if income <= thresh:
                break
            if rate < 0:
                # Whole-income sentinel (e.g. above $179,286 = 10% of total)
                return round(income * abs(rate), 2)
            next_thresh = help_table[i + 1][0] if i + 1 < len(help_table) else None
            band_top = min(income, next_thresh) if next_thresh else income
            if band_top > thresh:
                cumulative += (band_top - thresh) * rate
        return round(cumulative, 2)

    else:  # whole-income method
        active_rate = 0.0
        for threshold, rate in help_table:
            if income >= threshold:
                active_rate = rate
            else:
                break
        return round(income * active_rate, 2)


def _annual_tax_from_rates(income: float, has_threshold: bool,
                            brackets: list, medicare: dict, lito_with: list,
                            lito_no_thresh: list = None,
                            help_table: list = None,
                            help_method: str = "whole",
                            sapto: dict = None,
                            has_study_loan: bool = False,
                            is_senior: bool = False,
                            senior_couple: bool = False,
                            brackets_no_thresh: list = None) -> float:
    """
    Full annual PAYG withholding calculation (ATO Schedule 1 order):
      1. Gross income tax — Scale 1 (threshold claimed) or Scale 4 (not claimed)
         Scale 1: $18,200 tax-free zone, then 16%/30%/37%/45%
         Scale 4: 16% from dollar 1 (no free zone), then 30%/37%/45%
      2. Less LITO (with-threshold has LITO; no-threshold has none)
      3. Less SAPTO (if senior/pensioner)
      4. Plus Medicare levy
      5. Plus HELP/VSL/SSL compulsory repayment (if study loan)
    """
    if income <= 0:
        return 0.0

    if has_threshold:
        gross_tax = _calc_gross_tax(income, brackets)
        lito_val  = _calc_lito(income, lito_with)
    else:
        # Scale 4: use no-threshold brackets (no $18,200 free zone)
        # Fall back to deriving from Scale 1 brackets if no-thresh not stored
        nt_brackets = brackets_no_thresh or []
        if not nt_brackets and brackets:
            # Derive: replace the 0-rate zero band with the first marginal rate
            first_rate = next((r for _, _, r in brackets if r > 0), 0.16)
            nt_brackets = [[0, 0.0, first_rate]] + [b for b in brackets if b[0] > 0 and b[2] > 0]
        gross_tax = _calc_gross_tax(income, nt_brackets)
        lito_val  = 0.0  # No LITO without tax-free threshold (ATO Schedule 1)

    sapto_val = _calc_sapto(income, sapto or {}, couple=senior_couple) if is_senior else 0.0
    med       = _calc_medicare(income, medicare)
    net_tax   = max(0.0, gross_tax - lito_val - sapto_val + med)
    help_rep  = _calc_help_repayment(income, help_table or [], method=help_method) \
                if has_study_loan else 0.0
    return round(net_tax + help_rep, 2)


# ── Built-in constants — ATO 2024-25, Stage 3 tax cuts ───────────────────────
# Scale 1 (tax-free threshold claimed): $18,200 tax-free, then 16%/30%/37%/45%
_BUILTIN_BRACKETS = [
    [0,       0.00,    0.000],
    [18200,   0.00,    0.160],
    [45000,   4288.00, 0.300],
    [135000,  31288.00, 0.370],
    [190000,  51638.00, 0.450],
]
# Scale 4 (no threshold): 16% from $1, no free zone
_BUILTIN_BRACKETS_NO_THRESH = [
    [0,       0.00,     0.160],   # 16c from $1 (no $18,200 free zone)
    [45000,   7200.00,  0.300],   # 45000 * 0.16 = $7,200
    [135000,  34200.00, 0.370],
    [190000,  54550.00, 0.450],
]
# Medicare 2024-25: singles threshold $27,222; shade-in from $21,778
_BUILTIN_MEDICARE = {
    "full_rate": 0.020, "full_start": 27222.0,
    "shade_in_start": 21778.0, "shade_in_rate": 0.100,
}
_BUILTIN_LITO = [
    [37500,  700.0, 0.000],
    [45000,  700.0, 0.050],
    [66667,  325.0, 0.015],
    [999999,   0.0, 0.000],
]
_BUILTIN_LITO_NO_THRESH = []  # No LITO without tax-free threshold (ATO Schedule 1)

# HELP 2024-25 — whole-income rate method (NAT 3539)
_BUILTIN_HELP = [
    [0,        0.0000],
    [54435,    0.0100],
    [62851,    0.0200],
    [66621,    0.0250],
    [70619,    0.0300],
    [74856,    0.0350],
    [79347,    0.0400],
    [84108,    0.0450],
    [89155,    0.0500],
    [94504,    0.0550],
    [100175,   0.0600],
    [106186,   0.0650],
    [112557,   0.0700],
    [119310,   0.0750],
    [126468,   0.0800],
    [134057,   0.0850],
    [142101,   0.0900],
    [150627,   0.0950],
    [159664,   0.1000],
]
_BUILTIN_HELP_METHOD = "whole"

_BUILTIN_SAPTO = {
    "single_max": 2230.0, "single_shade_start": 32279.0,
    "couple_max": 1602.0, "couple_shade_start": 28974.0,
    "shade_rate": 0.125,
}


def _get_rates(db_path: str = None, fy_year: int = None) -> dict:
    """Return rate dict from DB or built-in fallback."""
    if db_path and fy_year:
        r = load_payg_rates(db_path, fy_year)
        if r:
            return r
    return {
        "brackets":           _BUILTIN_BRACKETS,
        "brackets_no_thresh": _BUILTIN_BRACKETS_NO_THRESH,
        "medicare":           _BUILTIN_MEDICARE,
        "lito":               _BUILTIN_LITO,
        "lito_no_thresh":     _BUILTIN_LITO_NO_THRESH,
        "help":               _BUILTIN_HELP,
        "help_method":        _BUILTIN_HELP_METHOD,
        "sapto":              _BUILTIN_SAPTO,
        "no_tfn_rate":        0.47,
    }


def _annual_tax_resident(income: float,
                          has_threshold: bool = True,
                          db_path: str = None,
                          fy_year: int = None,
                          has_study_loan: bool = False,
                          is_senior: bool = False,
                          senior_couple: bool = False) -> float:
    """
    Compute full annual PAYG withholding for an Australian resident.
    Loads rates from DB when db_path/fy_year provided; falls back to 2024-25 built-ins.
    """
    r = _get_rates(db_path, fy_year)
    return _annual_tax_from_rates(
        income, has_threshold,
        r["brackets"], r["medicare"],
        r["lito"], r.get("lito_no_thresh", []),
        r.get("help", []), r.get("help_method", "whole"),
        r.get("sapto", {}),
        has_study_loan=has_study_loan,
        is_senior=is_senior,
        senior_couple=senior_couple,
        brackets_no_thresh=r.get("brackets_no_thresh", []),
    )


def compute_payg(annual_income: float, has_tax_free_threshold: bool = True,
                 db_path: str = None, fy_year: int = None,
                 has_study_loan: bool = False,
                 is_senior: bool = False) -> float:
    """Weekly PAYG withholding from annual income. Rounds to nearest $1."""
    annual_tax = _annual_tax_resident(
        annual_income, has_tax_free_threshold,
        db_path=db_path, fy_year=fy_year,
        has_study_loan=has_study_loan, is_senior=is_senior)
    return max(0.0, round(annual_tax / 52))


def payg_for_period(gross_period: float, frequency: str,
                    has_tfn: bool = True,
                    has_threshold: bool = True,
                    db_path: str = None,
                    fy_year: int = None,
                    has_study_loan: bool = False,
                    is_senior: bool = False,
                    senior_couple: bool = False,
                    is_foreign_resident: bool = False,
                    medicare_exemption: str = "none") -> float:
    """
    PAYG withholding for a single pay period.

    Implements ATO Schedule 1 (NAT 1004) 2024-25 coefficient method exactly,
    matching the ATO Tax Withheld Calculator to the dollar.

    Parameters
    ----------
    gross_period      : earnings for the pay period
    frequency         : 'Weekly' | 'Fortnightly' | 'Monthly'
    has_tfn           : False → Scale 4 flat rate (47% resident, 45% foreign)
    has_threshold     : True  → Scale 2 (tax-free threshold claimed)
                        False → Scale 1 (no threshold)
    is_foreign_resident: True → Scale 3
    medicare_exemption: 'none' | 'full' (Scale 5) | 'half' (Scale 6)
    has_study_loan    : HELP/VSL/SSL repayment added (uses legacy formula method
                        as Schedule 8 coefficients are separate)
    is_senior         : SAPTO — added via legacy formula after base withholding
    """
    periods = {"Weekly": 52, "Fortnightly": 26, "Monthly": 12}.get(frequency, 26)

    # ── Scale 4: no TFN ───────────────────────────────────────────────────────
    if not has_tfn:
        rate = 0.45 if is_foreign_resident else 0.47
        return int(gross_period * rate)  # cents ignored per ATO Scale 4 rules

    # ── Convert to weekly equivalent ─────────────────────────────────────────
    # weekly_equiv = gross / (52/periods) = gross * periods / 52
    # e.g. FN $1730: 1730 * 26/52 = $865/week
    weekly = gross_period * periods / 52

    # ── Select coefficient scale ──────────────────────────────────────────────
    if is_foreign_resident:
        scale = _SCHED1_SCALE3
    elif medicare_exemption == "full":
        scale = _SCHED1_SCALE5
    elif medicare_exemption == "half":
        scale = _SCHED1_SCALE6
    elif has_threshold:
        scale = _SCHED1_SCALE2
    else:
        scale = _SCHED1_SCALE1

    weekly_wh = _payg_schedule1(weekly, scale)

    # ── Scale back to actual period ───────────────────────────────────────────
    # weekly_wh is per week; multiply by (52/periods) to get per-period amount
    # e.g. FN: weekly_wh * 52/26 = weekly_wh * 2
    period_wh = round(weekly_wh * 52 / periods)

    # ── HELP/study loan repayment (Schedule 8 — formula method) ──────────────
    if has_study_loan:
        r = _get_rates(db_path, fy_year)
        annual_income = gross_period * periods
        help_rep = _calc_help_repayment(
            annual_income, r.get("help", []), method=r.get("help_method", "whole"))
        period_wh += max(0, round(help_rep / periods))

    # ── SAPTO (seniors offset — formula method, post-base-withholding) ────────
    if is_senior:
        r = _get_rates(db_path, fy_year)
        annual_income = gross_period * periods
        sapto_annual = _calc_sapto(annual_income, r.get("sapto", {}), couple=senior_couple)
        period_wh = max(0, period_wh - round(sapto_annual / periods))

    return max(0, period_wh)

def _period_to_annual(amount: float, frequency: str) -> float:
    multipliers = {"Weekly": 52, "Fortnightly": 26, "Monthly": 12}
    return amount * multipliers.get(frequency, 26)


# ══════════════════════════════════════════════════════════════════════════════
#  DATABASE SCHEMA
# ══════════════════════════════════════════════════════════════════════════════

def migrate_payroll(conn):
    """Create all payroll tables. Safe to call multiple times."""

    conn.execute("""CREATE TABLE IF NOT EXISTS employees (
        id                  INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_number     TEXT NOT NULL UNIQUE,
        first_name          TEXT NOT NULL,
        last_name           TEXT NOT NULL,
        date_of_birth       TEXT,
        gender              TEXT,
        address             TEXT,
        city                TEXT,
        state               TEXT,
        postcode            TEXT,
        email               TEXT,
        phone               TEXT,
        -- Employment
        employment_type     TEXT NOT NULL DEFAULT 'Full-time',
        pay_frequency       TEXT NOT NULL DEFAULT 'Fortnightly',
        start_date          TEXT NOT NULL,
        termination_date    TEXT,
        position_title      TEXT,
        department          TEXT,
        -- Remuneration
        annual_salary       REAL,
        hourly_rate         REAL,
        hours_per_week      REAL NOT NULL DEFAULT 38.0,
        -- Tax
        tfn                 TEXT,
        tfn_quoted          INTEGER NOT NULL DEFAULT 1,
        has_tax_free_threshold INTEGER NOT NULL DEFAULT 1,
        study_loan          INTEGER NOT NULL DEFAULT 0,   -- HELP/HECS
        senior_offset       INTEGER NOT NULL DEFAULT 0,
        is_foreign_resident INTEGER NOT NULL DEFAULT 0,   -- Scale 3 vs Scale 1/2
        medicare_exemption  TEXT    NOT NULL DEFAULT 'none', -- none | full | half
        -- Super
        super_fund_name     TEXT,
        super_fund_abn      TEXT,
        super_fund_usi      TEXT,
        super_member_number TEXT,
        super_rate_override REAL,   -- NULL = use statutory rate
        -- Bank
        bank_bsb            TEXT,
        bank_account        TEXT,
        bank_name           TEXT,
        -- YTD accumulators (reset 1 July each year)
        ytd_gross           REAL NOT NULL DEFAULT 0,
        ytd_tax             REAL NOT NULL DEFAULT 0,
        ytd_super           REAL NOT NULL DEFAULT 0,
        ytd_allowances      REAL NOT NULL DEFAULT 0,
        ytd_leave_paid      REAL NOT NULL DEFAULT 0,
        -- STP
        stp_sent            INTEGER NOT NULL DEFAULT 0,
        is_active           INTEGER NOT NULL DEFAULT 1,
        created_at          TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS pay_runs (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        run_number      TEXT NOT NULL UNIQUE,
        pay_period_start TEXT NOT NULL,
        pay_period_end   TEXT NOT NULL,
        payment_date    TEXT NOT NULL,
        frequency       TEXT NOT NULL,
        status          TEXT NOT NULL DEFAULT 'Draft',  -- Draft, Finalised, STP_Lodged
        total_gross     REAL NOT NULL DEFAULT 0,
        total_tax       REAL NOT NULL DEFAULT 0,
        total_super     REAL NOT NULL DEFAULT 0,
        total_net       REAL NOT NULL DEFAULT 0,
        journal_id      INTEGER,
        stp_envelope    TEXT,   -- JSON of STP XML envelope sent
        stp_lodged_at   TEXT,
        created_by      INTEGER,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS payslips (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        pay_run_id      INTEGER NOT NULL REFERENCES pay_runs(id),
        employee_id     INTEGER NOT NULL REFERENCES employees(id),
        -- Pay period
        period_start    TEXT NOT NULL,
        period_end      TEXT NOT NULL,
        payment_date    TEXT NOT NULL,
        -- Earnings breakdown
        ordinary_hours  REAL NOT NULL DEFAULT 0,
        ordinary_rate   REAL NOT NULL DEFAULT 0,
        ordinary_gross  REAL NOT NULL DEFAULT 0,
        overtime_hours  REAL NOT NULL DEFAULT 0,
        overtime_rate   REAL NOT NULL DEFAULT 0,
        overtime_gross  REAL NOT NULL DEFAULT 0,
        leave_type      TEXT,
        leave_hours     REAL NOT NULL DEFAULT 0,
        leave_gross     REAL NOT NULL DEFAULT 0,
        allowances      REAL NOT NULL DEFAULT 0,
        allowances_json TEXT,   -- [{type, amount}]
        -- Deductions
        salary_sacrifice REAL NOT NULL DEFAULT 0,   -- pre-tax super
        other_deductions REAL NOT NULL DEFAULT 0,
        -- Totals
        gross_pay       REAL NOT NULL DEFAULT 0,
        payg_tax        REAL NOT NULL DEFAULT 0,
        net_pay         REAL NOT NULL DEFAULT 0,
        -- Super
        super_amount    REAL NOT NULL DEFAULT 0,
        super_ytd       REAL NOT NULL DEFAULT 0,
        -- YTD at time of payslip
        ytd_gross       REAL NOT NULL DEFAULT 0,
        ytd_tax         REAL NOT NULL DEFAULT 0,
        ytd_super       REAL NOT NULL DEFAULT 0,
        -- STP
        stp_income_type TEXT NOT NULL DEFAULT 'SAL',  -- SAL, WAG, LAB, VOL, IAA
        status          TEXT NOT NULL DEFAULT 'Calculated',
        notes           TEXT,
        UNIQUE(pay_run_id, employee_id))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS payroll_allowances (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        payslip_id  INTEGER NOT NULL REFERENCES payslips(id),
        allow_type  TEXT NOT NULL,
        description TEXT,
        amount      REAL NOT NULL)""")

    conn.execute("""CREATE TABLE IF NOT EXISTS stp_submissions (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        pay_run_id      INTEGER REFERENCES pay_runs(id),
        submission_type TEXT NOT NULL DEFAULT 'Update',  -- Update, Finalisation
        fy_year         INTEGER NOT NULL,
        submitted_at    TEXT DEFAULT (datetime('now','localtime')),
        status          TEXT NOT NULL DEFAULT 'Pending',  -- Pending, Accepted, Rejected
        payload_xml     TEXT,
        response_xml    TEXT,
        message         TEXT)""")

    # Additional employee columns (migration-safe ALTER TABLE)
    for _col, _def in [
        ("additional_withholding",  "REAL NOT NULL DEFAULT 0"),   # extra PAYG $ per period
        ("salary_sacrifice_amount", "REAL NOT NULL DEFAULT 0"),   # recurring pre-tax super $ per period
        ("voluntary_super_amount",  "REAL NOT NULL DEFAULT 0"),   # post-tax voluntary super $ per period
        ("is_foreign_resident",     "INTEGER NOT NULL DEFAULT 0"),  # Scale 3
        ("medicare_exemption",      "TEXT NOT NULL DEFAULT 'none'"), # none|full|half
        ("award_id",                "INTEGER"),                    # FK to awards
        ("classification_id",       "INTEGER"),                    # FK to award_classifications
        ("pay_point",               "INTEGER"),                    # pay point within classification
        ("pay_rate_modifier",       "REAL"),                       # e.g. 1.25 for senior loading
        ("pay_rate_modifier_type",  "TEXT"),                       # e.g. 'percentage' or 'flat'
        ("contact_id",              "INTEGER"),                    # FK to contacts (linked contact record)
    ]:
        try:
            conn.execute(f"ALTER TABLE employees ADD COLUMN {_col} {_def}")
        except Exception:
            pass

    # Payslip super remittance tracking (migration-safe)
    for _col, _def in [
        ("super_remitted",         "INTEGER NOT NULL DEFAULT 0"),
        ("super_payment_batch_id", "INTEGER"),
    ]:
        try:
            conn.execute(f"ALTER TABLE payslips ADD COLUMN {_col} {_def}")
        except Exception:
            pass

    # Super payment / remittance tables
    conn.execute("""CREATE TABLE IF NOT EXISTS super_payments (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        payment_number  TEXT NOT NULL UNIQUE,
        payment_date    TEXT NOT NULL,
        quarter         TEXT NOT NULL,          -- e.g. '2025-Q1'
        due_date        TEXT NOT NULL,          -- SG due date (28 days after quarter end)
        status          TEXT NOT NULL DEFAULT 'Draft',
                                                -- Draft | Paid | Overdue
        payment_method  TEXT DEFAULT 'SuperStream',
        reference       TEXT,                   -- bank / clearinghouse ref
        total_sgc       REAL NOT NULL DEFAULT 0,
        total_salary_sacrifice REAL NOT NULL DEFAULT 0,
        total_voluntary REAL NOT NULL DEFAULT 0,
        total_amount    REAL NOT NULL DEFAULT 0,
        journal_id      INTEGER,
        notes           TEXT,
        created_by      INTEGER,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS super_payment_lines (
        id                  INTEGER PRIMARY KEY AUTOINCREMENT,
        super_payment_id    INTEGER NOT NULL REFERENCES super_payments(id) ON DELETE CASCADE,
        employee_id         INTEGER NOT NULL REFERENCES employees(id),
        fund_name           TEXT,
        fund_abn            TEXT,
        fund_usi            TEXT,
        member_number       TEXT,
        sgc_amount          REAL NOT NULL DEFAULT 0,
        salary_sacrifice    REAL NOT NULL DEFAULT 0,
        voluntary_amount    REAL NOT NULL DEFAULT 0,
        total_amount        REAL NOT NULL DEFAULT 0,
        period_start        TEXT,
        period_end          TEXT,
        pay_run_ids         TEXT)""")   # JSON list of pay_run ids covered

    # Payroll-specific GL accounts (seed if not present)
    for code, name, atype, subtype in [
        ('2-1310', 'PAYG Withholding Payable', 'Liability', 'Current Liability'),
        ('2-1410', 'Superannuation Payable',   'Liability', 'Current Liability'),
        ('2-1420', 'Salary Sacrifice Clearing', 'Liability','Current Liability'),
        ('2-1430', 'Net Wages Payable',        'Liability', 'Current Liability'),
        ('2-1440', 'Voluntary Super Payable',  'Liability', 'Current Liability'),
        ('5-3710', 'Wages - Ordinary Time',    'Expense',   'Overhead'),
        ('5-3720', 'Wages - Overtime',         'Expense',   'Overhead'),
        ('5-3730', 'Wages - Annual Leave',     'Expense',   'Overhead'),
        ('5-3740', 'Wages - Personal Leave',   'Expense',   'Overhead'),
        ('5-3750', 'Wages - Other Leave',      'Expense',   'Overhead'),
        ('5-3760', 'Wages - Allowances',       'Expense',   'Overhead'),
        ('5-3510', 'Superannuation Expense',   'Expense',   'Overhead'),
    ]:
        try:
            conn.execute("""INSERT OR IGNORE INTO accounts
                (code,name,account_type,account_subtype,is_bank) VALUES (?,?,?,?,0)""",
                (code, name, atype, subtype))
        except Exception:
            pass

    # Leave management tables (migration-safe)
    from core.leave import migrate_leave
    migrate_leave(conn)

    # Awards & agreements tables (migration-safe)
    from core.awards import migrate_awards
    migrate_awards(conn)

    # PAYG tax rates table (migration-safe)
    conn.execute("""CREATE TABLE IF NOT EXISTS payg_tax_rates (
        fy_year                 INTEGER PRIMARY KEY,   -- e.g. 2025 = FY2024-25
        label                   TEXT NOT NULL,          -- e.g. '2024-25'
        brackets_json           TEXT NOT NULL,          -- [[threshold, base, rate], ...]
        brackets_no_thresh_json TEXT NOT NULL DEFAULT '[]',
        medicare_json           TEXT NOT NULL,          -- {full_rate, full_start, ...}
        lito_json               TEXT NOT NULL,          -- [[up_to, max_off, red_rate], ...]
        lito_no_thresh_json     TEXT NOT NULL DEFAULT '[]',
        help_json               TEXT NOT NULL DEFAULT '[]',
        help_method             TEXT NOT NULL DEFAULT 'whole',
        sapto_json              TEXT NOT NULL DEFAULT '{}',
        no_tfn_rate             REAL NOT NULL DEFAULT 0.47,
        notes                   TEXT,
        updated_at              TEXT DEFAULT (datetime('now','localtime')))""")


# ══════════════════════════════════════════════════════════════════════════════
#  EMPLOYEE CRUD
# ══════════════════════════════════════════════════════════════════════════════

def get_employees(db_path, active_only=True):
    conn = get_connection(db_path)
    q = "SELECT * FROM employees"
    if active_only:
        q += " WHERE is_active=1"
    q += " ORDER BY last_name, first_name"
    rows = conn.execute(q).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_employee(db_path, emp_id):
    conn = get_connection(db_path)
    row = conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_employee(db_path, emp_data: dict) -> int:
    """Insert or update employee. Returns employee id."""
    conn = get_connection(db_path)
    emp_id = emp_data.get("id")
    # Apply defaults for NOT NULL fields
    defaults = {
        "employment_type": "Full-time", "pay_frequency": "Fortnightly",
        "hours_per_week": 38.0, "tfn_quoted": 1, "has_tax_free_threshold": 1,
        "study_loan": 0, "senior_offset": 0, "is_active": 1,
        "additional_withholding": 0.0, "salary_sacrifice_amount": 0.0,
        "voluntary_super_amount": 0.0,
    }
    for k, v in defaults.items():
        if emp_data.get(k) is None:
            emp_data[k] = v
    fields = [
        "employee_number","first_name","last_name","date_of_birth","gender",
        "address","city","state","postcode","email","phone",
        "employment_type","pay_frequency","start_date","termination_date",
        "position_title","department","annual_salary","hourly_rate","hours_per_week",
        "tfn","tfn_quoted","has_tax_free_threshold","study_loan","senior_offset",
        "additional_withholding","salary_sacrifice_amount","voluntary_super_amount",
        "super_fund_name","super_fund_abn","super_fund_usi","super_member_number",
        "super_rate_override","bank_bsb","bank_account","bank_name","is_active",
        "award_id","classification_id","pay_point",
        "pay_rate_modifier","pay_rate_modifier_type",
        "contact_id",
    ]
    vals = [emp_data.get(f) for f in fields]
    try:
        if emp_id:
            sets = ", ".join(f"{f}=?" for f in fields)
            conn.execute(f"UPDATE employees SET {sets} WHERE id=?", vals + [emp_id])
        else:
            cols = ", ".join(fields)
            placeholders = ", ".join("?" for _ in fields)
            conn.execute(f"INSERT INTO employees ({cols}) VALUES ({placeholders})", vals)
            emp_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.commit()
    finally:
        conn.close()
    return emp_id


def next_employee_number(db_path) -> str:
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT employee_number FROM employees ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    if row:
        try:
            n = int(row[0].lstrip("EMP").lstrip("0") or "0") + 1
        except ValueError:
            n = 1
    else:
        n = 1
    return f"EMP{n:04d}"


# ══════════════════════════════════════════════════════════════════════════════
#  PAY RUN ENGINE
# ══════════════════════════════════════════════════════════════════════════════

def next_run_number(db_path) -> str:
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT run_number FROM pay_runs ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    prefix = f"PR{date.today().year}"
    if row and row[0].startswith(prefix):
        try:
            seq = int(row[0][len(prefix):]) + 1
        except ValueError:
            seq = 1
    else:
        seq = 1
    return f"{prefix}{seq:04d}"


def calculate_payslip(db_path, employee_id: int, period_start: str,
                       period_end: str, payment_date: str,
                       frequency: str,
                       ordinary_hours: float = None,
                       overtime_hours: float = 0.0,
                       leave_type: str = None,
                       leave_hours: float = 0.0,
                       allowances: list = None,
                       salary_sacrifice: float = None,   # None = use employee default
                       additional_withholding: float = None,  # None = use employee default
                       voluntary_super: float = None,    # None = use employee default
                       stp_income_type: str = "SAL") -> dict:
    """
    Calculate a payslip for one employee. Returns a payslip dict (not yet saved).
    If ordinary_hours is None, uses the employee's standard hours for the period.
    salary_sacrifice, additional_withholding, voluntary_super default to employee
    settings if not overridden.
    """
    emp = get_employee(db_path, employee_id)
    if not emp:
        raise ValueError(f"Employee {employee_id} not found")

    allowances = allowances or []
    periods = {"Weekly": 52, "Fortnightly": 26, "Monthly": 12}[frequency]

    # Use employee-level defaults if not explicitly passed
    if salary_sacrifice is None:
        salary_sacrifice = float(emp.get("salary_sacrifice_amount") or 0.0)
    if additional_withholding is None:
        additional_withholding = float(emp.get("additional_withholding") or 0.0)
    if voluntary_super is None:
        voluntary_super = float(emp.get("voluntary_super_amount") or 0.0)

    # Determine hourly rate
    if emp["hourly_rate"]:
        hourly = emp["hourly_rate"]
    elif emp["annual_salary"]:
        hourly = emp["annual_salary"] / (emp["hours_per_week"] * 52)
    elif emp.get("classification_id"):
        # Fall back to award classification rate
        from core.awards import resolve_rate_from_classification, apply_modifier
        try:
            pp = emp.get("pay_point") or 1
            resolved = resolve_rate_from_classification(db_path, emp["classification_id"], pp)
            base_hr = resolved.get("hourly_rate")
            if base_hr:
                mod = emp.get("pay_rate_modifier") or 0
                mod_type = emp.get("pay_rate_modifier_type") or "%"
                hourly = apply_modifier(base_hr, mod, mod_type)
            else:
                raise ValueError(
                    f"Employee {emp['first_name']} {emp['last_name']} has no pay rate")
        except ImportError:
            raise ValueError(
                f"Employee {emp['first_name']} {emp['last_name']} has no pay rate")
    else:
        raise ValueError(f"Employee {emp['first_name']} {emp['last_name']} has no pay rate")

    # Standard hours for period
    std_hours = emp["hours_per_week"] * 52 / periods
    if ordinary_hours is None:
        # Use max(leave_hours, 0) so a negative leave adjustment (reversal)
        # doesn't inflate ordinary_hours beyond std_hours
        ordinary_hours = max(0.0, std_hours - max(leave_hours, 0.0))

    # Earnings
    ordinary_gross = round(ordinary_hours * hourly, 2)
    overtime_rate  = round(hourly * 1.5, 4)   # 150% OT
    overtime_gross = round(overtime_hours * overtime_rate, 2)
    leave_gross    = round(leave_hours * hourly, 2)
    allow_total    = round(sum(a["amount"] for a in allowances), 2)

    gross_pay = ordinary_gross + overtime_gross + leave_gross + allow_total

    # Salary sacrifice reduces the taxable base (pre-tax super)
    salary_sacrifice = min(salary_sacrifice, gross_pay)   # can't sacrifice more than gross
    gross_after_sacrifice = max(0.0, gross_pay - salary_sacrifice)

    # PAYG withholding — use DB rates for current FY if available
    fy = current_fy()
    payg = payg_for_period(
        gross_after_sacrifice, frequency,
        has_tfn=bool(emp["tfn_quoted"]),
        has_threshold=bool(emp["has_tax_free_threshold"]),
        db_path=db_path, fy_year=fy,
        has_study_loan=bool(emp.get("study_loan", 0)),
        is_senior=bool(emp.get("senior_offset", 0)),
        is_foreign_resident=bool(emp.get("is_foreign_resident", 0)),
        medicare_exemption=emp.get("medicare_exemption") or "none")

    # Additional withholding (employee-elected extra tax) added on top
    payg = round(payg + additional_withholding, 2)

    # Post-tax voluntary super reduces net pay but doesn't affect PAYG
    voluntary_super = min(voluntary_super, max(0, gross_after_sacrifice - payg))

    net_pay = round(gross_after_sacrifice - payg - voluntary_super, 2)

    # Superannuation (on Ordinary Time Earnings - OTE)
    # SGC is calculated on OTE regardless of salary sacrifice
    sg_rate = emp["super_rate_override"] or super_rate(fy)
    ote = ordinary_gross + leave_gross + allow_total   # OTE excludes overtime
    super_sgc    = round(ote * sg_rate, 2)
    super_amount = super_sgc  # total employer super = SGC only (sacrifice tracked separately)

    # YTD snapshot (after this payslip)
    ytd_gross = round(emp["ytd_gross"] + gross_pay, 2)
    ytd_tax   = round(emp["ytd_tax"]   + payg, 2)
    ytd_super = round(emp["ytd_super"] + super_amount + salary_sacrifice, 2)

    return {
        "employee_id":          employee_id,
        "period_start":         period_start,
        "period_end":           period_end,
        "payment_date":         payment_date,
        "ordinary_hours":       ordinary_hours,
        "ordinary_rate":        hourly,
        "ordinary_gross":       ordinary_gross,
        "overtime_hours":       overtime_hours,
        "overtime_rate":        overtime_rate,
        "overtime_gross":       overtime_gross,
        "leave_type":           leave_type,
        "leave_hours":          leave_hours,
        "leave_gross":          leave_gross,
        "allowances":           allow_total,
        "allowances_json":      json.dumps(allowances),
        "salary_sacrifice":     salary_sacrifice,
        "additional_withholding": additional_withholding,
        "voluntary_super":      voluntary_super,
        "other_deductions":     0.0,
        "gross_pay":            gross_pay,
        "payg_tax":             payg,
        "net_pay":              net_pay,
        "super_amount":         super_amount,
        "super_sgc":            super_sgc,
        "ytd_gross":            ytd_gross,
        "ytd_tax":              ytd_tax,
        "ytd_super":            ytd_super,
        "stp_income_type":      stp_income_type,
        "status":               "Calculated",
        "_allowances":          allowances,
        "_employee":            emp,
    }


def create_pay_run(db_path, period_start: str, period_end: str,
                   payment_date: str, frequency: str,
                   payslips_data: list,
                   created_by: int = None) -> int:
    """
    Create a draft pay run with calculated payslips.
    payslips_data: list of dicts from calculate_payslip().
    Returns pay_run_id.
    """
    conn = get_connection(db_path)
    run_number = next_run_number(db_path)

    total_gross = sum(p["gross_pay"]    for p in payslips_data)
    total_tax   = sum(p["payg_tax"]     for p in payslips_data)
    total_super = sum(p["super_amount"] for p in payslips_data)
    total_net   = sum(p["net_pay"]      for p in payslips_data)

    conn.execute("""INSERT INTO pay_runs
        (run_number,pay_period_start,pay_period_end,payment_date,frequency,
         status,total_gross,total_tax,total_super,total_net,created_by)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (run_number, period_start, period_end, payment_date, frequency,
         "Draft", total_gross, total_tax, total_super, total_net, created_by))
    run_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    for p in payslips_data:
        conn.execute("""INSERT OR REPLACE INTO payslips
            (pay_run_id,employee_id,period_start,period_end,payment_date,
             ordinary_hours,ordinary_rate,ordinary_gross,overtime_hours,
             overtime_rate,overtime_gross,leave_type,leave_hours,leave_gross,
             allowances,allowances_json,salary_sacrifice,other_deductions,
             gross_pay,payg_tax,net_pay,super_amount,ytd_gross,ytd_tax,
             ytd_super,stp_income_type,status)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (run_id, p["employee_id"], period_start, period_end, payment_date,
             p["ordinary_hours"], p["ordinary_rate"], p["ordinary_gross"],
             p["overtime_hours"], p["overtime_rate"], p["overtime_gross"],
             p.get("leave_type"), p["leave_hours"], p["leave_gross"],
             p["allowances"], p.get("allowances_json"),
             p.get("salary_sacrifice", 0),
             p.get("other_deductions", 0)
             + p.get("additional_withholding", 0)
             + p.get("voluntary_super", 0),
             p["gross_pay"], p["payg_tax"], p["net_pay"],
             p["super_amount"], p["ytd_gross"], p["ytd_tax"], p["ytd_super"],
             p["stp_income_type"], "Calculated"))

        # Save individual allowances
        allowances = p.get("_allowances") or []
        if allowances:
            payslip_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            for a in allowances:
                conn.execute("""INSERT INTO payroll_allowances
                    (payslip_id,allow_type,description,amount)
                    VALUES (?,?,?,?)""",
                    (payslip_id, a.get("type","Other"), a.get("description",""), a["amount"]))

    conn.commit(); conn.close()
    return run_id


def finalise_pay_run(db_path, run_id: int, post_journal: bool = True) -> None:
    """
    Finalise a pay run: update YTD on employees, post to GL, mark Finalised,
    and trigger leave accruals for all payslips in the run.
    """
    # Single connection for read + YTD update (was 2 separate connections)
    conn = get_connection(db_path)
    try:
        slips = conn.execute(
            "SELECT * FROM payslips WHERE pay_run_id=?", (run_id,)).fetchall()
        run   = conn.execute(
            "SELECT * FROM pay_runs WHERE id=?", (run_id,)).fetchone()
        if not run:
            raise ValueError(f"Pay run {run_id} not found")
        if run["status"] == "Finalised":
            raise ValueError("Pay run already finalised")
        for slip in slips:
            conn.execute("""UPDATE employees SET
                ytd_gross = ytd_gross + ?,
                ytd_tax   = ytd_tax   + ?,
                ytd_super = ytd_super + ?,
                ytd_allowances = ytd_allowances + ?
                WHERE id=?""",
                (slip["gross_pay"], slip["payg_tax"],
                 slip["super_amount"], slip["allowances"],
                 slip["employee_id"]))
        conn.commit()
    finally:
        conn.close()

    # Post journal to GL
    if post_journal:
        _post_payroll_journal(db_path, run_id)

    conn = get_connection(db_path)
    conn.execute("UPDATE pay_runs SET status='Finalised' WHERE id=?", (run_id,))
    conn.execute("UPDATE payslips SET status='Final' WHERE pay_run_id=?", (run_id,))
    conn.commit(); conn.close()

    # Trigger leave accruals for all per_hour leave types.
    # Runs after the pay run is committed so a leave failure never rolls back payroll.
    try:
        from core.leave import accrue_for_payrun
        accrue_for_payrun(db_path, run_id, run["pay_period_end"])
    except Exception as _leave_ex:
        import logging
        logging.getLogger(__name__).error(
            "Leave accrual failed for pay run %s: %s", run_id, _leave_ex)


def void_pay_run(db_path, run_id: int, voided_by: str = "system") -> None:
    """
    Void a finalised pay run.

    Reverses the YTD accumulators on each employee, posts a reversal journal
    to the GL (using reverse_journal on the original payroll journal), and
    marks the run and all its payslips as Void.

    Only Finalised or STP_Lodged runs may be voided.
    """
    conn = get_connection(db_path)
    try:
        run = conn.execute(
            "SELECT * FROM pay_runs WHERE id=?", (run_id,)).fetchone()
        if not run:
            raise ValueError(f"Pay run {run_id} not found")
        if run["status"] not in ("Finalised", "STP_Lodged"):
            raise ValueError(
                f"Only Finalised pay runs can be voided "
                f"(current status: {run['status']})")

        slips = conn.execute(
            "SELECT * FROM payslips WHERE pay_run_id=?", (run_id,)).fetchall()

        # Reverse YTD accumulators
        for slip in slips:
            conn.execute("""UPDATE employees SET
                ytd_gross      = ytd_gross      - ?,
                ytd_tax        = ytd_tax        - ?,
                ytd_super      = ytd_super      - ?,
                ytd_allowances = ytd_allowances - ?
                WHERE id=?""",
                (slip["gross_pay"], slip["payg_tax"],
                 slip["super_amount"], slip["allowances"],
                 slip["employee_id"]))

        conn.execute("UPDATE pay_runs  SET status='Void' WHERE id=?",  (run_id,))
        conn.execute("UPDATE payslips  SET status='Void' WHERE pay_run_id=?", (run_id,))
        conn.commit()
    finally:
        conn.close()

    # Reverse the GL journal if one was posted
    journal_id = run["journal_id"] if "journal_id" in run.keys() else None
    if journal_id:
        try:
            from core.ledger import reverse_journal
            reverse_journal(db_path, journal_id, run["payment_date"])
        except Exception as _jex:
            import logging
            logging.getLogger(__name__).error(
                "GL reversal failed for pay run %s journal %s: %s",
                run_id, journal_id, _jex)


def _post_payroll_journal(db_path, run_id: int):
    """Post a double-entry journal for the pay run."""
    from core.ledger import post_journal as _post
    conn = get_connection(db_path)
    slips = conn.execute("SELECT * FROM payslips WHERE pay_run_id=?", (run_id,)).fetchall()
    run   = conn.execute("SELECT * FROM pay_runs WHERE id=?", (run_id,)).fetchone()

    # Look up accounts
    def acc(code):
        r = conn.execute("SELECT id FROM accounts WHERE code=?", (code,)).fetchone()
        return r["id"] if r else None

    wages_ord = acc("5-3710")
    wages_ovt = acc("5-3720")
    wages_ann = acc("5-3730")
    wages_per = acc("5-3740")
    wages_oth = acc("5-3750")
    wages_all = acc("5-3760")
    super_exp = acc("5-3510")
    payg_liab = acc("2-1310") or acc("2-1300")
    super_lia = acc("2-1410") or acc("2-1400")
    net_wages = acc("2-1430")
    conn.close()

    lines = []
    for slip in slips:
        if slip["ordinary_gross"] and wages_ord:
            lines.append({"account_id": wages_ord,
                          "debit": slip["ordinary_gross"], "credit": 0})
        if slip["overtime_gross"] and wages_ovt:
            lines.append({"account_id": wages_ovt,
                          "debit": slip["overtime_gross"], "credit": 0})
        if slip["leave_gross"] and slip["leave_type"]:
            lt = slip["leave_type"]
            acc_id = wages_ann if "Annual" in lt else (
                     wages_per if "Personal" in lt else wages_oth)
            if acc_id:
                lines.append({"account_id": acc_id,
                              "debit": slip["leave_gross"], "credit": 0})
        if slip["allowances"] and wages_all:
            lines.append({"account_id": wages_all,
                          "debit": slip["allowances"], "credit": 0})
        if slip["super_amount"] and super_exp:
            lines.append({"account_id": super_exp,
                          "debit": slip["super_amount"], "credit": 0})

    # Credits
    total_tax   = sum(s["payg_tax"]     for s in slips)
    total_super = sum(s["super_amount"] for s in slips)
    total_net   = sum(s["net_pay"]      for s in slips)
    if total_tax   and payg_liab:
        lines.append({"account_id": payg_liab,  "debit": 0, "credit": total_tax})
    if total_super and super_lia:
        lines.append({"account_id": super_lia,  "debit": 0, "credit": total_super})
    if total_net   and net_wages:
        lines.append({"account_id": net_wages,  "debit": 0, "credit": total_net})

    if not lines:
        return
    jid = _post(db_path, run["payment_date"],
                f"Payroll {run['run_number']}", run["run_number"], lines)
    conn = get_connection(db_path)
    conn.execute("UPDATE pay_runs SET journal_id=? WHERE id=?", (jid, run_id))
    conn.commit(); conn.close()


def get_pay_runs(db_path):
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT * FROM pay_runs ORDER BY payment_date DESC""").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_pay_run(db_path, run_id):
    conn = get_connection(db_path)
    run = conn.execute("SELECT * FROM pay_runs WHERE id=?", (run_id,)).fetchone()
    slips = conn.execute("""
        SELECT ps.*, e.first_name, e.last_name, e.employee_number,
               e.position_title, e.bank_bsb, e.bank_account
        FROM payslips ps JOIN employees e ON ps.employee_id=e.id
        WHERE ps.pay_run_id=? ORDER BY e.last_name, e.first_name""",
        (run_id,)).fetchall()
    conn.close()
    return dict(run) if run else None, [dict(s) for s in slips]


def get_payslips_for_employee(db_path, employee_id, limit=20):
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT ps.*, pr.run_number, pr.status as run_status
        FROM payslips ps JOIN pay_runs pr ON ps.pay_run_id=pr.id
        WHERE ps.employee_id=? ORDER BY ps.payment_date DESC LIMIT ?""",
        (employee_id, limit)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def reset_ytd(db_path):
    """Reset YTD accumulators for all employees (run on 1 July each year)."""
    conn = get_connection(db_path)
    conn.execute("""UPDATE employees SET
        ytd_gross=0, ytd_tax=0, ytd_super=0,
        ytd_allowances=0, ytd_leave_paid=0""")
    conn.commit(); conn.close()


# ══════════════════════════════════════════════════════════════════════════════
#  STP PHASE 2 XML GENERATION
# ══════════════════════════════════════════════════════════════════════════════

def generate_stp_xml(db_path, run_id: int, abn: str,
                     bms_id: str = None, submission_type: str = "Update") -> str:
    """
    Generate STP Phase 2 compliant XML payload for the given pay run.
    submission_type: 'Update' (each pay event) or 'Finalisation' (end of FY)

    The XML structure follows ATO STP Phase 2 specification:
    https://softwaredevelopers.ato.gov.au/stp-phase2

    NOTE: This generates the payload XML. Actual lodgement requires
    authorised STP software with a valid Software ID (SSID) registered
    with the ATO, and transmission via the Business to Government (B2G)
    gateway. dbox generates the payload; actual lodgement must be done
    via a registered STP channel (e.g., SuperStream, tax agent gateway).
    """
    run, slips = get_pay_run(db_path, run_id)
    if not run:
        raise ValueError(f"Pay run {run_id} not found")

    conn = get_connection(db_path)
    company = conn.execute("SELECT * FROM company").fetchone()
    conn.close()
    co = dict(company) if company else {}
    abn = abn or co.get("abn","").replace(" ","")

    fy = current_fy()
    now_iso = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    bms_id = bms_id or f"dbox-{hashlib.md5(abn.encode()).hexdigest()[:8].upper()}"

    # XML namespaces (ATO STP Phase 2 spec)
    ns = {
        "pi":  "http://payevnt.ato.gov.au/payEvent",
        "emp": "http://payevnt.ato.gov.au/employee",
        "inc": "http://payevnt.ato.gov.au/income",
        "xsi": "http://www.w3.org/2001/XMLSchema-instance",
    }
    for prefix, uri in ns.items():
        ET.register_namespace(prefix, uri)

    root = ET.Element("{http://payevnt.ato.gov.au/payEvent}InteractionHeader")
    root.set("{http://www.w3.org/2001/XMLSchema-instance}schemaLocation",
             "http://payevnt.ato.gov.au/payEvent payevnt.xsd")

    def sub(parent, tag, text=None, **attribs):
        el = ET.SubElement(parent, tag, **attribs)
        if text is not None:
            el.text = str(text)
        return el

    # Header
    hdr = sub(root, "Header")
    sub(hdr, "CreatedTimestamp", now_iso)
    sub(hdr, "InteractionType",  "PAYEVNTEMP" if submission_type == "Update" else "PAYEVNTFINAL")
    sub(hdr, "SoftwareInformation").append(ET.fromstring(
        f"<BMS_ID>{bms_id}</BMS_ID>"))
    sub(hdr, "PayerABN", abn.replace(" ",""))
    sub(hdr, "PayerBusinessName", co.get("name",""))

    # Pay event
    evt = sub(root, "PayEvent")
    sub(evt, "PayEventType", submission_type)
    sub(evt, "FYYear",       str(fy + 1))  # ATO requires end year: 2026 for FY2025-26
    sub(evt, "PayPeriodStart", run["pay_period_start"])
    sub(evt, "PayPeriodEnd",   run["pay_period_end"])
    sub(evt, "PaymentDate",    run["payment_date"])
    sub(evt, "PayFrequency",
        {"Weekly":"W","Fortnightly":"F","Monthly":"M"}[run["frequency"]])

    # Employee payroll events
    for slip in slips:
        emp = get_employee(db_path, slip["employee_id"])
        if not emp:
            continue

        ee = sub(evt, "EmployeePayrollEvent")
        id_el = sub(ee, "EmployeeIdentification")
        sub(id_el, "EmployeeIdentifier", emp["employee_number"])
        if emp.get("tfn"):
            sub(id_el, "TFN", emp["tfn"].replace(" ",""))
        else:
            sub(id_el, "TFNWithholdingIndicator", "true")
        sub(id_el, "FamilyName",   emp["last_name"])
        sub(id_el, "GivenNames",   emp["first_name"])
        if emp.get("date_of_birth"):
            sub(id_el, "DateOfBirth", emp["date_of_birth"])

        # Income statements
        inc_el = sub(ee, "IncomeStatements")
        stmt = sub(inc_el, "IncomeStatement")
        sub(stmt, "IncomeType", slip["stp_income_type"])
        sub(stmt, "GrossPayments",     f"{slip['gross_pay']:.2f}")
        sub(stmt, "PAYGWithheld",      f"{slip['payg_tax']:.2f}")
        sub(stmt, "ReportableEmployerSuper",
            f"{slip['salary_sacrifice']:.2f}")

        # Earnings breakdown (Phase 2 requires disaggregation)
        earn = sub(stmt, "Earnings")
        if slip["ordinary_gross"] > 0:
            oe = sub(earn, "EarningLine")
            sub(oe, "PaymentType",  "SAL")
            sub(oe, "Hours",        f"{slip['ordinary_hours']:.4f}")
            sub(oe, "Amount",       f"{slip['ordinary_gross']:.2f}")
        if slip["overtime_gross"] > 0:
            ote = sub(earn, "EarningLine")
            sub(ote, "PaymentType", "OVT")
            sub(ote, "Hours",       f"{slip['overtime_hours']:.4f}")
            sub(ote, "Amount",      f"{slip['overtime_gross']:.2f}")
        if slip["leave_gross"] > 0 and slip.get("leave_type"):
            lt_code = {"Annual Leave":"ANN","Personal/Carer's Leave":"PER",
                       "Long Service Leave":"LSL","Parental Leave":"MAT"}.get(
                           slip["leave_type"], "OTH")
            le = sub(earn, "EarningLine")
            sub(le, "PaymentType", lt_code)
            sub(le, "Hours",   f"{slip['leave_hours']:.4f}")
            sub(le, "Amount",  f"{slip['leave_gross']:.2f}")

        # Allowances
        if slip["allowances"] > 0:
            allow_el = sub(stmt, "Allowances")
            try:
                al_list = json.loads(slip.get("allowances_json") or "[]")
            except Exception:
                al_list = [{"type": "Other", "amount": slip["allowances"]}]
            for a in al_list:
                ae = sub(allow_el, "AllowanceLine")
                sub(ae, "AllowanceType", a.get("type", "OTH"))
                sub(ae, "Amount", f"{a['amount']:.2f}")

        # YTD
        ytd_el = sub(stmt, "YearToDateAmounts")
        sub(ytd_el, "YTDGross",  f"{slip['ytd_gross']:.2f}")
        sub(ytd_el, "YTDTax",   f"{slip['ytd_tax']:.2f}")
        sub(ytd_el, "YTDSuper", f"{slip['ytd_super']:.2f}")

        # Super
        if slip["super_amount"] > 0:
            sup_el = sub(ee, "SuperContributions")
            sc = sub(sup_el, "SuperContributionLine")
            sub(sc, "ContributionType", "SGC")
            sub(sc, "Amount",  f"{slip['super_amount']:.2f}")
            if emp.get("super_fund_name"):
                sub(sc, "FundName", emp["super_fund_name"])
            if emp.get("super_fund_abn"):
                sub(sc, "FundABN",  emp["super_fund_abn"].replace(" ",""))
            if emp.get("super_member_number"):
                sub(sc, "MemberNumber", emp["super_member_number"])

    # Produce indented XML
    ET.indent(root, space="  ")
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(
        root, encoding="unicode")


def lodge_stp(db_path, run_id: int, abn: str) -> dict:
    """
    Generate and 'lodge' STP submission.
    In production this would POST to the ATO B2G gateway via a registered
    STP software provider. Here we generate the payload and record it locally
    so it can be reviewed, printed, or sent via a tax agent / accounting firm.

    Returns: {status, payload_xml, message}
    """
    try:
        payload_xml = generate_stp_xml(db_path, run_id, abn)
    except Exception as e:
        return {"status": "Error", "payload_xml": None, "message": str(e)}

    conn = get_connection(db_path)
    run = conn.execute("SELECT * FROM pay_runs WHERE id=?", (run_id,)).fetchone()
    fy = current_fy()
    conn.execute("""INSERT INTO stp_submissions
        (pay_run_id,submission_type,fy_year,status,payload_xml,message)
        VALUES (?,?,?,?,?,?)""",
        (run_id, "Update", fy, "Pending", payload_xml,
         "XML payload generated. Provide to your tax agent or registered STP channel."))
    conn.execute("UPDATE pay_runs SET status='STP_Lodged', stp_envelope=? WHERE id=?",
                 (payload_xml, run_id))
    conn.commit(); conn.close()

    return {
        "status":      "Pending",
        "payload_xml": payload_xml,
        "message":     ("STP Phase 2 payload generated successfully.\n\n"
                        "IMPORTANT: dbox generates compliant XML payloads but is not "
                        "a registered ATO STP software channel. To lodge with the ATO, "
                        "either:\n"
                        "  1. Provide the XML to your registered tax agent\n"
                        "  2. Use a registered STP filing service\n"
                        "  3. Upload via the ATO Business Portal\n\n"
                        f"Submission recorded locally for record-keeping.")
    }


def lodge_stp_finalisation(db_path, abn: str) -> dict:
    """
    Generate an STP Phase 2 Finalisation declaration for the current financial year.

    The Finalisation event is NOT tied to a specific pay run — it is a
    year-end declaration that confirms the YTD figures reported during the year
    are final.  We use the most recent *Finalised* or *STP_Lodged* pay run as
    the source of YTD employee totals (those figures are cumulative).

    Returns: {status, payload_xml, submission_id, message}
    """
    conn = get_connection(db_path)
    # Find the most recent finalised pay run for use as YTD source
    run = conn.execute(
        """SELECT id FROM pay_runs
           WHERE status IN ('Finalised','STP_Lodged')
           ORDER BY payment_date DESC LIMIT 1"""
    ).fetchone()
    conn.close()

    if not run:
        return {
            "status": "Error",
            "payload_xml": None,
            "submission_id": None,
            "message": "No finalised pay runs found. Finalise at least one pay run before lodging a Finalisation declaration.",
        }

    run_id = run["id"]
    try:
        payload_xml = generate_stp_xml(db_path, run_id, abn,
                                       submission_type="Finalisation")
    except Exception as e:
        return {"status": "Error", "payload_xml": None, "submission_id": None,
                "message": str(e)}

    conn = get_connection(db_path)
    fy   = current_fy()
    cur  = conn.execute(
        """INSERT INTO stp_submissions
               (pay_run_id, submission_type, fy_year, status, payload_xml, message)
           VALUES (?, 'Finalisation', ?, 'Pending', ?, ?)""",
        (run_id, fy, payload_xml,
         f"FY{fy}/{fy+1} Finalisation declaration generated. "
         "Provide to your registered tax agent or STP filing service.")
    )
    submission_id = cur.lastrowid
    conn.commit(); conn.close()

    return {
        "status":        "Pending",
        "payload_xml":   payload_xml,
        "submission_id": submission_id,
        "message":       (
            f"STP Finalisation declaration for FY{fy}/{fy+1} generated successfully.\n\n"
            "This confirms the YTD figures reported during the year are final.\n\n"
            "IMPORTANT: dbox generates compliant XML payloads but is not a registered "
            "ATO STP software channel. Provide the XML to your registered tax agent or "
            "STP filing service to complete the end-of-year lodgement."
        ),
    }


def get_stp_submissions(db_path):
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT ss.*, pr.run_number
        FROM stp_submissions ss LEFT JOIN pay_runs pr ON ss.pay_run_id=pr.id
        ORDER BY ss.submitted_at DESC""").fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ══════════════════════════════════════════════════════════════════════════════
#  PAYSLIP PDF
# ══════════════════════════════════════════════════════════════════════════════

def generate_payslip_pdf(db_path, payslip_id: int = None,
                          run_id: int = None, employee_id: int = None,
                          output_path: str = None,
                          watermark: str = None, footer: str = None) -> str:
    """
    Generate a Fair Work Act compliant payslip PDF.
    Satisfies Fair Work Regulations 2009, reg 3.46 requirements.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors as rl_colors
        from reportlab.lib.units import mm
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.enums import TA_RIGHT
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                         Table, TableStyle, HRFlowable)
    except ImportError:
        raise ImportError("reportlab not installed. Run: pip install reportlab")

    import tempfile
    conn = get_connection(db_path)
    if payslip_id:
        slip = conn.execute("SELECT * FROM payslips WHERE id=?",
                            (payslip_id,)).fetchone()
    elif run_id and employee_id:
        slip = conn.execute(
            "SELECT * FROM payslips WHERE pay_run_id=? AND employee_id=?",
            (run_id, employee_id)).fetchone()
    else:
        raise ValueError("Provide payslip_id or (run_id + employee_id)")
    if not slip:
        raise ValueError("Payslip not found")
    slip = dict(slip)

    emp     = dict(conn.execute("SELECT * FROM employees WHERE id=?",
                                (slip["employee_id"],)).fetchone())
    company = conn.execute("SELECT * FROM company").fetchone()
    co      = dict(company) if company else {}

    # Award / classification name for reg 3.46(e)
    cls_name = award_name = None
    if emp.get("classification_id"):
        row = conn.execute("""SELECT ac.name AS cls, a.name AS aw
            FROM award_classifications ac
            JOIN awards a ON a.id = ac.award_id
            WHERE ac.id=?""", (emp["classification_id"],)).fetchone()
        if row:
            cls_name, award_name = row["cls"], row["aw"]

    # Leave balances for NES/s536 display
    try:
        from core.leave import get_leave_balances, hours_to_days
        SHOW_CODES = {"ANN", "SIC", "LSL", "TOIL"}
        all_bal = get_leave_balances(db_path, emp["id"])
        leave_balances = [b for b in all_bal if b.get("code") in SHOW_CODES]
    except Exception:
        leave_balances = []
        def hours_to_days(h, hpd=7.6):
            if not h: return "0d"
            d, r = divmod(float(h), hpd)
            return f"{int(d)}d {r:.1f}h" if r >= 0.1 else f"{int(d)}d"

    conn.close()

    if output_path is None:
        output_path = os.path.join(tempfile.mkdtemp(),
            f"payslip_{emp['employee_number']}_{slip['payment_date']}.pdf")

    # ── Colours & Styles ──────────────────────────────────────────────────────
    from core.invoice_pdf import _resolve_theme, _c, _load_doc_theme
    _th   = _resolve_theme(_load_doc_theme(co))
    NAVY  = _c(_th["header_bg"])
    BLUE  = _c(_th["accent_bar"])
    LTGR  = _c(_th["row_alt"])
    LTBLU = _c(_th["payment_box_bg"])
    WHITE = rl_colors.white
    GREEN = rl_colors.HexColor("#27ae60")
    LGREY = _c(_th["dim_text"])

    def sty(name, **kw):
        d = dict(fontName="Helvetica", fontSize=9, leading=12,
                 textColor=_c(_th["body_text"]))
        d.update(kw)
        return ParagraphStyle(name, **d)

    S = {
        "title": sty("title", fontName="Helvetica-Bold", fontSize=16, textColor=NAVY),
        "co":    sty("co",    fontName="Helvetica-Bold", fontSize=11, textColor=NAVY),
        "label": sty("label", fontSize=7,   textColor=LGREY, leading=9),
        "small": sty("small", fontSize=7.5, textColor=rl_colors.HexColor("#444")),
        "body":  sty("body"),
        "bold":  sty("bold",  fontName="Helvetica-Bold"),
        "right": sty("right", alignment=TA_RIGHT),
        "rbold": sty("rbold", fontName="Helvetica-Bold", alignment=TA_RIGHT),
        "green": sty("green", fontName="Helvetica-Bold", fontSize=11, textColor=GREEN),
        "rgreen":sty("rgreen",fontName="Helvetica-Bold", fontSize=11,
                      textColor=GREEN, alignment=TA_RIGHT),
    }

    def P(text, style="body"):  return Paragraph(str(text or "—"), S[style])
    def fmt(v):    return f"${float(v or 0):,.2f}"
    def fmt_h(v):  return f"{float(v or 0):.2f}"
    def hdr(text): return Paragraph(text, ParagraphStyle("hh",
        fontName="Helvetica-Bold", fontSize=7.5, textColor=WHITE, leading=10))

    doc = SimpleDocTemplate(output_path, pagesize=A4,
                            leftMargin=14*mm, rightMargin=14*mm,
                            topMargin=12*mm, bottomMargin=12*mm)
    W = 182*mm
    story = []

    # ── 1. HEADER — Employer details (reg 3.46(a)(b)) ────────────────────────
    co_name = co.get("name","") or "Company"
    abn     = co.get("abn","")
    co_lines = [P(co_name, "co")]
    if abn:          co_lines.append(P(f"ABN: {abn}", "small"))
    addr_parts = [p for p in [co.get("address",""), co.get("city",""),
                               co.get("state",""), co.get("postcode","")] if p]
    if addr_parts:   co_lines.append(P("  ".join(addr_parts), "small"))
    if co.get("phone"): co_lines.append(P(f"Ph: {co.get('phone')}", "small"))

    co_tbl = Table([[c] for c in co_lines], colWidths=[100*mm])
    co_tbl.setStyle(TableStyle([
        ("TOPPADDING",(0,0),(-1,-1),1),("BOTTOMPADDING",(0,0),(-1,-1),1),
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
    ]))
    hdr_tbl = Table([[co_tbl, P("PAYSLIP","title")]], colWidths=[100*mm, 82*mm])
    hdr_tbl.setStyle(TableStyle([
        ("VALIGN",(0,0),(-1,-1),"TOP"),
        ("ALIGN",(1,0),(1,0),"RIGHT"),
    ]))
    story.append(hdr_tbl)
    story.append(HRFlowable(width="100%", thickness=2, color=BLUE, spaceAfter=3*mm))

    # ── 2. EMPLOYEE INFO (reg 3.46(c)(d)(e)) ─────────────────────────────────
    full_name = f"{emp['first_name']} {emp['last_name']}"
    emp_addr = ", ".join(p for p in [emp.get("address",""), emp.get("city",""),
                                      emp.get("state",""), emp.get("postcode","")] if p) or "—"
    if cls_name:
        cls_str = cls_name + (f" ({award_name})" if award_name else "")
    else:
        cls_str = emp.get("employment_type","") or "—"
    tfn_str = "***-***-***" if emp.get("tfn") else               ("Not quoted — 47% rate" if not emp.get("tfn_quoted",1) else "Not on file")

    info_data = [
        [P("EMPLOYEE NAME","label"),   P("EMPLOYEE NO.","label"),
         P("TAX FILE NUMBER","label"), P("EMPLOYMENT TYPE","label")],
        [P(full_name,"bold"),          P(emp.get("employee_number",""),"bold"),
         P(tfn_str),                   P(emp.get("employment_type",""))],
        [P("ADDRESS","label"),         P("POSITION","label"),
         P("CLASSIFICATION / AWARD","label"), P("PAY FREQUENCY","label")],
        [Paragraph(emp_addr, S["small"]),
         P(emp.get("position_title","") or "—"),
         Paragraph(cls_str.replace("\n","<br/>"), S["small"]),
         P(slip.get("pay_frequency","") or emp.get("pay_frequency",""))],
    ]
    cw_info = [W*0.27, W*0.16, W*0.33, W*0.24]
    info_tbl = Table(info_data, colWidths=cw_info)
    info_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),LTGR),
        ("BACKGROUND",(0,2),(-1,2),LTGR),
        ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#ccd0e0")),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
    ]))
    story.append(info_tbl)
    story.append(Spacer(1,3*mm))

    # ── 3. PAY PERIOD (reg 3.46(f)(g)) ───────────────────────────────────────
    period_tbl = Table([
        [P("PAY PERIOD","label"), P("PAYMENT DATE","label"), P("PAY RUN REF.","label")],
        [P(f"{slip['period_start']}  to  {slip['period_end']}","bold"),
         P(slip["payment_date"],"bold"), P(f"#{slip.get('pay_run_id','')}")]
    ], colWidths=[W*0.46, W*0.30, W*0.24])
    period_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),LTBLU),
        ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#ccd0e0")),
    ]))
    story.append(period_tbl)
    story.append(Spacer(1,3*mm))

    # ── 4. EARNINGS (reg 3.46(h)(i)) ─────────────────────────────────────────
    # Each rate of pay, hours worked at each rate, and each allowance separately
    earn_rows = [[hdr("EARNINGS"), hdr("HOURS"), hdr("RATE ($/hr)"), hdr("AMOUNT ($)")]]

    if slip["ordinary_gross"] > 0:
        earn_rows.append([P("Ordinary Time"),
                          P(fmt_h(slip["ordinary_hours"]),"right"),
                          P(fmt(slip["ordinary_rate"]),"right"),
                          P(fmt(slip["ordinary_gross"]),"right")])

    if slip["overtime_gross"] > 0:
        ord_r = slip["ordinary_rate"] or 0
        ot_r  = slip["overtime_rate"]
        mult  = round(ot_r / ord_r, 1) if ord_r else 1.5
        earn_rows.append([P(f"Overtime ({mult:.1f}×)"),
                          P(fmt_h(slip["overtime_hours"]),"right"),
                          P(fmt(ot_r),"right"),
                          P(fmt(slip["overtime_gross"]),"right")])

    if slip.get("leave_gross",0) > 0:
        earn_rows.append([P(slip.get("leave_type","Leave") or "Leave"),
                          P(fmt_h(slip["leave_hours"]),"right"),
                          P(""), P(fmt(slip["leave_gross"]),"right")])

    if slip.get("allowances",0) > 0:
        try:
            al = json.loads(slip.get("allowances_json") or "[]")
        except Exception:
            al = []
        if al:
            for a in al:
                desc = a.get("type","Allowance")
                if a.get("description"):
                    desc += f" — {a['description']}"
                earn_rows.append([P(desc), P(""), P(""),
                                   P(fmt(a["amount"]),"right")])
        else:
            earn_rows.append([P("Allowances"), P(""), P(""),
                               P(fmt(slip["allowances"]),"right")])

    cw_earn = [W*0.50, W*0.16, W*0.18, W*0.16]
    earn_tbl = Table(earn_rows, colWidths=cw_earn)
    earn_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("TOPPADDING",(0,0),(-1,0),4),("BOTTOMPADDING",(0,0),(-1,0),4),
        ("TOPPADDING",(0,1),(-1,-1),3),("BOTTOMPADDING",(0,1),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[WHITE,LTGR]),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
        ("ALIGN",(1,0),(-1,-1),"RIGHT"),
    ]))
    story.append(earn_tbl)
    story.append(Spacer(1,2*mm))

    # ── 5. DEDUCTIONS (reg 3.46(j)) ──────────────────────────────────────────
    # Each deduction listed separately with purpose/recipient
    ded_rows = [[hdr("DEDUCTIONS"), hdr("RECIPIENT / PURPOSE"), hdr("AMOUNT ($)")]]
    has_ded = False

    if slip.get("payg_tax",0) > 0:
        ded_rows.append([P("PAYG Tax Withheld"),
                         P("Australian Taxation Office"),
                         P(f"({fmt(slip['payg_tax'])})","right")])
        has_ded = True

    # Show additional withholding breakdown if present
    # (stored in other_deductions when additional_withholding > 0)
    if slip.get("salary_sacrifice",0) > 0:
        ded_rows.append([P("Salary Sacrifice — Super"),
                         P(emp.get("super_fund_name","") or "Nominated super fund"),
                         P(f"({fmt(slip['salary_sacrifice'])})","right")])
        has_ded = True

    if slip.get("other_deductions",0) > 0:
        ded_rows.append([P("Other Deductions"),
                         P("See payroll administrator"),
                         P(f"({fmt(slip['other_deductions'])})","right")])
        has_ded = True

    if not has_ded:
        ded_rows.append([P("No deductions this period"), P(""), P("")])

    cw_ded = [W*0.38, W*0.44, W*0.18]
    ded_tbl = Table(ded_rows, colWidths=cw_ded)
    ded_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("TOPPADDING",(0,0),(-1,0),4),("BOTTOMPADDING",(0,0),(-1,0),4),
        ("TOPPADDING",(0,1),(-1,-1),3),("BOTTOMPADDING",(0,1),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[WHITE,LTGR]),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
        ("ALIGN",(2,0),(2,-1),"RIGHT"),
    ]))
    story.append(ded_tbl)
    story.append(Spacer(1,2*mm))

    # Gross / Net summary (reg 3.46(h) gross, reg 3.46(k) net)
    total_ded = (slip.get("payg_tax",0) + slip.get("salary_sacrifice",0)
                 + slip.get("other_deductions",0))
    sum_rows = [
        [P("Gross Pay","bold"),    P(fmt(slip["gross_pay"]),"rbold")],
        [P("Total Deductions"),    P(f"({fmt(total_ded)})","right")],
        [P("NET PAY","bold"),      P(fmt(slip["net_pay"]),"rgreen")],
    ]
    sum_tbl = Table(sum_rows, colWidths=[W*0.82, W*0.18])
    sum_tbl.setStyle(TableStyle([
        ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("LINEABOVE",(0,-1),(-1,-1),1.5,BLUE),
        ("LINEBELOW",(0,-1),(-1,-1),1.5,BLUE),
        ("BACKGROUND",(0,-1),(-1,-1),rl_colors.HexColor("#e8f5ee")),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
        ("ALIGN",(1,0),(1,-1),"RIGHT"),
    ]))
    story.append(sum_tbl)
    story.append(Spacer(1,3*mm))

    # ── 6. SUPERANNUATION (reg 3.46(l)) ──────────────────────────────────────
    # Fund name, ABN, member number, amount — all required
    super_pct = (emp.get("super_rate_override") or super_rate(current_fy())) * 100
    sup_rows = [
        [hdr("SUPERANNUATION"), hdr("FUND ABN"), hdr("MEMBER NO."),
         hdr("RATE"), hdr("THIS PERIOD")],
        [P(emp.get("super_fund_name","") or "—"),
         P(emp.get("super_fund_abn","")  or "—"),
         P(emp.get("super_member_number","") or "—"),
         P(f"{super_pct:.2f}%"),
         P(fmt(slip["super_amount"]),"right")],
    ]
    cw_sup = [W*0.36, W*0.22, W*0.18, W*0.10, W*0.14]
    sup_tbl = Table(sup_rows, colWidths=cw_sup)
    sup_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),rl_colors.HexColor("#1a6b3c")),
        ("BACKGROUND",(0,1),(-1,1),rl_colors.HexColor("#e8f5ee")),
        ("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#b8ddc8")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#b8ddc8")),
        ("ALIGN",(4,0),(4,-1),"RIGHT"),
    ]))
    story.append(sup_tbl)
    story.append(Spacer(1,3*mm))

    # ── 7. YEAR-TO-DATE ───────────────────────────────────────────────────────
    ytd_rows = [
        [hdr("YEAR TO DATE"), hdr("GROSS"), hdr("PAYG TAX"),
         hdr("SUPER"), hdr("ALLOWANCES")],
        [P("Cumulative FY Total"),
         P(fmt(slip["ytd_gross"]),"right"),
         P(fmt(slip["ytd_tax"]),"right"),
         P(fmt(slip["ytd_super"]),"right"),
         P(fmt(emp.get("ytd_allowances",0)),"right")],
    ]
    ytd_tbl = Table(ytd_rows, colWidths=[W*0.28, W*0.19, W*0.19, W*0.17, W*0.17])
    ytd_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("BACKGROUND",(0,1),(-1,1),LTBLU),
        ("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
        ("ALIGN",(1,0),(-1,-1),"RIGHT"),
    ]))
    story.append(ytd_tbl)
    story.append(Spacer(1,3*mm))

    # ── 8. LEAVE BALANCES (Fair Work Act s536, NES) ───────────────────────────
    if leave_balances:
        hpd = float(emp.get("hours_per_week",38) or 38) / 5
        lv_rows = [[hdr("LEAVE BALANCES"), hdr("ACCRUED (hrs)"), hdr("TAKEN (hrs)"),
                    hdr("BALANCE (hrs)"), hdr("BALANCE (days)")]]
        for b in leave_balances:
            acc = (b.get("accrued_hours") or 0) + (b.get("adjustment_hours") or 0)
            tak = b.get("taken_hours") or 0
            bal = acc - tak
            lv_rows.append([
                P(b.get("type_name","") or b.get("code","")),
                P(f"{acc:.2f}","right"),
                P(f"{tak:.2f}","right"),
                P(f"{bal:.2f}","right"),
                P(hours_to_days(bal,hpd),"right"),
            ])
        lv_tbl = Table(lv_rows,
                        colWidths=[W*0.36, W*0.16, W*0.16, W*0.18, W*0.14])
        lv_tbl.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0),rl_colors.HexColor("#5d4e8c")),
            ("TOPPADDING",(0,0),(-1,0),4),("BOTTOMPADDING",(0,0),(-1,0),4),
            ("TOPPADDING",(0,1),(-1,-1),3),("BOTTOMPADDING",(0,1),(-1,-1),3),
            ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[WHITE,rl_colors.HexColor("#f3f0fa")]),
            ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#c8c0e8")),
            ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#d8d0f0")),
            ("ALIGN",(1,0),(-1,-1),"RIGHT"),
        ]))
        story.append(lv_tbl)
        story.append(Spacer(1,3*mm))

    # ── 9. BANK DETAILS ───────────────────────────────────────────────────────
    if emp.get("bank_bsb") or emp.get("bank_name"):
        parts = ["Payment to:"]
        if emp.get("bank_name"):    parts.append(emp["bank_name"])
        if emp.get("bank_bsb"):     parts.append(f"BSB {emp['bank_bsb']}")
        if emp.get("bank_account"): parts.append(f"Acct {emp['bank_account']}")
        story.append(P("  ".join(parts), "small"))
        story.append(Spacer(1,2*mm))

    # ── Footer ────────────────────────────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=0.5,
                             color=rl_colors.HexColor("#ccd0e0"), spaceAfter=2*mm))
    story.append(P(
        "This payslip is issued in accordance with the Fair Work Act 2009 (Cth) s536 "
        "and Fair Work Regulations 2009 reg 3.46. Retain for your records. "
        "Queries: contact your payroll administrator.", "label"))
    if watermark:
        story.append(Spacer(1, 1*mm))
        story.append(P(watermark, "label"))

    doc.build(story)
    return output_path


def generate_payrun_report_pdf(db_path, run_id: int,
                                output_path: str = None,
                                watermark: str = None, footer: str = None) -> str:
    """
    Generate a pay run summary report PDF — management/bookkeeping copy.
    Shows employer totals, per-employee breakdown, GL posting details, and
    superannuation schedule.
    """
    try:
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib import colors as rl_colors
        from reportlab.lib.units import mm
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.enums import TA_RIGHT, TA_CENTER
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                         Table, TableStyle, HRFlowable,
                                         PageBreak)
    except ImportError:
        raise ImportError("reportlab not installed. Run: pip install reportlab")

    import tempfile
    conn = get_connection(db_path)
    run   = conn.execute("SELECT * FROM pay_runs WHERE id=?", (run_id,)).fetchone()
    if not run:
        conn.close()
        raise ValueError(f"Pay run {run_id} not found")
    run = dict(run)

    slips = conn.execute("""
        SELECT ps.*, e.first_name, e.last_name, e.employee_number,
               e.position_title, e.employment_type, e.super_fund_name,
               e.super_member_number, e.super_fund_abn
        FROM payslips ps
        JOIN employees e ON ps.employee_id = e.id
        WHERE ps.pay_run_id = ?
        ORDER BY e.last_name, e.first_name""", (run_id,)).fetchall()
    slips = [dict(s) for s in slips]

    company = conn.execute("SELECT * FROM company").fetchone()
    co = dict(company) if company else {}

    # GL journal lines for this run
    journal_lines = []
    if run.get("journal_id"):
        journal_lines = conn.execute("""
            SELECT jl.*, a.code AS acc_code, a.name AS acc_name
            FROM journal_lines jl
            JOIN accounts a ON a.id = jl.account_id
            WHERE jl.journal_id = ?
            ORDER BY jl.debit DESC""", (run["journal_id"],)).fetchall()
        journal_lines = [dict(j) for j in journal_lines]
    conn.close()

    if output_path is None:
        output_path = os.path.join(tempfile.mkdtemp(),
            f"payrun_report_{run['run_number']}_{run['payment_date']}.pdf")

    # ── Styles ────────────────────────────────────────────────────────────────
    from core.invoice_pdf import _resolve_theme, _c, _load_doc_theme
    _th   = _resolve_theme(_load_doc_theme(co))
    NAVY  = _c(_th["header_bg"])
    BLUE  = _c(_th["accent_bar"])
    LTGR  = _c(_th["row_alt"])
    LTBLU = _c(_th["payment_box_bg"])
    WHITE = rl_colors.white
    GREEN = rl_colors.HexColor("#27ae60")
    AMBER = rl_colors.HexColor("#e67e22")
    LGREY = _c(_th["dim_text"])
    DKGR  = _c(_th["dim_text"])

    def sty(name, **kw):
        d = dict(fontName="Helvetica", fontSize=9, leading=12,
                 textColor=_c(_th["body_text"]))
        d.update(kw)
        return ParagraphStyle(name, **d)

    S = {
        "title": sty("t",  fontName="Helvetica-Bold", fontSize=15, textColor=NAVY),
        "h2":    sty("h2", fontName="Helvetica-Bold", fontSize=10, textColor=NAVY),
        "label": sty("lb", fontSize=7,  textColor=LGREY, leading=9),
        "small": sty("sm", fontSize=7.5,textColor=DKGR),
        "body":  sty("bo"),
        "bold":  sty("bd", fontName="Helvetica-Bold"),
        "right": sty("ri", alignment=TA_RIGHT),
        "rbold": sty("rb", fontName="Helvetica-Bold", alignment=TA_RIGHT),
        "rgrn":  sty("rg", fontName="Helvetica-Bold", fontSize=10,
                     textColor=GREEN, alignment=TA_RIGHT),
        "ctr":   sty("ct", alignment=TA_CENTER),
        "amber": sty("am", fontName="Helvetica-Bold", textColor=AMBER),
    }

    def P(text, style="body"): return Paragraph(str(text or ""), S[style])
    def fmt(v):  return f"${float(v or 0):,.2f}"
    def fmth(v): return f"{float(v or 0):.2f}"
    def hdr(text, align="left"):
        st = "ct" if align == "center" else ("ri" if align == "right" else "label")
        return Paragraph(text, ParagraphStyle("hh",
            fontName="Helvetica-Bold", fontSize=7.5,
            textColor=WHITE, leading=10,
            alignment={"left":0,"center":1,"right":2}[align]))

    doc = SimpleDocTemplate(output_path, pagesize=A4,
                            leftMargin=14*mm, rightMargin=14*mm,
                            topMargin=12*mm, bottomMargin=12*mm)
    W = 182*mm
    story = []

    # ── HEADER ────────────────────────────────────────────────────────────────
    co_name = co.get("name","") or "Company"
    abn     = co.get("abn","")
    status_colour = GREEN if run["status"] == "Finalised" else AMBER

    co_lines = [P(co_name, "h2")]
    if abn: co_lines.append(P(f"ABN: {abn}", "small"))

    co_tbl = Table([[c] for c in co_lines], colWidths=[90*mm])
    co_tbl.setStyle(TableStyle([
        ("TOPPADDING",(0,0),(-1,-1),1),("BOTTOMPADDING",(0,0),(-1,-1),1),
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
    ]))

    title_tbl = Table([[co_tbl, P("PAY RUN REPORT", "title")]], colWidths=[90*mm, 92*mm])
    title_tbl.setStyle(TableStyle([
        ("VALIGN",(0,0),(-1,-1),"TOP"),
        ("ALIGN",(1,0),(1,0),"RIGHT"),
    ]))
    story.append(title_tbl)
    story.append(HRFlowable(width="100%", thickness=2, color=BLUE, spaceAfter=3*mm))

    # ── RUN SUMMARY BOX ───────────────────────────────────────────────────────
    status_lbl = Paragraph(run["status"],
        ParagraphStyle("sl", fontName="Helvetica-Bold", fontSize=9,
                       textColor=status_colour))

    sum_data = [
        [P("RUN NUMBER","label"), P("PERIOD","label"),
         P("PAYMENT DATE","label"), P("FREQUENCY","label"), P("STATUS","label")],
        [P(run["run_number"],"bold"),
         P(f"{run['pay_period_start']}  to  {run['pay_period_end']}","bold"),
         P(run["payment_date"],"bold"),
         P(run["frequency"]),
         status_lbl],
    ]
    sum_tbl = Table(sum_data, colWidths=[W*0.16, W*0.34, W*0.20, W*0.16, W*0.14])
    sum_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),LTGR),
        ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#ccd0e0")),
    ]))
    story.append(sum_tbl)
    story.append(Spacer(1,4*mm))

    # ── TOTALS BANNER ─────────────────────────────────────────────────────────
    n_emp = len(slips)
    tot_gross = sum(s["gross_pay"]    for s in slips)
    tot_ord   = sum(s["ordinary_gross"] for s in slips)
    tot_ot    = sum(s["overtime_gross"] for s in slips)
    tot_leave = sum(s.get("leave_gross",0) for s in slips)
    tot_allow = sum(s.get("allowances",0) for s in slips)
    tot_payg  = sum(s["payg_tax"]     for s in slips)
    tot_super = sum(s["super_amount"] for s in slips)
    tot_sal   = sum(s.get("salary_sacrifice",0) for s in slips)
    tot_net   = sum(s["net_pay"]      for s in slips)

    banner_data = [
        [hdr("EMPLOYEES"), hdr("GROSS PAY","right"), hdr("PAYG WITHHELD","right"),
         hdr("SUPER (SGC)","right"), hdr("NET PAY","right")],
        [P(str(n_emp),"bold"), P(fmt(tot_gross),"rbold"),
         P(fmt(tot_payg),"rbold"), P(fmt(tot_super),"rbold"),
         P(fmt(tot_net),"rgrn")],
    ]
    ban_tbl = Table(banner_data, colWidths=[W*0.14, W*0.22, W*0.22, W*0.20, W*0.22])
    ban_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("BACKGROUND",(0,1),(-1,1),LTBLU),
        ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
        ("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#ccd0e0")),
    ]))
    story.append(ban_tbl)
    story.append(Spacer(1,3*mm))

    # Earnings breakdown sub-totals
    earn_break = [
        [P("Ordinary Time","small"), P(fmt(tot_ord),"right")],
        [P("Overtime","small"),      P(fmt(tot_ot),"right")],
        [P("Leave","small"),         P(fmt(tot_leave),"right")],
        [P("Allowances","small"),    P(fmt(tot_allow),"right")],
        [P("Salary Sacrifice","small"), P(f"({fmt(tot_sal)})","right")],
    ]
    eb_tbl = Table(earn_break, colWidths=[W*0.25, W*0.15])
    eb_tbl.setStyle(TableStyle([
        ("TOPPADDING",(0,0),(-1,-1),2),("BOTTOMPADDING",(0,0),(-1,-1),2),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("ROWBACKGROUNDS",(0,0),(-1,-1),[WHITE, LTGR]),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
        ("ALIGN",(1,0),(1,-1),"RIGHT"),
    ]))
    story.append(P("Earnings Breakdown","label"))
    story.append(Spacer(1,1*mm))
    story.append(eb_tbl)
    story.append(Spacer(1,5*mm))

    # ── EMPLOYEE DETAIL TABLE ─────────────────────────────────────────────────
    story.append(P("Employee Detail", "h2"))
    story.append(Spacer(1,2*mm))

    det_rows = [
        [hdr("EMPLOYEE"), hdr("TYPE"), hdr("ORD HRS","right"),
         hdr("OT HRS","right"), hdr("GROSS","right"),
         hdr("PAYG","right"), hdr("SUPER","right"),
         hdr("NET","right"), hdr("STATUS")]
    ]
    for i, s in enumerate(slips):
        name = f"{s['last_name']}, {s['first_name']}"
        det_rows.append([
            P(name),
            P(s.get("employment_type","") or "", "small"),
            P(fmth(s["ordinary_hours"]), "right"),
            P(fmth(s["overtime_hours"]), "right"),
            P(fmt(s["gross_pay"]),    "right"),
            P(fmt(s["payg_tax"]),     "right"),
            P(fmt(s["super_amount"]),"right"),
            P(fmt(s["net_pay"]),      "right"),
            P(s.get("status",""),    "small"),
        ])

    # Totals row
    det_rows.append([
        P("TOTAL","bold"), P(""),
        P(fmth(sum(s["ordinary_hours"] for s in slips)),"rbold"),
        P(fmth(sum(s["overtime_hours"] for s in slips)),"rbold"),
        P(fmt(tot_gross),"rbold"),
        P(fmt(tot_payg),"rbold"),
        P(fmt(tot_super),"rbold"),
        P(fmt(tot_net),"rgrn"),
        P(""),
    ])

    cw_det = [W*0.22,W*0.09,W*0.08,W*0.07,W*0.11,W*0.10,W*0.10,W*0.11,W*0.08]
    det_tbl = Table(det_rows, colWidths=cw_det)
    det_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("TOPPADDING",(0,0),(-1,0),4),("BOTTOMPADDING",(0,0),(-1,0),4),
        ("TOPPADDING",(0,1),(-1,-1),3),("BOTTOMPADDING",(0,1),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),
        ("ROWBACKGROUNDS",(0,1),(-1,-2),[WHITE,LTGR]),
        ("BACKGROUND",(0,-1),(-1,-1),LTBLU),
        ("LINEABOVE",(0,-1),(-1,-1),1,BLUE),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
        ("ALIGN",(2,0),(-1,-1),"RIGHT"),
        ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
    ]))
    story.append(det_tbl)
    story.append(Spacer(1,5*mm))

    # ── SUPERANNUATION SCHEDULE ───────────────────────────────────────────────
    story.append(P("Superannuation Schedule", "h2"))
    story.append(Spacer(1,2*mm))

    super_rows = [
        [hdr("EMPLOYEE"), hdr("FUND NAME"), hdr("FUND ABN"),
         hdr("MEMBER NO."), hdr("AMOUNT","right")]
    ]
    super_total = 0.0
    for s in slips:
        name = f"{s['last_name']}, {s['first_name']}"
        super_rows.append([
            P(name),
            P(s.get("super_fund_name","") or "—", "small"),
            P(s.get("super_fund_abn","")  or "—", "small"),
            P(s.get("super_member_number","") or "—", "small"),
            P(fmt(s["super_amount"]), "right"),
        ])
        super_total += float(s["super_amount"] or 0)
    super_rows.append([P("TOTAL","bold"), P(""), P(""), P(""),
                        P(fmt(super_total),"rbold")])

    cw_sup = [W*0.22, W*0.30, W*0.20, W*0.16, W*0.12]
    sup_tbl = Table(super_rows, colWidths=cw_sup)
    sup_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),rl_colors.HexColor("#1a6b3c")),
        ("TOPPADDING",(0,0),(-1,0),4),("BOTTOMPADDING",(0,0),(-1,0),4),
        ("TOPPADDING",(0,1),(-1,-1),3),("BOTTOMPADDING",(0,1),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),
        ("ROWBACKGROUNDS",(0,1),(-1,-2),[WHITE, rl_colors.HexColor("#e8f5ee")]),
        ("BACKGROUND",(0,-1),(-1,-1),rl_colors.HexColor("#d4edda")),
        ("LINEABOVE",(0,-1),(-1,-1),1,GREEN),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#b8ddc8")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#b8ddc8")),
        ("ALIGN",(4,0),(4,-1),"RIGHT"),
    ]))
    story.append(sup_tbl)
    story.append(Spacer(1,5*mm))

    # ── GL JOURNAL POSTING ────────────────────────────────────────────────────
    story.append(P("General Ledger Journal", "h2"))
    if run.get("journal_id"):
        story.append(P(f"Journal #{run['journal_id']}  •  Posted {run['payment_date']}",
                       "small"))
    story.append(Spacer(1,2*mm))

    if journal_lines:
        gl_rows = [
            [hdr("ACCOUNT CODE"), hdr("ACCOUNT NAME"),
             hdr("DEBIT","right"), hdr("CREDIT","right")]
        ]
        for jl in journal_lines:
            gl_rows.append([
                P(jl.get("acc_code",""), "small"),
                P(jl.get("acc_name",""), "small"),
                P(fmt(jl["debit"])  if jl["debit"]  else "", "right"),
                P(fmt(jl["credit"]) if jl["credit"] else "", "right"),
            ])
        # Balance check
        tot_dr = sum(j["debit"]  or 0 for j in journal_lines)
        tot_cr = sum(j["credit"] or 0 for j in journal_lines)
        gl_rows.append([
            P(""), P("TOTAL","bold"),
            P(fmt(tot_dr),"rbold"), P(fmt(tot_cr),"rbold"),
        ])
        cw_gl = [W*0.14, W*0.54, W*0.16, W*0.16]
        gl_tbl = Table(gl_rows, colWidths=cw_gl)
        gl_tbl.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0),NAVY),
            ("TOPPADDING",(0,0),(-1,0),4),("BOTTOMPADDING",(0,0),(-1,0),4),
            ("TOPPADDING",(0,1),(-1,-1),3),("BOTTOMPADDING",(0,1),(-1,-1),3),
            ("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),
            ("ROWBACKGROUNDS",(0,1),(-1,-2),[WHITE,LTGR]),
            ("BACKGROUND",(0,-1),(-1,-1),LTBLU),
            ("LINEABOVE",(0,-1),(-1,-1),1,BLUE),
            ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
            ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
            ("ALIGN",(2,0),(3,-1),"RIGHT"),
        ]))
        story.append(gl_tbl)
    else:
        story.append(P("No journal posted for this pay run. "
                       "Finalise the pay run to generate GL entries.", "small"))

    story.append(Spacer(1,5*mm))

    # ── FOOTER ────────────────────────────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=0.5,
                             color=rl_colors.HexColor("#ccd0e0"), spaceAfter=2*mm))
    from datetime import datetime as _dt
    story.append(P(
        f"Generated {_dt.now().strftime('%d/%m/%Y %H:%M')}  •  {co_name}"
        + (f"  •  ABN {abn}" if abn else "")
        + "  •  CONFIDENTIAL — Payroll report for authorised personnel only.",
        "label"))

    if watermark:
        story.insert(0, Spacer(1, 2*mm))
        story.insert(0, P(watermark, "label"))

    doc.build(story)
    return output_path


# ══════════════════════════════════════════════════════════════════════════════
#  SUPERANNUATION PAYMENT MANAGEMENT
# ══════════════════════════════════════════════════════════════════════════════

def _super_quarter(payment_date: str) -> tuple:
    """Return (quarter_label, due_date) for an SGC quarter."""
    from datetime import date as _date, timedelta
    d = _date.fromisoformat(payment_date[:10])
    # SG quarters: Q1=Jul-Sep, Q2=Oct-Dec, Q3=Jan-Mar, Q4=Apr-Jun
    # Due 28 days after quarter end
    if d.month in (7, 8, 9):
        label = f"{d.year}-Q1"
        due   = _date(d.year, 10, 28)
    elif d.month in (10, 11, 12):
        label = f"{d.year}-Q2"
        due   = _date(d.year + 1, 1, 28)
    elif d.month in (1, 2, 3):
        label = f"{d.year}-Q3"
        due   = _date(d.year, 4, 28)
    else:
        label = f"{d.year}-Q4"
        due   = _date(d.year, 7, 28)
    return label, str(due)


def next_super_payment_number(db_path) -> str:
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT payment_number FROM super_payments ORDER BY id DESC LIMIT 1"
    ).fetchone()
    conn.close()
    prefix = f"SGC{date.today().year}"
    if row and row[0].startswith(prefix):
        try:
            seq = int(row[0][len(prefix):]) + 1
        except ValueError:
            seq = 1
    else:
        seq = 1
    return f"{prefix}{seq:04d}"


def get_super_payments(db_path) -> list:
    conn = get_connection(db_path)
    rows = conn.execute(
        "SELECT * FROM super_payments ORDER BY payment_date DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_super_payment(db_path, payment_id: int) -> tuple:
    """Returns (payment_dict, [line_dicts_with_emp_name])."""
    conn = get_connection(db_path)
    pmt = conn.execute(
        "SELECT * FROM super_payments WHERE id=?", (payment_id,)
    ).fetchone()
    lines = conn.execute("""
        SELECT spl.*, e.first_name, e.last_name, e.employee_number
        FROM super_payment_lines spl
        JOIN employees e ON e.id = spl.employee_id
        WHERE spl.super_payment_id = ?
        ORDER BY e.last_name, e.first_name
    """, (payment_id,)).fetchall()
    conn.close()
    return (dict(pmt) if pmt else None), [dict(l) for l in lines]


def create_super_payment(db_path, payment_date: str, quarter: str,
                          due_date: str, lines: list,
                          payment_method: str = "SuperStream",
                          reference: str = None,
                          notes: str = None,
                          created_by: int = None) -> int:
    """
    Create a super payment batch.
    lines: list of dicts with keys:
        employee_id, fund_name, fund_abn, fund_usi, member_number,
        sgc_amount, salary_sacrifice, voluntary_amount, period_start, period_end,
        pay_run_ids (list of ints)
    Returns super_payment_id.
    """
    conn = get_connection(db_path)
    pmt_number = next_super_payment_number(db_path)

    total_sgc  = round(sum(l.get("sgc_amount", 0)       for l in lines), 2)
    total_sal  = round(sum(l.get("salary_sacrifice", 0)  for l in lines), 2)
    total_vol  = round(sum(l.get("voluntary_amount", 0)  for l in lines), 2)
    total      = round(total_sgc + total_sal + total_vol, 2)

    conn.execute("""INSERT INTO super_payments
        (payment_number, payment_date, quarter, due_date, status,
         payment_method, reference, total_sgc, total_salary_sacrifice,
         total_voluntary, total_amount, notes, created_by)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (pmt_number, payment_date, quarter, due_date, "Draft",
         payment_method, reference, total_sgc, total_sal,
         total_vol, total, notes, created_by))
    pmt_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    for l in lines:
        conn.execute("""INSERT INTO super_payment_lines
            (super_payment_id, employee_id, fund_name, fund_abn, fund_usi,
             member_number, sgc_amount, salary_sacrifice, voluntary_amount,
             total_amount, period_start, period_end, pay_run_ids)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (pmt_id, l["employee_id"],
             l.get("fund_name"), l.get("fund_abn"), l.get("fund_usi"),
             l.get("member_number"),
             l.get("sgc_amount", 0), l.get("salary_sacrifice", 0),
             l.get("voluntary_amount", 0),
             round(l.get("sgc_amount", 0) + l.get("salary_sacrifice", 0)
                   + l.get("voluntary_amount", 0), 2),
             l.get("period_start"), l.get("period_end"),
             json.dumps(l.get("pay_run_ids") or [])))

        # Reserve these payslips so they don't appear in future accrual queries
        run_ids_raw = l.get("pay_run_ids") or []
        if isinstance(run_ids_raw, str):
            run_ids = [int(x) for x in run_ids_raw.split(",") if x.strip().isdigit()]
        else:
            run_ids = [int(x) for x in run_ids_raw]
        if run_ids:
            ph = ",".join("?" * len(run_ids))
            conn.execute(
                f"""UPDATE payslips SET super_payment_batch_id = ?
                    WHERE employee_id = ? AND pay_run_id IN ({ph})
                      AND super_payment_batch_id IS NULL AND super_remitted = 0""",
                [pmt_id, l["employee_id"]] + run_ids,
            )

    conn.commit()
    conn.close()
    return pmt_id


def finalise_super_payment(db_path, payment_id: int,
                             post_journal: bool = True) -> None:
    """Mark super payment as Paid, stamp covered payslips, optionally post GL journal."""
    conn = get_connection(db_path)
    pmt = conn.execute(
        "SELECT * FROM super_payments WHERE id=?", (payment_id,)
    ).fetchone()
    if not pmt:
        conn.close()
        raise ValueError(f"Super payment {payment_id} not found")
    if dict(pmt)["status"] == "Paid":
        conn.close()
        raise ValueError("Super payment already marked Paid")

    conn.execute("UPDATE super_payments SET status='Paid' WHERE id=?", (payment_id,))

    # Mark all payslips covered by lines in this batch as remitted
    lines = conn.execute(
        "SELECT * FROM super_payment_lines WHERE super_payment_id=?", (payment_id,)
    ).fetchall()
    for line in lines:
        pay_run_ids_raw = dict(line).get("pay_run_ids") or ""
        emp_id          = dict(line)["employee_id"]
        # pay_run_ids stored as JSON array e.g. "[1, 2, 3]"
        run_ids = []
        try:
            import json as _json
            parsed = _json.loads(pay_run_ids_raw)
            if isinstance(parsed, list):
                run_ids = [int(x) for x in parsed if str(x).lstrip("-").isdigit()]
        except Exception:
            # fallback: comma-separated string
            run_ids = [int(x) for x in pay_run_ids_raw.split(",")
                       if x.strip().lstrip("-").isdigit()]
        if run_ids:
            ph = ",".join("?" * len(run_ids))
            conn.execute(f"""
                UPDATE payslips
                SET super_remitted = 1, super_payment_batch_id = ?
                WHERE employee_id = ? AND pay_run_id IN ({ph})
                  AND super_remitted = 0
            """, [payment_id, emp_id] + run_ids)

    conn.commit()
    conn.close()

    if post_journal:
        _post_super_payment_journal(db_path, payment_id)


def _post_super_payment_journal(db_path, payment_id: int):
    """Post GL journal: Dr Super Payable / Cr Bank (or Clearing)."""
    from core.ledger import post_journal as _post
    conn = get_connection(db_path)
    pmt   = dict(conn.execute(
        "SELECT * FROM super_payments WHERE id=?", (payment_id,)).fetchone())

    def acc(code):
        r = conn.execute("SELECT id FROM accounts WHERE code=?", (code,)).fetchone()
        return r["id"] if r else None

    super_payable = acc("2-1410")
    sal_sac_clear = acc("2-1420")
    vol_super     = acc("2-1440")
    bank_acc      = conn.execute(
        "SELECT id FROM accounts WHERE is_bank=1 ORDER BY id LIMIT 1"
    ).fetchone()
    bank_id = bank_acc["id"] if bank_acc else None
    conn.close()

    lines = []
    if pmt["total_sgc"] and super_payable:
        lines.append({"account_id": super_payable,
                      "debit": pmt["total_sgc"], "credit": 0})
    if pmt["total_salary_sacrifice"] and sal_sac_clear:
        lines.append({"account_id": sal_sac_clear,
                      "debit": pmt["total_salary_sacrifice"], "credit": 0})
    if pmt["total_voluntary"] and vol_super:
        lines.append({"account_id": vol_super,
                      "debit": pmt["total_voluntary"], "credit": 0})
    if bank_id and pmt["total_amount"]:
        lines.append({"account_id": bank_id,
                      "debit": 0, "credit": pmt["total_amount"]})

    if not lines:
        return
    jid = _post(db_path, pmt["payment_date"],
                f"Super Payment {pmt['payment_number']}",
                pmt["payment_number"], lines)
    conn = get_connection(db_path)
    conn.execute("UPDATE super_payments SET journal_id=? WHERE id=?",
                 (jid, payment_id))
    conn.commit()
    conn.close()


def get_super_accruals(db_path, from_date: str = None,
                        to_date: str = None) -> list:
    """
    Return unpaid (not yet remitted) super accruals from finalised pay runs,
    grouped by employee.  Payslips already covered by a paid super payment
    batch are excluded via the super_remitted flag.
    """
    conn = get_connection(db_path)
    where = "WHERE pr.status IN ('Finalised','STP_Lodged') AND ps.super_remitted = 0 AND ps.super_payment_batch_id IS NULL"
    params = []
    if from_date:
        where += " AND pr.pay_period_start >= ?"
        params.append(from_date)
    if to_date:
        where += " AND pr.pay_period_end <= ?"
        params.append(to_date)

    rows = conn.execute(f"""
        SELECT
            e.id AS employee_id,
            e.first_name, e.last_name, e.employee_number,
            e.super_fund_name, e.super_fund_abn, e.super_fund_usi,
            e.super_member_number,
            SUM(ps.super_amount)      AS sgc_total,
            SUM(ps.salary_sacrifice)  AS salary_sacrifice_total,
            MIN(pr.pay_period_start)  AS period_start,
            MAX(pr.pay_period_end)    AS period_end,
            GROUP_CONCAT(pr.id)       AS pay_run_ids,
            GROUP_CONCAT(ps.id)       AS payslip_ids
        FROM payslips ps
        JOIN pay_runs pr ON pr.id = ps.pay_run_id
        JOIN employees e ON e.id  = ps.employee_id
        {where}
        GROUP BY e.id
        ORDER BY e.last_name, e.first_name
    """, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def generate_super_remittance_pdf(db_path, payment_id: int,
                                   output_path: str = None) -> str:
    """
    Generate a SuperStream-style remittance advice PDF for a super payment batch.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors as rl_colors
        from reportlab.lib.units import mm
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.enums import TA_RIGHT
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                         Table, TableStyle, HRFlowable)
    except ImportError:
        raise ImportError("reportlab not installed.")

    import tempfile
    pmt, lines = get_super_payment(db_path, payment_id)
    if not pmt:
        raise ValueError(f"Super payment {payment_id} not found")

    conn = get_connection(db_path)
    company = conn.execute("SELECT * FROM company").fetchone()
    co = dict(company) if company else {}
    conn.close()

    if output_path is None:
        output_path = os.path.join(tempfile.mkdtemp(),
            f"super_remittance_{pmt['payment_number']}.pdf")

    from core.invoice_pdf import _resolve_theme, _c, _load_doc_theme
    _th   = _resolve_theme(_load_doc_theme(co))
    NAVY  = _c(_th["header_bg"])
    BLUE  = _c(_th["accent_bar"])
    GREEN = rl_colors.HexColor("#27ae60")
    LTGR  = _c(_th["row_alt"])
    LTGRN = rl_colors.HexColor("#e8f5ee")   # semantic — super-allocated rows
    WHITE = rl_colors.white
    LGREY = _c(_th["dim_text"])
    AMBER = rl_colors.HexColor("#e67e22")

    def sty(name, **kw):
        d = dict(fontName="Helvetica", fontSize=9, leading=12,
                 textColor=_c(_th["body_text"]))
        d.update(kw); return ParagraphStyle(name, **d)

    S = {
        "title": sty("t",  fontName="Helvetica-Bold", fontSize=15, textColor=NAVY),
        "h2":    sty("h2", fontName="Helvetica-Bold", fontSize=10, textColor=NAVY),
        "label": sty("lb", fontSize=7,  textColor=LGREY, leading=9),
        "small": sty("sm", fontSize=7.5, textColor=LGREY),
        "body":  sty("bo"),
        "bold":  sty("bd", fontName="Helvetica-Bold"),
        "right": sty("ri", fontSize=8, leading=10, alignment=TA_RIGHT),
        "rbold": sty("rb", fontName="Helvetica-Bold", fontSize=8, leading=10, alignment=TA_RIGHT),
        "rgrn":  sty("rg", fontName="Helvetica-Bold", fontSize=8, leading=10,
                     textColor=GREEN, alignment=TA_RIGHT),
    }

    def P(text, style="body"): return Paragraph(str(text or ""), S[style])
    def fmt(v): return f"${float(v or 0):,.2f}"
    def _fmt_quarter(q):
        # Convert stored "2026-Q4" → "Q4 2025-26" (Australian FY labelling)
        # Q1=Jul-Sep, Q2=Oct-Dec, Q3=Jan-Mar, Q4=Apr-Jun
        # The year stored is the calendar year of the payment date
        try:
            year, qnum = q.split("-")
            year = int(year)
            q_labels = {
                "Q1": f"Q1 {year}-{str(year+1)[-2:]}",
                "Q2": f"Q2 {year}-{str(year+1)[-2:]}",
                "Q3": f"Q3 {year-1}-{str(year)[-2:]}",
                "Q4": f"Q4 {year-1}-{str(year)[-2:]}",
            }
            return q_labels.get(qnum, q)
        except Exception:
            return q or "—"
    def hdr(text, align="left"):
        return Paragraph(text, ParagraphStyle("hh",
            fontName="Helvetica-Bold", fontSize=7.5,
            textColor=WHITE, leading=10,
            alignment={"left":0,"right":2}.get(align,0)))

    def dhdr(text, align="left"):
        """Smaller header for the detail table — fits narrow numeric columns."""
        return Paragraph(text, ParagraphStyle("dhh",
            fontName="Helvetica-Bold", fontSize=7,
            textColor=WHITE, leading=9,
            alignment={"left":0,"right":2}.get(align,0)))

    doc = SimpleDocTemplate(output_path, pagesize=A4,
                            leftMargin=14*mm, rightMargin=14*mm,
                            topMargin=12*mm, bottomMargin=12*mm)
    W = 182*mm
    story = []

    # Header
    co_name = co.get("name","") or "Employer"
    abn     = co.get("abn","")
    co_block = [P(co_name, "h2")]
    if abn: co_block.append(P(f"ABN: {abn}", "small"))

    co_tbl = Table([[c] for c in co_block], colWidths=[90*mm])
    co_tbl.setStyle(TableStyle([
        ("TOPPADDING",(0,0),(-1,-1),1),("BOTTOMPADDING",(0,0),(-1,-1),1),
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
    ]))
    hdr_tbl = Table([[co_tbl, P("SUPERANNUATION\nREMITTANCE ADVICE","title")]],
                     colWidths=[90*mm, 92*mm])
    hdr_tbl.setStyle(TableStyle([
        ("VALIGN",(0,0),(-1,-1),"TOP"),("ALIGN",(1,0),(1,0),"RIGHT"),
    ]))
    story.append(hdr_tbl)
    story.append(HRFlowable(width="100%", thickness=2, color=GREEN, spaceAfter=3*mm))

    # Payment summary
    status_col = GREEN if pmt["status"] == "Paid" else AMBER
    status_lbl = Paragraph(pmt["status"],
        ParagraphStyle("sc", fontName="Helvetica-Bold", fontSize=9,
                       textColor=status_col))
    sum_data = [
        [P("PAYMENT NO.","label"), P("PAYMENT DATE","label"),
         P("QUARTER","label"),    P("DUE DATE","label"),
         P("METHOD","label"),     P("STATUS","label")],
        [P(pmt["payment_number"],"bold"), P(pmt["payment_date"],"bold"),
         P(_fmt_quarter(pmt["quarter"])), P(pmt["due_date"]),
         P(pmt.get("payment_method","SuperStream")), status_lbl],
    ]
    sum_tbl = Table(sum_data,
                    colWidths=[W*0.16,W*0.16,W*0.14,W*0.14,W*0.20,W*0.20])
    sum_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),LTGR),
        ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#ccd0e0")),
    ]))
    story.append(sum_tbl)
    story.append(Spacer(1,3*mm))

    # Totals banner
    ban_data = [
        [hdr("SGC (EMPLOYER)","right"), hdr("SALARY SACRIFICE","right"),
         hdr("VOLUNTARY","right"),       hdr("TOTAL","right")],
        [P(fmt(pmt["total_sgc"]),"rgrn"),
         P(fmt(pmt["total_salary_sacrifice"]),"rbold"),
         P(fmt(pmt["total_voluntary"]),"rbold"),
         P(fmt(pmt["total_amount"]),"rgrn")],
    ]
    ban_tbl = Table(ban_data, colWidths=[W*0.25]*4)
    ban_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),rl_colors.HexColor("#1a6b3c")),
        ("BACKGROUND",(0,1),(-1,1),LTGRN),
        ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
        ("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#b8ddc8")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#b8ddc8")),
    ]))
    story.append(ban_tbl)
    story.append(Spacer(1,4*mm))

    # Employee lines
    story.append(P("Employee Contribution Details", "h2"))
    story.append(Spacer(1,2*mm))

    det_rows = [
        [dhdr("EMPLOYEE"), dhdr("FUND NAME"), dhdr("FUND ABN"),
         dhdr("MEMBER NO."), dhdr("SGC","right"),
         dhdr("SAL. SAC.","right"), dhdr("VOLUNTARY","right"), dhdr("TOTAL","right")]
    ]
    for l in lines:
        name = f"{l.get('last_name','')}, {l.get('first_name','')}"
        det_rows.append([
            P(name),
            P(l.get("fund_name","") or "—", "small"),
            P(l.get("fund_abn","")  or "—", "small"),
            P(l.get("member_number","") or "—", "small"),
            P(fmt(l["sgc_amount"]),       "right"),
            P(fmt(l["salary_sacrifice"]), "right"),
            P(fmt(l["voluntary_amount"]), "right"),
            P(fmt(l["total_amount"]),     "right"),
        ])
    # Totals row
    # Totals row uses slightly smaller font to guarantee no wrap in narrow cols
    def Pamt(v, bold=False):
        st = "rbold" if bold else "right"
        return Paragraph(fmt(v), ParagraphStyle("amt",
            fontName="Helvetica-Bold" if bold else "Helvetica",
            fontSize=8, leading=10, alignment=2,
            textColor=GREEN if bold else rl_colors.HexColor("#1a1a2e")))

    det_rows.append([
        P("TOTAL","bold"), P(""), P(""), P(""),
        Pamt(pmt["total_sgc"], bold=True),
        Pamt(pmt["total_salary_sacrifice"]),
        Pamt(pmt["total_voluntary"]),
        Pamt(pmt["total_amount"], bold=True),
    ])

    cw_det = [W*0.17, W*0.165, W*0.13, W*0.11, W*0.105, W*0.105, W*0.105, W*0.11]
    det_tbl = Table(det_rows, colWidths=cw_det)
    det_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("TOPPADDING",(0,0),(-1,0),4),("BOTTOMPADDING",(0,0),(-1,0),4),
        ("TOPPADDING",(0,1),(-1,-1),3),("BOTTOMPADDING",(0,1),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),2),("RIGHTPADDING",(0,0),(-1,-1),2),
        ("ROWBACKGROUNDS",(0,1),(-1,-2),[WHITE, LTGR]),
        ("BACKGROUND",(0,-1),(-1,-1),LTGRN),
        ("LINEABOVE",(0,-1),(-1,-1),1,GREEN),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
        ("ALIGN",(4,0),(-1,-1),"RIGHT"),
    ]))
    story.append(det_tbl)
    story.append(Spacer(1,5*mm))

    # Reference + notes
    if pmt.get("reference"):
        story.append(P(f"Payment Reference: {pmt['reference']}", "bold"))
        story.append(Spacer(1,2*mm))
    if pmt.get("notes"):
        story.append(P(f"Notes: {pmt['notes']}", "small"))
        story.append(Spacer(1,2*mm))

    # Footer
    story.append(HRFlowable(width="100%", thickness=0.5,
                             color=rl_colors.HexColor("#ccd0e0"), spaceAfter=2*mm))
    from datetime import datetime as _dt
    story.append(P(
        f"Generated {_dt.now().strftime('%d/%m/%Y %H:%M')}  •  {co_name}"
        + (f"  •  ABN {abn}" if abn else "")
        + "  •  SuperStream compliant remittance. Retain for your records.",
        "label"))

    doc.build(story)
    return output_path


# ══════════════════════════════════════════════════════════════════════════════
#  PAYG PAYMENT SUMMARY (GROUP CERTIFICATES)
# ══════════════════════════════════════════════════════════════════════════════

def get_payg_summary(db_path: str, financial_year: int,
                      employee_id: int = None) -> list:
    """
    Build PAYG Payment Summary data for all (or one) employee(s) for
    the given financial year (e.g. 2025 = FY 2024-25).

    Aggregates finalised payslips in the FY period (1 July – 30 June).
    Returns list of dicts, one per employee, with:
        employee_id, employee_name, tfn, address,
        gross_wages, payg_withheld, super_employer,
        salary_sacrifice_super, other_deductions,
        allowances_total, allowances_breakdown,
        lump_sum_a, lump_sum_b, lump_sum_d, lump_sum_e,
        reportable_fringe_benefits,
        cdep_payments,
        financial_year
    """
    from core.database import get_connection as _gc
    conn = _gc(db_path)

    fy_start = f"{financial_year - 1}-07-01"
    fy_end   = f"{financial_year}-06-30"

    # Get all finalised payslips in range
    q = """
        SELECT
            ps.employee_id,
            e.first_name || ' ' || e.last_name   AS employee_name,
            e.tfn,
            e.address || COALESCE(', ' || e.city, '') || COALESCE(', ' || e.state, '') || COALESCE(' ' || e.postcode, '') AS full_address,
            e.employment_type,
            e.start_date,
            e.termination_date,
            COALESCE(SUM(ps.gross_pay), 0)        AS gross_wages,
            COALESCE(SUM(ps.payg_tax), 0)         AS payg_withheld,
            COALESCE(SUM(ps.super_amount), 0)     AS super_employer,
            COALESCE(SUM(ps.salary_sacrifice), 0) AS salary_sacrifice_super,
            COALESCE(SUM(ps.other_deductions), 0) AS other_deductions,
            COALESCE(SUM(ps.allowances), 0)       AS allowances_total,
            GROUP_CONCAT(ps.allowances_json)       AS all_allowances_json
        FROM payslips ps
        JOIN employees e ON ps.employee_id = e.id
        JOIN pay_runs  pr ON ps.pay_run_id  = pr.id
        WHERE pr.payment_date BETWEEN ? AND ?
          AND pr.status IN ('Finalised', 'STP_Lodged')
    """
    params = [fy_start, fy_end]
    if employee_id:
        q += " AND ps.employee_id = ?"
        params.append(employee_id)
    q += " GROUP BY ps.employee_id ORDER BY e.last_name, e.first_name"

    rows = conn.execute(q, params).fetchall()

    results = []
    for r in rows:
        r = dict(r)

        # Aggregate allowances breakdown from JSON blobs
        breakdown = {}
        try:
            import json as _j
            if r.get("all_allowances_json"):
                for chunk in r["all_allowances_json"].split(",{"):
                    chunk = chunk if chunk.startswith("[") or chunk.startswith("{") else "{" + chunk
                    try:
                        items = _j.loads(chunk) if isinstance(_j.loads(chunk), list) else [_j.loads(chunk)]
                        for item in items:
                            atype = item.get("type", "Other")
                            breakdown[atype] = breakdown.get(atype, 0) + float(item.get("amount", 0))
                    except Exception:
                        pass
        except Exception:
            pass

        # Get company super contributions (SGC only, not salary sacrifice)
        # Already included in super_amount field of payslips

        results.append({
            "employee_id":           r["employee_id"],
            "employee_name":         r["employee_name"],
            "employment_type":       r.get("employment_type") or "—",
            "tfn":                   r.get("tfn") or "Not quoted",
            "address":               r.get("full_address") or "",
            "gross_wages":           round(r["gross_wages"], 2),
            "payg_withheld":         round(r["payg_withheld"], 2),
            "super_employer":        round(r["super_employer"], 2),
            "salary_sacrifice_super":round(r["salary_sacrifice_super"], 2),
            "other_deductions":      round(r["other_deductions"], 2),
            "allowances_total":      round(r["allowances_total"], 2),
            "allowances_breakdown":  breakdown,
            # These fields require manual entry (future enhancement)
            "lump_sum_a":            0.0,
            "lump_sum_b":            0.0,
            "lump_sum_d":            0.0,
            "lump_sum_e":            0.0,
            "reportable_fringe_benefits": 0.0,
            "cdep_payments":         0.0,
            "financial_year":        financial_year,
            "fy_label":              f"{financial_year-1}–{financial_year}",
        })

    conn.close()
    return results


def render_payg_summary_pdf(db_path: str, financial_year: int,
                              employee_ids: list = None,
                              out_path: str = None) -> str:
    """
    Render ATO-style PAYG Payment Summary report for all employees.
    One record per employee per page (or compact multi-employee layout).
    Returns out_path.
    """
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors as rl_colors
    from reportlab.lib.units import mm
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_RIGHT, TA_CENTER, TA_LEFT
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                     Table, TableStyle, HRFlowable,
                                     PageBreak, KeepTogether)
    from core.database import get_connection as _gc
    import tempfile, datetime as _dt

    if out_path is None:
        out_path = tempfile.mktemp(suffix="_payg_summary.pdf")

    conn = _gc(db_path)
    co   = dict(conn.execute("SELECT * FROM company").fetchone() or {})
    conn.close()

    summaries = get_payg_summary(db_path, financial_year)
    if employee_ids:
        summaries = [s for s in summaries if s["employee_id"] in employee_ids]
    if not summaries:
        raise ValueError("No payroll data found for selected period.")

    co_name = co.get("name", "") or "Employer"
    co_abn  = co.get("abn", "") or ""
    co_addr = co.get("address", "") or ""
    fy_label = f"{financial_year-1}–{financial_year}"

    from core.invoice_pdf import _resolve_theme, _c, _load_doc_theme
    _th    = _resolve_theme(_load_doc_theme(co))
    NAVY   = _c(_th["header_bg"])
    RED    = rl_colors.HexColor("#c0392b")
    LTGR   = _c(_th["row_alt"])
    LTRED  = rl_colors.HexColor("#fdf0f0")   # semantic — withheld tax highlight
    WHITE  = rl_colors.white
    DIM    = _c(_th["dim_text"])
    BLACK  = rl_colors.black
    GOLD   = rl_colors.HexColor("#f39c12")   # semantic — PAYG withheld highlight

    W = 174*mm

    def sty(name, **kw):
        d = dict(fontName="Helvetica", fontSize=9, leading=13,
                 textColor=_c(_th["body_text"]))
        d.update(kw)
        return ParagraphStyle(name, **d)

    def P(txt, s="body"):
        _s = {
            "body":   sty("b"),
            "bold":   sty("bd", fontName="Helvetica-Bold"),
            "right":  sty("r",  alignment=TA_RIGHT),
            "rbold":  sty("rb", fontName="Helvetica-Bold", alignment=TA_RIGHT),
            "center": sty("c",  alignment=TA_CENTER),
            "cbold":  sty("cb", fontName="Helvetica-Bold", alignment=TA_CENTER),
            "hdr":    sty("hh", fontName="Helvetica-Bold", fontSize=9, textColor=WHITE),
            "dim":    sty("dm", textColor=DIM, fontSize=7.5),
            "title":  sty("ti", fontName="Helvetica-Bold", fontSize=13, textColor=NAVY),
            "red":    sty("rd", fontName="Helvetica-Bold", textColor=RED),
            "small":  sty("sm", fontSize=8),
            "label":  sty("lb", fontSize=8, textColor=DIM),
        }
        return Paragraph(str(txt or ""), _s.get(s, _s["body"]))

    def money(v):
        v = float(v or 0)
        return P(f"${v:,.2f}", "rbold")

    doc = SimpleDocTemplate(out_path, pagesize=A4,
                             leftMargin=15*mm, rightMargin=15*mm,
                             topMargin=12*mm, bottomMargin=12*mm)
    story = []

    for idx, emp in enumerate(summaries):
        if idx > 0:
            story.append(PageBreak())

        block = []

        # ATO header strip
        ato_hdr = Table([[
            Paragraph(f"<b>PAYG PAYMENT SUMMARY — INDIVIDUAL NON-BUSINESS</b>",
                      sty("ah", fontName="Helvetica-Bold", fontSize=11,
                          textColor=WHITE, alignment=TA_CENTER)),
            Paragraph(f"Financial Year: <b>{fy_label}</b>",
                      sty("fy", fontName="Helvetica-Bold", fontSize=10,
                          textColor=WHITE, alignment=TA_RIGHT)),
        ]], colWidths=[W*0.7, W*0.3])
        ato_hdr.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), RED),
            ("TOPPADDING",    (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ("LEFTPADDING",   (0, 0), (-1, -1), 10),
            ("RIGHTPADDING",  (0, 0), (-1, -1), 10),
        ]))
        block.append(ato_hdr)
        block.append(Spacer(1, 3*mm))

        # Employer / Employee boxes
        emp_boxes = Table([[
            # Employer (left)
            Table([
                [P("PAYER (EMPLOYER)", "label")],
                [P(f"<b>{co_name}</b>", "bold")],
                [P(f"ABN: {co_abn}" if co_abn else "ABN: —")],
                [P(co_addr or "", "small")],
            ], colWidths=[W*0.48]),
            # Payee (right)
            Table([
                [P("PAYEE (EMPLOYEE)", "label")],
                [P(f"<b>{emp['employee_name']}</b>", "bold")],
                [P(f"TFN: {emp['tfn']}")],
                [P(emp.get("address") or "", "small")],
            ], colWidths=[W*0.48]),
        ]], colWidths=[W*0.5, W*0.5])
        emp_boxes.setStyle(TableStyle([
            ("BACKGROUND",    (0, 0), (0, 0), LTGR),
            ("BACKGROUND",    (1, 0), (1, 0), LTRED),
            ("TOPPADDING",    (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ("LEFTPADDING",   (0, 0), (-1, -1), 10),
            ("RIGHTPADDING",  (0, 0), (-1, -1), 10),
            ("VALIGN",        (0, 0), (-1, -1), "TOP"),
            ("BOX",           (0, 0), (-1, -1), 0.5,
             rl_colors.HexColor("#ccd0e0")),
            ("LINEABOVE",     (1, 0), (1, 0), 0.5,
             rl_colors.HexColor("#ccd0e0")),
        ]))
        block.append(emp_boxes)
        block.append(Spacer(1, 4*mm))

        # Main figures
        def field_row(label_txt, amount, highlight=False):
            bg = LTRED if highlight else WHITE
            return [
                Table([[P(label_txt, "body")]], colWidths=[W*0.65]),
                Table([[money(amount)]], colWidths=[W*0.3]),
            ]

        fig_rows = [
            [P("INCOME / DEDUCTIONS", "hdr"), P("AMOUNT", "hdr")],
            field_row("1. Gross payments (wages, salary, allowances)", emp["gross_wages"]),
            field_row("2. Total tax withheld (PAYG)",                  emp["payg_withheld"], highlight=True),
            field_row("3. Employer super contributions (SGC)",          emp["super_employer"]),
            field_row("4. Reportable employer super (salary sacrifice)", emp["salary_sacrifice_super"]),
            field_row("5. Total allowances",                            emp["allowances_total"]),
            field_row("6. Lump sum A (redundancy / unused leave)",      emp["lump_sum_a"]),
            field_row("7. Lump sum B (unused pre-Aug 1993 leave)",      emp["lump_sum_b"]),
            field_row("8. Lump sum D (tax-free redundancy)",            emp["lump_sum_d"]),
            field_row("9. Lump sum E (back payments)",                  emp["lump_sum_e"]),
            field_row("10. Reportable fringe benefits (>$2,000)",       emp["reportable_fringe_benefits"]),
            field_row("11. CDEP payments",                              emp["cdep_payments"]),
        ]

        fig_tbl = Table(fig_rows, colWidths=[W*0.7, W*0.3])
        fig_tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0, 0), (-1, 0),   NAVY),
            ("ROWBACKGROUNDS",(0, 1), (-1, -1),  [WHITE, LTGR]),
            ("BACKGROUND",    (0, 2), (-1, 2),   LTRED),   # PAYG row highlight
            ("TOPPADDING",    (0, 0), (-1, -1),  4),
            ("BOTTOMPADDING", (0, 0), (-1, -1),  4),
            ("LEFTPADDING",   (0, 0), (-1, -1),  8),
            ("RIGHTPADDING",  (0, 0), (-1, -1),  8),
            ("BOX",           (0, 0), (-1, -1),  0.5,
             rl_colors.HexColor("#ccd0e0")),
            ("LINEABOVE",     (0, 1), (-1, 1),   0.5,
             rl_colors.HexColor("#ccd0e0")),
        ]))
        block.append(fig_tbl)

        # Allowances breakdown (if any)
        if emp.get("allowances_breakdown"):
            block.append(Spacer(1, 3*mm))
            allow_rows = [[P("Allowances Breakdown", "hdr"), P("Amount", "hdr")]]
            for atype, amt in sorted(emp["allowances_breakdown"].items()):
                allow_rows.append([P(f"  {atype}"), money(amt)])
            at = Table(allow_rows, colWidths=[W*0.7, W*0.3])
            at.setStyle(TableStyle([
                ("BACKGROUND",    (0, 0), (-1, 0),  NAVY),
                ("ROWBACKGROUNDS",(0, 1), (-1, -1), [WHITE, LTGR]),
                ("TOPPADDING",    (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ("LEFTPADDING",   (0, 0), (-1, -1), 8),
                ("BOX",           (0, 0), (-1, -1), 0.5,
                 rl_colors.HexColor("#ccd0e0")),
            ]))
            block.append(at)

        block.append(Spacer(1, 5*mm))

        # Certification box
        cert = Table([[
            Paragraph(
                "<b>PAYER DECLARATION:</b> I declare that the information on this "
                "payment summary is correct and that withholding amounts have been "
                "paid to the Australian Taxation Office.",
                sty("cert", fontSize=8, leading=11)),
        ]], colWidths=[W])
        cert.setStyle(TableStyle([
            ("BACKGROUND",    (0, 0), (-1, -1), LTGR),
            ("TOPPADDING",    (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ("LEFTPADDING",   (0, 0), (-1, -1), 10),
            ("BOX",           (0, 0), (-1, -1), 0.5,
             rl_colors.HexColor("#ccd0e0")),
        ]))
        block.append(cert)

        block.append(Spacer(1, 4*mm))
        block.append(P(
            f"Generated {_dt.datetime.now().strftime('%d/%m/%Y %H:%M')}  "
            f"•  {co_name}  •  NOT AN ATO FORM — for reference only",
            "dim"))

        story.append(KeepTogether(block))

    doc.build(story)
    return out_path


# ══════════════════════════════════════════════════════════════════════════════
#  PAYG PAYMENT SUMMARY
# ══════════════════════════════════════════════════════════════════════════════

def get_payment_summary_data(db_path: str, fy_year: int) -> list:
    """
    Return a list of PAYG Payment Summary records for each employee who had
    payslips finalised in the financial year ending 30 June `fy_year`.

    Each record:
        employee_id, name, address, tfn (masked), employment_type,
        gross_wages, payg_withheld, reportable_super, allowances_detail,
        lump_sum_a, lump_sum_b, lump_sum_d, lump_sum_e,
        reportable_fringe_benefits, deductible_expenses
    """
    date_from = f"{fy_year - 1}-07-01"
    date_to   = f"{fy_year}-06-30"

    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT
            e.id            AS employee_id,
            e.first_name || ' ' || e.last_name AS name,
            e.address       AS address,
            e.tfn           AS tfn,
            e.employment_type,
            COALESCE(SUM(ps.gross_pay), 0)           AS gross_wages,
            COALESCE(SUM(ps.payg_tax), 0)            AS payg_withheld,
            COALESCE(SUM(ps.salary_sacrifice),0) AS reportable_super,
            COALESCE(SUM(ps.allowances), 0)          AS total_allowances
        FROM employees e
        JOIN payslips ps ON ps.employee_id = e.id
        JOIN pay_runs pr ON ps.pay_run_id  = pr.id
        WHERE pr.status IN ('Finalised','STP_Lodged')
          AND ps.payment_date BETWEEN ? AND ?
        GROUP BY e.id
        ORDER BY e.last_name, e.first_name
    """, (date_from, date_to)).fetchall()

    # Collect allowance detail per employee for itemised listing
    allow_rows = conn.execute("""
        SELECT ps.employee_id, ps.allowances_json
        FROM payslips ps
        JOIN pay_runs pr ON ps.pay_run_id = pr.id
        WHERE pr.status IN ('Finalised','STP_Lodged')
          AND ps.payment_date BETWEEN ? AND ?
          AND ps.allowances_json IS NOT NULL
    """, (date_from, date_to)).fetchall()
    conn.close()

    import json as _json
    # Aggregate allowances by type per employee
    allow_by_emp = {}
    for ar in allow_rows:
        eid = ar["employee_id"]
        try:
            items = _json.loads(ar["allowances_json"] or "[]")
        except Exception:
            items = []
        bucket = allow_by_emp.setdefault(eid, {})
        for item in items:
            atype = item.get("type", "Other")
            bucket[atype] = round(bucket.get(atype, 0) + float(item.get("amount", 0)), 2)

    results = []
    for r in rows:
        d = dict(r)
        # Mask TFN — show last 3 digits only: ***-***-XXX
        tfn = str(d.get("tfn") or "")
        tfn_clean = tfn.replace(" ", "").replace("-", "")
        if len(tfn_clean) >= 3:
            d["tfn_display"] = f"***-***-{tfn_clean[-3:]}"
        else:
            d["tfn_display"] = "Not on file"
        d["allowances_detail"] = allow_by_emp.get(d["employee_id"], {})
        # These fields not yet tracked — zero placeholders for PDF layout
        d["lump_sum_a"] = 0.0
        d["lump_sum_b"] = 0.0
        d["lump_sum_d"] = 0.0
        d["lump_sum_e"] = 0.0
        d["reportable_fringe_benefits"] = 0.0
        d["deductible_expenses"]        = 0.0
        d["fy_year"]    = fy_year
        d["date_from"]  = date_from
        d["date_to"]    = date_to
        results.append(d)
    return results


# ══════════════════════════════════════════════════════════════════════════════
#  OUTSTANDING LEAVE REPORT
# ══════════════════════════════════════════════════════════════════════════════

def _get_all_leave_balances(db_path) -> list[dict]:
    """
    Return leave balance rows for all active employees, joined to employee
    and leave-type details.  Rows with zero balance and non-NES types are
    included so the report is complete; callers may filter as desired.
    """
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT
            e.id              AS employee_id,
            e.employee_number,
            e.first_name,
            e.last_name,
            e.employment_type,
            e.hours_per_week,
            lt.id             AS leave_type_id,
            lt.code,
            lt.name           AS type_name,
            lt.paid,
            lt.colour,
            COALESCE(lb.accrued_hours,    0) AS accrued_hours,
            COALESCE(lb.taken_hours,      0) AS taken_hours,
            COALESCE(lb.adjustment_hours, 0) AS adjustment_hours,
            COALESCE(lb.accrued_hours, 0)
                + COALESCE(lb.adjustment_hours, 0)
                - COALESCE(lb.taken_hours, 0)  AS balance_hours
        FROM employees e
        CROSS JOIN leave_types lt
        LEFT JOIN leave_balances lb
               ON lb.employee_id   = e.id
              AND lb.leave_type_id = lt.id
        WHERE e.is_active = 1
          AND lt.is_active = 1
        ORDER BY e.last_name, e.first_name,
                 lt.sort_order, lt.name
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def generate_outstanding_leave_csv(db_path, output_path: str = None) -> str:
    """
    Export outstanding leave balances for all active employees as CSV.
    Returns the path to the written file.
    """
    import csv, tempfile, os
    from core.leave import hours_to_days

    rows = _get_all_leave_balances(db_path)

    if not output_path:
        fd, output_path = tempfile.mkstemp(suffix=".csv", prefix="leave_balances_")
        os.close(fd)

    # NES types always shown; others only if non-zero balance
    NES = {"ANN", "LSL", "SIC"}
    rows = [r for r in rows
            if r["code"] in NES or r["balance_hours"] != 0]

    with open(output_path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow([
            "Employee Number", "Last Name", "First Name", "Employment Type",
            "Leave Type", "Leave Code", "Paid",
            "Accrued (hrs)", "Taken (hrs)", "Adjustment (hrs)",
            "Balance (hrs)", "Balance (days)",
        ])
        hpw = {}  # cache hours_per_week per employee
        for r in rows:
            emp_id = r["employee_id"]
            if emp_id not in hpw:
                hpw[emp_id] = float(r.get("hours_per_week") or 38)
            hpd = hpw[emp_id] / 5
            bal = r["balance_hours"]
            # hours_to_days returns a formatted string like "3.5 days"
            days_str = hours_to_days(bal, hpd)
            try:
                days_val = float(days_str.split()[0])
            except Exception:
                days_val = round(bal / hpd, 2) if hpd else ""
            writer.writerow([
                r["employee_number"],
                r["last_name"],
                r["first_name"],
                r["employment_type"] or "",
                r["type_name"],
                r["code"],
                "Yes" if r["paid"] else "No",
                f"{r['accrued_hours']:.2f}",
                f"{r['taken_hours']:.2f}",
                f"{r['adjustment_hours']:.2f}",
                f"{bal:.2f}",
                f"{days_val:.2f}" if isinstance(days_val, float) else days_val,
            ])

    return output_path


def generate_outstanding_leave_pdf(db_path, output_path: str = None,
                                   watermark: str = None, footer: str = None) -> str:
    """
    Generate a PDF report of outstanding leave balances for all active
    employees.  One section per employee; NES types always shown, others
    only when balance != 0.  Returns the path to the written file.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors as rl_colors
        from reportlab.lib.units import mm
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.enums import TA_RIGHT, TA_CENTER
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                         Table, TableStyle, HRFlowable,
                                         PageBreak)
    except ImportError:
        raise ImportError("reportlab not installed. Run: pip install reportlab")

    import tempfile, os
    from datetime import date as _date
    from core.leave import hours_to_days
    from collections import defaultdict

    if not output_path:
        fd, output_path = tempfile.mkstemp(suffix=".pdf", prefix="leave_balances_")
        os.close(fd)

    # ── Colours ───────────────────────────────────────────────────────────────
    from core.invoice_pdf import _resolve_theme, _c
    _th   = _resolve_theme(None)   # default theme — no company row available here
    NAVY  = _c(_th["header_bg"])
    PURP  = _c(_th["accent_bar"])
    LTPUR = _c(_th["payment_box_bg"])
    BORD  = _c(_th["rule_colour"])
    IBORD = _c(_th["rule_colour"])
    WHITE = rl_colors.white
    LGREY = _c(_th["dim_text"])
    GREEN = rl_colors.HexColor("#27ae60")
    RED   = rl_colors.HexColor("#e74c3c")

    # ── Page / doc setup ──────────────────────────────────────────────────────
    W, H = A4
    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        leftMargin=15*mm, rightMargin=15*mm,
        topMargin=18*mm,  bottomMargin=15*mm,
    )
    usable_w = W - 30*mm

    # ── Paragraph styles ──────────────────────────────────────────────────────
    def sty(name, **kw):
        base = dict(fontName="Helvetica", fontSize=9,
                    leading=12, textColor=NAVY)
        base.update(kw)
        return ParagraphStyle(name, **base)

    styles = {
        "title":  sty("title",  fontSize=16, fontName="Helvetica-Bold",
                       textColor=NAVY),
        "sub":    sty("sub",    fontSize=9,  textColor=LGREY),
        "h2":     sty("h2",     fontSize=11, fontName="Helvetica-Bold",
                       textColor=PURP),
        "normal": sty("normal"),
        "right":  sty("right",  alignment=TA_RIGHT),
        "label":  sty("label",  fontSize=7.5, textColor=LGREY),
        "bold":   sty("bold",   fontName="Helvetica-Bold"),
        "hdr":    sty("hdr",    fontName="Helvetica-Bold", fontSize=8,
                       textColor=WHITE),
    }

    def P(text, style="normal", colour=None):
        s = styles[style]
        if colour:
            s = ParagraphStyle(style + "_c", parent=s, textColor=colour)
        return Paragraph(str(text), s)

    # ── Fetch & group data ────────────────────────────────────────────────────
    all_rows = _get_all_leave_balances(db_path)
    NES = {"ANN", "LSL", "SIC"}

    # Group by employee
    by_emp = defaultdict(list)
    emp_meta = {}
    for r in all_rows:
        eid = r["employee_id"]
        if eid not in emp_meta:
            emp_meta[eid] = r
        if r["code"] in NES or r["balance_hours"] != 0:
            by_emp[eid].append(r)

    # ── Build story ───────────────────────────────────────────────────────────
    story = []
    today = _date.today().strftime("%d %B %Y")

    # Title block
    story.append(P("Outstanding Leave Balances", "title"))
    story.append(Spacer(1, 2*mm))
    story.append(P(f"All active employees  ·  As at {today}", "sub"))
    if watermark:
        story.append(Spacer(1, 1*mm))
        story.append(P(f"Company: {watermark}", "sub"))
    story.append(Spacer(1, 5*mm))
    story.append(HRFlowable(width="100%", thickness=1, color=PURP,
                             spaceAfter=6*mm))

    col_widths = [usable_w * p for p in [0.34, 0.12, 0.14, 0.14, 0.14, 0.12]]

    for eid, balances in by_emp.items():
        meta = emp_meta[eid]
        hpd  = float(meta.get("hours_per_week") or 38) / 5
        name = f"{meta['first_name']} {meta['last_name']}"
        emp_no   = meta["employee_number"] or ""
        emp_type = meta["employment_type"] or ""

        # Employee header
        story.append(P(f"{name}  <font color='#8892a4' size='8'>#{emp_no} · {emp_type}</font>",
                       "h2"))
        story.append(Spacer(1, 2*mm))

        # Table header row
        tbl_data = [[
            P("Leave Type",    "hdr"),
            P("Code",          "hdr"),
            P("Accrued",       "hdr"),
            P("Taken",         "hdr"),
            P("Adjustment",    "hdr"),
            P("Balance",       "hdr"),
        ]]

        for b in balances:
            bal  = b["balance_hours"]
            days_str = hours_to_days(bal, hpd)
            try:
                days_val = float(days_str.split()[0])
                bal_label = f"{bal:.2f} h\n({days_val:.1f} d)"
            except Exception:
                bal_label = f"{bal:.2f} h"

            bal_colour = GREEN if bal > 0 else (RED if bal < 0 else LGREY)
            tbl_data.append([
                P(b["type_name"]),
                P(b["code"]),
                P(f"{b['accrued_hours']:.2f}", "right"),
                P(f"{b['taken_hours']:.2f}",   "right"),
                P(f"{b['adjustment_hours']:.2f}", "right"),
                P(bal_label, "right", colour=bal_colour),
            ])

        tbl = Table(tbl_data, colWidths=col_widths, repeatRows=1)
        tbl.setStyle(TableStyle([
            # Header
            ("BACKGROUND",   (0, 0), (-1, 0), PURP),
            ("TOPPADDING",   (0, 0), (-1, 0), 4),
            ("BOTTOMPADDING",(0, 0), (-1, 0), 4),
            # Body
            ("ROWBACKGROUNDS",(0, 1), (-1, -1), [WHITE, LTPUR]),
            ("TOPPADDING",   (0, 1), (-1, -1), 3),
            ("BOTTOMPADDING",(0, 1), (-1, -1), 3),
            ("LEFTPADDING",  (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            # Borders
            ("BOX",       (0, 0), (-1, -1), 0.5, BORD),
            ("INNERGRID", (0, 0), (-1, -1), 0.25, IBORD),
            # Alignment
            ("ALIGN", (2, 0), (-1, -1), "RIGHT"),
            ("VALIGN",(0, 0), (-1, -1), "MIDDLE"),
        ]))
        story.append(tbl)
        story.append(Spacer(1, 6*mm))

    # Footer note
    story.append(HRFlowable(width="100%", thickness=0.5,
                             color=rl_colors.HexColor("#ccd0e0"),
                             spaceAfter=2*mm))
    story.append(P(
        "Balance = Accrued + Adjustments − Taken.  "
        "NES leave types (Annual, Personal/Carer's, Long Service) are always shown.  "
        "Other types shown only where a non-zero balance exists.  "
        "Generated by dbox Accounting.", "label"))

    doc.build(story)
    return output_path


def generate_period_leave_report_pdf(requests: list,
                                      period_start: str, period_end: str,
                                      output_path: str = None,
                                      watermark: str = None) -> str:
    """
    Generate a PDF listing approved leave requests that overlap a pay period.
    Used as a reference when manually applying leave via the Adjust button.
    requests: list of dicts as returned by get_leave_requests().
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors as rl_colors
        from reportlab.lib.units import mm
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.enums import TA_RIGHT
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                         Table, TableStyle, HRFlowable)
    except ImportError:
        raise ImportError("reportlab not installed. Run: pip install reportlab")

    import tempfile, os
    from datetime import date as _date

    if not output_path:
        fd, output_path = tempfile.mkstemp(suffix=".pdf", prefix="leave_report_")
        os.close(fd)

    from core.invoice_pdf import _resolve_theme, _c
    _th   = _resolve_theme(None)   # default theme — no company row available here
    NAVY  = _c(_th["header_bg"])
    PURP  = _c(_th["accent_bar"])
    LTPUR = _c(_th["payment_box_bg"])
    BORD  = _c(_th["rule_colour"])
    IBORD = _c(_th["rule_colour"])
    WHITE = rl_colors.white
    LGREY = _c(_th["dim_text"])
    AMBER = rl_colors.HexColor("#e67e22")

    W, H = A4
    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        leftMargin=15*mm, rightMargin=15*mm,
        topMargin=18*mm,  bottomMargin=15*mm)
    usable_w = W - 30*mm

    def sty(name, **kw):
        base = dict(fontName="Helvetica", fontSize=9, leading=12, textColor=NAVY)
        base.update(kw)
        return ParagraphStyle(name, **base)

    styles = {
        "title":  sty("title",  fontSize=15, fontName="Helvetica-Bold"),
        "sub":    sty("sub",    fontSize=9,  textColor=LGREY),
        "normal": sty("normal"),
        "right":  sty("right",  alignment=TA_RIGHT),
        "hdr":    sty("hdr",    fontName="Helvetica-Bold", fontSize=8, textColor=WHITE),
        "label":  sty("label",  fontSize=7.5, textColor=LGREY),
        "warn":   sty("warn",   fontSize=9, textColor=AMBER, fontName="Helvetica-Bold"),
    }

    def P(text, style="normal"):
        return Paragraph(str(text), styles[style])

    story = []
    today = _date.today().strftime("%d %B %Y")

    story.append(P("Approved Leave — Pay Period Reference", "title"))
    story.append(Spacer(1, 2*mm))
    story.append(P(f"Period: {period_start}  to  {period_end}   ·   Generated: {today}", "sub"))
    if watermark:
        story.append(P(f"Company: {watermark}", "sub"))
    story.append(Spacer(1, 3*mm))
    story.append(P(
        "Leave is not applied automatically. Use the Adjust button on each "
        "affected employee in the pay run to enter leave hours before finalising.",
        "warn"))
    story.append(Spacer(1, 4*mm))
    story.append(HRFlowable(width="100%", thickness=1, color=PURP, spaceAfter=5*mm))

    col_widths = [usable_w * p for p in [0.26, 0.22, 0.13, 0.13, 0.10, 0.16]]
    rows = [[
        P("Employee",   "hdr"), P("Leave Type", "hdr"),
        P("From",       "hdr"), P("To",         "hdr"),
        P("Hours",      "hdr"), P("Status",      "hdr"),
    ]]
    for r in requests:
        rows.append([
            P(r.get("employee_name", "")),
            P(r.get("type_name", "")),
            P(r.get("start_date", "")),
            P(r.get("end_date", "")),
            P(f"{r.get('hours_requested', 0):.2f}", "right"),
            P(r.get("status", "")),
        ])

    tbl = Table(rows, colWidths=col_widths, repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, 0), PURP),
        ("TOPPADDING",    (0, 0), (-1, 0), 4),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 4),
        ("ROWBACKGROUNDS",(0, 1), (-1, -1), [WHITE, LTPUR]),
        ("TOPPADDING",    (0, 1), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 3),
        ("LEFTPADDING",   (0, 0), (-1, -1), 5),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 5),
        ("BOX",           (0, 0), (-1, -1), 0.5, BORD),
        ("INNERGRID",     (0, 0), (-1, -1), 0.25, IBORD),
        ("ALIGN",         (4, 0), (4, -1), "RIGHT"),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 6*mm))

    total_hrs = sum(r.get("hours_requested", 0) for r in requests)
    story.append(P(
        f"Total: {len(requests)} request{'s' if len(requests) != 1 else ''}  ·  "
        f"{total_hrs:.2f} hours across all employees", "sub"))
    story.append(Spacer(1, 4*mm))
    story.append(HRFlowable(width="100%", thickness=0.5,
                             color=rl_colors.HexColor("#ccd0e0"), spaceAfter=2*mm))
    story.append(P("Generated by dbox Accounting. For internal payroll use only.", "label"))

    doc.build(story)
    return output_path
