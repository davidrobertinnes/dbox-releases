"""
dbox Inventory Management.

Extends the Items catalogue with stock tracking:
  • Stock-on-hand quantity per item (item_stock table)
  • Stock movement journal (inventory_movements)
  • Reorder level / reorder quantity alerts
  • Cost of Goods Sold (COGS) tracking — weighted average cost method
  • Stock adjustment (write-up / write-down / count correction)
  • Automatic stock reduction when invoice is finalised (via post_stock_movement)
  • Automatic stock increase when bill/PO is finalised

Movement types:
  PURCHASE   — stock received from supplier (increases qty, updates avg cost)
  SALE       — stock shipped to customer (reduces qty, posts COGS)
  ADJUSTMENT — manual stock count correction
  WRITE_OFF  — damaged / expired / lost
  TRANSFER   — inter-location (future)
  RETURN_IN  — customer return
  RETURN_OUT — return to supplier

All monetary posting goes to the GL via core.ledger.post_journal.
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.


from __future__ import annotations
import json
from datetime import date as _date, datetime as _dt
from core.database import get_connection

# ── ATO Livestock Prescribed Values (ITAA 1997 s70-75) ───────────────────────
# Groups and per-head values as specified by ATO categorisation.
# Verify against current ATO guidance each financial year.
ATO_LIVESTOCK_CATEGORIES = [
    ("cattle_horses_deer", "Cattle / Horses / Deer",  20.00),
    ("pigs",               "Pigs",                    12.00),
    ("emus",               "Emus / Ostriches",         8.00),
    ("sheep_goats",        "Sheep / Goats",             4.00),
    ("poultry",            "Poultry",                   0.35),
]
# key → prescribed $/head
ATO_PRESCRIBED = {k: v for k, _, v in ATO_LIVESTOCK_CATEGORIES}


class OversellError(Exception):
    """
    Raised when an invoice would sell more units than are on hand.
    Carries a list of dicts: {item_id, item_name, requested, on_hand, shortfall}
    so the caller can present a meaningful warning.
    """
    def __init__(self, items):
        self.items = items          # list of oversell detail dicts
        lines = [
            f"  {d['item_name']}: requested {d['requested']:.0f}, "
            f"on hand {d['on_hand']:.0f}, short by {d['shortfall']:.0f}"
            for d in items
        ]
        super().__init__(
            "Insufficient stock for the following items:\n" + "\n".join(lines)
        )


def check_oversell(db_path, lines: list) -> list:
    """
    Check a list of invoice lines for potential oversells.
    Only checks lines with item_id set where the item is inventoried.
    Returns a list of dicts for each oversell:
      {item_id, item_name, item_code, requested, on_hand, shortfall}
    Empty list = no oversell.
    """
    problems = []
    seen = {}   # item_id -> cumulative qty requested in this invoice

    for l in lines:
        item_id = l.get("item_id")
        if not item_id:
            continue
        qty = float(l.get("quantity") or 0)
        if qty <= 0:
            continue

        if item_id not in seen:
            item = get_inventory_item(db_path, item_id)
            if not item or not item.get("is_inventoried"):
                seen[item_id] = None   # not tracked
                continue
            seen[item_id] = {
                "item": item,
                "on_hand": float(item.get("qty_on_hand") or 0),
                "requested": 0.0,
            }

        if seen[item_id] is None:
            continue

        seen[item_id]["requested"] += qty

    for item_id, d in seen.items():
        if d is None:
            continue
        if d["requested"] > d["on_hand"]:
            item = d["item"]
            problems.append({
                "item_id":    item_id,
                "item_name":  item.get("name", ""),
                "item_code":  item.get("code", ""),
                "requested":  d["requested"],
                "on_hand":    d["on_hand"],
                "shortfall":  d["requested"] - d["on_hand"],
            })

    return problems



# ─────────────────────────────────────────────────────────────────────────────
#  MIGRATION
# ─────────────────────────────────────────────────────────────────────────────

def migrate_inventory(conn):
    """Create or upgrade inventory tables. Safe to call on existing databases."""

    # ── Extend items table with inventory fields (migration-safe) ──────────────
    for col, defn in [
        ("is_inventoried",    "INTEGER NOT NULL DEFAULT 0"),   # track stock?
        ("qty_on_hand",       "REAL NOT NULL DEFAULT 0"),      # denormalised cache
        ("reorder_level",     "REAL NOT NULL DEFAULT 0"),      # alert threshold
        ("reorder_qty",       "REAL NOT NULL DEFAULT 0"),      # suggested PO qty
        ("unit_cost",         "REAL NOT NULL DEFAULT 0"),      # weighted avg cost
        ("cogs_account_id",   "INTEGER"),                      # DR on sale
        ("stock_account_id",  "INTEGER"),                      # asset (inventory)
        ("location",          "TEXT"),                         # bin/shelf ref
        ("barcode",           "TEXT"),                         # optional
        ("pricing_mode",      "TEXT DEFAULT 'fixed'"),         # fixed|pct_markup|pct_margin|dollar_margin
        ("markup_value",      "REAL DEFAULT 0"),               # value for non-fixed modes
    ]:
        try:
            conn.execute(f"ALTER TABLE items ADD COLUMN {col} {defn}")
        except Exception:
            pass

    # ── Stock movement journal ─────────────────────────────────────────────────
    conn.execute("""CREATE TABLE IF NOT EXISTS inventory_movements (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        item_id         INTEGER NOT NULL REFERENCES items(id),
        movement_type   TEXT NOT NULL,  -- PURCHASE|SALE|ADJUSTMENT|WRITE_OFF|RETURN_IN|RETURN_OUT
        movement_date   TEXT NOT NULL,
        qty             REAL NOT NULL,  -- positive = in, negative = out
        unit_cost       REAL,           -- cost per unit at time of movement
        total_cost      REAL,           -- qty * unit_cost
        unit_price      REAL,           -- sale price (SALE movements)
        total_price     REAL,           -- qty * unit_price
        reference       TEXT,           -- invoice/bill number
        source_doc_type TEXT,           -- 'invoice'|'bill'|'adjustment'
        source_doc_id   INTEGER,
        journal_id      INTEGER,        -- GL journal entry if posted
        notes           TEXT,
        qty_before      REAL,           -- stock before this movement
        qty_after       REAL,           -- stock after this movement
        created_by      TEXT,
        created_at      TEXT DEFAULT (datetime('now','localtime'))
    )""")
    conn.execute("""CREATE INDEX IF NOT EXISTS idx_inv_mov_item
        ON inventory_movements(item_id, movement_date)""")
    conn.execute("""CREATE INDEX IF NOT EXISTS idx_inv_mov_date
        ON inventory_movements(movement_date)""")

    # ── receipt_id on movements (migration-safe) ───────────────────────────────
    try:
        conn.execute(
            "ALTER TABLE inventory_movements ADD COLUMN receipt_id INTEGER "
            "REFERENCES stock_receipts(id)")
    except Exception:
        pass

    # ── Stock receipt headers ──────────────────────────────────────────────────
    conn.execute("""CREATE TABLE IF NOT EXISTS stock_receipts (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        bill_id      INTEGER REFERENCES bills(id),
        receipt_date TEXT NOT NULL,
        reference    TEXT,
        notes        TEXT,
        created_at   TEXT DEFAULT (datetime('now','localtime'))
    )""")
    conn.execute("""CREATE INDEX IF NOT EXISTS idx_stock_receipts_bill
        ON stock_receipts(bill_id)""")


# ─────────────────────────────────────────────────────────────────────────────
#  ITEM STOCK QUERIES
# ─────────────────────────────────────────────────────────────────────────────

def get_inventory_items(db_path, include_non_inventoried=False,
                         low_stock_only=False) -> list:
    """Return items that have inventory tracking enabled."""
    conn = get_connection(db_path)
    where = "WHERE 1=1"
    if not include_non_inventoried:
        where += " AND i.is_inventoried = 1"
    if low_stock_only:
        where += " AND i.qty_on_hand <= i.reorder_level AND i.reorder_level > 0"

    rows = conn.execute(f"""
        SELECT
            i.*,
            a.name  AS account_name,
            a.code  AS account_code,
            sa.name AS stock_account_name,
            sa.code AS stock_account_code,
            ca.name AS cogs_account_name,
            ca.code AS cogs_account_code,
            CASE
                WHEN i.reorder_level > 0 AND i.qty_on_hand <= i.reorder_level
                     THEN 1 ELSE 0
            END AS is_low_stock,
            CASE
                WHEN i.qty_on_hand < 0 THEN 1 ELSE 0
            END AS is_negative_stock
        FROM items i
        LEFT JOIN accounts a  ON i.account_id       = a.id
        LEFT JOIN accounts sa ON i.stock_account_id  = sa.id
        LEFT JOIN accounts ca ON i.cogs_account_id   = ca.id
        {where}
        ORDER BY i.name COLLATE NOCASE
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]



def get_inventory_analytics(db_path, months: int = 6) -> dict:
    """
    Return per-item analytics over the last `months` months.
    Returns a dict keyed by item_id:
      {
        item_id: {
          avg_sold_per_month: float,   # avg units sold per month
          avg_cost_recent:    float,   # weighted avg cost of purchases in period
          total_sold:         float,   # total units sold in period
          months_cover:       float,   # qty_on_hand / avg_sold_per_month (None if no sales)
        }
      }
    Only items with movements in the period are included.
    """
    from datetime import date, timedelta
    conn = get_connection(db_path)

    cutoff = (date.today() - timedelta(days=months * 30)).isoformat()

    # Avg monthly sales
    sales = conn.execute("""
        SELECT item_id,
               SUM(ABS(qty))                      AS total_qty
        FROM   inventory_movements
        WHERE  movement_type = 'SALE'
          AND  movement_date >= ?
        GROUP  BY item_id
    """, (cutoff,)).fetchall()

    # Weighted avg cost of recent purchases
    purchases = conn.execute("""
        SELECT item_id,
               SUM(qty)        AS total_qty,
               SUM(total_cost) AS total_cost
        FROM   inventory_movements
        WHERE  movement_type = 'PURCHASE'
          AND  movement_date >= ?
        GROUP  BY item_id
    """, (cutoff,)).fetchall()

    # Current qty_on_hand per item
    stock = conn.execute(
        "SELECT id, qty_on_hand FROM items WHERE is_inventoried = 1"
    ).fetchall()
    conn.close()

    stock_map = {r["id"]: float(r["qty_on_hand"] or 0) for r in stock}

    # Build purchase analytics
    purchase_map = {}
    for r in purchases:
        tq = float(r["total_qty"] or 0)
        tc = float(r["total_cost"] or 0)
        if tq > 0:
            purchase_map[r["item_id"]] = round(tc / tq, 4)

    # Build result
    result = {}
    for r in sales:
        iid = r["item_id"]
        total_sold = float(r["total_qty"] or 0)
        avg_sold   = round(total_sold / months, 2)
        on_hand    = stock_map.get(iid, 0.0)
        cover      = round(on_hand / avg_sold, 1) if avg_sold > 0 else None
        result[iid] = {
            "avg_sold_per_month": avg_sold,
            "total_sold":         total_sold,
            "avg_cost_recent":    purchase_map.get(iid),  # None if no purchases
            "months_cover":       cover,
        }

    # Items with purchases but no sales still get recent cost
    for r in purchases:
        iid = r["item_id"]
        if iid not in result:
            tq = float(r["total_qty"] or 0)
            tc = float(r["total_cost"] or 0)
            if tq > 0:
                result[iid] = {
                    "avg_sold_per_month": 0.0,
                    "total_sold":         0.0,
                    "avg_cost_recent":    round(tc / tq, 4),
                    "months_cover":       None,
                }

    return result

def get_inventory_item(db_path, item_id: int) -> dict | None:
    """Return single inventory item with all linked account details."""
    conn = get_connection(db_path)
    row = conn.execute("""
        SELECT i.*,
               a.name  AS account_name,  a.code AS account_code,
               sa.name AS stock_account_name, sa.code AS stock_account_code,
               ca.name AS cogs_account_name,  ca.code AS cogs_account_code
        FROM items i
        LEFT JOIN accounts a  ON i.account_id      = a.id
        LEFT JOIN accounts sa ON i.stock_account_id = sa.id
        LEFT JOIN accounts ca ON i.cogs_account_id  = ca.id
        WHERE i.id = ?
    """, (item_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_stock_movements(db_path, item_id: int = None,
                         date_from: str = None, date_to: str = None,
                         movement_type: str = None) -> list:
    """Return stock movements, optionally filtered."""
    conn = get_connection(db_path)
    where = "WHERE 1=1"
    params = []
    if item_id:
        where += " AND m.item_id = ?"
        params.append(item_id)
    if date_from:
        where += " AND m.movement_date >= ?"
        params.append(date_from)
    if date_to:
        where += " AND m.movement_date <= ?"
        params.append(date_to)
    if movement_type:
        where += " AND m.movement_type = ?"
        params.append(movement_type)

    rows = conn.execute(f"""
        SELECT m.*, i.name AS item_name, i.code AS item_code
        FROM inventory_movements m
        JOIN items i ON i.id = m.item_id
        {where}
        ORDER BY m.movement_date DESC, m.id DESC
    """, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ─────────────────────────────────────────────────────────────────────────────
#  STOCK RECEIPT HEADERS
# ─────────────────────────────────────────────────────────────────────────────

def create_stock_receipt(db_path, bill_id: int, receipt_date: str,
                          reference: str = "", notes: str = "") -> int:
    """
    Create a stock_receipts header row for one receive-stock session.
    Returns the new receipt id — pass this to each post_stock_movement call
    as receipt_id so all movements from that session are grouped together.
    """
    conn = get_connection(db_path)
    conn.execute("""
        INSERT INTO stock_receipts (bill_id, receipt_date, reference, notes)
        VALUES (?, ?, ?, ?)
    """, (bill_id, receipt_date, reference or "", notes or ""))
    receipt_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit()
    conn.close()
    return receipt_id


def get_stock_receipts(db_path, bill_id: int = None) -> list:
    """
    Return stock receipt headers, optionally filtered to a single bill.
    Each row includes a summary of lines received in that session:
      lines_count  — number of distinct items received
      total_qty    — sum of all qty received
      total_cost   — sum of total_cost across movements
    """
    conn = get_connection(db_path)
    where = "WHERE 1=1"
    params = []
    if bill_id is not None:
        where += " AND r.bill_id = ?"
        params.append(bill_id)

    rows = conn.execute(f"""
        SELECT
            r.id,
            r.bill_id,
            r.receipt_date,
            r.reference,
            r.notes,
            r.created_at,
            COUNT(m.id)        AS lines_count,
            SUM(ABS(m.qty))    AS total_qty,
            SUM(m.total_cost)  AS total_cost
        FROM stock_receipts r
        LEFT JOIN inventory_movements m ON m.receipt_id = r.id
        {where}
        GROUP BY r.id
        ORDER BY r.receipt_date DESC, r.id DESC
    """, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_stock_summary(db_path) -> dict:
    """Return portfolio-level stock summary for dashboard/banner."""
    conn = get_connection(db_path)
    row = conn.execute("""
        SELECT
            COUNT(*)                                           AS total_items,
            SUM(CASE WHEN is_inventoried=1 THEN 1 ELSE 0 END) AS tracked_items,
            SUM(CASE WHEN is_inventoried=1 THEN qty_on_hand * unit_cost ELSE 0 END)
                                                               AS total_stock_value,
            SUM(CASE WHEN is_inventoried=1
                          AND reorder_level > 0
                          AND qty_on_hand <= reorder_level
                     THEN 1 ELSE 0 END)                        AS low_stock_count,
            SUM(CASE WHEN is_inventoried=1
                          AND qty_on_hand < 0
                     THEN 1 ELSE 0 END)                        AS negative_stock_count
        FROM items
    """).fetchone()
    conn.close()
    return dict(row) if row else {}


# ─────────────────────────────────────────────────────────────────────────────
#  SAVE / UPDATE ITEM INVENTORY SETTINGS
# ─────────────────────────────────────────────────────────────────────────────

def save_inventory_settings(db_path, item_id: int, data: dict):
    """
    Update inventory-specific fields on an existing item.
    data keys: is_inventoried, is_livestock, livestock_category,
               livestock_ni_method, livestock_pu_method,
               reorder_level, reorder_qty, unit_cost,
               cogs_account_id, stock_account_id, location, barcode
    """
    fields = ["is_inventoried", "is_livestock",
              "livestock_category", "livestock_ni_method", "livestock_pu_method",
              "reorder_level", "reorder_qty",
              "unit_cost", "cogs_account_id", "stock_account_id", "location", "barcode"]
    conn = get_connection(db_path)
    sets   = ", ".join(f"{f}=?" for f in fields)
    vals   = [data.get(f) for f in fields]
    conn.execute(f"UPDATE items SET {sets} WHERE id=?", vals + [item_id])
    conn.commit()
    conn.close()


# ─────────────────────────────────────────────────────────────────────────────
#  STOCK MOVEMENT ENGINE
# ─────────────────────────────────────────────────────────────────────────────

def post_stock_movement(db_path, item_id: int, movement_type: str,
                         movement_date: str, qty: float,
                         unit_cost: float = None,
                         unit_price: float = None,
                         reference: str = "",
                         source_doc_type: str = None,
                         source_doc_id: int = None,
                         notes: str = "",
                         created_by: str = None,
                         post_gl: bool = True,
                         receipt_id: int = None) -> int:
    """
    Core engine: record a stock movement, update qty_on_hand and weighted
    average unit_cost, optionally post GL entries.

    Returns movement id.

    GL posting rules:
      PURCHASE:   DR Inventory Asset  /  CR Accounts Payable (or Clearing)
      SALE:       DR COGS             /  CR Inventory Asset
      ADJUSTMENT: DR/CR Inventory Asset  /  CR/DR Stock Variance (5-9999)
      WRITE_OFF:  DR Stock Write-off   /  CR Inventory Asset
      RETURN_IN:  DR Inventory Asset  /  CR COGS
      RETURN_OUT: DR AP Clearing      /  CR Inventory Asset
    """
    conn = get_connection(db_path)
    item = conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
    if not item:
        conn.close()
        raise ValueError(f"Item {item_id} not found")

    item = dict(item)
    if not item.get("is_inventoried"):
        conn.close()
        raise ValueError(f"Item '{item['name']}' is not inventory-tracked")

    qty_before = float(item["qty_on_hand"] or 0)
    old_cost   = float(item["unit_cost"] or 0)

    # Determine signed qty (positive = stock in, negative = stock out)
    INBOUND  = {"PURCHASE", "RETURN_IN", "NATURAL_INCREASE"}
    OUTBOUND = {"SALE", "WRITE_OFF", "RETURN_OUT", "DEATH", "PRIVATE_USE"}
    if movement_type in OUTBOUND:
        signed_qty = -abs(qty)
    elif movement_type == "ADJUSTMENT":
        signed_qty = qty           # signed: negative = write down, positive = write up
    else:
        signed_qty = abs(qty)      # INBOUND types always positive

    qty_after = round(qty_before + signed_qty, 6)

    # For natural increase: resolve cost from ATO prescribed value or WAC
    if movement_type == "NATURAL_INCREASE" and unit_cost is None:
        ni_method  = item.get("livestock_ni_method") or "prescribed"
        category   = item.get("livestock_category") or ""
        if ni_method == "prescribed" and category in ATO_PRESCRIBED:
            unit_cost = ATO_PRESCRIBED[category]
        else:
            unit_cost = old_cost

    # Weighted average cost update (only on inbound)
    if unit_cost is None:
        unit_cost = old_cost
    new_avg_cost = old_cost
    if signed_qty > 0 and unit_cost is not None:
        total_existing = qty_before * old_cost if qty_before > 0 else 0
        total_new      = signed_qty * unit_cost
        new_total_qty  = qty_before + signed_qty
        if new_total_qty > 0:
            new_avg_cost = round((total_existing + total_new) / new_total_qty, 6)

    total_cost  = round(abs(signed_qty) * unit_cost, 2) if unit_cost else 0
    total_price = round(abs(qty) * unit_price, 2)       if unit_price else None

    # Write movement record
    conn.execute("""
        INSERT INTO inventory_movements
            (item_id, movement_type, movement_date, qty,
             unit_cost, total_cost, unit_price, total_price,
             reference, source_doc_type, source_doc_id,
             notes, qty_before, qty_after, created_by, receipt_id)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (item_id, movement_type, movement_date, signed_qty,
          unit_cost, total_cost, unit_price, total_price,
          reference, source_doc_type, source_doc_id,
          notes, qty_before, qty_after, created_by, receipt_id))

    mov_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    # Update item stock
    conn.execute("""
        UPDATE items SET qty_on_hand=?, unit_cost=? WHERE id=?
    """, (qty_after, new_avg_cost, item_id))

    conn.commit()
    conn.close()

    # GL posting
    journal_id = None
    if post_gl and item.get("stock_account_id"):
        journal_id = _post_movement_gl(db_path, item, movement_type,
                                        movement_date, abs(qty),
                                        unit_cost, unit_price,
                                        reference, notes)
        if journal_id:
            conn2 = get_connection(db_path)
            conn2.execute("UPDATE inventory_movements SET journal_id=? WHERE id=?",
                          (journal_id, mov_id))
            conn2.commit()
            conn2.close()

    return mov_id


def _post_movement_gl(db_path, item: dict, movement_type: str,
                       movement_date: str, qty: float,
                       unit_cost: float, unit_price: float,
                       reference: str, notes: str) -> int | None:
    """Post GL journal for a stock movement. Returns journal_id or None."""
    from core.ledger import post_journal as _post, get_accounts as _ga
    conn = get_connection(db_path)

    stock_acc = item.get("stock_account_id")
    cogs_acc  = item.get("cogs_account_id")
    total_cost  = round(qty * (unit_cost or 0), 2)
    total_price = round(qty * (unit_price or 0), 2) if unit_price else total_cost

    # Lookup variance / write-off accounts and livestock-specific accounts
    var_acc   = conn.execute(
        "SELECT id FROM accounts WHERE code='5-9999' LIMIT 1").fetchone()
    ap_acc    = conn.execute(
        "SELECT id FROM accounts WHERE account_type='Liability' "
        "AND code LIKE '2-1%' AND is_credit_card=0 ORDER BY code LIMIT 1"
    ).fetchone()
    ni_acc    = conn.execute(
        "SELECT id FROM accounts WHERE code='4-1200' LIMIT 1").fetchone()
    death_acc = conn.execute(
        "SELECT id FROM accounts WHERE code='5-1010' LIMIT 1").fetchone()
    pu_acc    = conn.execute(
        "SELECT id FROM accounts WHERE code='3-9100' LIMIT 1").fetchone()
    conn.close()

    lines = []
    desc  = f"{item['name']} — {movement_type.title()}"
    if notes:
        desc += f" | {notes}"

    if movement_type == "PURCHASE" and total_cost > 0:
        # DR Inventory  /  CR AP Clearing (or variance if no AP)
        cr_acc = ap_acc["id"] if ap_acc else (var_acc["id"] if var_acc else None)
        if cr_acc:
            lines = [
                {"account_id": stock_acc, "debit": total_cost, "credit": 0,
                 "description": desc},
                {"account_id": cr_acc,    "debit": 0, "credit": total_cost,
                 "description": desc},
            ]
    elif movement_type == "SALE" and cogs_acc and total_cost > 0:
        # DR COGS  /  CR Inventory
        lines = [
            {"account_id": cogs_acc,   "debit": total_cost,  "credit": 0,
             "description": desc},
            {"account_id": stock_acc,  "debit": 0, "credit": total_cost,
             "description": desc},
        ]
    elif movement_type in ("ADJUSTMENT", "WRITE_OFF") and var_acc and total_cost > 0:
        # Adjustment: DR/CR Inventory  vs  Stock Variance
        lines = [
            {"account_id": stock_acc,      "debit": total_cost,  "credit": 0,
             "description": desc},
            {"account_id": var_acc["id"],  "debit": 0, "credit": total_cost,
             "description": desc},
        ]
    elif movement_type == "RETURN_IN" and cogs_acc and total_cost > 0:
        # DR Inventory  /  CR COGS
        lines = [
            {"account_id": stock_acc, "debit": total_cost, "credit": 0,
             "description": desc},
            {"account_id": cogs_acc,  "debit": 0, "credit": total_cost,
             "description": desc},
        ]
    elif movement_type == "NATURAL_INCREASE" and total_cost > 0 and ni_acc:
        # DR Livestock Asset  /  CR Natural Increase Income
        lines = [
            {"account_id": stock_acc,    "debit": total_cost, "credit": 0,
             "description": desc},
            {"account_id": ni_acc["id"], "debit": 0, "credit": total_cost,
             "description": desc},
        ]
    elif movement_type == "DEATH" and total_cost > 0 and death_acc:
        # DR Livestock Deaths  /  CR Livestock Asset
        lines = [
            {"account_id": death_acc["id"], "debit": total_cost, "credit": 0,
             "description": desc},
            {"account_id": stock_acc,       "debit": 0, "credit": total_cost,
             "description": desc},
        ]
    elif movement_type == "PRIVATE_USE" and total_cost > 0 and pu_acc:
        # DR Livestock Private Use (Drawings)  /  CR Livestock Asset
        lines = [
            {"account_id": pu_acc["id"], "debit": total_cost, "credit": 0,
             "description": desc},
            {"account_id": stock_acc,    "debit": 0, "credit": total_cost,
             "description": desc},
        ]

    if not lines:
        return None

    try:
        return _post(db_path, movement_date, desc, reference or "", lines)
    except Exception:
        return None


# ─────────────────────────────────────────────────────────────────────────────
#  STOCK ADJUSTMENT HELPER
# ─────────────────────────────────────────────────────────────────────────────

def adjust_stock(db_path, item_id: int, new_qty: float,
                  adjustment_date: str = None,
                  reason: str = "Stock count correction",
                  unit_cost: float = None,
                  created_by: str = None) -> int:
    """
    Set stock to a specific quantity (e.g. after a physical count).
    The difference is posted as an ADJUSTMENT movement.
    Returns movement id.
    """
    if adjustment_date is None:
        adjustment_date = str(_date.today())

    conn = get_connection(db_path)
    item = conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
    conn.close()
    if not item:
        raise ValueError(f"Item {item_id} not found")

    item     = dict(item)
    current  = float(item["qty_on_hand"] or 0)
    diff     = round(new_qty - current, 6)
    if diff == 0:
        return 0  # no change

    if unit_cost is None:
        unit_cost = float(item.get("unit_cost") or 0)

    return post_stock_movement(
        db_path, item_id, "ADJUSTMENT",
        adjustment_date, diff,
        unit_cost=unit_cost,
        reference="ADJ",
        notes=reason,
        created_by=created_by,
        post_gl=True,
    )


# ─────────────────────────────────────────────────────────────────────────────
#  VALUATION REPORT
# ─────────────────────────────────────────────────────────────────────────────

def stock_valuation_report(db_path, as_at_date: str = None) -> dict:
    """
    Stock on hand valuation at a point in time.
    Uses current qty_on_hand and weighted avg cost (simplified — does not
    rewind history to the as_at date).
    Returns:
        { rows: [...], total_value: float, total_items: int }
    """
    items = get_inventory_items(db_path)
    rows  = []
    total = 0.0
    for item in items:
        qty   = float(item.get("qty_on_hand") or 0)
        cost  = float(item.get("unit_cost") or 0)
        value = round(qty * cost, 2)
        total += value
        rows.append({
            "item_id":    item["id"],
            "code":       item.get("code") or "",
            "name":       item["name"],
            "qty_on_hand":qty,
            "unit_cost":  cost,
            "total_value":value,
            "reorder_level": float(item.get("reorder_level") or 0),
            "is_low_stock":  int(item.get("is_low_stock") or 0),
            "location":      item.get("location") or "",
        })
    return {
        "as_at":        as_at_date or str(_date.today()),
        "rows":         rows,
        "total_value":  round(total, 2),
        "total_items":  len(rows),
    }


# ─────────────────────────────────────────────────────────────────────────────
#  LOW STOCK ALERTS
# ─────────────────────────────────────────────────────────────────────────────

def get_low_stock_items(db_path) -> list:
    """Return items where qty_on_hand <= reorder_level (and reorder_level > 0)."""
    return get_inventory_items(db_path, low_stock_only=True)


# ─────────────────────────────────────────────────────────────────────────────
#  SEEDING: default stock GL accounts
# ─────────────────────────────────────────────────────────────────────────────

def ensure_stock_accounts(db_path):
    """
    Ensure the standard inventory GL accounts exist.
    Called during migrate_inventory setup.
    """
    from core.database import get_connection as _gc
    conn = _gc(db_path)
    needs = [
        ("1-1500", "Inventory Asset",        "Asset",   "Current Asset",   0),
        ("5-1000", "Cost of Goods Sold",      "Expense", "Direct Cost",     0),
        ("5-9999", "Stock Variance / Write-off","Expense","Direct Cost",    0),
    ]
    for code, name, atype, subtype, opening in needs:
        existing = conn.execute(
            "SELECT id FROM accounts WHERE code=?", (code,)).fetchone()
        if not existing:
            conn.execute("""
                INSERT INTO accounts
                    (code, name, account_type, account_subtype, is_active, opening_balance)
                VALUES (?,?,?,?,1,?)
            """, (code, name, atype, subtype, opening))
    conn.commit()
    conn.close()


def get_livestock_category_list() -> list:
    """Return ATO livestock categories with prescribed values for the UI."""
    return [{"key": k, "label": l, "prescribed": v}
            for k, l, v in ATO_LIVESTOCK_CATEGORIES]


def ensure_livestock_accounts(db_path):
    """Seed default GL accounts for livestock trading if they don't already exist."""
    from core.database import get_connection as _gc
    conn = _gc(db_path)
    needs = [
        ("1-1600", "Livestock",                    "Asset",   "Current Asset", 0),
        ("4-1200", "Natural Increase — Livestock", "Income",  "Income",        0),
        ("5-1010", "Livestock Deaths",             "Expense", "Direct Cost",   0),
        ("5-1400", "Livestock Cost of Sales",      "Expense", "Direct Cost",   0),
        ("3-9100", "Livestock Private Use",        "Equity",  "Owner Equity",  0),
    ]
    for code, name, atype, subtype, opening in needs:
        if not conn.execute("SELECT id FROM accounts WHERE code=?", (code,)).fetchone():
            conn.execute("""
                INSERT INTO accounts
                    (code, name, account_type, account_subtype, is_active, opening_balance)
                VALUES (?,?,?,?,1,?)
            """, (code, name, atype, subtype, opening))
    conn.commit()
    conn.close()


# ─────────────────────────────────────────────────────────────────────────────
#  LIVESTOCK TRADING STATEMENT
# ─────────────────────────────────────────────────────────────────────────────

def get_livestock_trading_statement(db_path, date_from: str, date_to: str) -> dict:
    """
    Livestock Trading Account for a date range.

    Returns:
        items[]:   per-item breakdown
        totals:    { opening_stock, purchases, natural_increase, deaths,
                     private_use, closing_stock, cogs, sales_revenue, gross_income }
    """
    conn = get_connection(db_path)

    livestock_items = conn.execute(
        "SELECT * FROM items WHERE is_livestock=1 AND is_inventoried=1 AND is_active=1"
    ).fetchall()
    livestock_items = [dict(r) for r in livestock_items]

    item_rows = []
    totals = {
        "opening_stock":    0.0,
        "purchases":        0.0,
        "natural_increase": 0.0,
        "deaths":           0.0,
        "private_use":      0.0,
        "closing_stock":    0.0,
        "cogs":             0.0,
        "sales_revenue":    0.0,
    }

    for item in livestock_items:
        iid  = item["id"]
        cost = float(item.get("unit_cost") or 0)
        qty  = float(item.get("qty_on_hand") or 0)

        # Movements in period
        movs = conn.execute("""
            SELECT movement_type, SUM(ABS(qty)) AS total_qty,
                   SUM(total_cost) AS total_cost, SUM(total_price) AS total_price
            FROM inventory_movements
            WHERE item_id=? AND movement_date BETWEEN ? AND ?
            GROUP BY movement_type
        """, (iid, date_from, date_to)).fetchall()
        movs = {r["movement_type"]: dict(r) for r in movs}

        # Opening stock: qty_before of chronologically first movement in period
        first_mov = conn.execute("""
            SELECT qty_before, unit_cost FROM inventory_movements
            WHERE item_id=? AND movement_date BETWEEN ? AND ?
            ORDER BY movement_date, id LIMIT 1
        """, (iid, date_from, date_to)).fetchone()

        if first_mov:
            opening_qty  = float(first_mov["qty_before"] or 0)
            opening_cost = float(first_mov["unit_cost"] or cost)
        else:
            # No movements in period — opening = closing = current
            opening_qty  = qty
            opening_cost = cost
        opening_value = round(opening_qty * opening_cost, 2)

        # Closing stock: current position
        closing_value = round(qty * cost, 2)

        def mv(mtype, field="total_cost"):
            v = movs.get(mtype, {}).get(field) or 0
            return round(float(v), 2)

        purchases       = mv("PURCHASE")
        natural_increase= mv("NATURAL_INCREASE")
        deaths          = mv("DEATH")
        private_use     = mv("PRIVATE_USE")
        cogs            = mv("SALE")
        sales_revenue   = mv("SALE", "total_price")
        if sales_revenue == 0:
            sales_revenue = cogs  # fall back to cost if no price recorded

        item_rows.append({
            "id":               iid,
            "code":             item.get("code") or "",
            "name":             item["name"],
            "opening_qty":      opening_qty,
            "opening_value":    opening_value,
            "purchases":        purchases,
            "natural_increase": natural_increase,
            "deaths":           deaths,
            "private_use":      private_use,
            "closing_qty":      qty,
            "closing_value":    closing_value,
            "cogs":             cogs,
            "sales_revenue":    sales_revenue,
        })

        totals["opening_stock"]    += opening_value
        totals["purchases"]        += purchases
        totals["natural_increase"] += natural_increase
        totals["deaths"]           += deaths
        totals["private_use"]      += private_use
        totals["closing_stock"]    += closing_value
        totals["cogs"]             += cogs
        totals["sales_revenue"]    += sales_revenue

    conn.close()

    # Round totals
    for k in totals:
        totals[k] = round(totals[k], 2)

    totals["gross_income"] = round(
        totals["sales_revenue"] - totals["cogs"], 2)

    return {
        "date_from":  date_from,
        "date_to":    date_to,
        "items":      item_rows,
        "totals":     totals,
        "item_count": len(item_rows),
    }
