"""
dbox - Database Schema and Connection Management
SQLite single-file portable database
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.


import sqlite3


def get_connection(db_path):
    conn = sqlite3.connect(db_path, timeout=10)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")   # concurrent read+write, crash-safe
    conn.execute("PRAGMA synchronous = NORMAL")  # safe with WAL, faster than FULL
    conn.row_factory = sqlite3.Row
    return conn


def initialise_database(db_path):
    conn = get_connection(db_path)
    c = conn.cursor()

    c.execute("""CREATE TABLE IF NOT EXISTS company (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        name TEXT NOT NULL, abn TEXT, acn TEXT,
        address TEXT, city TEXT, state TEXT, postcode TEXT,
        phone TEXT, email TEXT, website TEXT,
        gst_registered INTEGER DEFAULT 1,
        fy_start_month INTEGER DEFAULT 7,
        logo_path TEXT,
        default_payment_instructions TEXT,
        created_at TEXT DEFAULT (datetime('now','localtime')))""")

    c.execute("""CREATE TABLE IF NOT EXISTS accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
        account_type TEXT NOT NULL, account_subtype TEXT,
        description TEXT, is_bank INTEGER DEFAULT 0,
        bsb TEXT, account_number TEXT,
        tax_code TEXT DEFAULT 'GST', is_active INTEGER DEFAULT 1,
        parent_id INTEGER REFERENCES accounts(id),
        opening_balance REAL DEFAULT 0.0,
        created_at TEXT DEFAULT (datetime('now','localtime')))""")

    c.execute("""CREATE TABLE IF NOT EXISTS tax_codes (
        code TEXT PRIMARY KEY, description TEXT NOT NULL,
        rate REAL NOT NULL, is_active INTEGER DEFAULT 1)""")

    c.execute("""CREATE TABLE IF NOT EXISTS contacts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        contact_type TEXT NOT NULL, name TEXT NOT NULL,
        abn TEXT, contact_person TEXT, email TEXT, phone TEXT,
        address TEXT, city TEXT, state TEXT, postcode TEXT,
        payment_terms INTEGER DEFAULT 30,
        default_tax_code TEXT DEFAULT 'GST',
        ar_account_id INTEGER REFERENCES accounts(id),
        ap_account_id INTEGER REFERENCES accounts(id),
        notes TEXT, is_active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT (datetime('now','localtime')))""")

    c.execute("""CREATE TABLE IF NOT EXISTS journal_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entry_date TEXT NOT NULL, reference TEXT,
        description TEXT NOT NULL, entry_type TEXT NOT NULL,
        source_id INTEGER, source_type TEXT,
        is_reconciled INTEGER DEFAULT 0,
        created_at TEXT DEFAULT (datetime('now','localtime')))""")

    c.execute("""CREATE TABLE IF NOT EXISTS journal_lines (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        journal_id INTEGER NOT NULL REFERENCES journal_entries(id) ON DELETE CASCADE,
        account_id INTEGER NOT NULL REFERENCES accounts(id),
        debit REAL DEFAULT 0.0, credit REAL DEFAULT 0.0,
        description TEXT, tax_code TEXT, gst_amount REAL DEFAULT 0.0,
        contact_id INTEGER REFERENCES contacts(id))""")

    c.execute("""CREATE TABLE IF NOT EXISTS invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_number TEXT NOT NULL UNIQUE,
        contact_id INTEGER NOT NULL REFERENCES contacts(id),
        invoice_date TEXT NOT NULL, due_date TEXT NOT NULL,
        status TEXT DEFAULT 'Draft',
        subtotal REAL DEFAULT 0.0, gst_total REAL DEFAULT 0.0,
        total REAL DEFAULT 0.0, amount_paid REAL DEFAULT 0.0,
        notes TEXT,
        payment_instructions TEXT,
        internal_comments TEXT,
        journal_id INTEGER REFERENCES journal_entries(id),
        created_at TEXT DEFAULT (datetime('now','localtime')))""")

    c.execute("""CREATE TABLE IF NOT EXISTS invoice_lines (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
        description TEXT NOT NULL, quantity REAL DEFAULT 1.0,
        unit_price REAL DEFAULT 0.0, tax_code TEXT DEFAULT 'GST',
        gst_amount REAL DEFAULT 0.0, line_total REAL DEFAULT 0.0,
        account_id INTEGER REFERENCES accounts(id))""")

    c.execute("""CREATE TABLE IF NOT EXISTS bills (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bill_number TEXT,
        contact_id INTEGER NOT NULL REFERENCES contacts(id),
        bill_date TEXT NOT NULL, due_date TEXT NOT NULL,
        status TEXT DEFAULT 'Draft',
        subtotal REAL DEFAULT 0.0, gst_total REAL DEFAULT 0.0,
        total REAL DEFAULT 0.0, amount_paid REAL DEFAULT 0.0,
        notes TEXT, journal_id INTEGER REFERENCES journal_entries(id),
        created_at TEXT DEFAULT (datetime('now','localtime')))""")

    c.execute("""CREATE TABLE IF NOT EXISTS bill_lines (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bill_id INTEGER NOT NULL REFERENCES bills(id) ON DELETE CASCADE,
        description TEXT NOT NULL, quantity REAL DEFAULT 1.0,
        unit_price REAL DEFAULT 0.0, tax_code TEXT DEFAULT 'GST',
        gst_amount REAL DEFAULT 0.0, line_total REAL DEFAULT 0.0,
        account_id INTEGER REFERENCES accounts(id))""")

    c.execute("""CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        payment_type TEXT NOT NULL,
        contact_id INTEGER REFERENCES contacts(id),
        payment_date TEXT NOT NULL, amount REAL NOT NULL,
        bank_account_id INTEGER NOT NULL REFERENCES accounts(id),
        reference TEXT, description TEXT,
        journal_id INTEGER REFERENCES journal_entries(id),
        created_at TEXT DEFAULT (datetime('now','localtime')))""")

    c.execute("""CREATE TABLE IF NOT EXISTS payment_allocations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        payment_id INTEGER NOT NULL REFERENCES payments(id) ON DELETE CASCADE,
        invoice_id INTEGER REFERENCES invoices(id),
        bill_id INTEGER REFERENCES bills(id),
        amount REAL NOT NULL)""")

    c.execute("""CREATE TABLE IF NOT EXISTS bank_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        account_id INTEGER NOT NULL REFERENCES accounts(id),
        transaction_date TEXT NOT NULL, description TEXT,
        reference TEXT, debit REAL DEFAULT 0.0,
        credit REAL DEFAULT 0.0, balance REAL DEFAULT 0.0,
        is_reconciled INTEGER DEFAULT 0, reconciled_date TEXT,
        journal_id INTEGER REFERENCES journal_entries(id),
        imported_at TEXT DEFAULT (datetime('now','localtime')))""")

    c.execute("""CREATE TABLE IF NOT EXISTS bank_reconciliations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        account_id INTEGER NOT NULL REFERENCES accounts(id),
        reconcile_date TEXT NOT NULL, closing_balance REAL NOT NULL,
        status TEXT DEFAULT 'Open',
        created_at TEXT DEFAULT (datetime('now','localtime')))""")

    # ── Schema migrations (safe for existing databases) ───────────────────
    _migrate(conn)
    _migrate_budget_and_users(conn)
    # Payroll schema
    try:
        from core.payroll import migrate_payroll
        migrate_payroll(conn)
    except Exception:
        pass
    # CRM schema
    try:
        from core.crm import migrate_crm
        migrate_crm(conn)
    except Exception:
        pass
    # Jobs/Projects schema
    try:
        from core.jobs import migrate_jobs
        migrate_jobs(conn)
    except Exception:
        pass
    # Recurring transactions schema
    try:
        from core.recurring import migrate_recurring
        migrate_recurring(conn)
    except Exception:
        pass
    # Item catalogue schema
    try:
        from core.items import migrate_items
        migrate_items(conn)
    except Exception:
        pass

    # Inventory / stock tracking schema
    try:
        from core.inventory import migrate_inventory, ensure_stock_accounts, ensure_livestock_accounts
        migrate_inventory(conn)
        conn.commit()
        ensure_stock_accounts(db_path)
        ensure_livestock_accounts(db_path)
    except Exception:
        pass

    # Promotions schema
    try:
        from core.promotions import migrate_promotions
        migrate_promotions(conn)
        conn.commit()
    except Exception:
        pass

    # Discount limits schema
    try:
        from core.discounts import migrate_discount_limits
        migrate_discount_limits(conn)
        conn.commit()
    except Exception:
        pass

    # Licence log schema
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS licence_log (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            event_at     TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
            action       TEXT    NOT NULL,
            licence_id   TEXT,
            build        TEXT,
            eula_version TEXT,
            os_info      TEXT,
            detail       TEXT
        )""")
        conn.execute("""CREATE INDEX IF NOT EXISTS idx_licence_log_event_at
            ON licence_log (event_at)""")
        conn.commit()
    except Exception:
        pass

    # Purchase Orders schema
    try:
        from core.purchase_orders import migrate_purchase_orders
        migrate_purchase_orders(conn)
        conn.commit()
    except Exception:
        pass

    # Fixed Assets schema
    try:
        from core.fixed_assets import migrate_fixed_assets
        migrate_fixed_assets(conn)
        conn.commit()
    except Exception:
        pass

    # Migration-safe: add item_id to invoice_lines and bill_lines for inventory wiring
    for tbl in ("invoice_lines", "bill_lines"):
        try:
            conn.execute(f"ALTER TABLE {tbl} ADD COLUMN item_id INTEGER REFERENCES items(id)")
        except Exception:
            pass

    conn.commit()
    conn.close()


def _migrate(conn):
    """Add new columns to existing databases without losing data."""

    # Unique index: account + date + running balance is genuinely unique per bank row.
    # We intentionally do NOT include description/amount because the same payee/amount
    # can legitimately appear multiple times (e.g. weekly rent, duplicate payees).
    # If the CSV has no balance column (all zeros), fall back to account+date+description+debit+credit.
    try:
        conn.execute("""DROP INDEX IF EXISTS idx_banktxn_unique""")
    except Exception:
        pass
    try:
        conn.execute("""CREATE UNIQUE INDEX IF NOT EXISTS idx_banktxn_balance
            ON bank_transactions(account_id, transaction_date, balance)
            WHERE balance != 0""")
    except Exception:
        pass

    # Add reconciliation columns to journal_lines for bank rec
    for col, defn in [
        ("is_reconciled",   "INTEGER DEFAULT 0"),
        ("reconciled_date", "TEXT"),
    ]:
        try:
            conn.execute(f"ALTER TABLE journal_lines ADD COLUMN {col} {defn}")
        except Exception:
            pass

    migrations = [
        ("invoices",  "payment_instructions",           "TEXT"),
        ("invoices",  "internal_comments",              "TEXT"),
        ("company",   "logo_path",                      "TEXT"),
        ("company",   "default_payment_instructions",   "TEXT"),
        ("company",   "aba_user_id",                    "TEXT"),
        ("company",   "aba_description",                "TEXT DEFAULT 'PAYMENT'"),
        # Licence tier — controls which modules are visible
        ("company",   "tier",                           "TEXT DEFAULT 'full'"),
        # Stock receiving tracking on bill lines
        ("bill_lines", "qty_received",                  "REAL DEFAULT 0"),
        # CRM opportunity link on invoices and bills
        ("invoices",   "opp_id",                        "INTEGER REFERENCES crm_opportunities(id)"),
        ("bills",      "opp_id",                        "INTEGER REFERENCES crm_opportunities(id)"),
        # Supplier bank details for ABA direct-entry payments
        ("contacts",  "bsb",                            "TEXT"),
        ("contacts",  "account_number",                 "TEXT"),
        ("contacts",  "bank_account_name",              "TEXT"),
        # Job and expense account on payments (for non-bill payments)
        ("payments",  "job_id",                         "INTEGER"),
        ("payments",  "expense_account_id",             "INTEGER"),
        ("invoice_lines", "line_type",                  "TEXT DEFAULT 'item'"),
    ]
    for table, col, coltype in migrations:
        try:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {coltype}")
        except Exception:
            pass  # Column already exists — expected, safe to ignore

    for tbl in ("invoices", "bills"):
        try:
            conn.execute(f"CREATE INDEX IF NOT EXISTS idx_{tbl}_opp ON {tbl}(opp_id)")
        except Exception:
            pass

    # Attachments table (migration-safe CREATE IF NOT EXISTS)
    conn.execute("""CREATE TABLE IF NOT EXISTS attachments (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        source_type TEXT NOT NULL,   -- 'invoice','bill','payment','journal'
        source_id   INTEGER NOT NULL,
        filename    TEXT NOT NULL,
        mime_type   TEXT,
        file_size   INTEGER,
        file_data   BLOB NOT NULL,
        description TEXT,
        uploaded_at TEXT DEFAULT (datetime('now','localtime')))""")
    conn.execute("""CREATE INDEX IF NOT EXISTS idx_attachments_source
        ON attachments(source_type, source_id)""")

    # Add opening_balance to bank_reconciliations for carry-forward
    try:
        conn.execute("ALTER TABLE bank_reconciliations ADD COLUMN opening_balance REAL DEFAULT 0.0")
    except Exception:
        pass

    # is_system flag on contacts — system contacts cannot be deleted
    try:
        conn.execute("ALTER TABLE contacts ADD COLUMN is_system INTEGER DEFAULT 0")
    except Exception:
        pass

    # contact_id on journal_entries — for contact-based allocations
    try:
        conn.execute("ALTER TABLE journal_entries ADD COLUMN contact_id INTEGER REFERENCES contacts(id)")
    except Exception:
        pass

    # alloc_mode on bank_transactions — tracks how it was categorised
    try:
        conn.execute("ALTER TABLE bank_transactions ADD COLUMN alloc_mode TEXT")
    except Exception:
        pass

    # Seed the "Cash" system contact if it doesn't exist
    existing = conn.execute(
        "SELECT id FROM contacts WHERE is_system=1 AND name='Cash'").fetchone()
    if not existing:
        conn.execute("""INSERT INTO contacts
            (contact_type, name, is_system, is_active, notes)
            VALUES ('Both','Cash',1,1,'System contact — used for cash transactions')""")
    conn.commit()

    # Add is_rejected flag to bank_transactions and journal_lines
    for tbl in ("bank_transactions", "journal_lines"):
        try:
            conn.execute(f"ALTER TABLE {tbl} ADD COLUMN is_rejected INTEGER DEFAULT 0")
        except Exception:
            pass

    # CSV import schema table — saves column mappings per account
    conn.execute("""CREATE TABLE IF NOT EXISTS csv_import_schemas (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        account_id  INTEGER NOT NULL REFERENCES accounts(id),
        schema_name TEXT NOT NULL,
        mappings    TEXT NOT NULL,
        created_at  TEXT DEFAULT (datetime('now','localtime')),
        UNIQUE(account_id, schema_name))""")

    # Bank categorisation rules — auto-categorise by description pattern
    conn.execute("""CREATE TABLE IF NOT EXISTS bank_rules (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        rule_name     TEXT NOT NULL,
        match_field   TEXT NOT NULL DEFAULT 'description',  -- 'description'|'reference'
        match_type    TEXT NOT NULL DEFAULT 'contains',     -- 'contains'|'startswith'|'exact'
        match_value   TEXT NOT NULL,                        -- pattern to match (case-insensitive)
        direction     TEXT NOT NULL DEFAULT 'both',         -- 'debit'|'credit'|'both'
        account_id    INTEGER REFERENCES accounts(id),      -- GL account to post to
        contact_id    INTEGER REFERENCES contacts(id),      -- contact to assign
        is_active     INTEGER NOT NULL DEFAULT 1,
        priority      INTEGER NOT NULL DEFAULT 0,           -- higher = checked first
        created_at    TEXT DEFAULT (datetime('now','localtime')))""")

    # PAYG tax rate table — editable per financial year
    # brackets_json:           [[threshold, base_tax, marginal_rate], ...]  Scale 1 (with threshold)
    # brackets_no_thresh_json: [[threshold, base_tax, marginal_rate], ...]  Scale 4 (no threshold)
    # medicare_json:           {full_rate, full_start, shade_in_start, shade_in_rate}
    # lito_json:               [[income_up_to, max_offset, reduction_rate], ...]  (with threshold)
    # lito_no_thresh_json:     same structure but for employees who haven't claimed threshold
    # help_json:               [[repayment_income_from, rate], ...]
    # help_method:             'whole' (pre-2025-26) or 'marginal' (2025-26+)
    # sapto_json:              {single_max, single_shade_start, couple_max, couple_shade_start, shade_rate}
    conn.execute("""CREATE TABLE IF NOT EXISTS payg_tax_rates (
        id                       INTEGER PRIMARY KEY AUTOINCREMENT,
        fy_year                  INTEGER NOT NULL UNIQUE,
        label                    TEXT NOT NULL,
        brackets_json            TEXT NOT NULL,
        brackets_no_thresh_json  TEXT NOT NULL DEFAULT '[]',
        medicare_json            TEXT NOT NULL,
        lito_json                TEXT NOT NULL,
        lito_no_thresh_json      TEXT NOT NULL DEFAULT '[]',
        help_json                TEXT NOT NULL DEFAULT '[]',
        help_method              TEXT NOT NULL DEFAULT 'whole',
        sapto_json               TEXT NOT NULL DEFAULT '{}',
        no_tfn_rate              REAL NOT NULL DEFAULT 0.47,
        notes                    TEXT,
        updated_at               TEXT DEFAULT (datetime('now','localtime')))""")

    import json as _json

    # Migrate existing databases — add any missing columns
    for col, dflt in [
        ("brackets_no_thresh_json", "TEXT NOT NULL DEFAULT '[]'"),
        ("lito_no_thresh_json",     "TEXT NOT NULL DEFAULT '[]'"),
        ("help_json",               "TEXT NOT NULL DEFAULT '[]'"),
        ("help_method",             "TEXT NOT NULL DEFAULT 'whole'"),
        ("sapto_json",              "TEXT NOT NULL DEFAULT '{}'"),
    ]:
        try:
            conn.execute(f"ALTER TABLE payg_tax_rates ADD COLUMN {col} {dflt}")
        except Exception:
            pass

    # ── Correct ATO rates sourced directly from ato.gov.au ───────────────────
    # Source: ato.gov.au/tax-rates-and-codes/tax-rates-australian-residents
    # Stage 3 tax cuts apply from 1 July 2024 (FY 2024-25 and 2025-26)

    # Scale 1 — WITH tax-free threshold claimed (primary job)
    _BRACKETS_STAGE3 = [
        # [threshold, base_tax_at_threshold, marginal_rate_above]
        [0,       0.00,    0.000],   # nil to $18,200
        [18200,   0.00,    0.160],   # 16c per $1 over $18,200
        [45000,   4288.00, 0.300],   # $4,288 + 30c per $1 over $45,000
        [135000,  31288.00, 0.370],  # $31,288 + 37c per $1 over $135,000
        [190000,  51638.00, 0.450],  # $51,638 + 45c per $1 over $190,000
    ]
    # Scale 4 — WITHOUT tax-free threshold (second job / did not claim)
    # No $18,200 tax-free band — 16c from dollar 1 through $45,000
    # base at $45,000 = 45000 * 0.16 = $7,200
    _BRACKETS_STAGE3_NO_THRESH = [
        [0,       0.00,     0.160],  # 16c from $1 (no free zone)
        [45000,   7200.00,  0.300],  # $7,200 + 30c over $45,000
        [135000,  34200.00, 0.370],  # $34,200 + 37c over $135,000
        [190000,  54550.00, 0.450],  # $54,550 + 45c over $190,000
    ]

    # 2026-27: 16% → 15% from 1 July 2026
    _BRACKETS_2627 = [
        [0,       0.00,    0.000],
        [18200,   0.00,    0.150],   # 15c per $1 over $18,200
        [45000,   4020.00, 0.300],   # (45000-18200)*0.15 = $4,020
        [135000,  31020.00, 0.370],
        [190000,  51370.00, 0.450],
    ]
    # Scale 4 for 2026-27: 15c from $1 through $45,000; base = 45000*0.15 = $6,750
    _BRACKETS_2627_NO_THRESH = [
        [0,       0.00,     0.150],  # 15c from $1
        [45000,   6750.00,  0.300],
        [135000,  33750.00, 0.370],
        [190000,  54100.00, 0.450],
    ]

    # Medicare levy — updated 2024-25 thresholds
    # Low income threshold: $27,222 (individuals); shade-in from $21,778 at 10c/$
    _MEDICARE_2425 = {
        "full_rate": 0.020, "full_start": 27222.0,
        "shade_in_start": 21778.0, "shade_in_rate": 0.100,
    }
    # 2025-26: same thresholds (no change announced)
    _MEDICARE_2526 = _MEDICARE_2425

    # LITO — unchanged since 2020-21: max $700, same bands for both years
    # Source: ato.gov.au/individuals-and-families/income-deductions-offsets-and-records/tax-offsets/low-income-tax-offset
    _LITO_WITH = [
        [37500,  700.0, 0.000],   # full $700 up to $37,500
        [45000,  700.0, 0.050],   # tapers 5c/$ over $37,500
        [66667,  325.0, 0.015],   # tapers 1.5c/$ over $45,000  (→ $0 at $66,667)
        [999999,   0.0, 0.000],
    ]
    # Without threshold: no LITO (ATO Schedule 1)
    _LITO_NO = []

    # HELP/VSL/SSL 2024-25 — WHOLE income rate method
    # Source: ato.gov.au/tax-rates-and-codes/study-and-training-support-loans-rates-and-repayment-thresholds
    # Table 2: 2024-25 thresholds. Rate applied to ENTIRE repayment income.
    _HELP_2425 = [
        [0,        0.0000],
        [54435,    0.0100],
        [62851,    0.0200],
        [66621,    0.0250],
        [70619,    0.0300],
        [74856,    0.0350],
        [79347,    0.0400],
        [84108,    0.0450],
        [89155,    0.0500],
        [94504,    0.0550],
        [100175,   0.0600],
        [106186,   0.0650],
        [112557,   0.0700],
        [119310,   0.0750],
        [126468,   0.0800],
        [134057,   0.0850],
        [142101,   0.0900],
        [150627,   0.0950],
        [159664,   0.1000],
    ]

    # HELP/VSL/SSL 2025-26 — NEW MARGINAL method (Universities Accord Act, 2 Aug 2025)
    # Source: Table 1: 2025-26 thresholds and rates
    # Repayment = marginal rate × (income − threshold), EXCEPT above $179,286 = 10% × whole income
    # Stored as [[threshold, marginal_rate_above_threshold], ...]
    # Special last band: [179286, 0.10] signals whole-income 10% mode (handled by engine)
    _HELP_2526 = [
        [0,       0.0000],   # nil below $67,000
        [67000,   0.1500],   # 15c per $1 over $67,000
        [125000,  0.1700],   # $8,700 + 17c per $1 over $125,000
        [179286, -0.1000],   # sentinel: negative rate = whole-income 10% above this
    ]

    # SAPTO 2024-25 — Senior Australians and Pensioners Tax Offset
    # Source: ato.gov.au — single max $2,230, shade-in $32,279; couple $1,602, shade-in $28,974
    _SAPTO_2425 = {
        "single_max": 2230.0, "single_shade_start": 32279.0,
        "couple_max": 1602.0, "couple_shade_start": 28974.0,
        "shade_rate": 0.125,
    }
    # 2025-26: same SAPTO (no change announced)
    _SAPTO_2526 = _SAPTO_2425

    _PAYG_DEFAULTS = [
        {
            "fy_year": 2025, "label": "2024-25",
            "brackets": _BRACKETS_STAGE3,
            "brackets_no_thresh": _BRACKETS_STAGE3_NO_THRESH,
            "medicare": _MEDICARE_2425,
            "lito": _LITO_WITH, "lito_no_thresh": _LITO_NO,
            "help": _HELP_2425, "help_method": "whole",
            "sapto": _SAPTO_2425, "no_tfn_rate": 0.47,
            "notes": (
                "ATO 2024-25 — Stage 3 tax cuts (from 1 July 2024).\n"
                "Scale 1 (threshold claimed): 0%/$18,201; 16%/$18,201; 30%/$45,001; 37%/$135,001; 45%/$190,001+\n"
                "Scale 4 (no threshold): 16% from $1; 30%/$45,001; 37%/$135,001; 45%/$190,001+\n"
                "Source: ato.gov.au/tax-rates-and-codes/tax-rates-australian-residents\n"
                "HELP: whole-income rate method, 19-band table. Min threshold $54,435.\n"
                "Medicare: low-income threshold $27,222 (shade-in from $21,778).\n"
                "LITO: max $700, tapers to nil at $66,667. No LITO without threshold.\n"
                "SAPTO: single $2,230 (shade from $32,279), couple $1,602 (shade from $28,974).\n"
                "Last verified: March 2026 against ATO website."
            ),
        },
        {
            "fy_year": 2026, "label": "2025-26",
            "brackets": _BRACKETS_STAGE3,
            "brackets_no_thresh": _BRACKETS_STAGE3_NO_THRESH,
            "medicare": _MEDICARE_2526,
            "lito": _LITO_WITH, "lito_no_thresh": _LITO_NO,
            "help": _HELP_2526, "help_method": "marginal",
            "sapto": _SAPTO_2526, "no_tfn_rate": 0.47,
            "notes": (
                "ATO 2025-26 — same income tax brackets as 2024-25 (Stage 3 unchanged).\n"
                "Scale 4 (no threshold): 16% from $1; 30%/$45,001; 37%/$135,001; 45%/$190,001+\n"
                "Source: ato.gov.au/tax-rates-and-codes/tax-rates-australian-residents\n"
                "HELP: NEW marginal method from 24 Sep 2025 (Universities Accord Act 2025).\n"
                "  Nil below $67,000; 15c/$ over $67k; $8,700 + 17c/$ over $125k; 10% whole income above $179,286.\n"
                "LITO: unchanged — max $700, tapers to nil at $66,667. No LITO without threshold.\n"
                "SAPTO: unchanged from 2024-25.\n"
                "Last verified: March 2026 against ATO website."
            ),
        },
        {
            "fy_year": 2027, "label": "2026-27",
            "brackets": _BRACKETS_2627,
            "brackets_no_thresh": _BRACKETS_2627_NO_THRESH,
            "medicare": _MEDICARE_2526,
            "lito": _LITO_WITH, "lito_no_thresh": _LITO_NO,
            "help": _HELP_2526, "help_method": "marginal",
            "sapto": _SAPTO_2526, "no_tfn_rate": 0.47,
            "notes": (
                "ATO 2026-27 — tax cut: 16% rate reduced to 15% from 1 July 2026.\n"
                "Scale 4 (no threshold): 15% from $1; 30%/$45,001; 37%/$135,001; 45%/$190,001+\n"
                "Source: ato.gov.au/about-ato/new-legislation/in-detail/individuals/personal-income-tax-new-tax-cuts-for-every-australian-taxpayer\n"
                "HELP: marginal method assumed to continue. Verify thresholds when indexed (annually in June).\n"
                "LITO, SAPTO: assumed unchanged. Update from ATO when 2026-27 Schedule 1 published.\n"
                "Last updated: March 2026 (placeholder — verify all values before FY start)."
            ),
        },
    ]

    for r in _PAYG_DEFAULTS:
        existing = conn.execute(
            "SELECT id FROM payg_tax_rates WHERE fy_year=?", (r["fy_year"],)).fetchone()
        if not existing:
            conn.execute("""INSERT INTO payg_tax_rates
                (fy_year, label, brackets_json, brackets_no_thresh_json, medicare_json, lito_json,
                 lito_no_thresh_json, help_json, help_method, sapto_json, no_tfn_rate, notes)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                (r["fy_year"], r["label"],
                 _json.dumps(r["brackets"]), _json.dumps(r["brackets_no_thresh"]),
                 _json.dumps(r["medicare"]),
                 _json.dumps(r["lito"]), _json.dumps(r["lito_no_thresh"]),
                 _json.dumps(r["help"]), r["help_method"],
                 _json.dumps(r["sapto"]), r["no_tfn_rate"], r["notes"]))
        else:
            # Always update the data for seeded years so corrections roll out on next open
            conn.execute("""UPDATE payg_tax_rates SET
                brackets_json           = ?,
                brackets_no_thresh_json = ?,
                medicare_json           = ?,
                lito_json               = ?,
                lito_no_thresh_json     = ?,
                help_json               = ?,
                help_method             = ?,
                sapto_json              = ?,
                no_tfn_rate             = ?,
                notes                   = ?
                WHERE fy_year=? AND label=?""",
                (_json.dumps(r["brackets"]), _json.dumps(r["brackets_no_thresh"]),
                 _json.dumps(r["medicare"]),
                 _json.dumps(r["lito"]), _json.dumps(r["lito_no_thresh"]),
                 _json.dumps(r["help"]), r["help_method"],
                 _json.dumps(r["sapto"]), r["no_tfn_rate"], r["notes"],
                 r["fy_year"], r["label"]))

    # Performance indexes for common query patterns
    _add_indexes(conn)

    # ── Warranties — linked to any transaction source ─────────────────────────
    conn.execute("""CREATE TABLE IF NOT EXISTS warranties (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        source_type     TEXT NOT NULL,   -- 'invoice', 'bill', 'payment', 'journal'
        source_id       INTEGER NOT NULL,
        item_description TEXT NOT NULL,
        serial_number   TEXT,
        provider        TEXT,            -- supplier/manufacturer name (free text)
        purchase_date   TEXT,            -- ISO date (copied from source for convenience)
        warranty_expiry TEXT NOT NULL,   -- ISO date
        notes           TEXT,
        claim_status    TEXT DEFAULT 'active',  -- 'active','claimed','voided','rejected'
        claim_date      TEXT,
        claim_outcome   TEXT,            -- 'replace','refund','partial_refund','repair','exchange','rejected'
        claim_notes     TEXT,
        claim_amount    REAL,            -- for refund / partial refund
        parent_warranty_id INTEGER REFERENCES warranties(id),  -- replacement links back to original
        created_at      TEXT DEFAULT (datetime('now','localtime')),
        updated_at      TEXT DEFAULT (datetime('now','localtime')))""")
    conn.execute("""CREATE INDEX IF NOT EXISTS idx_warranties_source
        ON warranties(source_type, source_id)""")
    conn.execute("""CREATE INDEX IF NOT EXISTS idx_warranties_expiry
        ON warranties(warranty_expiry)""")
    # Link table: warranty <-> attachment (reference only, no blob duplication)
    conn.execute("""CREATE TABLE IF NOT EXISTS warranty_attachments (
        warranty_id   INTEGER NOT NULL REFERENCES warranties(id) ON DELETE CASCADE,
        attachment_id INTEGER NOT NULL REFERENCES attachments(id) ON DELETE CASCADE,
        PRIMARY KEY (warranty_id, attachment_id))""")
    # Migrate existing warranty tables that predate claim columns
    for _col, _def in [
        ("claim_status",        "TEXT DEFAULT 'active'"),
        ("claim_date",          "TEXT"),
        ("claim_outcome",       "TEXT"),
        ("claim_notes",         "TEXT"),
        ("claim_amount",        "REAL"),
        ("parent_warranty_id",  "INTEGER"),
    ]:
        try:
            conn.execute(f"ALTER TABLE warranties ADD COLUMN {_col} {_def}")
        except Exception:
            pass
    conn.commit()


def _add_indexes(conn):
    """Create performance indexes — all CREATE IF NOT EXISTS, safe on existing DBs."""
    indexes = [
        # Invoice lookups
        ("idx_invoices_contact",    "invoices(contact_id)"),
        ("idx_invoices_status",     "invoices(status)"),
        ("idx_invoices_date",       "invoices(invoice_date)"),
        # Bill lookups
        ("idx_bills_contact",       "bills(contact_id)"),
        ("idx_bills_status",        "bills(status)"),
        ("idx_bills_date",          "bills(bill_date)"),
        # Journal lookups
        ("idx_jlines_account",      "journal_lines(account_id)"),
        ("idx_jlines_journal",      "journal_lines(journal_id)"),
        ("idx_jentries_date",       "journal_entries(entry_date)"),
        ("idx_jentries_source",     "journal_entries(source_type, source_id)"),
        # Payment lookups
        ("idx_payments_contact",    "payments(contact_id)"),
        ("idx_payments_date",       "payments(payment_date)"),
        # Bank transactions
        ("idx_banktxn_account",     "bank_transactions(account_id)"),
        ("idx_banktxn_reconciled",  "bank_transactions(account_id, is_reconciled)"),
        # Job transactions
        ("idx_jobtxn_job",          "job_transactions(job_id)"),
        ("idx_jobtxn_source",       "job_transactions(source_type, source_id)"),
        # Payroll
        ("idx_payslips_run",        "payslips(pay_run_id)"),
        ("idx_payruns_date",        "pay_runs(payment_date)"),
    ]
    for name, definition in indexes:
        try:
            conn.execute(f"CREATE INDEX IF NOT EXISTS {name} ON {definition}")
        except Exception:
            pass  # table may not exist yet on fresh DB


def seed_defaults(db_path):
    """Insert default tax codes and chart of accounts."""
    conn = get_connection(db_path)
    c = conn.cursor()

    tax_codes = [
        ('GST', 'GST on Income/Expenses (10%)', 0.10),
        ('FRE', 'GST Free', 0.00),
        ('INP', 'Input Taxed', 0.00),
        ('N-T', 'Not Reportable', 0.00),
        ('CAP', 'Capital Acquisitions (10%)', 0.10),
        ('EXP', 'Export Sales (0%)', 0.00),
    ]
    c.executemany("INSERT OR IGNORE INTO tax_codes VALUES (?,?,?,1)", tax_codes)

    accounts = [
        ('1-1100', 'Cheque Account', 'Asset', 'Bank', 1),
        ('1-1110', 'Savings Account', 'Asset', 'Bank', 1),
        ('1-1200', 'Accounts Receivable', 'Asset', 'Current Asset', 0),
        ('1-1300', 'GST Paid (Input Credits)', 'Asset', 'Current Asset', 0),
        ('1-1400', 'Inventory', 'Asset', 'Current Asset', 0),
        ('1-1500', 'Prepayments', 'Asset', 'Current Asset', 0),
        ('1-2100', 'Plant & Equipment', 'Asset', 'Fixed Asset', 0),
        ('1-2110', 'Accum Depr - Plant & Equipment', 'Asset', 'Fixed Asset', 0),
        ('1-2200', 'Motor Vehicles', 'Asset', 'Fixed Asset', 0),
        ('1-2210', 'Accum Depr - Motor Vehicles', 'Asset', 'Fixed Asset', 0),
        ('2-1100', 'Accounts Payable', 'Liability', 'Current Liability', 0),
        ('2-1200', 'GST Collected', 'Liability', 'Current Liability', 0),
        ('2-1300', 'PAYG Withholding Payable', 'Liability', 'Current Liability', 0),
        ('2-1400', 'Superannuation Payable', 'Liability', 'Current Liability', 0),
        ('2-1500', 'Credit Card', 'Liability', 'Credit Card', 0),
        ('2-2100', 'Bank Loan', 'Liability', 'Non-Current Liability', 0),
        ('3-1100', 'Owner Capital', 'Equity', 'Equity', 0),
        ('3-1200', 'Owner Drawings', 'Equity', 'Equity', 0),
        ('3-1300', 'Retained Earnings', 'Equity', 'Equity', 0),
        ('4-1100', 'Sales - Goods', 'Income', 'Income', 0),
        ('4-1200', 'Sales - Services', 'Income', 'Income', 0),
        ('4-1300', 'Other Income', 'Income', 'Income', 0),
        ('4-1400', 'Interest Received', 'Income', 'Income', 0),
        ('5-1100', 'Purchases / Cost of Goods Sold', 'Expense', 'Direct Cost', 0),
        ('5-2100', 'Accounting Fees', 'Expense', 'Overhead', 0),
        ('5-2200', 'Advertising & Marketing', 'Expense', 'Overhead', 0),
        ('5-2300', 'Bank Fees & Charges', 'Expense', 'Overhead', 0),
        ('5-2400', 'Computer Expenses', 'Expense', 'Overhead', 0),
        ('5-2500', 'Depreciation', 'Expense', 'Overhead', 0),
        ('5-2600', 'Insurance', 'Expense', 'Overhead', 0),
        ('5-2700', 'Interest Expense', 'Expense', 'Overhead', 0),
        ('5-2800', 'Motor Vehicle Expenses', 'Expense', 'Overhead', 0),
        ('5-2900', 'Office Supplies', 'Expense', 'Overhead', 0),
        ('5-3000', 'Postage & Freight', 'Expense', 'Overhead', 0),
        ('5-3100', 'Printing & Stationery', 'Expense', 'Overhead', 0),
        ('5-3200', 'Rent & Occupancy', 'Expense', 'Overhead', 0),
        ('5-3300', 'Repairs & Maintenance', 'Expense', 'Overhead', 0),
        ('5-3400', 'Subscriptions', 'Expense', 'Overhead', 0),
        ('5-3500', 'Superannuation Expense', 'Expense', 'Overhead', 0),
        ('5-3600', 'Telephone & Internet', 'Expense', 'Overhead', 0),
        ('5-3700', 'Wages & Salaries', 'Expense', 'Overhead', 0),
    ]
    for row in accounts:
        c.execute("""INSERT OR IGNORE INTO accounts
            (code, name, account_type, account_subtype, is_bank)
            VALUES (?,?,?,?,?)""", row)
    # Mark Credit Card subtype accounts
    c.execute("""UPDATE accounts SET is_credit_card=1
        WHERE account_subtype='Credit Card'""")
    # ── Default catalogue items ───────────────────────────────────────────────
    # Pre-seed common items that almost every business uses.
    # All non-inventoried. Prices are $0 except discounts (-1.00).
    # User can edit or delete these at any time.
    _default_items = [
        # (code, name, unit_price, tax_code, account_code, description)
        ('DISC-001',  'Discount',
         -1.00, 'GST', '4-1100',
         'Apply as a line item to reduce invoice total. '
         'Set quantity to 1 and enter the discount amount as a negative number.'),
        ('DISC-FRE',  'Discount (GST Free)',
         -1.00, 'FRE', '4-1100',
         'Discount on GST-free goods or services. No GST adjustment.'),
        ('FREIGHT',   'Freight / Delivery',
         0.00,  'GST', '4-1100',
         'Freight and delivery charges. GST applies on freight '
         'charged on taxable goods.'),
        ('LABOUR',    'Labour',
         0.00,  'GST', '4-1200',
         'Labour, installation, or service time. Set unit price '
         'to your hourly or fixed rate.'),
        ('REIMBURSE', 'Reimbursement of Expenses',
         0.00,  'N-T', '4-1300',
         'Reimbursement of actual costs incurred on behalf of the customer. '
         'Not subject to GST (N-T).'),
        ('ADJ-001',   'Invoice Adjustment / Rounding',
         0.00,  'GST', '4-1100',
         'Minor adjustments, corrections, or rounding differences.'),
    ]
    for code, name, price, tax, acc_code, desc in _default_items:
        acc_row = conn.execute(
            "SELECT id FROM accounts WHERE code=?", (acc_code,)).fetchone()
        if acc_row:
            conn.execute("""INSERT OR IGNORE INTO items
                (code, name, unit_price, tax_code, account_id,
                 is_inventoried, description)
                VALUES (?,?,?,?,?,0,?)""",
                (code, name, price, tax, acc_row["id"], desc))

    conn.commit()
    conn.close()


def _migrate_budget_and_users(conn):
    """Add budget and user management tables."""
    # Budget tables
    conn.execute("""CREATE TABLE IF NOT EXISTS budget_periods (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        name        TEXT NOT NULL,
        period_type TEXT DEFAULT 'Annual',  -- Annual, Quarterly, Monthly
        fy_year     INTEGER NOT NULL,
        start_date  TEXT NOT NULL,
        end_date    TEXT NOT NULL,
        created_by  INTEGER,
        created_at  TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS budget_lines (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        period_id   INTEGER NOT NULL REFERENCES budget_periods(id),
        account_id  INTEGER NOT NULL REFERENCES accounts(id),
        month       INTEGER NOT NULL,  -- 1-12
        amount      REAL    NOT NULL DEFAULT 0,
        notes       TEXT,
        UNIQUE(period_id, account_id, month))""")

    # Users table
    conn.execute("""CREATE TABLE IF NOT EXISTS users (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        username    TEXT NOT NULL UNIQUE,
        display_name TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        role        TEXT NOT NULL DEFAULT 'Staff',
        -- roles: Admin, Accountant, Staff, ReadOnly
        is_active   INTEGER NOT NULL DEFAULT 1,
        created_at  TEXT DEFAULT (datetime('now','localtime')),
        last_login  TEXT,
        force_password_change INTEGER NOT NULL DEFAULT 0)""")

    # Audit log — who did what
    conn.execute("""CREATE TABLE IF NOT EXISTS audit_log (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     INTEGER,
        username    TEXT,
        action      TEXT NOT NULL,
        target_type TEXT,
        target_id   INTEGER,
        detail      TEXT,
        logged_at   TEXT DEFAULT (datetime('now','localtime')))""")

    # Credit card account subtype support
    try:
        conn.execute("ALTER TABLE accounts ADD COLUMN is_credit_card INTEGER NOT NULL DEFAULT 0")
    except Exception:
        pass

    # Ensure Credit Card subtype accounts exist
    for code, name in [
        ('2-1500', 'Credit Card'),
        ('2-1510', 'Visa Credit Card'),
        ('2-1520', 'Mastercard'),
        ('2-1530', 'Amex'),
    ]:
        try:
            # Update existing Credit Card account subtype to 'Credit Card'
            conn.execute("""UPDATE accounts
                SET account_subtype='Credit Card', is_credit_card=1
                WHERE code=? AND account_type='Liability'""", (code,))
        except Exception:
            pass

    # Add created_by/modified_by to invoices, bills, payments
    for table, col in [
        ("invoices",  "created_by"),
        ("invoices",  "modified_by"),
        ("bills",     "created_by"),
        ("bills",     "modified_by"),
        ("payments",  "created_by"),
        ("journal_entries", "created_by"),
    ]:
        try:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} INTEGER")
        except Exception:
            pass

    try:
        conn.execute("ALTER TABLE users ADD COLUMN force_password_change INTEGER NOT NULL DEFAULT 0")
    except Exception:
        pass

def vacuum_database(db_path):
    """Reclaim space from deleted records and update query planner statistics.
    Safe to call at any time — runs outside a transaction.
    Typical use: call once after bulk deletes or on admin request.
    """
    conn = sqlite3.connect(db_path)     # plain connect - VACUUM can't run in WAL txn
    conn.execute("PRAGMA wal_checkpoint(FULL)")
    conn.execute("VACUUM")
    conn.execute("ANALYZE")
    conn.close()


def seed_demo(db_path):
    """
    Populate a demo company with realistic Australian small-business data:
    - Company details
    - 6 contacts (customers + suppliers)
    - 3 invoices (paid, partial, outstanding)
    - 3 bills (paid, outstanding)
    - Journal entries for the payments
    - 20 bank transactions already in the ledger (journal-sourced)
    - Sample CSV file written alongside the .dbox file for rec import
    """
    import os, csv
    from datetime import date, timedelta

    conn = get_connection(db_path)
    c = conn.cursor()

    # ── Company ───────────────────────────────────────────────────────────────
    conn.execute("""INSERT OR REPLACE INTO company
        (id, name, abn, address, phone, email, website,
         default_payment_instructions)
        VALUES (1,
            'Acme Consulting Pty Ltd',
            '12 345 678 901',
            '42 Demo Street, Sydney NSW 2000',
            '02 9000 0000',
            'accounts@acmeconsulting.com.au',
            'www.acmeconsulting.com.au',
            'Please pay via EFT to:\nBSB: 062-000  Account: 1234 5678\nRef: Invoice number')""")

    # ── Account opening balances ───────────────────────────────────────────────
    conn.execute("UPDATE accounts SET opening_balance=45000.00 WHERE code='1-1100'")
    conn.execute("UPDATE accounts SET opening_balance=12500.00 WHERE code='1-1110'")

    # ── Contacts ──────────────────────────────────────────────────────────────
    contacts = [
        # (type, name, email, phone, address, is_customer, is_supplier)
        ('Customer', 'Blue Sky Technologies',  'ap@bluesky.com.au',    '02 8000 1111', '10 Tech Ave, Sydney NSW 2000',  1, 0),
        ('Customer', 'Green Valley Farms',     'admin@gvfarms.com.au', '03 9000 2222', '5 Farm Rd, Melbourne VIC 3000', 1, 0),
        ('Customer', 'Harbour Bridge Events',  'accounts@hbe.com.au',  '02 8000 3333', '1 Circular Quay, Sydney NSW 2000', 1, 0),
        ('Supplier', 'Office Pro Supplies',    'bills@officepro.com.au','02 8000 4444','99 Office St, Sydney NSW 2000',  0, 1),
        ('Supplier', 'CloudHost Australia',    'billing@cloudhost.com.au','1300 555 666','Level 5, 200 George St, Sydney NSW 2000', 0, 1),
        ('Supplier', 'Sydney Commercial Rent', 'admin@scrent.com.au',  '02 8000 7777', '300 Kent St, Sydney NSW 2000',   0, 1),
    ]
    contact_ids = {}
    for ct, name, email, phone, addr, is_cust, is_supp in contacts:
        c.execute("""INSERT OR IGNORE INTO contacts
            (contact_type, name, email, phone, address, is_active)
            VALUES (?,?,?,?,?,1)""", (ct, name, email, phone, addr))
        row = conn.execute("SELECT id FROM contacts WHERE name=?", (name,)).fetchone()
        contact_ids[name] = row["id"]

    # Helper: account id by code
    def acc(code):
        r = conn.execute("SELECT id FROM accounts WHERE code=?", (code,)).fetchone()
        return r["id"] if r else None

    today      = date.today()
    def dstr(d): return d.strftime("%Y-%m-%d")
    def ago(n):  return dstr(today - timedelta(days=n))

    # ── Invoices ──────────────────────────────────────────────────────────────
    invs = [
        # (contact, inv_no, date, due, lines[(desc,qty,price,tax)], paid_amount, status)
        ('Blue Sky Technologies',  'INV-0001', ago(60), ago(30),
         [('IT Consulting - 20hrs', 20, 250.00, 'GST'),
          ('System Architecture Review', 1, 1500.00, 'GST')],
         7150.00, 'Paid'),
        ('Green Valley Farms',     'INV-0002', ago(35), ago(5),
         [('Agricultural Software Setup', 1, 3300.00, 'GST'),
          ('Training Session - 4hrs', 4, 220.00, 'GST')],
         880.00, 'Partial'),
        ('Harbour Bridge Events',  'INV-0003', ago(14), dstr(today + timedelta(days=16)),
         [('Event Technology Consulting', 1, 5500.00, 'GST')],
         0.00, 'Sent'),
    ]
    inv_ids = {}
    for contact_name, inv_no, inv_date, due_date, lines, paid, status in invs:
        cid  = contact_ids[contact_name]
        subtotal = sum(q * p for _, q, p, _ in lines)
        gst      = sum(q * p * 0.1 for _, q, p, t in lines if t == 'GST')
        total    = subtotal + gst
        c.execute("""INSERT INTO invoices
            (contact_id, invoice_number, invoice_date, due_date,
             subtotal, gst_total, total, amount_paid, status, notes)
            VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (cid, inv_no, inv_date, due_date,
             subtotal, gst, total, paid, status, ''))
        inv_id = c.lastrowid
        inv_ids[inv_no] = {'id': inv_id, 'contact_id': cid, 'total': total}
        for desc, qty, price, tax in lines:
            unit_price = price
            line_total = qty * price
            line_tax   = line_total * 0.1 if tax == 'GST' else 0.0
            c.execute("""INSERT INTO invoice_lines
                (invoice_id, description, quantity, unit_price,
                 line_total, tax_code, gst_amount)
                VALUES (?,?,?,?,?,?,?)""",
                (inv_id, desc, qty, unit_price,
                 line_total, tax, line_tax))

    # ── Bills ─────────────────────────────────────────────────────────────────
    bills_data = [
        ('Office Pro Supplies',  'BILL-001', ago(45), ago(15),
         [('Office Supplies - Monthly', 1, 320.00, 'GST')],
         352.00, 'Paid'),
        ('CloudHost Australia',  'BILL-002', ago(30), ago(0),
         [('Cloud Hosting - Monthly Fee', 1, 199.00, 'GST')],
         0.00, 'Approved'),
        ('Sydney Commercial Rent','BILL-003', ago(30), ago(0),
         [('Office Rent - Monthly', 1, 3500.00, 'FRE')],
         0.00, 'Approved'),
    ]
    bill_ids = {}
    for contact_name, bill_no, bill_date, due_date, lines, paid, status in bills_data:
        cid      = contact_ids[contact_name]
        subtotal = sum(q * p for _, q, p, _ in lines)
        gst      = sum(q * p * 0.1 for _, q, p, t in lines if t == 'GST')
        total    = subtotal + gst
        c.execute("""INSERT INTO bills
            (contact_id, bill_number, bill_date, due_date,
             subtotal, gst_total, total, amount_paid, status)
            VALUES (?,?,?,?,?,?,?,?,?)""",
            (cid, bill_no, bill_date, due_date,
             subtotal, gst, total, paid, status))
        bill_id = c.lastrowid
        bill_ids[bill_no] = {'id': bill_id, 'contact_id': cid, 'total': total}
        for desc, qty, price, tax in lines:
            line_total = qty * price
            line_tax   = line_total * 0.1 if tax == 'GST' else 0.0
            c.execute("""INSERT INTO bill_lines
                (bill_id, description, quantity, unit_price, line_total, tax_code, gst_amount)
                VALUES (?,?,?,?,?,?,?)""",
                (bill_id, desc, qty, price, line_total, tax, line_tax))

    # ── Journal entries + payments for settled items ─────────────────────────
    bank = acc('1-1100')
    ar   = acc('1-1200')
    ap   = acc('2-1100')
    gst_in  = acc('1-1300')
    gst_out = acc('2-1200')

    def post_journal(entry_date, description, entry_type, lines, source_id=None, source_type=None, contact_id=None):
        c.execute("""INSERT INTO journal_entries
            (entry_date, description, entry_type, source_id, source_type, contact_id)
            VALUES (?,?,?,?,?,?)""",
            (entry_date, description, entry_type, source_id, source_type, contact_id))
        jid = c.lastrowid
        for acc_id, dr, cr in lines:
            if acc_id:
                c.execute("""INSERT INTO journal_lines
                    (journal_id, account_id, debit, credit, is_reconciled, reconciled_date)
                    VALUES (?,?,?,?,1,?)""",
                    (jid, acc_id, dr, cr, entry_date))
        return jid

    # INV-0001 paid in full
    inv1 = inv_ids['INV-0001']
    c.execute("""INSERT INTO payments
        (payment_type,contact_id,payment_date,amount,bank_account_id,description)
        VALUES ('Receipt',?,?,?,?,'Receipt - INV-0001')""",
        (inv1['contact_id'], ago(28), 7150.00, bank))
    pmt1 = c.lastrowid
    c.execute("INSERT INTO payment_allocations (payment_id,invoice_id,amount) VALUES (?,?,?)",
              (pmt1, inv1['id'], 7150.00))
    jid1 = post_journal(ago(28), 'Receipt - INV-0001', 'Receipt',
        [(bank, 7150.00, 0), (ar, 0, 7150.00)],
        source_id=pmt1, source_type='payment', contact_id=inv1['contact_id'])
    c.execute("UPDATE payments SET journal_id=? WHERE id=?", (jid1, pmt1))

    # INV-0002 partial payment
    inv2 = inv_ids['INV-0002']
    c.execute("""INSERT INTO payments
        (payment_type,contact_id,payment_date,amount,bank_account_id,description)
        VALUES ('Receipt',?,?,?,?,'Partial Receipt - INV-0002')""",
        (inv2['contact_id'], ago(10), 880.00, bank))
    pmt2 = c.lastrowid
    c.execute("INSERT INTO payment_allocations (payment_id,invoice_id,amount) VALUES (?,?,?)",
              (pmt2, inv2['id'], 880.00))
    jid2 = post_journal(ago(10), 'Partial Receipt - INV-0002', 'Receipt',
        [(bank, 880.00, 0), (ar, 0, 880.00)],
        source_id=pmt2, source_type='payment', contact_id=inv2['contact_id'])
    c.execute("UPDATE payments SET journal_id=? WHERE id=?", (jid2, pmt2))

    # BILL-001 paid
    bill1 = bill_ids['BILL-001']
    c.execute("""INSERT INTO payments
        (payment_type,contact_id,payment_date,amount,bank_account_id,description)
        VALUES ('Payment',?,?,?,?,'Payment - BILL-001')""",
        (bill1['contact_id'], ago(12), 352.00, bank))
    pmt3 = c.lastrowid
    c.execute("INSERT INTO payment_allocations (payment_id,bill_id,amount) VALUES (?,?,?)",
              (pmt3, bill1['id'], 352.00))
    jid3 = post_journal(ago(12), 'Payment - BILL-001', 'Payment',
        [(bank, 0, 352.00), (ap, 352.00, 0)],
        source_id=pmt3, source_type='payment', contact_id=bill1['contact_id'])
    c.execute("UPDATE payments SET journal_id=? WHERE id=?", (jid3, pmt3))

    # A few extra direct bank journal entries (wages, subscriptions, etc.)
    extras = [
        (ago(55), 'Wages - Fortnight 1',   acc('5-3700'), 4200.00, False),
        (ago(41), 'Wages - Fortnight 2',   acc('5-3700'), 4200.00, False),
        (ago(27), 'Wages - Fortnight 3',   acc('5-3700'), 4200.00, False),
        (ago(13), 'Wages - Fortnight 4',   acc('5-3700'), 4200.00, False),
        (ago(50), 'Telephone & Internet',  acc('5-3600'), 189.00,  True),
        (ago(50), 'Insurance Premium',     acc('5-2600'), 550.00,  True),
        (ago(20), 'Office Supplies',       acc('5-2900'), 87.50,   True),
        (ago(5),  'Advertising - Google',  acc('5-2200'), 330.00,  True),
    ]
    for edate, desc, gl, amt, has_gst in extras:
        gst_amt = round(amt * 0.1 / 1.1, 2) if has_gst else 0.0
        net_amt = amt - gst_amt
        lines   = [(bank, 0, amt), (gl, net_amt, 0)]
        if gst_amt and gst_in:
            lines.append((gst_in, gst_amt, 0))
        post_journal(edate, desc, 'Bank Allocation', lines)

    conn.commit()
    conn.close()

    # ── Sample CSV for bank rec import ────────────────────────────────────────
    # Written to same directory as the .dbox file
    csv_path = os.path.splitext(db_path)[0] + "_sample_transactions.csv"
    balance  = 45000.00
    csv_rows = [
        # (date_offset_days_ago, description, debit, credit)
        (62, 'OPENING BALANCE',                    0,       0),
        (58, 'TRANSFER FROM SAVINGS',               0,    5000.00),
        (55, 'PAYROLL - FORTNIGHTLY',            4200.00,    0),
        (52, 'AMAZON WEB SERVICES',               99.00,     0),
        (50, 'TELSTRA BUSINESS',                 189.00,     0),
        (50, 'QBE INSURANCE',                    550.00,     0),
        (45, 'OFFICEPRO SUPPLIES PTY LTD',       352.00,     0),
        (42, 'WOOLWORTHS METRO - OFFICE SNACKS',  47.30,     0),
        (41, 'PAYROLL - FORTNIGHTLY',            4200.00,    0),
        (36, 'BLUE SKY TECHNOLOGIES - RECEIPT',    0,    7150.00),
        (35, 'INTEREST RECEIVED',                  0,      42.15),
        (30, 'CLOUDHOST AUSTRALIA',              218.90,     0),
        (30, 'SYDNEY COMMERCIAL RENT',          3500.00,     0),
        (29, 'UBER EATS - TEAM LUNCH',            89.50,     0),
        (27, 'PAYROLL - FORTNIGHTLY',            4200.00,    0),
        (20, 'OFFICEWORKS - STATIONERY',          67.80,     0),
        (20, 'GOOGLE ADS',                       330.00,     0),
        (13, 'PAYROLL - FORTNIGHTLY',            4200.00,    0),
        (10, 'GREEN VALLEY FARMS - RECEIPT',       0,     880.00),
        (5,  'AMAZON WEB SERVICES',               99.00,     0),
        (3,  'SUBSCRIPTION - ADOBE CC',           82.49,     0),
        (1,  'ATM WITHDRAWAL - PETTY CASH',      200.00,     0),
    ]

    running_bal = balance
    rows_out    = []
    for days_ago, desc, debit, credit in csv_rows:
        txn_date = dstr(today - timedelta(days=days_ago))
        running_bal = running_bal - debit + credit
        rows_out.append({
            'Date':        txn_date,
            'Description': desc,
            'Debit':       f'{debit:.2f}'  if debit  else '',
            'Credit':      f'{credit:.2f}' if credit else '',
            'Balance':     f'{running_bal:.2f}',
        })

    rows_out.sort(key=lambda r: r['Date'])
    with open(csv_path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=['Date','Description','Debit','Credit','Balance'])
        w.writeheader()
        w.writerows(rows_out)

    return csv_path
