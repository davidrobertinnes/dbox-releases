# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Accounting — Job billing bookkeeping

Tracks what on a job has already been billed, so nothing is billed twice
and voiding an invoice frees everything it billed:

  work_task_billings — one row per (task, invoice): the qty and amount of a
                       fixed-price task billed on that invoice. A task can be
                       billed in several parts ("10 of 24 panels").
                       work_tasks.qty_invoiced is the running total, and
                       work_tasks.invoice_id is only set once the task is
                       fully billed — so every existing "uninvoiced" query
                       keeps working unchanged.
  job_recharges      — a BOM line, bill or PO re-charged to the customer on
                       an invoice (materials).
  schedule_events.invoice_id — a job visit whose hours were billed.

Tasks are billed either 'fixed' (their own qty × unit price) or 'hourly' (no
price of their own — the money comes from visit hours × jobs.hourly_rate, and
the task appears on the invoice as a comment line).
"""

from __future__ import annotations
from core.database import get_connection

TASK_BILLING_TYPES = ('fixed', 'hourly')


# ─────────────────────────────────────────────────────────────────────────────
#  MIGRATION
# ─────────────────────────────────────────────────────────────────────────────

def migrate_job_billing(conn):
    for stmt in (
        "ALTER TABLE jobs       ADD COLUMN hourly_rate  REAL",
        "ALTER TABLE work_tasks ADD COLUMN billing      TEXT NOT NULL DEFAULT 'fixed'",
        "ALTER TABLE work_tasks ADD COLUMN qty_invoiced REAL NOT NULL DEFAULT 0",
    ):
        try:
            conn.execute(stmt)
        except Exception:
            pass

    conn.execute("""CREATE TABLE IF NOT EXISTS work_task_billings (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id     INTEGER NOT NULL REFERENCES work_tasks(id) ON DELETE CASCADE,
        invoice_id  INTEGER NOT NULL REFERENCES invoices(id),
        qty         REAL NOT NULL,
        amount      REAL NOT NULL,
        created_at  TEXT DEFAULT (datetime('now','localtime')))""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_wtb_task    ON work_task_billings(task_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_wtb_invoice ON work_task_billings(invoice_id)")

    conn.execute("""CREATE TABLE IF NOT EXISTS job_recharges (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id       INTEGER REFERENCES jobs(id),
        source_type  TEXT NOT NULL,             -- 'bom' | 'bill' | 'po'
        source_id    INTEGER NOT NULL,
        invoice_id   INTEGER NOT NULL REFERENCES invoices(id),
        cost_amount  REAL NOT NULL DEFAULT 0,
        sell_amount  REAL NOT NULL DEFAULT 0,
        created_at   TEXT DEFAULT (datetime('now','localtime')),
        UNIQUE(source_type, source_id))""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_jrc_invoice ON job_recharges(invoice_id)")

    # Backfill: tasks invoiced before this table existed get a billing row
    # for their full qty, so voiding that invoice releases them the same way.
    conn.execute("""INSERT INTO work_task_billings (task_id, invoice_id, qty, amount)
        SELECT wt.id, wt.invoice_id, COALESCE(wt.qty, 1),
               ROUND(COALESCE(wt.qty, 1) * COALESCE(wt.unit_price, 0), 2)
        FROM work_tasks wt
        JOIN invoices i ON i.id = wt.invoice_id AND i.status <> 'Void'
        WHERE NOT EXISTS (SELECT 1 FROM work_task_billings b WHERE b.task_id = wt.id)""")
    conn.execute("""UPDATE work_tasks SET qty_invoiced = COALESCE(qty, 1)
        WHERE invoice_id IS NOT NULL AND qty_invoiced = 0""")


# ─────────────────────────────────────────────────────────────────────────────
#  FIXED-PRICE TASKS — partial billing
# ─────────────────────────────────────────────────────────────────────────────

def to_date_amount(total_qty: float, unit_price: float, qty_to_date: float,
                   already_billed: float) -> float:
    """This claim's amount for a fixed-price task, by the to-date method:
    value of everything done so far, rounded once, minus what's already been
    billed. Rounding never accumulates — the claim that reaches the full qty
    lands exactly on qty × unit price (e.g. $700 / 24 panels billed as 8, 10,
    6 → 233.33 + 291.67 + 175.00 = 700.00)."""
    total_qty = float(total_qty or 0)
    if total_qty <= 0:
        return 0.0
    contract = round(total_qty * float(unit_price or 0), 2)
    if qty_to_date >= total_qty:
        to_date = contract
    else:
        to_date = round(contract * float(qty_to_date) / total_qty, 2)
    return round(to_date - float(already_billed or 0), 2)


def task_billing_state(conn, task_id: int) -> dict:
    """Qty/amount billed so far on a task, and what's left."""
    t = conn.execute("SELECT * FROM work_tasks WHERE id=?", (task_id,)).fetchone()
    if not t:
        raise ValueError(f"Task {task_id} not found")
    billed = conn.execute("""SELECT COALESCE(SUM(qty),0) AS q, COALESCE(SUM(amount),0) AS a
        FROM work_task_billings WHERE task_id=?""", (task_id,)).fetchone()
    qty = float(t["qty"] or 1)
    contract = round(qty * float(t["unit_price"] or 0), 2)
    return {
        "task": dict(t),
        "qty": qty,
        "contract": contract,
        "qty_billed": float(billed["q"]),
        "amount_billed": round(float(billed["a"]), 2),
        "qty_remaining": max(qty - float(billed["q"]), 0.0),
        "amount_remaining": round(contract - float(billed["a"]), 2),
    }


def plan_task_billing(conn, task_id: int, qty_to_date: float | None = None) -> dict:
    """Work out billing a fixed-price task up to qty_to_date (default: all of
    it) without writing anything — the invoice line, and the qty/amount to
    record once the invoice exists (record_task_billing). Raises if the task
    is hourly, already fully billed, or qty_to_date doesn't move forward."""
    st = task_billing_state(conn, task_id)
    t = st["task"]
    if (t.get("billing") or "fixed") != "fixed":
        raise ValueError(f"'{t['title']}' is an hourly task — it's billed through visit hours")
    if st["qty_remaining"] <= 0:
        raise ValueError(f"'{t['title']}' is already fully billed")
    if qty_to_date is None:
        qty_to_date = st["qty"]
    qty_to_date = min(float(qty_to_date), st["qty"])
    qty_now = round(qty_to_date - st["qty_billed"], 6)
    if qty_now <= 0:
        raise ValueError(f"'{t['title']}': {qty_to_date:g} is not more than the "
                         f"{st['qty_billed']:g} already billed")

    amount = to_date_amount(st["qty"], t["unit_price"], qty_to_date, st["amount_billed"])
    fully = qty_to_date >= st["qty"]
    desc = t["title"] + (f" — {t['description']}" if t.get("description") else "")
    if fully and st["qty_billed"] == 0:
        # Billed in one go — show the natural qty × price.
        line = {"description": desc, "quantity": st["qty"], "unit_price": t["unit_price"]}
    else:
        # A part of the task: one line for exactly this claim's amount, so
        # qty × price rounding can't drift from what gets recorded.
        line = {"description": f"{desc} ({qty_to_date:g} of {st['qty']:g} complete, "
                               f"{qty_now:g} this claim)",
                "quantity": 1, "unit_price": amount}
    line.update({"tax_code": "GST", "line_type": "item"})
    return {"task_id": task_id, "qty": qty_now, "qty_to_date": qty_to_date,
            "amount": amount, "fully_billed": fully, "line": line}


def record_task_billing(conn, plan: dict, invoice_id: int):
    """Write a plan_task_billing() result against invoice_id, inside the
    caller's transaction."""
    conn.execute("""INSERT INTO work_task_billings (task_id, invoice_id, qty, amount)
        VALUES (?,?,?,?)""", (plan["task_id"], invoice_id, plan["qty"], plan["amount"]))
    conn.execute("UPDATE work_tasks SET qty_invoiced=?, invoice_id=? WHERE id=?",
                 (plan["qty_to_date"], invoice_id if plan["fully_billed"] else None,
                  plan["task_id"]))


# ─────────────────────────────────────────────────────────────────────────────
#  MATERIALS — recharges of BOM lines / bills / POs
# ─────────────────────────────────────────────────────────────────────────────

def blocked_materials(conn, job_id: int, extra=()) -> dict:
    """Which BOM lines, bills and POs on a job can no longer be re-charged.

    An item is blocked if it was recharged itself, or if something that
    represents the same material was: a BOM line and the PO it was ordered
    on (and that PO's bill) are one purchase seen three ways. `extra` adds
    (type, id) pairs to treat as charged — picks earlier in the same claim."""
    rows = conn.execute("SELECT source_type, source_id FROM job_recharges WHERE job_id=?",
                        (job_id,)).fetchall()
    done = {(r["source_type"], r["source_id"]) for r in rows} | set(extra)

    po_bill = {}  # po_id -> bill_id (either direction of the link)
    for r in conn.execute("""SELECT id, bill_id FROM purchase_orders
            WHERE job_id=? AND bill_id IS NOT NULL""", (job_id,)).fetchall():
        po_bill[r["id"]] = r["bill_id"]
    for r in conn.execute("SELECT id, po_id FROM bills WHERE job_id=? AND po_id IS NOT NULL",
                          (job_id,)).fetchall():
        po_bill.setdefault(r["po_id"], r["id"])

    bom = conn.execute("SELECT id, po_id FROM job_bom_lines WHERE job_id=?", (job_id,)).fetchall()

    blocked = {"bom": set(), "bill": set(), "po": set()}
    for st, sid in done:
        blocked[st].add(sid)
    for po_id, bill_id in po_bill.items():
        if ("po", po_id) in done or ("bill", bill_id) in done:
            blocked["po"].add(po_id); blocked["bill"].add(bill_id)
    for b in bom:
        po_id = b["po_id"]
        if not po_id:
            continue
        bill_id = po_bill.get(po_id)
        if ("bom", b["id"]) in done:
            blocked["po"].add(po_id)
            if bill_id:
                blocked["bill"].add(bill_id)
        if po_id in blocked["po"] or (bill_id and bill_id in blocked["bill"]):
            blocked["bom"].add(b["id"])
    return blocked


def get_job_billable_materials(db_path, job_id: int) -> dict:
    """Unbilled materials for the claim builder: BOM lines (priced, not
    customer-supplied) plus bills/POs that aren't represented by a BOM line.
    A PO/bill that a BOM line points at is left out, so the same timber
    isn't offered twice — the BOM line (with its sell price) wins."""
    conn = get_connection(db_path)
    try:
        blocked = blocked_materials(conn, job_id)
        bom = [dict(r) for r in conn.execute("""SELECT * FROM job_bom_lines
            WHERE job_id=? AND COALESCE(is_customer_supplied,0)=0
            ORDER BY sort_order, id""", (job_id,)).fetchall()]
        bom = [b for b in bom if b["id"] not in blocked["bom"]]
        bom_pos = {b["po_id"] for b in conn.execute(
            "SELECT po_id FROM job_bom_lines WHERE job_id=? AND po_id IS NOT NULL",
            (job_id,)).fetchall()}
        bom_bills = {r["id"] for r in conn.execute(
            f"SELECT id FROM bills WHERE po_id IN ({','.join('?'*len(bom_pos)) or 'NULL'})",
            list(bom_pos)).fetchall()} if bom_pos else set()

        bills = [dict(r) for r in conn.execute("""SELECT b.id, b.bill_number, b.subtotal,
                b.bill_date, b.po_id, c.name AS contact_name
            FROM bills b LEFT JOIN contacts c ON c.id=b.contact_id
            WHERE b.job_id=? AND b.status NOT IN ('Void','Voided')""", (job_id,)).fetchall()]
        bills = [b for b in bills if b["id"] not in blocked["bill"] and b["id"] not in bom_bills]
        pos = [dict(r) for r in conn.execute("""SELECT p.id, p.po_number, p.subtotal,
                p.po_date, p.bill_id, c.name AS contact_name
            FROM purchase_orders p LEFT JOIN contacts c ON c.id=p.contact_id
            WHERE p.job_id=? AND p.status NOT IN ('Cancelled','Billed')""", (job_id,)).fetchall()]
        pos = [p for p in pos if p["id"] not in blocked["po"] and p["id"] not in bom_pos]
        return {"bom": bom, "bills": bills, "pos": pos}
    finally:
        conn.close()


def record_recharge(conn, job_id: int, source_type: str, source_id: int,
                    invoice_id: int, cost: float, sell: float):
    """Mark a material as re-charged on invoice_id, inside the caller's
    transaction. Raises if it (or the same purchase seen as a BOM line / PO /
    bill) has already been re-charged."""
    if source_type not in ("bom", "bill", "po"):
        raise ValueError(f"Unknown material type {source_type!r}")
    if source_id in blocked_materials(conn, job_id)[source_type]:
        raise ValueError(f"That {source_type.upper() if source_type != 'bom' else 'material line'} "
                         "has already been charged to the customer")
    conn.execute("""INSERT INTO job_recharges
        (job_id, source_type, source_id, invoice_id, cost_amount, sell_amount)
        VALUES (?,?,?,?,?,?)""",
        (job_id, source_type, source_id, invoice_id, round(cost or 0, 2), round(sell or 0, 2)))


def get_job_recharges(db_path, job_id: int) -> list:
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT r.*, i.invoice_number FROM job_recharges r
        LEFT JOIN invoices i ON i.id = r.invoice_id WHERE r.job_id=?""", (job_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ─────────────────────────────────────────────────────────────────────────────
#  RELEASE — voiding an invoice frees what it billed
# ─────────────────────────────────────────────────────────────────────────────

def release_invoice(db_path, invoice_id: int) -> dict:
    """Undo every job-billing record pointing at invoice_id: task billings
    (partial or full), visits, material recharges; and void the progress
    claim(s) raised with it. Called by core.ledger.void_invoice."""
    conn = get_connection(db_path)
    try:
        task_ids = {r["task_id"] for r in conn.execute(
            "SELECT task_id FROM work_task_billings WHERE invoice_id=?", (invoice_id,))}
        # Tasks stamped by older code paths that never wrote a billing row.
        task_ids |= {r["id"] for r in conn.execute(
            "SELECT id FROM work_tasks WHERE invoice_id=?", (invoice_id,))}
        conn.execute("DELETE FROM work_task_billings WHERE invoice_id=?", (invoice_id,))
        for tid in task_ids:
            q = conn.execute("""SELECT COALESCE(SUM(qty),0) AS q FROM work_task_billings
                WHERE task_id=?""", (tid,)).fetchone()["q"]
            # Whatever remains billed is on other invoices, and less than the
            # whole task — so it's no longer "fully invoiced".
            conn.execute("UPDATE work_tasks SET qty_invoiced=?, invoice_id=NULL WHERE id=?",
                         (q, tid))
        visits = conn.execute("""UPDATE schedule_events SET invoice_id=NULL, time_charged=NULL
            WHERE invoice_id=?""", (invoice_id,)).rowcount
        try:
            conn.execute("UPDATE visit_tasks SET invoice_id=NULL WHERE invoice_id=?", (invoice_id,))
        except Exception:
            pass  # table not migrated yet
        recharges = conn.execute("DELETE FROM job_recharges WHERE invoice_id=?",
                                 (invoice_id,)).rowcount
        claims = conn.execute("""UPDATE crm_progress_claims SET status='Void'
            WHERE invoice_id=? AND status <> 'Void'""", (invoice_id,)).rowcount
        conn.commit()
        return {"tasks": len(task_ids), "visits": visits, "recharges": recharges, "claims": claims}
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ─────────────────────────────────────────────────────────────────────────────
#  CLAIM BUILDER — one draft invoice + progress claim from everything unbilled
# ─────────────────────────────────────────────────────────────────────────────

def get_claim_builder_data(db_path, job_id: int) -> dict:
    """Everything on a job that can go on the next claim."""
    from core.jobs import get_job
    job = get_job(db_path, job_id)
    if not job:
        raise ValueError("Job not found")
    conn = get_connection(db_path)
    try:
        fixed = []
        for r in conn.execute("""SELECT id FROM work_tasks
                WHERE (job_id=? OR opp_id=?) AND invoice_id IS NULL
                  AND COALESCE(billing,'fixed')='fixed'
                ORDER BY is_done DESC, id""", (job_id, job_id)).fetchall():
            st = task_billing_state(conn, r["id"])
            if st["qty_remaining"] <= 0:
                continue
            t = st["task"]
            fixed.append({"id": t["id"], "title": t["title"], "description": t["description"],
                          "is_done": bool(t["is_done"]), "qty": st["qty"],
                          "unit_price": t["unit_price"], "contract": st["contract"],
                          "qty_billed": st["qty_billed"], "amount_billed": st["amount_billed"],
                          "amount_remaining": st["amount_remaining"]})
        hourly = [dict(r) for r in conn.execute("""SELECT id, title, description, is_done
            FROM work_tasks WHERE (job_id=? OR opp_id=?) AND invoice_id IS NULL
              AND billing='hourly' ORDER BY is_done DESC, id""", (job_id, job_id)).fetchall()]
        visits = [dict(r) for r in conn.execute("""SELECT id, title, description, event_date,
                start_time, end_time, all_day, hours
            FROM schedule_events WHERE job_id=? AND event_type='Visit' AND invoice_id IS NULL
            ORDER BY event_date, COALESCE(start_time,''), id""", (job_id,)).fetchall()]
        # Work recorded on each unclaimed visit (tasks on visits) — the
        # builder fills task quantities from the visits you tick.
        for v in visits:
            v["work"] = [dict(r) for r in conn.execute("""SELECT vt.task_id, vt.completed,
                    vt.qty_done, wt.title, COALESCE(wt.billing,'fixed') AS billing, wt.qty
                FROM visit_tasks vt JOIN work_tasks wt ON wt.id = vt.task_id
                WHERE vt.visit_id=? AND vt.invoice_id IS NULL
                  AND (vt.completed=1 OR COALESCE(vt.qty_done,0) > 0)
                ORDER BY vt.id""", (v["id"],)).fetchall()]
        claimed = conn.execute("""SELECT COALESCE(SUM(amount_inc_gst),0) AS s FROM crm_progress_claims
            WHERE job_id=? AND status <> 'Void'""", (job_id,)).fetchone()["s"]
        gst_reg = conn.execute("SELECT gst_registered FROM company WHERE id=1").fetchone()
    finally:
        conn.close()
    return {
        "job": {"id": job["id"], "job_number": job["job_number"], "name": job["name"],
                "contact_id": job["contact_id"], "hourly_rate": job.get("hourly_rate"),
                "value": job.get("value")},
        "fixed_tasks": fixed,
        "hourly_tasks": hourly,
        "visits": visits,
        "materials": get_job_billable_materials(db_path, job_id),
        "claimed_inc_gst": round(claimed, 2),
        "gst_registered": bool(gst_reg["gst_registered"]) if gst_reg else True,
    }


def _fmt_day(iso: str) -> str:
    from datetime import date
    d = date.fromisoformat(iso)
    return f"{d.day} {d.strftime('%b')}"


def build_claim_invoice(db_path, job_id: int, spec: dict, created_by=None) -> dict:
    """Create one Draft invoice + progress claim for a job from a selection:

      spec = {
        "tasks":           [{"id": task_id, "qty_to_date": n or None}],  fixed-price
        "visit_ids":       [...],     the visits this claim covers
        "include_time":    True,      their hours x hourly_rate as a labour line;
                                      False = the time is "not charged" (built
                                      into fixed prices) and never offered again
        "hourly_rate":     85.0,      defaults to the job's rate
        "hourly_task_ids": [...],     listed as comment lines under labour
        "materials":       [{"type": "bom"|"bill"|"po", "id": n}],
        "margin_pct":      15,        markup on bill/PO cost (BOM lines use their sell price)
        "claim_date":      "YYYY-MM-DD", "description": "...",
      }

    Everything is validated before the invoice is created, then every
    source is marked billed in one transaction; if that fails the new draft
    invoice is voided so nothing is left half-recorded. Returns
    {"invoice_id", "claim_id", "claim_number", "subtotal", "total"}."""
    from datetime import date, timedelta
    from core.ledger import save_invoice, void_invoice
    from core.jobs import get_job, next_claim_number, set_invoice_job

    job = get_job(db_path, job_id)
    if not job:
        raise ValueError("Job not found")
    if not job.get("contact_id"):
        raise ValueError("Job has no client — set one on the job before raising a claim")

    task_specs = spec.get("tasks") or []
    visit_ids  = [int(v) for v in (spec.get("visit_ids") or [])]
    hourly_ids = [int(t) for t in (spec.get("hourly_task_ids") or [])]
    mat_specs  = spec.get("materials") or []
    margin     = float(spec.get("margin_pct") or 0)
    claim_date = spec.get("claim_date") or date.today().isoformat()
    rate = spec.get("hourly_rate")
    rate = float(rate) if rate not in (None, "") else (job.get("hourly_rate") or None)
    include_time = bool(spec.get("include_time", True))

    conn = get_connection(db_path)
    try:
        gst_row = conn.execute("SELECT gst_registered FROM company WHERE id=1").fetchone()
        tax = "GST" if (not gst_row or gst_row["gst_registered"]) else "INP"
        terms = conn.execute("SELECT payment_terms FROM contacts WHERE id=?",
                             (job["contact_id"],)).fetchone()
        co = conn.execute("SELECT default_payment_instructions FROM company WHERE id=1").fetchone()

        lines, summary = [], []

        # Fixed-price tasks (whole or part)
        task_plans = []
        for ts in task_specs:
            tid = int(ts["id"])
            owner = conn.execute("SELECT job_id, opp_id FROM work_tasks WHERE id=?", (tid,)).fetchone()
            if not owner or job_id not in (owner["job_id"], owner["opp_id"]):
                raise ValueError(f"Task {tid} isn't on this job")
            q = ts.get("qty_to_date")
            plan = plan_task_billing(conn, tid, float(q) if q not in (None, "") else None)
            plan["line"]["tax_code"] = tax
            task_plans.append(plan)
            lines.append(plan["line"])
        if task_plans:
            summary.append(f"{len(task_plans)} task{'s' if len(task_plans) != 1 else ''}")

        # Visits: their time as labour, or marked "not charged"
        visits = []
        if visit_ids:
            if include_time and not rate:
                raise ValueError("Set an hourly rate (on the job or in the claim) to bill visit hours")
            ph = ",".join("?" * len(visit_ids))
            visits = [dict(r) for r in conn.execute(f"""SELECT id, event_date, hours, job_id,
                    event_type, invoice_id FROM schedule_events WHERE id IN ({ph})
                ORDER BY event_date""", visit_ids).fetchall()]
            if len(visits) != len(set(visit_ids)):
                raise ValueError("A selected visit no longer exists")
            for v in visits:
                if v["job_id"] != job_id or v["event_type"] != "Visit":
                    raise ValueError("A selected visit isn't on this job")
                if v["invoice_id"]:
                    raise ValueError(f"The {_fmt_day(v['event_date'])} visit has already been billed")
                if include_time and not v["hours"]:
                    raise ValueError(f"The {_fmt_day(v['event_date'])} visit has no hours recorded — "
                                     "add them, or leave the time off this claim")
            if include_time:
                hrs = round(sum(v["hours"] for v in visits), 2)
                days = ", ".join(_fmt_day(v["event_date"]) for v in visits)
                lines.append({"description": f"Labour — {hrs:g} hrs @ ${rate:,.2f}/hr ({days})",
                              "quantity": hrs, "unit_price": rate, "tax_code": tax, "line_type": "item"})
                summary.append(f"{hrs:g} hrs labour")
            else:
                summary.append(f"{len(visits)} visit{'s' if len(visits) != 1 else ''}")

        # Hourly tasks completed — listed under the labour, not priced
        hourly = []
        if hourly_ids:
            ph = ",".join("?" * len(hourly_ids))
            hourly = [dict(r) for r in conn.execute(f"""SELECT id, title, job_id, opp_id, billing,
                    invoice_id, qty FROM work_tasks WHERE id IN ({ph}) ORDER BY id""",
                    hourly_ids).fetchall()]
            for t in hourly:
                if job_id not in (t["job_id"], t["opp_id"]) or t["billing"] != "hourly":
                    raise ValueError(f"'{t['title']}' isn't an hourly task on this job")
                if t["invoice_id"]:
                    raise ValueError(f"'{t['title']}' is already on an invoice")
                lines.append({"description": f"✓ {t['title']}", "quantity": 0, "unit_price": 0,
                              "tax_code": tax, "line_type": "comment"})

        # Materials
        blocked = blocked_materials(conn, job_id)
        recharges = []
        for m in mat_specs:
            mtype, mid = m.get("type"), int(m.get("id"))
            if mtype not in ("bom", "bill", "po"):
                raise ValueError(f"Unknown material type {mtype!r}")
            if mid in blocked[mtype]:
                raise ValueError("A selected material has already been charged to the customer")
            if mtype == "bom":
                b = conn.execute("SELECT * FROM job_bom_lines WHERE id=? AND job_id=?",
                                 (mid, job_id)).fetchone()
                if not b:
                    raise ValueError("A selected material line isn't on this job")
                if b["is_customer_supplied"]:
                    raise ValueError(f"'{b['description']}' is customer-supplied")
                cost = round((b["qty"] or 0) * (b["unit_cost"] or 0), 2)
                sell = round((b["qty"] or 0) * (b["unit_price"] or 0), 2)
                lines.append({"description": f"Materials — {b['description']}",
                              "quantity": b["qty"] or 1, "unit_price": b["unit_price"] or 0,
                              "tax_code": tax, "line_type": "item"})
            else:
                table, num = ("bills", "bill_number") if mtype == "bill" else ("purchase_orders", "po_number")
                r = conn.execute(f"""SELECT x.{num} AS num, x.subtotal, c.name AS supplier
                    FROM {table} x LEFT JOIN contacts c ON c.id=x.contact_id
                    WHERE x.id=? AND x.job_id=?""", (mid, job_id)).fetchone()
                if not r:
                    raise ValueError(f"A selected {mtype.upper()} isn't on this job")
                cost = round(r["subtotal"] or 0, 2)
                sell = round(cost * (1 + margin / 100), 2)
                lines.append({"description": f"Materials — {r['num']} ({r['supplier'] or 'supplier'})",
                              "quantity": 1, "unit_price": sell, "tax_code": tax, "line_type": "item"})
            recharges.append((mtype, mid, cost, sell))
            # Picking a BOM line and its own PO/bill in the same claim is
            # the same purchase twice — treat this pick as charged already.
            blocked = blocked_materials(conn, job_id,
                                        extra=[(t, i) for t, i, _, _ in recharges])
        if recharges:
            summary.append("materials")
    finally:
        conn.close()

    if not any(l["line_type"] == "item" for l in lines):
        raise ValueError("Nothing to bill — select at least one task, visit or material")

    days = int(terms["payment_terms"]) if terms and terms["payment_terms"] else 30
    inv_id = save_invoice(db_path, {
        "contact_id":           job["contact_id"],
        "job_id":               job_id,
        "invoice_date":         claim_date,
        "due_date":             (date.fromisoformat(claim_date) + timedelta(days=days)).isoformat(),
        "status":               "Draft",
        "notes":                f"Progress claim — Job {job['job_number']} {job['name']}",
        "payment_instructions": co["default_payment_instructions"] if co else None,
    }, lines)
    set_invoice_job(db_path, inv_id, job_id)

    conn = get_connection(db_path)
    try:
        for p in task_plans:
            record_task_billing(conn, p, inv_id)
        claimed_tasks = [p["task_id"] for p in task_plans] + [t["id"] for t in hourly]
        for v in visits:
            conn.execute("UPDATE schedule_events SET invoice_id=?, time_charged=? WHERE id=?",
                         (inv_id, 1 if include_time else 0, v["id"]))
            # The work recorded on this visit for tasks on this claim is now
            # claimed (locked until the invoice is voided). Progress for tasks
            # left off the claim stays open for a later one.
            if claimed_tasks:
                ph = ",".join("?" * len(claimed_tasks))
                conn.execute(f"""UPDATE visit_tasks SET invoice_id=?
                    WHERE visit_id=? AND invoice_id IS NULL AND task_id IN ({ph})""",
                    [inv_id, v["id"]] + claimed_tasks)
        for t in hourly:
            q = float(t["qty"] or 1)
            conn.execute("""INSERT INTO work_task_billings (task_id, invoice_id, qty, amount)
                VALUES (?,?,?,0)""", (t["id"], inv_id, q))
            conn.execute("UPDATE work_tasks SET qty_invoiced=?, invoice_id=? WHERE id=?",
                         (q, inv_id, t["id"]))
        for mtype, mid, cost, sell in recharges:
            conn.execute("""INSERT INTO job_recharges
                (job_id, source_type, source_id, invoice_id, cost_amount, sell_amount)
                VALUES (?,?,?,?,?,?)""", (job_id, mtype, mid, inv_id, cost, sell))

        inv = conn.execute("SELECT subtotal, gst_total, total FROM invoices WHERE id=?",
                           (inv_id,)).fetchone()
        # save_invoice() stores subtotal unrounded (a float sum of qty × price);
        # the claim records whole cents.
        inv = {k: round(float(inv[k] or 0), 2) for k in ("subtotal", "gst_total", "total")}
        prior = conn.execute("""SELECT COALESCE(SUM(amount_inc_gst),0) AS s FROM crm_progress_claims
            WHERE job_id=? AND status <> 'Void'""", (job_id,)).fetchone()["s"]
        value = job.get("value") or 0
        pct = round((prior + inv["total"]) / value * 100, 1) if value else 0
        claim_number = next_claim_number(db_path)
        desc = (spec.get("description") or "").strip() or "Progress claim — " + ", ".join(summary)
        cur = conn.execute("""INSERT INTO crm_progress_claims
            (claim_number, job_id, contact_id, claim_date, description,
             amount_ex_gst, gst_amount, amount_inc_gst, cumulative_pct,
             invoice_id, status, created_by)
            VALUES (?,?,?,?,?,?,?,?,?,?, 'Invoiced', ?)""",
            (claim_number, job_id, job["contact_id"], claim_date, desc,
             inv["subtotal"], inv["gst_total"], inv["total"], pct, inv_id, created_by))
        conn.commit()
        return {"invoice_id": inv_id, "claim_id": cur.lastrowid, "claim_number": claim_number,
                "subtotal": inv["subtotal"], "total": inv["total"]}
    except Exception:
        conn.rollback()
        conn.close()
        conn = None
        # Don't leave a draft invoice behind that nothing is recorded against.
        void_invoice(db_path, inv_id)
        raise
    finally:
        if conn is not None:
            conn.close()
