# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""Google Drive sync-folder detection.

Detects the local folder where Google Drive for Desktop (or Backup and Sync)
syncs files, so the native file picker can open pre-pointed to Drive.
No API keys, no OAuth, no Google Cloud Console required.
"""
import os
import sys
import glob


def find_sync_folder() -> str:
    """Return the local Google Drive sync folder, or '' if not found."""
    home = os.path.expanduser('~')

    if sys.platform == 'win32':
        import ctypes

        # Identify the Google Drive virtual drive by its volume label.
        # GetVolumeInformationW is a fast kernel metadata call — it does NOT
        # traverse the virtual filesystem and will not block.
        try:
            buf = ctypes.create_unicode_buffer(261)
            for letter in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
                root = f'{letter}:\\'
                if not ctypes.windll.kernel32.GetVolumeInformationW(
                        root, buf, 261, None, None, None, None, 0):
                    continue
                if 'Google' in buf.value:
                    return f'{letter}:\\My Drive'
        except Exception:
            pass

        # Registry fallback (Drive for Desktop stores mount point here on some versions)
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                 r'Software\Google\DriveFS\Share')
            mount, _ = winreg.QueryValueEx(key, 'MountPoint')
            winreg.CloseKey(key)
            if mount:
                return os.path.join(mount, 'My Drive')
        except Exception:
            pass

        # Backup and Sync (legacy) — real local directories, safe to stat
        for name in ('Google Drive', 'My Drive'):
            p = os.path.join(home, name)
            if os.path.isdir(p):
                return p

    elif sys.platform == 'darwin':
        # Google Drive for Desktop on macOS uses ~/Library/CloudStorage/
        cloud = os.path.join(home, 'Library', 'CloudStorage')
        if os.path.isdir(cloud):
            matches = glob.glob(os.path.join(cloud, 'GoogleDrive-*', 'My Drive'))
            if matches:
                return matches[0]
        for name in ('Google Drive', 'My Drive'):
            p = os.path.join(home, name)
            if os.path.isdir(p):
                return p

    else:
        # Linux: rclone or google-drive-ocamlfuse common mount points
        for p in (
            os.path.join(home, 'GoogleDrive'),
            os.path.join(home, 'google-drive'),
            os.path.join(home, 'My Drive'),
            '/mnt/google-drive',
        ):
            if os.path.isdir(p):
                return p

    return ''
