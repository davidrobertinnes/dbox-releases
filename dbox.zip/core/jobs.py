"""
dbox Jobs / Projects module.

Schema:
  jobs              — project/job records with budget, status, contact
  job_transactions  — links any transaction (invoice/bill/journal/payment) to a job
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from datetime import date as _date, timedelta as _td
from core.database import get_connection

_TABLE_MAP = {
    "invoice": "invoices",
    "bill":    "bills",
    "payment": "payments",
    "journal": "journal_entries",
}


PIPELINE_STAGES = [
    "Lead", "Qualified", "Quoted", "Accepted",
    "In Progress", "On Hold", "Complete",
    "Invoiced", "Won", "Lost",
]


# ── Schema migration ──────────────────────────────────────────────────────────

def migrate_jobs(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS jobs (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        job_number      TEXT NOT NULL UNIQUE,
        name            TEXT NOT NULL,
        description     TEXT,
        contact_id      INTEGER REFERENCES contacts(id),
        status          TEXT NOT NULL DEFAULT 'Active',
        start_date      TEXT,
        end_date        TEXT,
        budget_amount   REAL,
        budget_notes    TEXT,
        manager         TEXT,
        created_by      INTEGER,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS job_transactions (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id          INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
        source_type     TEXT NOT NULL,
        source_id       INTEGER NOT NULL,
        amount          REAL NOT NULL DEFAULT 0,
        notes           TEXT,
        allocated_at    TEXT DEFAULT (datetime('now','localtime')),
        allocated_by    INTEGER,
        UNIQUE(job_id, source_type, source_id))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS job_employee_time (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id      INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
        employee_id INTEGER NOT NULL REFERENCES employees(id),
        entry_date  TEXT NOT NULL,
        hours       REAL NOT NULL DEFAULT 0,
        hourly_rate REAL NOT NULL DEFAULT 0,
        description TEXT,
        created_at  TEXT DEFAULT (datetime('now','localtime')))""")

    for table in ('invoices', 'bills', 'payments', 'journal_entries'):
        try:
            conn.execute(
                f"ALTER TABLE {table} ADD COLUMN job_id INTEGER REFERENCES jobs(id)")
        except Exception:
            pass


def migrate_jobs_v2(conn):
    """Phase 1: add pipeline fields to jobs — non-destructive ALTER TABLE only."""
    new_cols = [
        ("stage",        "TEXT NOT NULL DEFAULT 'Lead'"),
        ("source",       "TEXT"),
        ("value",        "REAL"),
        ("probability",  "INTEGER DEFAULT 50"),
        ("owner",        "TEXT"),
        ("target_close", "TEXT"),
        ("actual_close", "TEXT"),
        ("opp_number",   "TEXT"),
        ("notes",        "TEXT"),
    ]
    for col, defn in new_cols:
        try:
            conn.execute(f"ALTER TABLE jobs ADD COLUMN {col} {defn}")
        except Exception:
            pass
    try:
        conn.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_jobs_opp_number "
            "ON jobs(opp_number) WHERE opp_number IS NOT NULL")
    except Exception:
        pass


def migrate_phase5(conn):
    """Phase 5: drop crm_opportunities table — data is fully merged into jobs.

    Idempotent — if the table is already gone (or was never a real table), does nothing.
    """
    row = conn.execute(
        "SELECT type FROM sqlite_master WHERE name='crm_opportunities'"
    ).fetchone()
    if not row or row['type'] != 'table':
        return
    conn.execute("DROP TABLE crm_opportunities")
    conn.commit()


def migrate_remove_opp_fk(conn):
    """Patch stored CREATE TABLE SQL to remove dangling FK references to the
    dropped crm_opportunities table.  Uses PRAGMA writable_schema so no data
    is moved.  Idempotent — skips tables that no longer reference the old table.
    """
    import re

    # If crm_opportunities still exists there's nothing dangling to fix.
    if conn.execute(
        "SELECT name FROM sqlite_master WHERE name='crm_opportunities'"
    ).fetchone():
        return

    tables = ('crm_quotes', 'crm_communications', 'crm_tasks', 'crm_progress_claims', 'work_tasks', 'invoices', 'bills', 'purchase_orders')
    needs_fix = []
    for tbl in tables:
        row = conn.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (tbl,)
        ).fetchone()
        if row and row[0] and 'crm_opportunities' in row[0]:
            needs_fix.append((tbl, row[0]))

    if not needs_fix:
        return

    conn.execute("PRAGMA writable_schema = ON")
    for tbl, old_sql in needs_fix:
        new_sql = re.sub(
            r'\s+REFERENCES\s+crm_opportunities\([^)]+\)(?:\s+ON\s+DELETE\s+CASCADE)?',
            '',
            old_sql,
            flags=re.IGNORECASE,
        )
        conn.execute(
            "UPDATE sqlite_master SET sql=? WHERE type='table' AND name=?",
            (new_sql, tbl),
        )
    conn.execute("PRAGMA writable_schema = OFF")
    # Bump schema_version so SQLite invalidates its internal schema cache.
    ver = conn.execute("PRAGMA schema_version").fetchone()[0]
    conn.execute(f"PRAGMA schema_version = {ver + 1}")
    conn.commit()


def migrate_jobs_phase2(conn):
    """Phase 2: merge crm_opportunities data into jobs, populate job_id on dependents.

    Idempotent — safe to re-run. Does NOT drop crm_opportunities (Phase 5 cleanup).
    """
    # Step C runs unconditionally so fresh DBs always get job_id columns.
    for stmt in [
        "ALTER TABLE crm_communications ADD COLUMN job_id      INTEGER REFERENCES jobs(id)",
        "ALTER TABLE crm_communications ADD COLUMN invoice_id  INTEGER REFERENCES invoices(id)",
        "ALTER TABLE crm_quotes         ADD COLUMN job_id      INTEGER REFERENCES jobs(id)",
        "ALTER TABLE crm_tasks          ADD COLUMN job_id      INTEGER REFERENCES jobs(id)",
        "ALTER TABLE crm_tasks          ADD COLUMN contact_id  INTEGER REFERENCES contacts(id)",
    ]:
        try:
            conn.execute(stmt)
        except Exception:
            pass
    conn.commit()

    # If crm_opportunities is already gone (or never existed), data migration
    # already ran (or is not needed).
    row = conn.execute(
        "SELECT type FROM sqlite_master WHERE name='crm_opportunities'"
    ).fetchone()
    if not row or row['type'] != 'table':
        return

    # ── Step A: Linked opps (job_id set) — copy pipeline fields into jobs ────
    conn.execute("""
        UPDATE jobs SET
            stage        = COALESCE((SELECT stage        FROM crm_opportunities WHERE job_id=jobs.id LIMIT 1), stage),
            source       = COALESCE((SELECT source       FROM crm_opportunities WHERE job_id=jobs.id LIMIT 1), source),
            value        = COALESCE((SELECT value        FROM crm_opportunities WHERE job_id=jobs.id LIMIT 1), value),
            probability  = COALESCE((SELECT probability  FROM crm_opportunities WHERE job_id=jobs.id LIMIT 1), probability),
            owner        = COALESCE((SELECT owner        FROM crm_opportunities WHERE job_id=jobs.id LIMIT 1), owner),
            target_close = COALESCE((SELECT target_close FROM crm_opportunities WHERE job_id=jobs.id LIMIT 1), target_close),
            actual_close = COALESCE((SELECT actual_close FROM crm_opportunities WHERE job_id=jobs.id LIMIT 1), actual_close),
            opp_number   = COALESCE(opp_number, (SELECT opp_number FROM crm_opportunities WHERE job_id=jobs.id LIMIT 1)),
            notes        = COALESCE(notes, (SELECT notes FROM crm_opportunities WHERE job_id=jobs.id LIMIT 1))
        WHERE EXISTS (SELECT 1 FROM crm_opportunities WHERE job_id=jobs.id)
    """)
    conn.commit()

    # ── Step B: Orphan opps (no job_id) — create new job rows ────────────────
    _STAGE_TO_STATUS = {
        'Lost':     'Cancelled',
        'Complete': 'Completed',
        'Invoiced': 'Completed',
        'Won':      'Completed',
        'On Hold':  'On Hold',
    }
    orphans = conn.execute(
        "SELECT * FROM crm_opportunities WHERE job_id IS NULL"
    ).fetchall()
    for opp in orphans:
        stage  = opp['stage'] or 'Lead'
        status = _STAGE_TO_STATUS.get(stage, 'Active')
        jnum   = opp['opp_number'] or f"OPP-{opp['id']:04d}"
        conn.execute("""
            INSERT INTO jobs
                (job_number, name, description, contact_id, status,
                 start_date, end_date, budget_amount, manager, created_by, created_at,
                 stage, source, value, probability, owner,
                 target_close, actual_close, opp_number, notes)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            jnum, opp['title'], opp['description'], opp['contact_id'], status,
            opp['start_date'], opp['target_close'], opp['value'], opp['owner'],
            opp['created_by'], opp['created_at'],
            opp['stage'], opp['source'], opp['value'], opp['probability'], opp['owner'],
            opp['target_close'], opp['actual_close'], opp['opp_number'], opp['notes'],
        ))
        new_jid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        # Mark opp as linked so this step is idempotent on re-run
        conn.execute(
            "UPDATE crm_opportunities SET job_id=? WHERE id=?",
            (new_jid, opp['id']))
    conn.commit()

    # ── Step D: Populate job_id on all dependent tables ───────────────────────
    # Each UPDATE uses COALESCE so existing non-null values are never overwritten.
    updates = [
        # (table,               fk_col,         where_col)
        ("crm_communications",  "job_id",        "opp_id"),
        ("crm_tasks",           "job_id",        "opp_id"),
        ("work_tasks",          "job_id",        "opp_id"),
        ("crm_quotes",          "job_id",        "opp_id"),
        ("crm_progress_claims", "job_id",        "opp_id"),
        ("invoices",            "job_id",        "opp_id"),
        ("bills",               "job_id",        "opp_id"),
    ]
    for tbl, dest, src in updates:
        conn.execute(f"""
            UPDATE {tbl}
            SET {dest} = (
                SELECT job_id FROM crm_opportunities
                WHERE id = {tbl}.{src}
            )
            WHERE {src} IS NOT NULL AND {dest} IS NULL
        """)

    # purchase_orders uses opportunity_id not opp_id
    po_exists = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='purchase_orders'"
    ).fetchone()
    if po_exists:
        conn.execute("""
            UPDATE purchase_orders
            SET job_id = (
                SELECT job_id FROM crm_opportunities
                WHERE id = purchase_orders.opportunity_id
            )
            WHERE opportunity_id IS NOT NULL AND job_id IS NULL
        """)
    conn.commit()


# ── Job CRUD ──────────────────────────────────────────────────────────────────

def next_job_number(db_path) -> str:
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT job_number FROM jobs ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    prefix = f"JOB-{_date.today().year}-"
    if row and row[0].startswith(prefix):
        try:
            seq = int(row[0][len(prefix):]) + 1
        except ValueError:
            seq = 1
    else:
        seq = 1
    return f"{prefix}{seq:04d}"


def get_jobs(db_path, status=None):
    conn = get_connection(db_path)
    migrate_jobs(conn)   # ensure tables exist — idempotent
    conn.commit()
    q = """SELECT j.*, c.name as contact_name,
        (SELECT COUNT(*) FROM job_transactions jt WHERE jt.job_id=j.id) as txn_count,
        (SELECT COUNT(*) FROM crm_tasks ct WHERE ct.job_id=j.id AND ct.is_done=0) as open_tasks,
        (SELECT COUNT(*) FROM crm_communications cm WHERE cm.job_id=j.id) as comm_count
        FROM jobs j LEFT JOIN contacts c ON j.contact_id=c.id WHERE 1=1"""
    params = []
    if status:
        q += " AND j.status=?"
        params.append(status)
    q += " ORDER BY j.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_job(db_path, job_id):
    conn = get_connection(db_path)
    row = conn.execute("""SELECT j.*, c.name as contact_name
        FROM jobs j LEFT JOIN contacts c ON j.contact_id=c.id
        WHERE j.id=?""", (job_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_job(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    jid = data.get("id")
    fields = ["job_number","name","description","contact_id","status",
              "start_date","end_date","budget_amount","budget_notes",
              "manager","created_by",
              "stage","source","value","probability","owner",
              "target_close","actual_close","notes"]
    vals = [data.get(f) for f in fields]
    if jid:
        sets = ", ".join(f"{f}=?" for f in fields)
        conn.execute(f"UPDATE jobs SET {sets} WHERE id=?", vals + [jid])
    else:
        cols = ", ".join(fields)
        ph   = ", ".join("?" for _ in fields)
        conn.execute(f"INSERT INTO jobs ({cols}) VALUES ({ph})", vals)
        jid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit(); conn.close()
    return jid


def delete_job(db_path, job_id):
    conn = get_connection(db_path)
    try:
        # NULL out the denormalised job_id FK on transaction tables first.
        # These columns have no ON DELETE clause so SQLite raises
        # FOREIGN KEY constraint failed if any row still references the job.
        for table in ('invoices', 'bills', 'payments', 'journal_entries'):
            conn.execute(
                f"UPDATE {table} SET job_id=NULL WHERE job_id=?", (job_id,))
        conn.execute("DELETE FROM job_transactions  WHERE job_id=?", (job_id,))
        conn.execute("DELETE FROM job_employee_time WHERE job_id=?", (job_id,))
        conn.execute("DELETE FROM jobs WHERE id=?", (job_id,))
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ── Transaction Allocation ────────────────────────────────────────────────────

def allocate_transaction(db_path, job_id, source_type, source_id,
                          amount=0.0, notes="", allocated_by=None):
    conn = get_connection(db_path)
    conn.execute("""INSERT OR REPLACE INTO job_transactions
        (job_id, source_type, source_id, amount, notes, allocated_by)
        VALUES (?,?,?,?,?,?)""",
        (job_id, source_type, source_id, float(amount or 0), notes or "", allocated_by))
    if source_type in _TABLE_MAP:
        try:
            conn.execute(
                f"UPDATE {_TABLE_MAP[source_type]} SET job_id=? WHERE id=?",
                (job_id, source_id))
        except Exception:
            pass
    conn.commit(); conn.close()


def deallocate_transaction(db_path, job_id, source_type, source_id):
    conn = get_connection(db_path)
    conn.execute("""DELETE FROM job_transactions
        WHERE job_id=? AND source_type=? AND source_id=?""",
        (job_id, source_type, source_id))
    if source_type in _TABLE_MAP:
        try:
            conn.execute(
                f"UPDATE {_TABLE_MAP[source_type]} SET job_id=NULL WHERE id=?",
                (source_id,))
        except Exception:
            pass
    conn.commit(); conn.close()


def get_job_transactions(db_path, job_id):
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT jt.*,
        CASE jt.source_type
            WHEN 'invoice' THEN (SELECT invoice_number FROM invoices WHERE id=jt.source_id)
            WHEN 'bill'    THEN (SELECT bill_number    FROM bills    WHERE id=jt.source_id)
            WHEN 'payment' THEN (SELECT reference      FROM payments WHERE id=jt.source_id)
            WHEN 'journal' THEN (SELECT reference      FROM journal_entries WHERE id=jt.source_id)
        END as ref_number,
        CASE jt.source_type
            WHEN 'invoice' THEN (SELECT invoice_date FROM invoices WHERE id=jt.source_id)
            WHEN 'bill'    THEN (SELECT bill_date    FROM bills    WHERE id=jt.source_id)
            WHEN 'payment' THEN (SELECT payment_date FROM payments WHERE id=jt.source_id)
            WHEN 'journal' THEN (SELECT entry_date   FROM journal_entries WHERE id=jt.source_id)
        END as txn_date,
        CASE jt.source_type
            WHEN 'invoice' THEN (SELECT c.name FROM invoices i
                                 JOIN contacts c ON i.contact_id=c.id WHERE i.id=jt.source_id)
            WHEN 'bill'    THEN (SELECT c.name FROM bills b
                                 JOIN contacts c ON b.contact_id=c.id WHERE b.id=jt.source_id)
            WHEN 'payment' THEN (SELECT c.name FROM payments p
                                 JOIN contacts c ON p.contact_id=c.id WHERE p.id=jt.source_id)
            ELSE NULL
        END as contact_name
        FROM job_transactions jt
        WHERE jt.job_id=?
        ORDER BY txn_date, jt.id""", (job_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ── Job P&L ───────────────────────────────────────────────────────────────────

def get_job_pl(db_path, job_id):
    conn = get_connection(db_path)
    # Union direct job_id links with manual job_transactions to avoid double-counting
    rev = conn.execute("""
        SELECT COALESCE(SUM(subtotal), 0) FROM invoices
        WHERE id IN (
            SELECT source_id FROM job_transactions WHERE job_id=? AND source_type='invoice'
            UNION SELECT id FROM invoices WHERE job_id=?
        ) AND status NOT IN ('Void','Voided','Written Off')""",
        (job_id, job_id)).fetchone()[0]
    bill_costs = conn.execute("""
        SELECT COALESCE(SUM(subtotal), 0) FROM bills
        WHERE id IN (
            SELECT source_id FROM job_transactions WHERE job_id=? AND source_type='bill'
            UNION SELECT id FROM bills WHERE job_id=?
        ) AND status NOT IN ('Void','Voided')""",
        (job_id, job_id)).fetchone()[0]
    labour_costs = conn.execute("""
        SELECT COALESCE(SUM(hours * hourly_rate), 0) FROM job_employee_time
        WHERE job_id=?""",
        (job_id,)).fetchone()[0]
    jnl_costs = conn.execute("""SELECT COALESCE(SUM(jl.debit - jl.credit),0) as total
        FROM job_transactions jt
        JOIN journal_entries je ON jt.source_id=je.id
        JOIN journal_lines jl ON jl.journal_id=je.id
        JOIN accounts a ON jl.account_id=a.id
        WHERE jt.job_id=? AND jt.source_type='journal'
          AND a.account_type IN ('Expense','Cost of Sales')""",
        (job_id,)).fetchone()["total"]
    total_costs  = bill_costs + labour_costs + jnl_costs
    gross_profit = rev - total_costs
    job    = conn.execute("SELECT budget_amount FROM jobs WHERE id=?",
                          (job_id,)).fetchone()
    budget = (job["budget_amount"] or 0) if job else 0
    conn.close()
    return {
        "revenue":         round(rev, 2),
        "bill_costs":      round(bill_costs, 2),
        "labour_costs":    round(labour_costs, 2),
        "journal_costs":   round(jnl_costs, 2),
        "total_costs":     round(total_costs, 2),
        "gross_profit":    round(gross_profit, 2),
        "margin_pct":      round(gross_profit / rev * 100, 1) if rev else 0,
        "budget":          budget,
        "budget_variance": round(gross_profit - budget, 2),
    }


# ── Transaction pickers ───────────────────────────────────────────────────────

def get_unallocated_invoices(db_path):
    """Return invoices not yet linked to any job."""
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT i.id, i.invoice_number, i.invoice_date,
        c.name as contact_name, i.total, i.status
        FROM invoices i LEFT JOIN contacts c ON i.contact_id=c.id
        WHERE i.status NOT IN ('Void','Voided')
          AND i.id NOT IN (
              SELECT source_id FROM job_transactions WHERE source_type='invoice')
        ORDER BY i.invoice_date DESC""").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_unallocated_bills(db_path):
    """Return bills not yet linked to any job."""
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT b.id, b.bill_number, b.bill_date,
        c.name as contact_name, b.total, b.status
        FROM bills b LEFT JOIN contacts c ON b.contact_id=c.id
        WHERE b.status NOT IN ('Void','Voided')
          AND b.id NOT IN (
              SELECT source_id FROM job_transactions WHERE source_type='bill')
        ORDER BY b.bill_date DESC""").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_unallocated_payments(db_path):
    """Return payments not yet linked to any job."""
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT p.id, p.reference, p.payment_date,
        c.name as contact_name, p.amount, p.payment_type
        FROM payments p LEFT JOIN contacts c ON p.contact_id=c.id
        WHERE p.id NOT IN (
            SELECT source_id FROM job_transactions WHERE source_type='payment')
        ORDER BY p.payment_date DESC""").fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ── Job assignment helpers (invoice/bill forms) ───────────────────────────────

def get_job_for_invoice(db_path, invoice_id):
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT job_id FROM invoices WHERE id=?",
                           (invoice_id,)).fetchone()
        conn.close()
        return row["job_id"] if row else None
    except Exception:
        conn.close()
        return None


def get_job_for_bill(db_path, bill_id):
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT job_id FROM bills WHERE id=?",
                           (bill_id,)).fetchone()
        conn.close()
        return row["job_id"] if row else None
    except Exception:
        conn.close()
        return None


def set_invoice_job(db_path, invoice_id, job_id):
    """Assign or clear a job on an invoice, syncing job_transactions."""
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT total, job_id FROM invoices WHERE id=?",
                           (invoice_id,)).fetchone()
        old_jid = row["job_id"] if row else None
        amount  = float(row["total"] or 0) if row else 0.0
        conn.execute("UPDATE invoices SET job_id=? WHERE id=?", (job_id, invoice_id))
        conn.commit()
    except Exception:
        conn.close()
        return
    conn.close()
    if old_jid and old_jid != job_id:
        try:
            deallocate_transaction(db_path, old_jid, "invoice", invoice_id)
        except Exception:
            pass
    if job_id:
        allocate_transaction(db_path, job_id, "invoice", invoice_id, amount)


def set_bill_job(db_path, bill_id, job_id):
    """Assign or clear a job on a bill, syncing job_transactions."""
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT total, job_id FROM bills WHERE id=?",
                           (bill_id,)).fetchone()
        old_jid = row["job_id"] if row else None
        amount  = float(row["total"] or 0) if row else 0.0
        conn.execute("UPDATE bills SET job_id=? WHERE id=?", (job_id, bill_id))
        conn.commit()
    except Exception:
        conn.close()
        return
    conn.close()
    if old_jid and old_jid != job_id:
        try:
            deallocate_transaction(db_path, old_jid, "bill", bill_id)
        except Exception:
            pass
    if job_id:
        allocate_transaction(db_path, job_id, "bill", bill_id, amount)


def set_payment_job(db_path, payment_id, job_id):
    """Assign or clear a job on a payment, syncing job_transactions."""
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT amount FROM payments WHERE id=?",
                           (payment_id,)).fetchone()
        amount = float(row["amount"] or 0) if row else 0.0
        # Get old job via job_transactions
        old_jt = conn.execute(
            "SELECT job_id FROM job_transactions WHERE source_type='payment' AND source_id=?",
            (payment_id,)).fetchone()
        old_jid = old_jt["job_id"] if old_jt else None
        # Store job_id on payment row
        conn.execute("UPDATE payments SET job_id=? WHERE id=?", (job_id, payment_id))
        conn.commit()
    except Exception:
        conn.close()
        return
    conn.close()
    if old_jid and old_jid != job_id:
        try:
            deallocate_transaction(db_path, old_jid, "payment", payment_id)
        except Exception:
            pass
    if job_id:
        allocate_transaction(db_path, job_id, "payment", payment_id, amount)


# ── Job employee time entries ─────────────────────────────────────────────────

def get_job_time_entries(db_path, job_id):
    """Return all time entries for a job with employee names."""
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT jt.*, e.first_name, e.last_name, e.employee_number,
               (jt.hours * jt.hourly_rate) AS line_cost
        FROM job_employee_time jt
        JOIN employees e ON jt.employee_id = e.id
        WHERE jt.job_id = ?
        ORDER BY jt.entry_date, e.last_name""", (job_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_job_time_entry(db_path, data):
    """Insert or update a time entry. Returns the row id."""
    conn = get_connection(db_path)
    eid = data.get("id")
    if eid:
        conn.execute("""UPDATE job_employee_time
            SET job_id=?, employee_id=?, entry_date=?, hours=?,
                hourly_rate=?, description=?
            WHERE id=?""",
            (data["job_id"], data["employee_id"], data["entry_date"],
             data["hours"], data["hourly_rate"],
             data.get("description",""), eid))
    else:
        cur = conn.execute("""INSERT INTO job_employee_time
            (job_id, employee_id, entry_date, hours, hourly_rate, description)
            VALUES (?,?,?,?,?,?)""",
            (data["job_id"], data["employee_id"], data["entry_date"],
             data["hours"], data["hourly_rate"], data.get("description","")))
        eid = cur.lastrowid
    conn.commit()
    conn.close()
    return eid


def delete_job_time_entry(db_path, entry_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM job_employee_time WHERE id=?", (entry_id,))
    conn.commit()
    conn.close()


def get_job_employee_profitability(db_path, job_id):
    """
    Return per-employee summary for a job:
    { employee_id, name, total_hours, total_cost, revenue_share }
    Revenue is apportioned by hours fraction.
    """
    conn = get_connection(db_path)
    time_rows = conn.execute("""
        SELECT jt.employee_id,
               e.first_name || ' ' || e.last_name AS emp_name,
               e.employee_number,
               SUM(jt.hours)                       AS total_hours,
               SUM(jt.hours * jt.hourly_rate)      AS total_cost
        FROM job_employee_time jt
        JOIN employees e ON jt.employee_id = e.id
        WHERE jt.job_id = ?
        GROUP BY jt.employee_id
        ORDER BY emp_name""", (job_id,)).fetchall()

    # Get total job revenue from invoices
    rev_row = conn.execute("""
        SELECT COALESCE(SUM(i.total), 0) AS revenue
        FROM invoices i
        WHERE i.job_id = ? AND i.status NOT IN ('Void','Draft')
        """, (job_id,)).fetchone()
    conn.close()

    total_revenue = rev_row["revenue"] if rev_row else 0
    all_hours = sum(r["total_hours"] for r in time_rows) or 1

    result = []
    for r in time_rows:
        hours_frac = r["total_hours"] / all_hours
        rev_share  = total_revenue * hours_frac
        profit     = rev_share - r["total_cost"]
        margin     = (profit / rev_share * 100) if rev_share else 0
        result.append({
            "employee_id":  r["employee_id"],
            "name":         r["emp_name"],
            "employee_number": r["employee_number"],
            "total_hours":  r["total_hours"],
            "total_cost":   r["total_cost"],
            "revenue_share": rev_share,
            "profit":        profit,
            "margin_pct":    margin,
        })
    return result


def get_all_jobs_employee_profitability(db_path):
    """
    Cross-job summary: for every employee who has logged time,
    return their totals across ALL jobs.
    Returns list of dicts:
      { employee_id, name, employee_number, job_count,
        total_hours, total_cost, total_revenue, profit, margin_pct,
        jobs: [{job_id, job_number, name, hours, cost, revenue_share}] }
    """
    conn = get_connection(db_path)

    # Per-employee per-job hours and cost
    rows = conn.execute("""
        SELECT  jt.employee_id,
                e.first_name || ' ' || e.last_name AS emp_name,
                e.employee_number,
                jt.job_id,
                j.job_number,
                j.name                             AS job_name,
                SUM(jt.hours)                      AS hours,
                SUM(jt.hours * jt.hourly_rate)     AS cost
        FROM    job_employee_time jt
        JOIN    employees e ON jt.employee_id = e.id
        JOIN    jobs      j ON jt.job_id      = j.id
        GROUP BY jt.employee_id, jt.job_id
        ORDER BY emp_name, j.job_number
    """).fetchall()

    # Revenue per job (from non-void invoices with job_id set)
    rev_rows = conn.execute("""
        SELECT  jt2.job_id,
                COALESCE(SUM(i.total), 0) AS revenue
        FROM    (SELECT DISTINCT job_id FROM job_employee_time) jt2
        LEFT JOIN invoices i
               ON i.job_id = jt2.job_id
              AND i.status NOT IN ('Void','Draft')
        GROUP BY jt2.job_id
    """).fetchall()
    job_revenue = {r["job_id"]: r["revenue"] for r in rev_rows}

    # Total hours per job (for revenue apportionment)
    totalhrs_rows = conn.execute("""
        SELECT job_id, SUM(hours) AS total_hours
        FROM   job_employee_time
        GROUP BY job_id
    """).fetchall()
    job_total_hrs = {r["job_id"]: r["total_hours"] or 1 for r in totalhrs_rows}

    conn.close()

    # Aggregate by employee
    emp_map = {}
    for r in rows:
        eid = r["employee_id"]
        if eid not in emp_map:
            emp_map[eid] = {
                "employee_id":     eid,
                "name":            r["emp_name"],
                "employee_number": r["employee_number"],
                "job_count":       0,
                "total_hours":     0.0,
                "total_cost":      0.0,
                "total_revenue":   0.0,
                "jobs":            [],
            }
        rev = job_revenue.get(r["job_id"], 0)
        hrs_frac = r["hours"] / job_total_hrs[r["job_id"]]
        rev_share = rev * hrs_frac

        emp_map[eid]["total_hours"]   += r["hours"]
        emp_map[eid]["total_cost"]    += r["cost"]
        emp_map[eid]["total_revenue"] += rev_share
        emp_map[eid]["job_count"]     += 1
        emp_map[eid]["jobs"].append({
            "job_id":      r["job_id"],
            "job_number":  r["job_number"],
            "name":        r["job_name"],
            "hours":       r["hours"],
            "cost":        r["cost"],
            "revenue_share": rev_share,
        })

    result = []
    for e in emp_map.values():
        profit = e["total_revenue"] - e["total_cost"]
        margin = (profit / e["total_revenue"] * 100) if e["total_revenue"] else 0
        e["profit"]     = profit
        e["margin_pct"] = margin
        result.append(e)

    result.sort(key=lambda x: -x["total_hours"])
    return result


# ══════════════════════════════════════════════════════════════════════════════
# CRM — moved here from core/crm.py in Phase 3
# ══════════════════════════════════════════════════════════════════════════════

COMM_TYPES   = ["Call", "Email", "Meeting", "Site Visit", "Note", "SMS", "Other"]
TASK_TYPES   = ["Follow Up", "Send Quote", "Schedule Meeting",
                "Site Inspection", "Internal Review", "Other"]
PRIORITY     = ["Low", "Normal", "High", "Urgent"]
QUOTE_STATUS = ["Draft", "Sent", "Accepted", "Declined", "Superseded"]


# ── CRM Schema Migration ───────────────────────────────────────────────────────

def migrate_crm(conn):
    """Create all CRM tables. Safe to call on existing databases."""

    conn.execute("""CREATE TABLE IF NOT EXISTS crm_communications (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        opp_id          INTEGER,
        contact_id      INTEGER REFERENCES contacts(id),
        comm_date       TEXT NOT NULL,
        comm_type       TEXT NOT NULL DEFAULT 'Note',
        subject         TEXT,
        body            TEXT,
        outcome         TEXT,
        next_action     TEXT,
        next_action_date TEXT,
        logged_by       INTEGER,
        logged_at       TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS crm_tasks (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        opp_id          INTEGER,
        task_type       TEXT NOT NULL DEFAULT 'Follow Up',
        title           TEXT NOT NULL,
        description     TEXT,
        due_date        TEXT,
        priority        TEXT NOT NULL DEFAULT 'Normal',
        assigned_to     TEXT,
        is_done         INTEGER NOT NULL DEFAULT 0,
        done_at         TEXT,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS crm_quotes (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        quote_number    TEXT NOT NULL UNIQUE,
        opp_id          INTEGER,
        contact_id      INTEGER REFERENCES contacts(id),
        quote_date      TEXT NOT NULL,
        expiry_date     TEXT,
        status          TEXT NOT NULL DEFAULT 'Draft',
        subtotal        REAL DEFAULT 0,
        gst_total       REAL DEFAULT 0,
        total           REAL DEFAULT 0,
        intro_text      TEXT,
        terms_text      TEXT,
        internal_notes  TEXT,
        accepted_date   TEXT,
        accepted_by     TEXT,
        invoice_id      INTEGER REFERENCES invoices(id),
        created_by      INTEGER,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS crm_quote_lines (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        quote_id        INTEGER NOT NULL REFERENCES crm_quotes(id) ON DELETE CASCADE,
        sort_order      INTEGER DEFAULT 0,
        description     TEXT NOT NULL,
        quantity        REAL DEFAULT 1,
        unit_price      REAL DEFAULT 0,
        tax_code        TEXT DEFAULT 'GST',
        gst_amount      REAL DEFAULT 0,
        line_total      REAL DEFAULT 0,
        account_id      INTEGER REFERENCES accounts(id),
        item_id         INTEGER REFERENCES items(id),
        line_type       TEXT DEFAULT 'item')""")

    conn.execute("""CREATE TABLE IF NOT EXISTS crm_progress_claims (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        claim_number    TEXT NOT NULL UNIQUE,
        opp_id          INTEGER,
        job_id          INTEGER REFERENCES jobs(id),
        contact_id      INTEGER REFERENCES contacts(id),
        claim_date      TEXT NOT NULL,
        description     TEXT,
        amount_ex_gst   REAL NOT NULL DEFAULT 0,
        gst_amount      REAL DEFAULT 0,
        amount_inc_gst  REAL NOT NULL DEFAULT 0,
        cumulative_pct  REAL DEFAULT 0,
        invoice_id      INTEGER REFERENCES invoices(id),
        status          TEXT NOT NULL DEFAULT 'Draft',
        created_by      INTEGER,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS work_tasks (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        contact_id  INTEGER NOT NULL REFERENCES contacts(id),
        title       TEXT NOT NULL,
        description TEXT,
        qty         REAL DEFAULT 1,
        unit_price  REAL DEFAULT 0,
        is_done     BOOLEAN DEFAULT 0,
        done_at     TIMESTAMP,
        invoice_id  INTEGER REFERENCES invoices(id),
        created_at  TIMESTAMP DEFAULT (datetime('now','localtime')))""")

    for _stmt in [
        "ALTER TABLE crm_communications    ADD COLUMN invoice_id INTEGER REFERENCES invoices(id)",
        "ALTER TABLE crm_communications    ADD COLUMN job_id INTEGER REFERENCES jobs(id)",
        "ALTER TABLE crm_quotes            ADD COLUMN job_id INTEGER REFERENCES jobs(id)",
        "ALTER TABLE crm_progress_claims   ADD COLUMN job_id INTEGER REFERENCES jobs(id)",
        "ALTER TABLE crm_quote_lines       ADD COLUMN item_id INTEGER REFERENCES items(id)",
        "ALTER TABLE crm_quote_lines       ADD COLUMN line_type TEXT DEFAULT 'item'",
        "ALTER TABLE work_tasks            ADD COLUMN job_id INTEGER REFERENCES jobs(id)",
        "ALTER TABLE work_tasks            ADD COLUMN opp_id INTEGER",
        "ALTER TABLE crm_tasks             ADD COLUMN job_id INTEGER REFERENCES jobs(id)",
        "ALTER TABLE crm_tasks             ADD COLUMN contact_id INTEGER REFERENCES contacts(id)",
    ]:
        try:
            conn.execute(_stmt)
        except Exception:
            pass

    for name, defn in [
        ("idx_crm_comm_opp",       "crm_communications(opp_id)"),
        ("idx_crm_task_opp",       "crm_tasks(opp_id)"),
        ("idx_crm_task_due",       "crm_tasks(due_date, is_done)"),
        ("idx_crm_quote_opp",      "crm_quotes(opp_id)"),
        ("idx_crm_claim_opp",      "crm_progress_claims(opp_id)"),
        ("idx_work_tasks_contact", "work_tasks(contact_id)"),
        ("idx_work_tasks_invoice", "work_tasks(invoice_id)"),
        ("idx_crm_task_contact",   "crm_tasks(contact_id)"),
    ]:
        try:
            conn.execute(f"CREATE INDEX IF NOT EXISTS {name} ON {defn}")
        except Exception:
            pass


# ── Sequence numbers ──────────────────────────────────────────────────────────

def next_opp_number(db_path):
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT opp_number FROM jobs WHERE opp_number IS NOT NULL ORDER BY id DESC LIMIT 1"
    ).fetchone()
    conn.close()
    if row:
        try:
            return f"OPP-{int(row[0].split('-')[-1]) + 1:04d}"
        except Exception:
            pass
    return "OPP-0001"


def next_quote_number(db_path):
    conn = get_connection(db_path)
    co = conn.execute("SELECT quote_prefix, quote_next FROM company WHERE id=1").fetchone()
    prefix = (co["quote_prefix"] or "QTE-") if co else "QTE-"
    floor  = max(1, int(co["quote_next"] or 1)) if co else 1
    row = conn.execute(
        "SELECT quote_number FROM crm_quotes ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    num = floor
    if row and row[0]:
        last = row[0]
        stripped = last[len(prefix):] if last.startswith(prefix) else last
        try:
            num = max(int(stripped) + 1, floor)
        except Exception:
            pass
    return f"{prefix}{num:04d}"


def next_claim_number(db_path):
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT claim_number FROM crm_progress_claims ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    if row:
        try:
            return f"CLM-{int(row[0].split('-')[-1]) + 1:04d}"
        except Exception:
            pass
    return "CLM-0001"


# ── Opportunities ─────────────────────────────────────────────────────────────

def get_opportunities(db_path, stage=None, contact_id=None, search=None):
    conn = get_connection(db_path)
    q = """SELECT j.*, j.name AS title, j.id AS job_id, c.name as contact_name,
                  (SELECT COUNT(*) FROM crm_communications WHERE job_id=j.id) as comm_count,
                  (SELECT COUNT(*) FROM crm_tasks WHERE job_id=j.id AND is_done=0) as open_tasks,
                  (SELECT COUNT(*) FROM crm_quotes WHERE job_id=j.id) as quote_count
           FROM jobs j
           LEFT JOIN contacts c ON j.contact_id=c.id
           WHERE 1=1"""
    params = []
    if stage and stage != "All":
        q += " AND j.stage=?"
        params.append(stage)
    if contact_id:
        q += " AND j.contact_id=?"
        params.append(contact_id)
    if search:
        q += " AND (j.name LIKE ? OR c.name LIKE ? OR j.opp_number LIKE ?)"
        s = f"%{search}%"
        params += [s, s, s]
    q += " ORDER BY j.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_opportunity(db_path, opp_id):
    conn = get_connection(db_path)
    row = conn.execute("""SELECT j.*, j.name AS title, j.id AS job_id, c.name as contact_name
                          FROM jobs j
                          LEFT JOIN contacts c ON j.contact_id=c.id
                          WHERE j.id=?""", (opp_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_opportunity(db_path, data: dict) -> int:
    """Save a pipeline opportunity (stored as a job row after Phase 5)."""
    conn = get_connection(db_path)
    oid = data.get("id")
    name = data.get("title") or data.get("name", "")

    if oid:
        conn.execute("""UPDATE jobs SET
            name=?, contact_id=?, stage=?, source=?, value=?,
            probability=?, owner=?, start_date=?, target_close=?,
            actual_close=?, description=?, notes=?
            WHERE id=?""",
            (name, data.get("contact_id"), data.get("stage", "Lead"),
             data.get("source"), data.get("value"), data.get("probability", 50),
             data.get("owner"), data.get("start_date"), data.get("target_close"),
             data.get("actual_close"), data.get("description"), data.get("notes"),
             oid))
    else:
        opp_num = data.get("opp_number") or next_opp_number(db_path)
        job_num = data.get("job_number") or opp_num
        conn.execute("""INSERT INTO jobs
            (job_number, opp_number, name, contact_id, stage, source, value,
             probability, owner, start_date, target_close, description, notes, created_by)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (job_num, opp_num, name, data.get("contact_id"),
             data.get("stage", "Lead"), data.get("source"), data.get("value"),
             data.get("probability", 50), data.get("owner"), data.get("start_date"),
             data.get("target_close"), data.get("description"), data.get("notes"),
             data.get("created_by")))
        oid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit()
    conn.close()
    return oid


def delete_opportunity(db_path, opp_id):
    delete_job(db_path, opp_id)


def get_pipeline_summary(db_path):
    """Returns {stage: {count, value}} for dashboard."""
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT stage,
               COUNT(*) as cnt,
               COALESCE(SUM(value),0) as total_value
        FROM jobs
        GROUP BY stage""").fetchall()
    conn.close()
    return {r["stage"]: {"count": r["cnt"], "value": r["total_value"]} for r in rows}


# ── Communications ────────────────────────────────────────────────────────────

def get_communications(db_path, opp_id=None, contact_id=None,
                       invoice_id=None, job_id=None, limit=200):
    conn = get_connection(db_path)
    q = """SELECT cm.*, c.name as contact_name
           FROM crm_communications cm
           LEFT JOIN contacts c ON cm.contact_id=c.id
           WHERE 1=1"""
    params = []
    if opp_id:
        q += " AND cm.opp_id=?"
        params.append(opp_id)
    if job_id:
        q += " AND cm.job_id=?"
        params.append(job_id)
    if contact_id:
        q += " AND cm.contact_id=?"
        params.append(contact_id)
    if invoice_id:
        q += " AND cm.invoice_id=?"
        params.append(invoice_id)
    q += " ORDER BY cm.logged_at DESC, cm.id DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_communication(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    cid = data.get("id")
    if cid:
        conn.execute("""UPDATE crm_communications SET
            opp_id=?, job_id=?, contact_id=?, invoice_id=?, comm_date=?, comm_type=?,
            subject=?, body=?, outcome=?, next_action=?, next_action_date=?
            WHERE id=?""",
            (data.get("opp_id"), data.get("job_id"), data.get("contact_id"),
             data.get("invoice_id"), data["comm_date"], data.get("comm_type", "Note"),
             data.get("subject"), data.get("body"), data.get("outcome"),
             data.get("next_action"), data.get("next_action_date"), cid))
    else:
        conn.execute("""INSERT INTO crm_communications
            (opp_id,job_id,contact_id,invoice_id,comm_date,comm_type,subject,body,
             outcome,next_action,next_action_date,logged_by)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (data.get("opp_id"), data.get("job_id"), data.get("contact_id"),
             data.get("invoice_id"), data["comm_date"], data.get("comm_type", "Note"),
             data.get("subject"), data.get("body"), data.get("outcome"),
             data.get("next_action"), data.get("next_action_date"),
             data.get("logged_by")))
        cid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit()
    conn.close()
    return cid


def log_email_activity(db_path, contact_id, subject, body="", invoice_id=None):
    """Auto-log a sent email to the communications table."""
    from datetime import datetime as _dt
    save_communication(db_path, {
        "contact_id":  contact_id,
        "invoice_id":  invoice_id,
        "comm_date":   _dt.now().strftime("%Y-%m-%d"),
        "comm_type":   "Email",
        "subject":     subject,
        "body":        body,
    })


def delete_communication(db_path, comm_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM crm_communications WHERE id=?", (comm_id,))
    conn.commit()
    conn.close()


# ── Tasks ─────────────────────────────────────────────────────────────────────

def get_tasks(db_path, opp_id=None, job_id=None, contact_id=None, overdue_only=False, open_only=True):
    conn = get_connection(db_path)
    q = """SELECT t.*,
                  j.name as job_name, j.job_number,
                  j.name as opp_title, j.opp_number,
                  c.name as contact_name
           FROM crm_tasks t
           LEFT JOIN jobs j ON t.job_id=j.id
           LEFT JOIN contacts c ON t.contact_id=c.id
           WHERE 1=1"""
    params = []
    if opp_id:
        q += " AND (t.opp_id=? OR t.job_id=?)"
        params += [opp_id, opp_id]
    if job_id:
        q += " AND t.job_id=?"
        params.append(job_id)
    if contact_id:
        q += " AND t.contact_id=?"
        params.append(contact_id)
    if open_only:
        q += " AND t.is_done=0"
    if overdue_only:
        q += " AND t.due_date < date('now')"
    q += " ORDER BY t.due_date, t.priority DESC, t.id"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_contact_crm_tasks(db_path, contact_id):
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT t.*, j.name as job_name, j.job_number
        FROM crm_tasks t
        LEFT JOIN jobs j ON t.job_id=j.id
        WHERE t.contact_id=?
        ORDER BY t.is_done, t.due_date, t.priority DESC, t.id
    """, (contact_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_task(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    tid = data.get("id")

    opp_id = data.get("opp_id")
    job_id = data.get("job_id") or None

    contact_id = data.get("contact_id") or None

    if tid:
        conn.execute("""UPDATE crm_tasks SET
            opp_id=?, task_type=?, title=?, description=?,
            due_date=?, priority=?, assigned_to=?, is_done=?, done_at=?, job_id=?, contact_id=?
            WHERE id=?""",
            (data.get("opp_id"), data.get("task_type", "Follow Up"),
             data["title"], data.get("description"),
             data.get("due_date"), data.get("priority", "Normal"),
             data.get("assigned_to"), int(data.get("is_done", 0)),
             data.get("done_at"), job_id, contact_id, tid))
    else:
        conn.execute("""INSERT INTO crm_tasks
            (opp_id,task_type,title,description,due_date,priority,assigned_to,job_id,contact_id)
            VALUES (?,?,?,?,?,?,?,?,?)""",
            (data.get("opp_id"), data.get("task_type", "Follow Up"),
             data["title"], data.get("description"),
             data.get("due_date"), data.get("priority", "Normal"),
             data.get("assigned_to"), job_id, contact_id))
        tid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit()
    conn.close()
    return tid


def complete_task(db_path, task_id):
    conn = get_connection(db_path)
    conn.execute("""UPDATE crm_tasks SET is_done=1, done_at=datetime('now','localtime')
                    WHERE id=?""", (task_id,))
    conn.commit()
    conn.close()


def delete_task(db_path, task_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM crm_tasks WHERE id=?", (task_id,))
    conn.commit()
    conn.close()


# ── Quotes ────────────────────────────────────────────────────────────────────

def get_quotes(db_path, opp_id=None, job_id=None):
    conn = get_connection(db_path)
    q = """SELECT q.*, c.name as contact_name,
                  j.name as opp_title, j.opp_number
           FROM crm_quotes q
           LEFT JOIN contacts c ON q.contact_id=c.id
           LEFT JOIN jobs j ON q.job_id=j.id
           WHERE 1=1"""
    params = []
    if opp_id:
        q += " AND (q.opp_id=? OR q.job_id=?)"
        params += [opp_id, opp_id]
    if job_id:
        q += " AND q.job_id=?"
        params.append(job_id)
    q += " ORDER BY q.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_quote(db_path, quote_id):
    conn = get_connection(db_path)
    q = conn.execute("""SELECT q.*, c.name as contact_name
                        FROM crm_quotes q
                        LEFT JOIN contacts c ON q.contact_id=c.id
                        WHERE q.id=?""", (quote_id,)).fetchone()
    lines = conn.execute("""SELECT ql.*, a.name as account_name
                            FROM crm_quote_lines ql
                            LEFT JOIN accounts a ON ql.account_id=a.id
                            WHERE ql.quote_id=? ORDER BY ql.sort_order, ql.id""",
                         (quote_id,)).fetchall()
    conn.close()
    if not q:
        return None, []
    return dict(q), [dict(l) for l in lines]


def save_quote(db_path, qdata: dict, lines: list) -> int:
    """Save quote + recalculate totals. Returns quote_id."""
    conn = get_connection(db_path)
    gst_rate = 0.10
    subtotal = gst_total = 0.0
    for l in lines:
        if l.get("line_type") == "comment":
            l["gst_amount"] = 0.0
            l["line_total"] = 0.0
            continue
        ex  = round(float(l.get("quantity", 1)) * float(l.get("unit_price", 0)), 2)
        gst = round(ex * gst_rate, 2) if l.get("tax_code", "GST") == "GST" else 0.0
        l["gst_amount"] = gst
        l["line_total"] = round(ex + gst, 2)
        subtotal += ex
        gst_total += gst
    total = round(subtotal + gst_total, 2)

    qid = qdata.get("id")
    if qid:
        conn.execute("""UPDATE crm_quotes SET
            opp_id=?, job_id=?, contact_id=?, quote_date=?, expiry_date=?,
            status=?, subtotal=?, gst_total=?, total=?,
            intro_text=?, terms_text=?, internal_notes=?,
            accepted_date=?, accepted_by=?
            WHERE id=?""",
            (qdata.get("opp_id"), qdata.get("job_id"), qdata.get("contact_id"),
             qdata["quote_date"], qdata.get("expiry_date"),
             qdata.get("status", "Draft"), subtotal, gst_total, total,
             qdata.get("intro_text"), qdata.get("terms_text"),
             qdata.get("internal_notes"), qdata.get("accepted_date"),
             qdata.get("accepted_by"), qid))
        conn.execute("DELETE FROM crm_quote_lines WHERE quote_id=?", (qid,))
    else:
        conn.execute("""INSERT INTO crm_quotes
            (quote_number,opp_id,job_id,contact_id,quote_date,expiry_date,
             status,subtotal,gst_total,total,intro_text,terms_text,
             internal_notes,created_by)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (qdata.get("quote_number", next_quote_number(db_path)),
             qdata.get("opp_id"), qdata.get("job_id"), qdata.get("contact_id"),
             qdata["quote_date"], qdata.get("expiry_date"),
             qdata.get("status", "Draft"), subtotal, gst_total, total,
             qdata.get("intro_text"), qdata.get("terms_text"),
             qdata.get("internal_notes"), qdata.get("created_by")))
        qid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    for i, l in enumerate(lines):
        conn.execute("""INSERT INTO crm_quote_lines
            (quote_id,sort_order,description,quantity,unit_price,
             tax_code,gst_amount,line_total,account_id,item_id,line_type)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (qid, i, l["description"], l.get("quantity", 1),
             l.get("unit_price", 0), l.get("tax_code", "GST"),
             l["gst_amount"], l["line_total"], l.get("account_id"),
             l.get("item_id"), l.get("line_type", "item")))

    conn.commit()
    conn.close()
    return qid


def accept_quote(db_path, quote_id, accepted_by="") -> int:
    """Mark quote Accepted, set linked job to Accepted stage. Returns job_id."""
    conn = get_connection(db_path)
    conn.execute("""UPDATE crm_quotes SET status='Accepted',
                    accepted_date=date('now'), accepted_by=?
                    WHERE id=?""", (accepted_by, quote_id))
    row = conn.execute(
        "SELECT opp_id, job_id FROM crm_quotes WHERE id=?", (quote_id,)).fetchone()
    job_id = (row["job_id"] or row["opp_id"]) if row else None
    if job_id:
        conn.execute("""UPDATE crm_quotes SET status='Superseded'
                        WHERE (opp_id=? OR job_id=?) AND id!=? AND status='Draft'""",
                     (job_id, job_id, quote_id))
        conn.execute("UPDATE jobs SET stage='Accepted' WHERE id=?", (job_id,))
    conn.commit()
    conn.close()
    return job_id


def convert_quote_to_invoice(db_path, quote_id, created_by=None) -> int:
    """Convert an accepted quote into a formal invoice. Returns invoice_id."""
    from core.ledger import save_invoice
    quote, lines = get_quote(db_path, quote_id)
    if not quote:
        raise ValueError("Quote not found")

    inv_lines = []
    for l in lines:
        inv_lines.append({
            "description": l["description"],
            "quantity":    l["quantity"],
            "unit_price":  l["unit_price"],
            "tax_code":    l["tax_code"],
            "account_id":  l.get("account_id"),
            "item_id":     l.get("item_id"),
            "line_type":   l.get("line_type", "item"),
        })
    inv_data = {
        "contact_id":   quote["contact_id"],
        "invoice_date": str(_date.today()),
        "due_date":     str(_date.today() + _td(days=30)),
        "status":       "Draft",
        "notes":        f"From Quote {quote['quote_number']}",
        "job_id":       quote.get("job_id"),
    }
    inv_id = save_invoice(db_path, inv_data, inv_lines)

    job_id = quote.get("job_id")
    if job_id:
        set_invoice_job(db_path, inv_id, job_id)

    conn = get_connection(db_path)
    conn.execute(
        "UPDATE crm_quotes SET invoice_id=?, status='Invoiced' WHERE id=?",
        (inv_id, quote_id))
    if job_id:
        conn.execute("UPDATE jobs SET stage='Invoiced' WHERE id=?", (job_id,))
    conn.commit()
    conn.close()
    return inv_id


def delete_quote(db_path, quote_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM crm_quotes WHERE id=?", (quote_id,))
    conn.commit()
    conn.close()


# ── Progress Claims ───────────────────────────────────────────────────────────

def get_progress_claims(db_path, opp_id=None, job_id=None):
    conn = get_connection(db_path)
    q = """SELECT pc.*, c.name as contact_name
           FROM crm_progress_claims pc
           LEFT JOIN contacts c ON pc.contact_id=c.id
           WHERE 1=1"""
    params = []
    if opp_id:
        q += " AND pc.opp_id=?"
        params.append(opp_id)
    if job_id:
        q += " AND pc.job_id=?"
        params.append(job_id)
    q += " ORDER BY pc.id"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_progress_claim(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    cid = data.get("id")
    ex  = float(data.get("amount_ex_gst", 0))
    gst = round(ex * 0.10, 2) if data.get("tax_code", "GST") == "GST" else 0.0
    inc = round(ex + gst, 2)

    if cid:
        conn.execute("""UPDATE crm_progress_claims SET
            opp_id=?, job_id=?, contact_id=?, claim_date=?,
            description=?, amount_ex_gst=?, gst_amount=?,
            amount_inc_gst=?, cumulative_pct=?, status=?
            WHERE id=?""",
            (data.get("opp_id"), data.get("job_id"), data.get("contact_id"),
             data["claim_date"], data.get("description"),
             ex, gst, inc, data.get("cumulative_pct", 0),
             data.get("status", "Draft"), cid))
    else:
        conn.execute("""INSERT INTO crm_progress_claims
            (claim_number,opp_id,job_id,contact_id,claim_date,
             description,amount_ex_gst,gst_amount,amount_inc_gst,
             cumulative_pct,status,created_by)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (data.get("claim_number", next_claim_number(db_path)),
             data.get("opp_id"), data.get("job_id"), data.get("contact_id"),
             data["claim_date"], data.get("description"),
             ex, gst, inc, data.get("cumulative_pct", 0),
             data.get("status", "Draft"), data.get("created_by")))
        cid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit()
    conn.close()
    return cid


def claim_to_invoice(db_path, claim_id, created_by=None) -> int:
    """Convert a progress claim to a real invoice. Returns invoice_id."""
    from core.ledger import save_invoice
    conn = get_connection(db_path)
    claim = conn.execute(
        "SELECT * FROM crm_progress_claims WHERE id=?", (claim_id,)).fetchone()
    conn.close()
    if not claim:
        raise ValueError("Claim not found")
    claim = dict(claim)

    inv_lines = [{
        "description": claim["description"] or f"Progress Claim {claim['claim_number']}",
        "quantity":    1,
        "unit_price":  claim["amount_ex_gst"],
        "tax_code":    "GST",
        "account_id":  None,
    }]
    inv_data = {
        "contact_id":   claim["contact_id"],
        "invoice_date": str(_date.today()),
        "due_date":     str(_date.today() + _td(days=14)),
        "status":       "Draft",
        "notes":        f"Progress Claim {claim['claim_number']}",
    }
    inv_id = save_invoice(db_path, inv_data, inv_lines)

    job_id = claim.get("job_id")
    if job_id:
        set_invoice_job(db_path, inv_id, job_id)

    conn = get_connection(db_path)
    conn.execute("""UPDATE crm_progress_claims SET invoice_id=?, status='Invoiced'
                    WHERE id=?""", (inv_id, claim_id))
    conn.commit()
    conn.close()
    return inv_id


def update_claim_status(db_path, claim_id, status):
    conn = get_connection(db_path)
    conn.execute("UPDATE crm_progress_claims SET status=? WHERE id=?", (status, claim_id))
    conn.commit()
    conn.close()


def delete_progress_claim(db_path, claim_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM crm_progress_claims WHERE id=?", (claim_id,))
    conn.commit()
    conn.close()


# ── Dashboard helpers ─────────────────────────────────────────────────────────

def get_crm_dashboard(db_path):
    """Single-query dashboard snapshot."""
    conn = get_connection(db_path)
    pipeline = {r["stage"]: {"count": r["cnt"], "value": r["total_value"]}
                for r in conn.execute("""
                    SELECT stage, COUNT(*) cnt, COALESCE(SUM(value),0) total_value
                    FROM jobs GROUP BY stage""").fetchall()}
    overdue_tasks = conn.execute("""
        SELECT t.*, j.name as opp_title
        FROM crm_tasks t
        LEFT JOIN jobs j ON t.job_id=j.id
        WHERE t.is_done=0 AND t.due_date < date('now')
        ORDER BY t.due_date LIMIT 10""").fetchall()
    recent_comms = conn.execute("""
        SELECT cm.*, c.name as contact_name, j.name as opp_title
        FROM crm_communications cm
        LEFT JOIN contacts c ON cm.contact_id=c.id
        LEFT JOIN jobs j ON cm.job_id=j.id
        ORDER BY cm.comm_date DESC, cm.id DESC LIMIT 10""").fetchall()
    upcoming_tasks = conn.execute("""
        SELECT t.*, j.name as opp_title
        FROM crm_tasks t
        LEFT JOIN jobs j ON t.job_id=j.id
        WHERE t.is_done=0 AND (t.due_date >= date('now') OR t.due_date IS NULL)
        ORDER BY t.due_date LIMIT 10""").fetchall()
    conn.close()
    return {
        "pipeline":       pipeline,
        "overdue_tasks":  [dict(r) for r in overdue_tasks],
        "recent_comms":   [dict(r) for r in recent_comms],
        "upcoming_tasks": [dict(r) for r in upcoming_tasks],
    }


# ── Work Tasks ────────────────────────────────────────────────────────────────

def get_job_work_tasks(db_path, job_id):
    """Return work_tasks linked to a job directly (wt.job_id) or via legacy opp_id."""
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT wt.id, wt.contact_id, wt.title, wt.description,
               wt.qty, wt.unit_price, wt.is_done, wt.done_at,
               wt.invoice_id, wt.job_id, wt.opp_id, wt.created_at,
               c.name as contact_name,
               j.name as job_name, j.job_number,
               j.name as opp_title, j.opp_number
        FROM work_tasks wt
        LEFT JOIN contacts c ON wt.contact_id = c.id
        LEFT JOIN jobs j ON wt.job_id = j.id
        WHERE wt.job_id = ? OR wt.opp_id = ?
        GROUP BY wt.id
        ORDER BY wt.is_done ASC, wt.id DESC
    """, (job_id, job_id)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_work_tasks(db_path, contact_id=None, uninvoiced_only=False):
    conn = get_connection(db_path)
    q = """SELECT wt.*, j.name as job_name, j.job_number,
                  j.name as opp_title, j.opp_number
           FROM work_tasks wt
           LEFT JOIN jobs j ON wt.job_id=j.id
           WHERE 1=1"""
    params = []
    if contact_id:
        q += " AND wt.contact_id=?"
        params.append(contact_id)
    if uninvoiced_only:
        q += " AND wt.is_done=1 AND wt.invoice_id IS NULL"
    q += " ORDER BY wt.is_done ASC, wt.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_work_task(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    tid = data.get("id")

    if tid:
        _existing = conn.execute(
            "SELECT contact_id FROM work_tasks WHERE id=?", (tid,)).fetchone()
        task_contact_id = _existing["contact_id"] if _existing else None
    else:
        task_contact_id = data.get("contact_id")

    job_id = data.get("job_id") or None
    if job_id and task_contact_id:
        job_row = conn.execute(
            "SELECT contact_id FROM jobs WHERE id=?", (job_id,)).fetchone()
        if job_row and job_row["contact_id"] and job_row["contact_id"] != task_contact_id:
            conn.close()
            raise ValueError("Job belongs to a different contact — task not saved")

    opp_id = data.get("opp_id") or None
    if opp_id and task_contact_id:
        opp_row = conn.execute(
            "SELECT contact_id FROM jobs WHERE id=?", (opp_id,)).fetchone()
        if opp_row and opp_row["contact_id"] and opp_row["contact_id"] != task_contact_id:
            conn.close()
            raise ValueError("Opportunity belongs to a different contact — task not saved")

    if tid:
        conn.execute("""UPDATE work_tasks
            SET title=?, description=?, qty=?, unit_price=?, job_id=?, opp_id=?,
                created_at=COALESCE(?,created_at), done_at=?
            WHERE id=?""",
            (data["title"], data.get("description"), data.get("qty", 1),
             data.get("unit_price", 0),
             job_id, data.get("opp_id") or None,
             data.get("created_at") or None,
             data.get("done_at") or None,
             tid))
    else:
        conn.execute("""INSERT INTO work_tasks
            (contact_id, title, description, qty, unit_price, job_id, opp_id, created_at)
            VALUES (?,?,?,?,?,?,?,COALESCE(?,datetime('now','localtime')))""",
            (data["contact_id"], data["title"], data.get("description"),
             data.get("qty", 1), data.get("unit_price", 0),
             job_id, data.get("opp_id") or None,
             data.get("created_at") or None))
        tid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit()
    conn.close()
    return tid


def complete_work_task(db_path, task_id, is_done: bool = True):
    conn = get_connection(db_path)
    if is_done:
        conn.execute(
            "UPDATE work_tasks SET is_done=1, done_at=datetime('now','localtime') WHERE id=?",
            (task_id,))
    else:
        conn.execute(
            "UPDATE work_tasks SET is_done=0, done_at=NULL WHERE id=?",
            (task_id,))
    conn.commit()
    conn.close()


def delete_work_task(db_path, task_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM work_tasks WHERE id=?", (task_id,))
    conn.commit()
    conn.close()


def stamp_task_invoice(db_path, invoice_id: int, task_ids: list):
    """Stamp invoice_id on completed work tasks that have been added to an invoice."""
    if not task_ids:
        return
    conn = get_connection(db_path)
    placeholders = ",".join("?" * len(task_ids))
    conn.execute(
        f"UPDATE work_tasks SET invoice_id=? WHERE id IN ({placeholders}) AND is_done=1",
        [invoice_id] + [int(t) for t in task_ids]
    )
    conn.commit()
    conn.close()


def invoice_work_tasks(db_path, contact_id: int, task_ids: list) -> int:
    """Create a Draft invoice from completed+uninvoiced work tasks, stamp invoice_id."""
    from core.ledger import save_invoice
    from datetime import date

    conn = get_connection(db_path)
    placeholders = ",".join("?" * len(task_ids))
    rows = conn.execute(
        f"SELECT * FROM work_tasks WHERE id IN ({placeholders}) AND contact_id=?"
        " AND is_done=1 AND invoice_id IS NULL",
        task_ids + [contact_id]
    ).fetchall()
    conn.close()

    if not rows:
        raise ValueError("No eligible completed tasks found")

    today = date.today().isoformat()
    inv_data = {
        "contact_id":   contact_id,
        "invoice_date": today,
        "due_date":     today,
        "status":       "Draft",
        "notes":        "",
    }
    lines = [
        {
            "description": r["title"] + (f" — {r['description']}" if r["description"] else ""),
            "quantity":    r["qty"],
            "unit_price":  r["unit_price"],
            "tax_code":    "GST",
            "line_type":   "item",
        }
        for r in rows
    ]
    inv_id = save_invoice(db_path, inv_data, lines)

    conn = get_connection(db_path)
    conn.execute(
        f"UPDATE work_tasks SET invoice_id=? WHERE id IN ({placeholders})",
        [inv_id] + task_ids
    )
    conn.commit()
    conn.close()
    return inv_id
