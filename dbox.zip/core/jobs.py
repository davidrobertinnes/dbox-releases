"""
dbox Jobs / Projects module.

Schema:
  jobs              — project/job records with budget, status, contact
  job_transactions  — links any transaction (invoice/bill/journal/payment) to a job
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from datetime import date as _date
from core.database import get_connection

_TABLE_MAP = {
    "invoice": "invoices",
    "bill":    "bills",
    "payment": "payments",
    "journal": "journal_entries",
}


# ── Schema migration ──────────────────────────────────────────────────────────

def migrate_jobs(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS jobs (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        job_number      TEXT NOT NULL UNIQUE,
        name            TEXT NOT NULL,
        description     TEXT,
        contact_id      INTEGER REFERENCES contacts(id),
        status          TEXT NOT NULL DEFAULT 'Active',
        start_date      TEXT,
        end_date        TEXT,
        budget_amount   REAL,
        budget_notes    TEXT,
        manager         TEXT,
        created_by      INTEGER,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS job_transactions (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id          INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
        source_type     TEXT NOT NULL,
        source_id       INTEGER NOT NULL,
        amount          REAL NOT NULL DEFAULT 0,
        notes           TEXT,
        allocated_at    TEXT DEFAULT (datetime('now','localtime')),
        allocated_by    INTEGER,
        UNIQUE(job_id, source_type, source_id))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS job_employee_time (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id      INTEGER NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
        employee_id INTEGER NOT NULL REFERENCES employees(id),
        entry_date  TEXT NOT NULL,
        hours       REAL NOT NULL DEFAULT 0,
        hourly_rate REAL NOT NULL DEFAULT 0,
        description TEXT,
        created_at  TEXT DEFAULT (datetime('now','localtime')))""")

    for table in ('invoices', 'bills', 'payments', 'journal_entries'):
        try:
            conn.execute(
                f"ALTER TABLE {table} ADD COLUMN job_id INTEGER REFERENCES jobs(id)")
        except Exception:
            pass


# ── Job CRUD ──────────────────────────────────────────────────────────────────

def next_job_number(db_path) -> str:
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT job_number FROM jobs ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    prefix = f"JOB-{_date.today().year}-"
    if row and row[0].startswith(prefix):
        try:
            seq = int(row[0][len(prefix):]) + 1
        except ValueError:
            seq = 1
    else:
        seq = 1
    return f"{prefix}{seq:04d}"


def get_jobs(db_path, status=None):
    conn = get_connection(db_path)
    migrate_jobs(conn)   # ensure tables exist — idempotent
    conn.commit()
    q = """SELECT j.*, c.name as contact_name,
        (SELECT COUNT(*) FROM job_transactions jt WHERE jt.job_id=j.id) as txn_count
        FROM jobs j LEFT JOIN contacts c ON j.contact_id=c.id WHERE 1=1"""
    params = []
    if status:
        q += " AND j.status=?"
        params.append(status)
    q += " ORDER BY j.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_job(db_path, job_id):
    conn = get_connection(db_path)
    row = conn.execute("""SELECT j.*, c.name as contact_name
        FROM jobs j LEFT JOIN contacts c ON j.contact_id=c.id
        WHERE j.id=?""", (job_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_job(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    jid = data.get("id")
    fields = ["job_number","name","description","contact_id","status",
              "start_date","end_date","budget_amount","budget_notes",
              "manager","created_by"]
    vals = [data.get(f) for f in fields]
    if jid:
        sets = ", ".join(f"{f}=?" for f in fields)
        conn.execute(f"UPDATE jobs SET {sets} WHERE id=?", vals + [jid])
    else:
        cols = ", ".join(fields)
        ph   = ", ".join("?" for _ in fields)
        conn.execute(f"INSERT INTO jobs ({cols}) VALUES ({ph})", vals)
        jid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit(); conn.close()
    return jid


def delete_job(db_path, job_id):
    conn = get_connection(db_path)
    try:
        # NULL out the denormalised job_id FK on transaction tables first.
        # These columns have no ON DELETE clause so SQLite raises
        # FOREIGN KEY constraint failed if any row still references the job.
        for table in ('invoices', 'bills', 'payments', 'journal_entries'):
            conn.execute(
                f"UPDATE {table} SET job_id=NULL WHERE job_id=?", (job_id,))
        conn.execute("DELETE FROM job_transactions  WHERE job_id=?", (job_id,))
        conn.execute("DELETE FROM job_employee_time WHERE job_id=?", (job_id,))
        conn.execute("DELETE FROM jobs WHERE id=?", (job_id,))
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ── Transaction Allocation ────────────────────────────────────────────────────

def allocate_transaction(db_path, job_id, source_type, source_id,
                          amount=0.0, notes="", allocated_by=None):
    conn = get_connection(db_path)
    conn.execute("""INSERT OR REPLACE INTO job_transactions
        (job_id, source_type, source_id, amount, notes, allocated_by)
        VALUES (?,?,?,?,?,?)""",
        (job_id, source_type, source_id, float(amount or 0), notes or "", allocated_by))
    if source_type in _TABLE_MAP:
        try:
            conn.execute(
                f"UPDATE {_TABLE_MAP[source_type]} SET job_id=? WHERE id=?",
                (job_id, source_id))
        except Exception:
            pass
    conn.commit(); conn.close()


def deallocate_transaction(db_path, job_id, source_type, source_id):
    conn = get_connection(db_path)
    conn.execute("""DELETE FROM job_transactions
        WHERE job_id=? AND source_type=? AND source_id=?""",
        (job_id, source_type, source_id))
    if source_type in _TABLE_MAP:
        try:
            conn.execute(
                f"UPDATE {_TABLE_MAP[source_type]} SET job_id=NULL WHERE id=?",
                (source_id,))
        except Exception:
            pass
    conn.commit(); conn.close()


def get_job_transactions(db_path, job_id):
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT jt.*,
        CASE jt.source_type
            WHEN 'invoice' THEN (SELECT invoice_number FROM invoices WHERE id=jt.source_id)
            WHEN 'bill'    THEN (SELECT bill_number    FROM bills    WHERE id=jt.source_id)
            WHEN 'payment' THEN (SELECT reference      FROM payments WHERE id=jt.source_id)
            WHEN 'journal' THEN (SELECT reference      FROM journal_entries WHERE id=jt.source_id)
        END as ref_number,
        CASE jt.source_type
            WHEN 'invoice' THEN (SELECT invoice_date FROM invoices WHERE id=jt.source_id)
            WHEN 'bill'    THEN (SELECT bill_date    FROM bills    WHERE id=jt.source_id)
            WHEN 'payment' THEN (SELECT payment_date FROM payments WHERE id=jt.source_id)
            WHEN 'journal' THEN (SELECT entry_date   FROM journal_entries WHERE id=jt.source_id)
        END as txn_date,
        CASE jt.source_type
            WHEN 'invoice' THEN (SELECT c.name FROM invoices i
                                 JOIN contacts c ON i.contact_id=c.id WHERE i.id=jt.source_id)
            WHEN 'bill'    THEN (SELECT c.name FROM bills b
                                 JOIN contacts c ON b.contact_id=c.id WHERE b.id=jt.source_id)
            WHEN 'payment' THEN (SELECT c.name FROM payments p
                                 JOIN contacts c ON p.contact_id=c.id WHERE p.id=jt.source_id)
            ELSE NULL
        END as contact_name
        FROM job_transactions jt
        WHERE jt.job_id=?
        ORDER BY txn_date, jt.id""", (job_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ── Job P&L ───────────────────────────────────────────────────────────────────

def get_job_pl(db_path, job_id):
    conn = get_connection(db_path)
    rev = conn.execute("""SELECT COALESCE(SUM(i.subtotal),0) as total
        FROM job_transactions jt JOIN invoices i ON jt.source_id=i.id
        WHERE jt.job_id=? AND jt.source_type='invoice'
          AND i.status NOT IN ('Void','Voided')""",
        (job_id,)).fetchone()["total"]
    costs = conn.execute("""SELECT COALESCE(SUM(b.subtotal),0) as total
        FROM job_transactions jt JOIN bills b ON jt.source_id=b.id
        WHERE jt.job_id=? AND jt.source_type='bill'
          AND b.status NOT IN ('Void','Voided')""",
        (job_id,)).fetchone()["total"]
    jnl_costs = conn.execute("""SELECT COALESCE(SUM(jl.debit - jl.credit),0) as total
        FROM job_transactions jt
        JOIN journal_entries je ON jt.source_id=je.id
        JOIN journal_lines jl ON jl.journal_id=je.id
        JOIN accounts a ON jl.account_id=a.id
        WHERE jt.job_id=? AND jt.source_type='journal'
          AND a.account_type IN ('Expense','Cost of Sales')""",
        (job_id,)).fetchone()["total"]
    total_costs  = costs + jnl_costs
    gross_profit = rev - total_costs
    job    = conn.execute("SELECT budget_amount FROM jobs WHERE id=?",
                          (job_id,)).fetchone()
    budget = (job["budget_amount"] or 0) if job else 0
    conn.close()
    return {
        "revenue":         rev,
        "bill_costs":      costs,
        "journal_costs":   jnl_costs,
        "total_costs":     total_costs,
        "gross_profit":    gross_profit,
        "margin_pct":      (gross_profit / rev * 100) if rev else 0,
        "budget":          budget,
        "budget_variance": gross_profit - budget,
    }


# ── Transaction pickers ───────────────────────────────────────────────────────

def get_unallocated_invoices(db_path):
    """Return invoices not yet linked to any job."""
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT i.id, i.invoice_number, i.invoice_date,
        c.name as contact_name, i.total, i.status
        FROM invoices i LEFT JOIN contacts c ON i.contact_id=c.id
        WHERE i.status NOT IN ('Void','Voided')
          AND i.id NOT IN (
              SELECT source_id FROM job_transactions WHERE source_type='invoice')
        ORDER BY i.invoice_date DESC""").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_unallocated_bills(db_path):
    """Return bills not yet linked to any job."""
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT b.id, b.bill_number, b.bill_date,
        c.name as contact_name, b.total, b.status
        FROM bills b LEFT JOIN contacts c ON b.contact_id=c.id
        WHERE b.status NOT IN ('Void','Voided')
          AND b.id NOT IN (
              SELECT source_id FROM job_transactions WHERE source_type='bill')
        ORDER BY b.bill_date DESC""").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_unallocated_payments(db_path):
    """Return payments not yet linked to any job."""
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT p.id, p.reference, p.payment_date,
        c.name as contact_name, p.amount, p.payment_type
        FROM payments p LEFT JOIN contacts c ON p.contact_id=c.id
        WHERE p.id NOT IN (
            SELECT source_id FROM job_transactions WHERE source_type='payment')
        ORDER BY p.payment_date DESC""").fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ── Job assignment helpers (invoice/bill forms) ───────────────────────────────

def get_job_for_invoice(db_path, invoice_id):
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT job_id FROM invoices WHERE id=?",
                           (invoice_id,)).fetchone()
        conn.close()
        return row["job_id"] if row else None
    except Exception:
        conn.close()
        return None


def get_job_for_bill(db_path, bill_id):
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT job_id FROM bills WHERE id=?",
                           (bill_id,)).fetchone()
        conn.close()
        return row["job_id"] if row else None
    except Exception:
        conn.close()
        return None


def set_invoice_job(db_path, invoice_id, job_id):
    """Assign or clear a job on an invoice, syncing job_transactions."""
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT total, job_id FROM invoices WHERE id=?",
                           (invoice_id,)).fetchone()
        old_jid = row["job_id"] if row else None
        amount  = float(row["total"] or 0) if row else 0.0
        conn.execute("UPDATE invoices SET job_id=? WHERE id=?", (job_id, invoice_id))
        conn.commit()
    except Exception:
        conn.close()
        return
    conn.close()
    if old_jid and old_jid != job_id:
        try:
            deallocate_transaction(db_path, old_jid, "invoice", invoice_id)
        except Exception:
            pass
    if job_id:
        allocate_transaction(db_path, job_id, "invoice", invoice_id, amount)


def set_bill_job(db_path, bill_id, job_id):
    """Assign or clear a job on a bill, syncing job_transactions."""
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT total, job_id FROM bills WHERE id=?",
                           (bill_id,)).fetchone()
        old_jid = row["job_id"] if row else None
        amount  = float(row["total"] or 0) if row else 0.0
        conn.execute("UPDATE bills SET job_id=? WHERE id=?", (job_id, bill_id))
        conn.commit()
    except Exception:
        conn.close()
        return
    conn.close()
    if old_jid and old_jid != job_id:
        try:
            deallocate_transaction(db_path, old_jid, "bill", bill_id)
        except Exception:
            pass
    if job_id:
        allocate_transaction(db_path, job_id, "bill", bill_id, amount)


def set_payment_job(db_path, payment_id, job_id):
    """Assign or clear a job on a payment, syncing job_transactions."""
    conn = get_connection(db_path)
    try:
        row = conn.execute("SELECT amount FROM payments WHERE id=?",
                           (payment_id,)).fetchone()
        amount = float(row["amount"] or 0) if row else 0.0
        # Get old job via job_transactions
        old_jt = conn.execute(
            "SELECT job_id FROM job_transactions WHERE source_type='payment' AND source_id=?",
            (payment_id,)).fetchone()
        old_jid = old_jt["job_id"] if old_jt else None
        # Store job_id on payment row
        conn.execute("UPDATE payments SET job_id=? WHERE id=?", (job_id, payment_id))
        conn.commit()
    except Exception:
        conn.close()
        return
    conn.close()
    if old_jid and old_jid != job_id:
        try:
            deallocate_transaction(db_path, old_jid, "payment", payment_id)
        except Exception:
            pass
    if job_id:
        allocate_transaction(db_path, job_id, "payment", payment_id, amount)


# ── Job employee time entries ─────────────────────────────────────────────────

def get_job_time_entries(db_path, job_id):
    """Return all time entries for a job with employee names."""
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT jt.*, e.first_name, e.last_name, e.employee_number,
               (jt.hours * jt.hourly_rate) AS line_cost
        FROM job_employee_time jt
        JOIN employees e ON jt.employee_id = e.id
        WHERE jt.job_id = ?
        ORDER BY jt.entry_date, e.last_name""", (job_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_job_time_entry(db_path, data):
    """Insert or update a time entry. Returns the row id."""
    conn = get_connection(db_path)
    eid = data.get("id")
    if eid:
        conn.execute("""UPDATE job_employee_time
            SET job_id=?, employee_id=?, entry_date=?, hours=?,
                hourly_rate=?, description=?
            WHERE id=?""",
            (data["job_id"], data["employee_id"], data["entry_date"],
             data["hours"], data["hourly_rate"],
             data.get("description",""), eid))
    else:
        cur = conn.execute("""INSERT INTO job_employee_time
            (job_id, employee_id, entry_date, hours, hourly_rate, description)
            VALUES (?,?,?,?,?,?)""",
            (data["job_id"], data["employee_id"], data["entry_date"],
             data["hours"], data["hourly_rate"], data.get("description","")))
        eid = cur.lastrowid
    conn.commit()
    conn.close()
    return eid


def delete_job_time_entry(db_path, entry_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM job_employee_time WHERE id=?", (entry_id,))
    conn.commit()
    conn.close()


def get_job_employee_profitability(db_path, job_id):
    """
    Return per-employee summary for a job:
    { employee_id, name, total_hours, total_cost, revenue_share }
    Revenue is apportioned by hours fraction.
    """
    conn = get_connection(db_path)
    time_rows = conn.execute("""
        SELECT jt.employee_id,
               e.first_name || ' ' || e.last_name AS emp_name,
               e.employee_number,
               SUM(jt.hours)                       AS total_hours,
               SUM(jt.hours * jt.hourly_rate)      AS total_cost
        FROM job_employee_time jt
        JOIN employees e ON jt.employee_id = e.id
        WHERE jt.job_id = ?
        GROUP BY jt.employee_id
        ORDER BY emp_name""", (job_id,)).fetchall()

    # Get total job revenue from invoices
    rev_row = conn.execute("""
        SELECT COALESCE(SUM(i.total), 0) AS revenue
        FROM invoices i
        WHERE i.job_id = ? AND i.status NOT IN ('Void','Draft')
        """, (job_id,)).fetchone()
    conn.close()

    total_revenue = rev_row["revenue"] if rev_row else 0
    all_hours = sum(r["total_hours"] for r in time_rows) or 1

    result = []
    for r in time_rows:
        hours_frac = r["total_hours"] / all_hours
        rev_share  = total_revenue * hours_frac
        profit     = rev_share - r["total_cost"]
        margin     = (profit / rev_share * 100) if rev_share else 0
        result.append({
            "employee_id":  r["employee_id"],
            "name":         r["emp_name"],
            "employee_number": r["employee_number"],
            "total_hours":  r["total_hours"],
            "total_cost":   r["total_cost"],
            "revenue_share": rev_share,
            "profit":        profit,
            "margin_pct":    margin,
        })
    return result


def get_all_jobs_employee_profitability(db_path):
    """
    Cross-job summary: for every employee who has logged time,
    return their totals across ALL jobs.
    Returns list of dicts:
      { employee_id, name, employee_number, job_count,
        total_hours, total_cost, total_revenue, profit, margin_pct,
        jobs: [{job_id, job_number, name, hours, cost, revenue_share}] }
    """
    conn = get_connection(db_path)

    # Per-employee per-job hours and cost
    rows = conn.execute("""
        SELECT  jt.employee_id,
                e.first_name || ' ' || e.last_name AS emp_name,
                e.employee_number,
                jt.job_id,
                j.job_number,
                j.name                             AS job_name,
                SUM(jt.hours)                      AS hours,
                SUM(jt.hours * jt.hourly_rate)     AS cost
        FROM    job_employee_time jt
        JOIN    employees e ON jt.employee_id = e.id
        JOIN    jobs      j ON jt.job_id      = j.id
        GROUP BY jt.employee_id, jt.job_id
        ORDER BY emp_name, j.job_number
    """).fetchall()

    # Revenue per job (from non-void invoices with job_id set)
    rev_rows = conn.execute("""
        SELECT  jt2.job_id,
                COALESCE(SUM(i.total), 0) AS revenue
        FROM    (SELECT DISTINCT job_id FROM job_employee_time) jt2
        LEFT JOIN invoices i
               ON i.job_id = jt2.job_id
              AND i.status NOT IN ('Void','Draft')
        GROUP BY jt2.job_id
    """).fetchall()
    job_revenue = {r["job_id"]: r["revenue"] for r in rev_rows}

    # Total hours per job (for revenue apportionment)
    totalhrs_rows = conn.execute("""
        SELECT job_id, SUM(hours) AS total_hours
        FROM   job_employee_time
        GROUP BY job_id
    """).fetchall()
    job_total_hrs = {r["job_id"]: r["total_hours"] or 1 for r in totalhrs_rows}

    conn.close()

    # Aggregate by employee
    emp_map = {}
    for r in rows:
        eid = r["employee_id"]
        if eid not in emp_map:
            emp_map[eid] = {
                "employee_id":     eid,
                "name":            r["emp_name"],
                "employee_number": r["employee_number"],
                "job_count":       0,
                "total_hours":     0.0,
                "total_cost":      0.0,
                "total_revenue":   0.0,
                "jobs":            [],
            }
        rev = job_revenue.get(r["job_id"], 0)
        hrs_frac = r["hours"] / job_total_hrs[r["job_id"]]
        rev_share = rev * hrs_frac

        emp_map[eid]["total_hours"]   += r["hours"]
        emp_map[eid]["total_cost"]    += r["cost"]
        emp_map[eid]["total_revenue"] += rev_share
        emp_map[eid]["job_count"]     += 1
        emp_map[eid]["jobs"].append({
            "job_id":      r["job_id"],
            "job_number":  r["job_number"],
            "name":        r["job_name"],
            "hours":       r["hours"],
            "cost":        r["cost"],
            "revenue_share": rev_share,
        })

    result = []
    for e in emp_map.values():
        profit = e["total_revenue"] - e["total_cost"]
        margin = (profit / e["total_revenue"] * 100) if e["total_revenue"] else 0
        e["profit"]     = profit
        e["margin_pct"] = margin
        result.append(e)

    result.sort(key=lambda x: -x["total_hours"])
    return result
