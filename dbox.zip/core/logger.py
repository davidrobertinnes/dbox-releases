# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
core/logger.py — dbox application logging.

Sets up a rotating log file (dbox_error.log) in the app directory.
Captures:
  - Unhandled exceptions via sys.excepthook
  - Tkinter callback exceptions via Tk.report_callback_exception
  - Any code that calls log_error() or log_warning() directly

The log file is included automatically in bug reports via
Help → Report an Issue.

This module has no dependencies on the rest of the dbox codebase.
Call setup_logging() once from main.py before anything else.
"""


import logging
import os
import sys
import traceback
import platform
from logging.handlers import RotatingFileHandler
from datetime import datetime


# ── Constants ─────────────────────────────────────────────────────────────────
LOG_FILENAME   = "dbox_error.log"
MAX_BYTES      = 512 * 1024   # 512 KB per file
BACKUP_COUNT   = 3            # keep 3 rotated files (dbox_error.log.1 etc)
TAIL_LINES     = 30           # lines included in bug report email
LOG_FORMAT     = "%(asctime)s [%(levelname)-8s] %(name)s: %(message)s"
DATE_FORMAT    = "%Y-%m-%d %H:%M:%S"

# Module-level logger — other modules can do:
#   from core.logger import get_logger
#   log = get_logger(__name__)
_root_logger: logging.Logger | None = None
_log_path:    str | None = None


def _find_log_dir(app_entry: str | None = None) -> str:
    """
    Return the directory where dbox_error.log should be written.

    Priority:
      1. Same directory as the running executable (PyInstaller frozen build)
      2. Same directory as main.py / dbox.pyw (source run)
      3. User home directory as fallback (e.g. if app dir is read-only)
    """
    if getattr(sys, "frozen", False):
        # PyInstaller one-file: beside the .exe
        return os.path.dirname(os.path.abspath(sys.executable))

    if app_entry:
        d = os.path.dirname(os.path.abspath(app_entry))
        if os.access(d, os.W_OK):
            return d

    # Source run: parent of core/ (project root)
    this_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.normpath(os.path.join(this_dir, ".."))
    if os.access(project_root, os.W_OK):
        return project_root

    return os.path.expanduser("~")


def setup_logging(app_entry: str | None = None,
                  app_version: str = "unknown") -> str:
    """
    Initialise logging. Call once from main.py before creating dboxApp.

    app_entry:   path to the app entry point (main.py / dbox.pyw),
                 used to locate the log directory.
    app_version: APP_VERSION string, written to log on startup.

    Returns the full path to the log file.
    """
    global _root_logger, _log_path

    log_dir  = _find_log_dir(app_entry)
    _log_path = os.path.join(log_dir, LOG_FILENAME)

    # Root logger
    logger = logging.getLogger("Dogbox Accounting")
    logger.setLevel(logging.DEBUG)

    # Avoid duplicate handlers if called more than once
    if logger.handlers:
        _root_logger = logger
        return _log_path

    # Rotating file handler
    try:
        fh = RotatingFileHandler(
            _log_path,
            maxBytes=MAX_BYTES,
            backupCount=BACKUP_COUNT,
            encoding="utf-8",
        )
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT))
        logger.addHandler(fh)
    except Exception as e:
        # Can't write log file — silently continue, don't crash startup
        print(f"[Dogbox Accounting] Warning: could not create log file at {_log_path}: {e}",
              file=sys.stderr)

    # Also log WARNING+ to stderr so dev runs still show errors in console
    ch = logging.StreamHandler(sys.stderr)
    ch.setLevel(logging.WARNING)
    ch.setFormatter(logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT))
    logger.addHandler(ch)

    _root_logger = logger

    # Write startup banner
    logger.info("=" * 60)
    logger.info(f"dbox {app_version} — starting")
    logger.info(f"Python {sys.version.split()[0]}  |  {platform.system()} "
                f"{platform.release()}  |  {platform.machine()}")
    logger.info(f"Log file: {_log_path}")
    logger.info("=" * 60)

    # ── Global exception hooks ────────────────────────────────────────────────

    def _handle_exception(exc_type, exc_value, exc_tb):
        """Catch unhandled exceptions that escape all try/except blocks."""
        if issubclass(exc_type, KeyboardInterrupt):
            # Don't log Ctrl+C
            sys.__excepthook__(exc_type, exc_value, exc_tb)
            return
        logger.critical(
            "Unhandled exception",
            exc_info=(exc_type, exc_value, exc_tb)
        )

    sys.excepthook = _handle_exception

    return _log_path


def setup_tk_exception_handler(tk_root):
    """
    Wire the Tkinter callback exception handler to the log.
    Call after dboxApp.__init__ completes, passing the app instance.

    Tkinter swallows callback exceptions by default — this ensures they
    appear in the log rather than only on stderr.
    """
    logger = logging.getLogger("Dogbox Accounting")

    def _tk_exception(exc, val, tb):
        logger.error(
            "Tkinter callback exception",
            exc_info=(exc, val, tb)
        )

    tk_root.report_callback_exception = _tk_exception


def get_logger(name: str = "Dogbox Accounting") -> logging.Logger:
    """Return a named child logger. Usage: log = get_logger(__name__)"""
    return logging.getLogger(f"dbox.{name}" if not name.startswith("Dogbox Accounting") else name)


def log_error(msg: str, exc: Exception | None = None):
    """
    Log an error from anywhere in the codebase.
    Captures the full traceback when called from within an except block,
    or when an exception object is passed directly.
    This ensures handled exceptions (caught and shown as messageboxes) are
    still recorded in dbox_error.log for bug reporting.

    Falls back to writing directly to the log file if the logger has no
    handlers (e.g. called before setup_logging in an edge case).
    """
    import sys, traceback as _tb_mod

    # Build the message with traceback
    if exc is not None:
        exc_info = sys.exc_info()
        if exc_info[1] is exc:
            tb_str = _tb_mod.format_exc()
        else:
            tb_str = "".join(_tb_mod.format_exception(
                type(exc), exc, exc.__traceback__))
        full_msg = f"{msg}\n{tb_str}"
    else:
        exc_info = sys.exc_info()
        if exc_info[0] is not None:
            full_msg = f"{msg}\n{_tb_mod.format_exc()}"
        else:
            full_msg = msg

    logger = logging.getLogger("Dogbox Accounting")

    if logger.handlers:
        # Normal path — logger is initialised
        logger.error(full_msg)
    else:
        # Fallback: write directly to log file if path is known
        if _log_path:
            try:
                import datetime
                ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                with open(_log_path, "a", encoding="utf-8") as f:
                    f.write(f"{ts} [ERROR   ] dbox: {full_msg}\n")
            except Exception:
                pass
        # Also print to stderr so it's visible in console runs
        print(f"[dbox ERROR] {full_msg}", file=sys.stderr)


def log_warning(msg: str):
    """Convenience: log a warning."""
    logging.getLogger("Dogbox Accounting").warning(msg)


def get_log_path() -> str | None:
    """Return the current log file path, or None if logging not set up."""
    return _log_path


def get_log_tail(n: int = TAIL_LINES) -> str:
    """
    Return the last n lines of the current log file as a single string.
    Used by Help → Report an Issue to pre-fill the email body.
    Returns empty string if the log file cannot be read.
    """
    if not _log_path or not os.path.exists(_log_path):
        return ""
    try:
        with open(_log_path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        tail = lines[-n:] if len(lines) > n else lines
        return "".join(tail)
    except Exception:
        return ""


def get_log_size_kb() -> int:
    """Return current log file size in KB, or 0 if not found."""
    if not _log_path or not os.path.exists(_log_path):
        return 0
    try:
        return os.path.getsize(_log_path) // 1024
    except Exception:
        return 0
