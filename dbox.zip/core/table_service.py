# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from datetime import datetime as _dt
from core.database import get_connection

# ESC/POS constants (local copies to avoid circular import with core/pos.py)
_ESC = b'\x1b'
_GS  = b'\x1d'
_LF  = b'\x0a'

def _ep(cmd: bytes) -> bytes:
    return _ESC + cmd


# ── Migration ──────────────────────────────────────────────────────────────────

def migrate_table_service(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ts_zones (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            name       TEXT NOT NULL,
            sort_order INTEGER NOT NULL DEFAULT 0
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ts_tables (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            zone_id    INTEGER REFERENCES ts_zones(id) ON DELETE SET NULL,
            name       TEXT NOT NULL,
            seats      INTEGER NOT NULL DEFAULT 4,
            sort_order INTEGER NOT NULL DEFAULT 0,
            is_active  INTEGER NOT NULL DEFAULT 1
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_ts_tables_zone ON ts_tables(zone_id)")

    # ts_tabs — recreate without CHECK constraint if 'Sent' status is not yet allowed
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ts_tabs (
            id                INTEGER PRIMARY KEY AUTOINCREMENT,
            table_id          INTEGER NOT NULL REFERENCES ts_tables(id),
            session_id        INTEGER REFERENCES pos_sessions(id),
            contact_id        INTEGER REFERENCES contacts(id),
            opened_at         TEXT NOT NULL DEFAULT (datetime('now','localtime')),
            opened_by_user_id INTEGER,
            opened_by_name    TEXT,
            status            TEXT NOT NULL DEFAULT 'Open',
            notes             TEXT
        )
    """)
    # Expand status set on DBs that still have the old CHECK('Open','Settled','Voided')
    try:
        conn.execute("SAVEPOINT _ts_sent_test")
        conn.execute("INSERT INTO ts_tabs (table_id, status) VALUES (-1, 'Sent')")
        conn.execute("ROLLBACK TO SAVEPOINT _ts_sent_test")
        conn.execute("RELEASE SAVEPOINT _ts_sent_test")
    except Exception:
        conn.execute("ROLLBACK TO SAVEPOINT _ts_sent_test")
        conn.execute("RELEASE SAVEPOINT _ts_sent_test")
        # Recreate without the restrictive CHECK
        conn.execute("""CREATE TABLE ts_tabs_v2 (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            table_id INTEGER NOT NULL,
            session_id INTEGER,
            contact_id INTEGER,
            opened_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
            opened_by_user_id INTEGER,
            opened_by_name TEXT,
            status TEXT NOT NULL DEFAULT 'Open',
            notes TEXT
        )""")
        conn.execute("INSERT INTO ts_tabs_v2 SELECT * FROM ts_tabs")
        conn.execute("DROP TABLE ts_tabs")
        conn.execute("ALTER TABLE ts_tabs_v2 RENAME TO ts_tabs")

    conn.execute("CREATE INDEX IF NOT EXISTS idx_ts_tabs_table   ON ts_tabs(table_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_ts_tabs_session ON ts_tabs(session_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_ts_tabs_status  ON ts_tabs(status)")

    conn.execute("""
        CREATE TABLE IF NOT EXISTS ts_tab_items (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            tab_id          INTEGER NOT NULL REFERENCES ts_tabs(id) ON DELETE CASCADE,
            item_id         INTEGER REFERENCES items(id),
            description     TEXT NOT NULL,
            qty             REAL NOT NULL DEFAULT 1,
            unit_price      REAL NOT NULL DEFAULT 0,
            tax_code        TEXT NOT NULL DEFAULT 'GST',
            account_id      INTEGER REFERENCES accounts(id),
            note            TEXT,
            added_at        TEXT NOT NULL DEFAULT (datetime('now','localtime')),
            sent_to_kitchen INTEGER NOT NULL DEFAULT 0
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_ts_tab_items_tab ON ts_tab_items(tab_id)")

    # DB-backed parked carts (shared between POS and Table Service)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS pos_parked_carts (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER REFERENCES pos_sessions(id),
            label      TEXT NOT NULL DEFAULT '',
            cart_json  TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_pos_parked_session ON pos_parked_carts(session_id)")

    # Modifier group infrastructure (schema only — UI to come)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS item_modifier_groups (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            name       TEXT NOT NULL,
            required   INTEGER NOT NULL DEFAULT 0,
            min_select INTEGER NOT NULL DEFAULT 0,
            max_select INTEGER NOT NULL DEFAULT 1,
            sort_order INTEGER NOT NULL DEFAULT 0
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS item_modifier_options (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            group_id   INTEGER NOT NULL REFERENCES item_modifier_groups(id) ON DELETE CASCADE,
            name       TEXT NOT NULL,
            price_adj  REAL NOT NULL DEFAULT 0,
            sort_order INTEGER NOT NULL DEFAULT 0,
            is_active  INTEGER NOT NULL DEFAULT 1
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS item_modifier_group_links (
            item_id  INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
            group_id INTEGER NOT NULL REFERENCES item_modifier_groups(id) ON DELETE CASCADE,
            PRIMARY KEY (item_id, group_id)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ts_tab_item_modifiers (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            tab_item_id INTEGER NOT NULL REFERENCES ts_tab_items(id) ON DELETE CASCADE,
            option_id   INTEGER REFERENCES item_modifier_options(id),
            name        TEXT NOT NULL,
            price_adj   REAL NOT NULL DEFAULT 0
        )
    """)
    # Takeaway support — add columns if not present
    try:
        conn.execute("ALTER TABLE ts_tabs ADD COLUMN label TEXT")
    except Exception:
        pass
    try:
        conn.execute("ALTER TABLE ts_tables ADD COLUMN is_takeaway INTEGER NOT NULL DEFAULT 0")
    except Exception:
        pass

    conn.commit()


# ── Zones ─────────────────────────────────────────────────────────────────────

def get_zones(db_path) -> list:
    conn = get_connection(db_path)
    rows = conn.execute("SELECT id, name, sort_order FROM ts_zones ORDER BY sort_order, name").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_zone(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    zone_id = data.get("id")
    name = data["name"].strip()
    sort_order = int(data.get("sort_order") or 0)
    if zone_id:
        conn.execute("UPDATE ts_zones SET name=?, sort_order=? WHERE id=?", (name, sort_order, zone_id))
    else:
        cur = conn.execute("INSERT INTO ts_zones (name, sort_order) VALUES (?,?)", (name, sort_order))
        zone_id = cur.lastrowid
    conn.commit()
    conn.close()
    return zone_id


def delete_zone(db_path, zone_id: int):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM ts_zones WHERE id=?", (zone_id,))
    conn.commit()
    conn.close()


# ── Tables ────────────────────────────────────────────────────────────────────

def get_tables(db_path, active_only: bool = True) -> list:
    conn = get_connection(db_path)
    where = "WHERE t.is_active=1" if active_only else ""
    takeaway_clause = "AND t.is_takeaway=0" if active_only else ""
    rows = conn.execute(f"""
        SELECT t.id, t.zone_id, z.name AS zone_name, t.name, t.seats,
               t.sort_order, t.is_active, t.is_takeaway,
               (SELECT id     FROM ts_tabs WHERE table_id=t.id AND status IN ('Open','Sent') LIMIT 1) AS open_tab_id,
               (SELECT status FROM ts_tabs WHERE table_id=t.id AND status IN ('Open','Sent') LIMIT 1) AS open_tab_status,
               (SELECT opened_at FROM ts_tabs WHERE table_id=t.id AND status IN ('Open','Sent') LIMIT 1) AS tab_opened_at
        FROM ts_tables t
        LEFT JOIN ts_zones z ON z.id = t.zone_id
        {where} {takeaway_clause}
        ORDER BY z.sort_order NULLS LAST, z.name NULLS LAST, t.sort_order, t.name
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_table(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    table_id   = data.get("id")
    zone_id    = data.get("zone_id") or None
    name       = data["name"].strip()
    seats      = int(data.get("seats") or 4)
    sort_order = int(data.get("sort_order") or 0)
    is_active  = int(data.get("is_active", 1))
    is_takeaway = int(data.get("is_takeaway", 0))
    if table_id:
        conn.execute(
            "UPDATE ts_tables SET zone_id=?, name=?, seats=?, sort_order=?, is_active=?, is_takeaway=? WHERE id=?",
            (zone_id, name, seats, sort_order, is_active, is_takeaway, table_id)
        )
    else:
        cur = conn.execute(
            "INSERT INTO ts_tables (zone_id, name, seats, sort_order, is_active, is_takeaway) VALUES (?,?,?,?,?,?)",
            (zone_id, name, seats, sort_order, is_active, is_takeaway)
        )
        table_id = cur.lastrowid
    conn.commit()
    conn.close()
    return table_id


def delete_table(db_path, table_id: int):
    conn = get_connection(db_path)
    any_tab = conn.execute(
        "SELECT id FROM ts_tabs WHERE table_id=? LIMIT 1", (table_id,)
    ).fetchone()
    if any_tab:
        # Has historical tabs — deactivate instead of delete
        conn.execute("UPDATE ts_tables SET is_active=0 WHERE id=?", (table_id,))
        conn.commit()
        conn.close()
        raise ValueError("Table has transaction history and cannot be deleted — it has been deactivated instead")
    conn.execute("DELETE FROM ts_tables WHERE id=?", (table_id,))
    conn.commit()
    conn.close()


# ── Tabs ──────────────────────────────────────────────────────────────────────

def open_tab(db_path, table_id: int, session_id: int = None, contact_id: int = None,
             opened_by_user_id: int = None, opened_by_name: str = None,
             notes: str = "", label: str = "") -> dict:
    conn = get_connection(db_path)
    table_row = conn.execute("SELECT is_takeaway FROM ts_tables WHERE id=?", (table_id,)).fetchone()
    is_takeaway = table_row and table_row["is_takeaway"]
    if not is_takeaway:
        existing = conn.execute(
            "SELECT id FROM ts_tabs WHERE table_id=? AND status='Open' LIMIT 1", (table_id,)
        ).fetchone()
        if existing:
            conn.close()
            raise ValueError("Table already has an open tab")
    cur = conn.execute(
        """INSERT INTO ts_tabs (table_id, session_id, contact_id, opened_by_user_id, opened_by_name, notes, label)
           VALUES (?,?,?,?,?,?,?)""",
        (table_id, session_id or None, contact_id or None,
         opened_by_user_id or None, opened_by_name or None, notes or None, label or None)
    )
    tab_id = cur.lastrowid
    row = conn.execute("SELECT * FROM ts_tabs WHERE id=?", (tab_id,)).fetchone()
    conn.commit()
    conn.close()
    return dict(row)


def get_tab(db_path, tab_id: int) -> dict:
    conn = get_connection(db_path)
    row = conn.execute("""
        SELECT tb.*, t.name AS table_name, t.seats, t.is_takeaway,
               z.name AS zone_name, c.name AS contact_name
        FROM ts_tabs tb
        JOIN ts_tables t ON t.id = tb.table_id
        LEFT JOIN ts_zones z ON z.id = t.zone_id
        LEFT JOIN contacts c ON c.id = tb.contact_id
        WHERE tb.id=?
    """, (tab_id,)).fetchone()
    if not row:
        conn.close()
        raise ValueError(f"Tab {tab_id} not found")
    tab = dict(row)
    items = conn.execute(
        "SELECT * FROM ts_tab_items WHERE tab_id=? ORDER BY added_at", (tab_id,)
    ).fetchall()
    tab["items"] = [dict(i) for i in items]
    conn.close()
    return tab


def get_open_tabs(db_path) -> list:
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT tb.*, t.name AS table_name, z.name AS zone_name, c.name AS contact_name,
               (SELECT COUNT(*) FROM ts_tab_items WHERE tab_id=tb.id) AS item_count,
               (SELECT SUM(qty * unit_price * (CASE WHEN tax_code='GST' THEN 1.1 ELSE 1.0 END))
                FROM ts_tab_items WHERE tab_id=tb.id) AS running_total
        FROM ts_tabs tb
        JOIN ts_tables t ON t.id = tb.table_id
        LEFT JOIN ts_zones z ON z.id = t.zone_id
        LEFT JOIN contacts c ON c.id = tb.contact_id
        WHERE tb.status='Open'
        ORDER BY tb.opened_at
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def ensure_takeaway_table(db_path) -> int:
    """Return the ID of the takeaway virtual table, creating it if needed."""
    conn = get_connection(db_path)
    row = conn.execute("SELECT id FROM ts_tables WHERE is_takeaway=1 LIMIT 1").fetchone()
    if row:
        conn.close()
        return row["id"]
    cur = conn.execute(
        "INSERT INTO ts_tables (name, seats, sort_order, is_active, is_takeaway) VALUES (?,?,?,?,?)",
        ("Takeaway", 0, 9999, 1, 1)
    )
    table_id = cur.lastrowid
    conn.commit()
    conn.close()
    return table_id


def get_takeaway_queue(db_path) -> list:
    """All open/sent tabs on the takeaway table, with item counts and totals."""
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT tb.id, tb.label, tb.opened_at, tb.status, tb.notes, tb.session_id,
               COUNT(ti.id) AS item_count,
               COALESCE(SUM(ti.qty * ti.unit_price *
                   (CASE WHEN ti.tax_code='GST' THEN 1.1 ELSE 1.0 END)), 0) AS total
        FROM ts_tabs tb
        JOIN ts_tables t ON t.id = tb.table_id
        LEFT JOIN ts_tab_items ti ON ti.tab_id = tb.id
        WHERE t.is_takeaway=1 AND tb.status IN ('Open','Sent')
        GROUP BY tb.id
        ORDER BY tb.opened_at
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_tab(db_path, tab_id: int, data: dict):
    conn = get_connection(db_path)
    conn.execute(
        "UPDATE ts_tabs SET contact_id=?, notes=? WHERE id=?",
        (data.get("contact_id") or None, data.get("notes") or None, tab_id)
    )
    conn.commit()
    conn.close()


def void_tab(db_path, tab_id: int):
    conn = get_connection(db_path)
    row = conn.execute("SELECT status FROM ts_tabs WHERE id=?", (tab_id,)).fetchone()
    if not row:
        conn.close()
        raise ValueError("Tab not found")
    if row["status"] != "Open":
        conn.close()
        raise ValueError("Only Open tabs can be voided")
    conn.execute("UPDATE ts_tabs SET status='Voided' WHERE id=?", (tab_id,))
    conn.commit()
    conn.close()


# ── Tab Items ─────────────────────────────────────────────────────────────────

def add_tab_items(db_path, tab_id: int, lines: list, fire_kitchen: bool = True) -> list:
    conn = get_connection(db_path)
    tab = conn.execute("SELECT status FROM ts_tabs WHERE id=?", (tab_id,)).fetchone()
    if not tab or tab["status"] != "Open":
        conn.close()
        raise ValueError("Tab is not open")
    inserted = []
    for line in lines:
        cur = conn.execute(
            """INSERT INTO ts_tab_items (tab_id, item_id, description, qty, unit_price, tax_code, account_id, note, sent_to_kitchen)
               VALUES (?,?,?,?,?,?,?,?,0)""",
            (tab_id, line.get("item_id") or None, line["description"],
             float(line.get("qty", 1)), float(line.get("unit_price", 0)),
             line.get("tax_code", "GST"), line.get("account_id") or None,
             line.get("note") or None)
        )
        inserted.append(cur.lastrowid)
    conn.commit()
    conn.close()
    if fire_kitchen:
        fire_kitchen_docket(db_path, tab_id)
    return inserted


def remove_tab_item(db_path, item_id: int):
    conn = get_connection(db_path)
    # Verify the tab is still Open
    row = conn.execute(
        "SELECT tb.status FROM ts_tab_items i JOIN ts_tabs tb ON tb.id=i.tab_id WHERE i.id=?",
        (item_id,)
    ).fetchone()
    if not row or row["status"] != "Open":
        conn.close()
        raise ValueError("Cannot remove items from a closed tab")
    conn.execute("DELETE FROM ts_tab_items WHERE id=?", (item_id,))
    conn.commit()
    conn.close()


def update_tab_item_qty(db_path, item_id: int, qty: float):
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT tb.status FROM ts_tab_items i JOIN ts_tabs tb ON tb.id=i.tab_id WHERE i.id=?",
        (item_id,)
    ).fetchone()
    if not row or row["status"] != "Open":
        conn.close()
        raise ValueError("Cannot edit items on a closed tab")
    if qty <= 0:
        conn.execute("DELETE FROM ts_tab_items WHERE id=?", (item_id,))
    else:
        conn.execute("UPDATE ts_tab_items SET qty=? WHERE id=?", (qty, item_id))
    conn.commit()
    conn.close()


# ── Settlement ────────────────────────────────────────────────────────────────

def settle_tab(db_path, tab_id: int, tender: str, tendered_amount: float = None,
               terminal_tx_id: str = None, terminal_provider: str = None,
               split_tenders: dict = None, basket_discount: float = 0.0) -> dict:
    from core.pos import create_pos_sale
    tab = get_tab(db_path, tab_id)
    if tab["status"] != "Open":
        raise ValueError("Tab is not open")
    if not tab["items"]:
        raise ValueError("Cannot settle an empty tab")

    lines = [
        {
            "item_id":     item["item_id"],
            "description": item["description"],
            "qty":         item["qty"],
            # Round to 2dp so multi-line repeating decimals (e.g. 9.09/1.1=8.2636̄)
            # don't accumulate per-line GST rounding errors in the GL journal.
            "unit_price":  round(item["unit_price"], 2),
            "tax_code":    item["tax_code"],
            "account_id":  item["account_id"],
        }
        for item in tab["items"]
    ]

    note = f"Table {tab['table_name']}"
    if tab.get("zone_name"):
        note = f"{tab['zone_name']} — {note}"

    result = create_pos_sale(
        db_path,
        lines=lines,
        tender=tender,
        tendered_amount=tendered_amount,
        terminal_tx_id=terminal_tx_id,
        terminal_provider=terminal_provider,
        note=note,
        session_id=tab.get("session_id"),
        contact_id=tab.get("contact_id"),
        split_tenders=split_tenders,
        basket_discount=basket_discount,
    )

    conn = get_connection(db_path)
    conn.execute("UPDATE ts_tabs SET status='Settled' WHERE id=?", (tab_id,))
    conn.commit()
    conn.close()
    return result


# ── Kitchen Docket ────────────────────────────────────────────────────────────

def fire_kitchen_docket(db_path, tab_id: int) -> tuple:
    import socket
    from core.pos_settings import get_pos_settings
    settings = get_pos_settings(db_path)
    if not settings.get("printer_enabled"):
        return False, "Printer not enabled in POS settings"
    if settings.get("printer_type", "network") != "network":
        return False, "Only network printers are currently supported"
    host = (settings.get("printer_host") or "").strip()
    port = int(settings.get("printer_port") or 9100)
    if not host:
        return False, "Printer host/IP not configured"

    conn = get_connection(db_path)
    tab = conn.execute("""
        SELECT tb.id, tb.notes, t.name AS table_name, z.name AS zone_name
        FROM ts_tabs tb
        JOIN ts_tables t ON t.id = tb.table_id
        LEFT JOIN ts_zones z ON z.id = t.zone_id
        WHERE tb.id=?
    """, (tab_id,)).fetchone()
    unsent = conn.execute(
        "SELECT * FROM ts_tab_items WHERE tab_id=? AND sent_to_kitchen=0 ORDER BY added_at",
        (tab_id,)
    ).fetchall()

    if not unsent:
        conn.close()
        return True, "Nothing to fire"

    data = _format_kitchen_docket_escpos(dict(tab), [dict(r) for r in unsent])

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5)
            s.connect((host, port))
            s.sendall(data)
        conn.execute(
            "UPDATE ts_tab_items SET sent_to_kitchen=1 WHERE tab_id=? AND sent_to_kitchen=0",
            (tab_id,)
        )
        conn.commit()
        conn.close()
        return True, "Fired"
    except socket.timeout:
        conn.close()
        return False, f"Printer timeout — could not connect to {host}:{port}"
    except OSError as e:
        conn.close()
        return False, f"Printer error: {e}"


def _format_kitchen_docket_escpos(tab: dict, items: list, width: int = 48) -> bytes:
    out = bytearray()

    def txt(s: str = ""):
        out.extend(s.encode("ascii", errors="replace") + _LF)

    def div():
        txt("-" * width)

    def bold(on: bool):
        out.extend(_ep(b'E' + bytes([1 if on else 0])))

    def align(n: int):
        out.extend(_ep(b'a' + bytes([n])))

    def dbl_height(on: bool):
        out.extend(_ep(b'!' + bytes([0x10 if on else 0x00])))

    def feed(n: int):
        out.extend(_ep(b'd' + bytes([n])))

    out.extend(_ep(b'@'))
    feed(1)
    align(1)
    bold(True)
    dbl_height(True)
    txt("** KITCHEN ORDER **")
    dbl_height(False)
    bold(False)
    align(0)
    div()

    zone  = tab.get("zone_name") or ""
    table = tab.get("table_name") or ""
    loc   = f"{zone} — {table}" if zone else table
    txt(f"TABLE: {loc}"[:width])
    txt(f"TIME:  {_dt.now().strftime('%H:%M')}  TAB #{tab['id']}")
    div()

    for item in items:
        qty = item["qty"]
        qty_str = str(int(qty)) if qty == int(qty) else str(qty)
        desc = item["description"][: width - len(qty_str) - 5]
        txt(f"  {qty_str}x  {desc}")
        if item.get("note"):
            note_line = f"       NOTE: {item['note']}"
            txt(note_line[:width])

    div()
    feed(4)
    out.extend(_GS + b'V\x41\x00')
    return bytes(out)


# ── Parked Carts ──────────────────────────────────────────────────────────────

def park_cart(db_path, session_id, label: str, cart_data: dict) -> int:
    """Persist a cart to DB. cart_data is the full JSON payload (label, lines, contactId, etc.)"""
    import json
    conn = get_connection(db_path)
    cur = conn.execute(
        "INSERT INTO pos_parked_carts (session_id, label, cart_json) VALUES (?,?,?)",
        (session_id or None, label or '', json.dumps(cart_data))
    )
    cart_id = cur.lastrowid
    conn.commit()
    conn.close()
    return cart_id


def get_parked_carts(db_path, session_id=None) -> list:
    import json
    conn = get_connection(db_path)
    if session_id:
        rows = conn.execute(
            "SELECT id, session_id, label, cart_json, created_at FROM pos_parked_carts WHERE session_id=? ORDER BY created_at",
            (session_id,)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id, session_id, label, cart_json, created_at FROM pos_parked_carts ORDER BY created_at"
        ).fetchall()
    conn.close()
    result = []
    for r in rows:
        entry = dict(r)
        try:
            entry['cart_data'] = json.loads(entry['cart_json'])
        except Exception:
            entry['cart_data'] = {}
        result.append(entry)
    return result


def delete_parked_cart(db_path, cart_id: int):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM pos_parked_carts WHERE id=?", (cart_id,))
    conn.commit()
    conn.close()


# ── Send Tab to Register ──────────────────────────────────────────────────────

def send_tab_to_register(db_path, tab_id: int, session_id=None) -> int:
    import json
    tab = get_tab(db_path, tab_id)
    if tab['status'] != 'Open':
        raise ValueError("Only Open tabs can be sent to the register")
    if not tab['items']:
        raise ValueError("Cannot send an empty tab to the register")

    label_parts = []
    if tab.get('zone_name'):
        label_parts.append(tab['zone_name'])
    label_parts.append(tab['table_name'])
    label = ' — '.join(label_parts)

    cart_data = {
        '_tab_id':       tab_id,
        'contactId':     tab.get('contact_id'),
        'contactName':   tab.get('contact_name'),
        'basketDiscount': 0,
        'lines': [
            {
                'item_id':     item['item_id'],
                'description': item['description'],
                'qty':         item['qty'],
                # POS expects GST-inclusive unit_price (it divides by 1.1 before invoicing).
                # ts_tab_items stores ex-GST, so multiply back to avoid double-stripping.
                'unit_price':  round(item['unit_price'] * (1.1 if item['tax_code'] == 'GST' else 1.0), 2),
                'tax_code':    item['tax_code'],
                'account_id':  item['account_id'],
                'discount':    0,
                'total': round(item['qty'] * item['unit_price'] * (1.1 if item['tax_code'] == 'GST' else 1.0), 2),
                'gst':   round(item['qty'] * item['unit_price'] * (0.1 if item['tax_code'] == 'GST' else 0.0), 2),
            }
            for item in tab['items']
        ],
    }

    cart_id = park_cart(db_path, session_id or tab.get('session_id'), label, cart_data)

    conn = get_connection(db_path)
    conn.execute("UPDATE ts_tabs SET status='Sent' WHERE id=?", (tab_id,))
    conn.commit()
    conn.close()
    return cart_id


def mark_kitchen_sent(db_path, tab_id: int) -> int:
    """Mark all unsent tab items as sent_to_kitchen (manual/verbal order confirmation)."""
    conn = get_connection(db_path)
    conn.execute(
        "UPDATE ts_tab_items SET sent_to_kitchen=1 WHERE tab_id=? AND sent_to_kitchen=0",
        (tab_id,)
    )
    count = conn.execute("SELECT changes()").fetchone()[0]
    conn.commit()
    conn.close()
    return count


def mark_tab_settled(db_path, tab_id: int):
    """Mark a Sent tab as Settled (called by POS after it processes the payment)."""
    conn = get_connection(db_path)
    conn.execute(
        "UPDATE ts_tabs SET status='Settled' WHERE id=? AND status IN ('Open','Sent')",
        (tab_id,)
    )
    conn.commit()
    conn.close()


def recall_tab_from_register(db_path, tab_id: int):
    """Pull a Sent tab back to Open — deletes the matching parked cart."""
    import json
    conn = get_connection(db_path)
    row = conn.execute("SELECT status FROM ts_tabs WHERE id=?", (tab_id,)).fetchone()
    if not row:
        conn.close()
        raise ValueError("Tab not found")
    if row['status'] == 'Settled':
        conn.close()
        raise ValueError("Tab has already been settled at the register")
    if row['status'] != 'Sent':
        conn.close()
        raise ValueError(f"Tab cannot be recalled (status: {row['status']})")

    # Find and delete the matching parked cart
    carts = conn.execute("SELECT id, cart_json FROM pos_parked_carts").fetchall()
    for c in carts:
        try:
            data = json.loads(c['cart_json'])
            if data.get('_tab_id') == tab_id:
                conn.execute("DELETE FROM pos_parked_carts WHERE id=?", (c['id'],))
                break
        except Exception:
            pass

    conn.execute("UPDATE ts_tabs SET status='Open' WHERE id=?", (tab_id,))
    conn.commit()
    conn.close()
