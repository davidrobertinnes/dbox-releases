# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
dbox - Job Card PDF Generator
Professional A4 Job Card / Work Order document.
"""

import os
import tempfile

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_RIGHT, TA_LEFT, TA_CENTER
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, KeepTogether
)

from core.database import get_connection
from core.invoice_pdf import (
    _resolve_theme, _s, _fmt, _c, _load_doc_theme,
    _build_header, _make_page_callback,
    PAGE_W,
)


def _priority_label(p):
    return {"Low": "Low", "Normal": "Normal", "High": "High", "Urgent": "URGENT"}.get(p, p or "Normal")


def generate_job_card_pdf(db_path, job_id, output_path=None, doc_theme=None, watermark=None, footer=None, include_financials=False):
    """
    Generate a job card PDF for a given job.

    Args:
        db_path:             path to .dbox SQLite file
        job_id:              jobs.id
        output_path:         where to write the PDF (temp file if None)
        doc_theme:           optional colour theme dict (uses company theme if None)
        watermark:           optional watermark text string
        include_financials:  if True, append the P&L summary and time cost table

    Returns:
        Absolute path to the generated PDF file.
    """
    conn = get_connection(db_path)

    job = conn.execute("""
        SELECT j.*,
               c.name    as contact_name,
               c.email   as contact_email,
               c.phone   as contact_phone,
               c.address as contact_address,
               c.city    as contact_city,
               c.state   as contact_state,
               c.postcode as contact_postcode
        FROM jobs j
        LEFT JOIN contacts c ON j.contact_id = c.id
        WHERE j.id = ?""", (job_id,)).fetchone()

    if not job:
        conn.close()
        raise ValueError(f"Job {job_id} not found")

    # CRM tasks linked to this job
    crm_tasks = conn.execute("""
        SELECT t.*
        FROM crm_tasks t
        WHERE t.job_id = ?
        ORDER BY t.is_done, t.due_date, t.priority DESC, t.id
    """, (job_id,)).fetchall()

    # Contact (work) tasks linked to this job
    work_tasks = conn.execute("""
        SELECT wt.*, c.name as contact_name
        FROM work_tasks wt
        LEFT JOIN contacts c ON wt.contact_id = c.id
        WHERE wt.job_id = ?
        ORDER BY wt.is_done ASC, wt.id DESC
    """, (job_id,)).fetchall()

    # P&L
    revenue = conn.execute("""
        SELECT COALESCE(SUM(jt.amount), 0)
        FROM job_transactions jt
        WHERE jt.job_id=? AND jt.source_type='invoice'
    """, (job_id,)).fetchone()[0] or 0

    costs = conn.execute("""
        SELECT COALESCE(SUM(jt.amount), 0)
        FROM job_transactions jt
        WHERE jt.job_id=? AND jt.source_type IN ('bill','journal')
    """, (job_id,)).fetchone()[0] or 0

    # Time entries summary
    time_entries = conn.execute("""
        SELECT te.*, e.first_name, e.last_name
        FROM job_employee_time te
        LEFT JOIN employees e ON te.employee_id = e.id
        WHERE te.job_id = ?
        ORDER BY te.entry_date, te.id
    """, (job_id,)).fetchall()

    company = conn.execute("SELECT * FROM company").fetchone()
    conn.close()

    j  = dict(job)
    co = dict(company) if company else {}

    # Resolve theme
    if doc_theme is None:
        doc_theme = _load_doc_theme(co)
    th = _resolve_theme(doc_theme)

    if output_path is None:
        output_path = os.path.join(tempfile.mkdtemp(), f"{j['job_number']}.pdf")

    s = _s(th)

    # Extra styles
    s["job_num"] = ParagraphStyle(
        "job_num", fontName="Helvetica-Bold",
        fontSize=20, textColor=_c(th["accent_bar"]),
        leading=24, alignment=TA_RIGHT)
    s["section_hdr"] = ParagraphStyle(
        "section_hdr", fontName="Helvetica-Bold",
        fontSize=8, textColor=_c(th["label_colour"]),
        leading=11, spaceAfter=2, textTransform="uppercase")
    s["task_done"] = ParagraphStyle(
        "task_done", fontName="Helvetica",
        fontSize=9, textColor=_c(th["dim_text"]),
        leading=13)

    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        leftMargin=18*mm, rightMargin=18*mm,
        topMargin=14*mm, bottomMargin=14*mm,
        title=f"Job Card {j['job_number']}",
        author=co.get("name", ""),
    )
    story = []

    co_name, co_abn, co_addr, co_phone, co_email, co_web = \
        _build_header(story, co, "JOB CARD", s, th)

    # ── Job identity block ────────────────────────────────────────────────────
    def _meta_row(label, value):
        return [Paragraph(label, s["label"]), Paragraph(str(value) if value else "—", s["body"])]

    meta_rows = [
        _meta_row("Job Number", j.get("job_number")),
        _meta_row("Status",     j.get("status")),
        _meta_row("Manager",    j.get("manager")),
        _meta_row("Start Date", j.get("start_date") or "—"),
        _meta_row("End Date",   j.get("end_date") or "Ongoing"),
    ]
    if j.get("budget_amount"):
        meta_rows.append(_meta_row("Budget", f"${j['budget_amount']:,.2f}"))

    meta_tbl = Table(meta_rows, colWidths=[32*mm, 60*mm])
    meta_tbl.setStyle(TableStyle([
        ("TOPPADDING",    (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ("LEFTPADDING",   (0, 0), (-1, -1), 0),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 4),
        ("VALIGN",        (0, 0), (-1, -1), "TOP"),
    ]))

    # Client block
    client_elems = [Paragraph("Client", s["label"])]
    if j.get("contact_name"):
        client_elems.append(Paragraph(j["contact_name"], s["body_b"]))
    addr = ", ".join(filter(None, [
        j.get("contact_address"), j.get("contact_city"),
        j.get("contact_state"),   j.get("contact_postcode")]))
    if addr:
        client_elems.append(Paragraph(addr, s["body"]))
    if j.get("contact_phone"):
        client_elems.append(Paragraph(j["contact_phone"], s["small"]))
    if j.get("contact_email"):
        client_elems.append(Paragraph(j["contact_email"], s["small"]))

    identity_tbl = Table(
        [[client_elems, meta_tbl]],
        colWidths=[PAGE_W * 0.52, PAGE_W * 0.48])
    identity_tbl.setStyle(TableStyle([
        ("VALIGN",       (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING",  (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))
    story.append(identity_tbl)
    story.append(Spacer(1, 4*mm))

    # ── Job name + description ─────────────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=1,
                             color=_c(th["rule_colour"]), spaceAfter=4))
    story.append(Paragraph(j.get("name") or "", s["body_b"]))
    desc = (j.get("description") or "").strip()
    if desc:
        story.append(Spacer(1, 2*mm))
        story.append(Paragraph(desc.replace("\n", "<br/>"), s["body"]))
    if j.get("budget_notes"):
        story.append(Spacer(1, 1*mm))
        story.append(Paragraph(j["budget_notes"].replace("\n", "<br/>"), s["small"]))
    story.append(Spacer(1, 4*mm))

    # ── Task table helper ──────────────────────────────────────────────────────
    def _task_table_style():
        return TableStyle([
            ("BACKGROUND",     (0, 0), (-1, 0),  _c(th["header_bg"])),
            ("TEXTCOLOR",      (0, 0), (-1, 0),  _c(th["header_text"])),
            ("FONTNAME",       (0, 0), (-1, 0),  "Helvetica-Bold"),
            ("FONTSIZE",       (0, 0), (-1, 0),  8),
            ("TOPPADDING",     (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING",  (0, 0), (-1, -1), 3),
            ("LEFTPADDING",    (0, 0), (-1, -1), 4),
            ("RIGHTPADDING",   (0, 0), (-1, -1), 4),
            ("FONTSIZE",       (0, 1), (-1, -1), 9),
            ("GRID",           (0, 0), (-1, -1), 0.4, _c(th["rule_colour"])),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [_c(th["row_alt"]), colors.white]),
            ("VALIGN",         (0, 0), (-1, -1), "MIDDLE"),
        ])

    # ── CRM Tasks ─────────────────────────────────────────────────────────────
    if crm_tasks:
        story.append(Paragraph("CRM Tasks", s["section_hdr"]))
        story.append(Spacer(1, 1*mm))

        task_data = [[
            Paragraph("", s["tbl_hdr"]),
            Paragraph("Task", s["tbl_hdr"]),
            Paragraph("Type", s["tbl_hdr"]),
            Paragraph("Due", s["tbl_hdr"]),
            Paragraph("Assigned To", s["tbl_hdr"]),
            Paragraph("Priority", s["tbl_hdr"]),
        ]]
        for t in crm_tasks:
            td = dict(t)
            done = bool(td.get("is_done"))
            body_style = s["task_done"] if done else s["body"]
            task_data.append([
                Paragraph("✓" if done else "☐", s["body"]),
                Paragraph(td.get("title") or "", body_style),
                Paragraph(td.get("task_type") or "", body_style),
                Paragraph(td.get("due_date") or "—", body_style),
                Paragraph(td.get("assigned_to") or "—", body_style),
                Paragraph(_priority_label(td.get("priority")), body_style),
            ])

        cw = [8*mm, PAGE_W*0.35, PAGE_W*0.15, 22*mm, PAGE_W*0.18, 18*mm]
        task_tbl = Table(task_data, colWidths=cw, repeatRows=1)
        task_tbl.setStyle(_task_table_style())
        story.append(task_tbl)
        story.append(Spacer(1, 4*mm))

    # ── Contact (Work) Tasks ───────────────────────────────────────────────────
    if work_tasks:
        story.append(Paragraph("Contact Tasks", s["section_hdr"]))
        story.append(Spacer(1, 1*mm))

        wt_data = [[
            Paragraph("", s["tbl_hdr"]),
            Paragraph("Task", s["tbl_hdr"]),
            Paragraph("Contact", s["tbl_hdr"]),
            Paragraph("Qty", s["tbl_hdr_r"]),
            Paragraph("Unit Price", s["tbl_hdr_r"]),
        ]]
        for t in work_tasks:
            td = dict(t)
            done = bool(td.get("is_done"))
            body_style = s["task_done"] if done else s["body"]
            wt_data.append([
                Paragraph("✓" if done else "☐", s["body"]),
                Paragraph(td.get("title") or "", body_style),
                Paragraph(td.get("contact_name") or "—", body_style),
                Paragraph(str(int(td["qty"]) if td.get("qty") and td["qty"] == int(td["qty"]) else td.get("qty", 1)), s["right"]),
                Paragraph(_fmt(td.get("unit_price") or 0) if td.get("unit_price") else "—", s["right"]),
            ])

        cw_w = [8*mm, PAGE_W*0.42, PAGE_W*0.28, 18*mm, 24*mm]
        wt_tbl = Table(wt_data, colWidths=cw_w, repeatRows=1)
        wt_tbl.setStyle(_task_table_style())
        story.append(wt_tbl)
        story.append(Spacer(1, 5*mm))

    # ── P&L summary + time (only when include_financials=True) ──────────────
    if include_financials:
        gross_profit = revenue - costs
        pl_rows = [
            [Paragraph("Revenue", s["label"]),
             Paragraph(_fmt(revenue), s["right"])],
            [Paragraph("Costs", s["label"]),
             Paragraph(_fmt(costs), s["right"])],
            [Paragraph("Gross Profit", s["label"]),
             Paragraph(_fmt(gross_profit),
                       ParagraphStyle("gp", fontName="Helvetica-Bold",
                                      fontSize=9, leading=13, alignment=TA_RIGHT,
                                      textColor=colors.HexColor("#27ae60") if gross_profit >= 0
                                      else colors.HexColor("#e74c3c")))],
        ]
        if j.get("budget_amount"):
            variance = j["budget_amount"] - costs
            pl_rows.append([
                Paragraph("Budget Variance", s["label"]),
                Paragraph(_fmt(variance),
                          ParagraphStyle("bv", fontName="Helvetica",
                                         fontSize=9, leading=13, alignment=TA_RIGHT,
                                         textColor=colors.HexColor("#27ae60") if variance >= 0
                                         else colors.HexColor("#e74c3c"))),
            ])

        pl_tbl = Table(pl_rows, colWidths=[40*mm, 30*mm])
        pl_tbl.setStyle(TableStyle([
            ("TOPPADDING",    (0, 0), (-1, -1), 2),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
            ("LEFTPADDING",   (0, 0), (-1, -1), 0),
            ("RIGHTPADDING",  (0, 0), (-1, -1), 0),
            ("LINEABOVE",     (0, 2), (-1, 2),  0.5, _c(th["rule_colour"])),
        ]))

        if time_entries:
            total_hours = sum(e["hours"] or 0 for e in time_entries)
            total_cost  = sum((e["hours"] or 0) * (e["hourly_rate"] or 0) for e in time_entries)

            time_data = [[
                Paragraph("Employee", s["tbl_hdr"]),
                Paragraph("Date", s["tbl_hdr"]),
                Paragraph("Hours", s["tbl_hdr_r"]),
                Paragraph("Rate", s["tbl_hdr_r"]),
                Paragraph("Cost", s["tbl_hdr_r"]),
                Paragraph("Notes", s["tbl_hdr"]),
            ]]
            for e in time_entries:
                ed = dict(e)
                name = f"{ed.get('first_name','')} {ed.get('last_name','')}".strip() or "—"
                time_data.append([
                    Paragraph(name, s["body"]),
                    Paragraph(ed.get("entry_date") or "—", s["body"]),
                    Paragraph(f"{ed.get('hours',0):.1f}", s["right"]),
                    Paragraph(f"${ed.get('hourly_rate',0):.2f}", s["right"]),
                    Paragraph(_fmt((ed.get("hours") or 0) * (ed.get("hourly_rate") or 0)), s["right"]),
                    Paragraph(ed.get("description") or "", s["body"]),
                ])
            time_data.append([
                Paragraph("TOTAL", s["body_b"]), "",
                Paragraph(f"{total_hours:.1f}", s["right_b"]),
                "",
                Paragraph(_fmt(total_cost), s["right_b"]),
                "",
            ])

            cw_t = [PAGE_W*0.22, 22*mm, 16*mm, 16*mm, 22*mm, PAGE_W*0.25]
            time_tbl = Table(time_data, colWidths=cw_t, repeatRows=1)
            n_t = len(time_data)
            time_tbl.setStyle(TableStyle([
                ("BACKGROUND",    (0, 0), (-1, 0),   _c(th["header_bg"])),
                ("TEXTCOLOR",     (0, 0), (-1, 0),   _c(th["header_text"])),
                ("FONTNAME",      (0, 0), (-1, 0),   "Helvetica-Bold"),
                ("FONTSIZE",      (0, 0), (-1, 0),   8),
                ("TOPPADDING",    (0, 0), (-1, -1),  3),
                ("BOTTOMPADDING", (0, 0), (-1, -1),  3),
                ("LEFTPADDING",   (0, 0), (-1, -1),  4),
                ("RIGHTPADDING",  (0, 0), (-1, -1),  4),
                ("FONTSIZE",      (0, 1), (-1, -1),  9),
                ("GRID",          (0, 0), (-1, -2),  0.4, _c(th["rule_colour"])),
                ("ROWBACKGROUNDS", (0, 1), (-1, -2),
                 [_c(th["row_alt"]), colors.white]),
                ("BACKGROUND",    (0, n_t-1), (-1, n_t-1), _c(th["payment_box_bg"])),
                ("FONTNAME",      (0, n_t-1), (-1, n_t-1), "Helvetica-Bold"),
                ("VALIGN",        (0, 0), (-1, -1),  "MIDDLE"),
            ]))

            story.append(Paragraph("Employee Time", s["section_hdr"]))
            story.append(Spacer(1, 1*mm))

            summary_row = Table(
                [[pl_tbl, time_tbl]],
                colWidths=[80*mm, PAGE_W - 80*mm])
            summary_row.setStyle(TableStyle([
                ("VALIGN",       (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING",  (0, 0), (-1, -1), 0),
                ("RIGHTPADDING", (0, 0), (-1, -1), 0),
            ]))
            story.append(summary_row)
        else:
            story.append(Paragraph("P&L Summary", s["section_hdr"]))
            story.append(Spacer(1, 1*mm))
            story.append(pl_tbl)

    # ── Footer ────────────────────────────────────────────────────────────────
    story.append(Spacer(1, 6*mm))
    story.append(HRFlowable(width="100%", thickness=0.5,
                             color=_c(th["rule_colour"]), spaceAfter=3))
    footer_txt = f"Job Card {j['job_number']}  —  {j.get('name', '')}  —  Status: {j.get('status', '')}"
    story.append(Paragraph(footer_txt, s["small"]))

    _cb = _make_page_callback(watermark=watermark, footer=footer)
    doc.build(story, onFirstPage=_cb, onLaterPages=_cb)
    return output_path
