# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
dbox - Ledger Engine
Core double-entry accounting logic
"""


import re
from .database import get_connection

_ACCT_CODE_RE = re.compile(r'^[1-5]-\d{4}$')
_ACCT_TYPE_CLASS = {'Asset': '1', 'Liability': '2', 'Equity': '3', 'Income': '4', 'Expense': '5'}


def _next_invoice_number(conn):
    co = conn.execute("SELECT inv_prefix, inv_next FROM company WHERE id=1").fetchone()
    prefix = (co["inv_prefix"] or "INV-") if co else "INV-"
    floor  = max(1, int(co["inv_next"] or 1)) if co else 1
    row = conn.execute(
        "SELECT invoice_number FROM invoices WHERE is_credit_note=0 OR is_credit_note IS NULL "
        "ORDER BY id DESC LIMIT 1").fetchone()
    num = floor
    if row and row[0]:
        last = row[0]
        stripped = last[len(prefix):] if last.startswith(prefix) else last
        try:
            num = max(int(stripped) + 1, floor)
        except Exception:
            pass
    return f"{prefix}{num:05d}"


def _next_credit_note_number(conn):
    row = conn.execute(
        "SELECT invoice_number FROM invoices WHERE is_credit_note=1 ORDER BY id DESC LIMIT 1"
    ).fetchone()
    if row:
        try:
            num = int(row[0].replace("CN-", "")) + 1
        except Exception:
            num = 1
    else:
        num = 1
    return f"CN-{num:05d}"


def _gst_amount(amount_ex_gst, tax_code, conn):
    row = conn.execute(
        "SELECT rate FROM tax_codes WHERE code=?", (tax_code,)).fetchone()
    if row:
        return round(amount_ex_gst * row["rate"], 2)
    return 0.0


# ── Accounts ─────────────────────────────────────────────────────────────────

def get_accounts(db_path, account_type=None, is_bank=None,
                 is_credit_card=None, active_only=True):
    conn = get_connection(db_path)
    q = "SELECT * FROM accounts WHERE 1=1"
    params = []
    if active_only:
        q += " AND is_active=1"
    if account_type:
        q += " AND account_type=?"
        params.append(account_type)
    if is_bank is not None:
        q += " AND is_bank=?"
        params.append(is_bank)
    if is_credit_card is not None:
        q += " AND is_credit_card=?"
        params.append(is_credit_card)
    q += " ORDER BY code"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_account(db_path, data):
    code = (data.get("code") or "").strip()
    if not _ACCT_CODE_RE.match(code):
        raise ValueError("Account code must be in format C-HXXX (e.g. 1-1100) where C is class 1–5")
    atype = data.get("account_type", "")
    expected_class = _ACCT_TYPE_CLASS.get(atype)
    if expected_class and code[0] != expected_class:
        raise ValueError(
            f"{atype} accounts must use class {expected_class} "
            f"(code must start with {expected_class}-)"
        )
    conn = get_connection(db_path)
    # Derive flags from subtype — subtype is the single source of truth.
    # Manual flag values are only used as fallback when subtype doesn't match,
    # so existing data without a recognised subtype is never silently broken.
    subtype = data.get("account_subtype") or ""
    is_bank = 1 if subtype in ("Bank", "Cash and Cash Equivalents") else data.get("is_bank", 0)
    is_cc   = 1 if subtype == "Credit Card"                          else data.get("is_credit_card", 0)
    if data.get("id"):
        conn.execute("""UPDATE accounts SET code=?,name=?,account_type=?,
            account_subtype=?,description=?,is_bank=?,is_credit_card=?,
            bsb=?,account_number=?,
            tax_code=?,is_active=?,opening_balance=? WHERE id=?""",
            (data["code"], data["name"], data["account_type"],
             data.get("account_subtype"), data.get("description"),
             is_bank, is_cc,
             data.get("bsb"), data.get("account_number"),
             data.get("tax_code", "GST"), data.get("is_active", 1),
             data.get("opening_balance", 0), data["id"]))
    else:
        conn.execute("""INSERT INTO accounts
            (code,name,account_type,account_subtype,description,is_bank,
             is_credit_card,bsb,account_number,tax_code,is_active,opening_balance)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (data["code"], data["name"], data["account_type"],
             data.get("account_subtype"), data.get("description"),
             is_bank, is_cc,
             data.get("bsb"), data.get("account_number"),
             data.get("tax_code", "GST"), data.get("is_active", 1),
             data.get("opening_balance", 0)))
    conn.commit()
    conn.close()


def get_account_balance(db_path, account_id):
    conn = get_connection(db_path)
    acc = conn.execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
    row = conn.execute("""
        SELECT COALESCE(SUM(debit),0) - COALESCE(SUM(credit),0) AS net
        FROM journal_lines WHERE account_id=?""", (account_id,)).fetchone()
    conn.close()
    if not acc:
        return 0.0
    net = row["net"] if row else 0.0
    opening = acc["opening_balance"] or 0.0
    if acc["account_type"] in ("Asset", "Expense"):
        return opening + net
    else:
        return opening - net


def get_account_balances_batch(db_path, account_ids):
    """Return {account_id: balance} for a list of IDs in a single query."""
    if not account_ids:
        return {}
    conn = get_connection(db_path)
    ph = ",".join("?" * len(account_ids))
    accs = {r["id"]: r for r in conn.execute(
        f"SELECT * FROM accounts WHERE id IN ({ph})", account_ids).fetchall()}
    nets = {r["account_id"]: r["net"] for r in conn.execute(f"""
        SELECT account_id, COALESCE(SUM(debit),0) - COALESCE(SUM(credit),0) AS net
        FROM journal_lines WHERE account_id IN ({ph})
        GROUP BY account_id""", account_ids).fetchall()}
    conn.close()
    result = {}
    for aid in account_ids:
        acc = accs.get(aid)
        if not acc:
            result[aid] = 0.0
            continue
        net     = nets.get(aid, 0.0)
        opening = acc["opening_balance"] or 0.0
        result[aid] = opening + net if acc["account_type"] in ("Asset","Expense")                       else opening - net
    return result


# ── Contacts ──────────────────────────────────────────────────────────────────

def get_contacts(db_path, contact_type=None, active_only=True):
    conn = get_connection(db_path)
    q = "SELECT * FROM contacts WHERE 1=1"
    params = []
    if active_only:
        q += " AND is_active=1"
    if contact_type:
        q += " AND (contact_type=? OR contact_type=\'Both\')"
        params.append(contact_type)
    q += " ORDER BY name"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


_WORKER_TYPES = ("Employee", "Contractor")


def save_contact(db_path, data):
    # Works on jobs: Employee, Contractor or neither. A contact that is only a worker
    # has that as its contact_type too, so customer/supplier lists leave it out.
    if data.get("contact_type") in _WORKER_TYPES and not data.get("worker_type"):
        data["worker_type"] = data["contact_type"]
    if "worker_type" in data:
        if data["worker_type"] not in _WORKER_TYPES:
            data["worker_type"] = None
    conn = get_connection(db_path)
    if data.get("id") and "worker_type" in data and data["worker_type"] != "Employee":
        # A current payroll employee stays an Employee: pay runs, STP and super rely on it.
        try:
            emp = conn.execute("""SELECT 1 FROM employees WHERE contact_id=? AND
                (termination_date IS NULL OR termination_date='')""", (data["id"],)).fetchone()
        except Exception:
            emp = None   # no payroll tables in this file
        if emp:
            conn.close()
            raise ValueError("This contact is a current employee in Payroll, so it stays an Employee. "
                             "End their employment in Payroll first to make them a contractor.")
    if data.get("id"):
        conn.execute("""UPDATE contacts SET contact_type=?,name=?,abn=?,
            contact_person=?,email=?,phone=?,address=?,city=?,state=?,
            postcode=?,payment_terms=?,default_tax_code=?,notes=?,is_active=?,
            bsb=?,account_number=?,bank_account_name=?,
            approved_account=?,approved_by_employee_id=?
            WHERE id=?""",
            (data["contact_type"], data["name"], data.get("abn"),
             data.get("contact_person"), data.get("email"), data.get("phone"),
             data.get("address"), data.get("city"), data.get("state"),
             data.get("postcode"), data.get("payment_terms", 30),
             data.get("default_tax_code", "GST"), data.get("notes"),
             data.get("is_active", 1),
             data.get("bsb"), data.get("account_number"),
             data.get("bank_account_name"),
             data.get("approved_account", 0),
             data.get("approved_by_employee_id") or None,
             data["id"]))
        if "worker_type" in data:   # callers that don't send it leave it alone
            conn.execute("UPDATE contacts SET worker_type=? WHERE id=?", (data["worker_type"], data["id"]))
    else:
        conn.execute("""INSERT INTO contacts
            (contact_type,name,abn,contact_person,email,phone,address,
             city,state,postcode,payment_terms,default_tax_code,notes,
             is_active,bsb,account_number,bank_account_name,
             approved_account,approved_by_employee_id)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (data["contact_type"], data["name"], data.get("abn"),
             data.get("contact_person"), data.get("email"), data.get("phone"),
             data.get("address"), data.get("city"), data.get("state"),
             data.get("postcode"), data.get("payment_terms", 30),
             data.get("default_tax_code", "GST"), data.get("notes"),
             data.get("is_active", 1),
             data.get("bsb"), data.get("account_number"),
             data.get("bank_account_name"),
             data.get("approved_account", 0),
             data.get("approved_by_employee_id") or None))
        data["id"] = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        if data.get("worker_type"):
            conn.execute("UPDATE contacts SET worker_type=? WHERE id=?", (data["worker_type"], data["id"]))
    conn.commit()
    conn.close()
    return data.get("id")


def merge_contacts(db_path, keep_id, drop_id):
    """Reassign all records from drop_id to keep_id, then delete drop_id."""
    if keep_id == drop_id:
        raise ValueError("Cannot merge a contact with itself")
    conn = get_connection(db_path)
    try:
        keep = conn.execute("SELECT id, is_system FROM contacts WHERE id=?", (keep_id,)).fetchone()
        drop = conn.execute("SELECT id, is_system FROM contacts WHERE id=?", (drop_id,)).fetchone()
        if not keep or not drop:
            raise ValueError("Contact not found")
        if drop["is_system"]:
            raise ValueError("Cannot merge a system contact")
        tables = [
            ("invoices",            "contact_id"),
            ("bills",               "contact_id"),
            ("payments",            "contact_id"),
            ("journal_entries",     "contact_id"),
            ("purchase_orders",     "contact_id"),
            ("jobs",                "contact_id"),
            ("work_tasks",          "contact_id"),
            ("crm_communications",  "contact_id"),
            ("crm_quotes",          "contact_id"),
            ("crm_progress_claims", "contact_id"),
            ("bank_rules",          "contact_id"),
        ]
        for table, col in tables:
            try:
                conn.execute(f"UPDATE {table} SET {col}=? WHERE {col}=?", (keep_id, drop_id))
            except Exception:
                pass  # table may not exist in older databases
        conn.execute("DELETE FROM contacts WHERE id=?", (drop_id,))
        conn.commit()
    finally:
        conn.close()


# ── Invoices ──────────────────────────────────────────────────────────────────

def get_invoices(db_path, status=None, contact_id=None, opp_id=None):
    conn = get_connection(db_path)
    q = """SELECT i.*, c.name as contact_name
           FROM invoices i JOIN contacts c ON i.contact_id=c.id WHERE 1=1"""
    params = []
    if status:
        q += " AND i.status=?"
        params.append(status)
    if contact_id:
        q += " AND i.contact_id=?"
        params.append(contact_id)
    if opp_id:
        q += " AND i.opp_id=?"
        params.append(opp_id)
    q += " ORDER BY i.invoice_date DESC, i.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_invoice(db_path, invoice_id):
    conn = get_connection(db_path)
    inv = conn.execute("""SELECT i.*, c.name as contact_name, c.abn as contact_abn,
        c.email as contact_email, c.address as contact_address
        FROM invoices i JOIN contacts c ON i.contact_id=c.id
        WHERE i.id=?""", (invoice_id,)).fetchone()
    lines = conn.execute("""SELECT il.*, a.name as account_name
        FROM invoice_lines il LEFT JOIN accounts a ON il.account_id=a.id
        WHERE il.invoice_id=? ORDER BY il.id""", (invoice_id,)).fetchall()
    conn.close()
    if not inv:
        return None
    return {"invoice": dict(inv), "lines": [dict(l) for l in lines]}


def save_invoice(db_path, inv_data, lines, skip_gl=False):
    conn = get_connection(db_path)
    conn.execute("BEGIN IMMEDIATE")  # hold write lock before number generation + INSERT
    c = conn.cursor()
    item_lines = [l for l in lines if l.get("line_type", "item") != "comment"]
    subtotal = sum(l["quantity"] * l["unit_price"] for l in item_lines)
    gst_total = 0.0
    for l in lines:
        if l.get("line_type", "item") == "comment":
            l["gst_amount"] = 0.0
            l["line_total"] = 0.0
            l.setdefault("quantity", 0)
            l.setdefault("unit_price", 0)
        else:
            line_ex = l["quantity"] * l["unit_price"]
            l["gst_amount"] = _gst_amount(line_ex, l.get("tax_code", "GST"), conn)
            l["line_total"] = round(line_ex + l["gst_amount"], 2)
            gst_total += l["gst_amount"]

    # Invoice-level discount (applied proportionally across net + GST)
    disc_type = inv_data.get("discount_type") or "amount"
    disc_value = float(inv_data.get("discount_value") or 0)
    if disc_value > 0 and subtotal > 0:
        if disc_type == "percent":
            disc_amount = round(subtotal * disc_value / 100, 2)
        else:
            disc_amount = round(min(disc_value, subtotal), 2)
        disc_ratio = (subtotal - disc_amount) / subtotal
        adj_gst = round(gst_total * disc_ratio, 2)
        adj_subtotal = round(subtotal - disc_amount, 2)
    else:
        disc_amount = 0.0
        disc_ratio = 1.0
        adj_gst = gst_total
        adj_subtotal = subtotal
    total = round(adj_subtotal + adj_gst, 2)

    inv_id = inv_data.get("id")
    if inv_id:
        c.execute("""UPDATE invoices SET contact_id=?,invoice_date=?,due_date=?,
            status=?,subtotal=?,gst_total=?,total=?,notes=?,
            payment_instructions=?,internal_comments=?,opp_id=?,job_id=?,
            discount_type=?,discount_value=?,discount_amount=?,customer_ref=? WHERE id=?""",
            (inv_data["contact_id"], inv_data["invoice_date"], inv_data["due_date"],
             inv_data.get("status", "Draft"), adj_subtotal, adj_gst, total,
             inv_data.get("notes"), inv_data.get("payment_instructions"),
             inv_data.get("internal_comments"), inv_data.get("opp_id"),
             inv_data.get("job_id"),
             disc_type, disc_value, disc_amount,
             (inv_data.get("customer_ref") or "").strip() or None, inv_id))
        c.execute("DELETE FROM invoice_lines WHERE invoice_id=?", (inv_id,))
    else:
        inv_num = inv_data.get("invoice_number") or _next_invoice_number(conn)
        c.execute("""INSERT INTO invoices
            (invoice_number,contact_id,invoice_date,due_date,status,
             subtotal,gst_total,total,notes,payment_instructions,internal_comments,opp_id,job_id,
             discount_type,discount_value,discount_amount,customer_ref)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (inv_num, inv_data["contact_id"], inv_data["invoice_date"],
             inv_data["due_date"], inv_data.get("status", "Draft"),
             adj_subtotal, adj_gst, total, inv_data.get("notes"),
             inv_data.get("payment_instructions"),
             inv_data.get("internal_comments"), inv_data.get("opp_id"),
             inv_data.get("job_id"),
             disc_type, disc_value, disc_amount,
             (inv_data.get("customer_ref") or "").strip() or None))
        inv_id = c.lastrowid
    for l in lines:
        c.execute("""INSERT INTO invoice_lines
            (invoice_id,description,quantity,unit_price,tax_code,
             gst_amount,line_total,account_id,item_id,line_type)
            VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (inv_id, l["description"], l.get("quantity", 0), l.get("unit_price", 0),
             l.get("tax_code", "GST"), l["gst_amount"], l["line_total"],
             l.get("account_id"), l.get("item_id"), l.get("line_type", "item")))
    if not skip_gl and inv_data.get("status", "Draft") != "Draft":
        ar = conn.execute("SELECT id FROM accounts WHERE code='1-1200'").fetchone()
        gst_col = conn.execute("SELECT id FROM accounts WHERE code='2-1200'").fetchone()
        if ar and gst_col:
            # Replace existing journal rather than creating a duplicate.
            # Fetch current journal_id (may differ from inv_data if caller has stale data).
            existing = conn.execute(
                "SELECT journal_id FROM invoices WHERE id=?", (inv_id,)).fetchone()
            old_jid = existing["journal_id"] if existing else None
            if old_jid:
                c.execute("DELETE FROM journal_lines WHERE journal_id=?", (old_jid,))
                c.execute("""UPDATE journal_entries
                    SET entry_date=?, description=? WHERE id=?""",
                    (inv_data["invoice_date"], "Invoice " + str(inv_id), old_jid))
                jid = old_jid
            else:
                c.execute("""INSERT INTO journal_entries
                    (entry_date,reference,description,entry_type,source_id,source_type)
                    VALUES (?,?,?,?,?,?)""",
                    (inv_data["invoice_date"], "",
                     "Invoice " + str(inv_id), "Invoice", inv_id, "invoice"))
                jid = c.lastrowid
                c.execute("UPDATE invoices SET journal_id=? WHERE id=?", (jid, inv_id))
            c.execute("""INSERT INTO journal_lines
                (journal_id,account_id,debit,credit) VALUES (?,?,?,?)""",
                (jid, ar["id"], total, 0))
            income_lines = []   # [account_id, net, gst] — posted after rounding is settled
            for l in item_lines:
                gl_acc = l.get("account_id")
                if gl_acc:
                    acc_row = conn.execute(
                        "SELECT account_type FROM accounts WHERE id=?",
                        (gl_acc,)).fetchone()
                    if acc_row and acc_row["account_type"] not in (
                            "Income", "Revenue", "Other Income"):
                        gl_acc = None
                if not gl_acc:
                    fallback = conn.execute(
                        "SELECT id FROM accounts "
                        "WHERE account_type IN ('Income','Revenue') "
                        "ORDER BY code LIMIT 1").fetchone()
                    gl_acc = fallback["id"] if fallback else None
                if gl_acc:
                    line_net = round(l["quantity"] * l["unit_price"] * disc_ratio, 2)
                    line_gst = round(l["gst_amount"] * disc_ratio, 2)
                    income_lines.append([gl_acc, line_net, line_gst])
            # Lines rounded one by one can drift a cent from the rounded total
            # (several lines, or a discount); settle it on the largest line so
            # the journal balances: AR = income + GST collected.
            if income_lines:
                drift = round(round(total - round(adj_gst, 2), 2)
                              - sum(n for _, n, _ in income_lines), 2)
                if drift:
                    biggest = max(income_lines, key=lambda x: abs(x[1]))
                    biggest[1] = round(biggest[1] + drift, 2)
            for gl_acc, line_net, line_gst in income_lines:
                c.execute("""INSERT INTO journal_lines
                    (journal_id,account_id,debit,credit,gst_amount)
                    VALUES (?,?,?,?,?)""",
                    (jid, gl_acc, 0, line_net, line_gst))
            if adj_gst != 0:
                c.execute("""INSERT INTO journal_lines
                    (journal_id,account_id,debit,credit) VALUES (?,?,?,?)""",
                    (jid, gst_col["id"], 0, adj_gst))

    # ── Oversell check BEFORE commit ─────────────────────────────────────────
    # Check here so that if stock is insufficient the entire transaction
    # is rolled back — no invoice record, no journal. The UI pre-check
    # (in _save) shows the dialog; this is the enforcement backstop that
    # ensures a clean rollback if the check fires.
    if inv_data.get("status", "Draft") not in ("Draft", "Void"):
        if not inv_data.get("allow_negative_stock"):
            try:
                from core.inventory import check_oversell, OversellError
                problems = check_oversell(db_path, item_lines)
                if problems:
                    conn.rollback()
                    conn.close()
                    raise OversellError(problems)
            except OversellError:
                raise
            except Exception:
                pass  # check failure is non-blocking

    conn.commit()
    conn.close()

    # ── SALE movements (only reached if check passed or not applicable) ───────
    if inv_data.get("status", "Draft") not in ("Draft", "Void"):
        try:
            from core.inventory import post_stock_movement, get_inventory_item
            _dup_conn = get_connection(db_path)
            for l in lines:
                if l.get("item_id"):
                    item = get_inventory_item(db_path, l["item_id"])
                    if item and item.get("is_inventoried"):
                        already = _dup_conn.execute(
                            """SELECT id FROM inventory_movements
                               WHERE source_doc_type='invoice' AND source_doc_id=?
                                 AND item_id=? AND movement_type='SALE'
                               LIMIT 1""",
                            (inv_id, l["item_id"])).fetchone()
                        if already:
                            continue
                        post_stock_movement(
                            db_path, l["item_id"], "SALE",
                            inv_data.get("invoice_date", str(__import__('datetime').date.today())),
                            float(l.get("quantity", 1) or 1),
                            unit_cost=float(item.get("unit_cost") or 0),
                            unit_price=float(l.get("unit_price") or 0),
                            reference=f"INV-{inv_id}",
                            source_doc_type="invoice",
                            source_doc_id=inv_id,
                            post_gl=True,
                        )
            _dup_conn.close()
        except Exception:
            pass

    return inv_id


def void_invoice(db_path, invoice_id):
    """
    Void an invoice:
      1. Set status to Void.
      2. If a GL journal was posted (invoice was Sent/Partial/Paid),
         post a reversing entry to undo AR / Income / GST.
    """
    conn = get_connection(db_path)
    inv  = conn.execute("SELECT * FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    conn.close()
    if not inv:
        return
    inv = dict(inv)

    # Reverse the original journal before voiding
    journal_id = inv.get("journal_id")
    if journal_id and inv.get("status") not in ("Draft", "Void"):
        reverse_journal(db_path, journal_id,
                        reverse_date=inv.get("invoice_date"))

    conn = get_connection(db_path)
    conn.execute("UPDATE invoices SET status=\'Void\' WHERE id=?", (invoice_id,))
    conn.commit()
    conn.close()

    # Free whatever this invoice billed on a job (tasks, visit hours,
    # material recharges) so it can be billed again, and void its claim.
    from core.job_billing import release_invoice
    release_invoice(db_path, invoice_id)



def copy_invoice(db_path, invoice_id):
    """Duplicate an invoice as a new Draft with today's date and a fresh invoice number."""
    data = get_invoice(db_path, invoice_id)
    if not data:
        raise ValueError("Invoice not found")
    inv   = data["invoice"]
    lines = data["lines"]

    from datetime import date as _date, timedelta
    today = _date.today()
    conn  = get_connection(db_path)
    terms = conn.execute(
        "SELECT payment_terms FROM contacts WHERE id=?",
        (inv["contact_id"],)).fetchone()
    conn.close()
    payment_terms = (terms["payment_terms"] if terms else None) or 30
    due_date = str(today + timedelta(days=int(payment_terms)))

    new_inv = {
        "contact_id":           inv["contact_id"],
        "invoice_date":         str(today),
        "due_date":             due_date,
        "status":               "Draft",
        "notes":                inv.get("notes"),
        "payment_instructions": inv.get("payment_instructions"),
        "internal_comments":    inv.get("internal_comments"),
    }
    new_lines = [{
        "description": l.get("description", ""),
        "quantity":    l.get("quantity", 1),
        "unit_price":  l.get("unit_price", 0),
        "tax_code":    l.get("tax_code", "GST"),
        "account_id":  l.get("account_id"),
        "item_id":     l.get("item_id"),
        "line_type":   l.get("line_type", "item"),
    } for l in lines]
    return save_invoice(db_path, new_inv, new_lines)


def copy_bill(db_path, bill_id):
    """Duplicate a bill as a new Draft with today's date. bill_number is left blank."""
    data = get_bill(db_path, bill_id)
    if not data:
        raise ValueError("Bill not found")
    bill  = data["bill"]
    lines = data["lines"]

    from datetime import date as _date, timedelta
    today = _date.today()
    conn  = get_connection(db_path)
    terms = conn.execute(
        "SELECT payment_terms FROM contacts WHERE id=?",
        (bill["contact_id"],)).fetchone()
    conn.close()
    payment_terms = (terms["payment_terms"] if terms else None) or 30
    due_date = str(today + timedelta(days=int(payment_terms)))

    new_bill = {
        "contact_id":  bill["contact_id"],
        "bill_date":   str(today),
        "due_date":    due_date,
        "bill_number": None,
        "status":      "Draft",
        "notes":       bill.get("notes"),
    }
    new_lines = [{
        "description": l.get("description", ""),
        "quantity":    l.get("quantity", 1),
        "unit_price":  l.get("unit_price", 0),
        "tax_code":    l.get("tax_code", "GST"),
        "account_id":  l.get("account_id"),
        "item_id":     l.get("item_id"),
    } for l in lines]
    return save_bill(db_path, new_bill, new_lines)


def create_credit_note(db_path, source_invoice_id, lines, note_date, memo=""):
    """
    Issue a credit note against a posted invoice.

    GL posted (opposite of original invoice):
      CR  AR (1-1200)            gross credit total   — reduces receivable
      DR  Income accounts        net per line          — reverses revenue
      DR  GST Collected (2-1200) gst total             — ATO decreasing adjustment

    If the source invoice has an outstanding balance, the credit is auto-applied
    (up to the outstanding amount). If the invoice is fully paid, the credit note
    is created as an unapplied credit (amount_applied=0) that can be applied to
    future invoices via apply_credit_note().

    CN total is capped at the original invoice total.
    Returns cn_id.
    """
    conn = get_connection(db_path)
    conn.execute("BEGIN IMMEDIATE")
    src = conn.execute("SELECT * FROM invoices WHERE id=?", (source_invoice_id,)).fetchone()
    if not src:
        conn.close()
        raise ValueError("Source invoice not found")
    src = dict(src)

    if src["status"] in ("Draft", "Void", "Written Off", "Credit Note"):
        conn.close()
        raise ValueError(f"Cannot credit a {src['status']} invoice")

    c = conn.cursor()
    item_lines = [l for l in lines if l.get("line_type", "item") != "comment"]
    subtotal = 0.0
    gst_total = 0.0
    for l in lines:
        if l.get("line_type", "item") == "comment":
            l["gst_amount"] = 0.0
            l["line_total"] = 0.0
            l.setdefault("quantity", 0)
            l.setdefault("unit_price", 0)
        else:
            line_ex = round(float(l["quantity"]) * float(l["unit_price"]), 2)
            l["gst_amount"] = _gst_amount(line_ex, l.get("tax_code", "GST"), conn)
            l["line_total"] = round(line_ex + l["gst_amount"], 2)
            subtotal += line_ex
            gst_total += l["gst_amount"]

    total = round(subtotal + gst_total, 2)
    src_total = float(src["total"] or 0)
    if total <= 0.005:
        conn.close()
        raise ValueError("Credit note total must be greater than zero")
    if total > src_total + 0.005:
        conn.close()
        raise ValueError(
            f"Credit note total ({total:.2f}) exceeds original invoice total ({src_total:.2f})")

    cn_num = _next_credit_note_number(conn)

    c.execute("""INSERT INTO invoices
        (invoice_number, contact_id, invoice_date, due_date, status,
         subtotal, gst_total, total, notes, is_credit_note, source_invoice_id, amount_applied)
        VALUES (?, ?, ?, ?, 'Credit Note', ?, ?, ?, ?, 1, ?, 0)""",
        (cn_num, src["contact_id"], note_date, note_date,
         round(subtotal, 2), round(gst_total, 2), total, memo, source_invoice_id))
    cn_id = c.lastrowid

    for l in lines:
        c.execute("""INSERT INTO invoice_lines
            (invoice_id, description, quantity, unit_price, tax_code,
             gst_amount, line_total, account_id, line_type)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (cn_id, l["description"], l.get("quantity", 0), l.get("unit_price", 0),
             l.get("tax_code", "GST"), l["gst_amount"], l["line_total"],
             l.get("account_id"), l.get("line_type", "item")))

    ar = conn.execute("SELECT id FROM accounts WHERE code='1-1200'").fetchone()
    gst_col = conn.execute("SELECT id FROM accounts WHERE code='2-1200'").fetchone()

    if ar and gst_col:
        desc = f"Credit Note {cn_num}"
        if memo:
            desc += f" — {memo}"
        c.execute("""INSERT INTO journal_entries
            (entry_date, reference, description, entry_type, source_id, source_type)
            VALUES (?, ?, ?, 'Credit Note', ?, 'credit_note')""",
            (note_date, cn_num, desc, cn_id))
        jid = c.lastrowid
        c.execute("UPDATE invoices SET journal_id=? WHERE id=?", (jid, cn_id))

        # CR AR — reduces receivable
        c.execute("""INSERT INTO journal_lines (journal_id, account_id, debit, credit)
            VALUES (?, ?, ?, ?)""", (jid, ar["id"], 0, total))

        # DR Income accounts per line — reverses revenue
        for l in item_lines:
            gl_acc = l.get("account_id")
            if gl_acc:
                acc_row = conn.execute(
                    "SELECT account_type FROM accounts WHERE id=?", (gl_acc,)).fetchone()
                if acc_row and acc_row["account_type"] not in (
                        "Income", "Revenue", "Other Income"):
                    gl_acc = None
            if not gl_acc:
                fallback = conn.execute(
                    "SELECT id FROM accounts "
                    "WHERE account_type IN ('Income','Revenue') "
                    "ORDER BY code LIMIT 1").fetchone()
                gl_acc = fallback["id"] if fallback else None
            if gl_acc:
                c.execute("""INSERT INTO journal_lines
                    (journal_id, account_id, debit, credit, gst_amount) VALUES (?,?,?,?,?)""",
                    (jid, gl_acc,
                     round(float(l["quantity"]) * float(l["unit_price"]), 2),
                     0, l["gst_amount"]))

        # DR GST Collected — ATO decreasing adjustment
        if gst_total != 0:
            c.execute("""INSERT INTO journal_lines (journal_id, account_id, debit, credit)
                VALUES (?, ?, ?, ?)""", (jid, gst_col["id"], round(gst_total, 2), 0))

    # Auto-apply to source invoice if it has outstanding balance
    outstanding = round(src_total - float(src["amount_paid"] or 0), 2)
    auto_applied = 0.0
    if outstanding > 0.005:
        apply_amount = round(min(total, outstanding), 2)
        new_paid = round(float(src["amount_paid"] or 0) + apply_amount, 2)
        if new_paid >= round(src_total - 0.005, 2):
            new_status = "Paid"
            new_paid = src_total
        else:
            new_status = "Partial"
        c.execute("UPDATE invoices SET amount_paid=?, status=? WHERE id=?",
                  (new_paid, new_status, source_invoice_id))
        auto_applied = apply_amount

    c.execute("UPDATE invoices SET amount_applied=? WHERE id=?", (auto_applied, cn_id))

    conn.commit()
    conn.close()
    return cn_id


def get_unapplied_credits(db_path, contact_id):
    """Return credit notes with remaining unapplied balance for a contact."""
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT id, invoice_number, invoice_date, total,
               COALESCE(amount_applied, 0) AS amount_applied,
               (total - COALESCE(amount_applied, 0)) AS remaining
        FROM invoices
        WHERE is_credit_note=1 AND contact_id=?
          AND (total - COALESCE(amount_applied, 0)) > 0.005
        ORDER BY invoice_date DESC
    """, (contact_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_unallocated_payments(db_path, contact_id):
    """Return receipt payments with unallocated balance for a contact.

    Unallocated balance includes both advance payments (not yet matched to an invoice)
    and overpayments (where the allocation to an invoice exceeds the invoice total).
    Invoice allocations are capped at the invoice total so the excess is surfaced here.
    """
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT p.id, p.payment_date, p.amount, p.reference, p.description,
               COALESCE(SUM(
                   CASE WHEN pa.invoice_id IS NOT NULL
                       THEN MIN(pa.amount, COALESCE(i.total, pa.amount))
                       ELSE pa.amount END
               ), 0) AS allocated,
               (p.amount - COALESCE(SUM(
                   CASE WHEN pa.invoice_id IS NOT NULL
                       THEN MIN(pa.amount, COALESCE(i.total, pa.amount))
                       ELSE pa.amount END
               ), 0)) AS unallocated
        FROM payments p
        LEFT JOIN payment_allocations pa ON pa.payment_id = p.id
        LEFT JOIN invoices i ON i.id = pa.invoice_id
        WHERE p.contact_id=? AND p.payment_type='Receipt'
          AND (p.expense_account_id IS NULL OR p.expense_account_id = 0)
        GROUP BY p.id
        HAVING (p.amount - COALESCE(SUM(
            CASE WHEN pa.invoice_id IS NOT NULL
                THEN MIN(pa.amount, COALESCE(i.total, pa.amount))
                ELSE pa.amount END
        ), 0)) > 0.005
        ORDER BY p.payment_date DESC
    """, (contact_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def apply_payment_to_invoice(db_path, payment_id, invoice_id, amount):
    """Apply an unallocated portion of an existing receipt to an outstanding invoice.

    Creates a payment_allocations record and updates invoice amount_paid/status.
    No GL entry needed — the payment journal already credited AR.
    """
    conn = get_connection(db_path)
    pmt = conn.execute("SELECT * FROM payments WHERE id=? AND payment_type='Receipt'",
                       (payment_id,)).fetchone()
    inv = conn.execute("SELECT * FROM invoices WHERE id=? AND (is_credit_note IS NULL OR is_credit_note=0)",
                       (invoice_id,)).fetchone()
    if not pmt:
        conn.close()
        raise ValueError("Payment not found")
    if not inv:
        conn.close()
        raise ValueError("Invoice not found")
    pmt, inv = dict(pmt), dict(inv)

    if int(pmt["contact_id"] or 0) != int(inv["contact_id"] or 0):
        conn.close()
        raise ValueError("Payment and invoice must be for the same customer")

    # Effective allocation: invoice allocs capped at invoice total so overpayments surface
    effective_alloc = conn.execute("""
        SELECT COALESCE(SUM(
            CASE WHEN pa.invoice_id IS NOT NULL
                THEN MIN(pa.amount, COALESCE(i.total, pa.amount))
                ELSE pa.amount END
        ), 0)
        FROM payment_allocations pa
        LEFT JOIN invoices i ON i.id = pa.invoice_id
        WHERE pa.payment_id=?
    """, (payment_id,)).fetchone()[0]

    unallocated = round(float(pmt["amount"]) - float(effective_alloc or 0), 2)
    outstanding  = round(float(inv["total"]) - float(inv.get("amount_paid") or 0), 2)

    if unallocated < 0.005:
        conn.close()
        raise ValueError("Payment has no unallocated balance")
    if outstanding < 0.005:
        conn.close()
        raise ValueError("Invoice has no outstanding balance")

    apply_amount = round(min(float(amount), unallocated, outstanding), 2)
    if apply_amount <= 0:
        conn.close()
        raise ValueError("Amount must be greater than zero")

    c = conn.cursor()

    # If raw allocation sum equals payment amount, the available balance comes from
    # over-allocated invoices — reclaim the excess before creating the new allocation
    raw_allocated = conn.execute(
        "SELECT COALESCE(SUM(amount),0) FROM payment_allocations WHERE payment_id=?",
        (payment_id,)).fetchone()[0]
    if float(raw_allocated or 0) >= float(pmt["amount"]) - 0.005:
        remaining = apply_amount
        over_allocs = conn.execute("""
            SELECT pa.id, pa.invoice_id, pa.amount, i.total
            FROM payment_allocations pa
            JOIN invoices i ON i.id = pa.invoice_id
            WHERE pa.payment_id=? AND pa.amount > i.total
            ORDER BY (pa.amount - i.total) DESC
        """, (payment_id,)).fetchall()
        for oa in over_allocs:
            if remaining <= 0.005:
                break
            oa = dict(oa)
            excess = round(float(oa["amount"]) - float(oa["total"]), 2)
            reclaim = round(min(excess, remaining), 2)
            c.execute("UPDATE payment_allocations SET amount=? WHERE id=?",
                      (round(float(oa["amount"]) - reclaim, 2), oa["id"]))
            c.execute("""UPDATE invoices
                SET amount_paid = MAX(0, amount_paid - ?),
                    status = CASE
                        WHEN status = 'Void' THEN 'Void'
                        WHEN (amount_paid - ?) <= 0 THEN 'Sent'
                        WHEN (amount_paid - ?) < total THEN 'Partial'
                        ELSE status END
                WHERE id=?""",
                (reclaim, reclaim, reclaim, oa["invoice_id"]))
            remaining = round(remaining - reclaim, 2)

    c.execute("INSERT INTO payment_allocations (payment_id,invoice_id,amount) VALUES (?,?,?)",
              (payment_id, invoice_id, apply_amount))

    new_paid = round(float(inv.get("amount_paid") or 0) + apply_amount, 2)
    inv_total = float(inv["total"])
    new_status = "Paid" if new_paid >= round(inv_total - 0.005, 2) else "Partial"
    if new_status == "Paid":
        new_paid = inv_total
    conn.execute("UPDATE invoices SET amount_paid=?, status=? WHERE id=?",
                 (new_paid, new_status, invoice_id))

    conn.commit()
    conn.close()
    return apply_amount


def apply_credit_note(db_path, cn_id, invoice_id, amount):
    """
    Apply an unapplied (or partially applied) credit note to an outstanding invoice.
    No GL entry is needed — the AR credit was already posted when the CN was created.
    Updates invoice amount_paid and CN amount_applied.
    Returns the amount actually applied.
    """
    conn = get_connection(db_path)
    cn  = conn.execute("SELECT * FROM invoices WHERE id=? AND is_credit_note=1",
                       (cn_id,)).fetchone()
    inv = conn.execute("SELECT * FROM invoices WHERE id=? AND (is_credit_note=0 OR is_credit_note IS NULL)",
                       (invoice_id,)).fetchone()
    conn.close()
    if not cn:  raise ValueError("Credit note not found")
    if not inv: raise ValueError("Invoice not found")
    cn, inv = dict(cn), dict(inv)

    if int(cn["contact_id"]) != int(inv["contact_id"]):
        raise ValueError("Credit note and invoice must be for the same customer")

    remaining = round(float(cn["total"]) - float(cn.get("amount_applied") or 0), 2)
    if remaining < 0.005:
        raise ValueError("Credit note has no remaining balance")

    outstanding = round(float(inv["total"]) - float(inv.get("amount_paid") or 0), 2)
    if outstanding < 0.005:
        raise ValueError("Invoice has no outstanding balance")

    amount = round(float(amount), 2)
    if amount <= 0:
        raise ValueError("Amount must be greater than zero")
    apply_amount = round(min(amount, remaining, outstanding), 2)

    conn = get_connection(db_path)
    c = conn.cursor()

    new_inv_paid = round(float(inv.get("amount_paid") or 0) + apply_amount, 2)
    inv_total = float(inv["total"])
    if new_inv_paid >= round(inv_total - 0.005, 2):
        new_inv_status = "Paid"
        new_inv_paid = inv_total
    else:
        new_inv_status = "Partial"
    c.execute("UPDATE invoices SET amount_paid=?, status=? WHERE id=?",
              (new_inv_paid, new_inv_status, invoice_id))

    new_applied = round(float(cn.get("amount_applied") or 0) + apply_amount, 2)
    c.execute("UPDATE invoices SET amount_applied=? WHERE id=?", (new_applied, cn_id))

    conn.commit()
    conn.close()
    return apply_amount


def write_off_invoice(db_path, invoice_id, write_off_account_id, memo,
                       mark_contact_inactive=False, inactive_reason=None):
    """
    Write off an outstanding invoice as a bad debt.

    Journal posted (entry_type='Bad Debt'):
      DR Bad Debts Expense (write_off_account_id)   net outstanding
      DR GST Collected (2-1200)                     GST component (ATO decreasing adjustment)
      CR Accounts Receivable (1-1200)               gross outstanding

    The GST debit flows through to the accrual BAS as a 1A decreasing adjustment,
    reducing the GST liability for the period in which the write-off is posted.
    """
    conn = get_connection(db_path)
    inv = conn.execute("SELECT * FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    conn.close()
    if not inv:
        raise ValueError("Invoice not found")
    inv = dict(inv)

    if inv["status"] in ("Draft", "Void", "Written Off"):
        raise ValueError(f"Cannot write off an invoice with status '{inv['status']}'")

    total       = float(inv.get("total") or 0)
    amount_paid = float(inv.get("amount_paid") or 0)
    outstanding = round(total - amount_paid, 2)
    if outstanding <= 0.005:
        raise ValueError("Invoice has no outstanding balance to write off")

    gst_total = float(inv.get("gst_total") or 0)
    gst_component = round(outstanding * (gst_total / total), 2) if total > 0 else 0.0
    net_component = round(outstanding - gst_component, 2)

    conn = get_connection(db_path)
    ar_acct      = conn.execute("SELECT id FROM accounts WHERE code='1-1200'").fetchone()
    gst_col_acct = conn.execute("SELECT id FROM accounts WHERE code='2-1200'").fetchone()
    if not ar_acct:
        conn.close()
        raise ValueError("Accounts Receivable account (1-1200) not found")

    inv_num     = inv.get("invoice_number") or f"INV-{invoice_id}"
    description = f"Bad debt write-off — {inv_num}"
    if memo:
        description += f" — {memo}"

    from datetime import date as _date
    today = str(_date.today())

    c = conn.cursor()
    c.execute("""INSERT INTO journal_entries
        (entry_date, reference, description, entry_type, source_id, source_type)
        VALUES (?, ?, ?, 'Bad Debt', ?, 'invoice')""",
        (today, f"WO-{inv_num}", description, invoice_id))
    jid = c.lastrowid

    c.execute("""INSERT INTO journal_lines (journal_id, account_id, debit, credit, description)
        VALUES (?, ?, ?, 0, ?)""",
        (jid, write_off_account_id, net_component, f"Bad debt expense — {inv_num}"))
    if gst_component > 0.005 and gst_col_acct:
        c.execute("""INSERT INTO journal_lines (journal_id, account_id, debit, credit, description)
            VALUES (?, ?, ?, 0, ?)""",
            (jid, gst_col_acct["id"], gst_component,
             f"GST decreasing adjustment — bad debt — {inv_num}"))
    c.execute("""INSERT INTO journal_lines (journal_id, account_id, debit, credit, description)
        VALUES (?, ?, 0, ?, ?)""",
        (jid, ar_acct["id"], outstanding, f"AR write-off — {inv_num}"))

    conn.execute("UPDATE invoices SET status='Written Off' WHERE id=?", (invoice_id,))

    if mark_contact_inactive and inv.get("contact_id"):
        conn.execute(
            "UPDATE contacts SET is_active=0, inactive_reason=? WHERE id=?",
            (inactive_reason or "Bad debt write-off", inv["contact_id"]))

    conn.commit()
    conn.close()
    return jid


def void_bill(db_path, bill_id):
    """
    Void a bill:
      1. Set status to Void.
      2. If a GL journal was posted (bill was Approved/Partial/Paid),
         post a reversing entry to undo AP / Expense / GST.
    """
    conn = get_connection(db_path)
    bill = conn.execute("SELECT * FROM bills WHERE id=?", (bill_id,)).fetchone()
    conn.close()
    if not bill:
        return
    bill = dict(bill)

    journal_id = bill.get("journal_id")
    if journal_id and bill.get("status") not in ("Draft", "Void"):
        reverse_journal(db_path, journal_id,
                        reverse_date=bill.get("bill_date"))

    conn = get_connection(db_path)
    conn.execute("UPDATE bills SET status=\'Void\' WHERE id=?", (bill_id,))
    conn.commit()
    conn.close()


def repair_orphaned_void_journals(db_path):
    """
    Find voided invoices/bills whose GL journals were never reversed — caused
    by the old 'except: pass' bug in void_invoice/void_bill — and post the
    missing reversals now.

    Detection: a voided document has journal_id J but no journal_entry with
    reference 'REV-<J>' exists.

    Returns: {invoices_repaired, bills_repaired, errors}
    """
    conn = get_connection(db_path)
    orphan_inv = conn.execute("""
        SELECT i.id, i.invoice_number, i.journal_id, i.invoice_date
        FROM invoices i
        WHERE i.status = 'Void'
          AND i.journal_id IS NOT NULL
          AND NOT EXISTS (
            SELECT 1 FROM journal_entries je
            WHERE je.reference = 'REV-' || CAST(i.journal_id AS TEXT)
          )
    """).fetchall()
    orphan_bill = conn.execute("""
        SELECT b.id, b.bill_number, b.journal_id, b.bill_date
        FROM bills b
        WHERE b.status = 'Void'
          AND b.journal_id IS NOT NULL
          AND NOT EXISTS (
            SELECT 1 FROM journal_entries je
            WHERE je.reference = 'REV-' || CAST(b.journal_id AS TEXT)
          )
    """).fetchall()
    conn.close()

    inv_repaired = 0
    bill_repaired = 0
    errors = []

    for row in orphan_inv:
        try:
            reverse_journal(db_path, row["journal_id"],
                            reverse_date=row["invoice_date"])
            inv_repaired += 1
        except Exception as e:
            errors.append(f"Invoice {row['invoice_number']} (journal {row['journal_id']}): {e}")

    for row in orphan_bill:
        try:
            reverse_journal(db_path, row["journal_id"],
                            reverse_date=row["bill_date"])
            bill_repaired += 1
        except Exception as e:
            errors.append(f"Bill {row['bill_number']} (journal {row['journal_id']}): {e}")

    return {
        "invoices_repaired": inv_repaired,
        "bills_repaired":    bill_repaired,
        "errors":            errors,
    }


def repair_missing_gl_journals(db_path):
    """
    Find approved/sent/partial/paid invoices and bills that have no GL journal
    entry (journal_id IS NULL). This happens when 'Mark Sent' or 'Approve' was
    used before the fix that made those actions post to the ledger.

    Idempotent — documents that already have a journal_id are skipped.

    Returns: {invoices_repaired, bills_repaired, errors}
    """
    conn = get_connection(db_path)
    missing_inv = conn.execute("""
        SELECT id FROM invoices
        WHERE status IN ('Sent','Approved','Partial','Paid')
          AND journal_id IS NULL
    """).fetchall()
    missing_bill = conn.execute("""
        SELECT id FROM bills
        WHERE status IN ('Approved','Partial','Paid')
          AND journal_id IS NULL
    """).fetchall()
    conn.close()

    inv_repaired = 0
    bill_repaired = 0
    errors = []

    for row in missing_inv:
        try:
            inv_data = get_invoice(db_path, row["id"])
            if inv_data:
                save_invoice(db_path, inv_data["invoice"], inv_data["lines"])
                inv_repaired += 1
        except Exception as e:
            errors.append(f"Invoice id={row['id']}: {e}")

    for row in missing_bill:
        try:
            bill_data = get_bill(db_path, row["id"])
            if bill_data:
                save_bill(db_path, bill_data["bill"], bill_data["lines"])
                bill_repaired += 1
        except Exception as e:
            errors.append(f"Bill id={row['id']}: {e}")

    return {
        "invoices_repaired": inv_repaired,
        "bills_repaired":    bill_repaired,
        "errors":            errors,
    }


def approve_invoice(db_path, invoice_id):
    """Advance a Draft invoice to Approved (internal sign-off; GL posted when sent)."""
    conn = get_connection(db_path)
    conn.execute("UPDATE invoices SET status='Approved' WHERE id=? AND status='Draft'",
                 (invoice_id,))
    conn.commit()
    conn.close()


def mark_invoice_sent(db_path, invoice_id):
    """Advance a Draft or Approved invoice to Sent and post the GL journal entry."""
    conn = get_connection(db_path)
    changed = conn.execute(
        "UPDATE invoices SET status='Sent' WHERE id=? AND status IN ('Draft','Approved')",
        (invoice_id,)).rowcount
    conn.commit()
    conn.close()
    if changed:
        # Post GL via save_invoice so all journal logic stays in one place.
        inv_data = get_invoice(db_path, invoice_id)
        if inv_data:
            save_invoice(db_path, {**inv_data["invoice"], "status": "Sent"},
                         inv_data["lines"])

# ── Bills ─────────────────────────────────────────────────────────────────────

def get_bills(db_path, status=None, contact_id=None, opp_id=None, job_id=None):
    conn = get_connection(db_path)
    q = """SELECT b.*, c.name as contact_name
           FROM bills b JOIN contacts c ON b.contact_id=c.id WHERE 1=1"""
    params = []
    if status:
        q += " AND b.status=?"
        params.append(status)
    if contact_id:
        q += " AND b.contact_id=?"
        params.append(contact_id)
    if opp_id:
        q += " AND b.opp_id=?"
        params.append(opp_id)
    if job_id:
        q += " AND b.job_id=?"
        params.append(job_id)
    q += " ORDER BY b.bill_date DESC, b.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_bill(db_path, bill_id):
    conn = get_connection(db_path)
    bill = conn.execute("""SELECT b.*, c.name as contact_name
        FROM bills b JOIN contacts c ON b.contact_id=c.id
        WHERE b.id=?""", (bill_id,)).fetchone()
    lines = conn.execute("""SELECT bl.*, a.name as account_name
        FROM bill_lines bl LEFT JOIN accounts a ON bl.account_id=a.id
        WHERE bl.bill_id=? ORDER BY bl.id""", (bill_id,)).fetchall()
    conn.close()
    if not bill:
        return None
    return {"bill": dict(bill), "lines": [dict(l) for l in lines]}


def save_bill(db_path, bill_data, lines, skip_gl=False):
    conn = get_connection(db_path)
    c = conn.cursor()
    subtotal = sum(l["quantity"] * l["unit_price"] for l in lines if l.get("line_type") != "comment")
    gst_total = 0.0
    for l in lines:
        if l.get("line_type") == "comment":
            l["gst_amount"] = 0.0
            l["line_total"] = 0.0
            continue
        line_ex = l["quantity"] * l["unit_price"]
        l["gst_amount"] = _gst_amount(line_ex, l.get("tax_code", "GST"), conn)
        l["line_total"] = round(line_ex + l["gst_amount"], 2)
        gst_total += l["gst_amount"]
    total = round(subtotal + gst_total, 2)
    bill_id = bill_data.get("id")
    if bill_id:
        c.execute("""UPDATE bills SET contact_id=?,bill_date=?,due_date=?,
            bill_number=?,status=?,subtotal=?,gst_total=?,total=?,notes=?,opp_id=?
            WHERE id=?""",
            (bill_data["contact_id"], bill_data["bill_date"], bill_data["due_date"],
             bill_data.get("bill_number"), bill_data.get("status", "Draft"),
             subtotal, gst_total, total, bill_data.get("notes"), bill_data.get("opp_id"), bill_id))
        # Preserve qty_received per item_id before wiping lines
        prev_received = {}
        for row in c.execute(
                "SELECT item_id, qty_received FROM bill_lines WHERE bill_id=? AND item_id IS NOT NULL",
                (bill_id,)).fetchall():
            if row["qty_received"]:
                prev_received[row["item_id"]] = float(row["qty_received"])
        c.execute("DELETE FROM bill_lines WHERE bill_id=?", (bill_id,))
    else:
        prev_received = {}
        c.execute("""INSERT INTO bills
            (contact_id,bill_date,due_date,bill_number,status,
             subtotal,gst_total,total,notes,opp_id)
            VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (bill_data["contact_id"], bill_data["bill_date"], bill_data["due_date"],
             bill_data.get("bill_number"), bill_data.get("status", "Draft"),
             subtotal, gst_total, total, bill_data.get("notes"), bill_data.get("opp_id")))
        bill_id = c.lastrowid
    for l in lines:
        qty_received = prev_received.get(l.get("item_id"), 0.0) if l.get("item_id") else 0.0
        c.execute("""INSERT INTO bill_lines
            (bill_id,description,quantity,unit_price,tax_code,
             gst_amount,line_total,account_id,item_id,qty_received,line_type)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (bill_id, l["description"], l["quantity"], l["unit_price"],
             l.get("tax_code", "GST"), l["gst_amount"], l["line_total"],
             l.get("account_id"), l.get("item_id"), qty_received or None,
             l.get("line_type", "item")))
    if not skip_gl and bill_data.get("status", "Draft") != "Draft":
        ap = conn.execute("SELECT id FROM accounts WHERE code=\'2-1100\'").fetchone()
        gst_in = conn.execute("SELECT id FROM accounts WHERE code=\'1-1300\'").fetchone()
        if ap and gst_in:
            existing = conn.execute(
                "SELECT journal_id FROM bills WHERE id=?", (bill_id,)).fetchone()
            old_jid = existing["journal_id"] if existing else None
            if old_jid:
                c.execute("DELETE FROM journal_lines WHERE journal_id=?", (old_jid,))
                c.execute("""UPDATE journal_entries
                    SET entry_date=?, reference=?, description=? WHERE id=?""",
                    (bill_data["bill_date"], bill_data.get("bill_number", ""),
                     "Bill " + str(bill_id), old_jid))
                jid = old_jid
            else:
                c.execute("""INSERT INTO journal_entries
                    (entry_date,reference,description,entry_type,source_id,source_type)
                    VALUES (?,?,?,?,?,?)""",
                    (bill_data["bill_date"], bill_data.get("bill_number",""),
                     "Bill " + str(bill_id), "Bill", bill_id, "bill"))
                jid = c.lastrowid
                c.execute("UPDATE bills SET journal_id=? WHERE id=?", (jid, bill_id))
            c.execute("""INSERT INTO journal_lines
                (journal_id,account_id,debit,credit) VALUES (?,?,?,?)""",
                (jid, ap["id"], 0, total))
            for l in lines:
                if l.get("line_type") == "comment":
                    continue
                gl_acc = l.get("account_id")
                # For inventoried items: debit Inventory Asset, not the expense
                # account. The expense (COGS) is recognised when items are sold.
                if l.get("item_id"):
                    from core.inventory import get_inventory_item
                    inv_item = get_inventory_item(db_path, l["item_id"])
                    if inv_item and inv_item.get("is_inventoried") and                             inv_item.get("stock_account_id"):
                        gl_acc = inv_item["stock_account_id"]
                # Guard: bill debit must be Expense/Asset — not Income.
                # If account_id is Income/Revenue or None, fall back to expense.
                if gl_acc:
                    acc_row = conn.execute(
                        "SELECT account_type FROM accounts WHERE id=?",
                        (gl_acc,)).fetchone()
                    if acc_row and acc_row["account_type"] in ("Income", "Revenue", "Other Income"):
                        gl_acc = None  # trigger fallback
                if not gl_acc:
                    fallback = conn.execute(
                        "SELECT id FROM accounts "
                        "WHERE account_type IN (\'Expense\',\'Cost of Sales\') "
                        "ORDER BY code LIMIT 1").fetchone()
                    gl_acc = fallback["id"] if fallback else None
                if gl_acc:
                    c.execute("""INSERT INTO journal_lines
                        (journal_id,account_id,debit,credit,gst_amount)
                        VALUES (?,?,?,?,?)""",
                        (jid, gl_acc,
                         round(l["quantity"]*l["unit_price"],2), 0, l["gst_amount"]))
            if gst_total != 0:
                c.execute("""INSERT INTO journal_lines
                    (journal_id,account_id,debit,credit) VALUES (?,?,?,?)""",
                    (jid, gst_in["id"], gst_total, 0))
    conn.commit()
    conn.close()

    # ── Inventory: trigger PURCHASE movement for tracked items ─────────────────
    # Skip if Receive Stock has already been used for this bill (would double-count).
    if bill_data.get("status", "Draft") not in ("Draft", "Void"):
        try:
            from core.inventory import post_stock_movement, get_inventory_item
            from core.database import get_connection as _gc
            _conn = _gc(db_path)
            for l in lines:
                if l.get("item_id"):
                    item = get_inventory_item(db_path, l["item_id"])
                    if item and item.get("is_inventoried"):
                        already = _conn.execute(
                            """SELECT id FROM inventory_movements
                               WHERE source_doc_type='bill' AND source_doc_id=?
                                 AND item_id=? AND movement_type='PURCHASE'
                               LIMIT 1""",
                            (bill_id, l["item_id"])).fetchone()
                        if already:
                            continue  # Receive Stock already posted this movement
                        post_stock_movement(
                            db_path, l["item_id"], "PURCHASE",
                            bill_data.get("bill_date", str(__import__('datetime').date.today())),
                            float(l.get("quantity", 1) or 1),
                            unit_cost=float(l.get("unit_price") or 0),
                            reference=f"BILL-{bill_id}",
                            source_doc_type="bill",
                            source_doc_id=bill_id,
                            post_gl=False,  # GL posted in bill journal above
                        )
            _conn.close()
        except Exception:
            pass

    return bill_id



def mark_bill_approved(db_path, bill_id):
    """Advance a Draft bill to Approved and post the GL journal entry."""
    conn = get_connection(db_path)
    changed = conn.execute(
        "UPDATE bills SET status='Approved' WHERE id=? AND status='Draft'",
        (bill_id,)).rowcount
    conn.commit()
    conn.close()
    if changed:
        bill_data = get_bill(db_path, bill_id)
        if bill_data:
            save_bill(db_path, {**bill_data["bill"], "status": "Approved"},
                      bill_data["lines"])

# ── Payments ──────────────────────────────────────────────────────────────────

def record_payment(db_path, pmt_data, allocations):
    conn = get_connection(db_path)
    c = conn.cursor()
    c.execute("""INSERT INTO payments
        (payment_type,contact_id,payment_date,amount,bank_account_id,
         reference,description,job_id,expense_account_id)
        VALUES (?,?,?,?,?,?,?,?,?)""",
        (pmt_data["payment_type"], pmt_data.get("contact_id"),
         pmt_data["payment_date"], pmt_data["amount"],
         pmt_data["bank_account_id"], pmt_data.get("reference"),
         pmt_data.get("description"),
         pmt_data.get("job_id"),
         pmt_data.get("expense_account_id")))
    pmt_id = c.lastrowid
    for alloc in allocations:
        c.execute("""INSERT INTO payment_allocations
            (payment_id,invoice_id,bill_id,amount) VALUES (?,?,?,?)""",
            (pmt_id, alloc.get("invoice_id"), alloc.get("bill_id"), alloc["amount"]))
        if alloc.get("invoice_id"):
            conn.execute("""UPDATE invoices SET amount_paid=amount_paid+?,
                status=CASE WHEN (amount_paid+?)>=total THEN \'Paid\'
                WHEN (amount_paid+?)>0 THEN \'Partial\' ELSE status END
                WHERE id=?""",
                (alloc["amount"],)*3 + (alloc["invoice_id"],))
        if alloc.get("bill_id"):
            conn.execute("""UPDATE bills SET amount_paid=amount_paid+?,
                status=CASE WHEN (amount_paid+?)>=total THEN \'Paid\'
                WHEN (amount_paid+?)>0 THEN \'Partial\' ELSE status END
                WHERE id=?""",
                (alloc["amount"],)*3 + (alloc["bill_id"],))
    ar = conn.execute("SELECT id FROM accounts WHERE code='1-1200'").fetchone()
    ap = conn.execute("SELECT id FROM accounts WHERE code='2-1100'").fetchone()
    c.execute("""INSERT INTO journal_entries
        (entry_date,reference,description,entry_type,source_id,source_type)
        VALUES (?,?,?,?,?,?)""",
        (pmt_data["payment_date"], pmt_data.get("reference",""),
         pmt_data.get("description","Payment"),
         pmt_data["payment_type"], pmt_id, "payment"))
    jid = c.lastrowid
    amount  = pmt_data["amount"]
    bank    = pmt_data["bank_account_id"]
    exp_acc = pmt_data.get("expense_account_id")

    # GST calculation for direct GL allocation
    gst_amount = 0.0
    tax_code   = None
    if exp_acc:
        tax_code = pmt_data.get("tax_code", "N-T") or "N-T"
        tr = conn.execute("SELECT rate FROM tax_codes WHERE code=?", (tax_code,)).fetchone()
        if tr and tr["rate"]:
            gst_amount = round(amount * tr["rate"] / (1 + tr["rate"]), 2)

    gst_col_acc = conn.execute("SELECT id FROM accounts WHERE code='2-1200'").fetchone()
    gst_paid_acc = conn.execute("SELECT id FROM accounts WHERE code='1-1300'").fetchone()

    if pmt_data["payment_type"] == "Receipt":
        c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                  (jid, bank, amount, 0))
        if exp_acc:
            net = amount - gst_amount
            c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit,tax_code,gst_amount) VALUES (?,?,?,?,?,?)",
                      (jid, exp_acc, 0, net, tax_code, gst_amount))
            if gst_amount and gst_col_acc:
                c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                          (jid, gst_col_acc["id"], 0, gst_amount))
        elif ar:
            c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                      (jid, ar["id"], 0, amount))
    else:
        c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                  (jid, bank, 0, amount))
        if exp_acc:
            net = amount - gst_amount
            c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit,tax_code,gst_amount) VALUES (?,?,?,?,?,?)",
                      (jid, exp_acc, net, 0, tax_code, gst_amount))
            if gst_amount and gst_paid_acc:
                c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                          (jid, gst_paid_acc["id"], gst_amount, 0))
        elif ap:
            c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                      (jid, ap["id"], amount, 0))
    c.execute("UPDATE payments SET journal_id=? WHERE id=?", (jid, pmt_id))
    conn.commit()
    conn.close()
    return pmt_id


def record_batch_payments(db_path, kind, payment_date, bank_account_id, reference, items):
    """Pay several invoices (kind='invoice') or bills (kind='bill') at once.

    items: [{"id": invoice/bill id, "amount": amount to pay}]. Every row is checked
    before anything is recorded. Records one payment per customer/supplier, allocated
    across that contact's rows, so a remittance covering three invoices is one receipt.
    Bank Rec can match one bank line to several of these payments.
    Returns the new payment ids, in the order the contacts first appear."""
    if kind not in ("invoice", "bill"):
        raise ValueError("kind must be 'invoice' or 'bill'")
    if not items:
        raise ValueError("Nothing to pay")
    if not bank_account_id:
        raise ValueError("Choose the account the money went in or out of")
    table, num_col = ("invoices", "invoice_number") if kind == "invoice" else ("bills", "bill_number")
    closed = ("Draft", "Approved", "Void", "Paid", "Written Off") if kind == "invoice" \
        else ("Draft", "Void", "Paid")

    conn = get_connection(db_path)
    try:
        if not conn.execute("SELECT 1 FROM accounts WHERE id=?", (bank_account_id,)).fetchone():
            raise ValueError("Account not found")
        groups, seen = {}, set()
        for it in items:
            rid = int(it.get("id") or 0)
            amount = round(float(it.get("amount") or 0), 2)
            if rid in seen:
                raise ValueError("The same item is listed twice")
            seen.add(rid)
            row = conn.execute(f"SELECT * FROM {table} WHERE id=?", (rid,)).fetchone()
            if not row:
                raise ValueError(f"{kind.title()} {rid} not found")
            row = dict(row)
            label = row.get(num_col) or f"#{rid}"
            if row["status"] in closed or row.get("is_credit_note"):
                raise ValueError(f"{label} can't take a payment ({row['status']})")
            balance = round((row["total"] or 0) - (row["amount_paid"] or 0), 2)
            if amount <= 0:
                raise ValueError(f"Enter an amount for {label}")
            if amount > balance + 0.005:
                raise ValueError(f"{label}: {amount:.2f} is more than the {balance:.2f} owing")
            groups.setdefault(row["contact_id"], []).append((rid, label, amount))
    finally:
        conn.close()

    key = "invoice_id" if kind == "invoice" else "bill_id"
    word = "Invoice payment" if kind == "invoice" else "Bill payment"
    ids = []
    for contact_id, rows in groups.items():
        ids.append(record_payment(db_path, {
            "payment_type":    "Receipt" if kind == "invoice" else "Payment",
            "contact_id":      contact_id,
            "payment_date":    payment_date,
            "amount":          round(sum(r[2] for r in rows), 2),
            "bank_account_id": bank_account_id,
            "reference":       reference or "",
            "description":     f"{word} — " + ", ".join(r[1] for r in rows),
        }, [{key: r[0], "amount": r[2]} for r in rows]))
    return ids


def get_payment(db_path, payment_id):
    conn = get_connection(db_path)
    row  = conn.execute("""SELECT p.*, c.name as contact_name, a.name as bank_name
           FROM payments p
           LEFT JOIN contacts c ON p.contact_id=c.id
           LEFT JOIN accounts  a ON p.bank_account_id=a.id
           WHERE p.id=?""", (payment_id,)).fetchone()
    allocs = conn.execute("""SELECT pa.*, i.invoice_number, b.bill_number
           FROM payment_allocations pa
           LEFT JOIN invoices i ON pa.invoice_id=i.id
           LEFT JOIN bills    b ON pa.bill_id=b.id
           WHERE pa.payment_id=?""", (payment_id,)).fetchall()
    conn.close()
    if not row:
        return None
    return {"payment": dict(row), "allocations": [dict(a) for a in allocs]}


def void_payment(db_path, payment_id):
    """
    Void a payment:
      1. Reverse amount_paid on every allocated invoice/bill and recalculate status.
      2. Post a reversing journal entry.
      3. Delete payment_allocations and the payment row.
    """
    from datetime import date as _date
    conn = get_connection(db_path)
    c    = conn.cursor()

    pmt = conn.execute("SELECT * FROM payments WHERE id=?", (payment_id,)).fetchone()
    if not pmt:
        conn.close()
        raise ValueError(f"Payment {payment_id} not found")

    pmt = dict(pmt)
    allocs = conn.execute(
        "SELECT * FROM payment_allocations WHERE payment_id=?",
        (payment_id,)).fetchall()

    # 1. Reverse allocations on invoices / bills
    for a in allocs:
        a = dict(a)
        if a.get("invoice_id"):
            conn.execute("""UPDATE invoices
                SET amount_paid = MAX(0, amount_paid - ?),
                    status = CASE
                        WHEN status = 'Void' THEN 'Void'
                        WHEN (amount_paid - ?) <= 0 THEN 'Sent'
                        WHEN (amount_paid - ?) < total  THEN 'Partial'
                        ELSE status END
                WHERE id=?""",
                (a["amount"], a["amount"], a["amount"], a["invoice_id"]))
        if a.get("bill_id"):
            conn.execute("""UPDATE bills
                SET amount_paid = MAX(0, amount_paid - ?),
                    status = CASE
                        WHEN status = 'Void' THEN 'Void'
                        WHEN (amount_paid - ?) <= 0 THEN 'Approved'
                        WHEN (amount_paid - ?) < total  THEN 'Partial'
                        ELSE status END
                WHERE id=?""",
                (a["amount"], a["amount"], a["amount"], a["bill_id"]))

    # 2. Post reversing journal entry dated to the original payment date
    c.execute("""INSERT INTO journal_entries
        (entry_date, reference, description, entry_type, source_id, source_type)
        VALUES (?,?,?,?,?,?)""",
        (pmt["payment_date"],
         pmt.get("reference") or "",
         f"VOID: {pmt.get('description') or pmt['payment_type']} #{payment_id}",
         "Void", payment_id, "payment_void"))
    jid = c.lastrowid

    orig_journal_id = pmt.get("journal_id")
    if orig_journal_id:
        # Reverse the original lines exactly — handles exp_acc (cash sales / direct
        # expenses) as well as normal AR/AP payments without needing to reconstruct
        # the logic here.
        orig_lines = conn.execute(
            "SELECT account_id, debit, credit, is_reconciled, reconciled_date FROM journal_lines WHERE journal_id=?",
            (orig_journal_id,)
        ).fetchall()
        for line in orig_lines:
            c.execute(
                "INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                (jid, line["account_id"], line["credit"], line["debit"])
            )

        # If any bank lines in the original payment were already bank-reconciled,
        # carry that status to the void reversal lines. The reversal is an accounting
        # correction — there is no new bank statement movement to match against.
        reconciled_bank_lines = conn.execute("""
            SELECT jl.account_id, jl.reconciled_date
            FROM journal_lines jl
            JOIN accounts a ON a.id = jl.account_id
            WHERE jl.journal_id = ? AND jl.is_reconciled = 1 AND a.is_bank = 1
        """, (orig_journal_id,)).fetchall()
        for rec in reconciled_bank_lines:
            conn.execute("""
                UPDATE journal_lines SET is_reconciled = 1, reconciled_date = ?
                WHERE journal_id = ? AND account_id = ?
            """, (rec["reconciled_date"], jid, rec["account_id"]))
    else:
        # Fallback for legacy payments where journal_id was not recorded
        ar   = conn.execute("SELECT id FROM accounts WHERE code='1-1200'").fetchone()
        ap   = conn.execute("SELECT id FROM accounts WHERE code='2-1100'").fetchone()
        bank = pmt["bank_account_id"]
        amt  = pmt["amount"]
        if pmt["payment_type"] == "Receipt":
            c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                      (jid, bank, 0, amt))
            if ar:
                c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                          (jid, ar["id"], amt, 0))
        else:
            c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                      (jid, bank, amt, 0))
            if ap:
                c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                          (jid, ap["id"], 0, amt))

    # 3. Remove allocations and payment
    c.execute("DELETE FROM payment_allocations WHERE payment_id=?", (payment_id,))
    c.execute("DELETE FROM payments WHERE id=?", (payment_id,))

    conn.commit()
    conn.close()


def amend_payment(db_path, payment_id, new_data, new_allocations):
    """
    Amend a payment by voiding it and re-recording with updated data.
    Warranties linked to the original payment are re-linked to the new payment id.
    Returns the new payment id.
    """
    orig = get_payment(db_path, payment_id)
    if not orig:
        raise ValueError(f"Payment {payment_id} not found")

    # Preserve job/expense_account from original unless caller overrides
    new_data.setdefault("job_id",             orig["payment"].get("job_id"))
    new_data.setdefault("expense_account_id", orig["payment"].get("expense_account_id"))

    # Void the original (reverses allocations, posts reversing journal)
    void_payment(db_path, payment_id)

    # Re-record with updated data
    new_id = record_payment(db_path, new_data, new_allocations)

    # Migrate warranties from old id → new id so they aren't orphaned
    conn = get_connection(db_path)
    conn.execute(
        "UPDATE warranties SET source_id=?, updated_at=datetime('now','localtime') "
        "WHERE source_type='payment' AND source_id=?",
        (new_id, payment_id))
    conn.commit()
    conn.close()

    return new_id


def get_payments(db_path, payment_type=None, contact_id=None):
    conn = get_connection(db_path)
    q = """SELECT p.*, c.name as contact_name, a.name as bank_name
           FROM payments p
           LEFT JOIN contacts c ON p.contact_id=c.id
           LEFT JOIN accounts a ON p.bank_account_id=a.id WHERE 1=1"""
    params = []
    if payment_type:
        q += " AND p.payment_type=?"
        params.append(payment_type)
    if contact_id:
        q += " AND p.contact_id=?"
        params.append(contact_id)
    q += " ORDER BY p.payment_date DESC, p.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ── General Journal ───────────────────────────────────────────────────────────

def post_journal(db_path, entry_date, description, reference, lines):
    """Post a manual journal entry. lines = list of {account_id, debit, credit, description}"""
    conn = get_connection(db_path)
    c = conn.cursor()
    c.execute("""INSERT INTO journal_entries
        (entry_date,reference,description,entry_type)
        VALUES (?,?,?,\'Journal\')""",
        (entry_date, reference, description))
    jid = c.lastrowid
    for l in lines:
        c.execute("""INSERT INTO journal_lines
            (journal_id,account_id,debit,credit,description)
            VALUES (?,?,?,?,?)""",
            (jid, l["account_id"], l.get("debit",0), l.get("credit",0),
             l.get("description","")))
    conn.commit()
    conn.close()
    return jid


def get_journal_entries(db_path, limit=200):
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT * FROM journal_entries
        ORDER BY entry_date DESC, id DESC LIMIT ?""", (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_journal_lines(db_path, journal_id):
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT jl.*, a.code, a.name as account_name
        FROM journal_lines jl JOIN accounts a ON jl.account_id=a.id
        WHERE jl.journal_id=? ORDER BY jl.id""", (journal_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ── Bank Reconciliation ───────────────────────────────────────────────────────

def get_bank_journal_transactions(db_path, account_id):
    """Return all journal lines posted to account_id, for bank reconciliation."""
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT jl.id, je.entry_date as transaction_date,
               COALESCE(jl.description, je.description, '') as description,
               COALESCE(je.reference, '')                   as reference,
               jl.debit, jl.credit,
               jl.is_reconciled, jl.reconciled_date,
               jl.is_rejected,
               je.entry_type, je.source_type, je.source_id,
               je.id as journal_id
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id = je.id
        WHERE jl.account_id = ?
        ORDER BY je.entry_date, je.id
    """, (account_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def reconcile_journal_line(db_path, line_id, reconcile=True):
    """Toggle reconciliation on a journal_line."""
    from datetime import date as _date
    conn = get_connection(db_path)
    if reconcile:
        conn.execute(
            "UPDATE journal_lines SET is_reconciled=1, reconciled_date=? WHERE id=?",
            (str(_date.today()), line_id))
    else:
        conn.execute(
            "UPDATE journal_lines SET is_reconciled=0, reconciled_date=NULL WHERE id=?",
            (line_id,))
    conn.commit()
    conn.close()


def allocate_bank_transaction(db_path, bank_txn_id, mode, alloc_data):
    """
    Allocate an imported bank transaction to the ledger.

    mode: "account"  → post a journal entry to a GL account
          "invoice"  → record a receipt against an invoice
          "bill"     → record a payment against a bill

    alloc_data keys:
      account:  { account_id, tax_code, description }
      invoice:  { invoice_id, amount, contact_id, description }
      bill:     { bill_id,    amount, contact_id, description }
    """
    from datetime import date as _date

    conn = get_connection(db_path)
    c    = conn.cursor()

    txn  = conn.execute("SELECT * FROM bank_transactions WHERE id=?",
                        (bank_txn_id,)).fetchone()
    if not txn:
        conn.close()
        raise ValueError(f"Bank transaction {bank_txn_id} not found")

    txn = dict(txn)
    if txn.get("journal_id") or txn.get("alloc_mode") == "match":
        conn.close()
        raise ValueError("Transaction is already allocated — deallocate first")

    bank_id   = txn["account_id"]
    txn_date  = txn["transaction_date"]
    amount    = (txn["debit"] or 0) or (txn["credit"] or 0)
    is_credit = (txn["credit"] or 0) > 0   # money coming IN to bank

    # For liability accounts (CC/loan): stored credit = charge (increases liability).
    # The posting direction must be flipped so we CREDIT the CC account on a charge.
    acc_row = conn.execute("SELECT account_type FROM accounts WHERE id=?", (bank_id,)).fetchone()
    is_liability = acc_row and acc_row["account_type"] == "Liability"
    posting_is_credit = is_credit if not is_liability else not is_credit

    if mode == "account":
        gl_id    = alloc_data["account_id"]
        if gl_id == bank_id:
            conn.close()
            raise ValueError("Cannot allocate a transaction to the account being reconciled")
        tax_code = alloc_data.get("tax_code", "N-T")
        desc     = alloc_data.get("description") or txn["description"] or "Bank allocation"
        contact_id = alloc_data.get("contact_id")

        # GST calculation
        tax_rate = 0.0
        tr = conn.execute("SELECT rate FROM tax_codes WHERE code=?", (tax_code,)).fetchone()
        if tr:
            tax_rate = tr["rate"]
        gst_amount = round(amount * tax_rate / (1 + tax_rate), 2) if tax_rate else 0.0

        # Journal entry
        c.execute("""INSERT INTO journal_entries
            (entry_date, reference, description, entry_type, source_type, contact_id)
            VALUES (?,?,?,?,?,?)""",
            (txn_date, txn.get("reference",""), desc,
             "Bank Allocation", "bank_transaction", contact_id))
        jid = c.lastrowid

        # Bank line — posting_is_credit=True: money IN (asset) or payment (liability)
        if posting_is_credit:
            c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                      (jid, bank_id, amount, 0))
            c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit,tax_code,gst_amount) VALUES (?,?,?,?,?,?)",
                      (jid, gl_id, 0, amount - gst_amount, tax_code, gst_amount))
        else:
            c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                      (jid, bank_id, 0, amount))
            c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit,tax_code,gst_amount) VALUES (?,?,?,?,?,?)",
                      (jid, gl_id, amount - gst_amount, 0, tax_code, gst_amount))

        # GST line: posting_is_credit=True → income → GST Collected (2-1200)
        #           posting_is_credit=False → expense → GST Paid (1-1300)
        if gst_amount:
            gst_acc = conn.execute(
                "SELECT id FROM accounts WHERE code=?",
                ("2-1200" if posting_is_credit else "1-1300",)).fetchone()
            if gst_acc:
                if posting_is_credit:
                    c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                              (jid, gst_acc["id"], 0, gst_amount))
                else:
                    c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                              (jid, gst_acc["id"], gst_amount, 0))

    elif mode == "invoice":
        inv_id  = alloc_data["invoice_id"]
        amt     = alloc_data["amount"]
        desc    = alloc_data.get("description") or txn["description"] or "Receipt"
        contact = alloc_data.get("contact_id")

        c.execute("""INSERT INTO payments
            (payment_type,contact_id,payment_date,amount,bank_account_id,reference,description)
            VALUES (?,?,?,?,?,?,?)""",
            ("Receipt", contact, txn_date, amt, bank_id,
             txn.get("reference",""), desc))
        pmt_id = c.lastrowid
        c.execute("INSERT INTO payment_allocations (payment_id,invoice_id,amount) VALUES (?,?,?)",
                  (pmt_id, inv_id, amt))
        conn.execute("""UPDATE invoices SET amount_paid=amount_paid+?,
            status=CASE WHEN (amount_paid+?)>=total THEN 'Paid'
                        WHEN (amount_paid+?)>0 THEN 'Partial' ELSE status END
            WHERE id=?""", (amt,)*3 + (inv_id,))

        ar = conn.execute("SELECT id FROM accounts WHERE code='1-1200'").fetchone()
        c.execute("""INSERT INTO journal_entries
            (entry_date,reference,description,entry_type,source_id,source_type)
            VALUES (?,?,?,?,?,?)""",
            (txn_date, txn.get("reference",""), desc, "Receipt", pmt_id, "payment"))
        jid = c.lastrowid
        c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                  (jid, bank_id, amt, 0))
        if ar:
            c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                      (jid, ar["id"], 0, amt))
        c.execute("UPDATE payments SET journal_id=? WHERE id=?", (jid, pmt_id))

    elif mode == "bill":
        bill_id = alloc_data["bill_id"]
        amt     = alloc_data["amount"]
        desc    = alloc_data.get("description") or txn["description"] or "Payment"
        contact = alloc_data.get("contact_id")

        c.execute("""INSERT INTO payments
            (payment_type,contact_id,payment_date,amount,bank_account_id,reference,description)
            VALUES (?,?,?,?,?,?,?)""",
            ("Payment", contact, txn_date, amt, bank_id,
             txn.get("reference",""), desc))
        pmt_id = c.lastrowid
        c.execute("INSERT INTO payment_allocations (payment_id,bill_id,amount) VALUES (?,?,?)",
                  (pmt_id, bill_id, amt))
        conn.execute("""UPDATE bills SET amount_paid=amount_paid+?,
            status=CASE WHEN (amount_paid+?)>=total THEN 'Paid'
                        WHEN (amount_paid+?)>0 THEN 'Partial' ELSE status END
            WHERE id=?""", (amt,)*3 + (bill_id,))

        ap = conn.execute("SELECT id FROM accounts WHERE code='2-1100'").fetchone()
        c.execute("""INSERT INTO journal_entries
            (entry_date,reference,description,entry_type,source_id,source_type)
            VALUES (?,?,?,?,?,?)""",
            (txn_date, txn.get("reference",""), desc, "Payment", pmt_id, "payment"))
        jid = c.lastrowid
        c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                  (jid, bank_id, 0, amt))
        if ap:
            c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                      (jid, ap["id"], amt, 0))
        c.execute("UPDATE payments SET journal_id=? WHERE id=?", (jid, pmt_id))

    else:
        conn.close()
        raise ValueError(f"Unknown allocation mode: {mode}")

    # Link journal back to bank transaction and mark reconciled
    conn.execute("""UPDATE bank_transactions
        SET journal_id=?, is_reconciled=1, reconciled_date=?, alloc_mode=?
        WHERE id=?""", (jid, str(_date.today()), mode, bank_txn_id))
    # Receipts attached to the statement line move to the transaction it created
    from core.attachments import move_attachments
    move_attachments(conn, "bank_txn", bank_txn_id, "journal", jid)

    conn.commit()
    conn.close()
    return jid


def allocate_bank_transaction_multi(db_path, bank_txn_id, lines):
    """
    Allocate one imported bank transaction across multiple lines in a single journal entry.

    lines: list of dicts — each must have 'mode' and 'amount', plus mode-specific keys:
      account: account_id, tax_code, description, contact_id
      invoice: invoice_id, contact_id
      bill:    bill_id,    contact_id
    """
    from datetime import date as _date

    if not lines:
        raise ValueError("At least one allocation line is required")

    conn = get_connection(db_path)
    c    = conn.cursor()

    txn = conn.execute("SELECT * FROM bank_transactions WHERE id=?",
                       (bank_txn_id,)).fetchone()
    if not txn:
        conn.close()
        raise ValueError(f"Bank transaction {bank_txn_id} not found")

    txn = dict(txn)
    if txn.get("journal_id") or txn.get("alloc_mode") == "match":
        conn.close()
        raise ValueError("Transaction is already allocated — deallocate first")

    bank_id   = txn["account_id"]
    txn_date  = txn["transaction_date"]
    total     = round(float((txn["debit"] or 0) or (txn["credit"] or 0)), 2)
    is_credit = float(txn["credit"] or 0) > 0

    acc_row = conn.execute("SELECT account_type FROM accounts WHERE id=?", (bank_id,)).fetchone()
    is_liability = acc_row and acc_row["account_type"] == "Liability"
    posting_is_credit = is_credit if not is_liability else not is_credit

    line_total = round(sum(float(l["amount"]) for l in lines), 2)
    if abs(line_total - total) > 0.02:
        conn.close()
        raise ValueError(f"Line total {line_total} does not match transaction amount {total}")

    base_desc = txn.get("description") or "Bank allocation"
    c.execute("""INSERT INTO journal_entries
        (entry_date, reference, description, entry_type, source_type)
        VALUES (?,?,?,?,?)""",
        (txn_date, txn.get("reference", ""), base_desc,
         "Bank Allocation", "bank_transaction"))
    jid = c.lastrowid

    if posting_is_credit:
        c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                  (jid, bank_id, total, 0))
    else:
        c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                  (jid, bank_id, 0, total))

    for line in lines:
        mode = line["mode"]
        amt  = round(float(line["amount"]), 2)

        if mode == "account":
            gl_id     = line["account_id"]
            if gl_id == bank_id:
                conn.close()
                raise ValueError("Cannot allocate a transaction to the account being reconciled")
            tax_code  = line.get("tax_code", "N-T")
            line_desc = line.get("description") or base_desc
            contact   = line.get("contact_id")

            tax_rate = 0.0
            tr = conn.execute("SELECT rate FROM tax_codes WHERE code=?", (tax_code,)).fetchone()
            if tr:
                tax_rate = tr["rate"]
            gst = round(amt * tax_rate / (1 + tax_rate), 2) if tax_rate else 0.0

            if posting_is_credit:
                c.execute("""INSERT INTO journal_lines
                    (journal_id,account_id,debit,credit,tax_code,gst_amount) VALUES (?,?,?,?,?,?)""",
                    (jid, gl_id, 0, amt - gst, tax_code, gst))
            else:
                c.execute("""INSERT INTO journal_lines
                    (journal_id,account_id,debit,credit,tax_code,gst_amount) VALUES (?,?,?,?,?,?)""",
                    (jid, gl_id, amt - gst, 0, tax_code, gst))

            if gst:
                gst_code = "2-1200" if posting_is_credit else "1-1300"
                gst_acc = conn.execute("SELECT id FROM accounts WHERE code=?", (gst_code,)).fetchone()
                if gst_acc:
                    if posting_is_credit:
                        c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                                  (jid, gst_acc["id"], 0, gst))
                    else:
                        c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                                  (jid, gst_acc["id"], gst, 0))

        elif mode == "invoice":
            inv_id  = line["invoice_id"]
            contact = line.get("contact_id")
            c.execute("""INSERT INTO payments
                (payment_type,contact_id,payment_date,amount,bank_account_id,reference,description,journal_id)
                VALUES (?,?,?,?,?,?,?,?)""",
                ("Receipt", contact, txn_date, amt, bank_id,
                 txn.get("reference", ""), base_desc, jid))
            pmt_id = c.lastrowid
            c.execute("INSERT INTO payment_allocations (payment_id,invoice_id,amount) VALUES (?,?,?)",
                      (pmt_id, inv_id, amt))
            conn.execute("""UPDATE invoices SET amount_paid=amount_paid+?,
                status=CASE WHEN (amount_paid+?)>=total THEN 'Paid'
                            WHEN (amount_paid+?)>0 THEN 'Partial' ELSE status END
                WHERE id=?""", (amt,)*3 + (inv_id,))

            ar = conn.execute("SELECT id FROM accounts WHERE code='1-1200'").fetchone()
            if ar:
                if posting_is_credit:
                    c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                              (jid, ar["id"], 0, amt))
                else:
                    c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                              (jid, ar["id"], amt, 0))

        elif mode == "bill":
            bill_id = line["bill_id"]
            contact = line.get("contact_id")
            c.execute("""INSERT INTO payments
                (payment_type,contact_id,payment_date,amount,bank_account_id,reference,description,journal_id)
                VALUES (?,?,?,?,?,?,?,?)""",
                ("Payment", contact, txn_date, amt, bank_id,
                 txn.get("reference", ""), base_desc, jid))
            pmt_id = c.lastrowid
            c.execute("INSERT INTO payment_allocations (payment_id,bill_id,amount) VALUES (?,?,?)",
                      (pmt_id, bill_id, amt))
            conn.execute("""UPDATE bills SET amount_paid=amount_paid+?,
                status=CASE WHEN (amount_paid+?)>=total THEN 'Paid'
                            WHEN (amount_paid+?)>0 THEN 'Partial' ELSE status END
                WHERE id=?""", (amt,)*3 + (bill_id,))

            ap = conn.execute("SELECT id FROM accounts WHERE code='2-1100'").fetchone()
            if ap:
                if posting_is_credit:
                    c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                              (jid, ap["id"], 0, amt))
                else:
                    c.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,?)",
                              (jid, ap["id"], amt, 0))
        else:
            conn.close()
            raise ValueError(f"Unknown allocation mode: {mode}")

    conn.execute("""UPDATE bank_transactions
        SET journal_id=?, is_reconciled=1, reconciled_date=?, alloc_mode=?
        WHERE id=?""", (jid, str(_date.today()), "split", bank_txn_id))
    from core.attachments import move_attachments
    move_attachments(conn, "bank_txn", bank_txn_id, "journal", jid)

    conn.commit()
    conn.close()
    return jid


def deallocate_bank_transaction(db_path, bank_txn_id):
    """
    Remove the categorisation from a CSV bank transaction so it can be re-allocated.
    Reverses the journal entry, voids any payment records, restores invoice/bill balances.
    """
    conn = get_connection(db_path)
    txn  = conn.execute("SELECT * FROM bank_transactions WHERE id=?",
                        (bank_txn_id,)).fetchone()
    if not txn:
        conn.close()
        raise ValueError(f"Bank transaction {bank_txn_id} not found")
    txn = dict(txn)
    jid = txn.get("journal_id")

    # Matched to existing ledger lines (core.bank_match): just drop the links;
    # the ledger lines belong to their own payments and are left alone.
    conn.execute("DELETE FROM bank_matches WHERE bank_txn_id=?", (bank_txn_id,))

    if jid:
        # Find all payments linked via this journal (split allocations have multiple)
        pmts = conn.execute(
            "SELECT * FROM payments WHERE journal_id=?", (jid,)).fetchall()
        for pmt in pmts:
            pmt = dict(pmt)
            pmt_id = pmt["id"]
            allocs = conn.execute(
                "SELECT * FROM payment_allocations WHERE payment_id=?",
                (pmt_id,)).fetchall()
            for a in allocs:
                a = dict(a)
                if a.get("invoice_id"):
                    conn.execute("""UPDATE invoices
                        SET amount_paid = MAX(0, amount_paid - ?),
                            status = CASE
                                WHEN status = 'Void' THEN 'Void'
                                WHEN (amount_paid - ?) <= 0 THEN 'Sent'
                                WHEN (amount_paid - ?) < total  THEN 'Partial'
                                ELSE status END
                        WHERE id=?""", (a["amount"], a["amount"], a["amount"], a["invoice_id"]))
                if a.get("bill_id"):
                    conn.execute("""UPDATE bills
                        SET amount_paid = MAX(0, amount_paid - ?),
                            status = CASE
                                WHEN (amount_paid - ?) <= 0 THEN 'Approved'
                                ELSE 'Partial' END
                        WHERE id=?""", (a["amount"], a["amount"], a["bill_id"]))
            conn.execute("DELETE FROM payment_allocations WHERE payment_id=?", (pmt_id,))
            conn.execute("DELETE FROM payments WHERE id=?", (pmt_id,))

        # Null FK reference on bank_transaction BEFORE deleting the journal entry,
        # otherwise SQLite's FK constraint (bank_transactions.journal_id →
        # journal_entries.id) raises IntegrityError.
        conn.execute("""UPDATE bank_transactions
            SET journal_id=NULL, is_reconciled=0, reconciled_date=NULL, alloc_mode=NULL
            WHERE id=?""", (bank_txn_id,))

        # Receipts go back to the statement line, ready for when it's redone
        from core.attachments import move_attachments
        move_attachments(conn, "journal", jid, "bank_txn", bank_txn_id)

        # Delete journal lines and entry
        conn.execute("DELETE FROM journal_lines WHERE journal_id=?", (jid,))
        conn.execute("DELETE FROM journal_entries WHERE id=?", (jid,))
    else:
        # No journal — still reset the bank transaction state
        conn.execute("""UPDATE bank_transactions
            SET journal_id=NULL, is_reconciled=0, reconciled_date=NULL, alloc_mode=NULL
            WHERE id=?""", (bank_txn_id,))
    conn.commit()
    conn.close()


def get_bank_transactions(db_path, account_id, unreconciled_only=False):
    conn = get_connection(db_path)
    q = """SELECT * FROM bank_transactions WHERE account_id=?"""
    params = [account_id]
    if unreconciled_only:
        q += " AND is_reconciled=0"
    q += " ORDER BY transaction_date, id"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _mark_new_statement_rows(conn, account_id, rows):
    """Set r["new"] on each statement row about to be imported. Duplicates are
    found by counting: for each (date, debit, credit), rows already stored on
    the account (from any earlier CSV or OFX import, rejected ones included)
    cover the same number of rows in the file, and only the rest are new.
    Rows whose description matches a stored one are covered first.

    So re-importing an overlapping period adds nothing, switching between CSV
    and OFX (worded differently) doesn't double up, and two genuine $5.00
    coffees on one day both import."""
    from collections import defaultdict
    key = lambda d, dr, cr: (d, round(float(dr or 0), 2), round(float(cr or 0), 2))
    stored = defaultdict(list)
    dates = sorted({r["date"] for r in rows})
    if dates:
        for s in conn.execute("""SELECT transaction_date, description, debit, credit
                FROM bank_transactions WHERE account_id=? AND transaction_date BETWEEN ? AND ?""",
                (account_id, dates[0], dates[-1])):
            stored[key(s["transaction_date"], s["debit"], s["credit"])].append((s["description"] or "").strip())
    groups = defaultdict(list)
    for i, r in enumerate(rows):
        r["new"] = True
        groups[key(r["date"], r.get("debit"), r.get("credit"))].append(i)
    for k, idxs in groups.items():
        have = stored.get(k, [])
        for i in idxs:   # same description first
            d = (rows[i].get("description") or "").strip()
            if d in have:
                have.remove(d)
                rows[i]["new"] = False
        for i in idxs:   # then any other stored row with this date and amount
            if rows[i]["new"] and have:
                have.pop()
                rows[i]["new"] = False


def import_bank_csv(db_path, account_id, rows):
    """Import bank CSV rows (already mapped to date/description/reference/
    debit/credit/balance), skipping ones already imported — see
    _mark_new_statement_rows. Returns count of newly inserted rows."""
    rows = [dict(r) for r in rows]
    conn = get_connection(db_path)
    try:
        _mark_new_statement_rows(conn, account_id, rows)
        inserted = 0
        for r in rows:
            if not r["new"]:
                continue
            conn.execute("""INSERT INTO bank_transactions
                (account_id,transaction_date,description,reference,debit,credit,balance)
                VALUES (?,?,?,?,?,?,?)""",
                (account_id, r["date"], r.get("description", ""), r.get("reference", ""),
                 r.get("debit", 0) or 0, r.get("credit", 0) or 0, r.get("balance", 0) or 0))
            inserted += 1
        conn.commit()
        return inserted
    finally:
        conn.close()


def import_bank_ofx(db_path, account_id, parsed, dry_run=False):
    """Import (or with dry_run, preview) the rows of core.ofx.parse_ofx().

    Rows already imported are skipped (_mark_new_statement_rows).

    Running balances are filled in only when the file has a trustworthy
    closing balance (see core.ofx) and isn't a credit card.
    Returns {"rows": [... each with "new": bool], "inserted": n, "skipped": n}."""
    rows = [dict(r) for r in parsed["rows"]]

    if parsed.get("balance") is not None and parsed.get("account_type") != "CREDITCARD":
        order = sorted(range(len(rows)), key=lambda i: rows[i]["date"])  # stable: keeps file order in a day
        bal = parsed["balance"]
        for i in reversed(order):
            rows[i]["balance"] = round(bal, 2)
            bal -= rows[i]["credit"] - rows[i]["debit"]
    for r in rows:
        r.setdefault("balance", 0.0)

    conn = get_connection(db_path)
    try:
        _mark_new_statement_rows(conn, account_id, rows)
        new = [r for r in rows if r["new"]]
        if not dry_run:
            for r in new:
                conn.execute("""INSERT INTO bank_transactions
                    (account_id,transaction_date,description,reference,debit,credit,balance)
                    VALUES (?,?,?,?,?,?,?)""",
                    (account_id, r["date"], r["description"], r["reference"],
                     r["debit"], r["credit"], r["balance"]))
            conn.commit()
        return {"rows": rows, "inserted": 0 if dry_run else len(new),
                "new": len(new), "skipped": len(rows) - len(new)}
    finally:
        conn.close()


def import_transactions(db_path, rows, account_map, balancing, contact_map):
    """
    Import Saasu-style transaction rows as balanced journal entries.

    rows: list of dicts with keys:
        txn_number, txn_type, date, ext_account_id, amount, gst_amount,
        ext_contact_id, counterparty_name, line_comment, doc_number, tax_code
    account_map: {ext_account_id (str): dogbox_account_id (int)}
    balancing: {txn_type (str): dogbox_account_id (int)}
    contact_map: {ext_contact_id (str): dogbox_contact_id (int) | None}

    Returns: {imported: int, skipped: int, errors: list[str]}
    """
    from collections import OrderedDict
    conn = get_connection(db_path)
    c = conn.cursor()

    gst_col = c.execute("SELECT id FROM accounts WHERE code='2-1200'").fetchone()
    gst_paid = c.execute("SELECT id FROM accounts WHERE code='1-1300'").fetchone()
    gst_collected_id = gst_col[0] if gst_col else None
    gst_paid_id = gst_paid[0] if gst_paid else None

    # Group rows by txn_number, preserving order
    groups = OrderedDict()
    for r in rows:
        tn = str(r.get('txn_number', '')).strip()
        if not tn:
            continue
        if tn not in groups:
            groups[tn] = []
        groups[tn].append(r)

    imported = 0
    skipped = 0
    errors = []
    batch = 0

    for txn_number, txn_rows in groups.items():
        exists = c.execute(
            "SELECT 1 FROM journal_entries WHERE reference=? AND entry_type='TxnImport'",
            (txn_number,)
        ).fetchone()
        if exists:
            skipped += 1
            continue

        txn_type = txn_rows[0].get('txn_type', '')
        entry_date = txn_rows[0].get('date', '')
        doc_number = txn_rows[0].get('doc_number', '') or ''
        counterparty = txn_rows[0].get('counterparty_name', '') or ''
        ext_contact_id = str(txn_rows[0].get('ext_contact_id', '') or '')
        contact_id = contact_map.get(ext_contact_id)

        description = f"{counterparty} — {doc_number}" if doc_number else counterparty
        if not description.strip():
            description = f"{txn_type} {txn_number}"

        if txn_type not in balancing:
            errors.append(f"Txn {txn_number}: no balancing account for type '{txn_type}'")
            continue

        balancing_acct = balancing[txn_type]
        is_income = txn_type in ('sales_invoice', 'cash_received')

        lines = []
        total = 0.0
        ok_flag = True

        for row in txn_rows:
            ext_acct = str(row.get('ext_account_id', '') or '').strip()
            dogbox_acct = account_map.get(ext_acct)
            if not dogbox_acct:
                errors.append(f"Txn {txn_number}: no mapping for account '{ext_acct}'")
                ok_flag = False
                break

            amount = float(row.get('amount', 0) or 0)
            gst = float(row.get('gst_amount', 0) or 0)
            tax_code = row.get('tax_code', '') or ''
            line_desc = ' '.join(str(row.get('line_comment', '') or '').split())[:500]
            total += amount + gst

            if is_income:
                lines.append({'account_id': dogbox_acct, 'debit': 0, 'credit': amount,
                               'description': line_desc, 'tax_code': tax_code,
                               'gst_amount': gst, 'contact_id': contact_id})
                if gst > 0 and gst_collected_id:
                    lines.append({'account_id': gst_collected_id, 'debit': 0, 'credit': gst,
                                   'description': 'GST', 'tax_code': '', 'gst_amount': 0,
                                   'contact_id': None})
            else:
                lines.append({'account_id': dogbox_acct, 'debit': amount, 'credit': 0,
                               'description': line_desc, 'tax_code': tax_code,
                               'gst_amount': gst, 'contact_id': contact_id})
                if gst > 0 and gst_paid_id:
                    lines.append({'account_id': gst_paid_id, 'debit': gst, 'credit': 0,
                                   'description': 'GST', 'tax_code': '', 'gst_amount': 0,
                                   'contact_id': None})

        if not ok_flag or not lines:
            continue

        total = round(total, 2)
        if is_income:
            lines.append({'account_id': balancing_acct, 'debit': total, 'credit': 0,
                           'description': description, 'tax_code': '', 'gst_amount': 0,
                           'contact_id': contact_id})
        else:
            lines.append({'account_id': balancing_acct, 'debit': 0, 'credit': total,
                           'description': description, 'tax_code': '', 'gst_amount': 0,
                           'contact_id': contact_id})

        try:
            c.execute(
                "INSERT INTO journal_entries (entry_date,reference,description,entry_type) VALUES (?,?,?,?)",
                (entry_date, txn_number, description, 'TxnImport')
            )
            jid = c.lastrowid
            for l in lines:
                c.execute(
                    "INSERT INTO journal_lines "
                    "(journal_id,account_id,debit,credit,description,tax_code,gst_amount,contact_id) "
                    "VALUES (?,?,?,?,?,?,?,?)",
                    (jid, l['account_id'], l.get('debit', 0), l.get('credit', 0),
                     l.get('description', ''), l.get('tax_code', ''),
                     l.get('gst_amount', 0), l.get('contact_id'))
                )
            imported += 1
            batch += 1
            if batch >= 50:
                conn.commit()
                batch = 0
        except Exception as e:
            errors.append(f"Txn {txn_number}: {str(e)}")
            conn.rollback()

    conn.commit()
    conn.close()
    return {'imported': imported, 'skipped': skipped, 'errors': errors}


def reconcile_transaction(db_path, bank_txn_id, journal_id=None):
    conn = get_connection(db_path)
    from datetime import date as dt
    conn.execute("""UPDATE bank_transactions SET is_reconciled=1,
        reconciled_date=?, journal_id=? WHERE id=?""",
        (str(dt.today()), journal_id, bank_txn_id))
    conn.commit()
    conn.close()


def get_last_reconciliation(db_path, account_id):
    conn = get_connection(db_path)
    row = conn.execute("""SELECT * FROM bank_reconciliations
        WHERE account_id=? AND status='Completed'
        ORDER BY reconcile_date DESC, id DESC LIMIT 1""",
        (account_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def create_rec_adjustment_journal(db_path, rec_account_id, adj_account_id,
                                  diff, entry_date, description, is_asset):
    """Create a balancing journal for a bank rec difference.

    diff = stmt_closing - gl_closing (positive = GL needs to increase).
    Returns the journal_line_id for the rec account line (to pass to complete_reconciliation).
    """
    conn = get_connection(db_path)
    c = conn.cursor()
    abs_diff = round(abs(diff), 2)

    # Determine which account gets the debit vs credit.
    # Asset  + positive diff → GL too low → Debit rec account (bank up), Credit adj
    # Asset  + negative diff → GL too high → Debit adj, Credit rec account (bank down)
    # Liab   + positive diff → GL too low → Credit rec account (CC up), Debit adj
    # Liab   + negative diff → GL too high → Debit rec account (CC down), Credit adj
    rec_gets_debit = (is_asset and diff > 0) or (not is_asset and diff < 0)
    if rec_gets_debit:
        rec_debit, rec_credit = abs_diff, 0.0
        adj_debit, adj_credit = 0.0, abs_diff
    else:
        rec_debit, rec_credit = 0.0, abs_diff
        adj_debit, adj_credit = abs_diff, 0.0

    c.execute("""INSERT INTO journal_entries
        (entry_date, reference, description, entry_type)
        VALUES (?, 'REC-ADJ', ?, 'Journal')""", (entry_date, description))
    jid = c.lastrowid
    c.execute("""INSERT INTO journal_lines (journal_id, account_id, debit, credit, description)
        VALUES (?, ?, ?, ?, ?)""", (jid, rec_account_id, rec_debit, rec_credit, description))
    rec_line_id = c.lastrowid
    c.execute("""INSERT INTO journal_lines (journal_id, account_id, debit, credit, description)
        VALUES (?, ?, ?, ?, ?)""", (jid, adj_account_id, adj_debit, adj_credit, description))
    conn.commit()
    conn.close()
    return rec_line_id


def complete_reconciliation(db_path, account_id, reconcile_date, closing_balance,
                            expected_opening=None,
                            journal_line_ids=None, bank_txn_ids=None):
    conn = get_connection(db_path)
    prev = conn.execute("""SELECT closing_balance FROM bank_reconciliations
        WHERE account_id=? AND status='Completed'
        ORDER BY reconcile_date DESC, id DESC LIMIT 1""",
        (account_id,)).fetchone()
    if prev and prev["closing_balance"] is not None:
        # Lock: opening must equal previous rec's closing balance
        opening = float(prev["closing_balance"])
        if expected_opening is not None and abs(float(expected_opening) - opening) > 0.005:
            conn.close()
            raise ValueError(
                f"Opening balance mismatch: expected {opening:.2f}, "
                f"got {float(expected_opening):.2f}. Reload the bank rec and try again."
            )
    else:
        # No prior rec — use client-supplied opening (first rec or broken chain)
        opening = float(expected_opening) if expected_opening is not None else 0.0
    conn.execute("""INSERT INTO bank_reconciliations
        (account_id, reconcile_date, closing_balance, opening_balance, status)
        VALUES (?,?,?,?,'Completed')""",
        (account_id, reconcile_date, closing_balance, opening))
    if journal_line_ids is not None:
        # Web UI path: only reconcile explicitly selected journal lines
        if journal_line_ids:
            ph = ','.join('?' * len(journal_line_ids))
            conn.execute(
                f"UPDATE journal_lines SET is_reconciled=1, reconciled_date=?"
                f" WHERE id IN ({ph}) AND is_reconciled=0",
                [reconcile_date] + list(journal_line_ids))
    else:
        # Desktop UI fallback: reconcile all lines up to rec date
        conn.execute("""
            UPDATE journal_lines SET is_reconciled=1, reconciled_date=?
            WHERE id IN (
                SELECT jl.id FROM journal_lines jl
                JOIN journal_entries je ON jl.journal_id = je.id
                WHERE jl.account_id=? AND jl.is_reconciled=0
                  AND (jl.is_rejected IS NULL OR jl.is_rejected=0)
                  AND je.entry_date <= ?
            )""", (reconcile_date, account_id, reconcile_date))
    if bank_txn_ids is not None:
        # Web UI path: only reconcile explicitly selected CSV rows
        if bank_txn_ids:
            ph = ','.join('?' * len(bank_txn_ids))
            conn.execute(
                f"UPDATE bank_transactions SET is_reconciled=1, reconciled_date=?"
                f" WHERE id IN ({ph}) AND is_reconciled=0",
                [reconcile_date] + list(bank_txn_ids))
    else:
        # Desktop UI fallback: reconcile all CSV rows up to rec date
        conn.execute("""
            UPDATE bank_transactions SET is_reconciled=1, reconciled_date=?
            WHERE account_id=? AND is_reconciled=0
              AND (is_rejected IS NULL OR is_rejected=0)
              AND transaction_date <= ?""", (reconcile_date, account_id, reconcile_date))
    conn.commit()
    conn.close()


# ── Reports ───────────────────────────────────────────────────────────────────

def trial_balance(db_path, as_at_date=None):
    conn = get_connection(db_path)
    if as_at_date:
        rows = conn.execute("""
            SELECT a.id as account_id, a.code, a.name, a.account_type, a.opening_balance,
                   COALESCE(SUM(jl.debit),0) as total_debit,
                   COALESCE(SUM(jl.credit),0) as total_credit
            FROM accounts a
            LEFT JOIN journal_lines jl ON a.id=jl.account_id
            LEFT JOIN journal_entries je ON jl.journal_id=je.id
            WHERE a.is_active=1
              AND (jl.id IS NULL OR je.entry_date <= ?)
            GROUP BY a.id ORDER BY a.code""", (as_at_date,)).fetchall()
    else:
        rows = conn.execute("""
            SELECT a.id as account_id, a.code, a.name, a.account_type, a.opening_balance,
                   COALESCE(SUM(jl.debit),0) as total_debit,
                   COALESCE(SUM(jl.credit),0) as total_credit
            FROM accounts a
            LEFT JOIN journal_lines jl ON a.id=jl.account_id
            WHERE a.is_active=1
            GROUP BY a.id ORDER BY a.code""").fetchall()
    conn.close()
    result = []
    for r in rows:
        d = dict(r)
        opening = d["opening_balance"] or 0.0
        if d["account_type"] in ("Asset","Expense"):
            d["balance"] = opening + d["total_debit"] - d["total_credit"]
        else:
            d["balance"] = opening + d["total_credit"] - d["total_debit"]
        result.append(d)
    return result


def get_account_ledger(db_path, account_id, date_from=None, date_to=None):
    """Return journal lines for one account, optionally filtered by date range.
    Returns {account, lines, opening_balance} where opening_balance is the
    account balance at the start of the period (before date_from)."""
    conn = get_connection(db_path)
    acct = conn.execute(
        "SELECT id, code, name, account_type, opening_balance FROM accounts WHERE id=?",
        (account_id,)
    ).fetchone()
    if not acct:
        conn.close()
        return None

    acct = dict(acct)
    ob = float(acct.get("opening_balance") or 0)
    is_debit_normal = acct["account_type"] in ("Asset", "Expense")

    # Compute opening balance = balance of all entries BEFORE date_from
    opening_bal = ob
    if date_from:
        pre = conn.execute("""
            SELECT COALESCE(SUM(jl.debit),0) as d, COALESCE(SUM(jl.credit),0) as c
            FROM journal_lines jl
            JOIN journal_entries je ON jl.journal_id=je.id
            WHERE jl.account_id=? AND je.entry_date < ?""", (account_id, date_from)).fetchone()
        if pre:
            if is_debit_normal:
                opening_bal = ob + pre["d"] - pre["c"]
            else:
                opening_bal = ob + pre["c"] - pre["d"]

    # Fetch lines in the requested range (either bound may be open)
    where, params = ["jl.account_id=?"], [account_id]
    if date_from:
        where.append("je.entry_date >= ?"); params.append(date_from)
    if date_to:
        where.append("je.entry_date <= ?"); params.append(date_to)
    lines = conn.execute(f"""
        SELECT je.entry_date, je.reference, je.description as je_desc, je.entry_type,
               jl.debit, jl.credit, jl.description as line_desc, je.id as journal_id
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id=je.id
        WHERE {' AND '.join(where)}
        ORDER BY je.entry_date, je.id""", params).fetchall()

    conn.close()
    return {
        "account": acct,
        "opening_balance": opening_bal,
        "lines": [dict(l) for l in lines],
    }


def get_general_ledger(db_path, date_from, date_to):
    """Return all accounts with journal activity or non-zero opening balance
    for the given period. Each section has opening_balance, lines with running
    balance, and closing_balance. Ordered by account code."""
    conn = get_connection(db_path)

    accts = conn.execute(
        "SELECT id, code, name, account_type, COALESCE(opening_balance,0) as opening_balance "
        "FROM accounts ORDER BY code"
    ).fetchall()

    # Pre-period sums for every account in one query
    pre_rows = conn.execute("""
        SELECT jl.account_id,
               COALESCE(SUM(jl.debit),0)  AS dr,
               COALESCE(SUM(jl.credit),0) AS cr
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id=je.id
        WHERE je.entry_date < ?
        GROUP BY jl.account_id
    """, (date_from,)).fetchall()
    pre_map = {r["account_id"]: (float(r["dr"]), float(r["cr"])) for r in pre_rows}

    # All in-period lines ordered by account code then date/id
    line_rows = conn.execute("""
        SELECT jl.account_id,
               je.entry_date, je.reference,
               COALESCE(jl.description, je.description) AS description,
               jl.debit, jl.credit
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id=je.id
        JOIN accounts a ON jl.account_id=a.id
        WHERE je.entry_date BETWEEN ? AND ?
        ORDER BY a.code, je.entry_date, je.id
    """, (date_from, date_to)).fetchall()
    conn.close()

    from collections import defaultdict
    lines_by_acct = defaultdict(list)
    for l in line_rows:
        lines_by_acct[l["account_id"]].append(dict(l))

    sections = []
    for acct in accts:
        a = dict(acct)
        aid = a["id"]
        ob = float(a["opening_balance"])
        is_dr_normal = a["account_type"] in ("Asset", "Expense")

        pre_dr, pre_cr = pre_map.get(aid, (0.0, 0.0))
        opening_bal = ob + (pre_dr - pre_cr if is_dr_normal else pre_cr - pre_dr)

        acct_lines = lines_by_acct.get(aid, [])
        if not acct_lines and abs(opening_bal) < 0.005:
            continue

        bal = opening_bal
        out_lines = []
        for l in acct_lines:
            dr = float(l["debit"] or 0)
            cr = float(l["credit"] or 0)
            bal += (dr - cr) if is_dr_normal else (cr - dr)
            out_lines.append({
                "date":        l["entry_date"],
                "reference":   l["reference"] or "",
                "description": l["description"] or "",
                "debit":       dr or None,
                "credit":      cr or None,
                "balance":     bal,
            })

        sections.append({
            "account":         a,
            "opening_balance": opening_bal,
            "closing_balance": bal,
            "lines":           out_lines,
        })

    return {"sections": sections, "date_from": date_from, "date_to": date_to}


def profit_and_loss(db_path, date_from, date_to, basis="accrual"):
    """
    basis="accrual" : revenue/expense on invoice/bill date (default)
    basis="cash"    : revenue on receipt date, expense on payment date
    """
    conn = get_connection(db_path)

    if basis == "cash":
        # ── CASH BASIS ──────────────────────────────────────────────────────
        # Income: sum invoice line amounts for invoices paid within period
        # Expense: sum bill line amounts for bills paid within period
        # Manual journals (type='Journal') included in both bases

        income_accounts: dict  = {}   # account_id -> {code, name, amount}
        expense_accounts: dict = {}

        # Receipts in period → trace back to invoice lines
        receipts = conn.execute("""
            SELECT p.id as payment_id, pa.invoice_id, pa.amount as alloc_amount,
                   i.total as inv_total
            FROM payments p
            JOIN payment_allocations pa ON pa.payment_id=p.id
            JOIN invoices i ON pa.invoice_id=i.id
            WHERE p.payment_type='Receipt'
              AND p.payment_date BETWEEN ? AND ?
        """, (date_from, date_to)).fetchall()

        for r in receipts:
            if not r["inv_total"]: continue
            proportion = r["alloc_amount"] / r["inv_total"]
            # Read income from the invoice's GL journal lines — always correctly
            # attributed (save_invoice uses a fallback account_id), unlike
            # invoice_lines.account_id which can be NULL and would silently drop
            # lines via INNER JOIN.
            lines = conn.execute("""
                SELECT jl.account_id, jl.credit, a.code, a.name, a.account_type
                FROM invoices i
                JOIN journal_entries je ON je.id = i.journal_id
                JOIN journal_lines jl ON jl.journal_id = je.id
                JOIN accounts a ON a.id = jl.account_id
                WHERE i.id = ?
                  AND a.account_type IN ('Income', 'Revenue', 'Other Income')
                  AND jl.credit > 0
            """, (r["invoice_id"],)).fetchall()
            for l in lines:
                net = l["credit"] * proportion
                aid = l["account_id"]
                if aid not in income_accounts:
                    income_accounts[aid] = {"code": l["code"], "name": l["name"],
                                             "amount": 0.0}
                income_accounts[aid]["amount"] += net

        # Payments in period → trace back to bill lines
        payments = conn.execute("""
            SELECT p.id as payment_id, pa.bill_id, pa.amount as alloc_amount,
                   b.total as bill_total
            FROM payments p
            JOIN payment_allocations pa ON pa.payment_id=p.id
            JOIN bills b ON pa.bill_id=b.id
            WHERE p.payment_type='Payment'
              AND p.payment_date BETWEEN ? AND ?
        """, (date_from, date_to)).fetchall()

        for r in payments:
            if not r["bill_total"]: continue
            proportion = r["alloc_amount"] / r["bill_total"]
            lines = conn.execute("""
                SELECT bl.line_total, bl.gst_amount, bl.account_id,
                       a.code, a.name, a.account_type
                FROM bill_lines bl
                JOIN accounts a ON bl.account_id=a.id
                WHERE bl.bill_id=?
            """, (r["bill_id"],)).fetchall()
            for l in lines:
                net = (l["line_total"] - l["gst_amount"]) * proportion
                aid = l["account_id"]
                if l["account_type"] in ("Expense", "Cost of Sales"):
                    if aid not in expense_accounts:
                        expense_accounts[aid] = {"code": l["code"], "name": l["name"],
                                                  "amount": 0.0}
                    expense_accounts[aid]["amount"] += net

        # Direct GL receipts/payments (expense_account_id set, no invoice/bill allocation)
        # entry_type is 'Receipt' or 'Payment' — not captured by the invoice path above
        direct_gl = conn.execute("""
            SELECT a.id as account_id, a.code, a.name, a.account_type,
                   COALESCE(SUM(jl.credit),0) as total_credit,
                   COALESCE(SUM(jl.debit),0)  as total_debit
            FROM journal_entries je
            JOIN journal_lines jl ON jl.journal_id=je.id
            JOIN accounts a ON jl.account_id=a.id
            JOIN payments p ON je.source_id=p.id AND je.source_type='payment'
            WHERE je.entry_type IN ('Receipt','Payment')
              AND je.entry_date BETWEEN ? AND ?
              AND p.expense_account_id IS NOT NULL
              AND a.account_type IN ('Income','Revenue','Other Income','Expense','Cost of Sales')
            GROUP BY a.id
        """, (date_from, date_to)).fetchall()

        for r in direct_gl:
            d = dict(r)
            aid = d["account_id"]
            if d["account_type"] in ("Income", "Revenue", "Other Income"):
                amount = d["total_credit"] - d["total_debit"]
                if aid not in income_accounts:
                    income_accounts[aid] = {"code": d["code"], "name": d["name"], "amount": 0.0}
                income_accounts[aid]["amount"] += amount
            else:
                amount = d["total_debit"] - d["total_credit"]
                if aid not in expense_accounts:
                    expense_accounts[aid] = {"code": d["code"], "name": d["name"], "amount": 0.0}
                expense_accounts[aid]["amount"] += amount

        # Bank rec account allocations (entry_type='Bank Allocation') — direct cash flows
        # Captured by accrual via the catch-all journal query; must also appear in cash basis
        bank_alloc_gl = conn.execute("""
            SELECT a.id as account_id, a.code, a.name, a.account_type,
                   COALESCE(SUM(jl.credit),0) as total_credit,
                   COALESCE(SUM(jl.debit),0)  as total_debit
            FROM journal_entries je
            JOIN journal_lines jl ON jl.journal_id=je.id
            JOIN accounts a ON jl.account_id=a.id
            WHERE je.entry_type = 'Bank Allocation'
              AND je.entry_date BETWEEN ? AND ?
              AND a.account_type IN ('Income','Revenue','Other Income','Expense','Cost of Sales')
            GROUP BY a.id
        """, (date_from, date_to)).fetchall()

        for r in bank_alloc_gl:
            d = dict(r)
            aid = d["account_id"]
            if d["account_type"] in ("Income", "Revenue", "Other Income"):
                amount = d["total_credit"] - d["total_debit"]
                if aid not in income_accounts:
                    income_accounts[aid] = {"code": d["code"], "name": d["name"], "amount": 0.0}
                income_accounts[aid]["amount"] += amount
            else:
                amount = d["total_debit"] - d["total_credit"]
                if aid not in expense_accounts:
                    expense_accounts[aid] = {"code": d["code"], "name": d["name"], "amount": 0.0}
                expense_accounts[aid]["amount"] += amount

        # Manual journals still count for both bases
        manual = conn.execute("""
            SELECT a.code, a.name, a.account_type,
                   COALESCE(SUM(jl.debit),0)  as total_debit,
                   COALESCE(SUM(jl.credit),0) as total_credit
            FROM accounts a
            JOIN journal_lines jl ON a.id=jl.account_id
            JOIN journal_entries je ON jl.journal_id=je.id
            WHERE a.account_type IN ('Income','Expense','Revenue','Other Income','Cost of Sales')
              AND je.entry_type = 'Journal'
              AND (je.reference IS NULL OR je.reference NOT LIKE 'EOFY-%')
              AND je.entry_date BETWEEN ? AND ?
            GROUP BY a.id ORDER BY a.code
        """, (date_from, date_to)).fetchall()

        for r in manual:
            d = dict(r)
            aid_manual = None  # key by code+name since we don't have id
            key = (d["code"], d["name"])
            if d["account_type"] in ("Income", "Revenue", "Other Income"):
                amount = d["total_credit"] - d["total_debit"]
                found = next((v for v in income_accounts.values()
                              if v["code"] == d["code"]), None)
                if found:
                    found["amount"] += amount
                else:
                    income_accounts[key] = {"code": d["code"], "name": d["name"],
                                             "amount": amount}
            else:
                amount = d["total_debit"] - d["total_credit"]
                found = next((v for v in expense_accounts.values()
                              if v["code"] == d["code"]), None)
                if found:
                    found["amount"] += amount
                else:
                    expense_accounts[key] = {"code": d["code"], "name": d["name"],
                                              "amount": amount}

        conn.close()

        income_list  = sorted(income_accounts.values(),  key=lambda x: x["code"])
        expense_list = sorted(expense_accounts.values(), key=lambda x: x["code"])
        total_income  = sum(x["amount"] for x in income_list)
        total_expense = sum(x["amount"] for x in expense_list)
        return {
            "income":        income_list,
            "expense":       expense_list,
            "cost_of_sales": [],
            "total_income":  total_income,
            "total_expense": total_expense,
            "net_profit":    total_income - total_expense,
            "basis":         "cash",
        }

    # ── ACCRUAL BASIS (default) ──────────────────────────────────────────────
    rows = conn.execute("""
        SELECT a.id as account_id, a.code, a.name, a.account_type,
               COALESCE(SUM(jl.debit),0)  as total_debit,
               COALESCE(SUM(jl.credit),0) as total_credit
        FROM accounts a
        JOIN journal_lines jl ON a.id=jl.account_id
        JOIN journal_entries je ON jl.journal_id=je.id
        WHERE a.account_type IN ('Income','Expense','Revenue','Other Income','Cost of Sales')
          AND (je.reference IS NULL OR je.reference NOT LIKE 'EOFY-%')
          AND je.entry_date BETWEEN ? AND ?
        GROUP BY a.id ORDER BY a.code""", (date_from, date_to)).fetchall()
    conn.close()
    result = {"income": [], "expense": [], "cost_of_sales": [],
              "net_profit": 0.0, "basis": "accrual"}
    total_income = total_expense = 0.0
    for r in rows:
        d = dict(r)
        if d["account_type"] in ("Income", "Revenue", "Other Income"):
            d["amount"] = d["total_credit"] - d["total_debit"]
            result["income"].append(d)
            total_income += d["amount"]
        elif d["account_type"] == "Cost of Sales":
            d["amount"] = d["total_debit"] - d["total_credit"]
            result["cost_of_sales"].append(d)
            total_expense += d["amount"]
        else:
            d["amount"] = d["total_debit"] - d["total_credit"]
            result["expense"].append(d)
            total_expense += d["amount"]
    result["total_income"]  = total_income
    result["total_expense"] = total_expense
    result["net_profit"]    = total_income - total_expense
    return result


def balance_sheet(db_path, as_at_date):
    """
    AASB-structured balance sheet grouping assets into:
      Current Assets
      Non-Current Assets
        Property, Plant & Equipment (cost less accum depn per class)
        Intangible Assets
        Right-of-Use Assets

    Returns:
      {
        "current_assets":        [...rows...],
        "ppe_classes":           [...{class_label, cost, accum_depn, net_wdv}...],
        "other_noncurrent":      [...rows...],
        "liabilities":           [...rows...],
        "equity":                [...rows...],
        "total_current_assets":  float,
        "total_ppe_net":         float,
        "total_other_noncurrent":float,
        "total_assets":          float,
        "total_liabilities":     float,
        "total_equity":          float,
        # Legacy flat list for backward compat with PDF that hasn't been updated yet
        "assets": [...all asset rows...]
      }
    """
    from core.fixed_assets import ASSET_CLASSES, COST_CODE_TO_CLASS, ACCUM_CODE_TO_CLASS

    rows = trial_balance(db_path, as_at_date=as_at_date)

    # Build a dict keyed by account code for quick lookup
    by_code = {r["code"]: r for r in rows}

    # ── Classify every account ────────────────────────────────────────────────
    current_assets    = []
    ppe_cost_rows     = {}   # class_key → balance
    ppe_accum_rows    = {}   # class_key → balance (always positive = credit-side)
    other_noncurrent  = []
    liabilities       = []
    equity            = []

    CURRENT_SUBTYPES = {
        "Bank", "Current Asset", "Cash and Cash Equivalents",
        "Accounts Receivable", "Inventory", "Prepayments",
    }
    NONCURRENT_SKIP_SUBTYPES = {
        "Fixed Asset", "Accumulated Depreciation",
    }

    for r in rows:
        atype    = r.get("account_type", "")
        subtype  = r.get("account_subtype") or ""
        code     = r.get("code", "")
        balance  = float(r.get("balance", 0) or 0)

        if atype in ("Liability",):
            liabilities.append(r)
        elif atype in ("Equity",):
            equity.append(r)
        elif atype == "Asset":
            # Cost account for a PPE class?
            if code in COST_CODE_TO_CLASS:
                cls_key = COST_CODE_TO_CLASS[code]["key"]
                ppe_cost_rows[cls_key] = ppe_cost_rows.get(cls_key, 0.0) + balance
            # Accumulated depreciation contra account?
            elif code in ACCUM_CODE_TO_CLASS:
                cls_key = ACCUM_CODE_TO_CLASS[code]["key"]
                # Accum depn has a credit-normal balance, but trial_balance()
                # returns Asset accounts as debit-normal (debit-credit).
                # An accum depn account will have a NEGATIVE balance
                # (it's credit > debit). Store the absolute credit amount.
                ppe_accum_rows[cls_key] = ppe_accum_rows.get(cls_key, 0.0) + abs(balance)
            elif subtype in CURRENT_SUBTYPES or (
                    subtype not in NONCURRENT_SKIP_SUBTYPES and
                    code.startswith("1-1")):
                current_assets.append(r)
            elif subtype in NONCURRENT_SKIP_SUBTYPES:
                pass  # absorbed into ppe_cost/accum above
            else:
                other_noncurrent.append(r)

    # ── Build PPE class summary ───────────────────────────────────────────────
    ppe_classes = []
    for cls in ASSET_CLASSES:
        key   = cls["key"]
        cost  = ppe_cost_rows.get(key, 0.0)
        accum = ppe_accum_rows.get(key, 0.0)
        net   = round(cost - accum, 2)
        if abs(cost) < 0.005 and abs(accum) < 0.005:
            continue   # skip empty classes from the display
        ppe_classes.append({
            "key":        key,
            "label":      cls["label"],
            "cost_code":  cls["cost_code"],
            "accum_code": cls["accum_code"],
            "cost":       round(cost, 2),
            "accum_depn": round(accum, 2),
            "net_wdv":    net,
        })

    # ── Totals ────────────────────────────────────────────────────────────────
    total_current    = sum(float(r.get("balance", 0) or 0) for r in current_assets)
    total_ppe_net    = sum(c["net_wdv"] for c in ppe_classes)
    total_other_nc   = sum(float(r.get("balance", 0) or 0) for r in other_noncurrent)
    total_assets     = total_current + total_ppe_net + total_other_nc
    total_liabilities= sum(float(r.get("balance", 0) or 0) for r in liabilities)
    total_equity     = sum(float(r.get("balance", 0) or 0) for r in equity)

    # Current-year net profit: use P&L for the FY that contains as_at_date so
    # this agrees with the dashboard and stand-alone P&L report.  Do NOT sum
    # all-time income/expense from trial_balance rows — that would include prior
    # years and diverge from any date-filtered P&L.
    from datetime import date as _date
    _as_at = _date.fromisoformat(as_at_date) if isinstance(as_at_date, str) else as_at_date
    conn2 = get_connection(db_path)
    fy_row = conn2.execute("SELECT fy_start_month FROM company LIMIT 1").fetchone()
    conn2.close()
    fy_month = (fy_row["fy_start_month"] if fy_row and fy_row["fy_start_month"] else 7)
    if _as_at.month >= fy_month:
        fy_start = _as_at.replace(month=fy_month, day=1)
    else:
        fy_start = _as_at.replace(year=_as_at.year - 1, month=fy_month, day=1)
    pl = profit_and_loss(db_path, str(fy_start), str(_as_at))
    net_profit = round(pl.get("net_profit", 0.0) or 0.0, 2)
    if abs(net_profit) >= 0.005:
        equity.append({
            "code": "", "name": "Current Year Net Profit / (Loss)",
            "account_type": "Equity", "balance": net_profit,
        })
        total_equity += net_profit

    # Legacy flat assets list (for any code that still iterates result["assets"])
    flat_assets = list(current_assets)
    for cls_row in ppe_classes:
        flat_assets.append({
            "code":    cls_row["cost_code"] or "",
            "name":    cls_row["label"],
            "account_type": "Asset",
            "balance": cls_row["net_wdv"],
        })
    flat_assets.extend(other_noncurrent)

    return {
        "current_assets":         current_assets,
        "ppe_classes":            ppe_classes,
        "other_noncurrent":       other_noncurrent,
        "liabilities":            liabilities,
        "equity":                 equity,
        "total_current_assets":   round(total_current,    2),
        "total_ppe_net":          round(total_ppe_net,    2),
        "total_other_noncurrent": round(total_other_nc,   2),
        "total_assets":           round(total_assets,     2),
        "total_liabilities":      round(total_liabilities,2),
        "total_equity":           round(total_equity,     2),
        # Legacy
        "assets":                 flat_assets,
        "total_equity_legacy":    round(total_equity,     2),
    }


def bas_report(db_path, date_from, date_to, basis="accrual"):
    """
    basis="accrual": sales/purchases on invoice/bill date (default — ATO standard)
    basis="cash":    sales/purchases on payment receipt/payment date
    Note: most small businesses lodge BAS on a cash basis — the ATO allows this
          for businesses with turnover under $10M.
    """
    conn = get_connection(db_path)

    if basis == "cash":
        # GST collected on invoice receipts in period: each receipt carries the
        # invoice's GST share (receipt x GST / total), so a part payment counts
        # only its share and an invoice reduced by a credit note only the GST
        # actually received.
        gst_collected_inv = conn.execute("""
            SELECT COALESCE(SUM(pa.amount * i.gst_total / i.total),0) as amt
            FROM payment_allocations pa
            JOIN payments p ON pa.payment_id=p.id
            JOIN invoices i ON i.id=pa.invoice_id
            WHERE p.payment_type='Receipt'
              AND p.payment_date BETWEEN ? AND ?
              AND COALESCE(i.is_credit_note,0)=0
              AND i.status NOT IN ('Draft','Void')
              AND i.total > 0
        """, (date_from, date_to)).fetchone()

        # POS refunds paid out in period: the credit note's sale and GST come off
        pos_refunds = conn.execute("""
            SELECT COALESCE(SUM(cn.total),0) as amt, COALESCE(SUM(cn.gst_total),0) as gst
            FROM invoices cn
            JOIN journal_entries je ON je.reference = 'POSREF-' || cn.id
            WHERE cn.is_credit_note=1
              AND je.entry_date BETWEEN ? AND ?
        """, (date_from, date_to)).fetchone()

        # GST collected: from direct GL receipts in period
        gst_collected_direct = conn.execute("""
            SELECT COALESCE(SUM(jl.credit),0) as amt FROM journal_lines jl
            JOIN journal_entries je ON jl.journal_id=je.id
            JOIN accounts a ON jl.account_id=a.id
            JOIN payments p ON je.source_id=p.id AND je.source_type='payment'
            WHERE a.code='2-1200'
              AND je.entry_type='Receipt'
              AND je.entry_date BETWEEN ? AND ?
              AND p.expense_account_id IS NOT NULL
        """, (date_from, date_to)).fetchone()

        gst_collected_amt = ((gst_collected_inv["amt"] or 0) + (gst_collected_direct["amt"] or 0)
                             - (pos_refunds["gst"] or 0))

        # GST paid on bill payments in period — each payment's share, as for receipts
        gst_paid_bill = conn.execute("""
            SELECT COALESCE(SUM(pa.amount * b.gst_total / b.total),0) as amt
            FROM payment_allocations pa
            JOIN payments p ON pa.payment_id=p.id
            JOIN bills b ON b.id=pa.bill_id
            WHERE p.payment_type='Payment'
              AND p.payment_date BETWEEN ? AND ?
              AND b.status NOT IN ('Draft','Void')
              AND b.total > 0
        """, (date_from, date_to)).fetchone()

        # GST paid: from direct GL payments in period
        gst_paid_direct = conn.execute("""
            SELECT COALESCE(SUM(jl.debit),0) as amt FROM journal_lines jl
            JOIN journal_entries je ON jl.journal_id=je.id
            JOIN accounts a ON jl.account_id=a.id
            JOIN payments p ON je.source_id=p.id AND je.source_type='payment'
            WHERE a.code='1-1300'
              AND je.entry_type='Payment'
              AND je.entry_date BETWEEN ? AND ?
              AND p.expense_account_id IS NOT NULL
        """, (date_from, date_to)).fetchone()

        gst_paid_amt = (gst_paid_bill["amt"] or 0) + (gst_paid_direct["amt"] or 0)

        # G1: invoice receipts in period
        sales_inv = conn.execute("""
            SELECT COALESCE(SUM(pa.amount),0) as amt
            FROM payment_allocations pa
            JOIN payments p ON pa.payment_id=p.id
            WHERE pa.invoice_id IS NOT NULL
              AND p.payment_type='Receipt'
              AND p.payment_date BETWEEN ? AND ?
        """, (date_from, date_to)).fetchone()

        # G1: direct GL receipts to income accounts in period
        sales_direct = conn.execute("""
            SELECT COALESCE(SUM(p.amount),0) as amt
            FROM payments p
            JOIN journal_entries je ON je.source_id=p.id AND je.source_type='payment'
            JOIN accounts a ON a.id=p.expense_account_id
            WHERE p.payment_type='Receipt'
              AND je.entry_date BETWEEN ? AND ?
              AND p.expense_account_id IS NOT NULL
              AND a.account_type IN ('Income','Revenue','Other Income')
        """, (date_from, date_to)).fetchone()

        sales_amt = ((sales_inv["amt"] or 0) + (sales_direct["amt"] or 0)
                     - (pos_refunds["amt"] or 0))

        # G11: bill payments in period
        purchases_bill = conn.execute("""
            SELECT COALESCE(SUM(pa.amount),0) as amt
            FROM payment_allocations pa
            JOIN payments p ON pa.payment_id=p.id
            WHERE pa.bill_id IS NOT NULL
              AND p.payment_type='Payment'
              AND p.payment_date BETWEEN ? AND ?
        """, (date_from, date_to)).fetchone()

        # G11: direct GL payments to expense accounts in period
        purchases_direct = conn.execute("""
            SELECT COALESCE(SUM(p.amount),0) as amt
            FROM payments p
            JOIN journal_entries je ON je.source_id=p.id AND je.source_type='payment'
            JOIN accounts a ON a.id=p.expense_account_id
            WHERE p.payment_type='Payment'
              AND je.entry_date BETWEEN ? AND ?
              AND p.expense_account_id IS NOT NULL
              AND a.account_type IN ('Expense','Cost of Sales')
        """, (date_from, date_to)).fetchone()

        purchases_amt = (purchases_bill["amt"] or 0) + (purchases_direct["amt"] or 0)

        # Bank Allocation entries: direct cash flows via bank rec (account mode)
        # G1: gross bank debits for income allocations (money IN to bank)
        sales_bank_alloc = conn.execute("""
            SELECT COALESCE(SUM(jl.debit), 0) as amt
            FROM journal_entries je
            JOIN journal_lines jl ON jl.journal_id=je.id
            JOIN accounts a ON jl.account_id=a.id
            WHERE je.entry_type = 'Bank Allocation'
              AND je.entry_date BETWEEN ? AND ?
              AND a.account_type = 'Bank'
              AND jl.debit > 0
        """, (date_from, date_to)).fetchone()

        # G11: gross bank credits for expense allocations (money OUT of bank)
        purchases_bank_alloc = conn.execute("""
            SELECT COALESCE(SUM(jl.credit), 0) as amt
            FROM journal_entries je
            JOIN journal_lines jl ON jl.journal_id=je.id
            JOIN accounts a ON jl.account_id=a.id
            WHERE je.entry_type = 'Bank Allocation'
              AND je.entry_date BETWEEN ? AND ?
              AND a.account_type = 'Bank'
              AND jl.credit > 0
        """, (date_from, date_to)).fetchone()

        # GST collected: credits to 2-1200 from bank allocation income entries
        gst_col_bank_alloc = conn.execute("""
            SELECT COALESCE(SUM(jl.credit), 0) as amt
            FROM journal_entries je
            JOIN journal_lines jl ON jl.journal_id=je.id
            JOIN accounts a ON jl.account_id=a.id
            WHERE je.entry_type = 'Bank Allocation'
              AND je.entry_date BETWEEN ? AND ?
              AND a.code = '2-1200'
        """, (date_from, date_to)).fetchone()

        # GST paid: debits to 1-1300 from bank allocation expense entries
        gst_paid_bank_alloc = conn.execute("""
            SELECT COALESCE(SUM(jl.debit), 0) as amt
            FROM journal_entries je
            JOIN journal_lines jl ON jl.journal_id=je.id
            JOIN accounts a ON jl.account_id=a.id
            WHERE je.entry_type = 'Bank Allocation'
              AND je.entry_date BETWEEN ? AND ?
              AND a.code = '1-1300'
        """, (date_from, date_to)).fetchone()

        sales_amt     += (sales_bank_alloc["amt"] or 0)
        purchases_amt += (purchases_bank_alloc["amt"] or 0)
        gst_collected_amt += (gst_col_bank_alloc["amt"] or 0)
        gst_paid_amt      += (gst_paid_bank_alloc["amt"] or 0)

        gst_collected = {"amt": gst_collected_amt}
        gst_paid      = {"amt": gst_paid_amt}
        sales         = {"amt": sales_amt}
        purchases     = {"amt": purchases_amt}

    else:
        # Accrual: GST from journal entries in period by invoice/bill date.
        # Credit notes and reversals (voided invoices/journals) debit GST
        # Collected and reduce it; other debits (e.g. paying the ATO) don't.
        _reduces = ("(je.entry_type='Credit Note'"
                    " OR je.description LIKE 'Reversal of:%'"
                    " OR je.description LIKE 'VOID:%')")
        _reversal = "(je.description LIKE 'Reversal of:%' OR je.description LIKE 'VOID:%')"
        gst_collected = conn.execute(f"""
            SELECT COALESCE(SUM(jl.credit),0)
                 - COALESCE(SUM(CASE WHEN {_reduces} THEN jl.debit ELSE 0 END),0) as amt
            FROM journal_lines jl
            JOIN journal_entries je ON jl.journal_id=je.id
            JOIN accounts a ON jl.account_id=a.id
            WHERE a.code='2-1200' AND je.entry_date BETWEEN ? AND ?
        """, (date_from, date_to)).fetchone()

        # Bad debt decreasing adjustments: DR to 2-1200 from bad debt write-offs in period.
        # Subtracted from 1A to produce net GST on sales (ATO G7 equivalent).
        gst_bad_debt_adj = conn.execute("""
            SELECT COALESCE(SUM(jl.debit),0) as amt FROM journal_lines jl
            JOIN journal_entries je ON jl.journal_id=je.id
            JOIN accounts a ON jl.account_id=a.id
            WHERE a.code='2-1200' AND je.entry_type='Bad Debt'
              AND je.entry_date BETWEEN ? AND ?
        """, (date_from, date_to)).fetchone()

        # GST Paid: a voided bill's reversal credits it back
        gst_paid = conn.execute(f"""
            SELECT COALESCE(SUM(jl.debit),0)
                 - COALESCE(SUM(CASE WHEN {_reversal} THEN jl.credit ELSE 0 END),0) as amt
            FROM journal_lines jl
            JOIN journal_entries je ON jl.journal_id=je.id
            JOIN accounts a ON jl.account_id=a.id
            WHERE a.code='1-1300' AND je.entry_date BETWEEN ? AND ?
        """, (date_from, date_to)).fetchone()

        # G1: invoices less credit notes (status 'Credit Note', positive totals)
        sales = conn.execute("""
            SELECT COALESCE(SUM(CASE WHEN COALESCE(is_credit_note,0)=1 THEN -total ELSE total END),0) as amt
            FROM invoices
            WHERE status NOT IN ('Draft','Void')
              AND invoice_date BETWEEN ? AND ?
        """, (date_from, date_to)).fetchone()

        purchases = conn.execute("""
            SELECT COALESCE(SUM(total),0) as amt FROM bills
            WHERE status NOT IN ('Draft','Void')
              AND bill_date BETWEEN ? AND ?
        """, (date_from, date_to)).fetchone()

    conn.close()
    g1   = sales["amt"]         if sales         else 0.0
    g11  = purchases["amt"]     if purchases      else 0.0
    _1a_gross = gst_collected["amt"] if gst_collected else 0.0
    _bad_debt_adj = (gst_bad_debt_adj["amt"] if gst_bad_debt_adj else 0.0) if basis == "accrual" else 0.0
    _1a  = round(_1a_gross - _bad_debt_adj, 2)
    _1b  = gst_paid["amt"]      if gst_paid       else 0.0
    return {
        "G1_total_sales":        g1,
        "G11_total_purchases":   g11,
        "1A_GST_on_sales":       _1a,
        "1B_GST_on_purchases":   _1b,
        "GST_payable":           round(_1a - _1b, 2),
        "bad_debt_adjustments":  round(_bad_debt_adj, 2),
        "period_from":           date_from,
        "period_to":             date_to,
        "basis":                 basis,
    }



def ias_report(db_path, date_from, date_to):
    """
    Instalment Activity Statement (IAS) — ATO form for businesses that:
      - Are NOT registered for GST, OR
      - Report GST quarterly but PAYG withholding monthly, OR
      - Are a medium withholder (PAYG > $25k/yr) lodging monthly

    IAS fields:
      W1  Total salary, wages and other payments
      W2  Amount withheld from salary, wages and other payments (PAYG withholding)
      W3  Amount withheld where no ABN is quoted (if applicable)
      W4  Amount withheld from investment distributions (if applicable)
      W5  Total amounts withheld (W2 + W3 + W4)
      T1  PAYG income tax instalment (if applicable — company instalments)
      Net amount payable to ATO
    """
    conn = get_connection(db_path)

    # W1: Total gross wages paid in period
    # Sum all payslip gross_pay from pay_runs with payment_date in period
    w1_row = conn.execute("""
        SELECT COALESCE(SUM(ps.gross_pay), 0) as total
        FROM payslips ps
        JOIN pay_runs pr ON ps.pay_run_id = pr.id
        WHERE pr.status IN ('Finalised', 'STP_Lodged')
          AND pr.payment_date BETWEEN ? AND ?
    """, (date_from, date_to)).fetchone()

    # W2: PAYG withholding from wages (from payslips)
    w2_row = conn.execute("""
        SELECT COALESCE(SUM(ps.payg_tax), 0) as total
        FROM payslips ps
        JOIN pay_runs pr ON ps.pay_run_id = pr.id
        WHERE pr.status IN ('Finalised', 'STP_Lodged')
          AND pr.payment_date BETWEEN ? AND ?
    """, (date_from, date_to)).fetchone()

    # W2 from journal (PAYG Withholding Payable account 2-1310) as cross-check
    # and to capture any manual PAYG journals
    w2_journal = conn.execute("""
        SELECT COALESCE(SUM(jl.credit), 0) as total
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id = je.id
        JOIN accounts a ON jl.account_id = a.id
        WHERE a.code = '2-1310'
          AND je.entry_date BETWEEN ? AND ?
    """, (date_from, date_to)).fetchone()

    # W3: Withholding where no ABN quoted — look for specific journal entries
    # (businesses sometimes record this separately; check for no-ABN entries)
    w3_row = conn.execute("""
        SELECT COALESCE(SUM(jl.credit), 0) as total
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id = je.id
        JOIN accounts a ON jl.account_id = a.id
        WHERE a.name LIKE '%No ABN%' OR a.name LIKE '%no ABN%'
          AND je.entry_date BETWEEN ? AND ?
    """, (date_from, date_to)).fetchone()

    # T1: PAYG income tax instalments (for company tax instalments)
    # These are typically quarterly and posted as a separate journal
    # Look for journal entries to a PAYG Instalment account if one exists
    t1_row = conn.execute("""
        SELECT COALESCE(SUM(jl.debit), 0) as total
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id = je.id
        JOIN accounts a ON jl.account_id = a.id
        WHERE (a.name LIKE '%PAYG Instalment%' OR a.name LIKE '%Tax Instalment%'
               OR a.code = '2-1320')
          AND je.entry_date BETWEEN ? AND ?
    """, (date_from, date_to)).fetchone()

    # Pay run summary for period
    runs = conn.execute("""
        SELECT pr.run_number, pr.payment_date, pr.frequency,
               pr.pay_period_start, pr.pay_period_end,
               pr.total_gross, pr.total_tax, pr.total_net, pr.total_super,
               pr.status
        FROM pay_runs pr
        WHERE pr.status IN ('Finalised', 'STP_Lodged')
          AND pr.payment_date BETWEEN ? AND ?
        ORDER BY pr.payment_date
    """, (date_from, date_to)).fetchall()

    conn.close()

    w1 = float(w1_row["total"] if w1_row else 0)
    # Use journal figure if larger (catches manual PAYG adjustments)
    w2_payslip = float(w2_row["total"] if w2_row else 0)
    w2_jnl     = float(w2_journal["total"] if w2_journal else 0)
    w2 = max(w2_payslip, w2_jnl)
    w3 = float(w3_row["total"] if w3_row else 0)
    w4 = 0.0   # investment distribution withholding — not tracked in this system
    w5 = round(w2 + w3 + w4, 2)
    t1 = float(t1_row["total"] if t1_row else 0)
    net_payable = round(w5 + t1, 2)

    return {
        "W1_total_wages":          w1,
        "W2_payg_withheld":        w2,
        "W3_no_abn_withholding":   w3,
        "W4_investment_withholding": w4,
        "W5_total_withheld":       w5,
        "T1_tax_instalment":       t1,
        "net_payable":             net_payable,
        "pay_runs":                [dict(r) for r in runs],
        "period_from":             date_from,
        "period_to":               date_to,
    }


# ── Extended Journal Functions ────────────────────────────────────────────────

def get_journal_entry(db_path, journal_id):
    """Return a single journal entry with all its lines."""
    conn = get_connection(db_path)
    entry = conn.execute("SELECT * FROM journal_entries WHERE id=?",
                         (journal_id,)).fetchone()
    lines = conn.execute("""SELECT jl.*, a.code, a.name as account_name,
            a.account_type
        FROM journal_lines jl JOIN accounts a ON jl.account_id=a.id
        WHERE jl.journal_id=? ORDER BY jl.id""", (journal_id,)).fetchall()
    conn.close()
    if not entry:
        return None, []
    return dict(entry), [dict(l) for l in lines]


def get_journal_entries_full(db_path, entry_type=None, search=None,
                              date_from=None, date_to=None, limit=500):
    """Return journal entries with debit/credit totals for display."""
    conn = get_connection(db_path)
    q = """SELECT je.*,
        SUM(jl.debit)  as total_debit,
        SUM(jl.credit) as total_credit,
        COUNT(jl.id)   as line_count
        FROM journal_entries je
        LEFT JOIN journal_lines jl ON jl.journal_id=je.id
        WHERE 1=1"""
    params = []
    if entry_type:
        q += " AND je.entry_type=?"
        params.append(entry_type)
    if search:
        q += " AND (je.description LIKE ? OR je.reference LIKE ?)"
        params += [f"%{search}%", f"%{search}%"]
    if date_from:
        q += " AND je.entry_date>=?"
        params.append(date_from)
    if date_to:
        q += " AND je.entry_date<=?"
        params.append(date_to)
    q += " GROUP BY je.id ORDER BY je.entry_date DESC, je.id DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_journal(db_path, journal_id, entry_date, reference,
                   description, lines, updated_by=None):
    """
    Replace a manual journal entry's lines.
    Only allowed on entry_type='Journal' (not system-generated entries).
    """
    conn = get_connection(db_path)
    entry = conn.execute("SELECT entry_type FROM journal_entries WHERE id=?",
                         (journal_id,)).fetchone()
    if not entry or entry["entry_type"] != "Journal":
        conn.close()
        raise ValueError("Only manual Journal entries can be edited")
    conn.execute("""UPDATE journal_entries
        SET entry_date=?, reference=?, description=?
        WHERE id=?""", (entry_date, reference, description, journal_id))
    conn.execute("DELETE FROM journal_lines WHERE journal_id=?", (journal_id,))
    for l in lines:
        conn.execute("""INSERT INTO journal_lines
            (journal_id,account_id,debit,credit,description,tax_code,gst_amount)
            VALUES (?,?,?,?,?,?,?)""",
            (journal_id, l["account_id"], l.get("debit", 0),
             l.get("credit", 0), l.get("description", ""),
             l.get("tax_code"), l.get("gst_amount", 0)))
    conn.commit(); conn.close()


def void_journal(db_path, journal_id, voided_by=None):
    """
    Void a manual journal entry by posting its reverse,
    then marking the original as voided.
    """
    entry, lines = get_journal_entry(db_path, journal_id)
    if not entry:
        raise ValueError("Journal entry not found")
    if entry.get("entry_type") != "Journal":
        raise ValueError("Only manual Journal entries can be voided")
    if entry.get("reference","").startswith("VOID-"):
        raise ValueError("Entry is already voided")

    # Post reversal
    rev_lines = [{"account_id": l["account_id"],
                  "debit": l["credit"], "credit": l["debit"],
                  "description": f"Reversal: {l.get('description','')}"
                  } for l in lines]
    rev_id = post_journal(
        db_path,
        entry["entry_date"],
        f"VOID: {entry['description']}",
        f"VOID-{entry['reference'] or entry['id']}",
        rev_lines)

    # Mark original as voided
    conn = get_connection(db_path)
    conn.execute("""UPDATE journal_entries
        SET description=?, reference=?
        WHERE id=?""",
        (f"[VOIDED] {entry['description']}",
         f"VOID-{entry['reference'] or entry['id']}",
         journal_id))
    conn.commit(); conn.close()
    return rev_id


def reverse_journal(db_path, journal_id, reverse_date=None):
    """Post an exact reversal of any journal entry (even system-generated)."""
    entry, lines = get_journal_entry(db_path, journal_id)
    if not entry:
        raise ValueError("Journal entry not found")
    from datetime import date
    rev_date = reverse_date or str(date.today())
    rev_lines = [{"account_id": l["account_id"],
                  "debit": l["credit"], "credit": l["debit"],
                  "description": f"Reversal: {l.get('description','')}"
                  } for l in lines]
    return post_journal(
        db_path, rev_date,
        f"Reversal of: {entry['description']}",
        f"REV-{entry['reference'] or entry['id']}",
        rev_lines)


# ── Credit Card Functions ─────────────────────────────────────────────────────

def get_credit_card_accounts(db_path):
    """Return all credit card liability accounts."""
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT * FROM accounts
        WHERE account_subtype='Credit Card'
        ORDER BY code""").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def record_credit_card_charge(db_path, card_account_id, charge_date,
                               description, amount, expense_account_id,
                               reference="", tax_code=None, gst_amount=0.0,
                               contact_id=None, created_by=None):
    """
    Record a credit card charge:
      DR  Expense Account    amount (net)
      DR  GST Paid           gst_amount  (if applicable)
      CR  Credit Card        amount + gst_amount
    Returns journal_id.
    """
    conn = get_connection(db_path)
    total = amount + (gst_amount or 0)

    # GST Paid account
    gst_acc = conn.execute(
        "SELECT id FROM accounts WHERE code='1-1300'").fetchone()
    conn.close()

    lines = [
        {"account_id": expense_account_id, "debit": amount,
         "credit": 0, "description": description,
         "tax_code": tax_code, "gst_amount": gst_amount or 0},
    ]
    if gst_amount and gst_acc:
        lines.append({"account_id": gst_acc["id"], "debit": gst_amount,
                      "credit": 0, "description": f"GST: {description}"})
    lines.append({"account_id": card_account_id, "debit": 0,
                  "credit": total, "description": description})

    jid = post_journal(db_path, charge_date, description, reference, lines)
    conn = get_connection(db_path)
    conn.execute(
        "UPDATE journal_entries SET entry_type='CC Charge', contact_id=? WHERE id=?",
        (contact_id, jid))
    conn.commit()
    conn.close()
    return jid


def record_credit_card_payment(db_path, card_account_id, payment_date,
                                amount, bank_account_id, reference="",
                                description="Credit Card Payment"):
    """
    Record a payment to the credit card from a bank account:
      DR  Credit Card        amount
      CR  Bank Account       amount
    Returns journal_id.
    """
    lines = [
        {"account_id": card_account_id, "debit": amount, "credit": 0,
         "description": description},
        {"account_id": bank_account_id, "debit": 0, "credit": amount,
         "description": description},
    ]
    return post_journal(db_path, payment_date, description, reference, lines)


def void_cc_charge(db_path, journal_id):
    """
    Void a CC charge (or CC payment) by posting a full reversal and marking
    the original entry as voided.  Works on any entry_type that starts with 'CC'.
    """
    entry, lines = get_journal_entry(db_path, journal_id)
    if not entry:
        raise ValueError("Journal entry not found")
    if str(entry.get("reference", "")).startswith("VOID-") or \
            str(entry.get("description", "")).startswith("[VOIDED]"):
        raise ValueError("Entry is already voided")

    rev_lines = [{"account_id": l["account_id"],
                  "debit": l["credit"], "credit": l["debit"],
                  "description": f"Reversal: {l.get('description', '')}"
                  } for l in lines]
    post_journal(
        db_path,
        entry["entry_date"],
        f"VOID: {entry['description']}",
        f"VOID-{entry['reference'] or entry['id']}",
        rev_lines)

    conn = get_connection(db_path)
    conn.execute("""UPDATE journal_entries
        SET description=?, reference=?
        WHERE id=?""",
        (f"[VOIDED] {entry['description']}",
         f"VOID-{entry['reference'] or entry['id']}",
         journal_id))
    conn.commit()
    conn.close()


def get_credit_card_transactions(db_path, card_account_id,
                                  date_from=None, date_to=None):
    """Return all journal lines for a credit card account."""
    conn = get_connection(db_path)
    q = """SELECT je.id as journal_id, je.entry_date, je.reference,
        je.description as journal_desc, je.entry_type,
        je.contact_id, c.name as contact_name,
        jl.debit, jl.credit, jl.description as line_desc,
        jl.is_reconciled,
        (jl.credit - jl.debit) as movement
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id=je.id
        LEFT JOIN contacts c ON je.contact_id=c.id
        WHERE jl.account_id=?"""
    params = [card_account_id]
    if date_from:
        q += " AND je.entry_date>=?"
        params.append(date_from)
    if date_to:
        q += " AND je.entry_date<=?"
        params.append(date_to)
    q += " ORDER BY je.entry_date, je.id"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_credit_card_balance(db_path, card_account_id):
    """Return current balance (amount owed on card — credit balance is positive).
    Includes opening_balance so imported/pre-existing balances are reflected."""
    conn = get_connection(db_path)
    acc = conn.execute(
        "SELECT opening_balance FROM accounts WHERE id=?",
        (card_account_id,)).fetchone()
    row = conn.execute("""SELECT COALESCE(SUM(jl.credit - jl.debit), 0) as balance
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id=je.id
        WHERE jl.account_id=?""", (card_account_id,)).fetchone()
    conn.close()
    opening = (acc["opening_balance"] or 0.0) if acc else 0.0
    journal = row["balance"] if row else 0.0
    # Liability: credit increases balance, debit reduces it; opening adds directly
    return opening + journal


# ══════════════════════════════════════════════════════════════════════════════
#  AGED RECEIVABLES / PAYABLES
# ══════════════════════════════════════════════════════════════════════════════

def aged_receivables(db_path, as_at_date: str = None,
                     buckets: tuple = (0, 30, 60, 90)) -> dict:
    """
    Return aged receivables as at a given date.

    Returns:
        {
          "as_at":   "2025-09-30",
          "buckets": [0, 30, 60, 90],   # days overdue bucket boundaries
          "rows": [
              {
                "contact_id":   1,
                "contact_name": "Acme Pty Ltd",
                "current":      0.00,   # not yet due
                "b0":           0.00,   # 0-30 days overdue
                "b1":           0.00,   # 31-60
                "b2":           0.00,   # 61-90
                "b3":           0.00,   # 90+
                "total":        0.00,
                "invoices":     [...],  # detail rows
              }, ...
          ],
          "totals": { "current":0, "b0":0, "b1":0, "b2":0, "b3":0, "total":0 },
        }
    """
    from datetime import date as _date
    if as_at_date is None:
        as_at_date = str(_date.today())
    as_at = _date.fromisoformat(as_at_date)

    conn = get_connection(db_path)
    invs = conn.execute("""
        SELECT i.id, i.invoice_number, i.invoice_date, i.due_date,
               i.total, i.amount_paid, i.status,
               c.id as contact_id, c.name as contact_name
        FROM invoices i
        JOIN contacts c ON c.id = i.contact_id
        WHERE i.status IN ('Sent','Partial','Overdue')
          AND i.total > i.amount_paid
          AND i.invoice_date <= ?
        ORDER BY c.name, i.due_date
    """, (as_at_date,)).fetchall()
    conn.close()

    contacts = {}
    for inv in invs:
        r      = dict(inv)
        owing  = round(float(r["total"] or 0) - float(r["amount_paid"] or 0), 2)
        if owing <= 0:
            continue
        due    = _date.fromisoformat(r["due_date"])
        days   = (as_at - due).days   # negative = not yet due

        cid    = r["contact_id"]
        if cid not in contacts:
            contacts[cid] = {
                "contact_id":   cid,
                "contact_name": r["contact_name"],
                "current": 0.0,
                "b0": 0.0,   # 1-30
                "b1": 0.0,   # 31-60
                "b2": 0.0,   # 61-90
                "b3": 0.0,   # 90+
                "total":   0.0,
                "invoices": [],
            }
        c = contacts[cid]

        if days <= 0:
            bucket = "current"
        elif days <= buckets[1]:
            bucket = "b0"
        elif days <= buckets[2]:
            bucket = "b1"
        elif days <= buckets[3]:
            bucket = "b2"
        else:
            bucket = "b3"

        c[bucket] += owing
        c["total"] += owing
        c["invoices"].append({
            "invoice_id":     r["id"],
            "invoice_number": r["invoice_number"],
            "invoice_date":   r["invoice_date"],
            "due_date":       r["due_date"],
            "total":          float(r["total"] or 0),
            "amount_paid":    float(r["amount_paid"] or 0),
            "owing":          owing,
            "days_overdue":   max(0, days),
            "bucket":         bucket,
        })

    rows = sorted(contacts.values(), key=lambda x: x["contact_name"])
    totals = {k: round(sum(r[k] for r in rows), 2)
              for k in ("current","b0","b1","b2","b3","total")}

    return {
        "as_at":   as_at_date,
        "buckets": buckets,
        "rows":    rows,
        "totals":  totals,
    }


def aged_payables(db_path, as_at_date: str = None,
                  buckets: tuple = (0, 30, 60, 90)) -> dict:
    """Aged payables — mirror of aged_receivables but for bills."""
    from datetime import date as _date
    if as_at_date is None:
        as_at_date = str(_date.today())
    as_at = _date.fromisoformat(as_at_date)

    conn = get_connection(db_path)
    bills = conn.execute("""
        SELECT b.id, b.bill_number, b.bill_date, b.due_date,
               b.total, b.amount_paid, b.status,
               c.id as contact_id, c.name as contact_name
        FROM bills b
        JOIN contacts c ON c.id = b.contact_id
        WHERE b.status IN ('Approved','Partial','Overdue')
          AND b.total > b.amount_paid
          AND b.bill_date <= ?
        ORDER BY c.name, b.due_date
    """, (as_at_date,)).fetchall()
    conn.close()

    contacts = {}
    for bill in bills:
        r     = dict(bill)
        owing = round(float(r["total"] or 0) - float(r["amount_paid"] or 0), 2)
        if owing <= 0:
            continue
        due   = _date.fromisoformat(r["due_date"])
        days  = (as_at - due).days

        cid   = r["contact_id"]
        if cid not in contacts:
            contacts[cid] = {
                "contact_id":   cid,
                "contact_name": r["contact_name"],
                "current": 0.0, "b0": 0.0, "b1": 0.0, "b2": 0.0, "b3": 0.0,
                "total": 0.0, "bills": [],
            }
        c = contacts[cid]

        if days <= 0:
            bucket = "current"
        elif days <= buckets[1]:
            bucket = "b0"
        elif days <= buckets[2]:
            bucket = "b1"
        elif days <= buckets[3]:
            bucket = "b2"
        else:
            bucket = "b3"

        c[bucket] += owing
        c["total"] += owing
        c["bills"].append({
            "bill_id":     r["id"],
            "bill_number": r["bill_number"] or "",
            "bill_date":   r["bill_date"],
            "due_date":    r["due_date"],
            "total":       float(r["total"] or 0),
            "amount_paid": float(r["amount_paid"] or 0),
            "owing":       owing,
            "days_overdue": max(0, days),
            "bucket":      bucket,
        })

    rows   = sorted(contacts.values(), key=lambda x: x["contact_name"])
    totals = {k: round(sum(r[k] for r in rows), 2)
              for k in ("current","b0","b1","b2","b3","total")}

    return {
        "as_at":   as_at_date,
        "buckets": buckets,
        "rows":    rows,
        "totals":  totals,
    }


# ══════════════════════════════════════════════════════════════════════════════
#  CASH FLOW STATEMENT
# ══════════════════════════════════════════════════════════════════════════════

def cash_flow_statement(db_path: str, date_from: str, date_to: str) -> dict:
    """
    Indirect method cash flow statement for the period.

    Operating:
      Net Profit (from P&L, accrual)
      + Depreciation / amortisation (non-cash expense accounts tagged as such)
      ± Changes in Working Capital:
          - Increase in AR (more invoiced = cash not yet received)
          + Decrease in AR
          - Decrease in AP (paid more than we owed)
          + Increase in AP
          ± Change in Inventory
    Investing:
      Payments for fixed assets (accounts with type Asset, subtype Fixed Asset)
    Financing:
      Owner drawings / distributions
      Loan proceeds / repayments

    Returns dict:
        operating: {items: [...], subtotal: float}
        investing:  {items: [...], subtotal: float}
        financing:  {items: [...], subtotal: float}
        net_change: float
        opening_cash: float
        closing_cash: float
    """
    from datetime import date as _d, timedelta as _td

    conn = get_connection(db_path)

    # ── Net Profit (accrual) ─────────────────────────────────────────────────
    pl = profit_and_loss(db_path, date_from, date_to, basis="accrual")
    net_profit = pl.get("net_profit", 0.0)

    # ── Working capital changes (true balance-sheet approach) ────────────────
    # For any account, the cash-flow impact of its balance change in the period is:
    #   -(net debit − credit in period)
    # This works for both assets (debit = increase = cash used = negative) and
    # liabilities (credit = increase = cash saved = positive).
    # Using journal movements (= balance-sheet change) captures ALL entries,
    # including direct adjustments, not just the invoice/bill/payment cycle.
    def _wc_chg(code):
        row = conn.execute("SELECT id FROM accounts WHERE code=?", (code,)).fetchone()
        if not row:
            return 0.0
        mv = conn.execute("""
            SELECT COALESCE(SUM(jl.debit - jl.credit), 0) as v
            FROM journal_lines jl
            JOIN journal_entries je ON jl.journal_id=je.id
            WHERE jl.account_id=? AND je.entry_date BETWEEN ? AND ?
        """, (row["id"], date_from, date_to)).fetchone()["v"]
        return -float(mv)

    ar_change       = _wc_chg("1-1200")   # AR:       increase = used cash (−)
    ap_change       = _wc_chg("2-1100")   # AP:       increase = saved cash (+)
    gst_paid_change = _wc_chg("1-1300")   # GST Paid: increase = used cash (−)

    # ── Inventory change ─────────────────────────────────────────────────────
    # Use the GL account (1-1400) as the authoritative source — captures all
    # inventory transactions (receipts, adjustments, write-offs) at GL cost.
    inv_change = _wc_chg("1-1400")

    # ── Investing: payments to fixed asset accounts ───────────────────────────
    fixed_asset_accs = conn.execute("""
        SELECT id, name, code FROM accounts
        WHERE account_type='Asset' AND account_subtype IN ('Fixed Asset','Non-Current Asset')
    """).fetchall()

    investing_items = []
    investing_total = 0.0
    for acc in fixed_asset_accs:
        mv = conn.execute("""
            SELECT COALESCE(SUM(jl.debit - jl.credit), 0) as v
            FROM journal_lines jl
            JOIN journal_entries je ON jl.journal_id=je.id
            WHERE jl.account_id=? AND je.entry_date BETWEEN ? AND ?
        """, (acc["id"], date_from, date_to)).fetchone()["v"]
        if abs(mv) >= 0.01:
            investing_items.append({
                "label": f"{acc['code']}  {acc['name']}",
                "amount": -mv,  # debit to asset = cash outflow
            })
            investing_total += -mv

    # ── Financing: equity / loan / borrowing movements ───────────────────────
    # Only Accounts Payable is excluded — it's operating WC (trade creditors).
    # Everything else (CC, loans, overdrafts, equity) is financing by BS class.
    # Any new liability account a user creates (loan, chattel mortgage, line of
    # credit) is automatically included here without needing a flag.
    # Exclude EOFY closing entries (reference LIKE 'EOFY-%') — those journals
    # transfer net profit into Retained Earnings; net_profit is already in
    # operating so including the EOFY RE credit here would double-count it.
    financing_accs = conn.execute("""
        SELECT id, name, code FROM accounts
        WHERE account_type IN ('Equity','Liability')
          AND account_subtype NOT IN ('Accounts Payable')
    """).fetchall()

    financing_items = []
    financing_total = 0.0
    for acc in financing_accs:
        mv = conn.execute("""
            SELECT COALESCE(SUM(jl.credit - jl.debit), 0) as v
            FROM journal_lines jl
            JOIN journal_entries je ON jl.journal_id=je.id
            WHERE jl.account_id=? AND je.entry_date BETWEEN ? AND ?
              AND (je.reference IS NULL OR je.reference NOT LIKE 'EOFY-%')
        """, (acc["id"], date_from, date_to)).fetchone()["v"]
        if abs(mv) >= 0.01:
            financing_items.append({
                "label":  f"{acc['code']}  {acc['name']}",
                "amount": mv,
            })
            financing_total += mv

    # ── Cash balances ─────────────────────────────────────────────────────────
    bank_accs = conn.execute("""
        SELECT id FROM accounts WHERE is_bank=1 AND is_credit_card=0
    """).fetchall()
    bank_ids = [a["id"] for a in bank_accs]

    def cash_balance_at(dt):
        if not bank_ids:
            return 0.0
        ph = ",".join("?" * len(bank_ids))
        row = conn.execute(f"""
            SELECT COALESCE(SUM(jl.debit - jl.credit), 0) as v
            FROM journal_lines jl
            JOIN journal_entries je ON jl.journal_id=je.id
            WHERE jl.account_id IN ({ph}) AND je.entry_date <= ?
        """, bank_ids + [dt]).fetchone()
        return float(row["v"] if row else 0)

    closing_cash = cash_balance_at(date_to)
    # Opening = closing minus net movement in period
    net_bank_mv = conn.execute(f"""
        SELECT COALESCE(SUM(jl.debit - jl.credit), 0) as v
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id=je.id
        WHERE jl.account_id IN ({",".join("?" * len(bank_ids)) if bank_ids else "NULL"})
          AND je.entry_date BETWEEN ? AND ?
    """, (bank_ids + [date_from, date_to]) if bank_ids else [date_from, date_to]).fetchone()["v"] if bank_ids else 0.0
    opening_cash = closing_cash - float(net_bank_mv)

    conn.close()

    # ── Operating section ─────────────────────────────────────────────────────
    operating_items = [
        {"label": "Net Profit / (Loss)",           "amount": net_profit},
        {"label": "Change in Accounts Receivable", "amount": ar_change},
        {"label": "Change in Accounts Payable",    "amount": ap_change},
    ]
    operating_total = net_profit + ar_change + ap_change

    if abs(inv_change) >= 0.01:
        operating_items.append({"label": "Change in Inventory", "amount": inv_change})
        operating_total += inv_change

    if abs(gst_paid_change) >= 0.01:
        operating_items.append({"label": "Change in GST Input Credits", "amount": gst_paid_change})
        operating_total += gst_paid_change

    return {
        "date_from":     date_from,
        "date_to":       date_to,
        "operating":     {"items": operating_items, "subtotal": round(operating_total, 2)},
        "investing":     {"items": investing_items, "subtotal": round(investing_total, 2)},
        "financing":     {"items": financing_items, "subtotal": round(financing_total, 2)},
        "net_change":    round(operating_total + investing_total + financing_total, 2),
        "opening_cash":  round(opening_cash, 2),
        "closing_cash":  round(closing_cash, 2),
    }


# ══════════════════════════════════════════════════════════════════════════════
#  STATEMENT OF ACCOUNT (per contact)
# ══════════════════════════════════════════════════════════════════════════════

def statement_of_account(db_path: str, contact_id: int,
                          date_from: str = None,
                          date_to: str = None) -> dict:
    """
    Generate a statement of account for a contact showing:
      - All invoices in the period (or all time if no dates)
      - Payments received
      - Running balance
    Returns a dict ready for PDF or display.
    """
    from datetime import date as _d
    conn = get_connection(db_path)

    contact = conn.execute(
        "SELECT * FROM contacts WHERE id=?", (contact_id,)).fetchone()
    if not contact:
        conn.close()
        return {}
    contact = dict(contact)

    # Get invoices (regular only — credit notes handled separately)
    q_inv = """
        SELECT id, invoice_number as ref_no, invoice_date as txn_date,
               due_date, total, amount_paid, status,
               'Invoice' as txn_type
        FROM invoices
        WHERE contact_id=? AND status NOT IN ('Void','Draft')
          AND (is_credit_note IS NULL OR is_credit_note = 0)
    """
    params_inv = [contact_id]
    if date_from:
        q_inv += " AND invoice_date >= ?"
        params_inv.append(date_from)
    if date_to:
        q_inv += " AND invoice_date <= ?"
        params_inv.append(date_to)

    invoices = [dict(r) for r in conn.execute(q_inv, params_inv).fetchall()]

    # Get credit notes — appear as credits (reduce what the customer owes)
    q_cn = """
        SELECT id, invoice_number as ref_no, invoice_date as txn_date,
               total, status
        FROM invoices
        WHERE contact_id=? AND is_credit_note = 1
          AND status NOT IN ('Void','Draft')
    """
    params_cn = [contact_id]
    if date_from:
        q_cn += " AND invoice_date >= ?"
        params_cn.append(date_from)
    if date_to:
        q_cn += " AND invoice_date <= ?"
        params_cn.append(date_to)

    credit_notes = [dict(r) for r in conn.execute(q_cn, params_cn).fetchall()]

    # Get payments (receipts from this contact that went through A/R)
    # Exclude receipts with expense_account_id — those are cash sales posted
    # direct to an income account and never touched A/R
    q_pmt = """
        SELECT p.id, 'RCP-'||p.id as ref_no, p.payment_date as txn_date,
               NULL as due_date, p.amount as total, p.amount as amount_paid,
               'Received' as status, 'Payment' as txn_type,
               p.reference, p.description
        FROM payments p
        WHERE p.contact_id=? AND p.payment_type='Receipt'
          AND (p.expense_account_id IS NULL OR p.expense_account_id = 0)
    """
    params_pmt = [contact_id]
    if date_from:
        q_pmt += " AND p.payment_date >= ?"
        params_pmt.append(date_from)
    if date_to:
        q_pmt += " AND p.payment_date <= ?"
        params_pmt.append(date_to)

    payments = [dict(r) for r in conn.execute(q_pmt, params_pmt).fetchall()]

    # Get cash sale receipts (direct to income account, bypass A/R)
    # These appear as paired Sale + Receipt lines — visible but net zero on balance
    q_cash = """
        SELECT p.id, 'RCP-'||p.id as ref_no, p.payment_date as txn_date,
               p.amount as total, p.reference, p.description,
               a.name as income_account_name
        FROM payments p
        LEFT JOIN accounts a ON p.expense_account_id = a.id
        WHERE p.contact_id=? AND p.payment_type='Receipt'
          AND p.expense_account_id IS NOT NULL AND p.expense_account_id != 0
    """
    params_cash = [contact_id]
    if date_from:
        q_cash += " AND p.payment_date >= ?"
        params_cash.append(date_from)
    if date_to:
        q_cash += " AND p.payment_date <= ?"
        params_cash.append(date_to)

    cash_sales = [dict(r) for r in conn.execute(q_cash, params_cash).fetchall()]

    # Opening balance — net A/R activity strictly before date_from
    opening_balance = 0.0
    if date_from:
        ob_inv = conn.execute(
            "SELECT COALESCE(SUM(total),0) FROM invoices "
            "WHERE contact_id=? AND status NOT IN ('Void','Draft') "
            "  AND (is_credit_note IS NULL OR is_credit_note = 0) AND invoice_date < ?",
            (contact_id, date_from)).fetchone()[0]
        ob_cn = conn.execute(
            "SELECT COALESCE(SUM(total),0) FROM invoices "
            "WHERE contact_id=? AND is_credit_note = 1 "
            "  AND status NOT IN ('Void','Draft') AND invoice_date < ?",
            (contact_id, date_from)).fetchone()[0]
        ob_pmt = conn.execute(
            "SELECT COALESCE(SUM(amount),0) FROM payments "
            "WHERE contact_id=? AND payment_type='Receipt' "
            "  AND (expense_account_id IS NULL OR expense_account_id=0) "
            "  AND payment_date < ?",
            (contact_id, date_from)).fetchone()[0]
        opening_balance = round(float(ob_inv or 0) - float(ob_cn or 0) - float(ob_pmt or 0), 2)
    conn.close()

    # Merge and sort by date
    all_txns = []
    for inv in invoices:
        all_txns.append({
            "txn_type":  "Invoice",
            "date":      inv["txn_date"],
            "due_date":  inv.get("due_date", ""),
            "ref":       inv["ref_no"],
            "debit":     float(inv["total"] or 0),   # amount owed
            "credit":    0.0,
            "status":    inv["status"],
            "cash_sale": False,
        })
    for cn in credit_notes:
        all_txns.append({
            "txn_type":  "Credit Note",
            "date":      cn["txn_date"],
            "due_date":  "",
            "ref":       cn["ref_no"],
            "debit":     0.0,
            "credit":    float(cn["total"] or 0),
            "status":    "Credit Note",
            "cash_sale": False,
        })
    for pmt in payments:
        all_txns.append({
            "txn_type":  "Payment",
            "date":      pmt["txn_date"],
            "due_date":  "",
            "ref":       pmt.get("reference") or pmt["ref_no"],
            "debit":     0.0,
            "credit":    float(pmt["total"] or 0),   # payment received
            "status":    "Received",
            "cash_sale": False,
        })
    for cs in cash_sales:
        amt = float(cs["total"] or 0)
        acc = cs.get("income_account_name") or "Cash Sale"
        ref = cs.get("reference") or cs["ref_no"]
        # Sale line — debit (charge)
        all_txns.append({
            "txn_type":  "Cash Sale",
            "date":      cs["txn_date"],
            "due_date":  "",
            "ref":       ref,
            "debit":     amt,
            "credit":    0.0,
            "status":    acc,
            "cash_sale": True,
        })
        # Receipt line — credit (immediate payment), same date/ref
        all_txns.append({
            "txn_type":  "Cash Receipt",
            "date":      cs["txn_date"],
            "due_date":  "",
            "ref":       ref,
            "debit":     0.0,
            "credit":    amt,
            "status":    "Paid",
            "cash_sale": True,
        })

    all_txns.sort(key=lambda x: (x["date"], 0 if not x["cash_sale"] else 1))

    # Running balance — starts from opening_balance; cash sale pairs net to zero
    balance = opening_balance
    for txn in all_txns:
        balance += txn["debit"] - txn["credit"]
        txn["balance"] = round(balance, 2)

    # Summary totals — period only (exclude cash sale pairs; opening balance separate)
    total_invoiced = sum(t["debit"]  for t in all_txns if not t.get("cash_sale") and t["txn_type"] == "Invoice")
    total_credits  = sum(t["credit"] for t in all_txns if t["txn_type"] == "Credit Note")
    total_received = sum(t["credit"] for t in all_txns if not t.get("cash_sale") and t["txn_type"] not in ("Credit Note",))
    total_cash     = sum(t["debit"]  for t in all_txns if t.get("cash_sale") and t["txn_type"] == "Cash Sale")
    closing_balance = round(balance, 2)

    return {
        "contact":           contact,
        "date_from":         date_from,
        "date_to":           date_to,
        "transactions":      all_txns,
        "opening_balance":   opening_balance,
        "total_invoiced":    round(total_invoiced, 2),
        "total_credits":     round(total_credits, 2),
        "total_received":    round(total_received, 2),
        "total_cash_sales":  round(total_cash, 2),
        "closing_balance":   closing_balance,
    }


# ══════════════════════════════════════════════════════════════════════════════
#  GST DRILLDOWN
# ══════════════════════════════════════════════════════════════════════════════

def gst_drilldown(db_path: str, date_from: str, date_to: str,
                   basis: str = "accrual") -> dict:
    """
    Return every transaction contributing to the BAS GST figures,
    split into:
      - sales:     invoices with GST collected per line (tax_code GST/WET/LCT)
      - purchases: bills with GST credits per line
      - journals:  manual journal lines hitting GST accounts
      - adjustments: credit notes / void reversals

    Each item has:
      date, number, contact, description, tax_code,
      excl_amount, gst_amount, incl_amount, source_type
    """
    conn = get_connection(db_path)

    # ── Sales — invoice lines with GST ──────────────────────────────────────
    if basis == "cash":
        date_col = "p.payment_date"
        inv_join  = """
            JOIN payment_allocations pa ON pa.invoice_id = i.id
            JOIN payments p ON pa.payment_id = p.id
              AND p.payment_type = 'Receipt'
        """
        inv_where = f"AND {date_col} BETWEEN ? AND ?"
    else:
        date_col  = "i.invoice_date"
        inv_join  = ""
        inv_where = f"AND {date_col} BETWEEN ? AND ?"

    sales_rows = conn.execute(f"""
        SELECT
            {date_col}                     AS txn_date,
            i.invoice_number               AS ref,
            c.name                         AS contact,
            il.description                 AS description,
            il.tax_code                    AS tax_code,
            il.quantity * il.unit_price    AS excl_amount,
            COALESCE(il.gst_amount, 0)     AS gst_amount,
            il.line_total                  AS incl_amount,
            'Invoice'                      AS source_type,
            i.id                           AS doc_id
        FROM invoice_lines il
        JOIN invoices i   ON il.invoice_id = i.id
        JOIN contacts c   ON i.contact_id  = c.id
        {inv_join}
        WHERE i.status NOT IN ('Draft','Void')
          {inv_where}
          AND COALESCE(il.gst_amount, 0) <> 0
        ORDER BY txn_date, i.id, il.id
    """, (date_from, date_to)).fetchall()

    # ── Purchases — bill lines with GST ─────────────────────────────────────
    if basis == "cash":
        bill_date_col = "p.payment_date"
        bill_join = """
            JOIN payment_allocations pa ON pa.bill_id = b.id
            JOIN payments p ON pa.payment_id = p.id
              AND p.payment_type = 'Payment'
        """
        bill_where = f"AND {bill_date_col} BETWEEN ? AND ?"
    else:
        bill_date_col = "b.bill_date"
        bill_join     = ""
        bill_where    = f"AND {bill_date_col} BETWEEN ? AND ?"

    purchase_rows = conn.execute(f"""
        SELECT
            {bill_date_col}                AS txn_date,
            b.bill_number                  AS ref,
            c.name                         AS contact,
            bl.description                 AS description,
            bl.tax_code                    AS tax_code,
            bl.quantity * bl.unit_price    AS excl_amount,
            COALESCE(bl.gst_amount, 0)     AS gst_amount,
            bl.line_total                  AS incl_amount,
            'Bill'                         AS source_type,
            b.id                           AS doc_id
        FROM bill_lines bl
        JOIN bills b      ON bl.bill_id   = b.id
        JOIN contacts c   ON b.contact_id = c.id
        {bill_join}
        WHERE b.status NOT IN ('Draft','Void')
          {bill_where}
          AND COALESCE(bl.gst_amount, 0) <> 0
        ORDER BY txn_date, b.id, bl.id
    """, (date_from, date_to)).fetchall()

    # ── Manual journal lines hitting GST accounts ────────────────────────────
    journal_rows = conn.execute("""
        SELECT
            je.entry_date              AS txn_date,
            je.reference               AS ref,
            ''                         AS contact,
            jl.description             AS description,
            a.code                     AS tax_code,
            0                          AS excl_amount,
            (jl.credit - jl.debit)     AS gst_amount,
            (jl.credit - jl.debit)     AS incl_amount,
            'Journal'                  AS source_type,
            je.id                      AS doc_id
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id = je.id
        JOIN accounts a         ON jl.account_id  = a.id
        WHERE a.code IN ('2-1200','1-1300')
          AND je.entry_type = 'Manual'
          AND je.entry_date BETWEEN ? AND ?
          AND (jl.credit - jl.debit) <> 0
        ORDER BY txn_date, je.id
    """, (date_from, date_to)).fetchall()

    conn.close()

    def to_dicts(rows):
        return [dict(r) for r in rows]

    sales     = to_dicts(sales_rows)
    purchases = to_dicts(purchase_rows)
    journals  = to_dicts(journal_rows)

    # Totals
    total_gst_collected = round(sum(r["gst_amount"] for r in sales), 2)
    total_gst_credits   = round(sum(r["gst_amount"] for r in purchases), 2)
    total_journal_adj   = round(sum(r["gst_amount"] for r in journals), 2)
    net_gst             = round(total_gst_collected - total_gst_credits
                                 + total_journal_adj, 2)

    return {
        "sales":               sales,
        "purchases":           purchases,
        "journals":            journals,
        "total_gst_collected": total_gst_collected,
        "total_gst_credits":   total_gst_credits,
        "total_journal_adj":   total_journal_adj,
        "net_gst":             net_gst,
        "date_from":           date_from,
        "date_to":             date_to,
        "basis":               basis,
    }

def get_monthly_totals(db_path, months=6):
    """
    Returns list of last `months` months (oldest first) with:
      { month: "YYYY-MM", income: float, expenses: float, bank: float }
    Used for dashboard sparklines.
    """
    from datetime import date, timedelta
    import calendar

    conn = get_connection(db_path)
    today = date.today()
    result = []

    for i in range(months - 1, -1, -1):
        # First day of each month going back
        month_date = today.replace(day=1)
        for _ in range(i):
            month_date = (month_date - timedelta(days=1)).replace(day=1)
        year, month = month_date.year, month_date.month
        last_day = calendar.monthrange(year, month)[1]
        d_from = f"{year:04d}-{month:02d}-01"
        d_to   = f"{year:04d}-{month:02d}-{last_day:02d}"
        label  = f"{year:04d}-{month:02d}"

        # Income: sum of invoice totals in the month (accrual)
        inc_row = conn.execute("""
            SELECT COALESCE(SUM(total), 0) AS inc
            FROM invoices
            WHERE invoice_date BETWEEN ? AND ?
              AND status NOT IN ('Void','Draft')
        """, (d_from, d_to)).fetchone()

        # Expenses: sum of bill totals in the month
        exp_row = conn.execute("""
            SELECT COALESCE(SUM(total), 0) AS exp
            FROM bills
            WHERE bill_date BETWEEN ? AND ?
              AND status NOT IN ('Void','Draft')
        """, (d_from, d_to)).fetchone()

        result.append({
            "month":    label,
            "income":   float(inc_row["inc"] or 0),
            "expenses": float(exp_row["exp"] or 0),
        })

    conn.close()
    return result

def get_monthly_revenue(db_path, months: int = 6):
    """
    Return last N months of net revenue (invoices paid/sent) and expenses (bills).
    Returns list of dicts: {month: "YYYY-MM", revenue: float, expenses: float, profit: float}
    ordered oldest → newest.
    """
    from datetime import date, timedelta
    import calendar

    conn = get_connection(db_path)
    today = date.today()
    result = []

    for i in range(months - 1, -1, -1):
        # Calculate first/last day of month i months ago
        month_date = date(today.year, today.month, 1)
        # Go back i months
        m = today.month - i
        y = today.year
        while m <= 0:
            m += 12
            y -= 1
        last_day = calendar.monthrange(y, m)[1]
        month_str = f"{y}-{m:02d}"
        d_from = f"{y}-{m:02d}-01"
        d_to   = f"{y}-{m:02d}-{last_day:02d}"

        rev_row = conn.execute("""
            SELECT COALESCE(SUM(total), 0) AS rev
            FROM invoices
            WHERE status NOT IN ('Void','Draft')
              AND invoice_date BETWEEN ? AND ?
        """, (d_from, d_to)).fetchone()

        exp_row = conn.execute("""
            SELECT COALESCE(SUM(total), 0) AS exp
            FROM bills
            WHERE status NOT IN ('Void','Draft')
              AND bill_date BETWEEN ? AND ?
        """, (d_from, d_to)).fetchone()

        rev = float(rev_row["rev"] or 0)
        exp = float(exp_row["exp"] or 0)
        result.append({
            "month":    month_str,
            "revenue":  rev,
            "expenses": exp,
            "profit":   rev - exp,
        })

    conn.close()
    return result


# ── EOFY Rollover ─────────────────────────────────────────────────────────────

def _fy_range(fy_start_month: int, fy_year: int):
    """Return (fy_start date, fy_end date) for the FY that ends in fy_year."""
    import calendar as _cal
    from datetime import date as _d
    fy_end_month = (fy_start_month - 1) or 12
    fy_end_day   = _cal.monthrange(fy_year, fy_end_month)[1]
    fy_end       = _d(fy_year, fy_end_month, fy_end_day)
    fy_start     = _d(fy_year, 1, 1) if fy_start_month == 1 else _d(fy_year - 1, fy_start_month, 1)
    return fy_start, fy_end


def eofy_status(db_path):
    """
    Return info about the FY that needs attention next.

    Priority:
    1. Most recently completed FY that has NOT been rolled yet  → ready to roll
    2. If all completed FYs are rolled, the currently running FY → in progress
    """
    from datetime import date as _d
    today = _d.today()
    conn  = get_connection(db_path)
    row   = conn.execute("SELECT fy_start_month, lock_date FROM company LIMIT 1").fetchone()
    conn.close()

    fy_start_month = (row["fy_start_month"] if row else None) or 7
    lock_date      = (row["lock_date"] if row else None) or ""

    # Find the most recently completed FY
    fy_start = fy_end = None
    for candidate in [today.year, today.year - 1, today.year - 2]:
        s, e = _fy_range(fy_start_month, candidate)
        if e < today:
            fy_start, fy_end = s, e
            break
    if fy_end is None:
        fy_start, fy_end = _fy_range(fy_start_month, today.year)

    fy_year        = fy_end.year
    already_rolled = bool(lock_date and lock_date >= fy_end.isoformat())

    # Pre-flight checks — only relevant for a completed FY not yet rolled.
    preflight = None
    if fy_end < today and not already_rolled:
        conn2 = get_connection(db_path)
        ar = conn2.execute("""
            SELECT COUNT(*) AS c,
                   COALESCE(SUM(total - COALESCE(amount_paid,0)), 0) AS t
            FROM invoices
            WHERE status NOT IN ('Paid','Void','Credit Note')
              AND is_credit_note = 0
              AND invoice_date <= ?""", (fy_end.isoformat(),)).fetchone()
        ap = conn2.execute("""
            SELECT COUNT(*) AS c,
                   COALESCE(SUM(total - COALESCE(amount_paid,0)), 0) AS t
            FROM bills
            WHERE status NOT IN ('Paid','Void')
              AND bill_date <= ?""", (fy_end.isoformat(),)).fetchone()
        unreconciled = conn2.execute("""
            SELECT COUNT(DISTINCT jl.id) AS c
            FROM journal_lines jl
            JOIN journal_entries je ON jl.journal_id = je.id
            JOIN accounts a ON jl.account_id = a.id
            WHERE a.is_bank = 1
              AND jl.is_reconciled = 0
              AND (jl.is_rejected IS NULL OR jl.is_rejected = 0)
              AND je.entry_date <= ?""", (fy_end.isoformat(),)).fetchone()
        conn2.close()
        preflight = {
            "ar_outstanding": {"count": int(ar["c"]), "total": round(float(ar["t"]), 2)},
            "ap_outstanding": {"count": int(ap["c"]), "total": round(float(ap["t"]), 2)},
            "unreconciled_bank": int(unreconciled["c"]),
        }

    # If the most recently completed FY is already rolled, advance to show
    # the currently running FY so the user sees their current year.
    if already_rolled:
        fy_start, fy_end = _fy_range(fy_start_month, fy_year + 1)
        fy_year        = fy_end.year
        already_rolled = False

    fy_completed = fy_end < today
    pl = profit_and_loss(db_path, fy_start.isoformat(), fy_end.isoformat())

    # pkg_fy: always the most recently completed FY regardless of rollover state.
    # The accountant package is always downloaded for the completed year, even
    # when eofy_status() has advanced to show the currently running FY.
    pkg_fy = None
    for candidate in [today.year, today.year - 1, today.year - 2]:
        ps, pe = _fy_range(fy_start_month, candidate)
        if pe < today:
            pkg_fy = {"start": ps.isoformat(), "end": pe.isoformat(),
                      "label": f"FY{pe.year}", "year": pe.year}
            break

    return {
        "fy_year":       fy_year,
        "fy_start":      fy_start.isoformat(),
        "fy_end":        fy_end.isoformat(),
        "fy_label":      f"FY{fy_year}",
        "net_profit":    pl["net_profit"],
        "total_income":  pl["total_income"],
        "total_expense": pl["total_expense"],
        "lock_date":     lock_date,
        "already_rolled": already_rolled,
        "fy_completed":  fy_completed,
        "pkg_fy":        pkg_fy,
        "preflight":     preflight,
    }


def perform_eofy_rollover(db_path, fy_year: int):
    """
    Post year-end closing entries and set lock_date.

    Closes all Income/Expense accounts to Retained Earnings (3-1300) by posting
    a Journal entry dated the last day of the FY.  Sets company.lock_date so
    manual journals cannot be backdated into the closed year.

    Returns {journal_id, net_profit, lock_date, fy_year}.
    """
    from datetime import date as _d
    today = _d.today()
    conn  = get_connection(db_path)
    row   = conn.execute("SELECT fy_start_month, lock_date FROM company LIMIT 1").fetchone()
    fy_start_month = (row["fy_start_month"] if row else None) or 7
    lock_date      = (row["lock_date"] if row else None) or ""

    fy_start, fy_end = _fy_range(fy_start_month, fy_year)

    if fy_end >= today:
        conn.close()
        raise ValueError(f"FY{fy_year} ends {fy_end} — cannot roll over an incomplete year")
    if lock_date and lock_date >= fy_end.isoformat():
        conn.close()
        raise ValueError(f"FY{fy_year} has already been rolled over (locked through {lock_date})")

    re_row = conn.execute("SELECT id FROM accounts WHERE code='3-1300' LIMIT 1").fetchone()
    if not re_row:
        conn.close()
        raise ValueError("Retained Earnings account (3-1300) not found — please add it before running EOFY")
    re_id = re_row["id"]

    gl = conn.execute("""
        SELECT a.id AS account_id, a.name, a.account_type,
               COALESCE(SUM(jl.debit),  0) AS total_debit,
               COALESCE(SUM(jl.credit), 0) AS total_credit
        FROM accounts a
        JOIN journal_lines jl ON a.id = jl.account_id
        JOIN journal_entries je ON jl.journal_id = je.id
        WHERE a.account_type IN ('Income','Revenue','Other Income','Expense','Cost of Sales')
          AND je.entry_date BETWEEN ? AND ?
        GROUP BY a.id
    """, (fy_start.isoformat(), fy_end.isoformat())).fetchall()

    lines         = []
    total_income  = 0.0
    total_expense = 0.0

    for r in gl:
        if r["account_type"] in ("Income", "Revenue", "Other Income"):
            net = round(r["total_credit"] - r["total_debit"], 2)
            if net == 0:
                continue
            lines.append({
                "account_id":  r["account_id"],
                "debit":       max(net, 0),
                "credit":      max(-net, 0),
                "description": f"Year end close — {r['name']}",
            })
            total_income += net
        else:
            net = round(r["total_debit"] - r["total_credit"], 2)
            if net == 0:
                continue
            lines.append({
                "account_id":  r["account_id"],
                "debit":       max(-net, 0),
                "credit":      max(net, 0),
                "description": f"Year end close — {r['name']}",
            })
            total_expense += net

    net_profit = round(total_income - total_expense, 2)
    lines.append({
        "account_id":  re_id,
        "debit":       round(-net_profit, 2) if net_profit < 0 else 0,
        "credit":      round(net_profit,  2) if net_profit >= 0 else 0,
        "description": f"Year end close — net {'profit' if net_profit >= 0 else 'loss'} to retained earnings",
    })

    c = conn.cursor()
    c.execute("""INSERT INTO journal_entries
        (entry_date, reference, description, entry_type)
        VALUES (?, ?, ?, 'Journal')""",
        (fy_end.isoformat(), f"EOFY-{fy_year}",
         f"Year end closing entries — FY{fy_year}"))
    jid = c.lastrowid
    for l in lines:
        c.execute("""INSERT INTO journal_lines
            (journal_id, account_id, debit, credit, description)
            VALUES (?, ?, ?, ?, ?)""",
            (jid, l["account_id"], l["debit"], l["credit"], l["description"]))

    conn.execute("UPDATE company SET lock_date=?", (fy_end.isoformat(),))
    conn.commit()
    conn.close()
    return {"journal_id": jid, "net_profit": net_profit,
            "lock_date": fy_end.isoformat(), "fy_year": fy_year}


# ── Tax Return Summary ──────────────────────────────────────────────────────

_ATO_EXPENSE_ORDER = [
    'Salaries & Wages',
    'Contractor & Commission Expenses',
    'Rent & Leasing',
    'Interest Expenses',
    'Depreciation',
    'Motor Vehicle Expenses',
    'Other Expenses',
]

def _tax_category(name: str) -> str:
    """Map an expense account name to an ATO sole-trader tax return category."""
    n = name.lower()
    if any(k in n for k in ('depreciation', 'amortis', 'amortiz')):
        return 'Depreciation'
    if any(k in n for k in ('salary', 'salaries', 'wage', 'wages', 'payroll',
                              'superannuation', 'annual leave', 'sick leave',
                              'long service leave', 'workers comp', "worker's comp",
                              'worksafe', 'staff entitlement')):
        return 'Salaries & Wages'
    if any(k in n for k in ('contractor', 'subcontractor', 'sub-contractor',
                              'commission', 'labour hire', 'labor hire')):
        return 'Contractor & Commission Expenses'
    if any(k in n for k in ('rent', 'lease', 'leasing', 'premises')):
        return 'Rent & Leasing'
    if any(k in n for k in ('interest', 'finance charge')):
        return 'Interest Expenses'
    if any(k in n for k in ('motor vehicle', 'vehicle expense', 'car expense',
                              'car running', 'fuel', 'petrol', 'diesel',
                              'rego', 'vehicle rego', 'car rego', 'tolls', 'car park', 'parking')):
        return 'Motor Vehicle Expenses'
    return 'Other Expenses'


def tax_return_summary(db_path, date_from, date_to, basis="accrual"):
    """
    ATO-aligned income and expense summary for a sole-trader individual tax return.
    Expense accounts are auto-grouped into standard ATO schedule categories
    by keyword matching on account names.
    """
    pl  = profit_and_loss(db_path, date_from, date_to, basis=basis)
    gst = bas_report(db_path, date_from, date_to, basis=basis)

    buckets: dict = {cat: [] for cat in _ATO_EXPENSE_ORDER}
    for row in (pl.get('expense') or []):
        cat = _tax_category(row.get('name', ''))
        buckets[cat].append(row)

    expense_groups = []
    total_expenses = 0.0
    for cat in _ATO_EXPENSE_ORDER:
        accounts = buckets[cat]
        if not accounts:
            continue
        subtotal = sum(float(a.get('amount', 0) or 0) for a in accounts)
        total_expenses += subtotal
        expense_groups.append({
            'label':    cat,
            'accounts': accounts,
            'total':    round(subtotal, 2),
        })

    total_income = float(pl.get('total_income') or 0)
    total_cos    = sum(float(r.get('amount', 0) or 0) for r in (pl.get('cost_of_sales') or []))
    gross_profit = total_income - total_cos
    net_profit   = gross_profit - total_expenses

    return {
        'date_from':           date_from,
        'date_to':             date_to,
        'basis':               basis,
        'income':              pl.get('income', []),
        'cost_of_sales':       pl.get('cost_of_sales', []),
        'total_income':        round(total_income, 2),
        'total_cost_of_sales': round(total_cos, 2),
        'gross_profit':        round(gross_profit, 2),
        'expense_groups':      expense_groups,
        'total_expenses':      round(total_expenses, 2),
        'net_profit':          round(net_profit, 2),
        'gst': {
            'G1_total_sales':      gst.get('G1_total_sales', 0),
            '1A_GST_on_sales':     gst.get('1A_GST_on_sales', 0),
            '1B_GST_on_purchases': gst.get('1B_GST_on_purchases', 0),
            'GST_payable':         gst.get('GST_payable', 0),
            'basis':               basis,
        },
    }
