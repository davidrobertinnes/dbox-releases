"""
dbox - Point of Sale
Core POS logic: sale creation, payment terminal adapters (Tyro, Square, Mock).
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.

import time as _time
import uuid as _uuid
from datetime import date as _date

from core.database import get_connection
from core.items import get_items
from core.ledger import save_invoice, record_payment
from core.pos_settings import get_pos_settings


# ── Default accounts / contacts ───────────────────────────────────────────────

def _ensure_pos_defaults(db_path) -> dict:
    """
    Create Walk-In Customer contact, Cash Drawer account, and EFTPOS Clearing
    account if they don't exist. Returns their IDs.
    """
    conn = get_connection(db_path)

    # Walk-In Customer system contact
    row = conn.execute(
        "SELECT id FROM contacts WHERE is_system=1 AND name='Walk-In Customer'"
    ).fetchone()
    if not row:
        conn.execute("""INSERT INTO contacts
            (contact_type, name, is_system, is_active, notes)
            VALUES ('Customer','Walk-In Customer',1,1,
                    'System contact — POS walk-in sales')""")
        conn.commit()
        row = conn.execute(
            "SELECT id FROM contacts WHERE is_system=1 AND name='Walk-In Customer'"
        ).fetchone()
    walkin_id = row[0]

    # Cash Drawer bank account (1-1120)
    row = conn.execute("SELECT id FROM accounts WHERE code='1-1120'").fetchone()
    if not row:
        conn.execute("""INSERT OR IGNORE INTO accounts
            (code, name, account_type, account_subtype, is_bank, tax_code)
            VALUES ('1-1120','Cash Drawer','Asset','Bank',1,'N-T')""")
        conn.commit()
        row = conn.execute("SELECT id FROM accounts WHERE code='1-1120'").fetchone()
    cash_account_id = row[0]

    # EFTPOS Clearing bank account (1-1130)
    row = conn.execute("SELECT id FROM accounts WHERE code='1-1130'").fetchone()
    if not row:
        conn.execute("""INSERT OR IGNORE INTO accounts
            (code, name, account_type, account_subtype, is_bank, tax_code)
            VALUES ('1-1130','EFTPOS Clearing','Asset','Bank',1,'N-T')""")
        conn.commit()
        row = conn.execute("SELECT id FROM accounts WHERE code='1-1130'").fetchone()
    card_account_id = row[0]

    conn.close()
    return {
        "walkin_contact_id": walkin_id,
        "cash_account_id": cash_account_id,
        "card_account_id": card_account_id,
    }


# ── Item catalogue ────────────────────────────────────────────────────────────

def get_pos_items(db_path, search: str = None) -> list:
    """Return active items for POS, optionally filtered by search string."""
    items = get_items(db_path, active_only=True)
    if search:
        q = search.lower()
        items = [
            i for i in items
            if q in (i.get("name") or "").lower()
            or q in (i.get("code") or "").lower()
            or q in (i.get("barcode") or "").lower()
        ]
    return items


# ── Sale creation ─────────────────────────────────────────────────────────────

def create_pos_sale(
    db_path,
    lines: list,
    tender: str,
    tendered_amount: float = None,
    terminal_tx_id: str = None,
    terminal_provider: str = None,
    note: str = "",
) -> dict:
    """
    Create an invoice + immediate payment for a POS sale.

    lines: [{item_id, description, qty, unit_price, tax_code, account_id}]
    tender: 'cash' | 'card'
    tendered_amount: float — cash given by customer (cash only)
    terminal_tx_id: str — terminal transaction ID (card only)
    terminal_provider: str — 'tyro' | 'square' | 'mock' (card only)

    Returns {invoice_id, invoice_number, payment_id, total, change}
    """
    defaults = _ensure_pos_defaults(db_path)
    settings = get_pos_settings(db_path)

    walkin_id    = settings.get("walkin_contact_id") or defaults["walkin_contact_id"]
    cash_acct_id = settings.get("cash_account_id")  or defaults["cash_account_id"]
    card_acct_id = settings.get("card_account_id")  or defaults["card_account_id"]
    bank_acct_id = cash_acct_id if tender == "cash" else card_acct_id

    # Resolve fallback income account
    conn = get_connection(db_path)
    _def_inc = conn.execute("SELECT id FROM accounts WHERE code='4-1100'").fetchone()
    default_income_id = _def_inc[0] if _def_inc else None
    conn.close()

    today = _date.today().isoformat()

    inv_lines = [
        {
            "item_id":     l.get("item_id"),
            "description": l.get("description", ""),
            "quantity":    l.get("qty", 1),
            "unit_price":  l.get("unit_price", 0),
            "tax_code":    l.get("tax_code", "GST"),
            "account_id":  l.get("account_id") or default_income_id,
            "line_type":   "item",
        }
        for l in lines
    ]

    comments = f"tender={tender}"
    if terminal_tx_id:
        comments += f" provider={terminal_provider} tx={terminal_tx_id}"
    if note:
        comments += f" {note}"

    inv_data = {
        "contact_id":        walkin_id,
        "invoice_date":      today,
        "due_date":          today,
        "status":            "Sent",
        "notes":             "POS sale",
        "internal_comments": comments,
    }

    invoice_id = save_invoice(db_path, inv_data, inv_lines)

    conn = get_connection(db_path)
    inv = conn.execute(
        "SELECT total, invoice_number FROM invoices WHERE id=?", (invoice_id,)
    ).fetchone()
    conn.close()
    total          = inv["total"]
    invoice_number = inv["invoice_number"]

    pmt_data = {
        "payment_type":   "Receipt",
        "contact_id":     walkin_id,
        "payment_date":   today,
        "amount":         total,
        "bank_account_id": bank_acct_id,
        "reference":      f"POS-{invoice_number}",
        "description":    f"POS sale — {tender}",
    }
    payment_id = record_payment(db_path, pmt_data, [{"invoice_id": invoice_id, "amount": total}])

    change = 0.0
    if tender == "cash" and tendered_amount is not None:
        change = round(float(tendered_amount) - total, 2)

    return {
        "invoice_id":     invoice_id,
        "invoice_number": invoice_number,
        "payment_id":     payment_id,
        "total":          total,
        "change":         change,
    }


def get_pos_sales(db_path, limit: int = 50) -> list:
    """Return recent POS sales (invoices tagged with notes='POS sale')."""
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT i.id, i.invoice_number, i.invoice_date, i.total, i.status,
               COALESCE(i.internal_comments,'') AS internal_comments
        FROM invoices i
        WHERE i.notes = 'POS sale'
        ORDER BY i.id DESC
        LIMIT ?
    """, (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ── Terminal payment adapters ─────────────────────────────────────────────────

def charge_terminal(db_path, amount_cents: int, reference: str, idempotency_key: str) -> dict:
    """
    Initiate a card payment on the configured terminal.
    Returns {checkout_id, provider} immediately — poll get_terminal_status() for result.
    """
    settings = get_pos_settings(db_path)
    provider = settings.get("provider", "")
    if provider == "tyro":
        return _charge_tyro(settings, amount_cents, reference, idempotency_key)
    if provider == "square":
        return _charge_square(settings, amount_cents, reference, idempotency_key)
    if provider == "mock":
        return _charge_mock(settings, amount_cents, reference, idempotency_key)
    raise ValueError("No payment terminal configured. Set provider in POS Settings.")


def get_terminal_status(db_path, provider: str, checkout_id: str) -> dict:
    """
    Poll the terminal for payment status.
    Returns {status: 'pending'|'completed'|'declined'|'error', tx_id, method, message}
    """
    settings = get_pos_settings(db_path)
    if provider == "tyro":
        return _get_tyro_status(settings, checkout_id)
    if provider == "square":
        return _get_square_status(settings, checkout_id)
    if provider == "mock":
        return _get_mock_status(checkout_id)
    return {"status": "error", "message": f"Unknown provider: {provider}"}


# ── Mock adapter (development / demo — no hardware needed) ───────────────────

_mock_checkouts: dict = {}  # checkout_id -> {created_at, amount}


def _charge_mock(settings, amount_cents, reference, idempotency_key) -> dict:
    cid = f"mock-{_uuid.uuid4().hex[:8]}"
    _mock_checkouts[cid] = {"created_at": _time.time(), "amount": amount_cents}
    return {"checkout_id": cid, "provider": "mock"}


def _get_mock_status(checkout_id) -> dict:
    entry = _mock_checkouts.get(checkout_id)
    if not entry:
        return {"status": "error", "message": "Unknown checkout ID"}
    age = _time.time() - entry["created_at"]
    if age >= 3:
        return {"status": "completed", "tx_id": checkout_id, "method": "visa"}
    return {"status": "pending"}


# ── Tyro adapter (AU primary) ─────────────────────────────────────────────────

def _charge_tyro(settings, amount_cents, reference, idempotency_key) -> dict:
    import urllib.request, json as _json
    url = "https://api.tyro.com/connect/integrations/integrations/transactions"
    payload = {
        "merchantId":              settings.get("device_id", ""),
        "amount":                  str(amount_cents),
        "reference":               reference,
        "integratedReceiptPrinting": False,
        "requestType":             "PURCHASE",
    }
    headers = {
        "Content-Type": "application/json",
        "apiKey":        settings.get("api_key", ""),
    }
    req = urllib.request.Request(
        url, data=_json.dumps(payload).encode(), headers=headers, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = _json.loads(resp.read())
        return {"checkout_id": data.get("transactionId"), "provider": "tyro"}
    except Exception as e:
        raise RuntimeError(f"Tyro: {e}")


def _get_tyro_status(settings, checkout_id) -> dict:
    import urllib.request, json as _json
    url = f"https://api.tyro.com/connect/integrations/integrations/transactions/{checkout_id}"
    req = urllib.request.Request(url, headers={"apiKey": settings.get("api_key", "")})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = _json.loads(resp.read())
        status = data.get("status", "")
        if status == "APPROVED":
            return {
                "status": "completed",
                "tx_id":  checkout_id,
                "method": (data.get("cardType") or "card").lower(),
            }
        if status in ("DECLINED", "FAILED", "CANCELLED"):
            return {"status": "declined", "message": data.get("responseText", "Declined")}
        return {"status": "pending"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


# ── Square adapter (secondary) ────────────────────────────────────────────────

_SQUARE_VERSION = "2024-01-17"


def _charge_square(settings, amount_cents, reference, idempotency_key) -> dict:
    import urllib.request, json as _json
    url = "https://connect.squareup.com/v2/terminals/checkouts"
    payload = {
        "idempotency_key": idempotency_key,
        "checkout": {
            "amount_money":    {"amount": amount_cents, "currency": "AUD"},
            "reference_id":    reference,
            "device_options":  {"device_id": settings.get("device_id", "")},
            "payment_type":    "CARD_PRESENT",
        },
    }
    headers = {
        "Content-Type":  "application/json",
        "Authorization": f"Bearer {settings.get('api_key', '')}",
        "Square-Version": _SQUARE_VERSION,
    }
    req = urllib.request.Request(
        url, data=_json.dumps(payload).encode(), headers=headers, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = _json.loads(resp.read())
        checkout_id = (data.get("checkout") or {}).get("id")
        return {"checkout_id": checkout_id, "provider": "square"}
    except Exception as e:
        raise RuntimeError(f"Square: {e}")


def _get_square_status(settings, checkout_id) -> dict:
    import urllib.request, json as _json
    url = f"https://connect.squareup.com/v2/terminals/checkouts/{checkout_id}"
    headers = {
        "Authorization":  f"Bearer {settings.get('api_key', '')}",
        "Square-Version": _SQUARE_VERSION,
    }
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = _json.loads(resp.read())
        checkout = data.get("checkout") or {}
        status = checkout.get("status", "")
        if status == "COMPLETED":
            return {"status": "completed", "tx_id": checkout_id, "method": "card"}
        if status in ("CANCELED", "CANCEL_REQUESTED"):
            return {"status": "declined", "message": "Payment cancelled"}
        return {"status": "pending"}
    except Exception as e:
        return {"status": "error", "message": str(e)}
