# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
dbox - Point of Sale
Core POS logic: sale creation, payment terminal adapters (Tyro, Square, Mock).
"""

import time as _time
import uuid as _uuid
from datetime import date as _date

from core.database import get_connection
from core.items import get_items
from core.ledger import save_invoice, record_payment, post_journal, create_credit_note
from core.pos_settings import get_pos_settings


# ── Session management ────────────────────────────────────────────────────────

def _ensure_pos_session_tables(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS pos_sessions (
        id             INTEGER PRIMARY KEY,
        opened_at      TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        closed_at      TEXT,
        note           TEXT DEFAULT '',
        opening_float  REAL DEFAULT 0,
        cash_counted   REAL,
        banked         REAL DEFAULT 0,
        float_kept     REAL DEFAULT 0,
        variance       REAL
    )""")
    for col, defn in [
        ("opening_float",      "REAL DEFAULT 0"),
        ("cash_counted",       "REAL"),
        ("banked",             "REAL DEFAULT 0"),
        ("float_kept",         "REAL DEFAULT 0"),
        ("variance",           "REAL"),
        ("opened_by_user_id",  "INTEGER"),
        ("opened_by_name",     "TEXT"),
    ]:
        try:
            conn.execute(f"ALTER TABLE pos_sessions ADD COLUMN {col} {defn}")
        except Exception:
            pass
    conn.execute("""CREATE TABLE IF NOT EXISTS pos_sales (
        id         INTEGER PRIMARY KEY,
        session_id INTEGER REFERENCES pos_sessions(id),
        invoice_id INTEGER NOT NULL,
        tender     TEXT NOT NULL,
        total      REAL NOT NULL DEFAULT 0,
        gst        REAL NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    )""")
    for col, defn in [
        ("cash_amount", "REAL"),
        ("card_amount", "REAL"),
    ]:
        try:
            conn.execute(f"ALTER TABLE pos_sales ADD COLUMN {col} {defn}")
        except Exception:
            pass
    conn.commit()


def get_active_pos_session(db_path):
    """Return the currently open session or None."""
    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)
    row = conn.execute(
        "SELECT id, opened_at, opening_float, opened_by_name "
        "FROM pos_sessions WHERE closed_at IS NULL ORDER BY id DESC LIMIT 1"
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def get_last_pos_float(db_path) -> float:
    """Return the float_kept from the most recently closed session (0 if none)."""
    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)
    row = conn.execute(
        "SELECT COALESCE(float_kept, 0) AS f FROM pos_sessions WHERE closed_at IS NOT NULL ORDER BY id DESC LIMIT 1"
    ).fetchone()
    conn.close()
    return round(row["f"], 2) if row else 0.0


def open_pos_session(db_path, note="", opening_float=0.0,
                     opened_by_user_id=None, opened_by_name=None):
    """Open a new register session and return {id, opened_at, opening_float, opened_by_name}."""
    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)
    conn.execute(
        "INSERT INTO pos_sessions (note, opening_float, opened_by_user_id, opened_by_name) VALUES (?,?,?,?)",
        (note, round(float(opening_float), 2), opened_by_user_id, opened_by_name),
    )
    conn.commit()
    row = conn.execute(
        "SELECT id, opened_at, opening_float, opened_by_user_id, opened_by_name "
        "FROM pos_sessions ORDER BY id DESC LIMIT 1"
    ).fetchone()
    conn.close()
    return dict(row)


def _build_z_report(conn, session_id):
    sess = conn.execute(
        "SELECT id, opened_at, closed_at, opening_float, cash_counted, banked, float_kept, variance FROM pos_sessions WHERE id=?",
        (session_id,)
    ).fetchone()
    if not sess:
        raise ValueError("Session not found")
    rows = conn.execute("""
        SELECT ps.tender,
               COUNT(*) AS count,
               SUM(ps.total) AS total,
               SUM(COALESCE(il.gst_total, 0)) AS gst,
               COALESCE(SUM(ps.cash_amount), 0) AS split_cash,
               COALESCE(SUM(ps.card_amount), 0) AS split_card
        FROM pos_sales ps
        LEFT JOIN (
            SELECT invoice_id, SUM(gst_amount) AS gst_total
            FROM invoice_lines
            GROUP BY invoice_id
        ) il ON il.invoice_id = ps.invoice_id
        WHERE ps.session_id=?
        GROUP BY ps.tender
    """, (session_id,)).fetchall()
    by = {r["tender"]: r for r in rows}
    cash_row  = by.get("cash",  {"count": 0, "total": 0, "gst": 0, "split_cash": 0, "split_card": 0})
    card_row  = by.get("card",  {"count": 0, "total": 0, "gst": 0, "split_cash": 0, "split_card": 0})
    split_row = by.get("split", {"count": 0, "total": 0, "gst": 0, "split_cash": 0, "split_card": 0})

    split_cash_amt = round(float(split_row["split_cash"] or 0), 2)
    split_card_amt = round(float(split_row["split_card"] or 0), 2)
    split_gst_amt  = round(float(split_row["gst"] or 0), 2)
    split_count    = int(split_row["count"] or 0)
    split_total    = round(float(split_row["total"] or 0), 2)

    total = round(
        float(cash_row["total"] or 0) + float(card_row["total"] or 0) + split_total, 2
    )
    gst = round(
        float(cash_row["gst"] or 0) + float(card_row["gst"] or 0) + split_gst_amt, 2
    )
    # Cash in drawer includes cash portions of split transactions
    cash_drawer_total = round(float(cash_row["total"] or 0) + split_cash_amt, 2)

    return {
        "session_id": sess["id"],
        "opened_at":  sess["opened_at"],
        "closed_at":  sess["closed_at"],
        "cash": {
            "count": int(cash_row["count"] or 0),
            "total": round(float(cash_row["total"] or 0), 2),
            "gst":   round(float(cash_row["gst"] or 0), 2),
        },
        "card": {
            "count": int(card_row["count"] or 0),
            "total": round(float(card_row["total"] or 0), 2),
            "gst":   round(float(card_row["gst"] or 0), 2),
        },
        "split": {
            "count": split_count,
            "total": split_total,
            "cash":  split_cash_amt,
            "card":  split_card_amt,
            "gst":   split_gst_amt,
        },
        "cash_drawer_total": cash_drawer_total,
        "total":         total,
        "gst":           gst,
        "ex_gst":        round(total - gst, 2),
        "tx_count":      int(cash_row["count"] or 0) + int(card_row["count"] or 0) + split_count,
        "opening_float": round(float(sess["opening_float"] or 0), 2),
        "cash_counted":  round(float(sess["cash_counted"]), 2) if sess["cash_counted"] is not None else None,
        "banked":        round(float(sess["banked"] or 0), 2),
        "float_kept":    round(float(sess["float_kept"] or 0), 2),
        "variance":      round(float(sess["variance"]), 2) if sess["variance"] is not None else None,
    }


def get_pos_session_report(db_path, session_id):
    """Return current Z-report data without closing the session."""
    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)
    report = _build_z_report(conn, session_id)
    conn.close()
    return report


def close_pos_session(db_path, session_id,
                      cash_counted=None, banked=0.0, float_kept=0.0,
                      banking_account_id=None):
    """Close the session, record till balance, post banking journal if needed."""
    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)

    # calculate variance if cash was counted
    variance = None
    if cash_counted is not None:
        opening_float = (conn.execute(
            "SELECT opening_float FROM pos_sessions WHERE id=?", (session_id,)
        ).fetchone() or {"opening_float": 0})["opening_float"] or 0
        cash_sales = (conn.execute(
            "SELECT COALESCE(SUM(CASE WHEN tender='cash' THEN total ELSE 0 END),0)"
            " + COALESCE(SUM(CASE WHEN tender='split' THEN COALESCE(cash_amount,0) ELSE 0 END),0)"
            " FROM pos_sales WHERE session_id=?",
            (session_id,)
        ).fetchone() or (0,))[0] or 0
        expected = round(opening_float + cash_sales, 2)
        variance = round(float(cash_counted) - expected, 2)

    conn.execute("""UPDATE pos_sessions
        SET closed_at=datetime('now','localtime'),
            cash_counted=?, banked=?, float_kept=?, variance=?
        WHERE id=? AND closed_at IS NULL""",
        (cash_counted, round(float(banked), 2),
         round(float(float_kept), 2), variance, session_id))
    conn.commit()
    conn.close()

    # banking journal entry
    if banked and float(banked) > 0 and banking_account_id:
        settings = get_pos_settings(db_path)
        cash_acct = settings.get("cash_account_id")
        if cash_acct:
            from datetime import date as _d
            post_journal(db_path, _d.today().isoformat(),
                         f"Till banking — Session #{session_id}",
                         f"TILLBANK-{session_id}",
                         [
                             {"account_id": int(banking_account_id),
                              "debit": round(float(banked), 2), "credit": 0},
                             {"account_id": int(cash_acct),
                              "debit": 0, "credit": round(float(banked), 2)},
                         ])

    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)
    report = _build_z_report(conn, session_id)
    conn.close()
    return report


# ── Default accounts / contacts ───────────────────────────────────────────────

def _ensure_pos_defaults(db_path) -> dict:
    """
    Create Walk-In Customer contact, Cash Drawer account, and EFTPOS Clearing
    account if they don't exist. Returns their IDs.
    """
    conn = get_connection(db_path)

    # Walk-In Customer system contact
    row = conn.execute(
        "SELECT id FROM contacts WHERE is_system=1 AND name='Walk-In Customer'"
    ).fetchone()
    if not row:
        conn.execute("""INSERT INTO contacts
            (contact_type, name, is_system, is_active, notes)
            VALUES ('Customer','Walk-In Customer',1,1,
                    'System contact — POS walk-in sales')""")
        conn.commit()
        row = conn.execute(
            "SELECT id FROM contacts WHERE is_system=1 AND name='Walk-In Customer'"
        ).fetchone()
    walkin_id = row[0]

    # Cash Drawer bank account (1-1120)
    row = conn.execute("SELECT id FROM accounts WHERE code='1-1120'").fetchone()
    if not row:
        conn.execute("""INSERT OR IGNORE INTO accounts
            (code, name, account_type, account_subtype, is_bank, tax_code)
            VALUES ('1-1120','Cash Drawer','Asset','Bank',1,'N-T')""")
        conn.commit()
        row = conn.execute("SELECT id FROM accounts WHERE code='1-1120'").fetchone()
    cash_account_id = row[0]

    # EFTPOS Clearing bank account (1-1130)
    row = conn.execute("SELECT id FROM accounts WHERE code='1-1130'").fetchone()
    if not row:
        conn.execute("""INSERT OR IGNORE INTO accounts
            (code, name, account_type, account_subtype, is_bank, tax_code)
            VALUES ('1-1130','EFTPOS Clearing','Asset','Bank',1,'N-T')""")
        conn.commit()
        row = conn.execute("SELECT id FROM accounts WHERE code='1-1130'").fetchone()
    card_account_id = row[0]

    conn.close()
    return {
        "walkin_contact_id": walkin_id,
        "cash_account_id": cash_account_id,
        "card_account_id": card_account_id,
    }


# ── Item catalogue ────────────────────────────────────────────────────────────

def get_pos_items(db_path, search: str = None) -> list:
    """Return active items for POS with active promo prices applied."""
    items = get_items(db_path, active_only=True)
    if items:
        today = _date.today().isoformat()
        conn = get_connection(db_path)
        try:
            rows = conn.execute("""
                SELECT item_id, promo_name, promo_price
                FROM promotions
                WHERE is_active=1 AND start_date<=? AND end_date>=?
                ORDER BY promo_price ASC
            """, (today, today)).fetchall()
            promos = {}
            for r in rows:
                if r["item_id"] not in promos:
                    promos[r["item_id"]] = r
        except Exception:
            promos = {}
        finally:
            conn.close()
        for item in items:
            p = promos.get(item.get("id"))
            if p:
                item["standard_price"] = item["unit_price"]
                item["unit_price"]     = round(p["promo_price"], 2)
                item["promo_name"]     = p["promo_name"]
    if search:
        q = search.lower()
        items = [
            i for i in items
            if q in (i.get("name") or "").lower()
            or q in (i.get("code") or "").lower()
            or q in (i.get("barcode") or "").lower()
        ]
    return items


# ── Sale creation ─────────────────────────────────────────────────────────────

def create_pos_sale(
    db_path,
    lines: list,
    tender: str,
    tendered_amount: float = None,
    terminal_tx_id: str = None,
    terminal_provider: str = None,
    note: str = "",
    session_id: int = None,
    contact_id: int = None,
    gst: float = 0.0,
    split_tenders: dict = None,
) -> dict:
    """
    Create an invoice + immediate payment for a POS sale.

    lines: [{item_id, description, qty, unit_price, tax_code, account_id}]
    tender: 'cash' | 'card'
    tendered_amount: float — cash given by customer (cash only)
    terminal_tx_id: str — terminal transaction ID (card only)
    terminal_provider: str — 'tyro' | 'square' | 'mock' (card only)

    Returns {invoice_id, invoice_number, payment_id, total, change}
    """
    defaults = _ensure_pos_defaults(db_path)
    settings = get_pos_settings(db_path)

    walkin_id    = contact_id or settings.get("walkin_contact_id") or defaults["walkin_contact_id"]
    cash_acct_id = settings.get("cash_account_id")  or defaults["cash_account_id"]
    card_acct_id = settings.get("card_account_id")  or defaults["card_account_id"]
    bank_acct_id = cash_acct_id if tender == "cash" else card_acct_id

    # Resolve fallback income account
    conn = get_connection(db_path)
    _def_inc = conn.execute("SELECT id FROM accounts WHERE code='4-1100'").fetchone()
    default_income_id = _def_inc[0] if _def_inc else None
    conn.close()

    today = _date.today().isoformat()

    inv_lines = [
        {
            "item_id":     l.get("item_id"),
            "description": l.get("description", ""),
            "quantity":    l.get("qty", 1),
            "unit_price":  l.get("unit_price", 0),
            "tax_code":    l.get("tax_code", "GST"),
            "account_id":  l.get("account_id") or default_income_id,
            "line_type":   "item",
        }
        for l in lines
    ]

    comments = f"tender={tender}"
    if terminal_tx_id:
        comments += f" provider={terminal_provider} tx={terminal_tx_id}"
    if note:
        comments += f" {note}"

    inv_data = {
        "contact_id":        walkin_id,
        "invoice_date":      today,
        "due_date":          today,
        "status":            "Sent",
        "notes":             "POS sale",
        "internal_comments": comments,
    }

    invoice_id = save_invoice(db_path, inv_data, inv_lines)

    conn = get_connection(db_path)
    inv = conn.execute(
        "SELECT total, invoice_number FROM invoices WHERE id=?", (invoice_id,)
    ).fetchone()
    conn.close()
    total          = inv["total"]
    invoice_number = inv["invoice_number"]

    change = 0.0

    if split_tenders:
        cash_amt   = round(float(split_tenders.get("cash", 0)), 2)
        card_amt   = round(float(split_tenders.get("card", 0)), 2)
        sp_tx_id   = split_tenders.get("terminal_tx_id")
        sp_prov    = split_tenders.get("terminal_provider")
        # Cash leg
        record_payment(db_path, {
            "payment_type":    "Receipt",
            "contact_id":      walkin_id,
            "payment_date":    today,
            "amount":          cash_amt,
            "bank_account_id": cash_acct_id,
            "reference":       f"POS-{invoice_number}",
            "description":     "POS sale — cash (split)",
        }, [{"invoice_id": invoice_id, "amount": cash_amt}])
        # Card leg
        card_desc = "POS sale — card (split)"
        if sp_tx_id:
            card_desc += f" provider={sp_prov} tx={sp_tx_id}"
        payment_id = record_payment(db_path, {
            "payment_type":    "Receipt",
            "contact_id":      walkin_id,
            "payment_date":    today,
            "amount":          card_amt,
            "bank_account_id": card_acct_id,
            "reference":       f"POS-{invoice_number}",
            "description":     card_desc,
        }, [{"invoice_id": invoice_id, "amount": card_amt}])
        if session_id is not None:
            conn2 = get_connection(db_path)
            _ensure_pos_session_tables(conn2)
            conn2.execute(
                "INSERT INTO pos_sales (session_id, invoice_id, tender, total, gst, cash_amount, card_amount)"
                " VALUES (?,?,?,?,?,?,?)",
                (session_id, invoice_id, "split", total, round(float(gst), 2), cash_amt, card_amt)
            )
            conn2.commit()
            conn2.close()
    else:
        pmt_data = {
            "payment_type":    "Receipt",
            "contact_id":      walkin_id,
            "payment_date":    today,
            "amount":          total,
            "bank_account_id": bank_acct_id,
            "reference":       f"POS-{invoice_number}",
            "description":     f"POS sale — {tender}",
        }
        payment_id = record_payment(db_path, pmt_data, [{"invoice_id": invoice_id, "amount": total}])

        if tender == "cash" and tendered_amount is not None:
            change = round(float(tendered_amount) - total, 2)

        if session_id is not None:
            conn2 = get_connection(db_path)
            _ensure_pos_session_tables(conn2)
            conn2.execute(
                "INSERT INTO pos_sales (session_id, invoice_id, tender, total, gst) VALUES (?,?,?,?,?)",
                (session_id, invoice_id, tender, total, round(float(gst), 2))
            )
            conn2.commit()
            conn2.close()

    return {
        "invoice_id":     invoice_id,
        "invoice_number": invoice_number,
        "payment_id":     payment_id,
        "total":          total,
        "change":         change,
    }


def get_pos_sales(db_path, limit: int = 50) -> list:
    """Return recent POS sales with tender type and contact name."""
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT i.id, i.invoice_number, i.invoice_date, i.total, i.status,
               COALESCE(ps.tender,
                   CASE WHEN i.internal_comments LIKE 'tender=cash%' THEN 'cash' ELSE 'card' END
               ) AS tender,
               COALESCE(c.name, 'Walk-In Customer') AS contact_name,
               CASE WHEN cn.id IS NOT NULL THEN 1 ELSE 0 END AS refunded
        FROM invoices i
        LEFT JOIN pos_sales ps ON ps.invoice_id = i.id
        LEFT JOIN contacts c ON c.id = i.contact_id
        LEFT JOIN invoices cn ON cn.source_invoice_id = i.id
                              AND cn.is_credit_note = 1
                              AND cn.status != 'Void'
        WHERE i.notes = 'POS sale'
        ORDER BY i.id DESC
        LIMIT ?
    """, (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def create_pos_refund(db_path, invoice_id: int, lines: list, tender: str) -> dict:
    """
    Process a POS refund against a completed sale.

    GL flow:
      create_credit_note() → DR Income, DR GST Collected, CR AR  (reverses revenue/GST)
      post_journal()       → DR AR, CR Cash/Card               (cash leaves the drawer)

    Returns {cn_id, cn_number, total, tender}.
    """
    defaults = _ensure_pos_defaults(db_path)
    settings = get_pos_settings(db_path)

    cash_acct = settings.get("cash_account_id") or defaults["cash_account_id"]
    card_acct = settings.get("card_account_id") or defaults["card_account_id"]
    bank_acct = int(cash_acct if tender == "cash" else card_acct)

    today = _date.today().isoformat()

    cn_id = create_credit_note(
        db_path, invoice_id, lines, today,
        memo=f"POS refund — {tender}",
    )

    conn = get_connection(db_path)
    cn  = conn.execute("SELECT invoice_number, total FROM invoices WHERE id=?", (cn_id,)).fetchone()
    ar  = conn.execute("SELECT id FROM accounts WHERE code='1-1200'").fetchone()
    conn.close()

    cn_number = cn["invoice_number"]
    cn_total  = round(float(cn["total"]), 2)
    ar_id     = int(ar["id"]) if ar else None

    if ar_id and bank_acct:
        post_journal(
            db_path, today,
            f"POS refund {cn_number}",
            f"POSREF-{cn_id}",
            [
                {"account_id": ar_id,    "debit": cn_total, "credit": 0},
                {"account_id": bank_acct, "debit": 0,        "credit": cn_total},
            ],
        )

    # Mark CN as settled so it doesn't show as an open credit
    conn2 = get_connection(db_path)
    conn2.execute(
        "UPDATE invoices SET amount_paid=?, amount_applied=? WHERE id=?",
        (cn_total, cn_total, cn_id),
    )
    conn2.commit()
    conn2.close()

    return {"cn_id": cn_id, "cn_number": cn_number, "total": cn_total, "tender": tender}


def get_pos_sessions(db_path, limit: int = 30) -> list:
    """Return recent sessions with aggregated sales totals."""
    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)
    rows = conn.execute("""
        SELECT s.id, s.opened_at, s.closed_at, s.note,
               s.opening_float, s.banked, s.float_kept,
               s.opened_by_name,
               COUNT(ps.id) AS tx_count,
               COALESCE(SUM(ps.total), 0) AS total
        FROM pos_sessions s
        LEFT JOIN pos_sales ps ON ps.session_id = s.id
        GROUP BY s.id
        ORDER BY s.id DESC
        LIMIT ?
    """, (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def open_cash_drawer(db_path) -> tuple:
    """Send ESC/POS cash drawer kick command. Returns (True, 'Opened') or (False, error_msg)."""
    import socket
    settings = get_pos_settings(db_path)
    if not settings.get("printer_enabled"):
        return False, "Printer not enabled in POS settings"
    host = (settings.get("printer_host") or "").strip()
    port = int(settings.get("printer_port") or 9100)
    if not host:
        return False, "Printer host/IP not configured"
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5)
            s.connect((host, port))
            s.sendall(b'\x1b\x70\x00\x19\xfa')  # ESC p 0 — pin 2 kick
        return True, "Opened"
    except socket.timeout:
        return False, f"Printer timeout — could not connect to {host}:{port}"
    except OSError as e:
        return False, f"Drawer error: {e}"


# ── Terminal payment adapters ─────────────────────────────────────────────────

def charge_terminal(db_path, amount_cents: int, reference: str, idempotency_key: str) -> dict:
    """
    Initiate a card payment on the configured terminal.
    Returns {checkout_id, provider} immediately — poll get_terminal_status() for result.
    Linkly uses synchronous mode: this call blocks until the card is tapped (~5–30 s).
    """
    settings = get_pos_settings(db_path)
    provider = settings.get("provider", "")
    if provider == "tyro":
        return _charge_tyro(settings, amount_cents, reference, idempotency_key)
    if provider == "square":
        return _charge_square(settings, amount_cents, reference, idempotency_key)
    if provider == "linkly":
        return _charge_linkly(settings, amount_cents, reference, idempotency_key)
    if provider == "mock":
        return _charge_mock(settings, amount_cents, reference, idempotency_key)
    raise ValueError("No payment terminal configured. Set provider in POS Settings.")


def get_terminal_status(db_path, provider: str, checkout_id: str) -> dict:
    """
    Poll the terminal for payment status.
    Returns {status: 'pending'|'completed'|'declined'|'error', tx_id, method, message}
    """
    settings = get_pos_settings(db_path)
    if provider == "tyro":
        return _get_tyro_status(settings, checkout_id)
    if provider == "square":
        return _get_square_status(settings, checkout_id)
    if provider == "linkly":
        return _get_linkly_status(settings, checkout_id)
    if provider == "mock":
        return _get_mock_status(checkout_id)
    return {"status": "error", "message": f"Unknown provider: {provider}"}


# ── Mock adapter (development / demo — no hardware needed) ───────────────────

_mock_checkouts: dict = {}  # checkout_id -> {created_at, amount}


def _charge_mock(settings, amount_cents, reference, idempotency_key) -> dict:
    cid = f"mock-{_uuid.uuid4().hex[:8]}"
    _mock_checkouts[cid] = {"created_at": _time.time(), "amount": amount_cents}
    return {"checkout_id": cid, "provider": "mock"}


def _get_mock_status(checkout_id) -> dict:
    entry = _mock_checkouts.get(checkout_id)
    if not entry:
        return {"status": "error", "message": "Unknown checkout ID"}
    age = _time.time() - entry["created_at"]
    if age >= 3:
        return {"status": "completed", "tx_id": checkout_id, "method": "visa"}
    return {"status": "pending"}


# ── Tyro adapter (AU primary) ─────────────────────────────────────────────────

def _charge_tyro(settings, amount_cents, reference, idempotency_key) -> dict:
    import urllib.request, json as _json
    url = "https://api.tyro.com/connect/integrations/integrations/transactions"
    payload = {
        "merchantId":              settings.get("device_id", ""),
        "amount":                  str(amount_cents),
        "reference":               reference,
        "integratedReceiptPrinting": False,
        "requestType":             "PURCHASE",
    }
    headers = {
        "Content-Type": "application/json",
        "apiKey":        settings.get("api_key", ""),
    }
    req = urllib.request.Request(
        url, data=_json.dumps(payload).encode(), headers=headers, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = _json.loads(resp.read())
        return {"checkout_id": data.get("transactionId"), "provider": "tyro"}
    except Exception as e:
        raise RuntimeError(f"Tyro: {e}")


def _get_tyro_status(settings, checkout_id) -> dict:
    import urllib.request, json as _json
    url = f"https://api.tyro.com/connect/integrations/integrations/transactions/{checkout_id}"
    req = urllib.request.Request(url, headers={"apiKey": settings.get("api_key", "")})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = _json.loads(resp.read())
        status = data.get("status", "")
        if status == "APPROVED":
            return {
                "status": "completed",
                "tx_id":  checkout_id,
                "method": (data.get("cardType") or "card").lower(),
            }
        if status in ("DECLINED", "FAILED", "CANCELLED"):
            return {"status": "declined", "message": data.get("responseText", "Declined")}
        return {"status": "pending"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


# ── Linkly adapter (AU bank terminals — CBA, NAB, Westpac, ANZ, etc.) ────────

_LINKLY_AUTH = "https://auth.sandbox.cloud.pceftpos.com/v1/tokens/cloudpos"
_LINKLY_TXN  = "https://rest.pos.sandbox.cloud.pceftpos.com/v1/sessions"
_LINKLY_PAIR = "https://auth.sandbox.cloud.pceftpos.com/v1/pairing/cloudpos"

_linkly_token_cache: dict = {}   # pos_id -> {token, expires_at}
_linkly_checkouts:   dict = {}   # session_uuid -> result dict


def _linkly_get_token(settings) -> str:
    import urllib.request, urllib.error, json as _json
    pos_id = settings.get("device_id") or ""
    if not pos_id:
        raise RuntimeError("Linkly: Register ID not set — re-pair the terminal")
    cache = _linkly_token_cache.get(pos_id)
    if cache and cache["expires_at"] > _time.time() + 60:
        return cache["token"]
    secret = settings.get("api_key", "")
    if not secret:
        raise RuntimeError("Linkly: terminal not paired (no secret stored)")
    payload = {
        "secret":      secret,
        "posName":     "Dogbox Accounting",
        "posVersion":  "1.0",
        "posId":       pos_id,
        "posVendorId": "dogbox-accounting",
    }
    req = urllib.request.Request(
        _LINKLY_AUTH,
        data=_json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = _json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Linkly auth failed: HTTP {e.code} — {body}")
    token = data.get("token") or data.get("Token")
    if not token:
        raise RuntimeError(f"Linkly auth: no token in response — {data}")
    _linkly_token_cache[pos_id] = {"token": token, "expires_at": _time.time() + 82800}
    return token


def _charge_linkly(settings, amount_cents, reference, idempotency_key) -> dict:
    import urllib.request, urllib.error, json as _json
    token      = _linkly_get_token(settings)
    session_id = str(_uuid.uuid4())
    url        = f"{_LINKLY_TXN}/{session_id}/transaction?async=false"
    payload    = {
        "Request": {
            "Merchant":     "00",
            "TxnType":      "P",
            "AmtPurchase":  amount_cents,
            "TxnRef":       reference[:16],
            "CurrencyCode": "AUD",
        }
    }
    req = urllib.request.Request(
        url,
        data=_json.dumps(payload).encode(),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = _json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Linkly: HTTP {e.code} — {body}")
    resp_obj = data.get("Response", {})
    if resp_obj.get("Success") and resp_obj.get("ResponseCode") == "00":
        _linkly_checkouts[session_id] = {
            "status": "completed",
            "tx_id":  session_id,
            "method": (resp_obj.get("CardType") or "card").lower(),
        }
    else:
        code = resp_obj.get("ResponseCode", "")
        text = resp_obj.get("ResponseText", "Declined")
        _linkly_checkouts[session_id] = {
            "status":  "declined",
            "message": f"{text} ({code})" if code else text,
        }
    return {"checkout_id": session_id, "provider": "linkly"}


def _get_linkly_status(settings, checkout_id) -> dict:
    entry = _linkly_checkouts.get(checkout_id)
    if entry:
        return entry
    # Recovery path: app restarted mid-transaction — query Linkly directly
    import urllib.request, urllib.error, json as _json
    try:
        token = _linkly_get_token(settings)
        url   = f"{_LINKLY_TXN}/{checkout_id}/transaction"
        req   = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            if resp.status == 202:
                return {"status": "pending"}
            data = _json.loads(resp.read())
        resp_obj = data.get("Response", {})
        if resp_obj.get("Success"):
            return {"status": "completed", "tx_id": checkout_id,
                    "method": (resp_obj.get("CardType") or "card").lower()}
        return {"status": "declined", "message": resp_obj.get("ResponseText", "Declined")}
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return {"status": "error", "message": "Transaction not found on Linkly"}
        return {"status": "error", "message": f"Linkly: HTTP {e.code}"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


def pair_linkly_terminal(db_path, username: str, password: str, pair_code: str) -> dict:
    """Pair with a Linkly terminal. Stores the returned secret as api_key in pos_settings."""
    import urllib.request, urllib.error, json as _json
    from core.pos_settings import get_pos_settings, save_pos_settings
    payload = {"username": username, "password": password, "pairCode": pair_code}
    req = urllib.request.Request(
        _LINKLY_PAIR,
        data=_json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = _json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Pairing failed: HTTP {e.code} — {body}")
    secret = data.get("secret") or data.get("Secret")
    if not secret:
        raise RuntimeError(f"Pairing failed: no secret in response — {data}")
    settings = get_pos_settings(db_path)
    pos_id   = settings.get("device_id") or str(_uuid.uuid4())
    settings["api_key"]  = secret
    settings["device_id"] = pos_id
    settings["provider"] = "linkly"
    save_pos_settings(db_path, settings)
    _linkly_token_cache.pop(pos_id, None)
    return {"paired": True, "pos_id": pos_id}


# ── Square adapter (secondary) ────────────────────────────────────────────────

_SQUARE_VERSION = "2024-01-17"


def _square_base(settings) -> str:
    if settings.get("square_sandbox"):
        return "https://connect.squareupsandbox.com/v2"
    return "https://connect.squareup.com/v2"


def _charge_square(settings, amount_cents, reference, idempotency_key) -> dict:
    import urllib.request, urllib.error, json as _json
    url = f"{_square_base(settings)}/terminals/checkouts"
    checkout = {
        "amount_money":   {"amount": amount_cents, "currency": "AUD"},
        "reference_id":   reference,
        "device_options": {"device_id": settings.get("device_id", "")},
        "payment_type":   "CARD_PRESENT",
    }
    if settings.get("location_id"):
        checkout["location_id"] = settings["location_id"]
    payload = {"idempotency_key": idempotency_key, "checkout": checkout}
    headers = {
        "Content-Type":   "application/json",
        "Authorization":  f"Bearer {settings.get('api_key', '')}",
        "Square-Version": _SQUARE_VERSION,
    }
    req = urllib.request.Request(
        url, data=_json.dumps(payload).encode(), headers=headers, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = _json.loads(resp.read())
        checkout_id = (data.get("checkout") or {}).get("id")
        return {"checkout_id": checkout_id, "provider": "square"}
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Square {e.code}: {body}")
    except Exception as e:
        raise RuntimeError(f"Square: {e}")


# ── Thermal receipt printing ──────────────────────────────────────────────────

_ESC = b'\x1b'
_GS  = b'\x1d'
_LF  = b'\x0a'


def _ep(cmd: bytes) -> bytes:
    return _ESC + cmd


def get_receipt_data(db_path, invoice_id, tender: str, tendered: float, change: float,
                     split_tenders: dict = None) -> dict:
    from core.ledger import get_invoice
    from core.database import get_connection as _gc
    inv_data = get_invoice(db_path, invoice_id)
    if not inv_data:
        raise ValueError(f"Invoice {invoice_id} not found")
    inv   = inv_data["invoice"]
    lines = inv_data["lines"]
    conn  = _gc(db_path)
    co    = conn.execute("SELECT * FROM company LIMIT 1").fetchone()
    conn.close()
    co = dict(co) if co else {}
    item_lines = [l for l in lines if (l.get("line_type") or "item") != "comment"]
    subtotal   = sum(float(l.get("quantity", 0)) * float(l.get("unit_price", 0)) for l in item_lines)
    gst_total  = sum(float(l.get("gst_amount") or 0) for l in item_lines)
    return {
        "company_name":   co.get("name", ""),
        "abn":            co.get("abn", ""),
        "address":        co.get("address", ""),
        "phone":          co.get("phone", ""),
        "invoice_number": inv.get("invoice_number", ""),
        "invoice_date":   inv.get("invoice_date", ""),
        "lines": [
            {
                "description": l.get("description", ""),
                "qty":         float(l.get("quantity", 0)),
                "unit_price":  float(l.get("unit_price", 0)),
                "gst_amount":  float(l.get("gst_amount") or 0),
                "line_total":  float(l.get("line_total", 0)),
                "line_type":   l.get("line_type") or "item",
            }
            for l in lines
        ],
        "subtotal":  round(subtotal, 2),
        "gst_total": round(gst_total, 2),
        "total":     float(inv.get("total", 0)),
        "tender":        tender,
        "tendered":      float(tendered or 0),
        "change":        float(change or 0),
        "split_tenders": split_tenders,
    }


def _format_receipt_escpos(r: dict, width: int = 48, is_refund: bool = False,
                           is_credit_note: bool = False) -> bytes:
    """Build an ESC/POS byte sequence for a 80mm (48-char) thermal receipt."""
    from datetime import datetime

    def pad(left: str, right: str) -> str:
        gap = width - len(left) - len(right)
        return left + " " * max(1, gap) + right

    out = bytearray()

    def txt(s: str = ""):
        out.extend(s.encode("ascii", errors="replace") + _LF)

    def div():
        txt("-" * width)

    def bold(on: bool):
        out.extend(_ep(b'E' + bytes([1 if on else 0])))

    def align(n: int):   # 0=left, 1=centre, 2=right
        out.extend(_ep(b'a' + bytes([n])))

    def dbl_height(on: bool):
        out.extend(_ep(b'!' + bytes([0x10 if on else 0x00])))

    def feed(n: int):
        out.extend(_ep(b'd' + bytes([n])))

    # init
    out.extend(_ep(b'@'))
    feed(1)

    # company header — centred
    align(1)
    bold(True)
    dbl_height(True)
    name = r.get("company_name", "")[:24]
    txt(name)
    dbl_height(False)
    bold(False)
    if r.get("abn"):
        txt(f"ABN {r['abn']}")
    if r.get("address"):
        txt(r["address"][:width])
    if r.get("phone"):
        txt(r["phone"][:width])
    align(0)

    div()
    align(1)
    bold(True)
    if is_refund:
        txt("REFUND RECEIPT")
    elif is_credit_note:
        txt("CREDIT NOTE")
    else:
        txt("TAX INVOICE")
    bold(False)
    align(0)
    div()

    now = datetime.now()
    txt(f"Date: {now.strftime('%d/%m/%Y')}  Time: {now.strftime('%H:%M')}")
    txt(f"Receipt: {r.get('invoice_number', '')}")
    div()

    # line items
    txt(pad("DESCRIPTION", "TOTAL"))
    div()
    for line in r.get("lines", []):
        if line["line_type"] == "comment":
            txt(line["description"][:width])
            continue
        desc      = line["description"]
        qty       = line["qty"]
        uprice    = line["unit_price"]
        ltotal    = line["line_total"]
        total_str = f"${ltotal:.2f}"
        qty_str   = f"  {qty:g} x ${uprice:.2f}"
        if len(desc) + len(total_str) + 1 <= width:
            txt(pad(desc, total_str))
        else:
            txt(desc[:width])
            txt(pad(qty_str, total_str))

    div()
    txt(pad("Subtotal:", f"${r['subtotal']:.2f}"))
    txt(pad("GST (10%):", f"${r['gst_total']:.2f}"))
    bold(True)
    txt(pad("TOTAL:", f"${r['total']:.2f}"))
    bold(False)
    div()

    tender_label = r.get("tender", "cash").upper()
    split = r.get("split_tenders")
    if is_credit_note:
        txt(pad("STORE CREDIT:", f"${r['tendered']:.2f}"))
    elif is_refund:
        txt(pad(f"REFUNDED VIA {tender_label}:", f"${r['tendered']:.2f}"))
    elif split:
        txt(pad("CASH:", f"${float(split.get('cash', 0)):.2f}"))
        txt(pad("CARD:", f"${float(split.get('card', 0)):.2f}"))
    else:
        txt(pad(f"{tender_label}:", f"${r['tendered']:.2f}"))
        if r.get("change", 0) > 0.005:
            txt(pad("CHANGE:", f"${r['change']:.2f}"))
    div()

    align(1)
    txt("Thank you for your business!")
    txt()
    align(0)

    feed(4)
    # full cut
    out.extend(_GS + b'V\x41\x00')
    return bytes(out)


def print_receipt(db_path, invoice_id, tender: str, tendered: float, change: float,
                  split_tenders: dict = None):
    """Send a formatted ESC/POS receipt to the configured network printer.

    Returns (True, 'Printed') or (False, error_message).
    """
    import socket
    from core.pos_settings import get_pos_settings
    settings = get_pos_settings(db_path)
    if not settings.get("printer_enabled"):
        return False, "Printer not enabled in POS settings"
    if settings.get("printer_type", "network") != "network":
        return False, "Only network printers are currently supported"
    host = (settings.get("printer_host") or "").strip()
    port = int(settings.get("printer_port") or 9100)
    if not host:
        return False, "Printer host/IP not configured"
    receipt = get_receipt_data(db_path, invoice_id, tender, tendered, change, split_tenders)
    data    = _format_receipt_escpos(receipt)
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5)
            s.connect((host, port))
            s.sendall(data)
        return True, "Printed"
    except socket.timeout:
        return False, f"Printer timeout — could not connect to {host}:{port}"
    except OSError as e:
        return False, f"Printer error: {e}"


def print_refund_receipt(db_path, cn_id: int, tender: str, amount: float):
    """Print a REFUND RECEIPT for a credit note. Returns (True, 'Printed') or (False, msg)."""
    import socket
    from core.pos_settings import get_pos_settings
    settings = get_pos_settings(db_path)
    if not settings.get("printer_enabled"):
        return False, "Printer not enabled in POS settings"
    if settings.get("printer_type", "network") != "network":
        return False, "Only network printers are currently supported"
    host = (settings.get("printer_host") or "").strip()
    port = int(settings.get("printer_port") or 9100)
    if not host:
        return False, "Printer host/IP not configured"
    receipt = get_receipt_data(db_path, cn_id, tender, amount, 0)
    data = _format_receipt_escpos(receipt, is_refund=True)
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5)
            s.connect((host, port))
            s.sendall(data)
        return True, "Printed"
    except socket.timeout:
        return False, f"Printer timeout — could not connect to {host}:{port}"
    except OSError as e:
        return False, f"Printer error: {e}"


def create_pos_store_credit(db_path, invoice_id: int, lines: list) -> dict:
    """
    Issue a store credit (open credit note) against a completed sale.
    No cash movement — the CN is left unapplied for use against future invoices.
    Returns {cn_id, cn_number, total}.
    """
    today = _date.today().isoformat()
    cn_id = create_credit_note(
        db_path, invoice_id, lines, today,
        memo="POS store credit",
    )
    conn = get_connection(db_path)
    cn = conn.execute("SELECT invoice_number, total FROM invoices WHERE id=?", (cn_id,)).fetchone()
    conn.close()
    return {"cn_id": cn_id, "cn_number": cn["invoice_number"], "total": round(float(cn["total"]), 2)}


def print_credit_note_receipt(db_path, cn_id: int, amount: float):
    """Print a CREDIT NOTE receipt for a store credit. Returns (True, 'Printed') or (False, msg)."""
    import socket
    from core.pos_settings import get_pos_settings
    settings = get_pos_settings(db_path)
    if not settings.get("printer_enabled"):
        return False, "Printer not enabled in POS settings"
    if settings.get("printer_type", "network") != "network":
        return False, "Only network printers are currently supported"
    host = (settings.get("printer_host") or "").strip()
    port = int(settings.get("printer_port") or 9100)
    if not host:
        return False, "Printer host/IP not configured"
    receipt = get_receipt_data(db_path, cn_id, "credit", amount, 0)
    data = _format_receipt_escpos(receipt, is_credit_note=True)
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5)
            s.connect((host, port))
            s.sendall(data)
        return True, "Printed"
    except socket.timeout:
        return False, f"Printer timeout — could not connect to {host}:{port}"
    except OSError as e:
        return False, f"Printer error: {e}"


def _get_square_status(settings, checkout_id) -> dict:
    import urllib.request, json as _json
    url = f"{_square_base(settings)}/terminals/checkouts/{checkout_id}"
    headers = {
        "Authorization":  f"Bearer {settings.get('api_key', '')}",
        "Square-Version": _SQUARE_VERSION,
    }
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = _json.loads(resp.read())
        checkout = data.get("checkout") or {}
        status = checkout.get("status", "")
        if status == "COMPLETED":
            return {"status": "completed", "tx_id": checkout_id, "method": "card"}
        if status in ("CANCELED", "CANCEL_REQUESTED"):
            return {"status": "declined", "message": "Payment cancelled"}
        return {"status": "pending"}
    except Exception as e:
        return {"status": "error", "message": str(e)}
