# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Daily check-in, so we know roughly how many copies are in use.

Once a day (when the dashboard checks for updates) the app posts to the licence
server: a random install number made the first time it runs, the app version,
the operating system and the kind of licence (not registered, Pro trial, paid,
lapsed). Nothing that identifies the person or their data is sent, and the
server doesn't keep IP addresses.

No check-in from a git checkout (development and tests), or when
DOGBOX_NO_USAGE is set.
"""
import os
import sys
import json
import time
import uuid
import platform
import threading
import urllib.request

from core.licence import VALIDATION_URL

PING_URL = VALIDATION_URL.rstrip('/') + '/api/ping'
_INSTALL_DIR = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
_last = {'at': 0.0}
_lock = threading.Lock()


def _os_name(store=False):
    name = {'win32': 'Windows', 'darwin': 'macOS'}.get(sys.platform, platform.system() or 'Other')
    return name + (' (Store)' if store else '')


def licence_kind(status: dict) -> str:
    """Short label for the licence: unregistered, trial, paid or the status word."""
    st = (status or {}).get('status')
    if st == 'missing':
        return 'unregistered'
    if st == 'valid':
        return 'trial' if status.get('is_eval') else 'paid'
    return st or 'unknown'


def _install_id(id_dir):
    path = os.path.join(id_dir, 'install_id')
    try:
        with open(path) as f:
            v = f.read().strip()
        if len(v) == 32:
            return v
    except OSError:
        pass
    v = uuid.uuid4().hex
    os.makedirs(id_dir, exist_ok=True)
    with open(path, 'w') as f:
        f.write(v)
    return v


def enabled(install_dir=_INSTALL_DIR):
    return not os.environ.get('DOGBOX_NO_USAGE') and not os.path.exists(os.path.join(install_dir, '.git'))


def ping(app, version, id_dir, licence_fn=None, store=False, install_dir=_INSTALL_DIR):
    """Check in at most once a day per running app. Runs in the background and never
    raises; licence_fn is only called when a check-in is actually sent."""
    if not enabled(install_dir):
        return
    with _lock:
        now = time.time()
        if now - _last['at'] < 86400:
            return
        _last['at'] = now

    def _send():
        try:
            body = {'app': app, 'install_id': _install_id(id_dir), 'version': version,
                    'os': _os_name(store)}
            if licence_fn:
                try:
                    body['licence'] = licence_fn()
                except Exception:
                    pass
            req = urllib.request.Request(PING_URL, data=json.dumps(body).encode(),
                                         headers={'Content-Type': 'application/json'},
                                         method='POST')
            urllib.request.urlopen(req, timeout=10).close()
        except Exception:
            pass
    threading.Thread(target=_send, daemon=True).start()
