# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Shared constants and simple helpers used across multiple payroll sub-modules.
Nothing here imports from other payroll sub-modules.
"""

from datetime import date

# ══════════════════════════════════════════════════════════════════════════════
#  CONSTANTS
# ══════════════════════════════════════════════════════════════════════════════

# Super Guarantee rate schedule (FY start year -> rate)
SUPER_RATES = {
    2023: 0.1050, 2024: 0.1100, 2025: 0.1150,
    2026: 0.1150, 2027: 0.1200, 2028: 0.1200,
}

PAY_FREQUENCIES    = ["Weekly", "Fortnightly", "Monthly"]
MONTH_NAMES        = ["Jan","Feb","Mar","Apr","May","Jun",
                      "Jul","Aug","Sep","Oct","Nov","Dec"]
EMPLOYMENT_TYPES   = ["Full-time", "Part-time", "Casual"]
LEAVE_TYPES        = ["Annual Leave", "Personal/Carer's Leave", "Long Service Leave",
                      "Unpaid Leave", "Parental Leave"]
ALLOWANCE_TYPES    = ["Tool Allowance", "Car Allowance", "Meal Allowance",
                      "Uniform Allowance", "Other Allowance"]


# ══════════════════════════════════════════════════════════════════════════════
#  SIMPLE HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def super_rate(fy_year: int) -> float:
    return SUPER_RATES.get(fy_year, 0.115)


def current_fy() -> int:
    today = date.today()
    return today.year if today.month >= 7 else today.year - 1


def _period_to_annual(amount: float, frequency: str) -> float:
    multipliers = {"Weekly": 52, "Fortnightly": 26, "Monthly": 12}
    return amount * multipliers.get(frequency, 26)
