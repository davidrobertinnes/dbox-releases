# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Payroll database schema migration.  Creates all payroll tables and seeds
GL accounts.  Safe to call multiple times (idempotent).
"""


def migrate_payroll(conn):
    """Create all payroll tables. Safe to call multiple times."""

    conn.execute("""CREATE TABLE IF NOT EXISTS employees (
        id                  INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_number     TEXT NOT NULL UNIQUE,
        first_name          TEXT NOT NULL,
        last_name           TEXT NOT NULL,
        date_of_birth       TEXT,
        gender              TEXT,
        address             TEXT,
        city                TEXT,
        state               TEXT,
        postcode            TEXT,
        email               TEXT,
        phone               TEXT,
        -- Employment
        employment_type     TEXT NOT NULL DEFAULT 'Full-time',
        pay_frequency       TEXT NOT NULL DEFAULT 'Fortnightly',
        start_date          TEXT NOT NULL,
        termination_date    TEXT,
        position_title      TEXT,
        department          TEXT,
        -- Remuneration
        annual_salary       REAL,
        hourly_rate         REAL,
        hours_per_week      REAL NOT NULL DEFAULT 38.0,
        -- Tax
        tfn                 TEXT,
        tfn_quoted          INTEGER NOT NULL DEFAULT 1,
        has_tax_free_threshold INTEGER NOT NULL DEFAULT 1,
        study_loan          INTEGER NOT NULL DEFAULT 0,   -- HELP/HECS
        senior_offset       INTEGER NOT NULL DEFAULT 0,
        is_foreign_resident INTEGER NOT NULL DEFAULT 0,   -- Scale 3 vs Scale 1/2
        medicare_exemption  TEXT    NOT NULL DEFAULT 'none', -- none | full | half
        -- Super
        super_fund_name     TEXT,
        super_fund_abn      TEXT,
        super_fund_usi      TEXT,
        super_member_number TEXT,
        super_rate_override REAL,   -- NULL = use statutory rate
        -- Bank
        bank_bsb            TEXT,
        bank_account        TEXT,
        bank_name           TEXT,
        -- YTD accumulators (reset 1 July each year)
        ytd_gross           REAL NOT NULL DEFAULT 0,
        ytd_tax             REAL NOT NULL DEFAULT 0,
        ytd_super           REAL NOT NULL DEFAULT 0,
        ytd_allowances      REAL NOT NULL DEFAULT 0,
        ytd_leave_paid      REAL NOT NULL DEFAULT 0,
        -- STP
        stp_sent            INTEGER NOT NULL DEFAULT 0,
        is_active           INTEGER NOT NULL DEFAULT 1,
        created_at          TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS pay_runs (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        run_number      TEXT NOT NULL UNIQUE,
        pay_period_start TEXT NOT NULL,
        pay_period_end   TEXT NOT NULL,
        payment_date    TEXT NOT NULL,
        frequency       TEXT NOT NULL,
        status          TEXT NOT NULL DEFAULT 'Draft',  -- Draft, Finalised, STP_Lodged
        total_gross     REAL NOT NULL DEFAULT 0,
        total_tax       REAL NOT NULL DEFAULT 0,
        total_super     REAL NOT NULL DEFAULT 0,
        total_net       REAL NOT NULL DEFAULT 0,
        journal_id      INTEGER,
        stp_envelope    TEXT,   -- JSON of STP XML envelope sent
        stp_lodged_at   TEXT,
        created_by      INTEGER,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS payslips (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        pay_run_id      INTEGER NOT NULL REFERENCES pay_runs(id),
        employee_id     INTEGER NOT NULL REFERENCES employees(id),
        -- Pay period
        period_start    TEXT NOT NULL,
        period_end      TEXT NOT NULL,
        payment_date    TEXT NOT NULL,
        -- Earnings breakdown
        ordinary_hours  REAL NOT NULL DEFAULT 0,
        ordinary_rate   REAL NOT NULL DEFAULT 0,
        ordinary_gross  REAL NOT NULL DEFAULT 0,
        overtime_hours  REAL NOT NULL DEFAULT 0,
        overtime_rate   REAL NOT NULL DEFAULT 0,
        overtime_gross  REAL NOT NULL DEFAULT 0,
        leave_type      TEXT,
        leave_hours     REAL NOT NULL DEFAULT 0,
        leave_gross     REAL NOT NULL DEFAULT 0,
        allowances      REAL NOT NULL DEFAULT 0,
        allowances_json TEXT,   -- [{type, amount}]
        -- Deductions
        salary_sacrifice REAL NOT NULL DEFAULT 0,   -- pre-tax super
        other_deductions REAL NOT NULL DEFAULT 0,
        -- Totals
        gross_pay       REAL NOT NULL DEFAULT 0,
        payg_tax        REAL NOT NULL DEFAULT 0,
        net_pay         REAL NOT NULL DEFAULT 0,
        -- Super
        super_amount    REAL NOT NULL DEFAULT 0,
        super_ytd       REAL NOT NULL DEFAULT 0,
        -- YTD at time of payslip
        ytd_gross       REAL NOT NULL DEFAULT 0,
        ytd_tax         REAL NOT NULL DEFAULT 0,
        ytd_super       REAL NOT NULL DEFAULT 0,
        -- STP
        stp_income_type TEXT NOT NULL DEFAULT 'SAL',  -- SAL, WAG, LAB, VOL, IAA
        status          TEXT NOT NULL DEFAULT 'Calculated',
        notes           TEXT,
        UNIQUE(pay_run_id, employee_id))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS payroll_allowances (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        payslip_id  INTEGER NOT NULL REFERENCES payslips(id),
        allow_type  TEXT NOT NULL,
        description TEXT,
        amount      REAL NOT NULL)""")

    conn.execute("""CREATE TABLE IF NOT EXISTS stp_submissions (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        pay_run_id      INTEGER REFERENCES pay_runs(id),
        submission_type TEXT NOT NULL DEFAULT 'Update',  -- Update, Finalisation
        fy_year         INTEGER NOT NULL,
        submitted_at    TEXT DEFAULT (datetime('now','localtime')),
        status          TEXT NOT NULL DEFAULT 'Pending',  -- Pending, Accepted, Rejected
        payload_xml     TEXT,
        response_xml    TEXT,
        message         TEXT)""")

    # Additional employee columns (migration-safe ALTER TABLE)
    for _col, _def in [
        ("additional_withholding",  "REAL NOT NULL DEFAULT 0"),   # extra PAYG $ per period
        ("salary_sacrifice_amount", "REAL NOT NULL DEFAULT 0"),   # recurring pre-tax super $ per period
        ("voluntary_super_amount",  "REAL NOT NULL DEFAULT 0"),   # post-tax voluntary super $ per period
        ("is_foreign_resident",     "INTEGER NOT NULL DEFAULT 0"),  # Scale 3
        ("medicare_exemption",      "TEXT NOT NULL DEFAULT 'none'"), # none|full|half
        ("award_id",                "INTEGER"),                    # FK to awards
        ("classification_id",       "INTEGER"),                    # FK to award_classifications
        ("pay_point",               "INTEGER"),                    # pay point within classification
        ("pay_rate_modifier",       "REAL"),                       # e.g. 1.25 for senior loading
        ("pay_rate_modifier_type",  "TEXT"),                       # e.g. 'percentage' or 'flat'
        ("contact_id",              "INTEGER"),                    # FK to contacts (linked contact record)
    ]:
        try:
            conn.execute(f"ALTER TABLE employees ADD COLUMN {_col} {_def}")
        except Exception:
            pass

    # Payslip super remittance tracking (migration-safe)
    for _col, _def in [
        ("super_remitted",         "INTEGER NOT NULL DEFAULT 0"),
        ("super_payment_batch_id", "INTEGER"),
    ]:
        try:
            conn.execute(f"ALTER TABLE payslips ADD COLUMN {_col} {_def}")
        except Exception:
            pass

    # Super payment / remittance tables
    conn.execute("""CREATE TABLE IF NOT EXISTS super_payments (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        payment_number  TEXT NOT NULL UNIQUE,
        payment_date    TEXT NOT NULL,
        quarter         TEXT NOT NULL,          -- e.g. '2025-Q1'
        due_date        TEXT NOT NULL,          -- SG due date (28 days after quarter end)
        status          TEXT NOT NULL DEFAULT 'Draft',
                                                -- Draft | Paid | Overdue
        payment_method  TEXT DEFAULT 'SuperStream',
        reference       TEXT,                   -- bank / clearinghouse ref
        total_sgc       REAL NOT NULL DEFAULT 0,
        total_salary_sacrifice REAL NOT NULL DEFAULT 0,
        total_voluntary REAL NOT NULL DEFAULT 0,
        total_amount    REAL NOT NULL DEFAULT 0,
        journal_id      INTEGER,
        notes           TEXT,
        created_by      INTEGER,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS super_payment_lines (
        id                  INTEGER PRIMARY KEY AUTOINCREMENT,
        super_payment_id    INTEGER NOT NULL REFERENCES super_payments(id) ON DELETE CASCADE,
        employee_id         INTEGER NOT NULL REFERENCES employees(id),
        fund_name           TEXT,
        fund_abn            TEXT,
        fund_usi            TEXT,
        member_number       TEXT,
        sgc_amount          REAL NOT NULL DEFAULT 0,
        salary_sacrifice    REAL NOT NULL DEFAULT 0,
        voluntary_amount    REAL NOT NULL DEFAULT 0,
        total_amount        REAL NOT NULL DEFAULT 0,
        period_start        TEXT,
        period_end          TEXT,
        pay_run_ids         TEXT)""")   # JSON list of pay_run ids covered

    # Payroll-specific GL accounts (seed if not present)
    for code, name, atype, subtype in [
        ('2-1310', 'PAYG Withholding Payable', 'Liability', 'Current Liability'),
        ('2-1410', 'Superannuation Payable',   'Liability', 'Current Liability'),
        ('2-1420', 'Salary Sacrifice Clearing', 'Liability','Current Liability'),
        ('2-1430', 'Net Wages Payable',        'Liability', 'Current Liability'),
        ('2-1440', 'Voluntary Super Payable',  'Liability', 'Current Liability'),
        ('5-3710', 'Wages - Ordinary Time',    'Expense',   'Overhead'),
        ('5-3720', 'Wages - Overtime',         'Expense',   'Overhead'),
        ('5-3730', 'Wages - Annual Leave',     'Expense',   'Overhead'),
        ('5-3740', 'Wages - Personal Leave',   'Expense',   'Overhead'),
        ('5-3750', 'Wages - Other Leave',      'Expense',   'Overhead'),
        ('5-3760', 'Wages - Allowances',       'Expense',   'Overhead'),
        ('5-3510', 'Superannuation Expense',   'Expense',   'Overhead'),
    ]:
        try:
            conn.execute("""INSERT OR IGNORE INTO accounts
                (code,name,account_type,account_subtype,is_bank) VALUES (?,?,?,?,0)""",
                (code, name, atype, subtype))
        except Exception:
            pass

    # Leave management tables (migration-safe)
    from core.leave import migrate_leave
    migrate_leave(conn)

    # Awards & agreements tables (migration-safe)
    from core.awards import migrate_awards
    migrate_awards(conn)

    # PAYG tax rates table (migration-safe)
    conn.execute("""CREATE TABLE IF NOT EXISTS payg_tax_rates (
        fy_year                 INTEGER PRIMARY KEY,   -- e.g. 2025 = FY2024-25
        label                   TEXT NOT NULL,          -- e.g. '2024-25'
        brackets_json           TEXT NOT NULL,          -- [[threshold, base, rate], ...]
        brackets_no_thresh_json TEXT NOT NULL DEFAULT '[]',
        medicare_json           TEXT NOT NULL,          -- {full_rate, full_start, ...}
        lito_json               TEXT NOT NULL,          -- [[up_to, max_off, red_rate], ...]
        lito_no_thresh_json     TEXT NOT NULL DEFAULT '[]',
        help_json               TEXT NOT NULL DEFAULT '[]',
        help_method             TEXT NOT NULL DEFAULT 'whole',
        sapto_json              TEXT NOT NULL DEFAULT '{}',
        no_tfn_rate             REAL NOT NULL DEFAULT 0.47,
        notes                   TEXT,
        updated_at              TEXT DEFAULT (datetime('now','localtime')))""")
