# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
PAYG withholding: ATO Schedule 1 coefficient tables, tax computation helpers,
DB-backed rate storage (payg_tax_rates table), and the public payg_for_period()
entry point.
"""

import json as _json
import math as _math

from core.database import get_connection
from core.payroll._shared import current_fy


# ══════════════════════════════════════════════════════════════════════════════
#  DB SCHEMA & RATE STORAGE
# ══════════════════════════════════════════════════════════════════════════════

_PAYG_TABLE_DDL = """CREATE TABLE IF NOT EXISTS payg_tax_rates (
    fy_year                 INTEGER PRIMARY KEY,
    label                   TEXT NOT NULL,
    brackets_json           TEXT NOT NULL,
    brackets_no_thresh_json TEXT NOT NULL DEFAULT '[]',
    medicare_json           TEXT NOT NULL,
    lito_json               TEXT NOT NULL,
    lito_no_thresh_json     TEXT NOT NULL DEFAULT '[]',
    help_json               TEXT NOT NULL DEFAULT '[]',
    help_method             TEXT NOT NULL DEFAULT 'whole',
    sapto_json              TEXT NOT NULL DEFAULT '{}',
    no_tfn_rate             REAL NOT NULL DEFAULT 0.47,
    notes                   TEXT,
    updated_at              TEXT DEFAULT (datetime('now','localtime')))"""


def _ensure_payg_table(conn) -> None:
    """Create payg_tax_rates if it doesn't exist. Safe to call on every access."""
    conn.execute(_PAYG_TABLE_DDL)


def load_payg_rates(db_path: str, fy_year: int) -> dict | None:
    """
    Load all PAYG withholding parameters for a financial year from the database.
    Returns keys: brackets, brackets_no_thresh, medicare, lito, lito_no_thresh,
                  help, help_method, sapto, no_tfn_rate, label.
    Returns None if not found.
    """
    try:
        conn = get_connection(db_path)
        row = conn.execute(
            "SELECT * FROM payg_tax_rates WHERE fy_year=?", (fy_year,)).fetchone()
        conn.close()
        if not row:
            return None
        keys = row.keys()
        return {
            "brackets":           _json.loads(row["brackets_json"]),
            "brackets_no_thresh": _json.loads(row["brackets_no_thresh_json"] if "brackets_no_thresh_json" in keys else "[]"),
            "medicare":           _json.loads(row["medicare_json"]),
            "lito":               _json.loads(row["lito_json"]),
            "lito_no_thresh":     _json.loads(row["lito_no_thresh_json"] or "[]"),
            "help":               _json.loads(row["help_json"] or "[]"),
            "help_method":        row["help_method"] if "help_method" in keys else "whole",
            "sapto":              _json.loads(row["sapto_json"] or "{}"),
            "no_tfn_rate":        row["no_tfn_rate"],
            "label":              row["label"],
        }
    except Exception:
        return None


def save_payg_rates(db_path: str, fy_year: int, label: str,
                    brackets: list, brackets_no_thresh: list,
                    medicare: dict,
                    lito: list, lito_no_thresh: list,
                    help_table: list, sapto: dict,
                    no_tfn_rate: float = 0.47,
                    help_method: str = "whole",
                    notes: str = "") -> None:
    """Save or update all PAYG rates for a financial year."""
    conn = get_connection(db_path)
    _ensure_payg_table(conn)
    conn.execute("""INSERT INTO payg_tax_rates
        (fy_year, label, brackets_json, brackets_no_thresh_json, medicare_json, lito_json,
         lito_no_thresh_json, help_json, help_method, sapto_json,
         no_tfn_rate, notes, updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?, datetime('now','localtime'))
        ON CONFLICT(fy_year) DO UPDATE SET
            label=excluded.label,
            brackets_json=excluded.brackets_json,
            brackets_no_thresh_json=excluded.brackets_no_thresh_json,
            medicare_json=excluded.medicare_json,
            lito_json=excluded.lito_json,
            lito_no_thresh_json=excluded.lito_no_thresh_json,
            help_json=excluded.help_json,
            help_method=excluded.help_method,
            sapto_json=excluded.sapto_json,
            no_tfn_rate=excluded.no_tfn_rate,
            notes=excluded.notes,
            updated_at=excluded.updated_at""",
        (fy_year, label,
         _json.dumps(brackets), _json.dumps(brackets_no_thresh),
         _json.dumps(medicare),
         _json.dumps(lito), _json.dumps(lito_no_thresh),
         _json.dumps(help_table), help_method,
         _json.dumps(sapto), no_tfn_rate, notes))
    conn.commit()
    conn.close()


def list_payg_rate_years(db_path: str) -> list:
    """Return list of dicts (fy_year, label, notes, updated_at) from DB."""
    try:
        conn = get_connection(db_path)
        _ensure_payg_table(conn)
        rows = conn.execute(
            "SELECT fy_year, label, notes, updated_at FROM payg_tax_rates "
            "ORDER BY fy_year").fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except Exception:
        return []


# ══════════════════════════════════════════════════════════════════════════════
#  ATO SCHEDULE 1 COEFFICIENT TABLES
# ══════════════════════════════════════════════════════════════════════════════
#
# Formula:  y = a × x − b
#   y = weekly withholding (dollars, rounded to nearest dollar, 0.5 rounds up)
#   x = int(weekly_earnings) + 0.99
#
# For fortnightly/monthly earnings, convert to weekly equivalent first:
#   weekly_equiv = period_earnings / periods_per_week   (fortnightly ÷ 2, monthly ÷ (52/12))
# Then multiply result by periods_per_week.
#
# 2025-26 source: ATO NAT 1004, published 17 June 2024 (same for 2024-25 and 2025-26).
# 2026-27 source: ATO NAT 1004, published 17 June 2026 (16% → 15% first band).
#
# Each row: (weekly_earnings_upper_bound, a, b)
# Last row has upper_bound = inf.  None means no withholding in that range.

# ── 2025-26 coefficient tables (valid for FY2024-25 and FY2025-26) ────────────
_SCHED1_SCALE1_2526 = [   # No tax-free threshold
    (150,      0.1600,   0.1600),
    (371,      0.2117,   7.7550),
    (515,      0.1890,  -0.6702),
    (932,      0.3227,  68.2367),
    (2246,     0.3200,  65.7202),
    (3303,     0.3900, 222.9510),
    (_math.inf, 0.4700, 487.2587),
]
_SCHED1_SCALE2_2526 = [   # Tax-free threshold claimed
    (361,      None,      None),
    (500,      0.1600,   57.8462),
    (625,      0.2600,  107.8462),
    (721,      0.1800,   57.8462),
    (865,      0.1890,   64.3365),
    (1282,     0.3227,  180.0385),
    (2596,     0.3200,  176.5769),
    (3653,     0.3900,  358.3077),
    (_math.inf, 0.4700, 650.6154),
]
_SCHED1_SCALE5_2526 = [   # Full Medicare levy exemption
    (361,      None,      None),
    (721,      0.1600,   57.8462),
    (865,      0.1690,   64.3365),
    (1282,     0.3027,  180.0385),
    (2596,     0.3000,  176.5769),
    (3653,     0.3700,  358.3077),
    (_math.inf, 0.4500, 650.6154),
]
_SCHED1_SCALE6_2526 = [   # Half Medicare levy exemption
    (361,      None,      None),
    (721,      0.1600,   57.8462),
    (843,      0.1690,   64.3365),
    (865,      0.2190,  106.4962),
    (1053,     0.3527,  222.1981),
    (1282,     0.3127,  180.0385),
    (2596,     0.3100,  176.5769),
    (3653,     0.3800,  358.3077),
    (_math.inf, 0.4600, 650.6154),
]

# ── 2026-27 coefficient tables (valid from 1 July 2026) ───────────────────────
_SCHED1_SCALE1_2627 = [   # No tax-free threshold
    (188,      0.1500,   0.1500),
    (371,      0.2084,  11.0185),
    (515,      0.1790,   0.1066),
    (932,      0.3227,  74.1674),
    (2246,     0.3200,  71.6508),
    (3303,     0.3900, 228.8816),
    (_math.inf, 0.4700, 493.1893),
]
_SCHED1_SCALE2_2627 = [   # Tax-free threshold claimed
    (362,      None,      None),
    (538,      0.1500,   54.3462),
    (673,      0.2500,  108.2135),
    (721,      0.1700,   54.3473),
    (865,      0.1790,   60.8377),
    (1282,     0.3227,  185.1935),
    (2596,     0.3200,  181.7319),
    (3653,     0.3900,  363.4627),
    (_math.inf, 0.4700, 655.7704),
]
_SCHED1_SCALE5_2627 = [   # Full Medicare levy exemption
    (362,      None,      None),
    (721,      0.1500,   54.3462),
    (865,      0.1590,   60.8365),
    (1282,     0.3027,  185.1923),
    (2596,     0.3000,  181.7308),
    (3653,     0.3700,  363.4615),
    (_math.inf, 0.4500, 655.7692),
]
_SCHED1_SCALE6_2627 = [   # Half Medicare levy exemption
    (362,      None,      None),
    (721,      0.1500,   54.3462),
    (865,      0.1590,   60.8365),
    (908,      0.3027,  185.1923),
    (1135,     0.3527,  230.6135),
    (1282,     0.3127,  185.1923),
    (2596,     0.3100,  181.7308),
    (3653,     0.3800,  363.4615),
    (_math.inf, 0.4600, 655.7692),
]

# Scale 3 (foreign residents) unchanged between vintages
_SCHED1_SCALE3 = [
    (2596,     0.3000,   0.3000),
    (3653,     0.3700, 181.7308),
    (_math.inf, 0.4500, 474.0385),
]
# Scale 4 (no TFN): flat rate, no coefficient table needed.
# Resident 47%, foreign resident 45%.  Cents ignored.


def _payg_schedule1(weekly_earnings: float, scale: list) -> int:
    """
    ATO Schedule 1 weekly withholding using coefficient table.
    y = a × (int(e) + 0.99) − b, rounded to nearest dollar (0.5 → up).
    Returns 0 for earnings in a no-withholding band (a is None).
    """
    e = int(weekly_earnings)   # truncate cents per ATO spec
    x = e + 0.99
    for upper, a, b in scale:
        if e < upper:
            if a is None:
                return 0
            y = a * x - b
            return max(0, _math.floor(y + 0.5))  # round half-up
    return 0                   # shouldn't reach here if table has inf row


# ══════════════════════════════════════════════════════════════════════════════
#  CORE TAX COMPUTATION HELPERS (used by both legacy formula and coefficient)
# ══════════════════════════════════════════════════════════════════════════════

def _calc_gross_tax(income: float, brackets: list) -> float:
    """Income tax before any offsets. brackets sorted ascending by threshold."""
    active_thresh = 0.0
    active_base   = 0.0
    active_rate   = 0.0
    for threshold, base, rate in brackets:
        if income >= threshold:
            active_thresh = threshold
            active_base   = base
            active_rate   = rate
        else:
            break
    return active_base + (income - active_thresh) * active_rate


def _calc_medicare(income: float, m: dict) -> float:
    """Medicare levy with phase-in for low incomes."""
    full_start  = m.get("full_start",     26000.0)
    full_rate   = m.get("full_rate",      0.020)
    shade_start = m.get("shade_in_start", 22801.0)
    shade_rate  = m.get("shade_in_rate",  0.100)
    if income >= full_start:
        return income * full_rate
    elif income >= shade_start:
        return (income - shade_start) * shade_rate
    return 0.0


def _calc_lito(income: float, lito_bands: list) -> float:
    """
    Low Income Tax Offset.
    lito_bands: [[income_up_to, max_offset, reduction_rate_above_prev_ceiling], ...]
    Returns offset amount (always >= 0).
    """
    if not lito_bands:
        return 0.0
    prev = 0.0
    for up_to, max_off, red_rate in lito_bands:
        if income <= up_to:
            return max(0.0, max_off - (income - prev) * red_rate)
        prev = up_to
    return 0.0


def _calc_sapto(income: float, sapto: dict, couple: bool = False) -> float:
    """
    Senior Australians and Pensioners Tax Offset.
    Shades out at 12.5c per $1 over the shade-in threshold.
    Returns offset amount (>= 0).
    """
    if not sapto:
        return 0.0
    shade_rate = sapto.get("shade_rate", 0.125)
    if couple:
        max_off    = sapto.get("couple_max", 1602.0)
        shade_start = sapto.get("couple_shade_start", 28974.0)
    else:
        max_off    = sapto.get("single_max", 2230.0)
        shade_start = sapto.get("single_shade_start", 32279.0)
    reduction = max(0.0, (income - shade_start) * shade_rate) if income > shade_start else 0.0
    return max(0.0, max_off - reduction)


def _calc_help_repayment(income: float, help_table: list,
                          method: str = "whole") -> float:
    """
    HELP/VSL/SSL/ABSTUDY SSL/AASL annual compulsory repayment.

    method='whole' (2024-25 and earlier):
        help_table: [[income_from, rate], ...] — rate × entire income.

    method='marginal' (2025-26+, Universities Accord Act 2025):
        help_table: [[threshold, marginal_rate_above], ...]
        Negative rate sentinel (-0.10) = whole-income 10% above that threshold.
    """
    if not help_table or income <= 0:
        return 0.0

    if method == "marginal":
        cumulative = 0.0
        for i, (thresh, rate) in enumerate(help_table):
            if income <= thresh:
                break
            if rate < 0:
                # Whole-income sentinel (e.g. above $179,286 = 10% of total)
                return round(income * abs(rate), 2)
            next_thresh = help_table[i + 1][0] if i + 1 < len(help_table) else None
            band_top = min(income, next_thresh) if next_thresh else income
            if band_top > thresh:
                cumulative += (band_top - thresh) * rate
        return round(cumulative, 2)

    else:  # whole-income method
        active_rate = 0.0
        for threshold, rate in help_table:
            if income >= threshold:
                active_rate = rate
            else:
                break
        return round(income * active_rate, 2)


def _annual_tax_from_rates(income: float, has_threshold: bool,
                            brackets: list, medicare: dict, lito_with: list,
                            lito_no_thresh: list = None,
                            help_table: list = None,
                            help_method: str = "whole",
                            sapto: dict = None,
                            has_study_loan: bool = False,
                            is_senior: bool = False,
                            senior_couple: bool = False,
                            brackets_no_thresh: list = None) -> float:
    """
    Full annual PAYG withholding calculation (ATO Schedule 1 order):
      1. Gross income tax — Scale 1 (threshold claimed) or Scale 4 (not claimed)
         Scale 1: $18,200 tax-free zone, then 16%/30%/37%/45%
         Scale 4: 16% from dollar 1 (no free zone), then 30%/37%/45%
      2. Less LITO (with-threshold has LITO; no-threshold has none)
      3. Less SAPTO (if senior/pensioner)
      4. Plus Medicare levy
      5. Plus HELP/VSL/SSL compulsory repayment (if study loan)
    """
    if income <= 0:
        return 0.0

    if has_threshold:
        gross_tax = _calc_gross_tax(income, brackets)
        lito_val  = _calc_lito(income, lito_with)
    else:
        # Scale 4: use no-threshold brackets (no $18,200 free zone)
        # Fall back to deriving from Scale 1 brackets if no-thresh not stored
        nt_brackets = brackets_no_thresh or []
        if not nt_brackets and brackets:
            # Derive: replace the 0-rate zero band with the first marginal rate
            first_rate = next((r for _, _, r in brackets if r > 0), 0.16)
            nt_brackets = [[0, 0.0, first_rate]] + [b for b in brackets if b[0] > 0 and b[2] > 0]
        gross_tax = _calc_gross_tax(income, nt_brackets)
        lito_val  = 0.0  # No LITO without tax-free threshold (ATO Schedule 1)

    sapto_val = _calc_sapto(income, sapto or {}, couple=senior_couple) if is_senior else 0.0
    med       = _calc_medicare(income, medicare)
    net_tax   = max(0.0, gross_tax - lito_val - sapto_val + med)
    help_rep  = _calc_help_repayment(income, help_table or [], method=help_method) \
                if has_study_loan else 0.0
    return round(net_tax + help_rep, 2)


# ══════════════════════════════════════════════════════════════════════════════
#  BUILT-IN RATE CONSTANTS — ATO 2024-25, Stage 3 tax cuts
# ══════════════════════════════════════════════════════════════════════════════

# Scale 1 (tax-free threshold claimed): $18,200 tax-free, then 16%/30%/37%/45%
_BUILTIN_BRACKETS = [
    [0,       0.00,    0.000],
    [18200,   0.00,    0.160],
    [45000,   4288.00, 0.300],
    [135000,  31288.00, 0.370],
    [190000,  51638.00, 0.450],
]
# Scale 4 (no threshold): 16% from $1, no free zone
_BUILTIN_BRACKETS_NO_THRESH = [
    [0,       0.00,     0.160],   # 16c from $1 (no $18,200 free zone)
    [45000,   7200.00,  0.300],   # 45000 * 0.16 = $7,200
    [135000,  34200.00, 0.370],
    [190000,  54550.00, 0.450],
]
# Medicare 2024-25: singles threshold $27,222; shade-in from $21,778
_BUILTIN_MEDICARE = {
    "full_rate": 0.020, "full_start": 27222.0,
    "shade_in_start": 21778.0, "shade_in_rate": 0.100,
}
_BUILTIN_LITO = [
    [37500,  700.0, 0.000],
    [45000,  700.0, 0.050],
    [66667,  325.0, 0.015],
    [999999,   0.0, 0.000],
]
_BUILTIN_LITO_NO_THRESH = []  # No LITO without tax-free threshold (ATO Schedule 1)

# HELP 2024-25 — whole-income rate method (NAT 3539)
_BUILTIN_HELP = [
    [0,        0.0000],
    [54435,    0.0100],
    [62851,    0.0200],
    [66621,    0.0250],
    [70619,    0.0300],
    [74856,    0.0350],
    [79347,    0.0400],
    [84108,    0.0450],
    [89155,    0.0500],
    [94504,    0.0550],
    [100175,   0.0600],
    [106186,   0.0650],
    [112557,   0.0700],
    [119310,   0.0750],
    [126468,   0.0800],
    [134057,   0.0850],
    [142101,   0.0900],
    [150627,   0.0950],
    [159664,   0.1000],
]
_BUILTIN_HELP_METHOD = "whole"

_BUILTIN_SAPTO = {
    "single_max": 2230.0, "single_shade_start": 32279.0,
    "couple_max": 1602.0, "couple_shade_start": 28974.0,
    "shade_rate": 0.125,
}


def _get_rates(db_path: str = None, fy_year: int = None) -> dict:
    """Return rate dict from DB or built-in fallback."""
    if db_path and fy_year:
        r = load_payg_rates(db_path, fy_year)
        if r:
            return r
    return {
        "brackets":           _BUILTIN_BRACKETS,
        "brackets_no_thresh": _BUILTIN_BRACKETS_NO_THRESH,
        "medicare":           _BUILTIN_MEDICARE,
        "lito":               _BUILTIN_LITO,
        "lito_no_thresh":     _BUILTIN_LITO_NO_THRESH,
        "help":               _BUILTIN_HELP,
        "help_method":        _BUILTIN_HELP_METHOD,
        "sapto":              _BUILTIN_SAPTO,
        "no_tfn_rate":        0.47,
    }


def _annual_tax_resident(income: float,
                          has_threshold: bool = True,
                          db_path: str = None,
                          fy_year: int = None,
                          has_study_loan: bool = False,
                          is_senior: bool = False,
                          senior_couple: bool = False) -> float:
    """
    Compute full annual PAYG withholding for an Australian resident.
    Loads rates from DB when db_path/fy_year provided; falls back to 2024-25 built-ins.
    """
    r = _get_rates(db_path, fy_year)
    return _annual_tax_from_rates(
        income, has_threshold,
        r["brackets"], r["medicare"],
        r["lito"], r.get("lito_no_thresh", []),
        r.get("help", []), r.get("help_method", "whole"),
        r.get("sapto", {}),
        has_study_loan=has_study_loan,
        is_senior=is_senior,
        senior_couple=senior_couple,
        brackets_no_thresh=r.get("brackets_no_thresh", []),
    )


def compute_payg(annual_income: float, has_tax_free_threshold: bool = True,
                 db_path: str = None, fy_year: int = None,
                 has_study_loan: bool = False,
                 is_senior: bool = False) -> float:
    """Weekly PAYG withholding from annual income. Rounds to nearest $1."""
    annual_tax = _annual_tax_resident(
        annual_income, has_tax_free_threshold,
        db_path=db_path, fy_year=fy_year,
        has_study_loan=has_study_loan, is_senior=is_senior)
    return max(0.0, round(annual_tax / 52))


def payg_for_period(gross_period: float, frequency: str,
                    has_tfn: bool = True,
                    has_threshold: bool = True,
                    db_path: str = None,
                    fy_year: int = None,
                    has_study_loan: bool = False,
                    is_senior: bool = False,
                    senior_couple: bool = False,
                    is_foreign_resident: bool = False,
                    medicare_exemption: str = "none") -> float:
    """
    PAYG withholding for a single pay period.

    Implements ATO Schedule 1 (NAT 1004) 2024-25 coefficient method exactly,
    matching the ATO Tax Withheld Calculator to the dollar.

    Parameters
    ----------
    gross_period      : earnings for the pay period
    frequency         : 'Weekly' | 'Fortnightly' | 'Monthly'
    has_tfn           : False → Scale 4 flat rate (47% resident, 45% foreign)
    has_threshold     : True  → Scale 2 (tax-free threshold claimed)
                        False → Scale 1 (no threshold)
    is_foreign_resident: True → Scale 3
    medicare_exemption: 'none' | 'full' (Scale 5) | 'half' (Scale 6)
    has_study_loan    : HELP/VSL/SSL repayment added (uses legacy formula method
                        as Schedule 8 coefficients are separate)
    is_senior         : SAPTO — added via legacy formula after base withholding
    """
    periods = {"Weekly": 52, "Fortnightly": 26, "Monthly": 12}.get(frequency, 26)

    # ── Scale 4: no TFN ───────────────────────────────────────────────────────
    if not has_tfn:
        rate = 0.45 if is_foreign_resident else 0.47
        return int(gross_period * rate)  # cents ignored per ATO Scale 4 rules

    # ── Convert to weekly equivalent ─────────────────────────────────────────
    weekly = gross_period * periods / 52

    # ── Select coefficient scale ──────────────────────────────────────────────
    # current_fy() returns FY start year: June 2026 → 2025; July 2026 → 2026.
    # Use 2026-27 tables from 1 July 2026 onwards (fy_year >= 2026).
    _s1, _s2, _s5, _s6 = (
        (_SCHED1_SCALE1_2627, _SCHED1_SCALE2_2627,
         _SCHED1_SCALE5_2627, _SCHED1_SCALE6_2627)
        if (fy_year or 0) >= 2026 else
        (_SCHED1_SCALE1_2526, _SCHED1_SCALE2_2526,
         _SCHED1_SCALE5_2526, _SCHED1_SCALE6_2526)
    )
    if is_foreign_resident:
        scale = _SCHED1_SCALE3
    elif medicare_exemption == "full":
        scale = _s5
    elif medicare_exemption == "half":
        scale = _s6
    elif has_threshold:
        scale = _s2
    else:
        scale = _s1

    weekly_wh = _payg_schedule1(weekly, scale)

    # ── Scale back to actual period ───────────────────────────────────────────
    period_wh = round(weekly_wh * 52 / periods)

    # ── HELP/study loan repayment (Schedule 8 — formula method) ──────────────
    if has_study_loan:
        r = _get_rates(db_path, fy_year)
        annual_income = gross_period * periods
        help_rep = _calc_help_repayment(
            annual_income, r.get("help", []), method=r.get("help_method", "whole"))
        period_wh += max(0, round(help_rep / periods))

    # ── SAPTO (seniors offset — formula method, post-base-withholding) ────────
    if is_senior:
        r = _get_rates(db_path, fy_year)
        annual_income = gross_period * periods
        sapto_annual = _calc_sapto(annual_income, r.get("sapto", {}), couple=senior_couple)
        period_wh = max(0, period_wh - round(sapto_annual / periods))

    return max(0, period_wh)
