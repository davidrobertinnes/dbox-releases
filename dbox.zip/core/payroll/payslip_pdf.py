# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Payslip and payroll PDF/CSV generation:
  - generate_payslip_pdf          — individual payslip (Fair Work Act reg 3.46)
  - generate_payrun_report_pdf    — pay run summary (management copy)
  - generate_super_remittance_pdf — SuperStream remittance advice
  - render_payg_summary_pdf       — PAYG Payment Summary (group certificate)
  - generate_outstanding_leave_pdf / _csv — leave balance reports
  - generate_period_leave_report_pdf      — approved leave for a pay period
"""

import json
import os

from core.database import get_connection
from core.payroll._shared import super_rate, current_fy
from core.payroll.payrun import (
    get_pay_run, get_payg_summary, _get_all_leave_balances,
)
from core.payroll.super import get_super_payment
from core.payroll.employees import get_employee


# ══════════════════════════════════════════════════════════════════════════════
#  INDIVIDUAL PAYSLIP PDF
# ══════════════════════════════════════════════════════════════════════════════

def generate_payslip_pdf(db_path, payslip_id: int = None,
                          run_id: int = None, employee_id: int = None,
                          output_path: str = None,
                          watermark: str = None, footer: str = None) -> str:
    """
    Generate a Fair Work Act compliant payslip PDF.
    Satisfies Fair Work Regulations 2009, reg 3.46 requirements.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors as rl_colors
        from reportlab.lib.units import mm
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.enums import TA_RIGHT
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                         Table, TableStyle, HRFlowable)
    except ImportError:
        raise ImportError("reportlab not installed. Run: pip install reportlab")

    import tempfile
    conn = get_connection(db_path)
    if payslip_id:
        slip = conn.execute("SELECT * FROM payslips WHERE id=?",
                            (payslip_id,)).fetchone()
    elif run_id and employee_id:
        slip = conn.execute(
            "SELECT * FROM payslips WHERE pay_run_id=? AND employee_id=?",
            (run_id, employee_id)).fetchone()
    else:
        raise ValueError("Provide payslip_id or (run_id + employee_id)")
    if not slip:
        raise ValueError("Payslip not found")
    slip = dict(slip)

    emp     = dict(conn.execute("SELECT * FROM employees WHERE id=?",
                                (slip["employee_id"],)).fetchone())
    company = conn.execute("SELECT * FROM company").fetchone()
    co      = dict(company) if company else {}

    # Award / classification name for reg 3.46(e)
    cls_name = award_name = None
    if emp.get("classification_id"):
        row = conn.execute("""SELECT ac.name AS cls, a.name AS aw
            FROM award_classifications ac
            JOIN awards a ON a.id = ac.award_id
            WHERE ac.id=?""", (emp["classification_id"],)).fetchone()
        if row:
            cls_name, award_name = row["cls"], row["aw"]

    # Leave balances for NES/s536 display
    try:
        from core.leave import get_leave_balances, hours_to_days
        SHOW_CODES = {"ANN", "SIC", "LSL", "TOIL"}
        all_bal = get_leave_balances(db_path, emp["id"])
        leave_balances = [b for b in all_bal if b.get("code") in SHOW_CODES]
    except Exception:
        leave_balances = []
        def hours_to_days(h, hpd=7.6):
            if not h: return "0d"
            d, r = divmod(float(h), hpd)
            return f"{int(d)}d {r:.1f}h" if r >= 0.1 else f"{int(d)}d"

    conn.close()

    if output_path is None:
        output_path = os.path.join(tempfile.mkdtemp(),
            f"payslip_{emp['employee_number']}_{slip['payment_date']}.pdf")

    # ── Colours & Styles ──────────────────────────────────────────────────────
    from core.invoice_pdf import _resolve_theme, _c, _load_doc_theme
    _th   = _resolve_theme(_load_doc_theme(co))
    NAVY  = _c(_th["header_bg"])
    BLUE  = _c(_th["accent_bar"])
    LTGR  = _c(_th["row_alt"])
    LTBLU = _c(_th["payment_box_bg"])
    WHITE = rl_colors.white
    GREEN = rl_colors.HexColor("#27ae60")
    LGREY = _c(_th["dim_text"])

    def sty(name, **kw):
        d = dict(fontName="Helvetica", fontSize=9, leading=12,
                 textColor=_c(_th["body_text"]))
        d.update(kw)
        return ParagraphStyle(name, **d)

    S = {
        "title": sty("title", fontName="Helvetica-Bold", fontSize=16, textColor=NAVY),
        "co":    sty("co",    fontName="Helvetica-Bold", fontSize=11, textColor=NAVY),
        "label": sty("label", fontSize=7,   textColor=LGREY, leading=9),
        "small": sty("small", fontSize=7.5, textColor=rl_colors.HexColor("#444")),
        "body":  sty("body"),
        "bold":  sty("bold",  fontName="Helvetica-Bold"),
        "right": sty("right", alignment=TA_RIGHT),
        "rbold": sty("rbold", fontName="Helvetica-Bold", alignment=TA_RIGHT),
        "green": sty("green", fontName="Helvetica-Bold", fontSize=11, textColor=GREEN),
        "rgreen":sty("rgreen",fontName="Helvetica-Bold", fontSize=11,
                      textColor=GREEN, alignment=TA_RIGHT),
    }

    def P(text, style="body"):  return Paragraph(str(text or "—"), S[style])
    def fmt(v):    return f"${float(v or 0):,.2f}"
    def fmt_h(v):  return f"{float(v or 0):.2f}"
    def hdr(text): return Paragraph(text, ParagraphStyle("hh",
        fontName="Helvetica-Bold", fontSize=7.5, textColor=WHITE, leading=10))

    doc = SimpleDocTemplate(output_path, pagesize=A4,
                            leftMargin=14*mm, rightMargin=14*mm,
                            topMargin=12*mm, bottomMargin=12*mm)
    W = 182*mm
    story = []

    # ── 1. HEADER — Employer details (reg 3.46(a)(b)) ────────────────────────
    co_name = co.get("name","") or "Company"
    abn     = co.get("abn","")
    co_lines = [P(co_name, "co")]
    if abn:          co_lines.append(P(f"ABN: {abn}", "small"))
    addr_parts = [p for p in [co.get("address",""), co.get("city",""),
                               co.get("state",""), co.get("postcode","")] if p]
    if addr_parts:   co_lines.append(P("  ".join(addr_parts), "small"))
    if co.get("phone"): co_lines.append(P(f"Ph: {co.get('phone')}", "small"))

    co_tbl = Table([[c] for c in co_lines], colWidths=[100*mm])
    co_tbl.setStyle(TableStyle([
        ("TOPPADDING",(0,0),(-1,-1),1),("BOTTOMPADDING",(0,0),(-1,-1),1),
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
    ]))
    hdr_tbl = Table([[co_tbl, P("PAYSLIP","title")]], colWidths=[100*mm, 82*mm])
    hdr_tbl.setStyle(TableStyle([
        ("VALIGN",(0,0),(-1,-1),"TOP"),
        ("ALIGN",(1,0),(1,0),"RIGHT"),
    ]))
    story.append(hdr_tbl)
    story.append(HRFlowable(width="100%", thickness=2, color=BLUE, spaceAfter=3*mm))

    # ── 2. EMPLOYEE INFO (reg 3.46(c)(d)(e)) ─────────────────────────────────
    full_name = f"{emp['first_name']} {emp['last_name']}"
    emp_addr = ", ".join(p for p in [emp.get("address",""), emp.get("city",""),
                                      emp.get("state",""), emp.get("postcode","")] if p) or "—"
    if cls_name:
        cls_str = cls_name + (f" ({award_name})" if award_name else "")
    else:
        cls_str = emp.get("employment_type","") or "—"
    tfn_str = "***-***-***" if emp.get("tfn") else               ("Not quoted — 47% rate" if not emp.get("tfn_quoted",1) else "Not on file")

    info_data = [
        [P("EMPLOYEE NAME","label"),   P("EMPLOYEE NO.","label"),
         P("TAX FILE NUMBER","label"), P("EMPLOYMENT TYPE","label")],
        [P(full_name,"bold"),          P(emp.get("employee_number",""),"bold"),
         P(tfn_str),                   P(emp.get("employment_type",""))],
        [P("ADDRESS","label"),         P("POSITION","label"),
         P("CLASSIFICATION / AWARD","label"), P("PAY FREQUENCY","label")],
        [Paragraph(emp_addr, S["small"]),
         P(emp.get("position_title","") or "—"),
         Paragraph(cls_str.replace("\n","<br/>"), S["small"]),
         P(slip.get("pay_frequency","") or emp.get("pay_frequency",""))],
    ]
    cw_info = [W*0.27, W*0.16, W*0.33, W*0.24]
    info_tbl = Table(info_data, colWidths=cw_info)
    info_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),LTGR),
        ("BACKGROUND",(0,2),(-1,2),LTGR),
        ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#ccd0e0")),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
    ]))
    story.append(info_tbl)
    story.append(Spacer(1,3*mm))

    # ── 3. PAY PERIOD (reg 3.46(f)(g)) ───────────────────────────────────────
    period_tbl = Table([
        [P("PAY PERIOD","label"), P("PAYMENT DATE","label"), P("PAY RUN REF.","label")],
        [P(f"{slip['period_start']}  to  {slip['period_end']}","bold"),
         P(slip["payment_date"],"bold"), P(f"#{slip.get('pay_run_id','')}")]
    ], colWidths=[W*0.46, W*0.30, W*0.24])
    period_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),LTBLU),
        ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#ccd0e0")),
    ]))
    story.append(period_tbl)
    story.append(Spacer(1,3*mm))

    # ── 4. EARNINGS (reg 3.46(h)(i)) ─────────────────────────────────────────
    earn_rows = [[hdr("EARNINGS"), hdr("HOURS"), hdr("RATE ($/hr)"), hdr("AMOUNT ($)")]]

    if slip["ordinary_gross"] > 0:
        earn_rows.append([P("Ordinary Time"),
                          P(fmt_h(slip["ordinary_hours"]),"right"),
                          P(fmt(slip["ordinary_rate"]),"right"),
                          P(fmt(slip["ordinary_gross"]),"right")])

    if slip["overtime_gross"] > 0:
        ord_r = slip["ordinary_rate"] or 0
        ot_r  = slip["overtime_rate"]
        mult  = round(ot_r / ord_r, 1) if ord_r else 1.5
        earn_rows.append([P(f"Overtime ({mult:.1f}×)"),
                          P(fmt_h(slip["overtime_hours"]),"right"),
                          P(fmt(ot_r),"right"),
                          P(fmt(slip["overtime_gross"]),"right")])

    if slip.get("leave_gross",0) > 0:
        earn_rows.append([P(slip.get("leave_type","Leave") or "Leave"),
                          P(fmt_h(slip["leave_hours"]),"right"),
                          P(""), P(fmt(slip["leave_gross"]),"right")])

    if slip.get("allowances",0) > 0:
        try:
            al = json.loads(slip.get("allowances_json") or "[]")
        except Exception:
            al = []
        if al:
            for a in al:
                desc = a.get("type","Allowance")
                if a.get("description"):
                    desc += f" — {a['description']}"
                earn_rows.append([P(desc), P(""), P(""),
                                   P(fmt(a["amount"]),"right")])
        else:
            earn_rows.append([P("Allowances"), P(""), P(""),
                               P(fmt(slip["allowances"]),"right")])

    cw_earn = [W*0.50, W*0.16, W*0.18, W*0.16]
    earn_tbl = Table(earn_rows, colWidths=cw_earn)
    earn_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("TOPPADDING",(0,0),(-1,0),4),("BOTTOMPADDING",(0,0),(-1,0),4),
        ("TOPPADDING",(0,1),(-1,-1),3),("BOTTOMPADDING",(0,1),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[WHITE,LTGR]),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
        ("ALIGN",(1,0),(-1,-1),"RIGHT"),
    ]))
    story.append(earn_tbl)
    story.append(Spacer(1,2*mm))

    # ── 5. DEDUCTIONS (reg 3.46(j)) ──────────────────────────────────────────
    ded_rows = [[hdr("DEDUCTIONS"), hdr("RECIPIENT / PURPOSE"), hdr("AMOUNT ($)")]]
    has_ded = False

    if slip.get("payg_tax",0) > 0:
        ded_rows.append([P("PAYG Tax Withheld"),
                         P("Australian Taxation Office"),
                         P(f"({fmt(slip['payg_tax'])})","right")])
        has_ded = True

    if slip.get("salary_sacrifice",0) > 0:
        ded_rows.append([P("Salary Sacrifice — Super"),
                         P(emp.get("super_fund_name","") or "Nominated super fund"),
                         P(f"({fmt(slip['salary_sacrifice'])})","right")])
        has_ded = True

    if slip.get("other_deductions",0) > 0:
        ded_rows.append([P("Other Deductions"),
                         P("See payroll administrator"),
                         P(f"({fmt(slip['other_deductions'])})","right")])
        has_ded = True

    if not has_ded:
        ded_rows.append([P("No deductions this period"), P(""), P("")])

    cw_ded = [W*0.38, W*0.44, W*0.18]
    ded_tbl = Table(ded_rows, colWidths=cw_ded)
    ded_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("TOPPADDING",(0,0),(-1,0),4),("BOTTOMPADDING",(0,0),(-1,0),4),
        ("TOPPADDING",(0,1),(-1,-1),3),("BOTTOMPADDING",(0,1),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[WHITE,LTGR]),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
        ("ALIGN",(2,0),(2,-1),"RIGHT"),
    ]))
    story.append(ded_tbl)
    story.append(Spacer(1,2*mm))

    # Gross / Net summary (reg 3.46(h) gross, reg 3.46(k) net)
    total_ded = (slip.get("payg_tax",0) + slip.get("salary_sacrifice",0)
                 + slip.get("other_deductions",0))
    sum_rows = [
        [P("Gross Pay","bold"),    P(fmt(slip["gross_pay"]),"rbold")],
        [P("Total Deductions"),    P(f"({fmt(total_ded)})","right")],
        [P("NET PAY","bold"),      P(fmt(slip["net_pay"]),"rgreen")],
    ]
    sum_tbl = Table(sum_rows, colWidths=[W*0.82, W*0.18])
    sum_tbl.setStyle(TableStyle([
        ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("LINEABOVE",(0,-1),(-1,-1),1.5,BLUE),
        ("LINEBELOW",(0,-1),(-1,-1),1.5,BLUE),
        ("BACKGROUND",(0,-1),(-1,-1),rl_colors.HexColor("#e8f5ee")),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
        ("ALIGN",(1,0),(1,-1),"RIGHT"),
    ]))
    story.append(sum_tbl)
    story.append(Spacer(1,3*mm))

    # ── 6. SUPERANNUATION (reg 3.46(l)) ──────────────────────────────────────
    super_pct = (emp.get("super_rate_override") or super_rate(current_fy())) * 100
    sup_rows = [
        [hdr("SUPERANNUATION"), hdr("FUND ABN"), hdr("MEMBER NO."),
         hdr("RATE"), hdr("THIS PERIOD")],
        [P(emp.get("super_fund_name","") or "—"),
         P(emp.get("super_fund_abn","")  or "—"),
         P(emp.get("super_member_number","") or "—"),
         P(f"{super_pct:.2f}%"),
         P(fmt(slip["super_amount"]),"right")],
    ]
    cw_sup = [W*0.36, W*0.22, W*0.18, W*0.10, W*0.14]
    sup_tbl = Table(sup_rows, colWidths=cw_sup)
    sup_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),rl_colors.HexColor("#1a6b3c")),
        ("BACKGROUND",(0,1),(-1,1),rl_colors.HexColor("#e8f5ee")),
        ("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#b8ddc8")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#b8ddc8")),
        ("ALIGN",(4,0),(4,-1),"RIGHT"),
    ]))
    story.append(sup_tbl)
    story.append(Spacer(1,3*mm))

    # ── 7. YEAR-TO-DATE ───────────────────────────────────────────────────────
    ytd_rows = [
        [hdr("YEAR TO DATE"), hdr("GROSS"), hdr("PAYG TAX"),
         hdr("SUPER"), hdr("ALLOWANCES")],
        [P("Cumulative FY Total"),
         P(fmt(slip["ytd_gross"]),"right"),
         P(fmt(slip["ytd_tax"]),"right"),
         P(fmt(slip["ytd_super"]),"right"),
         P(fmt(emp.get("ytd_allowances",0)),"right")],
    ]
    ytd_tbl = Table(ytd_rows, colWidths=[W*0.28, W*0.19, W*0.19, W*0.17, W*0.17])
    ytd_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("BACKGROUND",(0,1),(-1,1),LTBLU),
        ("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
        ("ALIGN",(1,0),(-1,-1),"RIGHT"),
    ]))
    story.append(ytd_tbl)
    story.append(Spacer(1,3*mm))

    # ── 8. LEAVE BALANCES (Fair Work Act s536, NES) ───────────────────────────
    if leave_balances:
        hpd = float(emp.get("hours_per_week",38) or 38) / 5
        lv_rows = [[hdr("LEAVE BALANCES"), hdr("ACCRUED (hrs)"), hdr("TAKEN (hrs)"),
                    hdr("BALANCE (hrs)"), hdr("BALANCE (days)")]]
        for b in leave_balances:
            acc = (b.get("accrued_hours") or 0) + (b.get("adjustment_hours") or 0)
            tak = b.get("taken_hours") or 0
            bal = acc - tak
            lv_rows.append([
                P(b.get("type_name","") or b.get("code","")),
                P(f"{acc:.2f}","right"),
                P(f"{tak:.2f}","right"),
                P(f"{bal:.2f}","right"),
                P(hours_to_days(bal,hpd),"right"),
            ])
        lv_tbl = Table(lv_rows,
                        colWidths=[W*0.36, W*0.16, W*0.16, W*0.18, W*0.14])
        lv_tbl.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0),rl_colors.HexColor("#5d4e8c")),
            ("TOPPADDING",(0,0),(-1,0),4),("BOTTOMPADDING",(0,0),(-1,0),4),
            ("TOPPADDING",(0,1),(-1,-1),3),("BOTTOMPADDING",(0,1),(-1,-1),3),
            ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[WHITE,rl_colors.HexColor("#f3f0fa")]),
            ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#c8c0e8")),
            ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#d8d0f0")),
            ("ALIGN",(1,0),(-1,-1),"RIGHT"),
        ]))
        story.append(lv_tbl)
        story.append(Spacer(1,3*mm))

    # ── 9. BANK DETAILS ───────────────────────────────────────────────────────
    if emp.get("bank_bsb") or emp.get("bank_name"):
        parts = ["Payment to:"]
        if emp.get("bank_name"):    parts.append(emp["bank_name"])
        if emp.get("bank_bsb"):     parts.append(f"BSB {emp['bank_bsb']}")
        if emp.get("bank_account"): parts.append(f"Acct {emp['bank_account']}")
        story.append(P("  ".join(parts), "small"))
        story.append(Spacer(1,2*mm))

    # ── Footer ────────────────────────────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=0.5,
                             color=rl_colors.HexColor("#ccd0e0"), spaceAfter=2*mm))
    story.append(P(
        "This payslip is issued in accordance with the Fair Work Act 2009 (Cth) s536 "
        "and Fair Work Regulations 2009 reg 3.46. Retain for your records. "
        "Queries: contact your payroll administrator.", "label"))
    if watermark:
        story.append(Spacer(1, 1*mm))
        story.append(P(watermark, "label"))

    doc.build(story)
    return output_path


# ══════════════════════════════════════════════════════════════════════════════
#  PAY RUN REPORT PDF
# ══════════════════════════════════════════════════════════════════════════════

def generate_payrun_report_pdf(db_path, run_id: int,
                                output_path: str = None,
                                watermark: str = None, footer: str = None) -> str:
    """
    Generate a pay run summary report PDF — management/bookkeeping copy.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors as rl_colors
        from reportlab.lib.units import mm
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.enums import TA_RIGHT, TA_CENTER
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                         Table, TableStyle, HRFlowable,
                                         PageBreak)
    except ImportError:
        raise ImportError("reportlab not installed. Run: pip install reportlab")

    import tempfile
    conn = get_connection(db_path)
    run   = conn.execute("SELECT * FROM pay_runs WHERE id=?", (run_id,)).fetchone()
    if not run:
        conn.close()
        raise ValueError(f"Pay run {run_id} not found")
    run = dict(run)

    slips = conn.execute("""
        SELECT ps.*, e.first_name, e.last_name, e.employee_number,
               e.position_title, e.employment_type, e.super_fund_name,
               e.super_member_number, e.super_fund_abn
        FROM payslips ps
        JOIN employees e ON ps.employee_id = e.id
        WHERE ps.pay_run_id = ?
        ORDER BY e.last_name, e.first_name""", (run_id,)).fetchall()
    slips = [dict(s) for s in slips]

    company = conn.execute("SELECT * FROM company").fetchone()
    co = dict(company) if company else {}

    # GL journal lines for this run
    journal_lines = []
    if run.get("journal_id"):
        journal_lines = conn.execute("""
            SELECT jl.*, a.code AS acc_code, a.name AS acc_name
            FROM journal_lines jl
            JOIN accounts a ON a.id = jl.account_id
            WHERE jl.journal_id = ?
            ORDER BY jl.debit DESC""", (run["journal_id"],)).fetchall()
        journal_lines = [dict(j) for j in journal_lines]
    conn.close()

    if output_path is None:
        output_path = os.path.join(tempfile.mkdtemp(),
            f"payrun_report_{run['run_number']}_{run['payment_date']}.pdf")

    # ── Styles ────────────────────────────────────────────────────────────────
    from core.invoice_pdf import _resolve_theme, _c, _load_doc_theme
    _th   = _resolve_theme(_load_doc_theme(co))
    NAVY  = _c(_th["header_bg"])
    BLUE  = _c(_th["accent_bar"])
    LTGR  = _c(_th["row_alt"])
    LTBLU = _c(_th["payment_box_bg"])
    WHITE = rl_colors.white
    GREEN = rl_colors.HexColor("#27ae60")
    AMBER = rl_colors.HexColor("#e67e22")
    LGREY = _c(_th["dim_text"])
    DKGR  = _c(_th["dim_text"])

    def sty(name, **kw):
        d = dict(fontName="Helvetica", fontSize=9, leading=12,
                 textColor=_c(_th["body_text"]))
        d.update(kw)
        return ParagraphStyle(name, **d)

    S = {
        "title": sty("t",  fontName="Helvetica-Bold", fontSize=15, textColor=NAVY),
        "h2":    sty("h2", fontName="Helvetica-Bold", fontSize=10, textColor=NAVY),
        "label": sty("lb", fontSize=7,  textColor=LGREY, leading=9),
        "small": sty("sm", fontSize=7.5,textColor=DKGR),
        "body":  sty("bo"),
        "bold":  sty("bd", fontName="Helvetica-Bold"),
        "right": sty("ri", alignment=TA_RIGHT),
        "rbold": sty("rb", fontName="Helvetica-Bold", alignment=TA_RIGHT),
        "rgrn":  sty("rg", fontName="Helvetica-Bold", fontSize=10,
                     textColor=GREEN, alignment=TA_RIGHT),
        "ctr":   sty("ct", alignment=TA_CENTER),
        "amber": sty("am", fontName="Helvetica-Bold", textColor=AMBER),
    }

    def P(text, style="body"): return Paragraph(str(text or ""), S[style])
    def fmt(v):  return f"${float(v or 0):,.2f}"
    def fmth(v): return f"{float(v or 0):.2f}"
    def hdr(text, align="left"):
        st = "ct" if align == "center" else ("ri" if align == "right" else "label")
        return Paragraph(text, ParagraphStyle("hh",
            fontName="Helvetica-Bold", fontSize=7.5,
            textColor=WHITE, leading=10,
            alignment={"left":0,"center":1,"right":2}[align]))

    doc = SimpleDocTemplate(output_path, pagesize=A4,
                            leftMargin=14*mm, rightMargin=14*mm,
                            topMargin=12*mm, bottomMargin=12*mm)
    W = 182*mm
    story = []

    # ── HEADER ────────────────────────────────────────────────────────────────
    co_name = co.get("name","") or "Company"
    abn     = co.get("abn","")
    status_colour = GREEN if run["status"] == "Finalised" else AMBER

    co_lines = [P(co_name, "h2")]
    if abn: co_lines.append(P(f"ABN: {abn}", "small"))

    co_tbl = Table([[c] for c in co_lines], colWidths=[90*mm])
    co_tbl.setStyle(TableStyle([
        ("TOPPADDING",(0,0),(-1,-1),1),("BOTTOMPADDING",(0,0),(-1,-1),1),
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
    ]))

    title_tbl = Table([[co_tbl, P("PAY RUN REPORT", "title")]], colWidths=[90*mm, 92*mm])
    title_tbl.setStyle(TableStyle([
        ("VALIGN",(0,0),(-1,-1),"TOP"),
        ("ALIGN",(1,0),(1,0),"RIGHT"),
    ]))
    story.append(title_tbl)
    story.append(HRFlowable(width="100%", thickness=2, color=BLUE, spaceAfter=3*mm))

    # ── RUN SUMMARY BOX ───────────────────────────────────────────────────────
    status_lbl = Paragraph(run["status"],
        ParagraphStyle("sl", fontName="Helvetica-Bold", fontSize=9,
                       textColor=status_colour))

    sum_data = [
        [P("RUN NUMBER","label"), P("PERIOD","label"),
         P("PAYMENT DATE","label"), P("FREQUENCY","label"), P("STATUS","label")],
        [P(run["run_number"],"bold"),
         P(f"{run['pay_period_start']}  to  {run['pay_period_end']}","bold"),
         P(run["payment_date"],"bold"),
         P(run["frequency"]),
         status_lbl],
    ]
    sum_tbl = Table(sum_data, colWidths=[W*0.16, W*0.34, W*0.20, W*0.16, W*0.14])
    sum_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),LTGR),
        ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#ccd0e0")),
    ]))
    story.append(sum_tbl)
    story.append(Spacer(1,4*mm))

    # ── TOTALS BANNER ─────────────────────────────────────────────────────────
    n_emp = len(slips)
    tot_gross = sum(s["gross_pay"]    for s in slips)
    tot_ord   = sum(s["ordinary_gross"] for s in slips)
    tot_ot    = sum(s["overtime_gross"] for s in slips)
    tot_leave = sum(s.get("leave_gross",0) for s in slips)
    tot_allow = sum(s.get("allowances",0) for s in slips)
    tot_payg  = sum(s["payg_tax"]     for s in slips)
    tot_super = sum(s["super_amount"] for s in slips)
    tot_sal   = sum(s.get("salary_sacrifice",0) for s in slips)
    tot_net   = sum(s["net_pay"]      for s in slips)

    banner_data = [
        [hdr("EMPLOYEES"), hdr("GROSS PAY","right"), hdr("PAYG WITHHELD","right"),
         hdr("SUPER (SGC)","right"), hdr("NET PAY","right")],
        [P(str(n_emp),"bold"), P(fmt(tot_gross),"rbold"),
         P(fmt(tot_payg),"rbold"), P(fmt(tot_super),"rbold"),
         P(fmt(tot_net),"rgrn")],
    ]
    ban_tbl = Table(banner_data, colWidths=[W*0.14, W*0.22, W*0.22, W*0.20, W*0.22])
    ban_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("BACKGROUND",(0,1),(-1,1),LTBLU),
        ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
        ("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#ccd0e0")),
    ]))
    story.append(ban_tbl)
    story.append(Spacer(1,3*mm))

    earn_break = [
        [P("Ordinary Time","small"), P(fmt(tot_ord),"right")],
        [P("Overtime","small"),      P(fmt(tot_ot),"right")],
        [P("Leave","small"),         P(fmt(tot_leave),"right")],
        [P("Allowances","small"),    P(fmt(tot_allow),"right")],
        [P("Salary Sacrifice","small"), P(f"({fmt(tot_sal)})","right")],
    ]
    eb_tbl = Table(earn_break, colWidths=[W*0.25, W*0.15])
    eb_tbl.setStyle(TableStyle([
        ("TOPPADDING",(0,0),(-1,-1),2),("BOTTOMPADDING",(0,0),(-1,-1),2),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("ROWBACKGROUNDS",(0,0),(-1,-1),[WHITE, LTGR]),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
        ("ALIGN",(1,0),(1,-1),"RIGHT"),
    ]))
    story.append(P("Earnings Breakdown","label"))
    story.append(Spacer(1,1*mm))
    story.append(eb_tbl)
    story.append(Spacer(1,5*mm))

    # ── EMPLOYEE DETAIL TABLE ─────────────────────────────────────────────────
    story.append(P("Employee Detail", "h2"))
    story.append(Spacer(1,2*mm))

    det_rows = [
        [hdr("EMPLOYEE"), hdr("TYPE"), hdr("ORD HRS","right"),
         hdr("OT HRS","right"), hdr("GROSS","right"),
         hdr("PAYG","right"), hdr("SUPER","right"),
         hdr("NET","right"), hdr("STATUS")]
    ]
    for i, s in enumerate(slips):
        name = f"{s['last_name']}, {s['first_name']}"
        det_rows.append([
            P(name),
            P(s.get("employment_type","") or "", "small"),
            P(fmth(s["ordinary_hours"]), "right"),
            P(fmth(s["overtime_hours"]), "right"),
            P(fmt(s["gross_pay"]),    "right"),
            P(fmt(s["payg_tax"]),     "right"),
            P(fmt(s["super_amount"]),"right"),
            P(fmt(s["net_pay"]),      "right"),
            P(s.get("status",""),    "small"),
        ])

    det_rows.append([
        P("TOTAL","bold"), P(""),
        P(fmth(sum(s["ordinary_hours"] for s in slips)),"rbold"),
        P(fmth(sum(s["overtime_hours"] for s in slips)),"rbold"),
        P(fmt(tot_gross),"rbold"),
        P(fmt(tot_payg),"rbold"),
        P(fmt(tot_super),"rbold"),
        P(fmt(tot_net),"rgrn"),
        P(""),
    ])

    cw_det = [W*0.22,W*0.09,W*0.08,W*0.07,W*0.11,W*0.10,W*0.10,W*0.11,W*0.08]
    det_tbl = Table(det_rows, colWidths=cw_det)
    det_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("TOPPADDING",(0,0),(-1,0),4),("BOTTOMPADDING",(0,0),(-1,0),4),
        ("TOPPADDING",(0,1),(-1,-1),3),("BOTTOMPADDING",(0,1),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),
        ("ROWBACKGROUNDS",(0,1),(-1,-2),[WHITE,LTGR]),
        ("BACKGROUND",(0,-1),(-1,-1),LTBLU),
        ("LINEABOVE",(0,-1),(-1,-1),1,BLUE),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
        ("ALIGN",(2,0),(-1,-1),"RIGHT"),
        ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
    ]))
    story.append(det_tbl)
    story.append(Spacer(1,5*mm))

    # ── SUPERANNUATION SCHEDULE ───────────────────────────────────────────────
    story.append(P("Superannuation Schedule", "h2"))
    story.append(Spacer(1,2*mm))

    super_rows = [
        [hdr("EMPLOYEE"), hdr("FUND NAME"), hdr("FUND ABN"),
         hdr("MEMBER NO."), hdr("AMOUNT","right")]
    ]
    super_total = 0.0
    for s in slips:
        name = f"{s['last_name']}, {s['first_name']}"
        super_rows.append([
            P(name),
            P(s.get("super_fund_name","") or "—", "small"),
            P(s.get("super_fund_abn","")  or "—", "small"),
            P(s.get("super_member_number","") or "—", "small"),
            P(fmt(s["super_amount"]), "right"),
        ])
        super_total += float(s["super_amount"] or 0)
    super_rows.append([P("TOTAL","bold"), P(""), P(""), P(""),
                        P(fmt(super_total),"rbold")])

    cw_sup = [W*0.22, W*0.30, W*0.20, W*0.16, W*0.12]
    sup_tbl = Table(super_rows, colWidths=cw_sup)
    sup_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),rl_colors.HexColor("#1a6b3c")),
        ("TOPPADDING",(0,0),(-1,0),4),("BOTTOMPADDING",(0,0),(-1,0),4),
        ("TOPPADDING",(0,1),(-1,-1),3),("BOTTOMPADDING",(0,1),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),
        ("ROWBACKGROUNDS",(0,1),(-1,-2),[WHITE, rl_colors.HexColor("#e8f5ee")]),
        ("BACKGROUND",(0,-1),(-1,-1),rl_colors.HexColor("#d4edda")),
        ("LINEABOVE",(0,-1),(-1,-1),1,GREEN),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#b8ddc8")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#b8ddc8")),
        ("ALIGN",(4,0),(4,-1),"RIGHT"),
    ]))
    story.append(sup_tbl)
    story.append(Spacer(1,5*mm))

    # ── GL JOURNAL POSTING ────────────────────────────────────────────────────
    story.append(P("General Ledger Journal", "h2"))
    if run.get("journal_id"):
        story.append(P(f"Journal #{run['journal_id']}  •  Posted {run['payment_date']}",
                       "small"))
    story.append(Spacer(1,2*mm))

    if journal_lines:
        gl_rows = [
            [hdr("ACCOUNT CODE"), hdr("ACCOUNT NAME"),
             hdr("DEBIT","right"), hdr("CREDIT","right")]
        ]
        for jl in journal_lines:
            gl_rows.append([
                P(jl.get("acc_code",""), "small"),
                P(jl.get("acc_name",""), "small"),
                P(fmt(jl["debit"])  if jl["debit"]  else "", "right"),
                P(fmt(jl["credit"]) if jl["credit"] else "", "right"),
            ])
        tot_dr = sum(j["debit"]  or 0 for j in journal_lines)
        tot_cr = sum(j["credit"] or 0 for j in journal_lines)
        gl_rows.append([
            P(""), P("TOTAL","bold"),
            P(fmt(tot_dr),"rbold"), P(fmt(tot_cr),"rbold"),
        ])
        cw_gl = [W*0.14, W*0.54, W*0.16, W*0.16]
        gl_tbl = Table(gl_rows, colWidths=cw_gl)
        gl_tbl.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0),NAVY),
            ("TOPPADDING",(0,0),(-1,0),4),("BOTTOMPADDING",(0,0),(-1,0),4),
            ("TOPPADDING",(0,1),(-1,-1),3),("BOTTOMPADDING",(0,1),(-1,-1),3),
            ("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),
            ("ROWBACKGROUNDS",(0,1),(-1,-2),[WHITE,LTGR]),
            ("BACKGROUND",(0,-1),(-1,-1),LTBLU),
            ("LINEABOVE",(0,-1),(-1,-1),1,BLUE),
            ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
            ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
            ("ALIGN",(2,0),(3,-1),"RIGHT"),
        ]))
        story.append(gl_tbl)
    else:
        story.append(P("No journal posted for this pay run. "
                       "Finalise the pay run to generate GL entries.", "small"))

    story.append(Spacer(1,5*mm))

    # ── FOOTER ────────────────────────────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=0.5,
                             color=rl_colors.HexColor("#ccd0e0"), spaceAfter=2*mm))
    from datetime import datetime as _dt
    story.append(P(
        f"Generated {_dt.now().strftime('%d/%m/%Y %H:%M')}  •  {co_name}"
        + (f"  •  ABN {abn}" if abn else "")
        + "  •  CONFIDENTIAL — Payroll report for authorised personnel only.",
        "label"))

    if watermark:
        story.insert(0, Spacer(1, 2*mm))
        story.insert(0, P(watermark, "label"))

    doc.build(story)
    return output_path


# ══════════════════════════════════════════════════════════════════════════════
#  SUPER REMITTANCE ADVICE PDF
# ══════════════════════════════════════════════════════════════════════════════

def generate_super_remittance_pdf(db_path, payment_id: int,
                                   output_path: str = None) -> str:
    """
    Generate a SuperStream-style remittance advice PDF for a super payment batch.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors as rl_colors
        from reportlab.lib.units import mm
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.enums import TA_RIGHT
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                         Table, TableStyle, HRFlowable)
    except ImportError:
        raise ImportError("reportlab not installed.")

    import tempfile
    pmt, lines = get_super_payment(db_path, payment_id)
    if not pmt:
        raise ValueError(f"Super payment {payment_id} not found")

    conn = get_connection(db_path)
    company = conn.execute("SELECT * FROM company").fetchone()
    co = dict(company) if company else {}
    conn.close()

    if output_path is None:
        output_path = os.path.join(tempfile.mkdtemp(),
            f"super_remittance_{pmt['payment_number']}.pdf")

    from core.invoice_pdf import _resolve_theme, _c, _load_doc_theme
    _th   = _resolve_theme(_load_doc_theme(co))
    NAVY  = _c(_th["header_bg"])
    BLUE  = _c(_th["accent_bar"])
    GREEN = rl_colors.HexColor("#27ae60")
    LTGR  = _c(_th["row_alt"])
    LTGRN = rl_colors.HexColor("#e8f5ee")
    WHITE = rl_colors.white
    LGREY = _c(_th["dim_text"])
    AMBER = rl_colors.HexColor("#e67e22")

    def sty(name, **kw):
        d = dict(fontName="Helvetica", fontSize=9, leading=12,
                 textColor=_c(_th["body_text"]))
        d.update(kw); return ParagraphStyle(name, **d)

    S = {
        "title": sty("t",  fontName="Helvetica-Bold", fontSize=15, textColor=NAVY),
        "h2":    sty("h2", fontName="Helvetica-Bold", fontSize=10, textColor=NAVY),
        "label": sty("lb", fontSize=7,  textColor=LGREY, leading=9),
        "small": sty("sm", fontSize=7.5, textColor=LGREY),
        "body":  sty("bo"),
        "bold":  sty("bd", fontName="Helvetica-Bold"),
        "right": sty("ri", fontSize=8, leading=10, alignment=TA_RIGHT),
        "rbold": sty("rb", fontName="Helvetica-Bold", fontSize=8, leading=10, alignment=TA_RIGHT),
        "rgrn":  sty("rg", fontName="Helvetica-Bold", fontSize=8, leading=10,
                     textColor=GREEN, alignment=TA_RIGHT),
    }

    def P(text, style="body"): return Paragraph(str(text or ""), S[style])
    def fmt(v): return f"${float(v or 0):,.2f}"
    def _fmt_quarter(q):
        try:
            year, qnum = q.split("-")
            year = int(year)
            q_labels = {
                "Q1": f"Q1 {year}-{str(year+1)[-2:]}",
                "Q2": f"Q2 {year}-{str(year+1)[-2:]}",
                "Q3": f"Q3 {year-1}-{str(year)[-2:]}",
                "Q4": f"Q4 {year-1}-{str(year)[-2:]}",
            }
            return q_labels.get(qnum, q)
        except Exception:
            return q or "—"
    def hdr(text, align="left"):
        return Paragraph(text, ParagraphStyle("hh",
            fontName="Helvetica-Bold", fontSize=7.5,
            textColor=WHITE, leading=10,
            alignment={"left":0,"right":2}.get(align,0)))

    def dhdr(text, align="left"):
        return Paragraph(text, ParagraphStyle("dhh",
            fontName="Helvetica-Bold", fontSize=7,
            textColor=WHITE, leading=9,
            alignment={"left":0,"right":2}.get(align,0)))

    doc = SimpleDocTemplate(output_path, pagesize=A4,
                            leftMargin=14*mm, rightMargin=14*mm,
                            topMargin=12*mm, bottomMargin=12*mm)
    W = 182*mm
    story = []

    co_name = co.get("name","") or "Employer"
    abn     = co.get("abn","")
    co_block = [P(co_name, "h2")]
    if abn: co_block.append(P(f"ABN: {abn}", "small"))

    co_tbl = Table([[c] for c in co_block], colWidths=[90*mm])
    co_tbl.setStyle(TableStyle([
        ("TOPPADDING",(0,0),(-1,-1),1),("BOTTOMPADDING",(0,0),(-1,-1),1),
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
    ]))
    hdr_tbl = Table([[co_tbl, P("SUPERANNUATION\nREMITTANCE ADVICE","title")]],
                     colWidths=[90*mm, 92*mm])
    hdr_tbl.setStyle(TableStyle([
        ("VALIGN",(0,0),(-1,-1),"TOP"),("ALIGN",(1,0),(1,0),"RIGHT"),
    ]))
    story.append(hdr_tbl)
    story.append(HRFlowable(width="100%", thickness=2, color=GREEN, spaceAfter=3*mm))

    status_col = GREEN if pmt["status"] == "Paid" else AMBER
    status_lbl = Paragraph(pmt["status"],
        ParagraphStyle("sc", fontName="Helvetica-Bold", fontSize=9,
                       textColor=status_col))
    sum_data = [
        [P("PAYMENT NO.","label"), P("PAYMENT DATE","label"),
         P("QUARTER","label"),    P("DUE DATE","label"),
         P("METHOD","label"),     P("STATUS","label")],
        [P(pmt["payment_number"],"bold"), P(pmt["payment_date"],"bold"),
         P(_fmt_quarter(pmt["quarter"])), P(pmt["due_date"]),
         P(pmt.get("payment_method","SuperStream")), status_lbl],
    ]
    sum_tbl = Table(sum_data,
                    colWidths=[W*0.16,W*0.16,W*0.14,W*0.14,W*0.20,W*0.20])
    sum_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),LTGR),
        ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#ccd0e0")),
    ]))
    story.append(sum_tbl)
    story.append(Spacer(1,3*mm))

    ban_data = [
        [hdr("SGC (EMPLOYER)","right"), hdr("SALARY SACRIFICE","right"),
         hdr("VOLUNTARY","right"),       hdr("TOTAL","right")],
        [P(fmt(pmt["total_sgc"]),"rgrn"),
         P(fmt(pmt["total_salary_sacrifice"]),"rbold"),
         P(fmt(pmt["total_voluntary"]),"rbold"),
         P(fmt(pmt["total_amount"]),"rgrn")],
    ]
    ban_tbl = Table(ban_data, colWidths=[W*0.25]*4)
    ban_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),rl_colors.HexColor("#1a6b3c")),
        ("BACKGROUND",(0,1),(-1,1),LTGRN),
        ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
        ("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#b8ddc8")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#b8ddc8")),
    ]))
    story.append(ban_tbl)
    story.append(Spacer(1,4*mm))

    story.append(P("Employee Contribution Details", "h2"))
    story.append(Spacer(1,2*mm))

    det_rows = [
        [dhdr("EMPLOYEE"), dhdr("FUND NAME"), dhdr("FUND ABN"),
         dhdr("MEMBER NO."), dhdr("SGC","right"),
         dhdr("SAL. SAC.","right"), dhdr("VOLUNTARY","right"), dhdr("TOTAL","right")]
    ]
    for l in lines:
        name = f"{l.get('last_name','')}, {l.get('first_name','')}"
        det_rows.append([
            P(name),
            P(l.get("fund_name","") or "—", "small"),
            P(l.get("fund_abn","")  or "—", "small"),
            P(l.get("member_number","") or "—", "small"),
            P(fmt(l["sgc_amount"]),       "right"),
            P(fmt(l["salary_sacrifice"]), "right"),
            P(fmt(l["voluntary_amount"]), "right"),
            P(fmt(l["total_amount"]),     "right"),
        ])

    def Pamt(v, bold=False):
        return Paragraph(fmt(v), ParagraphStyle("amt",
            fontName="Helvetica-Bold" if bold else "Helvetica",
            fontSize=8, leading=10, alignment=2,
            textColor=GREEN if bold else rl_colors.HexColor("#1a1a2e")))

    det_rows.append([
        P("TOTAL","bold"), P(""), P(""), P(""),
        Pamt(pmt["total_sgc"], bold=True),
        Pamt(pmt["total_salary_sacrifice"]),
        Pamt(pmt["total_voluntary"]),
        Pamt(pmt["total_amount"], bold=True),
    ])

    cw_det = [W*0.17, W*0.165, W*0.13, W*0.11, W*0.105, W*0.105, W*0.105, W*0.11]
    det_tbl = Table(det_rows, colWidths=cw_det)
    det_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("TOPPADDING",(0,0),(-1,0),4),("BOTTOMPADDING",(0,0),(-1,0),4),
        ("TOPPADDING",(0,1),(-1,-1),3),("BOTTOMPADDING",(0,1),(-1,-1),3),
        ("LEFTPADDING",(0,0),(-1,-1),2),("RIGHTPADDING",(0,0),(-1,-1),2),
        ("ROWBACKGROUNDS",(0,1),(-1,-2),[WHITE, LTGR]),
        ("BACKGROUND",(0,-1),(-1,-1),LTGRN),
        ("LINEABOVE",(0,-1),(-1,-1),1,GREEN),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
        ("ALIGN",(4,0),(-1,-1),"RIGHT"),
    ]))
    story.append(det_tbl)
    story.append(Spacer(1,5*mm))

    if pmt.get("reference"):
        story.append(P(f"Payment Reference: {pmt['reference']}", "bold"))
        story.append(Spacer(1,2*mm))
    if pmt.get("notes"):
        story.append(P(f"Notes: {pmt['notes']}", "small"))
        story.append(Spacer(1,2*mm))

    story.append(HRFlowable(width="100%", thickness=0.5,
                             color=rl_colors.HexColor("#ccd0e0"), spaceAfter=2*mm))
    from datetime import datetime as _dt
    story.append(P(
        f"Generated {_dt.now().strftime('%d/%m/%Y %H:%M')}  •  {co_name}"
        + (f"  •  ABN {abn}" if abn else "")
        + "  •  SuperStream compliant remittance. Retain for your records.",
        "label"))

    doc.build(story)
    return output_path


# ══════════════════════════════════════════════════════════════════════════════
#  PAYG PAYMENT SUMMARY PDF
# ══════════════════════════════════════════════════════════════════════════════

def render_payg_summary_pdf(db_path: str, financial_year: int,
                              employee_ids: list = None,
                              out_path: str = None) -> str:
    """
    Render ATO-style PAYG Payment Summary report for all employees.
    One record per employee per page (or compact multi-employee layout).
    Returns out_path.
    """
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors as rl_colors
    from reportlab.lib.units import mm
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_RIGHT, TA_CENTER, TA_LEFT
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                     Table, TableStyle, HRFlowable,
                                     PageBreak, KeepTogether)
    from core.database import get_connection as _gc
    import tempfile, datetime as _dt

    if out_path is None:
        out_path = tempfile.mktemp(suffix="_payg_summary.pdf")

    conn = _gc(db_path)
    co   = dict(conn.execute("SELECT * FROM company").fetchone() or {})
    conn.close()

    summaries = get_payg_summary(db_path, financial_year)
    if employee_ids:
        summaries = [s for s in summaries if s["employee_id"] in employee_ids]
    if not summaries:
        raise ValueError("No payroll data found for selected period.")

    co_name = co.get("name", "") or "Employer"
    co_abn  = co.get("abn", "") or ""
    co_addr = co.get("address", "") or ""
    fy_label = f"{financial_year-1}–{financial_year}"

    from core.invoice_pdf import _resolve_theme, _c, _load_doc_theme
    _th    = _resolve_theme(_load_doc_theme(co))
    NAVY   = _c(_th["header_bg"])
    RED    = rl_colors.HexColor("#c0392b")
    LTGR   = _c(_th["row_alt"])
    LTRED  = rl_colors.HexColor("#fdf0f0")
    WHITE  = rl_colors.white
    DIM    = _c(_th["dim_text"])
    BLACK  = rl_colors.black
    GOLD   = rl_colors.HexColor("#f39c12")

    W = 174*mm

    def sty(name, **kw):
        d = dict(fontName="Helvetica", fontSize=9, leading=13,
                 textColor=_c(_th["body_text"]))
        d.update(kw)
        return ParagraphStyle(name, **d)

    def P(txt, s="body"):
        _s = {
            "body":   sty("b"),
            "bold":   sty("bd", fontName="Helvetica-Bold"),
            "right":  sty("r",  alignment=TA_RIGHT),
            "rbold":  sty("rb", fontName="Helvetica-Bold", alignment=TA_RIGHT),
            "center": sty("c",  alignment=TA_CENTER),
            "cbold":  sty("cb", fontName="Helvetica-Bold", alignment=TA_CENTER),
            "hdr":    sty("hh", fontName="Helvetica-Bold", fontSize=9, textColor=WHITE),
            "dim":    sty("dm", textColor=DIM, fontSize=7.5),
            "title":  sty("ti", fontName="Helvetica-Bold", fontSize=13, textColor=NAVY),
            "red":    sty("rd", fontName="Helvetica-Bold", textColor=RED),
            "small":  sty("sm", fontSize=8),
            "label":  sty("lb", fontSize=8, textColor=DIM),
        }
        return Paragraph(str(txt or ""), _s.get(s, _s["body"]))

    def money(v):
        v = float(v or 0)
        return P(f"${v:,.2f}", "rbold")

    doc = SimpleDocTemplate(out_path, pagesize=A4,
                             leftMargin=15*mm, rightMargin=15*mm,
                             topMargin=12*mm, bottomMargin=12*mm)
    story = []

    for idx, emp in enumerate(summaries):
        if idx > 0:
            story.append(PageBreak())

        block = []

        ato_hdr = Table([[
            Paragraph(f"<b>PAYG PAYMENT SUMMARY — INDIVIDUAL NON-BUSINESS</b>",
                      sty("ah", fontName="Helvetica-Bold", fontSize=11,
                          textColor=WHITE, alignment=TA_CENTER)),
            Paragraph(f"Financial Year: <b>{fy_label}</b>",
                      sty("fy", fontName="Helvetica-Bold", fontSize=10,
                          textColor=WHITE, alignment=TA_RIGHT)),
        ]], colWidths=[W*0.7, W*0.3])
        ato_hdr.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), RED),
            ("TOPPADDING",    (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ("LEFTPADDING",   (0, 0), (-1, -1), 10),
            ("RIGHTPADDING",  (0, 0), (-1, -1), 10),
        ]))
        block.append(ato_hdr)
        block.append(Spacer(1, 3*mm))

        emp_boxes = Table([[
            Table([
                [P("PAYER (EMPLOYER)", "label")],
                [P(f"<b>{co_name}</b>", "bold")],
                [P(f"ABN: {co_abn}" if co_abn else "ABN: —")],
                [P(co_addr or "", "small")],
            ], colWidths=[W*0.48]),
            Table([
                [P("PAYEE (EMPLOYEE)", "label")],
                [P(f"<b>{emp['employee_name']}</b>", "bold")],
                [P(f"TFN: {emp['tfn']}")],
                [P(emp.get("address") or "", "small")],
            ], colWidths=[W*0.48]),
        ]], colWidths=[W*0.5, W*0.5])
        emp_boxes.setStyle(TableStyle([
            ("BACKGROUND",    (0, 0), (0, 0), LTGR),
            ("BACKGROUND",    (1, 0), (1, 0), LTRED),
            ("TOPPADDING",    (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ("LEFTPADDING",   (0, 0), (-1, -1), 10),
            ("RIGHTPADDING",  (0, 0), (-1, -1), 10),
            ("VALIGN",        (0, 0), (-1, -1), "TOP"),
            ("BOX",           (0, 0), (-1, -1), 0.5,
             rl_colors.HexColor("#ccd0e0")),
            ("LINEABOVE",     (1, 0), (1, 0), 0.5,
             rl_colors.HexColor("#ccd0e0")),
        ]))
        block.append(emp_boxes)
        block.append(Spacer(1, 4*mm))

        def field_row(label_txt, amount, highlight=False):
            bg = LTRED if highlight else WHITE
            return [
                Table([[P(label_txt, "body")]], colWidths=[W*0.65]),
                Table([[money(amount)]], colWidths=[W*0.3]),
            ]

        fig_rows = [
            [P("INCOME / DEDUCTIONS", "hdr"), P("AMOUNT", "hdr")],
            field_row("1. Gross payments (wages, salary, allowances)", emp["gross_wages"]),
            field_row("2. Total tax withheld (PAYG)",                  emp["payg_withheld"], highlight=True),
            field_row("3. Employer super contributions (SGC)",          emp["super_employer"]),
            field_row("4. Reportable employer super (salary sacrifice)", emp["salary_sacrifice_super"]),
            field_row("5. Total allowances",                            emp["allowances_total"]),
            field_row("6. Lump sum A (redundancy / unused leave)",      emp["lump_sum_a"]),
            field_row("7. Lump sum B (unused pre-Aug 1993 leave)",      emp["lump_sum_b"]),
            field_row("8. Lump sum D (tax-free redundancy)",            emp["lump_sum_d"]),
            field_row("9. Lump sum E (back payments)",                  emp["lump_sum_e"]),
            field_row("10. Reportable fringe benefits (>$2,000)",       emp["reportable_fringe_benefits"]),
            field_row("11. CDEP payments",                              emp["cdep_payments"]),
        ]

        fig_tbl = Table(fig_rows, colWidths=[W*0.7, W*0.3])
        fig_tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0, 0), (-1, 0),   NAVY),
            ("ROWBACKGROUNDS",(0, 1), (-1, -1),  [WHITE, LTGR]),
            ("BACKGROUND",    (0, 2), (-1, 2),   LTRED),
            ("TOPPADDING",    (0, 0), (-1, -1),  4),
            ("BOTTOMPADDING", (0, 0), (-1, -1),  4),
            ("LEFTPADDING",   (0, 0), (-1, -1),  8),
            ("RIGHTPADDING",  (0, 0), (-1, -1),  8),
            ("BOX",           (0, 0), (-1, -1),  0.5,
             rl_colors.HexColor("#ccd0e0")),
            ("LINEABOVE",     (0, 1), (-1, 1),   0.5,
             rl_colors.HexColor("#ccd0e0")),
        ]))
        block.append(fig_tbl)

        if emp.get("allowances_breakdown"):
            block.append(Spacer(1, 3*mm))
            allow_rows = [[P("Allowances Breakdown", "hdr"), P("Amount", "hdr")]]
            for atype, amt in sorted(emp["allowances_breakdown"].items()):
                allow_rows.append([P(f"  {atype}"), money(amt)])
            at = Table(allow_rows, colWidths=[W*0.7, W*0.3])
            at.setStyle(TableStyle([
                ("BACKGROUND",    (0, 0), (-1, 0),  NAVY),
                ("ROWBACKGROUNDS",(0, 1), (-1, -1), [WHITE, LTGR]),
                ("TOPPADDING",    (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ("LEFTPADDING",   (0, 0), (-1, -1), 8),
                ("BOX",           (0, 0), (-1, -1), 0.5,
                 rl_colors.HexColor("#ccd0e0")),
            ]))
            block.append(at)

        block.append(Spacer(1, 5*mm))

        cert = Table([[
            Paragraph(
                "<b>PAYER DECLARATION:</b> I declare that the information on this "
                "payment summary is correct and that withholding amounts have been "
                "paid to the Australian Taxation Office.",
                sty("cert", fontSize=8, leading=11)),
        ]], colWidths=[W])
        cert.setStyle(TableStyle([
            ("BACKGROUND",    (0, 0), (-1, -1), LTGR),
            ("TOPPADDING",    (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ("LEFTPADDING",   (0, 0), (-1, -1), 10),
            ("BOX",           (0, 0), (-1, -1), 0.5,
             rl_colors.HexColor("#ccd0e0")),
        ]))
        block.append(cert)

        block.append(Spacer(1, 4*mm))
        block.append(P(
            f"Generated {_dt.datetime.now().strftime('%d/%m/%Y %H:%M')}  "
            f"•  {co_name}  •  NOT AN ATO FORM — for reference only",
            "dim"))

        story.append(KeepTogether(block))

    doc.build(story)
    return out_path


# ══════════════════════════════════════════════════════════════════════════════
#  OUTSTANDING LEAVE REPORTS
# ══════════════════════════════════════════════════════════════════════════════

def generate_outstanding_leave_csv(db_path, output_path: str = None) -> str:
    """
    Export outstanding leave balances for all active employees as CSV.
    Returns the path to the written file.
    """
    import csv, tempfile, os
    from core.leave import hours_to_days

    rows = _get_all_leave_balances(db_path)

    if not output_path:
        fd, output_path = tempfile.mkstemp(suffix=".csv", prefix="leave_balances_")
        os.close(fd)

    NES = {"ANN", "LSL", "SIC"}
    rows = [r for r in rows
            if r["code"] in NES or r["balance_hours"] != 0]

    with open(output_path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow([
            "Employee Number", "Last Name", "First Name", "Employment Type",
            "Leave Type", "Leave Code", "Paid",
            "Accrued (hrs)", "Taken (hrs)", "Adjustment (hrs)",
            "Balance (hrs)", "Balance (days)",
        ])
        hpw = {}
        for r in rows:
            emp_id = r["employee_id"]
            if emp_id not in hpw:
                hpw[emp_id] = float(r.get("hours_per_week") or 38)
            hpd = hpw[emp_id] / 5
            bal = r["balance_hours"]
            days_str = hours_to_days(bal, hpd)
            try:
                days_val = float(days_str.split()[0])
            except Exception:
                days_val = round(bal / hpd, 2) if hpd else ""
            writer.writerow([
                r["employee_number"],
                r["last_name"],
                r["first_name"],
                r["employment_type"] or "",
                r["type_name"],
                r["code"],
                "Yes" if r["paid"] else "No",
                f"{r['accrued_hours']:.2f}",
                f"{r['taken_hours']:.2f}",
                f"{r['adjustment_hours']:.2f}",
                f"{bal:.2f}",
                f"{days_val:.2f}" if isinstance(days_val, float) else days_val,
            ])

    return output_path


def generate_outstanding_leave_pdf(db_path, output_path: str = None,
                                   watermark: str = None, footer: str = None) -> str:
    """
    Generate a PDF report of outstanding leave balances for all active employees.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors as rl_colors
        from reportlab.lib.units import mm
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.enums import TA_RIGHT, TA_CENTER
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                         Table, TableStyle, HRFlowable,
                                         PageBreak)
    except ImportError:
        raise ImportError("reportlab not installed. Run: pip install reportlab")

    import tempfile, os
    from datetime import date as _date
    from core.leave import hours_to_days
    from collections import defaultdict

    if not output_path:
        fd, output_path = tempfile.mkstemp(suffix=".pdf", prefix="leave_balances_")
        os.close(fd)

    from core.invoice_pdf import _resolve_theme, _c
    _th   = _resolve_theme(None)
    NAVY  = _c(_th["header_bg"])
    PURP  = _c(_th["accent_bar"])
    LTPUR = _c(_th["payment_box_bg"])
    BORD  = _c(_th["rule_colour"])
    IBORD = _c(_th["rule_colour"])
    WHITE = rl_colors.white
    LGREY = _c(_th["dim_text"])
    GREEN = rl_colors.HexColor("#27ae60")
    RED   = rl_colors.HexColor("#e74c3c")

    W, H = A4
    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        leftMargin=15*mm, rightMargin=15*mm,
        topMargin=18*mm,  bottomMargin=15*mm,
    )
    usable_w = W - 30*mm

    def sty(name, **kw):
        base = dict(fontName="Helvetica", fontSize=9,
                    leading=12, textColor=NAVY)
        base.update(kw)
        return ParagraphStyle(name, **base)

    styles = {
        "title":  sty("title",  fontSize=16, fontName="Helvetica-Bold",
                       textColor=NAVY),
        "sub":    sty("sub",    fontSize=9,  textColor=LGREY),
        "h2":     sty("h2",     fontSize=11, fontName="Helvetica-Bold",
                       textColor=PURP),
        "normal": sty("normal"),
        "right":  sty("right",  alignment=TA_RIGHT),
        "label":  sty("label",  fontSize=7.5, textColor=LGREY),
        "bold":   sty("bold",   fontName="Helvetica-Bold"),
        "hdr":    sty("hdr",    fontName="Helvetica-Bold", fontSize=8,
                       textColor=WHITE),
    }

    def P(text, style="normal", colour=None):
        s = styles[style]
        if colour:
            s = ParagraphStyle(style + "_c", parent=s, textColor=colour)
        return Paragraph(str(text), s)

    all_rows = _get_all_leave_balances(db_path)
    NES = {"ANN", "LSL", "SIC"}

    by_emp = defaultdict(list)
    emp_meta = {}
    for r in all_rows:
        eid = r["employee_id"]
        if eid not in emp_meta:
            emp_meta[eid] = r
        if r["code"] in NES or r["balance_hours"] != 0:
            by_emp[eid].append(r)

    story = []
    today = _date.today().strftime("%d %B %Y")

    story.append(P("Outstanding Leave Balances", "title"))
    story.append(Spacer(1, 2*mm))
    story.append(P(f"All active employees  ·  As at {today}", "sub"))
    if watermark:
        story.append(Spacer(1, 1*mm))
        story.append(P(f"Company: {watermark}", "sub"))
    story.append(Spacer(1, 5*mm))
    story.append(HRFlowable(width="100%", thickness=1, color=PURP,
                             spaceAfter=6*mm))

    col_widths = [usable_w * p for p in [0.34, 0.12, 0.14, 0.14, 0.14, 0.12]]

    for eid, balances in by_emp.items():
        meta = emp_meta[eid]
        hpd  = float(meta.get("hours_per_week") or 38) / 5
        name = f"{meta['first_name']} {meta['last_name']}"
        emp_no   = meta["employee_number"] or ""
        emp_type = meta["employment_type"] or ""

        story.append(P(f"{name}  <font color='#8892a4' size='8'>#{emp_no} · {emp_type}</font>",
                       "h2"))
        story.append(Spacer(1, 2*mm))

        tbl_data = [[
            P("Leave Type",    "hdr"),
            P("Code",          "hdr"),
            P("Accrued",       "hdr"),
            P("Taken",         "hdr"),
            P("Adjustment",    "hdr"),
            P("Balance",       "hdr"),
        ]]

        for b in balances:
            bal  = b["balance_hours"]
            days_str = hours_to_days(bal, hpd)
            try:
                days_val = float(days_str.split()[0])
                bal_label = f"{bal:.2f} h\n({days_val:.1f} d)"
            except Exception:
                bal_label = f"{bal:.2f} h"

            bal_colour = GREEN if bal > 0 else (RED if bal < 0 else LGREY)
            tbl_data.append([
                P(b["type_name"]),
                P(b["code"]),
                P(f"{b['accrued_hours']:.2f}", "right"),
                P(f"{b['taken_hours']:.2f}",   "right"),
                P(f"{b['adjustment_hours']:.2f}", "right"),
                P(bal_label, "right", colour=bal_colour),
            ])

        tbl = Table(tbl_data, colWidths=col_widths, repeatRows=1)
        tbl.setStyle(TableStyle([
            ("BACKGROUND",   (0, 0), (-1, 0), PURP),
            ("TOPPADDING",   (0, 0), (-1, 0), 4),
            ("BOTTOMPADDING",(0, 0), (-1, 0), 4),
            ("ROWBACKGROUNDS",(0, 1), (-1, -1), [WHITE, LTPUR]),
            ("TOPPADDING",   (0, 1), (-1, -1), 3),
            ("BOTTOMPADDING",(0, 1), (-1, -1), 3),
            ("LEFTPADDING",  (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("BOX",       (0, 0), (-1, -1), 0.5, BORD),
            ("INNERGRID", (0, 0), (-1, -1), 0.25, IBORD),
            ("ALIGN", (2, 0), (-1, -1), "RIGHT"),
            ("VALIGN",(0, 0), (-1, -1), "MIDDLE"),
        ]))
        story.append(tbl)
        story.append(Spacer(1, 6*mm))

    story.append(HRFlowable(width="100%", thickness=0.5,
                             color=rl_colors.HexColor("#ccd0e0"),
                             spaceAfter=2*mm))
    story.append(P(
        "Balance = Accrued + Adjustments − Taken.  "
        "NES leave types (Annual, Personal/Carer's, Long Service) are always shown.  "
        "Other types shown only where a non-zero balance exists.  "
        "Generated by dbox Accounting.", "label"))

    doc.build(story)
    return output_path


def generate_period_leave_report_pdf(requests: list,
                                      period_start: str, period_end: str,
                                      output_path: str = None,
                                      watermark: str = None) -> str:
    """
    Generate a PDF listing approved leave requests that overlap a pay period.
    requests: list of dicts as returned by get_leave_requests().
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors as rl_colors
        from reportlab.lib.units import mm
        from reportlab.lib.styles import ParagraphStyle
        from reportlab.lib.enums import TA_RIGHT
        from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                         Table, TableStyle, HRFlowable)
    except ImportError:
        raise ImportError("reportlab not installed. Run: pip install reportlab")

    import tempfile, os
    from datetime import date as _date

    if not output_path:
        fd, output_path = tempfile.mkstemp(suffix=".pdf", prefix="leave_report_")
        os.close(fd)

    from core.invoice_pdf import _resolve_theme, _c
    _th   = _resolve_theme(None)
    NAVY  = _c(_th["header_bg"])
    PURP  = _c(_th["accent_bar"])
    LTPUR = _c(_th["payment_box_bg"])
    BORD  = _c(_th["rule_colour"])
    IBORD = _c(_th["rule_colour"])
    WHITE = rl_colors.white
    LGREY = _c(_th["dim_text"])
    AMBER = rl_colors.HexColor("#e67e22")

    W, H = A4
    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        leftMargin=15*mm, rightMargin=15*mm,
        topMargin=18*mm,  bottomMargin=15*mm)
    usable_w = W - 30*mm

    def sty(name, **kw):
        base = dict(fontName="Helvetica", fontSize=9, leading=12, textColor=NAVY)
        base.update(kw)
        return ParagraphStyle(name, **base)

    styles = {
        "title":  sty("title",  fontSize=15, fontName="Helvetica-Bold"),
        "sub":    sty("sub",    fontSize=9,  textColor=LGREY),
        "normal": sty("normal"),
        "right":  sty("right",  alignment=TA_RIGHT),
        "hdr":    sty("hdr",    fontName="Helvetica-Bold", fontSize=8, textColor=WHITE),
        "label":  sty("label",  fontSize=7.5, textColor=LGREY),
        "warn":   sty("warn",   fontSize=9, textColor=AMBER, fontName="Helvetica-Bold"),
    }

    def P(text, style="normal"):
        return Paragraph(str(text), styles[style])

    story = []
    today = _date.today().strftime("%d %B %Y")

    story.append(P("Approved Leave — Pay Period Reference", "title"))
    story.append(Spacer(1, 2*mm))
    story.append(P(f"Period: {period_start}  to  {period_end}   ·   Generated: {today}", "sub"))
    if watermark:
        story.append(P(f"Company: {watermark}", "sub"))
    story.append(Spacer(1, 3*mm))
    story.append(P(
        "Leave is not applied automatically. Use the Adjust button on each "
        "affected employee in the pay run to enter leave hours before finalising.",
        "warn"))
    story.append(Spacer(1, 4*mm))
    story.append(HRFlowable(width="100%", thickness=1, color=PURP, spaceAfter=5*mm))

    col_widths = [usable_w * p for p in [0.26, 0.22, 0.13, 0.13, 0.10, 0.16]]
    rows = [[
        P("Employee",   "hdr"), P("Leave Type", "hdr"),
        P("From",       "hdr"), P("To",         "hdr"),
        P("Hours",      "hdr"), P("Status",      "hdr"),
    ]]
    for r in requests:
        rows.append([
            P(r.get("employee_name", "")),
            P(r.get("type_name", "")),
            P(r.get("start_date", "")),
            P(r.get("end_date", "")),
            P(f"{r.get('hours_requested', 0):.2f}", "right"),
            P(r.get("status", "")),
        ])

    tbl = Table(rows, colWidths=col_widths, repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, 0), PURP),
        ("TOPPADDING",    (0, 0), (-1, 0), 4),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 4),
        ("ROWBACKGROUNDS",(0, 1), (-1, -1), [WHITE, LTPUR]),
        ("TOPPADDING",    (0, 1), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 3),
        ("LEFTPADDING",   (0, 0), (-1, -1), 5),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 5),
        ("BOX",           (0, 0), (-1, -1), 0.5, BORD),
        ("INNERGRID",     (0, 0), (-1, -1), 0.25, IBORD),
        ("ALIGN",         (4, 0), (4, -1), "RIGHT"),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 6*mm))

    total_hrs = sum(r.get("hours_requested", 0) for r in requests)
    story.append(P(
        f"Total: {len(requests)} request{'s' if len(requests) != 1 else ''}  ·  "
        f"{total_hrs:.2f} hours across all employees", "sub"))
    story.append(Spacer(1, 4*mm))
    story.append(HRFlowable(width="100%", thickness=0.5,
                             color=rl_colors.HexColor("#ccd0e0"), spaceAfter=2*mm))
    story.append(P("Generated by dbox Accounting. For internal payroll use only.", "label"))

    doc.build(story)
    return output_path
