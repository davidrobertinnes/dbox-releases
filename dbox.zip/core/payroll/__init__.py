# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
core.payroll package — Australian STP Phase 2 compliant payroll engine.

This __init__.py re-exports every public name from the sub-modules so that all
existing ``from core.payroll import X`` callers continue to work unchanged.

Sub-module layout
-----------------
_shared.py       Constants and tiny helpers shared across sub-modules
withholding.py   ATO Schedule 1 coefficient tables, PAYG computation, DB rate storage
schema.py        migrate_payroll() — creates all payroll DB tables
employees.py     Employee CRUD
payrun.py        Pay run engine, payslip calculation, YTD, PAYG Payment Summary
super.py         Superannuation payment management
stp.py           STP Phase 2 XML generation and lodgement helpers
payslip_pdf.py   PDF/CSV generation (payslip, pay run report, super remittance, etc.)
"""

# ── Shared constants & simple helpers ────────────────────────────────────────
from core.payroll._shared import (
    SUPER_RATES,
    PAY_FREQUENCIES,
    MONTH_NAMES,
    EMPLOYMENT_TYPES,
    LEAVE_TYPES,
    ALLOWANCE_TYPES,
    super_rate,
    current_fy,
    _period_to_annual,
)

# ── PAYG withholding ──────────────────────────────────────────────────────────
from core.payroll.withholding import (
    # DB-backed rate storage
    load_payg_rates,
    save_payg_rates,
    list_payg_rate_years,
    # Public computation entry points
    compute_payg,
    payg_for_period,
    # Internal helpers (imported by payroll_ui.py and tax_estimate.py)
    _annual_tax_from_rates,
    _calc_gross_tax,
    _calc_medicare,
    _calc_lito,
    _calc_sapto,
    _calc_help_repayment,
    _get_rates,
    # Built-in rate constants (imported by payroll_ui.py)
    _BUILTIN_BRACKETS,
    _BUILTIN_BRACKETS_NO_THRESH,
    _BUILTIN_MEDICARE,
    _BUILTIN_LITO,
    _BUILTIN_LITO_NO_THRESH,
    _BUILTIN_HELP,
    _BUILTIN_SAPTO,
    # Coefficient tables (available for testing/inspection)
    _SCHED1_SCALE1_2526,
    _SCHED1_SCALE2_2526,
    _SCHED1_SCALE5_2526,
    _SCHED1_SCALE6_2526,
    _SCHED1_SCALE1_2627,
    _SCHED1_SCALE2_2627,
    _SCHED1_SCALE5_2627,
    _SCHED1_SCALE6_2627,
    _SCHED1_SCALE3,
)

# ── DB schema ─────────────────────────────────────────────────────────────────
from core.payroll.schema import migrate_payroll

# ── Employee CRUD ─────────────────────────────────────────────────────────────
from core.payroll.employees import (
    get_employees,
    get_employee,
    save_employee,
    next_employee_number,
)

# ── Pay run engine ────────────────────────────────────────────────────────────
from core.payroll.payrun import (
    next_run_number,
    calculate_payslip,
    create_pay_run,
    finalise_pay_run,
    void_pay_run,
    get_pay_runs,
    get_pay_run,
    get_payslips_for_employee,
    reset_ytd,
    get_payg_summary,
    get_payment_summary_data,
    _get_all_leave_balances,
    _post_payroll_journal,
)

# ── Superannuation payments ───────────────────────────────────────────────────
from core.payroll.super import (
    _super_quarter,
    next_super_payment_number,
    get_super_payments,
    get_super_payment,
    create_super_payment,
    finalise_super_payment,
    get_super_accruals,
    _post_super_payment_journal,
)

# ── STP Phase 2 ───────────────────────────────────────────────────────────────
from core.payroll.stp import (
    generate_stp_xml,
    lodge_stp,
    lodge_stp_finalisation,
    get_stp_submissions,
)

# ── PDF / CSV generation ──────────────────────────────────────────────────────
from core.payroll.payslip_pdf import (
    generate_payslip_pdf,
    generate_payrun_report_pdf,
    generate_super_remittance_pdf,
    render_payg_summary_pdf,
    generate_outstanding_leave_csv,
    generate_outstanding_leave_pdf,
    generate_period_leave_report_pdf,
)

__all__ = [
    # _shared
    "SUPER_RATES", "PAY_FREQUENCIES", "MONTH_NAMES", "EMPLOYMENT_TYPES",
    "LEAVE_TYPES", "ALLOWANCE_TYPES", "super_rate", "current_fy",
    "_period_to_annual",
    # withholding
    "load_payg_rates", "save_payg_rates", "list_payg_rate_years",
    "compute_payg", "payg_for_period",
    "_annual_tax_from_rates", "_calc_gross_tax", "_calc_medicare",
    "_calc_lito", "_calc_sapto", "_calc_help_repayment", "_get_rates",
    "_BUILTIN_BRACKETS", "_BUILTIN_BRACKETS_NO_THRESH", "_BUILTIN_MEDICARE",
    "_BUILTIN_LITO", "_BUILTIN_LITO_NO_THRESH", "_BUILTIN_HELP", "_BUILTIN_SAPTO",
    "_SCHED1_SCALE1_2526", "_SCHED1_SCALE2_2526",
    "_SCHED1_SCALE5_2526", "_SCHED1_SCALE6_2526",
    "_SCHED1_SCALE1_2627", "_SCHED1_SCALE2_2627",
    "_SCHED1_SCALE5_2627", "_SCHED1_SCALE6_2627",
    "_SCHED1_SCALE3",
    # schema
    "migrate_payroll",
    # employees
    "get_employees", "get_employee", "save_employee", "next_employee_number",
    # payrun
    "next_run_number", "calculate_payslip", "create_pay_run",
    "finalise_pay_run", "void_pay_run", "get_pay_runs", "get_pay_run",
    "get_payslips_for_employee", "reset_ytd",
    "get_payg_summary", "get_payment_summary_data",
    "_get_all_leave_balances", "_post_payroll_journal",
    # super
    "_super_quarter", "next_super_payment_number",
    "get_super_payments", "get_super_payment", "create_super_payment",
    "finalise_super_payment", "get_super_accruals", "_post_super_payment_journal",
    # stp
    "generate_stp_xml", "lodge_stp", "lodge_stp_finalisation",
    "get_stp_submissions",
    # pdf
    "generate_payslip_pdf", "generate_payrun_report_pdf",
    "generate_super_remittance_pdf", "render_payg_summary_pdf",
    "generate_outstanding_leave_csv", "generate_outstanding_leave_pdf",
    "generate_period_leave_report_pdf",
]
