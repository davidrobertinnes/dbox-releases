# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Employee CRUD — create, read, update employees.
"""

from core.database import get_connection


def get_employees(db_path, active_only=True):
    conn = get_connection(db_path)
    q = "SELECT * FROM employees"
    if active_only:
        q += " WHERE is_active=1"
    q += " ORDER BY last_name, first_name"
    rows = conn.execute(q).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_employee(db_path, emp_id):
    conn = get_connection(db_path)
    row = conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_employee(db_path, emp_data: dict) -> int:
    """Insert or update employee. Returns employee id."""
    conn = get_connection(db_path)
    emp_id = emp_data.get("id")
    # Apply defaults for NOT NULL fields
    defaults = {
        "employment_type": "Full-time", "pay_frequency": "Fortnightly",
        "hours_per_week": 38.0, "tfn_quoted": 1, "has_tax_free_threshold": 1,
        "study_loan": 0, "senior_offset": 0, "is_active": 1,
        "additional_withholding": 0.0, "salary_sacrifice_amount": 0.0,
        "voluntary_super_amount": 0.0,
    }
    for k, v in defaults.items():
        if emp_data.get(k) is None:
            emp_data[k] = v
    fields = [
        "employee_number","first_name","last_name","date_of_birth","gender",
        "address","city","state","postcode","email","phone",
        "employment_type","pay_frequency","start_date","termination_date",
        "position_title","department","annual_salary","hourly_rate","hours_per_week",
        "tfn","tfn_quoted","has_tax_free_threshold","study_loan","senior_offset",
        "additional_withholding","salary_sacrifice_amount","voluntary_super_amount",
        "super_fund_name","super_fund_abn","super_fund_usi","super_member_number",
        "super_rate_override","bank_bsb","bank_account","bank_name","is_active",
        "award_id","classification_id","pay_point",
        "pay_rate_modifier","pay_rate_modifier_type",
        "contact_id",
    ]
    vals = [emp_data.get(f) for f in fields]
    try:
        if emp_id:
            sets = ", ".join(f"{f}=?" for f in fields)
            conn.execute(f"UPDATE employees SET {sets} WHERE id=?", vals + [emp_id])
        else:
            cols = ", ".join(fields)
            placeholders = ", ".join("?" for _ in fields)
            conn.execute(f"INSERT INTO employees ({cols}) VALUES ({placeholders})", vals)
            emp_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.commit()
    finally:
        conn.close()
    return emp_id


def next_employee_number(db_path) -> str:
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT employee_number FROM employees ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    if row:
        try:
            n = int(row[0].lstrip("EMP").lstrip("0") or "0") + 1
        except ValueError:
            n = 1
    else:
        n = 1
    return f"EMP{n:04d}"
