# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Superannuation payment management — create/finalise super payment batches,
accrue super from pay runs, GL journal posting, remittance advice PDF.
"""

import json
from datetime import date

from core.database import get_connection


# ══════════════════════════════════════════════════════════════════════════════
#  QUARTER & NUMBERING HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _super_quarter(payment_date: str) -> tuple:
    """Return (quarter_label, due_date) for an SGC quarter."""
    from datetime import date as _date
    d = _date.fromisoformat(payment_date[:10])
    # SG quarters: Q1=Jul-Sep, Q2=Oct-Dec, Q3=Jan-Mar, Q4=Apr-Jun
    # Due 28 days after quarter end
    if d.month in (7, 8, 9):
        label = f"{d.year}-Q1"
        due   = _date(d.year, 10, 28)
    elif d.month in (10, 11, 12):
        label = f"{d.year}-Q2"
        due   = _date(d.year + 1, 1, 28)
    elif d.month in (1, 2, 3):
        label = f"{d.year}-Q3"
        due   = _date(d.year, 4, 28)
    else:
        label = f"{d.year}-Q4"
        due   = _date(d.year, 7, 28)
    return label, str(due)


def next_super_payment_number(db_path) -> str:
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT payment_number FROM super_payments ORDER BY id DESC LIMIT 1"
    ).fetchone()
    conn.close()
    prefix = f"SGC{date.today().year}"
    if row and row[0].startswith(prefix):
        try:
            seq = int(row[0][len(prefix):]) + 1
        except ValueError:
            seq = 1
    else:
        seq = 1
    return f"{prefix}{seq:04d}"


# ══════════════════════════════════════════════════════════════════════════════
#  SUPER PAYMENT CRUD
# ══════════════════════════════════════════════════════════════════════════════

def get_super_payments(db_path) -> list:
    conn = get_connection(db_path)
    rows = conn.execute(
        "SELECT * FROM super_payments ORDER BY payment_date DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_super_payment(db_path, payment_id: int) -> tuple:
    """Returns (payment_dict, [line_dicts_with_emp_name])."""
    conn = get_connection(db_path)
    pmt = conn.execute(
        "SELECT * FROM super_payments WHERE id=?", (payment_id,)
    ).fetchone()
    lines = conn.execute("""
        SELECT spl.*, e.first_name, e.last_name, e.employee_number
        FROM super_payment_lines spl
        JOIN employees e ON e.id = spl.employee_id
        WHERE spl.super_payment_id = ?
        ORDER BY e.last_name, e.first_name
    """, (payment_id,)).fetchall()
    conn.close()
    return (dict(pmt) if pmt else None), [dict(l) for l in lines]


def create_super_payment(db_path, payment_date: str, quarter: str,
                          due_date: str, lines: list,
                          payment_method: str = "SuperStream",
                          reference: str = None,
                          notes: str = None,
                          created_by: int = None) -> int:
    """
    Create a super payment batch.
    lines: list of dicts with keys:
        employee_id, fund_name, fund_abn, fund_usi, member_number,
        sgc_amount, salary_sacrifice, voluntary_amount, period_start, period_end,
        pay_run_ids (list of ints)
    Returns super_payment_id.
    """
    conn = get_connection(db_path)
    pmt_number = next_super_payment_number(db_path)

    total_sgc  = round(sum(l.get("sgc_amount", 0)       for l in lines), 2)
    total_sal  = round(sum(l.get("salary_sacrifice", 0)  for l in lines), 2)
    total_vol  = round(sum(l.get("voluntary_amount", 0)  for l in lines), 2)
    total      = round(total_sgc + total_sal + total_vol, 2)

    conn.execute("""INSERT INTO super_payments
        (payment_number, payment_date, quarter, due_date, status,
         payment_method, reference, total_sgc, total_salary_sacrifice,
         total_voluntary, total_amount, notes, created_by)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (pmt_number, payment_date, quarter, due_date, "Draft",
         payment_method, reference, total_sgc, total_sal,
         total_vol, total, notes, created_by))
    pmt_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    for l in lines:
        conn.execute("""INSERT INTO super_payment_lines
            (super_payment_id, employee_id, fund_name, fund_abn, fund_usi,
             member_number, sgc_amount, salary_sacrifice, voluntary_amount,
             total_amount, period_start, period_end, pay_run_ids)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (pmt_id, l["employee_id"],
             l.get("fund_name"), l.get("fund_abn"), l.get("fund_usi"),
             l.get("member_number"),
             l.get("sgc_amount", 0), l.get("salary_sacrifice", 0),
             l.get("voluntary_amount", 0),
             round(l.get("sgc_amount", 0) + l.get("salary_sacrifice", 0)
                   + l.get("voluntary_amount", 0), 2),
             l.get("period_start"), l.get("period_end"),
             json.dumps(l.get("pay_run_ids") or [])))

        # Reserve these payslips so they don't appear in future accrual queries
        run_ids_raw = l.get("pay_run_ids") or []
        if isinstance(run_ids_raw, str):
            run_ids = [int(x) for x in run_ids_raw.split(",") if x.strip().isdigit()]
        else:
            run_ids = [int(x) for x in run_ids_raw]
        if run_ids:
            ph = ",".join("?" * len(run_ids))
            conn.execute(
                f"""UPDATE payslips SET super_payment_batch_id = ?
                    WHERE employee_id = ? AND pay_run_id IN ({ph})
                      AND super_payment_batch_id IS NULL AND super_remitted = 0""",
                [pmt_id, l["employee_id"]] + run_ids,
            )

    conn.commit()
    conn.close()
    return pmt_id


def finalise_super_payment(db_path, payment_id: int,
                             post_journal: bool = True) -> None:
    """Mark super payment as Paid, stamp covered payslips, optionally post GL journal."""
    conn = get_connection(db_path)
    pmt = conn.execute(
        "SELECT * FROM super_payments WHERE id=?", (payment_id,)
    ).fetchone()
    if not pmt:
        conn.close()
        raise ValueError(f"Super payment {payment_id} not found")
    if dict(pmt)["status"] == "Paid":
        conn.close()
        raise ValueError("Super payment already marked Paid")

    conn.execute("UPDATE super_payments SET status='Paid' WHERE id=?", (payment_id,))

    # Mark all payslips covered by lines in this batch as remitted
    lines = conn.execute(
        "SELECT * FROM super_payment_lines WHERE super_payment_id=?", (payment_id,)
    ).fetchall()
    for line in lines:
        pay_run_ids_raw = dict(line).get("pay_run_ids") or ""
        emp_id          = dict(line)["employee_id"]
        # pay_run_ids stored as JSON array e.g. "[1, 2, 3]"
        run_ids = []
        try:
            import json as _json
            parsed = _json.loads(pay_run_ids_raw)
            if isinstance(parsed, list):
                run_ids = [int(x) for x in parsed if str(x).lstrip("-").isdigit()]
        except Exception:
            # fallback: comma-separated string
            run_ids = [int(x) for x in pay_run_ids_raw.split(",")
                       if x.strip().lstrip("-").isdigit()]
        if run_ids:
            ph = ",".join("?" * len(run_ids))
            conn.execute(f"""
                UPDATE payslips
                SET super_remitted = 1, super_payment_batch_id = ?
                WHERE employee_id = ? AND pay_run_id IN ({ph})
                  AND super_remitted = 0
            """, [payment_id, emp_id] + run_ids)

    conn.commit()
    conn.close()

    if post_journal:
        _post_super_payment_journal(db_path, payment_id)


def _post_super_payment_journal(db_path, payment_id: int):
    """Post GL journal: Dr Super Payable / Cr Bank (or Clearing)."""
    from core.ledger import post_journal as _post
    conn = get_connection(db_path)
    pmt   = dict(conn.execute(
        "SELECT * FROM super_payments WHERE id=?", (payment_id,)).fetchone())

    def acc(code):
        r = conn.execute("SELECT id FROM accounts WHERE code=?", (code,)).fetchone()
        return r["id"] if r else None

    super_payable = acc("2-1410")
    sal_sac_clear = acc("2-1420")
    vol_super     = acc("2-1440")
    bank_acc      = conn.execute(
        "SELECT id FROM accounts WHERE is_bank=1 ORDER BY id LIMIT 1"
    ).fetchone()
    bank_id = bank_acc["id"] if bank_acc else None
    conn.close()

    lines = []
    if pmt["total_sgc"] and super_payable:
        lines.append({"account_id": super_payable,
                      "debit": pmt["total_sgc"], "credit": 0})
    if pmt["total_salary_sacrifice"] and sal_sac_clear:
        lines.append({"account_id": sal_sac_clear,
                      "debit": pmt["total_salary_sacrifice"], "credit": 0})
    if pmt["total_voluntary"] and vol_super:
        lines.append({"account_id": vol_super,
                      "debit": pmt["total_voluntary"], "credit": 0})
    if bank_id and pmt["total_amount"]:
        lines.append({"account_id": bank_id,
                      "debit": 0, "credit": pmt["total_amount"]})

    if not lines:
        return
    jid = _post(db_path, pmt["payment_date"],
                f"Super Payment {pmt['payment_number']}",
                pmt["payment_number"], lines)
    conn = get_connection(db_path)
    conn.execute("UPDATE super_payments SET journal_id=? WHERE id=?",
                 (jid, payment_id))
    conn.commit()
    conn.close()


def get_super_accruals(db_path, from_date: str = None,
                        to_date: str = None) -> list:
    """
    Return unpaid (not yet remitted) super accruals from finalised pay runs,
    grouped by employee.  Payslips already covered by a paid super payment
    batch are excluded via the super_remitted flag.
    """
    conn = get_connection(db_path)
    where = "WHERE pr.status IN ('Finalised','STP_Lodged') AND ps.super_remitted = 0 AND ps.super_payment_batch_id IS NULL"
    params = []
    if from_date:
        where += " AND pr.pay_period_start >= ?"
        params.append(from_date)
    if to_date:
        where += " AND pr.pay_period_end <= ?"
        params.append(to_date)

    rows = conn.execute(f"""
        SELECT
            e.id AS employee_id,
            e.first_name, e.last_name, e.employee_number,
            e.super_fund_name, e.super_fund_abn, e.super_fund_usi,
            e.super_member_number,
            SUM(ps.super_amount)      AS sgc_total,
            SUM(ps.salary_sacrifice)  AS salary_sacrifice_total,
            MIN(pr.pay_period_start)  AS period_start,
            MAX(pr.pay_period_end)    AS period_end,
            GROUP_CONCAT(pr.id)       AS pay_run_ids,
            GROUP_CONCAT(ps.id)       AS payslip_ids
        FROM payslips ps
        JOIN pay_runs pr ON pr.id = ps.pay_run_id
        JOIN employees e ON e.id  = ps.employee_id
        {where}
        GROUP BY e.id
        ORDER BY e.last_name, e.first_name
    """, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]
