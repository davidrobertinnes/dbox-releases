# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Single Touch Payroll (STP) Phase 2 XML payload builder and lodgement helpers.
"""

import hashlib
import json
import xml.etree.ElementTree as ET
from datetime import datetime

from core.database import get_connection
from core.payroll._shared import current_fy
from core.payroll.payrun import get_pay_run
from core.payroll.employees import get_employee


def generate_stp_xml(db_path, run_id: int, abn: str,
                     bms_id: str = None, submission_type: str = "Update") -> str:
    """
    Generate STP Phase 2 compliant XML payload for the given pay run.
    submission_type: 'Update' (each pay event) or 'Finalisation' (end of FY)

    The XML structure follows ATO STP Phase 2 specification:
    https://softwaredevelopers.ato.gov.au/stp-phase2

    NOTE: This generates the payload XML. Actual lodgement requires
    authorised STP software with a valid Software ID (SSID) registered
    with the ATO, and transmission via the Business to Government (B2G)
    gateway. dbox generates the payload; actual lodgement must be done
    via a registered STP channel (e.g., SuperStream, tax agent gateway).
    """
    run, slips = get_pay_run(db_path, run_id)
    if not run:
        raise ValueError(f"Pay run {run_id} not found")

    conn = get_connection(db_path)
    company = conn.execute("SELECT * FROM company").fetchone()
    conn.close()
    co = dict(company) if company else {}
    abn = abn or co.get("abn","").replace(" ","")

    fy = current_fy()
    now_iso = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    bms_id = bms_id or f"dbox-{hashlib.md5(abn.encode()).hexdigest()[:8].upper()}"

    # XML namespaces (ATO STP Phase 2 spec)
    ns = {
        "pi":  "http://payevnt.ato.gov.au/payEvent",
        "emp": "http://payevnt.ato.gov.au/employee",
        "inc": "http://payevnt.ato.gov.au/income",
        "xsi": "http://www.w3.org/2001/XMLSchema-instance",
    }
    for prefix, uri in ns.items():
        ET.register_namespace(prefix, uri)

    root = ET.Element("{http://payevnt.ato.gov.au/payEvent}InteractionHeader")
    root.set("{http://www.w3.org/2001/XMLSchema-instance}schemaLocation",
             "http://payevnt.ato.gov.au/payEvent payevnt.xsd")

    def sub(parent, tag, text=None, **attribs):
        el = ET.SubElement(parent, tag, **attribs)
        if text is not None:
            el.text = str(text)
        return el

    # Header
    hdr = sub(root, "Header")
    sub(hdr, "CreatedTimestamp", now_iso)
    sub(hdr, "InteractionType",  "PAYEVNTEMP" if submission_type == "Update" else "PAYEVNTFINAL")
    sub(hdr, "SoftwareInformation").append(ET.fromstring(
        f"<BMS_ID>{bms_id}</BMS_ID>"))
    sub(hdr, "PayerABN", abn.replace(" ",""))
    sub(hdr, "PayerBusinessName", co.get("name",""))

    # Pay event
    evt = sub(root, "PayEvent")
    sub(evt, "PayEventType", submission_type)
    sub(evt, "FYYear",       str(fy + 1))  # ATO requires end year: 2026 for FY2025-26
    sub(evt, "PayPeriodStart", run["pay_period_start"])
    sub(evt, "PayPeriodEnd",   run["pay_period_end"])
    sub(evt, "PaymentDate",    run["payment_date"])
    sub(evt, "PayFrequency",
        {"Weekly":"W","Fortnightly":"F","Monthly":"M"}[run["frequency"]])

    # Employee payroll events
    for slip in slips:
        emp = get_employee(db_path, slip["employee_id"])
        if not emp:
            continue

        ee = sub(evt, "EmployeePayrollEvent")
        id_el = sub(ee, "EmployeeIdentification")
        sub(id_el, "EmployeeIdentifier", emp["employee_number"])
        if emp.get("tfn"):
            sub(id_el, "TFN", emp["tfn"].replace(" ",""))
        else:
            sub(id_el, "TFNWithholdingIndicator", "true")
        sub(id_el, "FamilyName",   emp["last_name"])
        sub(id_el, "GivenNames",   emp["first_name"])
        if emp.get("date_of_birth"):
            sub(id_el, "DateOfBirth", emp["date_of_birth"])

        # Income statements
        inc_el = sub(ee, "IncomeStatements")
        stmt = sub(inc_el, "IncomeStatement")
        sub(stmt, "IncomeType", slip["stp_income_type"])
        sub(stmt, "GrossPayments",     f"{slip['gross_pay']:.2f}")
        sub(stmt, "PAYGWithheld",      f"{slip['payg_tax']:.2f}")
        sub(stmt, "ReportableEmployerSuper",
            f"{slip['salary_sacrifice']:.2f}")

        # Earnings breakdown (Phase 2 requires disaggregation)
        earn = sub(stmt, "Earnings")
        if slip["ordinary_gross"] > 0:
            oe = sub(earn, "EarningLine")
            sub(oe, "PaymentType",  "SAL")
            sub(oe, "Hours",        f"{slip['ordinary_hours']:.4f}")
            sub(oe, "Amount",       f"{slip['ordinary_gross']:.2f}")
        if slip["overtime_gross"] > 0:
            ote = sub(earn, "EarningLine")
            sub(ote, "PaymentType", "OVT")
            sub(ote, "Hours",       f"{slip['overtime_hours']:.4f}")
            sub(ote, "Amount",      f"{slip['overtime_gross']:.2f}")
        if slip["leave_gross"] > 0 and slip.get("leave_type"):
            lt_code = {"Annual Leave":"ANN","Personal/Carer's Leave":"PER",
                       "Long Service Leave":"LSL","Parental Leave":"MAT"}.get(
                           slip["leave_type"], "OTH")
            le = sub(earn, "EarningLine")
            sub(le, "PaymentType", lt_code)
            sub(le, "Hours",   f"{slip['leave_hours']:.4f}")
            sub(le, "Amount",  f"{slip['leave_gross']:.2f}")

        # Allowances
        if slip["allowances"] > 0:
            allow_el = sub(stmt, "Allowances")
            try:
                al_list = json.loads(slip.get("allowances_json") or "[]")
            except Exception:
                al_list = [{"type": "Other", "amount": slip["allowances"]}]
            for a in al_list:
                ae = sub(allow_el, "AllowanceLine")
                sub(ae, "AllowanceType", a.get("type", "OTH"))
                sub(ae, "Amount", f"{a['amount']:.2f}")

        # YTD
        ytd_el = sub(stmt, "YearToDateAmounts")
        sub(ytd_el, "YTDGross",  f"{slip['ytd_gross']:.2f}")
        sub(ytd_el, "YTDTax",   f"{slip['ytd_tax']:.2f}")
        sub(ytd_el, "YTDSuper", f"{slip['ytd_super']:.2f}")

        # Super
        if slip["super_amount"] > 0:
            sup_el = sub(ee, "SuperContributions")
            sc = sub(sup_el, "SuperContributionLine")
            sub(sc, "ContributionType", "SGC")
            sub(sc, "Amount",  f"{slip['super_amount']:.2f}")
            if emp.get("super_fund_name"):
                sub(sc, "FundName", emp["super_fund_name"])
            if emp.get("super_fund_abn"):
                sub(sc, "FundABN",  emp["super_fund_abn"].replace(" ",""))
            if emp.get("super_member_number"):
                sub(sc, "MemberNumber", emp["super_member_number"])

    # Produce indented XML
    ET.indent(root, space="  ")
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(
        root, encoding="unicode")


def lodge_stp(db_path, run_id: int, abn: str) -> dict:
    """
    Generate and 'lodge' STP submission.
    In production this would POST to the ATO B2G gateway via a registered
    STP software provider. Here we generate the payload and record it locally
    so it can be reviewed, printed, or sent via a tax agent / accounting firm.

    Returns: {status, payload_xml, message}
    """
    try:
        payload_xml = generate_stp_xml(db_path, run_id, abn)
    except Exception as e:
        return {"status": "Error", "payload_xml": None, "message": str(e)}

    conn = get_connection(db_path)
    run = conn.execute("SELECT * FROM pay_runs WHERE id=?", (run_id,)).fetchone()
    fy = current_fy()
    conn.execute("""INSERT INTO stp_submissions
        (pay_run_id,submission_type,fy_year,status,payload_xml,message)
        VALUES (?,?,?,?,?,?)""",
        (run_id, "Update", fy, "Pending", payload_xml,
         "XML payload generated. Provide to your tax agent or registered STP channel."))
    conn.execute("UPDATE pay_runs SET status='STP_Lodged', stp_envelope=? WHERE id=?",
                 (payload_xml, run_id))
    conn.commit(); conn.close()

    return {
        "status":      "Pending",
        "payload_xml": payload_xml,
        "message":     ("STP Phase 2 payload generated successfully.\n\n"
                        "IMPORTANT: dbox generates compliant XML payloads but is not "
                        "a registered ATO STP software channel. To lodge with the ATO, "
                        "either:\n"
                        "  1. Provide the XML to your registered tax agent\n"
                        "  2. Use a registered STP filing service\n"
                        "  3. Upload via the ATO Business Portal\n\n"
                        f"Submission recorded locally for record-keeping.")
    }


def lodge_stp_finalisation(db_path, abn: str) -> dict:
    """
    Generate an STP Phase 2 Finalisation declaration for the current financial year.

    Returns: {status, payload_xml, submission_id, message}
    """
    conn = get_connection(db_path)
    # Find the most recent finalised pay run for use as YTD source
    run = conn.execute(
        """SELECT id FROM pay_runs
           WHERE status IN ('Finalised','STP_Lodged')
           ORDER BY payment_date DESC LIMIT 1"""
    ).fetchone()
    conn.close()

    if not run:
        return {
            "status": "Error",
            "payload_xml": None,
            "submission_id": None,
            "message": "No finalised pay runs found. Finalise at least one pay run before lodging a Finalisation declaration.",
        }

    run_id = run["id"]
    try:
        payload_xml = generate_stp_xml(db_path, run_id, abn,
                                       submission_type="Finalisation")
    except Exception as e:
        return {"status": "Error", "payload_xml": None, "submission_id": None,
                "message": str(e)}

    conn = get_connection(db_path)
    fy   = current_fy()
    cur  = conn.execute(
        """INSERT INTO stp_submissions
               (pay_run_id, submission_type, fy_year, status, payload_xml, message)
           VALUES (?, 'Finalisation', ?, 'Pending', ?, ?)""",
        (run_id, fy, payload_xml,
         f"FY{fy}/{fy+1} Finalisation declaration generated. "
         "Provide to your registered tax agent or STP filing service.")
    )
    submission_id = cur.lastrowid
    conn.commit(); conn.close()

    return {
        "status":        "Pending",
        "payload_xml":   payload_xml,
        "submission_id": submission_id,
        "message":       (
            f"STP Finalisation declaration for FY{fy}/{fy+1} generated successfully.\n\n"
            "This confirms the YTD figures reported during the year are final.\n\n"
            "IMPORTANT: dbox generates compliant XML payloads but is not a registered "
            "ATO STP software channel. Provide the XML to your registered tax agent or "
            "STP filing service to complete the end-of-year lodgement."
        ),
    }


def get_stp_submissions(db_path):
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT ss.*, pr.run_number
        FROM stp_submissions ss LEFT JOIN pay_runs pr ON ss.pay_run_id=pr.id
        ORDER BY ss.submitted_at DESC""").fetchall()
    conn.close()
    return [dict(r) for r in rows]
