# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Pay run engine — calculate_payslip, create/finalise/void pay runs, GL posting,
YTD management, PAYG Payment Summary helpers.
"""

import json
from datetime import date

from core.database import get_connection
from core.payroll._shared import super_rate, current_fy
from core.payroll.withholding import payg_for_period
from core.payroll.employees import get_employee


# ══════════════════════════════════════════════════════════════════════════════
#  RUN NUMBER HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def next_run_number(db_path) -> str:
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT run_number FROM pay_runs ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    prefix = f"PR{date.today().year}"
    if row and row[0].startswith(prefix):
        try:
            seq = int(row[0][len(prefix):]) + 1
        except ValueError:
            seq = 1
    else:
        seq = 1
    return f"{prefix}{seq:04d}"


# ══════════════════════════════════════════════════════════════════════════════
#  PAYSLIP CALCULATION
# ══════════════════════════════════════════════════════════════════════════════

def calculate_payslip(db_path, employee_id: int, period_start: str,
                       period_end: str, payment_date: str,
                       frequency: str,
                       ordinary_hours: float = None,
                       overtime_hours: float = 0.0,
                       leave_type: str = None,
                       leave_hours: float = 0.0,
                       allowances: list = None,
                       salary_sacrifice: float = None,   # None = use employee default
                       additional_withholding: float = None,  # None = use employee default
                       voluntary_super: float = None,    # None = use employee default
                       stp_income_type: str = "SAL") -> dict:
    """
    Calculate a payslip for one employee. Returns a payslip dict (not yet saved).
    If ordinary_hours is None, uses the employee's standard hours for the period.
    salary_sacrifice, additional_withholding, voluntary_super default to employee
    settings if not overridden.
    """
    emp = get_employee(db_path, employee_id)
    if not emp:
        raise ValueError(f"Employee {employee_id} not found")

    allowances = allowances or []
    periods = {"Weekly": 52, "Fortnightly": 26, "Monthly": 12}[frequency]

    # Use employee-level defaults if not explicitly passed
    if salary_sacrifice is None:
        salary_sacrifice = float(emp.get("salary_sacrifice_amount") or 0.0)
    if additional_withholding is None:
        additional_withholding = float(emp.get("additional_withholding") or 0.0)
    if voluntary_super is None:
        voluntary_super = float(emp.get("voluntary_super_amount") or 0.0)

    # Determine hourly rate
    if emp["hourly_rate"]:
        hourly = emp["hourly_rate"]
    elif emp["annual_salary"]:
        hourly = emp["annual_salary"] / (emp["hours_per_week"] * 52)
    elif emp.get("classification_id"):
        # Fall back to award classification rate
        from core.awards import resolve_rate_from_classification, apply_modifier
        try:
            pp = emp.get("pay_point") or 1
            resolved = resolve_rate_from_classification(db_path, emp["classification_id"], pp)
            base_hr = resolved.get("hourly_rate")
            if base_hr:
                mod = emp.get("pay_rate_modifier") or 0
                mod_type = emp.get("pay_rate_modifier_type") or "%"
                hourly = apply_modifier(base_hr, mod, mod_type)
            else:
                raise ValueError(
                    f"Employee {emp['first_name']} {emp['last_name']} has no pay rate")
        except ImportError:
            raise ValueError(
                f"Employee {emp['first_name']} {emp['last_name']} has no pay rate")
    else:
        raise ValueError(f"Employee {emp['first_name']} {emp['last_name']} has no pay rate")

    # Standard hours for period
    std_hours = emp["hours_per_week"] * 52 / periods
    if ordinary_hours is None:
        # Use max(leave_hours, 0) so a negative leave adjustment (reversal)
        # doesn't inflate ordinary_hours beyond std_hours
        ordinary_hours = max(0.0, std_hours - max(leave_hours, 0.0))

    # Earnings
    ordinary_gross = round(ordinary_hours * hourly, 2)
    overtime_rate  = round(hourly * 1.5, 4)   # 150% OT
    overtime_gross = round(overtime_hours * overtime_rate, 2)
    leave_gross    = round(leave_hours * hourly, 2)
    allow_total    = round(sum(a["amount"] for a in allowances), 2)

    gross_pay = ordinary_gross + overtime_gross + leave_gross + allow_total

    # Salary sacrifice reduces the taxable base (pre-tax super)
    salary_sacrifice = min(salary_sacrifice, gross_pay)   # can't sacrifice more than gross
    gross_after_sacrifice = max(0.0, gross_pay - salary_sacrifice)

    # PAYG withholding — use DB rates for current FY if available
    fy = current_fy()
    payg = payg_for_period(
        gross_after_sacrifice, frequency,
        has_tfn=bool(emp["tfn_quoted"]),
        has_threshold=bool(emp["has_tax_free_threshold"]),
        db_path=db_path, fy_year=fy,
        has_study_loan=bool(emp.get("study_loan", 0)),
        is_senior=bool(emp.get("senior_offset", 0)),
        is_foreign_resident=bool(emp.get("is_foreign_resident", 0)),
        medicare_exemption=emp.get("medicare_exemption") or "none")

    # Additional withholding (employee-elected extra tax) added on top
    payg = round(payg + additional_withholding, 2)

    # Post-tax voluntary super reduces net pay but doesn't affect PAYG
    voluntary_super = min(voluntary_super, max(0, gross_after_sacrifice - payg))

    net_pay = round(gross_after_sacrifice - payg - voluntary_super, 2)

    # Superannuation (on Ordinary Time Earnings - OTE)
    # SGC is calculated on OTE regardless of salary sacrifice
    sg_rate = emp["super_rate_override"] or super_rate(fy)
    ote = ordinary_gross + leave_gross + allow_total   # OTE excludes overtime
    super_sgc    = round(ote * sg_rate, 2)
    super_amount = super_sgc  # total employer super = SGC only (sacrifice tracked separately)

    # YTD snapshot (after this payslip)
    ytd_gross = round(emp["ytd_gross"] + gross_pay, 2)
    ytd_tax   = round(emp["ytd_tax"]   + payg, 2)
    ytd_super = round(emp["ytd_super"] + super_amount + salary_sacrifice, 2)

    return {
        "employee_id":          employee_id,
        "period_start":         period_start,
        "period_end":           period_end,
        "payment_date":         payment_date,
        "ordinary_hours":       ordinary_hours,
        "ordinary_rate":        hourly,
        "ordinary_gross":       ordinary_gross,
        "overtime_hours":       overtime_hours,
        "overtime_rate":        overtime_rate,
        "overtime_gross":       overtime_gross,
        "leave_type":           leave_type,
        "leave_hours":          leave_hours,
        "leave_gross":          leave_gross,
        "allowances":           allow_total,
        "allowances_json":      json.dumps(allowances),
        "salary_sacrifice":     salary_sacrifice,
        "additional_withholding": additional_withholding,
        "voluntary_super":      voluntary_super,
        "other_deductions":     0.0,
        "gross_pay":            gross_pay,
        "payg_tax":             payg,
        "net_pay":              net_pay,
        "super_amount":         super_amount,
        "super_sgc":            super_sgc,
        "ytd_gross":            ytd_gross,
        "ytd_tax":              ytd_tax,
        "ytd_super":            ytd_super,
        "stp_income_type":      stp_income_type,
        "status":               "Calculated",
        "_allowances":          allowances,
        "_employee":            emp,
    }


# ══════════════════════════════════════════════════════════════════════════════
#  PAY RUN CRUD
# ══════════════════════════════════════════════════════════════════════════════

def create_pay_run(db_path, period_start: str, period_end: str,
                   payment_date: str, frequency: str,
                   payslips_data: list,
                   created_by: int = None) -> int:
    """
    Create a draft pay run with calculated payslips.
    payslips_data: list of dicts from calculate_payslip().
    Returns pay_run_id.
    """
    conn = get_connection(db_path)
    run_number = next_run_number(db_path)

    total_gross = sum(p["gross_pay"]    for p in payslips_data)
    total_tax   = sum(p["payg_tax"]     for p in payslips_data)
    total_super = sum(p["super_amount"] for p in payslips_data)
    total_net   = sum(p["net_pay"]      for p in payslips_data)

    conn.execute("""INSERT INTO pay_runs
        (run_number,pay_period_start,pay_period_end,payment_date,frequency,
         status,total_gross,total_tax,total_super,total_net,created_by)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (run_number, period_start, period_end, payment_date, frequency,
         "Draft", total_gross, total_tax, total_super, total_net, created_by))
    run_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    for p in payslips_data:
        conn.execute("""INSERT OR REPLACE INTO payslips
            (pay_run_id,employee_id,period_start,period_end,payment_date,
             ordinary_hours,ordinary_rate,ordinary_gross,overtime_hours,
             overtime_rate,overtime_gross,leave_type,leave_hours,leave_gross,
             allowances,allowances_json,salary_sacrifice,other_deductions,
             gross_pay,payg_tax,net_pay,super_amount,ytd_gross,ytd_tax,
             ytd_super,stp_income_type,status)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (run_id, p["employee_id"], period_start, period_end, payment_date,
             p["ordinary_hours"], p["ordinary_rate"], p["ordinary_gross"],
             p["overtime_hours"], p["overtime_rate"], p["overtime_gross"],
             p.get("leave_type"), p["leave_hours"], p["leave_gross"],
             p["allowances"], p.get("allowances_json"),
             p.get("salary_sacrifice", 0),
             p.get("other_deductions", 0)
             + p.get("additional_withholding", 0)
             + p.get("voluntary_super", 0),
             p["gross_pay"], p["payg_tax"], p["net_pay"],
             p["super_amount"], p["ytd_gross"], p["ytd_tax"], p["ytd_super"],
             p["stp_income_type"], "Calculated"))

        # Save individual allowances
        allowances = p.get("_allowances") or []
        if allowances:
            payslip_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            for a in allowances:
                conn.execute("""INSERT INTO payroll_allowances
                    (payslip_id,allow_type,description,amount)
                    VALUES (?,?,?,?)""",
                    (payslip_id, a.get("type","Other"), a.get("description",""), a["amount"]))

    conn.commit(); conn.close()
    return run_id


def finalise_pay_run(db_path, run_id: int, post_journal: bool = True) -> None:
    """
    Finalise a pay run: update YTD on employees, post to GL, mark Finalised,
    and trigger leave accruals for all payslips in the run.
    """
    # Single connection for read + YTD update (was 2 separate connections)
    conn = get_connection(db_path)
    try:
        slips = conn.execute(
            "SELECT * FROM payslips WHERE pay_run_id=?", (run_id,)).fetchall()
        run   = conn.execute(
            "SELECT * FROM pay_runs WHERE id=?", (run_id,)).fetchone()
        if not run:
            raise ValueError(f"Pay run {run_id} not found")
        if run["status"] == "Finalised":
            raise ValueError("Pay run already finalised")
        for slip in slips:
            conn.execute("""UPDATE employees SET
                ytd_gross = ytd_gross + ?,
                ytd_tax   = ytd_tax   + ?,
                ytd_super = ytd_super + ?,
                ytd_allowances = ytd_allowances + ?
                WHERE id=?""",
                (slip["gross_pay"], slip["payg_tax"],
                 slip["super_amount"], slip["allowances"],
                 slip["employee_id"]))
        conn.commit()
    finally:
        conn.close()

    # Post journal to GL
    if post_journal:
        _post_payroll_journal(db_path, run_id)

    conn = get_connection(db_path)
    conn.execute("UPDATE pay_runs SET status='Finalised' WHERE id=?", (run_id,))
    conn.execute("UPDATE payslips SET status='Final' WHERE pay_run_id=?", (run_id,))
    conn.commit(); conn.close()

    # Trigger leave accruals for all per_hour leave types.
    # Runs after the pay run is committed so a leave failure never rolls back payroll.
    try:
        from core.leave import accrue_for_payrun
        accrue_for_payrun(db_path, run_id, run["pay_period_end"])
    except Exception as _leave_ex:
        import logging
        logging.getLogger(__name__).error(
            "Leave accrual failed for pay run %s: %s", run_id, _leave_ex)


def void_pay_run(db_path, run_id: int, voided_by: str = "system") -> None:
    """
    Void a finalised pay run.

    Reverses the YTD accumulators on each employee, posts a reversal journal
    to the GL (using reverse_journal on the original payroll journal), and
    marks the run and all its payslips as Void.

    Only Finalised or STP_Lodged runs may be voided.
    """
    conn = get_connection(db_path)
    try:
        run = conn.execute(
            "SELECT * FROM pay_runs WHERE id=?", (run_id,)).fetchone()
        if not run:
            raise ValueError(f"Pay run {run_id} not found")
        if run["status"] not in ("Finalised", "STP_Lodged"):
            raise ValueError(
                f"Only Finalised pay runs can be voided "
                f"(current status: {run['status']})")

        slips = conn.execute(
            "SELECT * FROM payslips WHERE pay_run_id=?", (run_id,)).fetchall()

        # Reverse YTD accumulators
        for slip in slips:
            conn.execute("""UPDATE employees SET
                ytd_gross      = ytd_gross      - ?,
                ytd_tax        = ytd_tax        - ?,
                ytd_super      = ytd_super      - ?,
                ytd_allowances = ytd_allowances - ?
                WHERE id=?""",
                (slip["gross_pay"], slip["payg_tax"],
                 slip["super_amount"], slip["allowances"],
                 slip["employee_id"]))

        conn.execute("UPDATE pay_runs  SET status='Void' WHERE id=?",  (run_id,))
        conn.execute("UPDATE payslips  SET status='Void' WHERE pay_run_id=?", (run_id,))
        conn.commit()
    finally:
        conn.close()

    # Reverse the GL journal if one was posted
    journal_id = run["journal_id"] if "journal_id" in run.keys() else None
    if journal_id:
        try:
            from core.ledger import reverse_journal
            reverse_journal(db_path, journal_id, run["payment_date"])
        except Exception as _jex:
            import logging
            logging.getLogger(__name__).error(
                "GL reversal failed for pay run %s journal %s: %s",
                run_id, journal_id, _jex)


def _post_payroll_journal(db_path, run_id: int):
    """Post a double-entry journal for the pay run."""
    from core.ledger import post_journal as _post
    conn = get_connection(db_path)
    slips = conn.execute("SELECT * FROM payslips WHERE pay_run_id=?", (run_id,)).fetchall()
    run   = conn.execute("SELECT * FROM pay_runs WHERE id=?", (run_id,)).fetchone()

    # Look up accounts
    def acc(code):
        r = conn.execute("SELECT id FROM accounts WHERE code=?", (code,)).fetchone()
        return r["id"] if r else None

    wages_ord = acc("5-3710")
    wages_ovt = acc("5-3720")
    wages_ann = acc("5-3730")
    wages_per = acc("5-3740")
    wages_oth = acc("5-3750")
    wages_all = acc("5-3760")
    super_exp = acc("5-3510")
    payg_liab = acc("2-1310") or acc("2-1300")
    super_lia = acc("2-1410") or acc("2-1400")
    net_wages = acc("2-1430")
    conn.close()

    lines = []
    for slip in slips:
        if slip["ordinary_gross"] and wages_ord:
            lines.append({"account_id": wages_ord,
                          "debit": slip["ordinary_gross"], "credit": 0})
        if slip["overtime_gross"] and wages_ovt:
            lines.append({"account_id": wages_ovt,
                          "debit": slip["overtime_gross"], "credit": 0})
        if slip["leave_gross"] and slip["leave_type"]:
            lt = slip["leave_type"]
            acc_id = wages_ann if "Annual" in lt else (
                     wages_per if "Personal" in lt else wages_oth)
            if acc_id:
                lines.append({"account_id": acc_id,
                              "debit": slip["leave_gross"], "credit": 0})
        if slip["allowances"] and wages_all:
            lines.append({"account_id": wages_all,
                          "debit": slip["allowances"], "credit": 0})
        if slip["super_amount"] and super_exp:
            lines.append({"account_id": super_exp,
                          "debit": slip["super_amount"], "credit": 0})

    # Credits
    total_tax   = sum(s["payg_tax"]     for s in slips)
    total_super = sum(s["super_amount"] for s in slips)
    total_net   = sum(s["net_pay"]      for s in slips)
    if total_tax   and payg_liab:
        lines.append({"account_id": payg_liab,  "debit": 0, "credit": total_tax})
    if total_super and super_lia:
        lines.append({"account_id": super_lia,  "debit": 0, "credit": total_super})
    if total_net   and net_wages:
        lines.append({"account_id": net_wages,  "debit": 0, "credit": total_net})

    if not lines:
        return
    jid = _post(db_path, run["payment_date"],
                f"Payroll {run['run_number']}", run["run_number"], lines)
    conn = get_connection(db_path)
    conn.execute("UPDATE pay_runs SET journal_id=? WHERE id=?", (jid, run_id))
    conn.commit(); conn.close()


def get_pay_runs(db_path):
    conn = get_connection(db_path)
    rows = conn.execute("""SELECT * FROM pay_runs ORDER BY payment_date DESC""").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_pay_run(db_path, run_id):
    conn = get_connection(db_path)
    run = conn.execute("SELECT * FROM pay_runs WHERE id=?", (run_id,)).fetchone()
    slips = conn.execute("""
        SELECT ps.*, e.first_name, e.last_name, e.employee_number,
               e.position_title, e.bank_bsb, e.bank_account
        FROM payslips ps JOIN employees e ON ps.employee_id=e.id
        WHERE ps.pay_run_id=? ORDER BY e.last_name, e.first_name""",
        (run_id,)).fetchall()
    conn.close()
    return dict(run) if run else None, [dict(s) for s in slips]


def get_payslips_for_employee(db_path, employee_id, limit=20):
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT ps.*, pr.run_number, pr.status as run_status
        FROM payslips ps JOIN pay_runs pr ON ps.pay_run_id=pr.id
        WHERE ps.employee_id=? ORDER BY ps.payment_date DESC LIMIT ?""",
        (employee_id, limit)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def reset_ytd(db_path):
    """Reset YTD accumulators for all employees (run on 1 July each year)."""
    conn = get_connection(db_path)
    conn.execute("""UPDATE employees SET
        ytd_gross=0, ytd_tax=0, ytd_super=0,
        ytd_allowances=0, ytd_leave_paid=0""")
    conn.commit(); conn.close()


# ══════════════════════════════════════════════════════════════════════════════
#  PAYG PAYMENT SUMMARY
# ══════════════════════════════════════════════════════════════════════════════

def get_payg_summary(db_path: str, financial_year: int,
                      employee_id: int = None) -> list:
    """
    Build PAYG Payment Summary data for all (or one) employee(s) for
    the given financial year (e.g. 2025 = FY 2024-25).

    Aggregates finalised payslips in the FY period (1 July – 30 June).
    """
    from core.database import get_connection as _gc
    conn = _gc(db_path)

    fy_start = f"{financial_year - 1}-07-01"
    fy_end   = f"{financial_year}-06-30"

    q = """
        SELECT
            ps.employee_id,
            e.first_name || ' ' || e.last_name   AS employee_name,
            e.tfn,
            e.address || COALESCE(', ' || e.city, '') || COALESCE(', ' || e.state, '') || COALESCE(' ' || e.postcode, '') AS full_address,
            e.employment_type,
            e.start_date,
            e.termination_date,
            COALESCE(SUM(ps.gross_pay), 0)        AS gross_wages,
            COALESCE(SUM(ps.payg_tax), 0)         AS payg_withheld,
            COALESCE(SUM(ps.super_amount), 0)     AS super_employer,
            COALESCE(SUM(ps.salary_sacrifice), 0) AS salary_sacrifice_super,
            COALESCE(SUM(ps.other_deductions), 0) AS other_deductions,
            COALESCE(SUM(ps.allowances), 0)       AS allowances_total,
            GROUP_CONCAT(ps.allowances_json)       AS all_allowances_json
        FROM payslips ps
        JOIN employees e ON ps.employee_id = e.id
        JOIN pay_runs  pr ON ps.pay_run_id  = pr.id
        WHERE pr.payment_date BETWEEN ? AND ?
          AND pr.status IN ('Finalised', 'STP_Lodged')
    """
    params = [fy_start, fy_end]
    if employee_id:
        q += " AND ps.employee_id = ?"
        params.append(employee_id)
    q += " GROUP BY ps.employee_id ORDER BY e.last_name, e.first_name"

    rows = conn.execute(q, params).fetchall()

    results = []
    for r in rows:
        r = dict(r)

        # Aggregate allowances breakdown from JSON blobs
        breakdown = {}
        try:
            import json as _j
            if r.get("all_allowances_json"):
                for chunk in r["all_allowances_json"].split(",{"):
                    chunk = chunk if chunk.startswith("[") or chunk.startswith("{") else "{" + chunk
                    try:
                        items = _j.loads(chunk) if isinstance(_j.loads(chunk), list) else [_j.loads(chunk)]
                        for item in items:
                            atype = item.get("type", "Other")
                            breakdown[atype] = breakdown.get(atype, 0) + float(item.get("amount", 0))
                    except Exception:
                        pass
        except Exception:
            pass

        results.append({
            "employee_id":           r["employee_id"],
            "employee_name":         r["employee_name"],
            "employment_type":       r.get("employment_type") or "—",
            "tfn":                   r.get("tfn") or "Not quoted",
            "address":               r.get("full_address") or "",
            "gross_wages":           round(r["gross_wages"], 2),
            "payg_withheld":         round(r["payg_withheld"], 2),
            "super_employer":        round(r["super_employer"], 2),
            "salary_sacrifice_super":round(r["salary_sacrifice_super"], 2),
            "other_deductions":      round(r["other_deductions"], 2),
            "allowances_total":      round(r["allowances_total"], 2),
            "allowances_breakdown":  breakdown,
            # These fields require manual entry (future enhancement)
            "lump_sum_a":            0.0,
            "lump_sum_b":            0.0,
            "lump_sum_d":            0.0,
            "lump_sum_e":            0.0,
            "reportable_fringe_benefits": 0.0,
            "cdep_payments":         0.0,
            "financial_year":        financial_year,
            "fy_label":              f"{financial_year-1}–{financial_year}",
        })

    conn.close()
    return results


def get_payment_summary_data(db_path: str, fy_year: int) -> list:
    """
    Return a list of PAYG Payment Summary records for each employee who had
    payslips finalised in the financial year ending 30 June `fy_year`.
    """
    date_from = f"{fy_year - 1}-07-01"
    date_to   = f"{fy_year}-06-30"

    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT
            e.id            AS employee_id,
            e.first_name || ' ' || e.last_name AS name,
            e.address       AS address,
            e.tfn           AS tfn,
            e.employment_type,
            COALESCE(SUM(ps.gross_pay), 0)           AS gross_wages,
            COALESCE(SUM(ps.payg_tax), 0)            AS payg_withheld,
            COALESCE(SUM(ps.salary_sacrifice),0) AS reportable_super,
            COALESCE(SUM(ps.allowances), 0)          AS total_allowances
        FROM employees e
        JOIN payslips ps ON ps.employee_id = e.id
        JOIN pay_runs pr ON ps.pay_run_id  = pr.id
        WHERE pr.status IN ('Finalised','STP_Lodged')
          AND ps.payment_date BETWEEN ? AND ?
        GROUP BY e.id
        ORDER BY e.last_name, e.first_name
    """, (date_from, date_to)).fetchall()

    # Collect allowance detail per employee for itemised listing
    allow_rows = conn.execute("""
        SELECT ps.employee_id, ps.allowances_json
        FROM payslips ps
        JOIN pay_runs pr ON ps.pay_run_id = pr.id
        WHERE pr.status IN ('Finalised','STP_Lodged')
          AND ps.payment_date BETWEEN ? AND ?
          AND ps.allowances_json IS NOT NULL
    """, (date_from, date_to)).fetchall()
    conn.close()

    import json as _json
    # Aggregate allowances by type per employee
    allow_by_emp = {}
    for ar in allow_rows:
        eid = ar["employee_id"]
        try:
            items = _json.loads(ar["allowances_json"] or "[]")
        except Exception:
            items = []
        bucket = allow_by_emp.setdefault(eid, {})
        for item in items:
            atype = item.get("type", "Other")
            bucket[atype] = round(bucket.get(atype, 0) + float(item.get("amount", 0)), 2)

    results = []
    for r in rows:
        d = dict(r)
        # Mask TFN — show last 3 digits only: ***-***-XXX
        tfn = str(d.get("tfn") or "")
        tfn_clean = tfn.replace(" ", "").replace("-", "")
        if len(tfn_clean) >= 3:
            d["tfn_display"] = f"***-***-{tfn_clean[-3:]}"
        else:
            d["tfn_display"] = "Not on file"
        d["allowances_detail"] = allow_by_emp.get(d["employee_id"], {})
        # These fields not yet tracked — zero placeholders for PDF layout
        d["lump_sum_a"] = 0.0
        d["lump_sum_b"] = 0.0
        d["lump_sum_d"] = 0.0
        d["lump_sum_e"] = 0.0
        d["reportable_fringe_benefits"] = 0.0
        d["deductible_expenses"]        = 0.0
        d["fy_year"]    = fy_year
        d["date_from"]  = date_from
        d["date_to"]    = date_to
        results.append(d)
    return results


# ══════════════════════════════════════════════════════════════════════════════
#  LEAVE REPORT HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _get_all_leave_balances(db_path) -> list:
    """
    Return leave balance rows for all active employees, joined to employee
    and leave-type details.
    """
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT
            e.id              AS employee_id,
            e.employee_number,
            e.first_name,
            e.last_name,
            e.employment_type,
            e.hours_per_week,
            lt.id             AS leave_type_id,
            lt.code,
            lt.name           AS type_name,
            lt.paid,
            lt.colour,
            COALESCE(lb.accrued_hours,    0) AS accrued_hours,
            COALESCE(lb.taken_hours,      0) AS taken_hours,
            COALESCE(lb.adjustment_hours, 0) AS adjustment_hours,
            COALESCE(lb.accrued_hours, 0)
                + COALESCE(lb.adjustment_hours, 0)
                - COALESCE(lb.taken_hours, 0)  AS balance_hours
        FROM employees e
        CROSS JOIN leave_types lt
        LEFT JOIN leave_balances lb
               ON lb.employee_id   = e.id
              AND lb.leave_type_id = lt.id
        WHERE e.is_active = 1
          AND lt.is_active = 1
        ORDER BY e.last_name, e.first_name,
                 lt.sort_order, lt.name
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]
