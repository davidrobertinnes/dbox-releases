# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
dbox - POS Settings
Stores payment terminal configuration in the company DB.
Follows the email_settings pattern: single row, id=1 constraint.
"""

import base64 as _b64
from core.database import get_connection


def _enc(s: str) -> str:
    return _b64.b64encode(s.encode()).decode() if s else ""


def _dec(s: str) -> str:
    if not s:
        return ""
    try:
        return _b64.b64decode(s.encode()).decode()
    except Exception:
        return s


def get_pos_settings(db_path) -> dict:
    conn = get_connection(db_path)
    conn.execute("""CREATE TABLE IF NOT EXISTS pos_settings (
        id                INTEGER PRIMARY KEY CHECK (id=1),
        provider          TEXT DEFAULT '',
        api_key           TEXT DEFAULT '',
        device_id         TEXT DEFAULT '',
        location_id       TEXT DEFAULT '',
        terminal_name     TEXT DEFAULT 'POS Terminal',
        cash_account_id   INTEGER,
        card_account_id   INTEGER,
        walkin_contact_id INTEGER,
        printer_enabled   INTEGER DEFAULT 0,
        printer_type      TEXT DEFAULT 'network',
        printer_host      TEXT DEFAULT '',
        printer_port      INTEGER DEFAULT 9100,
        printer_auto_print INTEGER DEFAULT 0,
        square_sandbox    INTEGER DEFAULT 0,
        banking_account_id INTEGER,
        receipt_footer    TEXT DEFAULT ''
    )""")
    # migrate existing rows that predate printer columns
    for col, defn in [
        ("printer_enabled",    "INTEGER DEFAULT 0"),
        ("printer_type",       "TEXT DEFAULT 'network'"),
        ("printer_host",       "TEXT DEFAULT ''"),
        ("printer_port",       "INTEGER DEFAULT 9100"),
        ("printer_auto_print", "INTEGER DEFAULT 0"),
        ("square_sandbox",      "INTEGER DEFAULT 0"),
        ("banking_account_id",  "INTEGER"),
        ("receipt_footer",      "TEXT DEFAULT ''"),
        ("eod_email_enabled",   "INTEGER DEFAULT 0"),
        ("eod_email_address",   "TEXT DEFAULT ''"),
    ]:
        try:
            conn.execute(f"ALTER TABLE pos_settings ADD COLUMN {col} {defn}")
        except Exception:
            pass
    conn.commit()
    row = conn.execute("SELECT * FROM pos_settings").fetchone()
    conn.close()
    if not row:
        return {
            "provider": "", "api_key": "", "device_id": "",
            "location_id": "", "terminal_name": "POS Terminal",
            "cash_account_id": None, "card_account_id": None,
            "walkin_contact_id": None,
            "printer_enabled": 0, "printer_type": "network",
            "printer_host": "", "printer_port": 9100, "printer_auto_print": 0,
            "square_sandbox": 0, "banking_account_id": None,
            "receipt_footer": "",
            "eod_email_enabled": 0, "eod_email_address": "",
        }
    d = dict(row)
    d["api_key"] = _dec(d.get("api_key") or "")
    return d


def save_pos_settings(db_path, data: dict):
    get_pos_settings(db_path)  # ensure table + columns exist
    conn = get_connection(db_path)
    conn.execute("""INSERT OR REPLACE INTO pos_settings
        (id, provider, api_key, device_id, location_id, terminal_name,
         cash_account_id, card_account_id, walkin_contact_id,
         printer_enabled, printer_type, printer_host, printer_port, printer_auto_print,
         square_sandbox, banking_account_id, receipt_footer,
         eod_email_enabled, eod_email_address)
        VALUES (1,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            data.get("provider", ""),
            _enc(data.get("api_key", "")),
            data.get("device_id", ""),
            data.get("location_id", ""),
            data.get("terminal_name", "POS Terminal"),
            data.get("cash_account_id") or None,
            data.get("card_account_id") or None,
            data.get("walkin_contact_id") or None,
            1 if data.get("printer_enabled") else 0,
            data.get("printer_type", "network"),
            data.get("printer_host", ""),
            int(data.get("printer_port") or 9100),
            1 if data.get("printer_auto_print") else 0,
            1 if data.get("square_sandbox") else 0,
            data.get("banking_account_id") or None,
            data.get("receipt_footer", ""),
            1 if data.get("eod_email_enabled") else 0,
            (data.get("eod_email_address") or "").strip(),
        ))
    conn.commit()
    conn.close()
