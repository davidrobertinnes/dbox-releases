"""
dbox - POS Settings
Stores payment terminal configuration in the company DB.
Follows the email_settings pattern: single row, id=1 constraint.
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.

import base64 as _b64
from core.database import get_connection


def _enc(s: str) -> str:
    return _b64.b64encode(s.encode()).decode() if s else ""


def _dec(s: str) -> str:
    if not s:
        return ""
    try:
        return _b64.b64decode(s.encode()).decode()
    except Exception:
        return s


def get_pos_settings(db_path) -> dict:
    conn = get_connection(db_path)
    conn.execute("""CREATE TABLE IF NOT EXISTS pos_settings (
        id                INTEGER PRIMARY KEY CHECK (id=1),
        provider          TEXT DEFAULT '',
        api_key           TEXT DEFAULT '',
        device_id         TEXT DEFAULT '',
        location_id       TEXT DEFAULT '',
        terminal_name     TEXT DEFAULT 'POS Terminal',
        cash_account_id   INTEGER,
        card_account_id   INTEGER,
        walkin_contact_id INTEGER
    )""")
    conn.commit()
    row = conn.execute("SELECT * FROM pos_settings").fetchone()
    conn.close()
    if not row:
        return {
            "provider": "", "api_key": "", "device_id": "",
            "location_id": "", "terminal_name": "POS Terminal",
            "cash_account_id": None, "card_account_id": None,
            "walkin_contact_id": None,
        }
    d = dict(row)
    d["api_key"] = _dec(d.get("api_key") or "")
    return d


def save_pos_settings(db_path, data: dict):
    get_pos_settings(db_path)  # ensure table exists
    conn = get_connection(db_path)
    conn.execute("""INSERT OR REPLACE INTO pos_settings
        (id, provider, api_key, device_id, location_id, terminal_name,
         cash_account_id, card_account_id, walkin_contact_id)
        VALUES (1,?,?,?,?,?,?,?,?)""",
        (
            data.get("provider", ""),
            _enc(data.get("api_key", "")),
            data.get("device_id", ""),
            data.get("location_id", ""),
            data.get("terminal_name", "POS Terminal"),
            data.get("cash_account_id") or None,
            data.get("card_account_id") or None,
            data.get("walkin_contact_id") or None,
        ))
    conn.commit()
    conn.close()
