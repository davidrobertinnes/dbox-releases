# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import re
from datetime import date

from core.database import get_connection


def diagnose_balances(db_path: str) -> list:
    today = str(date.today())
    conn  = get_connection(db_path)
    try:
        accounts_raw = conn.execute(
            "SELECT id, code, name, account_type, account_subtype, is_bank, opening_balance "
            "FROM accounts WHERE is_bank=1 AND is_active=1 ORDER BY code"
        ).fetchall()

        result = []
        for a in accounts_raw:
            aid = a["id"]

            jl_all = conn.execute(
                "SELECT COALESCE(SUM(debit),0)-COALESCE(SUM(credit),0) AS net "
                "FROM journal_lines WHERE account_id=?", (aid,)
            ).fetchone()["net"] or 0.0

            jl_today = conn.execute(
                "SELECT COALESCE(SUM(jl.debit),0)-COALESCE(SUM(jl.credit),0) AS net "
                "FROM journal_lines jl "
                "JOIN journal_entries je ON jl.journal_id=je.id "
                "WHERE jl.account_id=? AND je.entry_date<=?", (aid, today)
            ).fetchone()["net"] or 0.0

            orphaned = conn.execute(
                "SELECT COALESCE(SUM(jl.debit),0)-COALESCE(SUM(jl.credit),0) AS net "
                "FROM journal_lines jl "
                "LEFT JOIN journal_entries je ON jl.journal_id=je.id "
                "WHERE jl.account_id=? AND je.id IS NULL", (aid,)
            ).fetchone()["net"] or 0.0

            ob = a["opening_balance"] or 0.0

            ob_jl = conn.execute(
                "SELECT COALESCE(SUM(jl.debit),0)-COALESCE(SUM(jl.credit),0) AS net "
                "FROM journal_lines jl "
                "JOIN journal_entries je ON jl.journal_id=je.id "
                "WHERE jl.account_id=? AND (je.reference LIKE 'OB-%' OR je.description='Opening balances')",
                (aid,)
            ).fetchone()["net"] or 0.0

            future_jl = conn.execute(
                "SELECT COALESCE(SUM(jl.debit),0)-COALESCE(SUM(jl.credit),0) AS net "
                "FROM journal_lines jl "
                "JOIN journal_entries je ON jl.journal_id=je.id "
                "WHERE jl.account_id=? AND je.entry_date>?", (aid, today)
            ).fetchone()["net"] or 0.0

            result.append({
                "id": aid, "code": a["code"], "name": a["name"],
                "account_type": a["account_type"], "subtype": a["account_subtype"],
                "opening_balance_field": ob,
                "jl_sum_all_time":        round(ob + jl_all,   2),
                "jl_sum_as_at_today":     round(ob + jl_today, 2),
                "ob_journal_contribution": round(ob_jl, 2),
                "double_counted_by": round(ob_jl, 2) if abs(ob) > 0.01 and abs(ob_jl) > 0.01 else 0,
                "orphaned_jl_net":     round(orphaned,  2),
                "future_dated_jl_net": round(future_jl, 2),
            })
        return result
    finally:
        conn.close()


def repair_opening_balances(db_path: str) -> dict:
    conn = get_connection(db_path)
    try:
        affected = conn.execute("""
            SELECT DISTINCT jl.account_id
            FROM journal_lines jl
            JOIN journal_entries je ON jl.journal_id = je.id
            WHERE je.reference LIKE 'OB-%' OR je.description = 'Opening balances'
        """).fetchall()

        fixed = 0
        skipped = 0
        for row in affected:
            cur = conn.execute("SELECT opening_balance FROM accounts WHERE id=?",
                               (row["account_id"],)).fetchone()
            if cur and (cur["opening_balance"] or 0) != 0:
                conn.execute("UPDATE accounts SET opening_balance=0 WHERE id=?",
                             (row["account_id"],))
                fixed += 1
            else:
                skipped += 1
        conn.commit()
        return {"accounts_fixed": fixed, "already_zero": skipped}
    finally:
        conn.close()


def repair_date_formats(db_path: str) -> dict:
    MONTHS = {'JAN': '01', 'FEB': '02', 'MAR': '03', 'APR': '04', 'MAY': '05', 'JUN': '06',
              'JUL': '07', 'AUG': '08', 'SEP': '09', 'OCT': '10', 'NOV': '11', 'DEC': '12'}
    pattern = re.compile(r'^(\d{4})-([A-Z]{3})-(\d{2})$')

    def _fix(d):
        if not d:
            return None
        m = pattern.match(str(d))
        if m:
            y, mon, day = m.groups()
            num = MONTHS.get(mon)
            return f"{y}-{num}-{day}" if num else None
        return None

    conn = get_connection(db_path)
    try:
        bt_rows = conn.execute(
            "SELECT id, transaction_date FROM bank_transactions").fetchall()
        je_rows = conn.execute(
            "SELECT id, entry_date FROM journal_entries").fetchall()

        bt_fixed = je_fixed = 0
        for r in bt_rows:
            iso = _fix(r["transaction_date"])
            if iso:
                conn.execute("UPDATE bank_transactions SET transaction_date=? WHERE id=?",
                             (iso, r["id"]))
                bt_fixed += 1
        for r in je_rows:
            iso = _fix(r["entry_date"])
            if iso:
                conn.execute("UPDATE journal_entries SET entry_date=? WHERE id=?",
                             (iso, r["id"]))
                je_fixed += 1

        conn.commit()
        return {"bank_transactions_fixed": bt_fixed, "journal_entries_fixed": je_fixed}
    finally:
        conn.close()
