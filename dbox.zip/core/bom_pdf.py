# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""dbox - Bill of Materials PDF"""

import os
import tempfile
from datetime import date

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_RIGHT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

from core.database import get_connection
from core.invoice_pdf import (
    _resolve_theme, _s, _fmt, _c, _load_doc_theme,
    _build_header, _make_page_callback,
)

# Usable width on A4 portrait with 18mm margins each side
_BOM_W = 210*mm - 36*mm   # 174 mm


def generate_bom_pdf(db_path, job_id: int, output_path=None,
                     watermark=None, footer=None) -> str:
    conn = get_connection(db_path)

    job = conn.execute("""
        SELECT j.*, c.name AS contact_name
        FROM jobs j
        LEFT JOIN contacts c ON j.contact_id = c.id
        WHERE j.id = ?
    """, (job_id,)).fetchone()
    if not job:
        conn.close()
        raise ValueError(f"Job {job_id} not found")

    bom_rows = conn.execute("""
        SELECT b.*, p.po_number
        FROM job_bom_lines b
        LEFT JOIN purchase_orders p ON p.id = b.po_id
        WHERE b.job_id = ?
        ORDER BY b.sort_order, b.id
    """, (job_id,)).fetchall()

    company = conn.execute("SELECT * FROM company").fetchone()
    conn.close()

    j  = dict(job)
    co = dict(company) if company else {}
    th = _resolve_theme(_load_doc_theme(co))
    s  = _s(th)

    s["hdr_r"] = ParagraphStyle(
        "hdr_r", parent=s["tbl_hdr"],
        alignment=TA_RIGHT,
    )
    s["cell_r"] = ParagraphStyle(
        "cell_r", parent=s["body"],
        alignment=TA_RIGHT, fontSize=9,
    )
    s["cell_sm"] = ParagraphStyle(
        "cell_sm", parent=s["small"],
        fontSize=8, textColor=_c(th["dim_text"]),
    )
    s["status_pending"]  = ParagraphStyle("st_p", parent=s["small"], fontSize=8,
                                           textColor=colors.HexColor("#b45309"))
    s["status_ordered"]  = ParagraphStyle("st_o", parent=s["small"], fontSize=8,
                                           textColor=colors.HexColor("#1d4ed8"))
    s["status_onhand"]   = ParagraphStyle("st_h", parent=s["small"], fontSize=8,
                                           textColor=colors.HexColor("#15803d"))
    s["status_client"]   = ParagraphStyle("st_c", parent=s["small"], fontSize=8,
                                           textColor=colors.HexColor("#6b7280"))

    ref      = j.get("job_number") or f"JOB{job_id}"
    job_name = j.get("name") or ""
    client   = j.get("contact_name") or ""
    today    = date.today().strftime("%d/%m/%Y")

    if output_path is None:
        output_path = os.path.join(tempfile.mkdtemp(), f"bom_{ref}.pdf")

    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        leftMargin=18*mm, rightMargin=18*mm,
        topMargin=14*mm, bottomMargin=14*mm,
        title=f"Bill of Materials — {ref}",
        author=co.get("name", ""),
    )

    cb = _make_page_callback(watermark=watermark, footer=footer)
    story = []

    _build_header(story, co, "BILL OF MATERIALS", s, th)

    # ── Job header block ──────────────────────────────────────────────────────
    hdr_data = [[
        [
            Paragraph("Job", s["label"]),
            Paragraph(f"{ref} — {job_name}", s["body_b"]),
            *(([Paragraph(f"Client: {client}", s["small"])]) if client else []),
        ],
        [
            Paragraph("Date", s["label"]),
            Paragraph(today, s["body"]),
        ],
    ]]
    hdr_tbl = Table(hdr_data, colWidths=[_BOM_W * 0.70, _BOM_W * 0.30])
    hdr_tbl.setStyle(TableStyle([
        ("VALIGN",        (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING",   (0, 0), (-1, -1), 0),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 0),
        ("TOPPADDING",    (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
    ]))
    story.append(hdr_tbl)
    story.append(Spacer(1, 5*mm))

    # ── BOM table ─────────────────────────────────────────────────────────────
    def _status(row):
        if row["is_on_hand"]:
            return Paragraph("On Hand", s["status_onhand"])
        if row["is_customer_supplied"]:
            return Paragraph("Client Supplied", s["status_client"])
        if row["po_id"]:
            return Paragraph(f"Ordered\n{row['po_number'] or ''}", s["status_ordered"])
        return Paragraph("Pending", s["status_pending"])

    def _qty(row):
        q = float(row["qty"] or 1)
        return f"{int(q)}" if q == int(q) else f"{q:.3g}"

    RULE = _c(th["rule_colour"])
    BG   = _c(th["header_bg"])
    FG   = _c(th["header_text"])
    ALT  = _c(th["row_alt"])

    # Column widths: Description | Qty | Unit Cost | Unit Price | PO | Status
    # Trimmed to fit A4 portrait (174mm usable)
    desc_w   = 55 * mm
    qty_w    = 14 * mm
    cost_w   = 20 * mm
    price_w  = 20 * mm
    po_w     = 25 * mm
    status_w = _BOM_W - desc_w - qty_w - cost_w - price_w - po_w  # ~40mm

    tbl_data = [[
        Paragraph("Description",  s["tbl_hdr"]),
        Paragraph("Qty",          s["hdr_r"]),
        Paragraph("Unit Cost",    s["hdr_r"]),
        Paragraph("Unit Price",   s["hdr_r"]),
        Paragraph("PO",           s["tbl_hdr"]),
        Paragraph("Status",       s["tbl_hdr"]),
    ]]

    our_cost_total  = 0.0
    bill_total      = 0.0
    client_count    = 0

    for row in bom_rows:
        is_client = bool(row["is_customer_supplied"])
        qty       = float(row["qty"] or 1)
        unit_cost = float(row["unit_cost"] or 0)
        unit_price= float(row["unit_price"] or 0)

        notes = row["notes"] or ""
        desc_cell = [Paragraph(row["description"] or "", s["body"])]
        if notes:
            desc_cell.append(Paragraph(notes, s["cell_sm"]))

        if not is_client:
            our_cost_total += qty * unit_cost
            bill_total     += qty * unit_price
        else:
            client_count += 1

        tbl_data.append([
            desc_cell,
            Paragraph(_qty(row),                                      s["cell_r"]),
            Paragraph("—" if is_client else _fmt(unit_cost),          s["cell_r"]),
            Paragraph("—" if is_client else _fmt(unit_price),         s["cell_r"]),
            Paragraph(row["po_number"] or ("—" if not row["po_id"] else ""), s["cell_sm"]),
            _status(row),
        ])

    if not bom_rows:
        tbl_data.append([
            Paragraph("No materials recorded.", s["small"]),
            "", "", "", "", "",
        ])

    bom_style = [
        ("BACKGROUND",     (0, 0), (-1, 0),  BG),
        ("TEXTCOLOR",      (0, 0), (-1, 0),  FG),
        ("FONTNAME",       (0, 0), (-1, 0),  "Helvetica-Bold"),
        ("FONTSIZE",       (0, 0), (-1, 0),  8),
        ("FONTSIZE",       (0, 1), (-1, -1), 9),
        ("TOPPADDING",     (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING",  (0, 0), (-1, -1), 4),
        ("LEFTPADDING",    (0, 0), (-1, -1), 4),
        ("RIGHTPADDING",   (0, 0), (-1, -1), 4),
        ("GRID",           (0, 0), (-1, -1), 0.4, RULE),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [ALT, colors.white]),
        ("VALIGN",         (0, 0), (-1, -1), "TOP"),
    ]
    if not bom_rows:
        bom_style.append(("SPAN", (0, 1), (-1, 1)))

    bom_tbl = Table(
        tbl_data,
        colWidths=[desc_w, qty_w, cost_w, price_w, po_w, status_w],
        repeatRows=1,
    )
    bom_tbl.setStyle(TableStyle(bom_style))
    story.append(bom_tbl)
    story.append(Spacer(1, 5*mm))

    # ── Totals summary ────────────────────────────────────────────────────────
    if bom_rows:
        margin = bill_total - our_cost_total
        tot_rows = [
            ("Our Cost (excl. GST)",    f"${our_cost_total:,.2f}"),
            ("Billable (excl. GST)",     f"${bill_total:,.2f}"),
        ]
        if margin > 0:
            tot_rows.append(("Margin", f"${margin:,.2f}"))
        if client_count:
            tot_rows.append(("Client-supplied lines", str(client_count)))

        val_style = ParagraphStyle(
            "tot_val", parent=s["body"], alignment=TA_RIGHT,
            fontName="Helvetica-Bold", fontSize=9,
        )
        lbl_style = ParagraphStyle(
            "tot_lbl", parent=s["small"],
            textColor=_c(th["dim_text"]), fontSize=9,
        )
        tot_data = [
            [Paragraph(lbl, lbl_style), Paragraph(val, val_style)]
            for lbl, val in tot_rows
        ]
        tot_tbl = Table(
            tot_data,
            colWidths=[_BOM_W - 50*mm, 50*mm],
        )
        tot_tbl.setStyle(TableStyle([
            ("TOPPADDING",    (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ("LEFTPADDING",   (0, 0), (-1, -1), 4),
            ("RIGHTPADDING",  (0, 0), (-1, -1), 4),
            ("LINEBELOW",     (0, -1), (-1, -1), 0.5, RULE),
            ("LINEABOVE",     (0, 0),  (-1, 0),  0.5, RULE),
        ]))
        story.append(tot_tbl)

    doc.build(story, onFirstPage=cb, onLaterPages=cb)
    return output_path
