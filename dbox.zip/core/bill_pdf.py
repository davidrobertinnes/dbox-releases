"""
dbox - Bill / Remittance Advice PDF Generator
Matches invoice layout exactly — same header, theme, styles.
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.


import os, tempfile, json
from datetime import date as dt
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_RIGHT, TA_CENTER
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, KeepTogether
)
from core.database import get_connection
from core.invoice_pdf import (
    _resolve_theme, _s, _fmt, _c,
    _build_header, _build_meta_table,
    _build_line_table, _build_totals_block, _build_footer,
    _load_doc_theme, _make_page_callback, WHITE, GREEN, RED, GREY, PAGE_W
)


def generate_bill_pdf(db_path, bill_id, output_path=None, doc_theme=None, watermark=None, footer=None):
    conn = get_connection(db_path)
    bill = conn.execute("""
        SELECT b.*, c.name as cname, c.abn as cabn, c.email as cemail,
               c.address as caddress, c.city as ccity,
               c.state as cstate, c.postcode as cpostcode, c.phone as cphone
        FROM bills b JOIN contacts c ON b.contact_id=c.id
        WHERE b.id=?""", (bill_id,)).fetchone()
    lines = conn.execute("""
        SELECT bl.*, a.name as aname
        FROM bill_lines bl LEFT JOIN accounts a ON bl.account_id=a.id
        WHERE bl.bill_id=? ORDER BY bl.id""", (bill_id,)).fetchall()
    company = conn.execute("SELECT * FROM company").fetchone()
    conn.close()

    if not bill:
        raise ValueError(f"Bill {bill_id} not found")

    bill  = dict(bill)
    lines = [dict(l) for l in lines]
    co    = dict(company) if company else {}

    if doc_theme is None:
        doc_theme = _load_doc_theme(co)
    th = _resolve_theme(doc_theme)
    s  = _s(th)

    if output_path is None:
        num = bill.get("bill_number") or f"BILL-{bill_id}"
        output_path = os.path.join(tempfile.mkdtemp(), f"{num}.pdf")

    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        leftMargin=18*mm, rightMargin=18*mm,
        topMargin=14*mm, bottomMargin=14*mm,
        title=f"Bill {bill.get('bill_number', bill_id)}",
        author=co.get("name", ""),
    )
    story = []

    # ── Header ────────────────────────────────────────────────────────────────
    co_name, co_abn, co_addr, co_phone, co_email, co_web = \
        _build_header(story, co, "BILL / REMITTANCE", s, th)

    # ── Address block ─────────────────────────────────────────────────────────
    today_str  = str(dt.today())
    is_overdue = (bill["status"] not in ("Paid", "Void", "Draft") and
                  (bill.get("due_date") or "") < today_str)
    status_col = (GREEN if bill["status"] == "Paid" else
                  RED   if is_overdue else
                  GREY  if bill["status"] == "Void" else
                  _c(th["header_bg"]))

    supp_elems = [Paragraph("Supplier", s["label"]),
                  Paragraph(bill["cname"], s["body_b"])]
    if bill.get("cabn"):
        supp_elems.append(Paragraph(f"ABN: {bill['cabn']}", s["body"]))
    supp_addr = ", ".join(filter(None, [bill.get("caddress"), bill.get("ccity"),
                                         bill.get("cstate"), bill.get("cpostcode")]))
    if supp_addr:
        supp_elems.append(Paragraph(supp_addr, s["body"]))
    if bill.get("cemail"):
        supp_elems.append(Paragraph(bill["cemail"], s["small"]))

    left_col = supp_elems

    meta_rows = [
        ["Bill No",    bill.get("bill_number", "")],
        ["Bill Date",  bill.get("bill_date", "")],
        ["Due Date",   bill.get("due_date") or "—"],
        ["Status",     bill["status"]],
    ]
    if bill.get("amount_paid", 0) > 0:
        meta_rows.append(["Amount Paid", _fmt(bill["amount_paid"])])

    meta_tbl = _build_meta_table(meta_rows, th,
                                  status_row=3, status_colour=status_col)
    addr_tbl = Table([[left_col, meta_tbl]],
                     colWidths=[PAGE_W * 0.55, PAGE_W * 0.45])
    addr_tbl.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                                   ("LEFTPADDING",  (0, 0), (-1, -1), 0),
                                   ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    story.append(addr_tbl)
    story.append(Spacer(1, 5*mm))

    # ── Line items ────────────────────────────────────────────────────────────
    cw = [PAGE_W * 0.40, PAGE_W * 0.09, PAGE_W * 0.14,
          PAGE_W * 0.08, PAGE_W * 0.12, PAGE_W * 0.17]
    tbl_data = [[
        Paragraph("Description",  s["tbl_hdr"]),
        Paragraph("Qty",          s["tbl_hdr_r"]),
        Paragraph("Unit Price",   s["tbl_hdr_r"]),
        Paragraph("Tax",          s["tbl_hdr_c"]),
        Paragraph("GST",          s["tbl_hdr_r"]),
        Paragraph("Amount",       s["tbl_hdr_r"]),
    ]]
    for l in lines:
        tbl_data.append([
            Paragraph(l.get("description", ""), s["body"]),
            Paragraph(f"{l.get('quantity', 1):g}", s["right"]),
            Paragraph(_fmt(l.get("unit_price", 0)), s["right"]),
            Paragraph(l.get("tax_code", "GST"),
                      ParagraphStyle("tc", fontName="Helvetica",
                                     fontSize=9, alignment=TA_CENTER)),
            Paragraph(_fmt(l.get("gst_amount", 0)), s["right"]),
            Paragraph(_fmt(l.get("line_total", 0)), s["right_b"]),
        ])
    story.append(_build_line_table(tbl_data, cw, th))
    story.append(Spacer(1, 4*mm))

    # ── Totals ────────────────────────────────────────────────────────────────
    total = bill.get("total", 0) or 0
    gst   = bill.get("gst_total", 0) or 0
    sub   = bill.get("subtotal", total - gst) or 0
    paid  = bill.get("amount_paid", 0) or 0

    grand_lbl = ("AMOUNT DUE" if paid > 0 and (total - paid) > 0 else
                 "PAID IN FULL" if paid > 0 else "TOTAL DUE")
    totals = _build_totals_block(sub, gst, total, paid, th, s, grand_lbl)

    summary = Table([[Spacer(1, 1), totals]],
                    colWidths=[PAGE_W * 0.57, PAGE_W * 0.43])
    summary.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN",  (1, 0), (1, 0),  "RIGHT"),
        ("LEFTPADDING",  (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))
    story.append(summary)

    # ── Notes ─────────────────────────────────────────────────────────────────
    notes = (bill.get("notes") or "").strip()
    if notes:
        story.append(Spacer(1, 4*mm))
        story.append(HRFlowable(width="100%", thickness=0.5,
                                 color=_c(th["rule_colour"]), spaceAfter=2*mm))
        story.append(Paragraph("Notes", s["label"]))
        story.append(Paragraph(notes.replace("\n", "<br/>"), s["body"]))

    # ── Footer ────────────────────────────────────────────────────────────────
    _build_footer(story, co_name, co_abn, co_email, co_phone,
                  "This document is a Bill / Remittance Advice. "
                  "Please retain for your records.", th, s)

    _cb = _make_page_callback(watermark=watermark, footer=footer)
    doc.build(story, onFirstPage=_cb, onLaterPages=_cb)
    return output_path
