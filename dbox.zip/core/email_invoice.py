# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
dbox - Email Invoice
Sends invoice PDF via email using Python's smtplib.
Supports: Gmail (app password), Outlook, generic SMTP.
Settings stored in the company DB.
"""


import smtplib
import ssl
import os
import base64 as _b64


def _enc_pw(pw: str) -> str:
    """Minimal obfuscation for SMTP password in local SQLite file."""
    return _b64.b64encode(pw.encode()).decode() if pw else ""

def _dec_pw(stored: str) -> str:
    """Decode stored SMTP password."""
    if not stored:
        return ""
    try:
        return _b64.b64decode(stored.encode()).decode()
    except Exception:
        return stored  # backwards-compat: return as-is if not encoded
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

from core.database import get_connection


def get_email_settings(db_path):
    """Retrieve SMTP settings from the database."""
    conn = get_connection(db_path)
    conn.execute("""CREATE TABLE IF NOT EXISTS email_settings (
        id INTEGER PRIMARY KEY CHECK (id=1),
        smtp_host TEXT DEFAULT 'smtp.gmail.com',
        smtp_port INTEGER DEFAULT 587,
        smtp_user TEXT,
        smtp_password TEXT,  -- stored as base64; not encrypted (local DB)
        from_name TEXT,
        from_email TEXT,
        use_tls INTEGER DEFAULT 1,
        invoice_subject TEXT DEFAULT 'Invoice {invoice_number} from {company_name}',
        invoice_body TEXT DEFAULT 'Please find attached your invoice {invoice_number} for {total}.\n\nThank you for your business.\n\n{company_name}',
        overdue_subject TEXT DEFAULT 'Overdue invoice {invoice_number} — {company_name}',
        overdue_body TEXT DEFAULT 'Dear {customer},\n\nThis is a reminder that invoice {invoice_number} for {total} was due on {due_date} and remains unpaid.\n\nPlease arrange payment at your earliest convenience.\n\nRegards,\n{company_name}'
    )""")
    for col, defn in [
        ("overdue_subject", "TEXT DEFAULT 'Overdue invoice {invoice_number} — {company_name}'"),
        ("overdue_body",    "TEXT"),
    ]:
        try:
            conn.execute(f"ALTER TABLE email_settings ADD COLUMN {col} {defn}")
        except Exception:
            pass
    conn.commit()
    row = conn.execute("SELECT * FROM email_settings").fetchone()
    conn.close()
    return dict(row) if row else {}


def save_email_settings(db_path, data):
    get_email_settings(db_path)  # ensures table + columns exist
    conn = get_connection(db_path)
    conn.execute("""INSERT OR REPLACE INTO email_settings
        (id,smtp_host,smtp_port,smtp_user,smtp_password,from_name,from_email,
         use_tls,invoice_subject,invoice_body,overdue_subject,overdue_body)
        VALUES (1,?,?,?,?,?,?,?,?,?,?,?)""",
        (data.get("smtp_host","smtp.gmail.com"),
         int(data.get("smtp_port",587)),
         data.get("smtp_user",""),
         _enc_pw(data.get("smtp_password","")),
         data.get("from_name",""),
         data.get("from_email",""),
         int(data.get("use_tls",1)),
         data.get("invoice_subject","Invoice {invoice_number} from {company_name}"),
         data.get("invoice_body","Please find attached invoice {invoice_number}.\n\nThank you for your business.\n\n{company_name}"),
         data.get("overdue_subject","Overdue invoice {invoice_number} — {company_name}"),
         data.get("overdue_body","")))
    conn.commit()
    conn.close()


def send_invoice_email(db_path, invoice_id, pdf_path, to_email,
                        subject_override=None, body_override=None):
    """
    Send an invoice PDF by email.
    Returns (True, None) on success, (False, error_message) on failure.
    """
    settings = get_email_settings(db_path)
    if not settings.get("smtp_user") or not settings.get("smtp_password"):
        return False, "Email not configured. Go to File → Email Settings."

    conn = get_connection(db_path)
    inv = conn.execute("""SELECT i.*, c.name as cname
        FROM invoices i JOIN contacts c ON i.contact_id=c.id
        WHERE i.id=?""", (invoice_id,)).fetchone()
    company = conn.execute("SELECT * FROM company").fetchone()
    conn.close()

    if not inv:
        return False, "Invoice not found"

    inv = dict(inv)
    co = dict(company) if company else {}
    co_name = co.get("name","Your Company")

    # Template substitution
    tmpl_vars = {
        "invoice_number": inv["invoice_number"],
        "company_name": co_name,
        "total": f"${inv['total']:,.2f}",
        "due_date": inv["due_date"],
        "customer": inv["cname"],
    }

    subject = subject_override or settings.get(
        "invoice_subject","Invoice {invoice_number} from {company_name}")
    body    = body_override or settings.get(
        "invoice_body","Please find attached invoice {invoice_number}.\n\nThank you.\n\n{company_name}")

    for k, v in tmpl_vars.items():
        subject = subject.replace("{"+k+"}", v)
        body    = body.replace("{"+k+"}", v)

    # Build message
    msg = MIMEMultipart()
    from_addr = settings.get("from_email") or settings.get("smtp_user","")
    from_name = settings.get("from_name") or co_name
    msg["From"]    = f"{from_name} <{from_addr}>"
    msg["To"]      = to_email
    msg["Subject"] = subject

    msg.attach(MIMEText(body, "plain"))

    # Attach PDF
    fname = os.path.basename(pdf_path)
    with open(pdf_path, "rb") as f:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(f.read())
    encoders.encode_base64(part)
    part.add_header("Content-Disposition", f'attachment; filename="{fname}"')
    msg.attach(part)

    # Send
    try:
        context = ssl.create_default_context()
        port = int(settings.get("smtp_port", 587))
        host = settings.get("smtp_host","smtp.gmail.com")
        use_tls = int(settings.get("use_tls",1))

        if port == 465:
            with smtplib.SMTP_SSL(host, port, context=context) as server:
                server.login(settings["smtp_user"], _dec_pw(settings["smtp_password"]))
                server.sendmail(from_addr, to_email, msg.as_string())
        else:
            with smtplib.SMTP(host, port) as server:
                if use_tls:
                    server.starttls(context=context)
                server.login(settings["smtp_user"], _dec_pw(settings["smtp_password"]))
                server.sendmail(from_addr, to_email, msg.as_string())

        return True, None
    except smtplib.SMTPAuthenticationError:
        return False, ("Authentication failed.\n\nFor Gmail: use an App Password "
                       "(Google Account → Security → 2-Step Verification → App passwords).\n"
                       "For Outlook: enable SMTP AUTH in your account settings.")
    except smtplib.SMTPException as e:
        return False, f"SMTP error: {e}"
    except Exception as e:
        return False, f"Error: {e}"

def send_pdf_email(db_path, pdf_path, to_email, subject, body):
    """Send any PDF as an email attachment. Returns (True, None) or (False, error)."""
    settings = get_email_settings(db_path)
    if not settings.get("smtp_user") or not settings.get("smtp_password"):
        return False, "Email not configured. Go to Settings → Email."

    conn = get_connection(db_path)
    company = conn.execute("SELECT * FROM company LIMIT 1").fetchone()
    conn.close()
    co = dict(company) if company else {}
    co_name = co.get("name", "Your Company")

    msg = MIMEMultipart()
    from_addr = settings.get("from_email") or settings.get("smtp_user", "")
    from_name = settings.get("from_name") or co_name
    msg["From"]    = f"{from_name} <{from_addr}>"
    msg["To"]      = to_email
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    fname = os.path.basename(pdf_path)
    with open(pdf_path, "rb") as f:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(f.read())
    encoders.encode_base64(part)
    part.add_header("Content-Disposition", f'attachment; filename="{fname}"')
    msg.attach(part)

    try:
        context = ssl.create_default_context()
        port = int(settings.get("smtp_port", 587))
        host = settings.get("smtp_host", "smtp.gmail.com")
        use_tls = int(settings.get("use_tls", 1))

        if port == 465:
            with smtplib.SMTP_SSL(host, port, context=context) as server:
                server.login(settings["smtp_user"], _dec_pw(settings["smtp_password"]))
                server.sendmail(from_addr, to_email, msg.as_string())
        else:
            with smtplib.SMTP(host, port) as server:
                if use_tls:
                    server.starttls(context=context)
                server.login(settings["smtp_user"], _dec_pw(settings["smtp_password"]))
                server.sendmail(from_addr, to_email, msg.as_string())
        return True, None
    except smtplib.SMTPAuthenticationError:
        return False, ("Authentication failed. For Gmail: use an App Password "
                       "(Google Account → Security → 2-Step Verification → App passwords).")
    except smtplib.SMTPException as e:
        return False, f"SMTP error: {e}"
    except Exception as e:
        return False, f"Error: {e}"


def send_overdue_notice(db_path, invoice_id, to_email,
                        subject_override=None, body_override=None):
    """
    Send an overdue notice for an invoice. Generates the PDF with the OVERDUE
    stamp forced on (regardless of overdue_suppress flag) and emails it.
    Returns (True, None) on success, (False, error_message) on failure.
    """
    from core.invoice_pdf import generate_invoice_pdf
    import tempfile, os
    from datetime import date as _today

    settings = get_email_settings(db_path)
    if not settings.get("smtp_user") or not settings.get("smtp_password"):
        return False, "Email not configured. Go to Settings → Email."

    conn = get_connection(db_path)
    inv = conn.execute("""SELECT i.*, c.name as cname, c.email as cemail
        FROM invoices i JOIN contacts c ON i.contact_id=c.id
        WHERE i.id=?""", (invoice_id,)).fetchone()
    company = conn.execute("SELECT * FROM company LIMIT 1").fetchone()
    conn.close()

    if not inv:
        return False, "Invoice not found"

    inv = dict(inv)
    co  = dict(company) if company else {}
    co_name = co.get("name", "Your Company")

    due = inv.get("due_date", "")
    try:
        days_overdue = (_today.today() - _today.fromisoformat(due)).days
    except Exception:
        days_overdue = 0

    tmpl_vars = {
        "invoice_number": inv["invoice_number"],
        "company_name":   co_name,
        "total":          f"${inv['total']:,.2f}",
        "due_date":       due,
        "days_overdue":   str(max(0, days_overdue)),
        "customer":       inv["cname"],
    }

    default_subj = "Overdue invoice {invoice_number} — {company_name}"
    default_body = (
        "Dear {customer},\n\n"
        "This is a reminder that invoice {invoice_number} for {total} was due on "
        "{due_date} and remains unpaid.\n\n"
        "Please arrange payment at your earliest convenience.\n\n"
        "Regards,\n{company_name}"
    )
    subject = subject_override or settings.get("overdue_subject") or default_subj
    body    = body_override    or settings.get("overdue_body")    or default_body

    for k, v in tmpl_vars.items():
        subject = subject.replace("{" + k + "}", v)
        body    = body.replace("{" + k + "}", v)

    tmp = tempfile.mktemp(suffix=".pdf", prefix=f"{inv['invoice_number']}_OVERDUE_")
    try:
        from core.licence import get_licence_status, watermark_text, pdf_footer_text, pdf_branding_footer
        import os as _os
        _app_dir = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
        _lic = get_licence_status(_app_dir)
        _footer = pdf_footer_text(_lic)
        if not _footer:
            try:
                _row = get_connection(db_path).execute(
                    "SELECT pdf_branding FROM company WHERE id=1").fetchone()
                if _row is None or int(_row["pdf_branding"] if _row["pdf_branding"] is not None else 1):
                    _footer = pdf_branding_footer(_lic)
            except Exception:
                _footer = pdf_branding_footer(_lic)
        generate_invoice_pdf(db_path, invoice_id, tmp, force_overdue=True,
                             watermark=watermark_text(_lic),
                             footer=_footer)
        ok_flag, msg = send_pdf_email(db_path, tmp, to_email, subject, body)
        if ok_flag:
            # stamp the invoice so the PDF watermark persists
            c2 = get_connection(db_path)
            c2.execute("UPDATE invoices SET overdue_suppress=0 WHERE id=?", (invoice_id,))
            c2.commit()
            c2.close()
        return ok_flag, msg
    finally:
        try: os.unlink(tmp)
        except Exception: pass


def send_raw_email(db_path, to_email, subject, body):
    """
    Send a plain-text email (no attachment).
    Returns (True, None) on success, (False, error_message) on failure.
    Used for reminder/chase emails and other non-invoice notifications.
    """
    settings = get_email_settings(db_path)
    if not settings.get("smtp_user") or not settings.get("smtp_password"):
        return False, "Email not configured. Go to File > Email Settings."

    conn = get_connection(db_path)
    company = conn.execute("SELECT * FROM company LIMIT 1").fetchone()
    conn.close()
    co = dict(company) if company else {}
    co_name = co.get("name", "Your Company")

    msg = MIMEMultipart()
    from_addr = settings.get("from_email") or settings.get("smtp_user", "")
    from_name = settings.get("from_name") or co_name
    msg["From"]    = f"{from_name} <{from_addr}>"
    msg["To"]      = to_email
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    try:
        context = ssl.create_default_context()
        port = int(settings.get("smtp_port", 587))
        host = settings.get("smtp_host", "")
        user = settings.get("smtp_user", "")
        pw   = settings.get("smtp_password", "")
        use_tls = settings.get("use_tls", True)

        if port == 465:
            with smtplib.SMTP_SSL(host, port, context=context) as server:
                server.login(user, pw)
                server.sendmail(from_addr, to_email, msg.as_string())
        else:
            with smtplib.SMTP(host, port) as server:
                server.ehlo()
                if use_tls:
                    server.starttls(context=context)
                server.login(user, pw)
                server.sendmail(from_addr, to_email, msg.as_string())
        return True, None
    except Exception as e:
        return False, str(e)

