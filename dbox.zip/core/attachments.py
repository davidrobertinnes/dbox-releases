# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
dbox - Attachment Manager
Store, retrieve and delete file attachments linked to any transaction.
Files are stored as BLOBs inside the .dbox SQLite file — fully portable.
"""


import os
import mimetypes
import tempfile
import subprocess
import sys
from core.database import get_connection


# ── MIME helpers ──────────────────────────────────────────────────────────────

IMAGE_TYPES = {"image/png", "image/jpeg", "image/gif", "image/bmp",
               "image/webp", "image/tiff"}
PDF_TYPE    = "application/pdf"

def _mime(filename):
    mt, _ = mimetypes.guess_type(filename)
    return mt or "application/octet-stream"

def _fmt_size(n):
    if n < 1024:
        return f"{n} B"
    elif n < 1024**2:
        return f"{n/1024:.1f} KB"
    else:
        return f"{n/1024**2:.1f} MB"


# ── CRUD ──────────────────────────────────────────────────────────────────────

def get_attachments(db_path, source_type, source_id):
    """Return list of attachment metadata (no blob data)."""
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT id, source_type, source_id, filename, mime_type,
               file_size, description, uploaded_at
        FROM attachments
        WHERE source_type=? AND source_id=?
        ORDER BY uploaded_at""",
        (source_type, source_id)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def add_attachment(db_path, source_type, source_id, file_path, description=""):
    """Read a file from disk and store it in the database."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    filename  = os.path.basename(file_path)
    mime_type = _mime(filename)
    with open(file_path, "rb") as f:
        data = f.read()
    file_size = len(data)
    conn = get_connection(db_path)
    conn.execute("""INSERT INTO attachments
        (source_type, source_id, filename, mime_type, file_size,
         file_data, description)
        VALUES (?,?,?,?,?,?,?)""",
        (source_type, source_id, filename, mime_type,
         file_size, data, description))
    conn.commit()
    conn.close()
    return file_size


def delete_attachment(db_path, attachment_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM attachments WHERE id=?", (attachment_id,))
    conn.commit()
    conn.close()


def get_attachment_data(db_path, attachment_id):
    """Return full attachment row including blob data."""
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT * FROM attachments WHERE id=?", (attachment_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def export_attachment(db_path, attachment_id, dest_dir=None):
    """
    Write attachment to a temp file and return the path.
    Caller is responsible for cleanup.
    """
    att = get_attachment_data(db_path, attachment_id)
    if not att:
        raise ValueError("Attachment not found")
    if dest_dir is None:
        dest_dir = tempfile.mkdtemp()
    out_path = os.path.join(dest_dir, att["filename"])
    with open(out_path, "wb") as f:
        f.write(att["file_data"])
    return out_path


def open_attachment(db_path, attachment_id):
    """Export to temp file and open with the system default application."""
    path = export_attachment(db_path, attachment_id)
    if sys.platform == "win32":
        os.startfile(path)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])
    return path


def get_image_thumbnail(db_path, attachment_id, size=(80, 80)):
    """
    Return a PIL Image thumbnail for image attachments, or None.
    Requires Pillow — gracefully returns None if not installed.
    """
    try:
        from PIL import Image
        import io
        att = get_attachment_data(db_path, attachment_id)
        if not att or att["mime_type"] not in IMAGE_TYPES:
            return None
        img = Image.open(io.BytesIO(att["file_data"]))
        img.thumbnail(size, Image.LANCZOS)
        return img
    except Exception:
        return None


def attachment_count(db_path, source_type, source_id):
    conn = get_connection(db_path)
    n = conn.execute("""SELECT COUNT(*) FROM attachments
        WHERE source_type=? AND source_id=?""",
        (source_type, source_id)).fetchone()[0]
    conn.close()
    return n
