"""
dbox - Logo Colour Extractor
Analyses a logo image and derives a harmonious document colour palette.

Algorithm:
  1. Strip transparent + near-white background pixels
  2. K-means cluster remaining pixels into dominant colours
  3. Pick the most vivid (saturated × bright) cluster as PRIMARY
  4. Derive a darker SECONDARY shade for the totals bar
  5. Derive a pale TINT for payment-box backgrounds
  6. Choose white or black text based on WCAG luminance contrast
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.


import colorsys
import json
import os
from PIL import Image


# ── Colour math ───────────────────────────────────────────────────────────────

def _hex(r, g, b):
    return f"#{int(r):02x}{int(g):02x}{int(b):02x}"

def _from_hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def _luminance(r, g, b):
    def c(v):
        v /= 255
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    return 0.2126*c(r) + 0.7152*c(g) + 0.0722*c(b)

def _contrast(hex1, hex2):
    l1 = _luminance(*_from_hex(hex1))
    l2 = _luminance(*_from_hex(hex2))
    hi, lo = max(l1,l2), min(l1,l2)
    return (hi + 0.05) / (lo + 0.05)

def _vividness(r, g, b):
    _, s, v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
    return s * v                    # saturation × brightness

def _darken(r, g, b, factor=0.38):
    h, s, v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
    v2 = max(0.0, v * (1 - factor))
    s2 = min(1.0, s * 1.05)
    return tuple(int(x*255) for x in colorsys.hsv_to_rgb(h, s2, v2))

def _lighten(r, g, b, factor=0.55):
    h, s, v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
    v2 = min(1.0, v + (1-v)*factor)
    s2 = max(0.0, s * (1 - factor*0.6))
    return tuple(int(x*255) for x in colorsys.hsv_to_rgb(h, s2, v2))

def _tint(r, g, b, strength=0.10):
    """Very pale wash — almost white with a hint of the colour."""
    return (
        int(255*(1-strength) + r*strength),
        int(255*(1-strength) + g*strength),
        int(255*(1-strength) + b*strength),
    )

def _muted(r, g, b, desat=0.45):
    """Desaturated version — good for rule lines and labels."""
    h, s, v = colorsys.rgb_to_hsv(r/255, g/255, b/255)
    s2 = max(0, s*(1-desat))
    v2 = min(1.0, v*1.1)
    return tuple(int(x*255) for x in colorsys.hsv_to_rgb(h, s2, v2))

def _best_text(bg_hex):
    white_cr = _contrast(bg_hex, "#ffffff")
    black_cr = _contrast(bg_hex, "#1a1a1a")
    return "#ffffff" if white_cr >= black_cr else "#1a1a1a"

def _mix(hex1, hex2, ratio=0.5):
    r1,g1,b1 = _from_hex(hex1)
    r2,g2,b2 = _from_hex(hex2)
    return _hex(int(r1*(1-ratio)+r2*ratio),
                int(g1*(1-ratio)+g2*ratio),
                int(b1*(1-ratio)+b2*ratio))


# ── K-means ───────────────────────────────────────────────────────────────────

def _kmeans(pixels, k=8, iterations=14):
    import random
    if not pixels:
        return []
    k = min(k, len(pixels))
    centroids = random.sample(pixels, k)
    for _ in range(iterations):
        clusters = [[] for _ in range(k)]
        for px in pixels:
            best = min(range(k),
                key=lambda i: sum((px[c]-centroids[i][c])**2 for c in range(3)))
            clusters[best].append(px)
        new_c = []
        for i, cl in enumerate(clusters):
            if cl:
                n = len(cl)
                new_c.append(tuple(int(sum(p[j] for p in cl)/n) for j in range(3)))
            else:
                new_c.append(centroids[i])
        if new_c == centroids:
            break
        centroids = new_c
    # Sort by cluster weight (largest first)
    weighted = sorted(
        [(centroids[i], len(clusters[i])) for i in range(k) if clusters[i]],
        key=lambda x: -x[1])
    return [w[0] for w in weighted]


# ── Main extraction ───────────────────────────────────────────────────────────

def extract_logo_palette(logo_path, n_clusters=10):
    """
    Returns a palette dict, or None if the logo is essentially greyscale.
    """
    img = Image.open(logo_path).convert("RGBA")
    w, h = img.size
    if w > 250:
        img = img.resize((250, int(h*250/w)), Image.LANCZOS)

    pixels = list(img.getdata())

    # Strip transparent + near-white + pure-grey pixels
    filtered = []
    for r, g, b, a in pixels:
        if a < 100:
            continue
        if r > 232 and g > 232 and b > 232:    # near white
            continue
        if r < 18 and g < 18 and b < 18:       # near black
            continue
        _, s, _ = colorsys.rgb_to_hsv(r/255, g/255, b/255)
        if s < 0.08:                            # desaturated grey
            continue
        filtered.append((r, g, b))

    if len(filtered) < 30:
        # Relax: include greys but not pure white/black
        filtered = [(r,g,b) for r,g,b,a in pixels
                    if a >= 100 and not (r>232 and g>232 and b>232)]

    if len(filtered) < 15:
        return None

    clusters = _kmeans(filtered, k=min(n_clusters, max(1, len(filtered)//8)))
    if not clusters:
        return None

    # Rank by vividness × relative cluster weight
    scored = [(c, _vividness(*c)) for c in clusters if _vividness(*c) > 0.05]
    if not scored:
        scored = [(c, _vividness(*c)) for c in clusters]
    scored.sort(key=lambda x: -x[1])
    primary_rgb = scored[0][0]

    p = _hex(*primary_rgb)
    s = _hex(*_darken(*primary_rgb))
    tint = _hex(*_tint(*primary_rgb))
    muted = _hex(*_muted(*primary_rgb))
    light = _hex(*_lighten(*primary_rgb, 0.45))

    return {
        "primary":         p,
        "secondary":       s,
        "tint":            tint,
        "muted":           muted,
        "light":           light,
        "text_on_primary": _best_text(p),
        "text_on_secondary": _best_text(s),
    }


def palette_to_doc_theme(palette):
    """Convert raw palette into the invoice_pdf doc_theme dict."""
    if not palette:
        return None
    p  = palette["primary"]
    s  = palette["secondary"]
    t  = palette["tint"]
    mu = palette["muted"]
    tp = palette["text_on_primary"]
    ts = palette["text_on_secondary"]

    # rule colour: very light mix of tint and white
    rule = _mix(t, "#ffffff", 0.35)
    # row alt: extremely subtle tint
    row_alt = _mix(t, "#ffffff", 0.15)

    return {
        "header_bg":          p,
        "header_text":        tp,
        "accent_bar":         p,
        "total_bar_bg":       s,
        "total_bar_text":     ts,
        "rule_colour":        rule,
        "payment_box_bg":     t,
        "payment_box_border": p,
        "label_colour":       mu,
        "row_alt":            row_alt,
        "body_text":          "#1a1a2e",
        "dim_text":           "#4a5568",
    }


# ── Persistence ───────────────────────────────────────────────────────────────

def save_doc_theme(db_path, doc_theme):
    """Persist doc_theme JSON into the company table."""
    from core.database import get_connection
    conn = get_connection(db_path)
    try:
        conn.execute("ALTER TABLE company ADD COLUMN doc_theme TEXT")
    except Exception:
        pass  # column already exists
    try:
        conn.execute("UPDATE company SET doc_theme=? WHERE id=1",
                     (json.dumps(doc_theme) if doc_theme else None,))
        conn.commit()
    finally:
        conn.close()


def clear_doc_theme(db_path):
    save_doc_theme(db_path, None)


def load_doc_theme(db_path):
    """Load doc_theme from company table, or None."""
    from core.database import get_connection
    try:
        conn = get_connection(db_path)
        try:
            row = conn.execute("SELECT doc_theme FROM company WHERE id=1").fetchone()
        finally:
            conn.close()
        if row and row[0]:
            return json.loads(row[0])
    except Exception:
        pass
    return None
