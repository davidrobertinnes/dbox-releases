"""
core/importer.py — Import data from Xero, MYOB, QuickBooks (IIF), and BAS Off / FAS3.

Each parser returns a normalised dict:
{
  "accounts":  [ {code, name, type, description} ],
  "contacts":  [ {name, contact_type, email, phone, abn, address, payment_terms} ],
  "invoices":  [ {contact_name, invoice_date, due_date, invoice_number, status,
                  lines: [{description, quantity, unit_price, tax_code, account_name}]} ],
  "bills":     [ same structure as invoices ],
  "journals":  [ {date, description, reference,
                  lines: [{account_name, debit, credit, description}]} ],
  "warnings":  [ str ],
}

Callers use import_to_dbox() to write the data into an dbox DB.
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import csv
import io
import re
from datetime import datetime, date


# ── Helpers ───────────────────────────────────────────────────────────────────

def _empty():
    return {"accounts": [], "contacts": [], "invoices": [],
            "bills": [], "journals": [], "warnings": []}

def _parse_date(s, fmts=None):
    if not s:
        return None
    s = str(s).strip()
    fmts = fmts or [
        "%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y",
        "%d %b %Y", "%d %B %Y", "%Y/%m/%d", "%d/%m/%y",
    ]
    for f in fmts:
        try:
            return datetime.strptime(s, f).date().isoformat()
        except ValueError:
            continue
    return None

def _money(s):
    if s is None:
        return 0.0
    try:
        return float(str(s).replace(",", "").replace("$", "").strip() or 0)
    except ValueError:
        return 0.0

def _tax_code(s):
    """Map various tax code names to dbox codes."""
    if not s:
        return "GST"
    s = str(s).upper().strip()
    MAP = {
        "GST":    "GST", "TAX":  "GST", "10%":  "GST", "OUTPUT":  "GST",
        "INPUT":  "GST", "GSTONIMPORTS": "GST",
        "FRE":    "FRE", "EXEMPT": "FRE", "E":   "FRE", "ZERO":    "FRE",
        "FREE":   "FRE", "ZEERATED": "FRE", "BAS EXCLUDED": "N-T",
        "N-T":    "N-T", "NT":   "N-T", "OUT OF SCOPE": "N-T", "NONE": "N-T",
        "CAP":    "CAP", "CAPITAL": "CAP",
        "INP":    "INP",
    }
    return MAP.get(s, "GST")

def _account_type(s):
    """Map foreign account type names to dbox types."""
    if not s:
        return "Expense"
    s = str(s).title().strip()
    MAP = {
        "Bank":              "Bank",
        "Current Asset":     "Current Asset",
        "Current Assets":    "Current Asset",
        "Fixed Asset":       "Fixed Asset",
        "Fixed Assets":      "Fixed Asset",
        "Non-Current Asset": "Fixed Asset",
        "Inventory":         "Current Asset",
        "Current Liability": "Current Liability",
        "Current Liabilities": "Current Liability",
        "Non-Current Liability": "Non-Current Liability",
        "Long Term Liability": "Non-Current Liability",
        "Equity":            "Equity",
        "Revenue":           "Revenue",
        "Sales":             "Revenue",
        "Income":            "Revenue",
        "Other Income":      "Revenue",
        "Cost Of Sales":     "Cost of Sales",
        "Direct Costs":      "Cost of Sales",
        "Expense":           "Expense",
        "Expenses":          "Expense",
        "Overhead":          "Expense",
        "Other Expense":     "Expense",
        "Accounts Receivable": "Accounts Receivable",
        "Accounts Payable":  "Accounts Payable",
    }
    for k, v in MAP.items():
        if k.lower() in s.lower():
            return v
    return "Expense"


# ══════════════════════════════════════════════════════════════════════════════
#  XERO CSV IMPORT
# ══════════════════════════════════════════════════════════════════════════════

def parse_xero(file_path: str) -> dict:
    """
    Parse a Xero CSV export.  Xero exports separate CSVs for different entity
    types; we detect which one this is from the header row.

    Supported Xero CSV types:
      - Chart of Accounts: Code, Name, Type, Tax, Description, [YTD]
      - Contacts:          ContactName, EmailAddress, FirstName, LastName,
                           PhoneNumber, AccountNumber, TaxNumber (ABN)...
      - Invoices/Quotes:   ContactName, EmailAddress, POAddressLine1, ...
                           InvoiceNumber, Reference, InvoiceDate, DueDate,
                           InventoryItemCode, Description, Quantity,
                           UnitAmount, Discount, AccountCode, TaxType, ...
    """
    result = _empty()
    with open(file_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    if not rows:
        result["warnings"].append("File appears empty.")
        return result

    headers = set(rows[0].keys())

    # ── Chart of Accounts ─────────────────────────────────────────────────
    if "Code" in headers and "Type" in headers and "Name" in headers \
            and "ContactName" not in headers:
        for row in rows:
            if not row.get("Name"):
                continue
            result["accounts"].append({
                "code":        row.get("Code", "").strip(),
                "name":        row["Name"].strip(),
                "type":        _account_type(row.get("Type", "")),
                "description": row.get("Description", "").strip(),
            })
        return result

    # ── Contacts ──────────────────────────────────────────────────────────
    if "ContactName" in headers and "InvoiceNumber" not in headers:
        for row in rows:
            name = row.get("ContactName", "").strip()
            if not name:
                continue
            # Determine type from AccountNumber prefix or assume Customer
            is_supplier = bool(row.get("AccountNumber", "").upper().startswith("S"))
            result["contacts"].append({
                "name":          name,
                "contact_type":  "Supplier" if is_supplier else "Customer",
                "email":         row.get("EmailAddress", "").strip(),
                "phone":         row.get("PhoneNumber", "").strip(),
                "abn":           row.get("TaxNumber", "").strip(),
                "address":       " ".join(filter(None, [
                    row.get("POAddressLine1", ""),
                    row.get("POCity", ""),
                    row.get("PORegion", ""),
                    row.get("POPostalCode", ""),
                ])).strip(),
                "payment_terms": 30,
            })
        return result

    # ── Invoices / Bills ──────────────────────────────────────────────────
    if "InvoiceNumber" in headers or "ContactName" in headers:
        inv_map = {}
        for row in rows:
            num = row.get("InvoiceNumber", "").strip()
            if not num:
                continue
            if num not in inv_map:
                doc_type = row.get("Type", "ACCREC").upper()
                is_bill = doc_type in ("ACCPAY", "BILL", "PURCHASE")
                inv_map[num] = {
                    "contact_name":     row.get("ContactName", "").strip(),
                    "invoice_number":   num,
                    "invoice_date":     _parse_date(row.get("InvoiceDate", "")),
                    "due_date":         _parse_date(row.get("DueDate", "")),
                    "status":           "Draft",
                    "notes":            row.get("Description", "").strip(),
                    "lines":            [],
                    "_is_bill":         is_bill,
                }
            line = {
                "description": row.get("Description", "").strip(),
                "quantity":    _money(row.get("Quantity", 1)),
                "unit_price":  _money(row.get("UnitAmount", 0)),
                "tax_code":    _tax_code(row.get("TaxType", "")),
                "account_name": row.get("AccountCode", "").strip(),
            }
            if line["description"] or line["unit_price"]:
                inv_map[num]["lines"].append(line)

        for inv in inv_map.values():
            if inv.pop("_is_bill", False):
                result["bills"].append(inv)
            else:
                result["invoices"].append(inv)
        return result

    result["warnings"].append(
        "Could not detect Xero CSV type. Expected headers for Chart of Accounts, "
        "Contacts, or Invoices.")
    return result


# ══════════════════════════════════════════════════════════════════════════════
#  MYOB IMPORT  (AccountRight tab-delimited TXT or CSV)
# ══════════════════════════════════════════════════════════════════════════════

def parse_myob(file_path: str) -> dict:
    """
    Parse a MYOB AccountRight export file (tab-delimited .txt or .csv).

    MYOB exports different entity types in separate files; we detect from
    headers.  Common headers:
      Accounts:  Account Number, Account Name, Account Type, Tax Code, ...
      Contacts:  Co./Last Name, First Name, Card ID, Card Type (Customer/Supplier),
                 Phone 1, Email, ABN, Address 1, Terms...
      Journals:  Date, Memo, Account Number, Debit, Credit, ...
      Invoices:  Customer, Invoice #, Date, Due Date, Item, Description,
                 Qty, Unit Price, Tax Code...
    """
    result = _empty()

    # Try tab-delimited first, then comma
    for delim in ("\t", ","):
        with open(file_path, newline="", encoding="utf-8-sig") as f:
            sample = f.read(512)
        if delim in sample:
            break

    with open(file_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f, delimiter=delim)
        rows = list(reader)

    if not rows:
        result["warnings"].append("File appears empty.")
        return result

    headers = {h.strip() for h in rows[0].keys()}

    # ── Chart of Accounts ─────────────────────────────────────────────────
    if "Account Number" in headers and "Account Name" in headers:
        for row in rows:
            row = {k.strip(): v.strip() for k, v in row.items()}
            name = row.get("Account Name", "")
            if not name:
                continue
            result["accounts"].append({
                "code":        row.get("Account Number", ""),
                "name":        name,
                "type":        _account_type(row.get("Account Type", "")),
                "description": row.get("Description", ""),
            })
        return result

    # ── Contacts (Cards) ──────────────────────────────────────────────────
    if "Co./Last Name" in headers or "Card Type" in headers:
        for row in rows:
            row = {k.strip(): v.strip() for k, v in row.items()}
            last  = row.get("Co./Last Name", "")
            first = row.get("First Name", "")
            name  = f"{first} {last}".strip() if first else last
            if not name:
                continue
            ctype_raw = row.get("Card Type", "Customer").lower()
            ctype = "Supplier" if "supplier" in ctype_raw or "vendor" in ctype_raw \
                    else "Customer"
            terms_str = row.get("Payment Terms", "30") or "30"
            try:
                terms = int(re.search(r"\d+", terms_str).group())
            except Exception:
                terms = 30
            result["contacts"].append({
                "name":          name,
                "contact_type":  ctype,
                "email":         row.get("Email", ""),
                "phone":         row.get("Phone 1", ""),
                "abn":           row.get("ABN", ""),
                "address":       " ".join(filter(None, [
                    row.get("Address 1", ""), row.get("City", ""),
                    row.get("State", ""),    row.get("Postcode", ""),
                ])).strip(),
                "payment_terms": terms,
            })
        return result

    # ── General Journal ───────────────────────────────────────────────────
    if "Debit" in headers and "Credit" in headers and "Account Number" in headers:
        journal_map = {}
        for row in rows:
            row = {k.strip(): v.strip() for k, v in row.items()}
            memo = row.get("Memo", row.get("Description", ""))
            d    = _parse_date(row.get("Date", ""))
            key  = (d, memo)
            if key not in journal_map:
                journal_map[key] = {
                    "date":        d,
                    "description": memo,
                    "reference":   row.get("Job", ""),
                    "lines":       [],
                }
            journal_map[key]["lines"].append({
                "account_name": row.get("Account Name",
                                         row.get("Account Number", "")),
                "debit":        _money(row.get("Debit", 0)),
                "credit":       _money(row.get("Credit", 0)),
                "description":  memo,
            })
        result["journals"] = list(journal_map.values())
        return result

    result["warnings"].append(
        "Could not detect MYOB export type. Expected Accounts, Cards, or Journal headers.")
    return result


# ══════════════════════════════════════════════════════════════════════════════
#  QUICKBOOKS IIF IMPORT
# ══════════════════════════════════════════════════════════════════════════════

def parse_quickbooks_iif(file_path: str) -> dict:
    """
    Parse a QuickBooks IIF (Intuit Interchange Format) file.
    IIF is tab-delimited.  Structure:
      !TRNS <col headers>
      !SPL  <col headers>
      !ENDTRNS
      TRNS  <values...>
      SPL   <values...>
      ENDTRNS
    Also handles !CUST, !VEND, !ACCNT list sections.
    """
    result = _empty()

    with open(file_path, newline="", encoding="utf-8-sig") as f:
        content = f.read()

    lines = content.replace("\r\n", "\n").replace("\r", "\n").split("\n")

    # Parse into sections
    trns_headers = []
    spl_headers  = []
    acc_headers  = []
    cust_headers = []
    vend_headers = []

    current_trns = None
    section      = None

    for raw in lines:
        parts = raw.rstrip("\n").split("\t")
        if not parts or not parts[0]:
            continue
        tag = parts[0].strip().upper()

        if tag == "!TRNS":
            trns_headers = [p.strip() for p in parts[1:]]
            section = "TRNS"
        elif tag == "!SPL":
            spl_headers = [p.strip() for p in parts[1:]]
        elif tag == "!ACCNT":
            acc_headers = [p.strip() for p in parts[1:]]
            section = "ACCNT"
        elif tag == "!CUST":
            cust_headers = [p.strip() for p in parts[1:]]
            section = "CUST"
        elif tag == "!VEND":
            vend_headers = [p.strip() for p in parts[1:]]
            section = "VEND"
        elif tag == "ACCNT" and acc_headers:
            row = dict(zip(acc_headers, parts[1:]))
            result["accounts"].append({
                "code":        row.get("ACCNUM", ""),
                "name":        row.get("NAME", ""),
                "type":        _account_type(row.get("ACCTYPE", "")),
                "description": row.get("DESC", ""),
            })
        elif tag == "CUST" and cust_headers:
            row = dict(zip(cust_headers, parts[1:]))
            name = row.get("NAME", "").strip()
            if name:
                result["contacts"].append({
                    "name":          name,
                    "contact_type":  "Customer",
                    "email":         row.get("EMAIL", ""),
                    "phone":         row.get("PHONE1", ""),
                    "abn":           "",
                    "address":       " ".join(filter(None, [
                        row.get("BADDR1", ""), row.get("BADDR2", ""),
                        row.get("BADDR3", ""), row.get("BADDR4", ""),
                    ])).strip(),
                    "payment_terms": 30,
                })
        elif tag == "VEND" and vend_headers:
            row = dict(zip(vend_headers, parts[1:]))
            name = row.get("NAME", "").strip()
            if name:
                result["contacts"].append({
                    "name":          name,
                    "contact_type":  "Supplier",
                    "email":         row.get("EMAIL", ""),
                    "phone":         row.get("PHONE1", ""),
                    "abn":           row.get("TAXID", ""),
                    "address":       " ".join(filter(None, [
                        row.get("BADDR1", ""), row.get("BADDR2", ""),
                        row.get("BADDR3", ""), row.get("BADDR4", ""),
                    ])).strip(),
                    "payment_terms": 30,
                })
        elif tag == "TRNS" and trns_headers:
            row = dict(zip(trns_headers, parts[1:]))
            current_trns = {
                "date":        _parse_date(row.get("DATE", "")),
                "description": row.get("MEMO", ""),
                "reference":   row.get("DOCNUM", row.get("REFNUM", "")),
                "contact":     row.get("NAME", ""),
                "trns_type":   row.get("TRNSTYPE", ""),
                "account":     row.get("ACCNT", ""),
                "amount":      _money(row.get("AMOUNT", 0)),
                "lines":       [],
            }
        elif tag == "SPL" and spl_headers and current_trns:
            row = dict(zip(spl_headers, parts[1:]))
            current_trns["lines"].append({
                "account_name": row.get("ACCNT", ""),
                "debit":   max(0.0, _money(row.get("AMOUNT", 0))),
                "credit":  max(0.0, -_money(row.get("AMOUNT", 0))),
                "description": row.get("MEMO", current_trns["description"]),
            })
        elif tag == "ENDTRNS" and current_trns:
            # Convert to journal entry
            if current_trns["lines"]:
                result["journals"].append({
                    "date":        current_trns["date"],
                    "description": current_trns["description"] or current_trns["trns_type"],
                    "reference":   current_trns["reference"],
                    "lines":       current_trns["lines"],
                })
            current_trns = None

    return result


# ══════════════════════════════════════════════════════════════════════════════
#  BAS OFF / FAS3 IMPORT  (general journal CSV or bank transaction CSV)
# ══════════════════════════════════════════════════════════════════════════════

def parse_basoff(file_path: str) -> dict:
    """
    Parse a BAS Off / FAS3 (Free Accounting Software) export.
    FAS3 exports bank transactions as CSV with columns:
      Date, Description/Narration, Debit, Credit  (or Amount with +/-)
    Also handles a general journal CSV with:
      Date, Account, Description, Debit, Credit, Reference
    And contact/account exports with recognisable headers.
    """
    result = _empty()
    with open(file_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    if not rows:
        result["warnings"].append("File appears empty.")
        return result

    headers = {h.strip().lower() for h in rows[0].keys()}
    raw_headers = list(rows[0].keys())

    def h(name):
        """Find header key case-insensitively."""
        for k in raw_headers:
            if k.strip().lower() == name.lower():
                return k
        return None

    # ── General Journal (has Account column) ──────────────────────────────
    if any(hdr in headers for hdr in ("account", "account name", "account number")):
        acc_key  = h("account") or h("account name") or h("account number")
        date_key = h("date") or h("transaction date")
        # FAS3 transactions list uses "Comment" / "Line comment" for description
        desc_key = (h("description") or h("narration") or h("memo")
                    or h("comment") or h("line comment"))
        dr_key   = h("debit") or h("dr")
        cr_key   = h("credit") or h("cr")
        # FAS3 transactions list uses "Document number" / "Transaction number" for reference
        ref_key  = (h("reference") or h("ref")
                    or h("document number") or h("transaction number"))
        # Group multi-line transactions by transaction number where available
        grp_key  = h("transaction number") or h("document number")
        amt_key  = h("amount")
        lc_key   = h("line comment")

        journal_map = {}
        for row in rows:
            d    = _parse_date(row.get(date_key or "", ""))
            desc = row.get(desc_key or "", "").strip() if desc_key else ""
            ref  = row.get(ref_key or "", "").strip() if ref_key else ""
            grp  = row.get(grp_key or "", "").strip() if grp_key else ""
            # Group by transaction number if available; otherwise by date+desc+ref
            key  = (d, grp) if grp else (d, desc, ref)
            if key not in journal_map:
                journal_map[key] = {
                    "date": d, "description": desc,
                    "reference": ref, "lines": [],
                }
            dr = _money(row.get(dr_key or "", 0)) if dr_key else 0.0
            cr = _money(row.get(cr_key or "", 0)) if cr_key else 0.0
            # If only one Amount column, use sign
            if not dr_key and not cr_key and amt_key:
                amt = _money(row.get(amt_key, 0))
                dr, cr = (amt, 0) if amt >= 0 else (0, -amt)
            # Use line comment for per-line description if available
            line_desc = row.get(lc_key, "").strip() if lc_key else desc
            journal_map[key]["lines"].append({
                "account_name": row.get(acc_key or "", ""),
                "debit":        dr,
                "credit":       cr,
                "description":  line_desc or desc,
            })
        result["journals"] = list(journal_map.values())
        return result

    # ── Bank transaction list (Date, Description, Amount/Debit/Credit) ────
    date_key = h("date") or h("transaction date") or h("value date")
    desc_key = h("description") or h("narration") or h("details") or h("particulars")
    amt_key  = h("amount")
    dr_key   = h("debit") or h("dr") or h("withdrawals")
    cr_key   = h("credit") or h("cr") or h("deposits")

    if date_key and desc_key and (amt_key or dr_key or cr_key):
        for row in rows:
            d    = _parse_date(row.get(date_key, ""))
            desc = row.get(desc_key, "").strip() if desc_key else ""
            if amt_key:
                amt = _money(row.get(amt_key, 0))
                dr = max(0.0, -amt)
                cr = max(0.0, amt)
            else:
                dr = _money(row.get(dr_key or "", 0)) if dr_key else 0.0
                cr = _money(row.get(cr_key or "", 0)) if cr_key else 0.0
            if not d:
                continue
            result["journals"].append({
                "date":        d,
                "description": desc,
                "reference":   "",
                "lines": [
                    {"account_name": "Bank", "debit": cr, "credit": dr,
                     "description": desc},
                    {"account_name": "Suspense", "debit": dr, "credit": cr,
                     "description": desc},
                ],
            })
        if not result["journals"]:
            result["warnings"].append("No parseable bank transactions found.")
        else:
            result["warnings"].append(
                f"Bank transactions imported as journals to Suspense account. "
                f"Please re-categorise in Bank Reconciliation.")
        return result

    result["warnings"].append(
        "Could not detect BAS Off/FAS3 file type. "
        "Expected: journal CSV (Account, Date, Debit, Credit) or "
        "bank CSV (Date, Description, Amount/Debit/Credit).")
    return result


# ══════════════════════════════════════════════════════════════════════════════
#  BAS OFF / FAS3 GLENIX XML IMPORT
# ══════════════════════════════════════════════════════════════════════════════

def parse_basoff_xml(file_path: str) -> dict:
    """
    Parse a BAS Off / FAS3 Glenix XML export.
    The XML uses the namespace http://www.glenix.com.au/ and contains
    account, contact, and transaction data.

    Classification mapping:
      income / revenue  → Revenue
      expense / overhead → Expense
      asset             → Current Asset
      liability         → Current Liability
      equity            → Equity
      distribution      → Equity
    """
    import xml.etree.ElementTree as ET

    result = _empty()
    NS = "http://www.glenix.com.au/"

    def gx(tag):
        return f"{{{NS}}}{tag}"

    def text(el, tag):
        child = el.find(gx(tag))
        return (child.text or "").strip() if child is not None else ""

    TYPE_MAP = {
        "income":       "Revenue",
        "revenue":      "Revenue",
        "expense":      "Expense",
        "overhead":     "Expense",
        "asset":        "Current Asset",
        "fixedasset":   "Fixed Asset",
        "liability":    "Current Liability",
        "equity":       "Equity",
        "distribution": "Equity",
        "bank":         "Bank",
        "receivable":   "Accounts Receivable",
        "payable":      "Accounts Payable",
    }

    try:
        tree = ET.parse(file_path)
    except ET.ParseError as e:
        result["warnings"].append(f"XML parse error: {e}")
        return result

    root = tree.getroot()
    business = root.find(gx("business"))
    if business is None:
        # Root may be the business element itself
        business = root

    for txn in business.findall(gx("transaction")):
        for line in txn.findall(gx("transactionLine")):

            # ── Account record ────────────────────────────────────────────
            acc_el = line.find(gx("account"))
            if acc_el is not None:
                name  = text(acc_el, "accountName")
                if not name:
                    continue
                active = text(acc_el, "accountActive").lower()
                if active == "false":
                    continue
                cls   = text(acc_el, "accountClassificationReference").lower()
                code  = text(acc_el, "accountIdentifier")
                desc  = text(acc_el, "accountDescription")
                atype = TYPE_MAP.get(cls, "Expense")
                result["accounts"].append({
                    "code":        code,
                    "name":        name,
                    "type":        atype,
                    "description": desc,
                })
                continue

            # ── Contact record ────────────────────────────────────────────
            contact_el = line.find(gx("contact"))
            if contact_el is None:
                contact_el = line.find(gx("counterparty"))
            if contact_el is not None:
                name = (text(contact_el, "contactName") or
                        text(contact_el, "counterpartyLegalName") or
                        text(contact_el, "name"))
                if not name:
                    continue
                ctype_raw = text(contact_el, "contactType").lower()
                ctype = "Supplier" if "supplier" in ctype_raw or "vendor" in ctype_raw \
                        else "Customer"
                result["contacts"].append({
                    "name":          name,
                    "contact_type":  ctype,
                    "email":         text(contact_el, "email"),
                    "phone":         text(contact_el, "phone"),
                    "abn":           text(contact_el, "abn"),
                    "address":       text(contact_el, "address"),
                    "payment_terms": 30,
                })
                continue

    if not result["accounts"] and not result["contacts"]:
        result["warnings"].append(
            "Glenix XML parsed but no accounts or contacts found. "
            "Check the file contains account or contact data.")
    else:
        counts = []
        if result["accounts"]:
            counts.append(f"{len(result['accounts'])} accounts")
        if result["contacts"]:
            counts.append(f"{len(result['contacts'])} contacts")
        result["warnings"].append(
            f"Glenix XML import: {', '.join(counts)} found. "
            "Transactions must be imported separately via the CSV export.")

    return result


# ══════════════════════════════════════════════════════════════════════════════
#  REPORT CSV IMPORT  (P&L, Balance Sheet, Trial Balance → opening balances)
# ══════════════════════════════════════════════════════════════════════════════

# dbox standard chart — (code, name, gl_type, foreign_subtypes, name_keywords)
_DBOX_CHART = [
    # Assets
    ("1-1100", "Cheque Account",                  "Asset",
     ["cash", "bank", "cheque", "checking"],
     ["cheque", "checking", "cash at bank", "operating account", "transaction account",
      "petty cash"]),
    ("1-1110", "Savings Account",                 "Asset",
     [],
     ["savings", "savings account", "term deposit", "offset account"]),
    ("1-1200", "Accounts Receivable",             "Asset",
     ["accountsreceivable", "debtors"],
     ["accounts receivable", "trade receivable", "debtors", "receivable"]),
    ("1-1300", "GST Paid (Input Credits)",        "Asset",
     ["gstpaid", "inputcredits", "inputtax"],
     ["gst paid", "gst input", "input tax credit", "bas refundable",
      "gst free purchases", "gst clearing", "bas asset", "gst receivable"]),
    ("1-1400", "Inventory",                       "Asset",
     ["inventory", "stock"],
     ["inventory", "stock on hand", "trading stock", "raw material"]),
    ("1-1500", "Prepayments",                     "Asset",
     ["prepayment", "prepaid"],
     ["prepayment", "prepaid", "advance payment", "deposit paid"]),
    ("1-2100", "Plant & Equipment",               "Asset",
     [],
     ["plant", "equipment", "machinery", "tools", "furniture", "office equipment",
      "fixtures", "fittings", "software", "intangible", "website", "computer hardware"]),
    ("1-2110", "Accum Depr - Plant & Equipment",  "Asset",
     [],
     ["accum depr plant", "accumulated depreciation plant", "accum dep plant",
      "accum depreciation equip", "accumulated depr equipment"]),
    ("1-2200", "Motor Vehicles",                  "Asset",
     [],
     ["motor vehicle", "vehicle", "car", "van", "truck", "ute", "fleet"]),
    ("1-2210", "Accum Depr - Motor Vehicles",     "Asset",
     [],
     ["accum depr motor", "accumulated depreciation motor", "accum dep vehicle",
      "accumulated depreciation vehicle", "accum depreciation vehicle"]),
    # Liabilities
    ("2-1100", "Accounts Payable",                "Liability",
     ["accountspayable", "creditors"],
     ["accounts payable", "trade payable", "creditors", "payable"]),
    ("2-1200", "GST Collected",                   "Liability",
     ["gstcollected", "gstpayable", "outputtax"],
     ["gst collected", "gst payable", "output tax", "bas liability",
      "gst liability", "bas payable"]),
    ("2-1300", "PAYG Withholding Payable",        "Liability",
     ["payg", "paygwithholding", "taxwithheld"],
     ["payg", "withholding payable", "tax withheld", "payg withholding"]),
    ("2-1400", "Superannuation Payable",          "Liability",
     ["superannuation", "superpayable"],
     ["superannuation payable", "super payable", "super liability",
      "superannuation liability", "super guarantee payable", "sg payable"]),
    ("2-1500", "Credit Card",                     "Liability",
     ["creditcard"],
     ["credit card", "mastercard", "visa", "amex", "american express",
      "diners", "charge card"]),
    ("2-2100", "Bank Loan",                       "Liability",
     ["bankloan", "loan"],
     ["bank loan", "loan payable", "mortgage", "term loan", "borrowing",
      "hire purchase", "finance lease", "equipment loan"]),
    # Equity
    ("3-1100", "Owner Capital",                   "Equity",
     ["ownercapital", "capital"],
     ["owner capital", "capital contribution", "owners equity", "proprietor",
      "share capital", "paid up capital", "contributed equity"]),
    ("3-1200", "Owner Drawings",                  "Equity",
     ["drawings", "drawing"],
     ["drawings", "owner drawings", "proprietor drawings"]),
    ("3-1300", "Retained Earnings",               "Equity",
     ["retainedearnings", "retainedprofit", "accumulatedearnings"],
     ["retained earnings", "retained profit", "accumulated earnings",
      "accumulated profit", "prior year earnings"]),
    # Income
    ("4-1100", "Sales - Goods",                   "Income",
     [],
     ["sales goods", "product sales", "merchandise", "trading income",
      "goods sold", "hardware sales", "parts sales", "retail sales"]),
    ("4-1200", "Sales - Services",                "Income",
     [],
     ["sales service", "service income", "consulting income", "professional fees",
      "labour income", "services rendered"]),
    ("4-1300", "Other Income",                    "Income",
     [],
     ["other income", "sundry income", "miscellaneous income", "grant income"]),
    ("4-1400", "Interest Received",               "Income",
     [],
     ["interest received", "interest income", "bank interest"]),
    # Expenses
    ("5-1100", "Purchases / Cost of Goods Sold",  "Expense",
     [],
     ["cost of goods", "cogs", "cost of sales", "direct material",
      "cost of products", "purchases"]),
    ("5-2100", "Accounting Fees",                 "Expense",
     [],
     ["accounting fee", "bookkeeping", "audit fee", "tax agent", "bas agent"]),
    ("5-2200", "Advertising & Marketing",         "Expense",
     [],
     ["advertising", "marketing", "promotion", "social media"]),
    ("5-2300", "Bank Fees & Charges",             "Expense",
     [],
     ["bank fee", "bank charge", "merchant fee", "eftpos fee", "account fee",
      "transaction fee"]),
    ("5-2400", "Computer Expenses",               "Expense",
     [],
     ["computer expense", "software subscription", "saas", "it expense",
      "technology", "cloud", "hosting", "software"]),
    ("5-2500", "Depreciation",                    "Expense",
     [],
     ["depreciation expense", "amortisation expense", "amortization expense",
      "depr expense"]),
    ("5-2600", "Insurance",                       "Expense",
     [],
     ["insurance", "public liability", "professional indemnity",
      "workers comp", "business insurance"]),
    ("5-2700", "Interest Expense",                "Expense",
     [],
     ["interest expense", "interest paid", "finance charge", "loan interest"]),
    ("5-2800", "Motor Vehicle Expenses",          "Expense",
     [],
     ["motor vehicle expense", "vehicle expense", "fuel", "registration",
      "car expense", "petrol", "fleet expense"]),
    ("5-2900", "Office Supplies",                 "Expense",
     [],
     ["office supplies", "consumables", "office expense"]),
    ("5-3000", "Postage & Freight",               "Expense",
     [],
     ["postage", "freight", "courier", "shipping", "delivery charge"]),
    ("5-3100", "Printing & Stationery",           "Expense",
     [],
     ["printing", "stationery", "print", "binding"]),
    ("5-3200", "Rent & Occupancy",                "Expense",
     [],
     ["rent", "occupancy", "office rent", "premises", "lease expense"]),
    ("5-3300", "Repairs & Maintenance",           "Expense",
     [],
     ["repairs", "maintenance", "repair"]),
    ("5-3400", "Subscriptions",                   "Expense",
     [],
     ["subscription", "membership", "licence fee", "annual fee"]),
    ("5-3500", "Superannuation Expense",          "Expense",
     [],
     ["super expense", "superannuation expense", "super guarantee",
      "employer super", "sg expense"]),
    ("5-3600", "Telephone & Internet",            "Expense",
     [],
     ["telephone", "internet", "mobile phone", "broadband", "data plan"]),
    ("5-3700", "Wages & Salaries",                "Expense",
     ["salariesandwages", "wages"],
     ["wages", "salary", "salaries", "payroll", "labour cost", "staff cost",
      "employee expense"]),
]

# Calculated totals in exported reports — not real GL accounts; skip them
_REPORT_SKIP_TYPES = frozenset({
    "netassets", "noncurrentassets", "currentassets",
    "noncurrentliabilities", "currentliabilities",
    "totalliabilities", "totalassets", "totalequity",
    "total", "subtotal",
})

# Normalise foreign account type strings → dbox gl_type
_TYPE_NORMALISE = {
    "asset":              "Asset",
    "assets":             "Asset",
    "fixedasset":         "Asset",
    "fixedassets":        "Asset",
    "currentasset":       "Asset",
    "currentassets":      "Asset",
    "noncurrentasset":    "Asset",
    "liability":          "Liability",
    "liabilities":        "Liability",
    "currentliability":   "Liability",
    "currentliabilities": "Liability",
    "noncurrentliability": "Liability",
    "equity":             "Equity",
    "retainedearnings":   "Equity",
    "income":             "Income",
    "revenue":            "Income",
    "sales":              "Income",
    "otherincome":        "Income",
    "expense":            "Expense",
    "expenses":           "Expense",
    "overhead":           "Expense",
    "directcost":         "Expense",
    "directcosts":        "Expense",
    "costofsales":        "Expense",
}

# Type-only fallbacks when no keyword matches
_TYPE_FALLBACKS = {
    "Asset":     ("1-1200", "Accounts Receivable",  "Asset"),
    "Liability": ("2-1100", "Accounts Payable",     "Liability"),
    "Equity":    ("3-1100", "Owner Capital",        "Equity"),
    "Income":    ("4-1300", "Other Income",         "Income"),
    "Expense":   ("5-2900", "Office Supplies",      "Expense"),
}


def map_to_dbox_account(source_name: str, source_type: str,
                         source_subtype: str = "") -> dict:
    """
    Map a foreign account to the closest dbox GL account.

    Matching priority:
      1. Exact subtype match  → confidence "high"
      2. Name keyword match   → confidence "medium"  (longest keyword wins)
      3. Type-only fallback   → confidence "low"
      4. No match possible    → confidence "none"

    Args:
        source_name:    Account name from the foreign system.
        source_type:    Account type string (e.g. "asset", "liability", "income").
        source_subtype: Subtype hint from the foreign system (e.g. "accountsreceivable").

    Returns:
        {"code", "name", "gl_type", "confidence", "reason"}
    """
    name_l  = source_name.strip().lower()
    stype_l = (source_type or "").strip().lower().replace(" ", "").replace("-", "")
    ssub_l  = (source_subtype or "").strip().lower().replace(" ", "").replace("-", "")
    gl_type = _TYPE_NORMALISE.get(stype_l, "")

    # 1 — exact foreign subtype match
    if ssub_l:
        for code, acct_name, atype, subtypes, _kw in _DBOX_CHART:
            if ssub_l in subtypes:
                return {"code": code, "name": acct_name, "gl_type": atype,
                        "confidence": "high",
                        "reason": f"subtype match: {source_subtype!r}"}

    # 2 — name keyword match (restrict to correct GL type when known)
    best = None
    best_score = 0
    for code, acct_name, atype, _sub, keywords in _DBOX_CHART:
        if gl_type and atype != gl_type:
            continue
        for kw in keywords:
            if kw in name_l:
                score = len(kw)
                if score > best_score:
                    best_score = score
                    best = (code, acct_name, atype, kw)
                break

    if best:
        code, acct_name, atype, kw = best
        return {"code": code, "name": acct_name, "gl_type": atype,
                "confidence": "medium",
                "reason": f"name keyword: {kw!r}"}

    # 3 — type-only fallback
    if gl_type in _TYPE_FALLBACKS:
        fb_code, fb_name, fb_type = _TYPE_FALLBACKS[gl_type]
        return {"code": fb_code, "name": fb_name, "gl_type": fb_type,
                "confidence": "low",
                "reason": f"type-only fallback for {gl_type!r}"}

    return {"code": None, "name": None, "gl_type": None,
            "confidence": "none",
            "reason": "no match — unknown type and no keyword hit"}


def parse_report_csv(file_path: str) -> dict:
    """
    Parse a P&L, Balance Sheet, or Trial Balance CSV export from any accounting
    system and map each account row to the closest dbox GL account.

    Handles column name variations from Xero, MYOB, Reckon, QuickBooks, and
    generic exports.  Auto-detects the report type from column headers and data.

    Returns:
    {
        "report_type": "balance_sheet" | "profit_loss" | "trial_balance" | "unknown",
        "rows": [
            {
                "source_name":    str,         # original account name
                "source_type":    str,         # original type field
                "source_subtype": str,         # original subtype field (if present)
                "amount":         float,       # net/closing balance (ex-GST preferred)
                "debit":          float,       # trial balance only, else 0.0
                "credit":         float,       # trial balance only, else 0.0
                "suggested_code": str | None,  # best-match dbox account code
                "suggested_name": str | None,  # best-match dbox account name
                "confidence":     str,         # "high" | "medium" | "low" | "none"
                "match_reason":   str,         # explanation for the match
                "skip":           bool,        # True = calculated total, not a GL account
            }
        ],
        "warnings": [str],
    }
    """
    result = {"report_type": "unknown", "rows": [], "warnings": []}

    with open(file_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    if not rows:
        result["warnings"].append("File appears empty.")
        return result

    raw_headers = list(rows[0].keys())
    headers_lower = {h.strip().lower(): h for h in raw_headers}

    def _find_col(*candidates):
        """Return the first matching header key (case-insensitive), or None."""
        for c in candidates:
            if c.lower() in headers_lower:
                return headers_lower[c.lower()]
        return None

    name_col    = _find_col("name", "account name", "account", "description",
                             "account description")
    type_col    = _find_col("account type", "type", "account_type",
                             "classification", "category")
    subtype_col = _find_col("payment deduction type", "subtype",
                             "account subtype", "sub type", "sub-type")
    net_col     = _find_col("net (ex. gst)", "net", "net amount", "amount",
                             "balance", "closing balance", "ytd",
                             "this period", "total amount")
    gross_col   = _find_col("gross (incl. gst)", "gross", "incl gst",
                             "gross amount")
    debit_col   = _find_col("debit", "dr", "debit balance", "dr balance",
                             "debits", "debit amount")
    credit_col  = _find_col("credit", "cr", "credit balance", "cr balance",
                             "credits", "credit amount")

    if not name_col:
        result["warnings"].append(
            f"Cannot locate account name column. Headers found: "
            f"{', '.join(raw_headers)}")
        return result

    # ── Detect report type ─────────────────────────────────────────────────
    has_dr_cr = bool(debit_col and credit_col)
    all_types = set()
    if type_col:
        for r in rows:
            t = (r.get(type_col) or "").strip().lower().replace(" ", "").replace("-", "")
            if t:
                all_types.add(t)

    income_expense = all_types & {"income", "revenue", "expense", "expenses",
                                   "overhead", "directcost", "directcosts",
                                   "costofsales", "sales"}
    balance_sheet  = all_types & {"asset", "assets", "liability", "liabilities",
                                   "equity", "netassets", "retainedearnings"}

    if has_dr_cr:
        result["report_type"] = "trial_balance"
    elif income_expense and balance_sheet:
        result["report_type"] = "trial_balance"
    elif income_expense:
        result["report_type"] = "profit_loss"
    elif balance_sheet:
        result["report_type"] = "balance_sheet"

    # ── Parse rows ─────────────────────────────────────────────────────────
    for row in rows:
        name = (row.get(name_col) or "").strip()
        if not name:
            continue

        r_type  = (row.get(type_col) or "").strip() if type_col else ""
        r_sub   = (row.get(subtype_col) or "").strip() if subtype_col else ""
        r_type_key = r_type.lower().replace(" ", "").replace("-", "")

        # Determine amounts
        amount = 0.0
        if net_col and row.get(net_col, "").strip():
            amount = _money(row[net_col])
        elif gross_col and row.get(gross_col, "").strip():
            amount = _money(row[gross_col])

        debit  = _money(row.get(debit_col,  "")) if debit_col  else 0.0
        credit = _money(row.get(credit_col, "")) if credit_col else 0.0

        # Skip calculated totals
        if r_type_key in _REPORT_SKIP_TYPES:
            result["rows"].append({
                "source_name": name,    "source_type": r_type,
                "source_subtype": r_sub, "amount": amount,
                "debit": debit,          "credit": credit,
                "suggested_code": None,  "suggested_name": None,
                "confidence": "none",
                "match_reason": "calculated total row — not a GL account",
                "skip": True,
            })
            continue

        match = map_to_dbox_account(name, r_type, r_sub)
        result["rows"].append({
            "source_name":    name,
            "source_type":    r_type,
            "source_subtype": r_sub,
            "amount":         amount,
            "debit":          debit,
            "credit":         credit,
            "suggested_code": match["code"],
            "suggested_name": match["name"],
            "confidence":     match["confidence"],
            "match_reason":   match["reason"],
            "skip":           False,
        })

    mapped_rows = [r for r in result["rows"] if not r["skip"]]
    by_conf = {"high": 0, "medium": 0, "low": 0, "none": 0}
    for r in mapped_rows:
        by_conf[r["confidence"]] = by_conf.get(r["confidence"], 0) + 1
    result["warnings"].append(
        f"{result['report_type'].replace('_', ' ').title()} — "
        f"{len(mapped_rows)} accounts: "
        f"{by_conf['high']} high, {by_conf['medium']} medium, "
        f"{by_conf['low'] + by_conf['none']} low/unmatched confidence.")

    return result


# ══════════════════════════════════════════════════════════════════════════════
#  AUTO-DETECT FORMAT
# ══════════════════════════════════════════════════════════════════════════════

def detect_and_parse(file_path: str) -> tuple:
    """
    Try to detect the source format and parse the file.
    Returns (format_name, result_dict).
    """
    with open(file_path, "rb") as f:
        raw = f.read(2048)
    text = raw.decode("utf-8-sig", errors="replace")

    # Glenix XML (BAS Off / FAS3 native export)
    if "glenix.com.au" in text:
        return "BAS Off / FAS3 (Glenix XML)", parse_basoff_xml(file_path)

    # IIF detection: starts with !TRNS or !ACCNT
    if re.search(r"^!(?:TRNS|ACCNT|CUST|VEND|INVMEMO)", text, re.MULTILINE):
        return "QuickBooks (IIF)", parse_quickbooks_iif(file_path)

    # Tab-delimited = likely MYOB
    first_line = text.split("\n")[0]
    if "\t" in first_line:
        return "MYOB AccountRight", parse_myob(file_path)

    # Xero markers
    xero_headers = {"ContactName", "InvoiceNumber", "UnitAmount",
                    "TaxType", "AccountCode"}
    with open(file_path, newline="", encoding="utf-8-sig") as f:
        try:
            reader = csv.DictReader(f)
            hdrs = set(reader.fieldnames or [])
        except Exception:
            hdrs = set()
    if hdrs & xero_headers:
        return "Xero", parse_xero(file_path)
    if {"Code", "Type", "Tax", "YTD"} & hdrs and "Name" in hdrs:
        return "Xero", parse_xero(file_path)

    # BAS Off / FAS3 — fallback for CSVs with date+description+amount
    return "BAS Off / FAS3", parse_basoff(file_path)


# ══════════════════════════════════════════════════════════════════════════════
#  WRITE TO DBOX DATABASE
# ══════════════════════════════════════════════════════════════════════════════

def import_to_dbox(db_path: str, data: dict,
                       import_accounts: bool = True,
                       import_contacts: bool = True,
                       import_invoices: bool = True,
                       import_bills:    bool = True,
                       import_journals: bool = True) -> dict:
    """
    Write parsed data into an dbox SQLite database.
    Returns {"imported": {accounts:n, contacts:n, ...}, "errors": [str]}.
    """
    from core.ledger import (save_account, save_contact, save_invoice,
                              save_bill, post_journal, get_accounts,
                              get_contacts)
    from core.database import get_connection

    counts = {"accounts": 0, "contacts": 0, "invoices": 0,
              "bills": 0, "journals": 0}
    errors = []

    # Build lookup maps for existing accounts and contacts
    existing_accounts = {a["name"].lower(): a for a in get_accounts(db_path)}
    existing_contacts = {c["name"].lower(): c for c in get_contacts(db_path)}

    # ── Accounts ──────────────────────────────────────────────────────────
    if import_accounts:
        _dbox_code_re = re.compile(r'^[1-5]-\d{4}$')
        _type_class   = {
            "Bank": "1", "Current Asset": "1", "Fixed Asset": "1",
            "Accounts Receivable": "1",
            "Current Liability": "2", "Non-Current Liability": "2",
            "Accounts Payable": "2",
            "Equity": "3",
            "Revenue": "4",
            "Cost of Sales": "5", "Expense": "5",
        }
        used_codes = {a.get("code") for a in get_accounts(db_path) if a.get("code")}

        def _normalise_code(ext_code, acc_type):
            if _dbox_code_re.match(ext_code or ""):
                return ext_code
            cls = _type_class.get(acc_type, "5")
            digits = re.sub(r'\D', '', ext_code or "")
            base = int(digits[-4:]) if len(digits) >= 4 else (int(digits) if digits else 9000)
            for offset in range(200):
                candidate = f"{cls}-{(base + offset):04d}"
                if candidate not in used_codes:
                    used_codes.add(candidate)
                    return candidate
            return f"{cls}-9999"

        for acc in data.get("accounts", []):
            if not acc.get("name"):
                continue
            if acc["name"].lower() in existing_accounts:
                continue  # skip existing
            try:
                code = _normalise_code(acc.get("code", ""), acc.get("type", "Expense"))
                save_account(db_path, {
                    "id":           None,
                    "code":         code,
                    "name":         acc["name"],
                    "account_type": acc.get("type", "Expense"),
                    "description":  acc.get("description", ""),
                    "is_bank":      0,
                    "is_active":    1,
                })
                existing_accounts[acc["name"].lower()] = True
                counts["accounts"] += 1
            except Exception as e:
                errors.append(f"Account '{acc['name']}': {e}")

    # ── Contacts ──────────────────────────────────────────────────────────
    if import_contacts:
        for c in data.get("contacts", []):
            if not c.get("name"):
                continue
            if c["name"].lower() in existing_contacts:
                continue
            try:
                save_contact(db_path, {
                    "id":            None,
                    "name":          c["name"],
                    "contact_type":  c.get("contact_type", "Customer"),
                    "email":         c.get("email", ""),
                    "phone":         c.get("phone", ""),
                    "abn":           c.get("abn", ""),
                    "address":       c.get("address", ""),
                    "payment_terms": c.get("payment_terms", 30),
                    "is_active":     1,
                    "bank_bsb":      "",
                    "bank_account":  "",
                    "bank_name":     "",
                })
                existing_contacts[c["name"].lower()] = True
                counts["contacts"] += 1
            except Exception as e:
                errors.append(f"Contact '{c['name']}': {e}")

    # ── Invoices ──────────────────────────────────────────────────────────
    if import_invoices:
        for inv in data.get("invoices", []):
            if not inv.get("contact_name") or not inv.get("lines"):
                continue
            # Find contact_id
            contact = existing_contacts.get(inv["contact_name"].lower())
            if not contact or not isinstance(contact, dict):
                # Auto-create contact
                try:
                    save_contact(db_path, {
                        "id": None, "name": inv["contact_name"],
                        "contact_type": "Customer", "email": "",
                        "phone": "", "abn": "", "address": "",
                        "payment_terms": 30, "is_active": 1,
                        "bank_bsb": "", "bank_account": "", "bank_name": "",
                    })
                    existing_contacts[inv["contact_name"].lower()] = \
                        {"name": inv["contact_name"]}
                except Exception:
                    pass
                contact = get_contacts(db_path)
                contact = next((c for c in contact
                                if c["name"].lower() == inv["contact_name"].lower()),
                               None)

            contact_id = contact["id"] if contact and isinstance(contact, dict) else None
            if not contact_id:
                errors.append(f"Invoice {inv.get('invoice_number','?')}: "
                              f"contact '{inv['contact_name']}' not found")
                continue

            today = date.today().isoformat()
            try:
                lines = [{
                    "description": ln.get("description", "Imported line"),
                    "quantity":    float(ln.get("quantity", 1)),
                    "unit_price":  float(ln.get("unit_price", 0)),
                    "tax_code":    ln.get("tax_code", "GST"),
                    "account_id":  None,
                } for ln in inv["lines"]]
                save_invoice(db_path, {
                    "id":               None,
                    "contact_id":       contact_id,
                    "invoice_number":   inv.get("invoice_number", ""),
                    "invoice_date":     inv.get("invoice_date") or today,
                    "due_date":         inv.get("due_date") or today,
                    "status":           "Sent",
                    "notes":            inv.get("notes", ""),
                    "payment_instructions": "",
                    "internal_comments": f"Imported from {inv.get('_source','external')}",
                }, lines)
                counts["invoices"] += 1
            except Exception as e:
                errors.append(f"Invoice '{inv.get('invoice_number','?')}': {e}")

    # ── Bills ─────────────────────────────────────────────────────────────
    if import_bills:
        for bill in data.get("bills", []):
            if not bill.get("contact_name") or not bill.get("lines"):
                continue
            contact = existing_contacts.get(bill["contact_name"].lower())
            if not contact or not isinstance(contact, dict):
                try:
                    save_contact(db_path, {
                        "id": None, "name": bill["contact_name"],
                        "contact_type": "Supplier", "email": "",
                        "phone": "", "abn": "", "address": "",
                        "payment_terms": 30, "is_active": 1,
                        "bank_bsb": "", "bank_account": "", "bank_name": "",
                    })
                except Exception:
                    pass
                contact = get_contacts(db_path)
                contact = next((c for c in contact
                                if c["name"].lower() == bill["contact_name"].lower()),
                               None)

            contact_id = contact["id"] if contact and isinstance(contact, dict) else None
            if not contact_id:
                errors.append(f"Bill {bill.get('invoice_number','?')}: "
                              f"contact '{bill['contact_name']}' not found")
                continue

            today = date.today().isoformat()
            try:
                lines = [{
                    "description": ln.get("description", "Imported line"),
                    "quantity":    float(ln.get("quantity", 1)),
                    "unit_price":  float(ln.get("unit_price", 0)),
                    "tax_code":    ln.get("tax_code", "GST"),
                    "account_id":  None,
                } for ln in bill["lines"]]
                save_bill(db_path, {
                    "id":          None,
                    "contact_id":  contact_id,
                    "bill_number": bill.get("invoice_number", ""),
                    "bill_date":   bill.get("invoice_date") or today,
                    "due_date":    bill.get("due_date") or today,
                    "status":      "Approved",
                    "notes":       bill.get("notes", ""),
                    "internal_comments": f"Imported from {bill.get('_source','external')}",
                }, lines)
                counts["bills"] += 1
            except Exception as e:
                errors.append(f"Bill '{bill.get('invoice_number','?')}': {e}")

    # ── Journals ──────────────────────────────────────────────────────────
    if import_journals:
        # Build account-by-name lookup
        acc_rows = get_accounts(db_path)
        acc_by_name = {}
        for a in acc_rows:
            acc_by_name[a["name"].lower()] = a["id"]
            if a.get("code"):
                acc_by_name[a["code"].lower()] = a["id"]

        def _find_account(name):
            if not name:
                return None
            return acc_by_name.get(str(name).lower())

        for jnl in data.get("journals", []):
            if not jnl.get("lines"):
                continue
            lines = []
            for ln in jnl["lines"]:
                acc_id = _find_account(ln.get("account_name", ""))
                if not acc_id:
                    # Try to find or skip
                    continue
                lines.append({
                    "account_id":  acc_id,
                    "debit":       float(ln.get("debit", 0)),
                    "credit":      float(ln.get("credit", 0)),
                    "description": ln.get("description", ""),
                })
            if not lines:
                errors.append(f"Journal {jnl.get('date','?')}: no matching accounts found")
                continue
            try:
                post_journal(
                    db_path,
                    entry_date  = jnl.get("date") or date.today().isoformat(),
                    description = jnl.get("description", "Imported"),
                    reference   = jnl.get("reference", ""),
                    lines       = lines,
                )
                counts["journals"] += 1
            except Exception as e:
                errors.append(f"Journal {jnl.get('date','?')}: {e}")

    return {"imported": counts, "errors": errors}
