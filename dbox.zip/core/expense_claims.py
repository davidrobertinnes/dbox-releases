"""
Dogbox Accounting — Expense Claims

Out-of-pocket expense tracking for sole traders and small businesses.
Workflow: Draft → Posted (creates balanced GL journal entry)

GL on post:
  DR  Expense account    (net amount ex GST)
  DR  GST Paid 1-1300   (GST component, if applicable)
  CR  Owner Expense Claims 2-1150  (total — liability until reimbursed/reconciled)
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.

from __future__ import annotations
from datetime import date as _date
from core.database import get_connection

EXPENSE_CATEGORIES = [
    'Motor Vehicle', 'Mileage', 'Travel & Accommodation',
    'Meals & Entertainment', 'Office Supplies', 'Phone & Internet',
    'Professional Development', 'Tools & Equipment', 'Subscriptions', 'Other',
]

ATO_MILEAGE_RATE = 0.88   # $ per km, ATO 2024-25

_CLAIMS_CODE = '2-1150'
_CLAIMS_NAME = 'Owner Expense Claims'


# ─────────────────────────────────────────────────────────────────────────────
#  MIGRATION
# ─────────────────────────────────────────────────────────────────────────────

def migrate_expense_claims(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS expense_claims (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        claim_date    TEXT NOT NULL,
        description   TEXT NOT NULL,
        category      TEXT DEFAULT 'Other',
        is_mileage    INTEGER NOT NULL DEFAULT 0,
        km            REAL,
        km_rate       REAL,
        amount_ex_gst REAL NOT NULL DEFAULT 0,
        gst_amount    REAL NOT NULL DEFAULT 0,
        total         REAL NOT NULL DEFAULT 0,
        tax_code      TEXT NOT NULL DEFAULT 'GST',
        account_id    INTEGER REFERENCES accounts(id),
        notes         TEXT,
        status        TEXT NOT NULL DEFAULT 'Draft',
        journal_id    INTEGER REFERENCES journal_entries(id),
        created_by    TEXT,
        created_at    TEXT DEFAULT (datetime('now','localtime')),
        updated_at    TEXT DEFAULT (datetime('now','localtime'))
    )""")


# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _ensure_claims_account(conn) -> int:
    row = conn.execute(
        "SELECT id FROM accounts WHERE code=?", (_CLAIMS_CODE,)
    ).fetchone()
    if row:
        return row['id']
    conn.execute("""INSERT INTO accounts (code, name, account_type, description)
        VALUES (?, ?, 'Liability',
                'Clearing account for owner out-of-pocket expense claims')""",
        (_CLAIMS_CODE, _CLAIMS_NAME))
    return conn.execute("SELECT last_insert_rowid()").fetchone()[0]


def _compute(data: dict) -> tuple:
    """Return (amount_ex_gst, gst_amount, total, tax_code, km, km_rate)."""
    is_mileage = bool(data.get('is_mileage'))
    if is_mileage:
        km      = round(float(data.get('km') or 0), 2)
        km_rate = round(float(data.get('km_rate') or ATO_MILEAGE_RATE), 4)
        ex_gst  = round(km * km_rate, 2)
        gst     = 0.0
        tc      = 'FRE'
    else:
        km = km_rate = None
        ex_gst = round(float(data.get('amount_ex_gst') or 0), 2)
        tc     = data.get('tax_code', 'GST')
        gst    = round(ex_gst * 0.1, 2) if tc == 'GST' else 0.0
    return ex_gst, gst, round(ex_gst + gst, 2), tc, km, km_rate


# ─────────────────────────────────────────────────────────────────────────────
#  CRUD
# ─────────────────────────────────────────────────────────────────────────────

def get_expense_claims(db_path, status=None) -> list:
    conn = get_connection(db_path)
    q = """SELECT ec.*, a.name as account_name, a.code as account_code
           FROM expense_claims ec
           LEFT JOIN accounts a ON ec.account_id = a.id
           WHERE 1=1"""
    params = []
    if status:
        q += " AND ec.status = ?"
        params.append(status)
    q += " ORDER BY ec.claim_date DESC, ec.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_expense_claim(db_path, claim_id: int) -> dict | None:
    conn = get_connection(db_path)
    row = conn.execute("""
        SELECT ec.*, a.name as account_name, a.code as account_code
        FROM expense_claims ec
        LEFT JOIN accounts a ON ec.account_id = a.id
        WHERE ec.id = ?""", (claim_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_expense_claim(db_path, data: dict) -> int:
    ex_gst, gst, total, tc, km, km_rate = _compute(data)
    is_mileage = 1 if data.get('is_mileage') else 0
    conn = get_connection(db_path)
    cid = data.get('id')
    if cid:
        conn.execute("""UPDATE expense_claims SET
              claim_date=?, description=?, category=?,
              is_mileage=?, km=?, km_rate=?,
              amount_ex_gst=?, gst_amount=?, total=?, tax_code=?,
              account_id=?, notes=?,
              updated_at=datetime('now','localtime')
            WHERE id=?""",
            (data['claim_date'], data['description'], data.get('category', 'Other'),
             is_mileage, km, km_rate, ex_gst, gst, total, tc,
             data.get('account_id'), data.get('notes'), cid))
    else:
        conn.execute("""INSERT INTO expense_claims
              (claim_date, description, category,
               is_mileage, km, km_rate,
               amount_ex_gst, gst_amount, total, tax_code,
               account_id, notes, status, created_by)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'Draft',?)""",
            (data['claim_date'], data['description'], data.get('category', 'Other'),
             is_mileage, km, km_rate, ex_gst, gst, total, tc,
             data.get('account_id'), data.get('notes'), data.get('created_by')))
        cid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit()
    conn.close()
    return cid


def delete_expense_claim(db_path, claim_id: int):
    claim = get_expense_claim(db_path, claim_id)
    if not claim:
        raise ValueError(f"Claim {claim_id} not found")
    if claim['status'] == 'Posted':
        raise ValueError("Void the claim before deleting")
    conn = get_connection(db_path)
    conn.execute("DELETE FROM expense_claims WHERE id=?", (claim_id,))
    conn.commit()
    conn.close()


# ─────────────────────────────────────────────────────────────────────────────
#  POSTING / VOIDING
# ─────────────────────────────────────────────────────────────────────────────

def post_expense_claim(db_path, claim_id: int) -> int:
    """Post a Draft claim. Returns journal_id."""
    claim = get_expense_claim(db_path, claim_id)
    if not claim:
        raise ValueError(f"Claim {claim_id} not found")
    if claim['status'] != 'Draft':
        raise ValueError(f"Claim is already {claim['status']}")
    if not claim.get('account_id'):
        raise ValueError("Expense account must be set before posting")

    conn = get_connection(db_path)
    claims_acc = _ensure_claims_account(conn)
    gst_acc = conn.execute(
        "SELECT id FROM accounts WHERE code='1-1300'"
    ).fetchone()
    if not gst_acc and claim['gst_amount']:
        conn.close()
        raise ValueError("GST Paid account (1-1300) not found")

    conn.execute("""INSERT INTO journal_entries
        (entry_date, reference, description, entry_type, source_id, source_type)
        VALUES (?,?,?,?,?,?)""",
        (claim['claim_date'], f"EXP-{claim_id:04d}",
         claim['description'], 'Expense Claim', claim_id, 'expense_claim'))
    jid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    # CR Owner Expense Claims (total)
    conn.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,0,?)",
                 (jid, claims_acc, claim['total']))
    # DR Expense account (net)
    conn.execute("INSERT INTO journal_lines (journal_id,account_id,debit,credit) VALUES (?,?,?,0)",
                 (jid, claim['account_id'], claim['amount_ex_gst']))
    # DR GST Paid (if any)
    if claim['gst_amount']:
        conn.execute("""INSERT INTO journal_lines
            (journal_id,account_id,debit,credit,gst_amount) VALUES (?,?,?,0,?)""",
            (jid, gst_acc['id'], claim['gst_amount'], claim['gst_amount']))

    conn.execute("""UPDATE expense_claims SET status='Posted', journal_id=?,
        updated_at=datetime('now','localtime') WHERE id=?""", (jid, claim_id))
    conn.commit()
    conn.close()
    return jid


def void_expense_claim(db_path, claim_id: int):
    """Reverse a Posted claim — deletes the journal, reverts to Draft."""
    claim = get_expense_claim(db_path, claim_id)
    if not claim:
        raise ValueError(f"Claim {claim_id} not found")
    if claim['status'] != 'Posted':
        raise ValueError("Only Posted claims can be voided")
    conn = get_connection(db_path)
    if claim.get('journal_id'):
        conn.execute("DELETE FROM journal_lines WHERE journal_id=?", (claim['journal_id'],))
        conn.execute("DELETE FROM journal_entries WHERE id=?", (claim['journal_id'],))
    conn.execute("""UPDATE expense_claims SET status='Draft', journal_id=NULL,
        updated_at=datetime('now','localtime') WHERE id=?""", (claim_id,))
    conn.commit()
    conn.close()
