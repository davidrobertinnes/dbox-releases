# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

#!/usr/bin/env python3
"""
Dogbox Accounting — Fixed Assets & Depreciation Register
================================================
ATO-compliant depreciation engine supporting:

  • Prime Cost (straight-line)           — Div 40 ITAA97
  • Diminishing Value                    — Div 40 ITAA97
  • Instant Asset Write-Off (IAWO)       — full cost-price deduction in year of acquisition
  • Temporary Full Expensing (TFE)       — 2020-21 to 2022-23 FY rule
  • Low-Value Pool (LVP)                 — assets < $1,000 or added to pool at DV < $1,000
  • Small Business Simplified Pool       — single pool for SBEs (2% opening balance, 15% new)

ATO effective-life tables (selected subset) included; user can override.

Depreciation is computed per-year (AU FY = 1 Jul – 30 Jun).
Journals are posted to the general ledger as:
    DR  Depreciation Expense  (5-2500)
    CR  Accumulated Depreciation account linked to each asset

Data model (SQLite):
  fixed_assets           — asset master
  fixed_asset_depn       — depreciation schedule (one row per FY)
  fixed_asset_disposal   — disposal records

All monetary values in AUD.
"""

import math
import datetime as _dt
from core.database import get_connection


# ══════════════════════════════════════════════════════════════════════════════
#  AASB ASSET CLASSES
#  Aligned with AASB 116 Property, Plant & Equipment and AASB 138 Intangibles.
#  Each class has:
#    key           — internal identifier, stored in fixed_assets.category
#    label         — display name
#    cost_code     — GL account code for asset at cost
#    cost_name     — GL account name
#    accum_code    — GL account code for accumulated depreciation
#    accum_name    — GL account name
#    depn_code     — default depreciation expense account
#    default_method— ATO-recommended default depreciation method
#    default_life  — ATO effective life (years); None = user must set
#    notes         — AASB / ATO guidance note shown in UI
#
#  Account codes follow the 1-3xxx range for non-current assets, keeping
#  1-2xxx already used for Plant/Vehicles and extending to 1-3xxx for new classes.
#
#  Accumulated depreciation accounts use credit-normal convention and sit under
#  the asset class as a contra account (deducted in the balance sheet).
# ══════════════════════════════════════════════════════════════════════════════

ASSET_CLASSES = [
    # ── AASB 116 — Property, Plant & Equipment ───────────────────────────────
    {
        "key":            "Land",
        "label":          "Land",
        "cost_code":      "1-3100",
        "cost_name":      "Land at Cost",
        "accum_code":     None,          # Land is NOT depreciated (AASB 116.54)
        "accum_name":     None,
        "depn_code":      None,
        "default_method": None,
        "default_life":   None,
        "notes":          "Land is not depreciated (AASB 116.54). Record at cost or "
                          "fair value. Revaluation increments go to equity (OCI).",
    },
    {
        "key":            "Buildings",
        "label":          "Buildings",
        "cost_code":      "1-3200",
        "cost_name":      "Buildings at Cost",
        "accum_code":     "1-3210",
        "accum_name":     "Accum Depr – Buildings",
        "depn_code":      "5-2500",
        "default_method": "Prime Cost",
        "default_life":   40.0,          # ATO TR 2023/1: 40 years
        "notes":          "Commercial buildings: ATO effective life 40 years, "
                          "prime cost. Residential: 40 yrs. Does not include land.",
    },
    {
        "key":            "Leasehold Improvements",
        "label":          "Leasehold Improvements",
        "cost_code":      "1-3300",
        "cost_name":      "Leasehold Improvements at Cost",
        "accum_code":     "1-3310",
        "accum_name":     "Accum Depr – Leasehold Improvements",
        "depn_code":      "5-2500",
        "default_method": "Prime Cost",
        "default_life":   None,          # Life = lease term (user must set)
        "notes":          "Depreciate over the shorter of useful life or remaining "
                          "lease term (AASB 116.57). ATO effective life: 15–20 years.",
    },
    {
        "key":            "Plant and Equipment",
        "label":          "Plant & Equipment",
        "cost_code":      "1-2100",
        "cost_name":      "Plant & Equipment at Cost",
        "accum_code":     "1-2110",
        "accum_name":     "Accum Depr – Plant & Equipment",
        "depn_code":      "5-2500",
        "default_method": "Diminishing Value",
        "default_life":   15.0,          # ATO: general plant 10–20 yrs
        "notes":          "Machinery, equipment, tools. ATO DV rate 200%/life. "
                          "Check ATO TR 2023/1 for specific effective lives.",
    },
    {
        "key":            "Motor Vehicles",
        "label":          "Motor Vehicles",
        "cost_code":      "1-2200",
        "cost_name":      "Motor Vehicles at Cost",
        "accum_code":     "1-2210",
        "accum_name":     "Accum Depr – Motor Vehicles",
        "depn_code":      "5-2510",
        "default_method": "Diminishing Value",
        "default_life":   8.0,           # ATO: cars/utes 8 yrs, trucks 15 yrs
        "notes":          "Cars subject to car-limit cap ($69,674 in FY2024–25). "
                          "Use car-limit as cost base if purchase price exceeds limit.",
    },
    {
        "key":            "Fixtures and Fittings",
        "label":          "Fixtures & Fittings",
        "cost_code":      "1-3400",
        "cost_name":      "Fixtures & Fittings at Cost",
        "accum_code":     "1-3410",
        "accum_name":     "Accum Depr – Fixtures & Fittings",
        "depn_code":      "5-2500",
        "default_method": "Prime Cost",
        "default_life":   10.0,          # ATO: furniture/fittings 10 yrs
        "notes":          "Office furniture, shop fittings, carpet, blinds, desks. "
                          "ATO effective life generally 10 years.",
    },
    {
        "key":            "Computer Equipment",
        "label":          "Computer Equipment",
        "cost_code":      "1-3500",
        "cost_name":      "Computer Equipment at Cost",
        "accum_code":     "1-3510",
        "accum_name":     "Accum Depr – Computer Equipment",
        "depn_code":      "5-2500",
        "default_method": "Diminishing Value",
        "default_life":   4.0,           # ATO: computers/laptops 4 yrs
        "notes":          "Computers, servers, printers, networking. ATO effective "
                          "life 4 years. Consider Instant Asset Write-Off eligibility.",
    },
    {
        "key":            "Office Equipment",
        "label":          "Office Equipment",
        "cost_code":      "1-3600",
        "cost_name":      "Office Equipment at Cost",
        "accum_code":     "1-3610",
        "accum_name":     "Accum Depr – Office Equipment",
        "depn_code":      "5-2500",
        "default_method": "Diminishing Value",
        "default_life":   5.0,           # ATO: general office equipment 5 yrs
        "notes":          "Photocopiers, phones, projectors, POS systems. "
                          "ATO effective life 4–5 years.",
    },
    {
        "key":            "Low-Value Pool",
        "label":          "Low-Value Pool",
        "cost_code":      "1-3700",
        "cost_name":      "Low-Value Pool",
        "accum_code":     "1-3710",
        "accum_name":     "Accum Depr – Low-Value Pool",
        "depn_code":      "5-2500",
        "default_method": "Low-Value Pool",
        "default_life":   None,          # Pool rate-based, no fixed life
        "notes":          "Assets costing < $1,000 (or DV < $1,000 during year). "
                          "18.75% first year, 37.5% ongoing (ATO s. 40-430).",
    },
    # ── AASB 138 — Intangible Assets ─────────────────────────────────────────
    {
        "key":            "Intangibles",
        "label":          "Intangible Assets",
        "cost_code":      "1-3800",
        "cost_name":      "Intangible Assets at Cost",
        "accum_code":     "1-3810",
        "accum_name":     "Accum Amort – Intangible Assets",
        "depn_code":      "5-2520",
        "default_method": "Prime Cost",
        "default_life":   5.0,           # Varies widely; software 2.5 yrs, trademarks longer
        "notes":          "Software (2.5 yrs ATO), trademarks, patents, licences, "
                          "goodwill (not amortised under AASB 3). AASB 138 applies.",
    },
    # ── Right-of-Use Assets (AASB 16 Leases) ─────────────────────────────────
    {
        "key":            "Right-of-Use Assets",
        "label":          "Right-of-Use Assets",
        "cost_code":      "1-3900",
        "cost_name":      "Right-of-Use Assets",
        "accum_code":     "1-3910",
        "accum_name":     "Accum Depr – Right-of-Use Assets",
        "depn_code":      "5-2500",
        "default_method": "Prime Cost",
        "default_life":   None,          # = lease term
        "notes":          "AASB 16 operating leases recognised on balance sheet for "
                          "periods from 1 Jan 2019. Depreciate over lease term. "
                          "Not available under tax (Div 40) — for accounting only.",
    },
]

# Quick-access dicts
ASSET_CLASS_BY_KEY   = {c["key"]:   c for c in ASSET_CLASSES}
ASSET_CLASS_LABELS   = [c["label"]  for c in ASSET_CLASSES]
ASSET_CLASS_KEYS     = [c["key"]    for c in ASSET_CLASSES]

# Map cost account codes → class (for balance sheet grouping)
COST_CODE_TO_CLASS   = {c["cost_code"]:  c for c in ASSET_CLASSES if c["cost_code"]}
ACCUM_CODE_TO_CLASS  = {c["accum_code"]: c for c in ASSET_CLASSES if c["accum_code"]}

# Separate depreciation expense accounts
EXTRA_DEPN_ACCOUNTS = [
    ("5-2510", "Motor Vehicle Depreciation", "Expense", "Overhead"),
    ("5-2520", "Amortisation – Intangibles",  "Expense", "Overhead"),
]


# ══════════════════════════════════════════════════════════════════════════════
#  ATO EFFECTIVE LIFE TABLE (representative subset, Taxation Ruling TR 2023/1)
#  Keys are lowercase description fragments; values are years (prime cost).
#  The full ATO table has 6,000+ entries — this covers the most common assets.
# ══════════════════════════════════════════════════════════════════════════════

ATO_EFFECTIVE_LIFE: dict[str, float] = {
    # Computers & IT
    "computer":              4,
    "laptop":                4,
    "tablet":                4,
    "server":                5,
    "printer":               5,
    "scanner":               5,
    "monitor":               5,
    "networking equipment":  5,
    "software":              2.5,
    "pos system":            4,
    # Motor vehicles
    "car":                   8,
    "sedan":                 8,
    "ute":                   8,
    "van":                   8,
    "truck":                 15,
    "bus":                   15,
    "motorcycle":            10,
    "forklift":              10,
    # Plant & equipment (general)
    "plant":                 15,
    "machinery":             15,
    "lathe":                 20,
    "press":                 20,
    "pump":                  15,
    "compressor":            15,
    "generator":             15,
    "air conditioner":       10,
    "hvac":                  20,
    "refrigerator":          12,
    "refrigeration":         12,
    "freezer":               12,
    "washing machine":       10,
    # Furniture & fittings
    "desk":                  10,
    "chair":                 10,
    "furniture":             10,
    "shelving":              10,
    "carpet":                10,
    "blinds":                10,
    "office fit":            15,
    "fitout":                15,
    "fit-out":               15,
    "leasehold improvement": 15,
    # Tools
    "tool":                  5,
    "power tool":            5,
    "hand tool":             10,
    "drill":                 5,
    "saw":                   5,
    # Buildings
    "building":              40,
    "warehouse":             40,
    "shed":                  20,
    # Other
    "telephone":             4,
    "mobile phone":          3,
    "camera":                5,
    "projector":             5,
    "solar panel":           20,
    "solar":                 20,
    "battery storage":       10,
}

# ATO Instant Asset Write-Off thresholds by acquisition date
# Each entry: (date_from, date_to, threshold, requires_sbe)
# threshold=None means unlimited (Temporary Full Expensing)
IAWO_THRESHOLDS = [
    # Temporary Full Expensing 2020-21 to 2022-23
    ("2020-10-06", "2023-06-30", None,     False),   # No limit, all businesses
    # Covid-era IAWO
    ("2020-03-12", "2020-10-05", 150_000,  False),
    ("2019-04-02", "2020-03-11",  30_000,  False),
    ("2018-01-29", "2019-04-01",  25_000,  True),    # SBE only
    ("2015-05-12", "2018-01-28",  20_000,  True),    # SBE only
    # Current (from 2023-07-01): $20,000 for SBEs, not available to others
    ("2023-07-01", "2099-12-31",  20_000,  True),    # SBE only, FY2024+
]


def lookup_ato_life(description):
    """Return ATO effective life (years) for a plain-text asset description, or None."""
    desc_lower = description.lower()
    for fragment, years in ATO_EFFECTIVE_LIFE.items():
        if fragment in desc_lower:
            return years
    return None


def iawo_limit(acquisition_date, is_sbe = True):
    """
    Return the Instant Asset Write-Off limit applicable on acquisition_date.
    Returns None if IAWO is unavailable (e.g. non-SBE after TFE period).
    Returns float('inf') for Temporary Full Expensing (unlimited).
    """
    for df, dt, limit, sbe_only in IAWO_THRESHOLDS:
        if df <= acquisition_date <= dt:
            if sbe_only and not is_sbe:
                continue
            return float("inf") if limit is None else float(limit)
    return None


# ══════════════════════════════════════════════════════════════════════════════
#  SCHEMA MIGRATION
# ══════════════════════════════════════════════════════════════════════════════

def migrate_fixed_assets(conn):
    """Create fixed-asset tables and seed all AASB asset-class GL accounts (safe to re-run)."""
    conn.execute("""CREATE TABLE IF NOT EXISTS fixed_assets (
        id                   INTEGER PRIMARY KEY AUTOINCREMENT,
        asset_number         TEXT,
        description          TEXT NOT NULL,
        category             TEXT,
        acquisition_date     TEXT NOT NULL,
        cost_price           REAL NOT NULL,
        cost_excl_gst        REAL,
        residual_value       REAL DEFAULT 0,
        depn_method          TEXT NOT NULL DEFAULT 'Prime Cost',
        effective_life_years REAL,
        asset_account_id     INTEGER REFERENCES accounts(id),
        accum_depn_account_id INTEGER REFERENCES accounts(id),
        depn_expense_account_id INTEGER REFERENCES accounts(id),
        status               TEXT DEFAULT 'Active',
        disposal_date        TEXT,
        disposal_proceeds    REAL,
        disposal_journal_id  INTEGER,
        notes                TEXT,
        source_type          TEXT,
        source_ref           TEXT,
        source_supplier      TEXT,
        created_at           TEXT DEFAULT (datetime('now','localtime')),
        updated_at           TEXT DEFAULT (datetime('now','localtime'))
    )""")

    conn.execute("""CREATE TABLE IF NOT EXISTS fixed_asset_depn (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        asset_id     INTEGER NOT NULL REFERENCES fixed_assets(id),
        fy_year      INTEGER NOT NULL,
        depn_amount  REAL NOT NULL,
        opening_wdv  REAL NOT NULL,
        closing_wdv  REAL NOT NULL,
        journal_id   INTEGER,
        posted       INTEGER DEFAULT 0,
        notes        TEXT,
        UNIQUE(asset_id, fy_year)
    )""")

    conn.execute("""CREATE TABLE IF NOT EXISTS fixed_asset_disposal (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        asset_id         INTEGER NOT NULL REFERENCES fixed_assets(id),
        disposal_date    TEXT NOT NULL,
        disposal_proceeds REAL NOT NULL DEFAULT 0,
        disposal_method  TEXT,
        gain_loss        REAL,
        journal_id       INTEGER,
        notes            TEXT,
        created_at       TEXT DEFAULT (datetime('now','localtime'))
    )""")

    # ── Seed all AASB asset-class GL accounts ────────────────────────────────
    # Cost accounts
    for cls in ASSET_CLASSES:
        if cls["cost_code"]:
            conn.execute("""INSERT OR IGNORE INTO accounts
                (code, name, account_type, account_subtype, is_bank)
                VALUES (?,?,'Asset','Fixed Asset',0)""",
                (cls["cost_code"], cls["cost_name"]))
        if cls["accum_code"]:
            conn.execute("""INSERT OR IGNORE INTO accounts
                (code, name, account_type, account_subtype, is_bank)
                VALUES (?,?,'Asset','Accumulated Depreciation',0)""",
                (cls["accum_code"], cls["accum_name"]))

    # Depreciation expense accounts
    conn.execute("""INSERT OR IGNORE INTO accounts
        (code, name, account_type, account_subtype, is_bank)
        VALUES ('5-2500','Depreciation','Expense','Overhead',0)""")
    for code, name, atype, subtype in EXTRA_DEPN_ACCOUNTS:
        conn.execute("""INSERT OR IGNORE INTO accounts
            (code, name, account_type, account_subtype, is_bank)
            VALUES (?,?,?,?,0)""", (code, name, atype, subtype))

    # Gain/loss on disposal
    conn.execute("""INSERT OR IGNORE INTO accounts
        (code, name, account_type, account_subtype, is_bank)
        VALUES ('4-1400','Gain on Disposal of Assets','Income','Other Income',0)""")
    conn.execute("""INSERT OR IGNORE INTO accounts
        (code, name, account_type, account_subtype, is_bank)
        VALUES ('5-2530','Loss on Disposal of Assets','Expense','Overhead',0)""")

    conn.commit()

    # Safe column migrations for existing databases
    for col in ("source_type", "source_ref", "source_supplier"):
        try:
            conn.execute(f"ALTER TABLE fixed_assets ADD COLUMN {col} TEXT")
            conn.commit()
        except Exception:
            pass

    # Fix any assets that ended up with NULL status (web save bug — pre-fix DBs)
    conn.execute(
        "UPDATE fixed_assets SET status='Active' WHERE status IS NULL OR status=''")
    conn.commit()


# ══════════════════════════════════════════════════════════════════════════════
#  DEPRECIATION CALCULATOR
# ══════════════════════════════════════════════════════════════════════════════

def _fy_dates(fy_year):
    """Return (date_from, date_to) for Australian financial year fy_year.
    fy_year=2025 → 2024-07-01 to 2025-06-30
    """
    return (f"{fy_year-1}-07-01", f"{fy_year}-06-30")


def _days_in_fy(acquisition_date, fy_year):
    """Days of ownership within a financial year (for pro-rata first year)."""
    fy_start = _dt.date(fy_year - 1, 7, 1)
    fy_end   = _dt.date(fy_year,     6, 30)
    acq      = _dt.date.fromisoformat(acquisition_date)

    own_start = max(acq, fy_start)
    own_end   = fy_end
    if own_start > own_end:
        return 0
    # ATO: days = (fy_end - own_start).days + 1
    return (own_end - own_start).days + 1


def calculate_depreciation_schedule(
    cost_excl_gst,
    residual_value,
    depn_method,
    effective_life_years,
    acquisition_date,
    fy_start,            # first FY to include (e.g. 2025)
    fy_end,              # last FY to project to
    existing_wdv=None,   # if asset already has WDV (float or None)
):
    """
    Return a list of annual depreciation rows, one per FY.
    Each row: {fy_year, opening_wdv, depn_amount, closing_wdv, notes}
    """
    rows    = []
    depn_base = cost_excl_gst - residual_value
    if depn_base <= 0:
        return rows

    method = depn_method.lower()

    # ── Instant Write-Off / Full Expensing ────────────────────────────────
    if "instant" in method or "write" in method:
        first_fy = fy_start
        rows.append({
            "fy_year":     first_fy,
            "opening_wdv": cost_excl_gst,
            "depn_amount": cost_excl_gst,
            "closing_wdv": 0.0,
            "notes":       "Instant Asset Write-Off / Full Expensing",
        })
        return rows

    # ── Low-Value Pool (18.75% first year, 37.5% thereafter) ─────────────
    if "low" in method and "pool" in method:
        wdv = existing_wdv if existing_wdv is not None else cost_excl_gst
        for fy in range(fy_start, fy_end + 1):
            if wdv <= 0.005:
                break
            days  = _days_in_fy(acquisition_date, fy)
            if days <= 0:
                continue
            rate  = 0.1875 if (fy == fy_start and existing_wdv is None) else 0.375
            depn  = round(min(wdv, wdv * rate * days / 365), 2)
            new_wdv = round(max(0.0, wdv - depn), 2)
            rows.append({
                "fy_year":     fy,
                "opening_wdv": round(wdv, 2),
                "depn_amount": depn,
                "closing_wdv": new_wdv,
                "notes":       f"Low-Value Pool {rate*100:.2f}% × {days}/365",
            })
            wdv = new_wdv
        return rows

    # ── Small Business Pool (15% new additions, 30% ongoing) ─────────────
    if "small business" in method or "sbp" in method:
        wdv = existing_wdv if existing_wdv is not None else cost_excl_gst
        for fy in range(fy_start, fy_end + 1):
            if wdv <= 0.005:
                break
            days  = _days_in_fy(acquisition_date, fy)
            if days <= 0:
                continue
            is_first = (fy == fy_start and existing_wdv is None)
            rate  = 0.15 if is_first else 0.30
            depn  = round(min(wdv, wdv * rate * days / 365), 2)
            new_wdv = round(max(0.0, wdv - depn), 2)
            rows.append({
                "fy_year":     fy,
                "opening_wdv": round(wdv, 2),
                "depn_amount": depn,
                "closing_wdv": new_wdv,
                "notes":       f"Small Business Pool {rate*100:.0f}% × {days}/365",
            })
            wdv = new_wdv
        return rows

    if not effective_life_years or effective_life_years <= 0:
        return rows

    # ── Prime Cost (straight-line) ────────────────────────────────────────
    if "prime" in method:
        annual_depn = round(depn_base / effective_life_years, 2)
        wdv = existing_wdv if existing_wdv is not None else cost_excl_gst

        for fy in range(fy_start, fy_end + 1):
            if wdv <= residual_value + 0.005:
                break
            days   = _days_in_fy(acquisition_date, fy)
            if days <= 0:
                continue
            depn   = round(min(wdv - residual_value, annual_depn * days / 365), 2)
            new_wdv = round(max(residual_value, wdv - depn), 2)
            rows.append({
                "fy_year":     fy,
                "opening_wdv": round(wdv, 2),
                "depn_amount": depn,
                "closing_wdv": new_wdv,
                "notes":       (f"Prime Cost {(1/effective_life_years)*100:.2f}% "
                                f"× {days}/365"),
            })
            wdv = new_wdv

    # ── Diminishing Value ─────────────────────────────────────────────────
    elif "diminish" in method or "dv" in method:
        # ATO: DV rate = 200% / effective life (from 10 May 2006)
        rate_pct = min(200.0 / effective_life_years / 100, 1.0)
        wdv = existing_wdv if existing_wdv is not None else cost_excl_gst

        for fy in range(fy_start, fy_end + 1):
            if wdv <= residual_value + 0.005:
                break
            days   = _days_in_fy(acquisition_date, fy)
            if days <= 0:
                continue
            depn   = round(min(wdv - residual_value,
                               wdv * rate_pct * days / 365), 2)
            new_wdv = round(max(residual_value, wdv - depn), 2)
            rows.append({
                "fy_year":     fy,
                "opening_wdv": round(wdv, 2),
                "depn_amount": depn,
                "closing_wdv": new_wdv,
                "notes":       (f"Diminishing Value {rate_pct*100:.2f}% "
                                f"× {days}/365"),
            })
            wdv = new_wdv

    return rows


# ══════════════════════════════════════════════════════════════════════════════
#  CRUD — FIXED ASSETS
# ══════════════════════════════════════════════════════════════════════════════

def get_class_defaults(db_path, category_key):
    """
    Return the default GL account IDs and depreciation settings for an asset class.
    Used by the UI to auto-populate account pickers when a category is selected.
    """
    cls = ASSET_CLASS_BY_KEY.get(category_key)
    if not cls:
        return {}
    conn = get_connection(db_path)
    def _id(code):
        if not code:
            return None
        r = conn.execute("SELECT id FROM accounts WHERE code=?", (code,)).fetchone()
        return r["id"] if r else None
    result = {
        "asset_account_id":          _id(cls["cost_code"]),
        "accum_depn_account_id":     _id(cls["accum_code"]),
        "depn_expense_account_id":   _id(cls["depn_code"] or "5-2500"),
        "default_method":            cls["default_method"],
        "default_life":              cls["default_life"],
        "notes_hint":                cls["notes"],
    }
    conn.close()
    return result


def get_fixed_assets(db_path, status=None):
    conn = get_connection(db_path)
    q = """
        SELECT fa.*,
               aa.code  as asset_account_code,
               aa.name  as asset_account_name,
               ad.code  as accum_depn_account_code,
               ad.name  as accum_depn_account_name,
               de.code  as depn_expense_account_code,
               de.name  as depn_expense_account_name
        FROM   fixed_assets fa
        LEFT JOIN accounts aa ON fa.asset_account_id        = aa.id
        LEFT JOIN accounts ad ON fa.accum_depn_account_id   = ad.id
        LEFT JOIN accounts de ON fa.depn_expense_account_id = de.id
    """
    params = []
    if status:
        q += " WHERE fa.status = ?"
        params.append(status)
    q += " ORDER BY fa.acquisition_date DESC, fa.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_fixed_asset(db_path, asset_id):
    conn  = get_connection(db_path)
    row   = conn.execute("SELECT * FROM fixed_assets WHERE id=?",
                         (asset_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_fixed_asset(db_path, data):
    """Insert or update a fixed asset record. Returns asset id."""
    conn = get_connection(db_path)
    c    = conn.cursor()
    # status is managed by dispose/depreciation workflows — never overwrite it
    # on UPDATE unless explicitly provided; always default to 'Active' on INSERT.
    edit_fields = ("asset_number", "description", "category", "acquisition_date",
                   "cost_price", "cost_excl_gst", "residual_value", "depn_method",
                   "effective_life_years", "asset_account_id", "accum_depn_account_id",
                   "depn_expense_account_id", "notes",
                   "source_type", "source_ref", "source_supplier")
    vals = tuple(data.get(f) for f in edit_fields)
    aid  = data.get("id")
    if aid:
        set_clause = ", ".join(f"{f}=?" for f in edit_fields)
        c.execute(f"UPDATE fixed_assets SET {set_clause}, "
                  f"updated_at=datetime('now','localtime') WHERE id=?",
                  vals + (aid,))
    else:
        status = data.get("status") or "Active"
        all_fields = edit_fields + ("status",)
        placeholders = ", ".join("?" * len(all_fields))
        col_clause   = ", ".join(all_fields)
        c.execute(f"INSERT INTO fixed_assets ({col_clause}) VALUES ({placeholders})",
                  vals + (status,))
        aid = c.lastrowid
    conn.commit()
    conn.close()
    return aid


def delete_fixed_asset(db_path, asset_id):
    """Delete asset and its depreciation schedule (if no posted journals)."""
    conn = get_connection(db_path)
    posted = conn.execute(
        "SELECT COUNT(*) as n FROM fixed_asset_depn WHERE asset_id=? AND posted=1",
        (asset_id,)).fetchone()["n"]
    if posted:
        conn.close()
        raise ValueError(
            "Cannot delete an asset with posted depreciation journals. "
            "Dispose of it instead.")
    conn.execute("DELETE FROM fixed_asset_depn   WHERE asset_id=?", (asset_id,))
    conn.execute("DELETE FROM fixed_asset_disposal WHERE asset_id=?", (asset_id,))
    conn.execute("DELETE FROM fixed_assets        WHERE id=?",        (asset_id,))
    conn.commit()
    conn.close()


# ══════════════════════════════════════════════════════════════════════════════
#  DEPRECIATION SCHEDULE MANAGEMENT
# ══════════════════════════════════════════════════════════════════════════════

def get_depn_schedule(db_path, asset_id):
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT * FROM fixed_asset_depn
        WHERE asset_id=? ORDER BY fy_year
    """, (asset_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def regenerate_schedule(db_path, asset_id,
                         project_years = 40):
    """
    (Re)build the full projected depreciation schedule for an asset.
    Deletes any existing unposted rows and replaces them.
    Posted rows are kept as-is; the schedule continues from the last posted WDV.
    Returns the new full schedule.
    """
    asset = get_fixed_asset(db_path, asset_id)
    if not asset:
        raise ValueError(f"Asset {asset_id} not found")

    conn = get_connection(db_path)

    # What has already been posted?
    posted = conn.execute("""
        SELECT * FROM fixed_asset_depn
        WHERE asset_id=? AND posted=1
        ORDER BY fy_year
    """, (asset_id,)).fetchall()
    posted = [dict(r) for r in posted]

    # Delete unposted
    conn.execute("DELETE FROM fixed_asset_depn WHERE asset_id=? AND posted=0",
                 (asset_id,))
    conn.commit()

    # Determine starting WDV and FY
    if posted:
        last_posted = posted[-1]
        start_wdv   = last_posted["closing_wdv"]
        start_fy    = last_posted["fy_year"] + 1
    else:
        start_wdv   = None
        acq_year    = int(asset["acquisition_date"][:4])
        acq_month   = int(asset["acquisition_date"][5:7])
        # FY = calendar year of June-end of the FY containing acquisition
        start_fy    = acq_year if acq_month <= 6 else acq_year + 1

    end_fy = start_fy + project_years

    rows = calculate_depreciation_schedule(
        cost_excl_gst       = (asset["cost_excl_gst"] if asset["cost_excl_gst"] is not None
                               else (asset["cost_price"] or 0)),
        residual_value       = asset["residual_value"] or 0.0,
        depn_method          = asset["depn_method"] or "Prime Cost",
        effective_life_years = asset["effective_life_years"],
        acquisition_date     = asset["acquisition_date"],
        fy_start             = start_fy,
        fy_end               = end_fy,
        existing_wdv         = start_wdv,
    )

    c = conn.cursor()
    for r in rows:
        c.execute("""INSERT OR REPLACE INTO fixed_asset_depn
            (asset_id, fy_year, depn_amount, opening_wdv, closing_wdv, notes, posted)
            VALUES (?,?,?,?,?,?,0)""",
            (asset_id, r["fy_year"], r["depn_amount"],
             r["opening_wdv"], r["closing_wdv"], r.get("notes", "")))
    conn.commit()
    conn.close()

    return get_depn_schedule(db_path, asset_id)


def post_depreciation_journal(db_path, asset_id, fy_year):
    """
    Post the depreciation journal for one asset for one FY.
    DR  Depreciation Expense
    CR  Accumulated Depreciation
    Returns journal_id.
    """
    asset = get_fixed_asset(db_path, asset_id)
    if not asset:
        raise ValueError(f"Asset {asset_id} not found")

    conn  = get_connection(db_path)
    row   = conn.execute("""SELECT * FROM fixed_asset_depn
        WHERE asset_id=? AND fy_year=?""", (asset_id, fy_year)).fetchone()
    if not row:
        conn.close()
        raise ValueError(f"No depreciation schedule row for FY{fy_year}")
    row = dict(row)
    if row["posted"]:
        conn.close()
        raise ValueError(f"FY{fy_year} depreciation already posted")

    depn_exp_acc  = asset.get("depn_expense_account_id")
    accum_depn_acc = asset.get("accum_depn_account_id")

    if not depn_exp_acc or not accum_depn_acc:
        # Fall back to defaults
        depn_exp_acc  = conn.execute(
            "SELECT id FROM accounts WHERE code='5-2500' LIMIT 1").fetchone()
        accum_depn_acc = conn.execute(
            "SELECT id FROM accounts WHERE code LIKE '1-2%10' LIMIT 1").fetchone()
        if depn_exp_acc:
            depn_exp_acc = depn_exp_acc["id"]
        if accum_depn_acc:
            accum_depn_acc = accum_depn_acc["id"]
        if not depn_exp_acc or not accum_depn_acc:
            conn.close()
            raise ValueError(
                "Cannot find Depreciation Expense or Accumulated Depreciation accounts. "
                "Set them on the asset record.")
    conn.close()

    from core.ledger import post_journal
    fy_date = f"{fy_year}-06-30"   # post on 30 June (end of FY)
    desc    = f"Depreciation — {asset['description']} FY{fy_year-1}/{str(fy_year)[-2:]}"
    ref     = f"DEPN-{asset.get('asset_number') or asset_id}-{fy_year}"
    lines   = [
        {"account_id": depn_exp_acc,   "debit":  row["depn_amount"],
         "credit": 0,                  "description": desc},
        {"account_id": accum_depn_acc, "debit":  0,
         "credit": row["depn_amount"], "description": desc},
    ]
    jid = post_journal(db_path, fy_date, desc, ref, lines)

    conn2 = get_connection(db_path)
    conn2.execute("""UPDATE fixed_asset_depn
        SET posted=1, journal_id=? WHERE asset_id=? AND fy_year=?""",
        (jid, asset_id, fy_year))
    # Mark asset Fully Depreciated if closing WDV ≈ 0
    if row["closing_wdv"] < 0.01:
        conn2.execute(
            "UPDATE fixed_assets SET status='Fully Depreciated' WHERE id=?",
            (asset_id,))
    conn2.commit()
    conn2.close()
    return jid


def post_all_fy_depreciation(db_path, fy_year):
    """
    Post depreciation for all Active assets for a given FY.
    Returns list of {asset_id, description, depn_amount, journal_id, error}.
    """
    assets  = get_fixed_assets(db_path, status="Active")
    results = []
    for a in assets:
        conn = get_connection(db_path)
        row  = conn.execute("""SELECT * FROM fixed_asset_depn
            WHERE asset_id=? AND fy_year=? AND posted=0""",
            (a["id"], fy_year)).fetchone()
        conn.close()
        if not row:
            continue
        try:
            jid = post_depreciation_journal(db_path, a["id"], fy_year)
            results.append({
                "asset_id":    a["id"],
                "description": a["description"],
                "depn_amount": row["depn_amount"],
                "journal_id":  jid,
                "error":       None,
            })
        except Exception as ex:
            results.append({
                "asset_id":    a["id"],
                "description": a["description"],
                "depn_amount": row["depn_amount"] if row else 0,
                "journal_id":  None,
                "error":       str(ex),
            })
    return results


# ══════════════════════════════════════════════════════════════════════════════
#  DISPOSAL
# ══════════════════════════════════════════════════════════════════════════════

def dispose_asset(db_path, asset_id, disposal_date,
                   proceeds, method = "Sale",
                   notes = ""):
    """
    Record disposal of a fixed asset and post the disposal journal.
    Journal:
        DR  Cash / Bank                     proceeds
        DR  Accumulated Depreciation        (total accumulated)
        DR/CR  Loss/Gain on Disposal        (balancing figure)
        CR  Asset at Cost                   original cost
    Returns {journal_id, gain_loss, disposed_asset}.
    """
    asset = get_fixed_asset(db_path, asset_id)
    if not asset:
        raise ValueError(f"Asset {asset_id} not found")

    conn  = get_connection(db_path)
    # Compute total accumulated depreciation posted
    accum = conn.execute("""
        SELECT COALESCE(SUM(depn_amount),0) as total
        FROM fixed_asset_depn WHERE asset_id=? AND posted=1
    """, (asset_id,)).fetchone()["total"]

    cost = (asset["cost_excl_gst"] if asset["cost_excl_gst"] is not None
            else (asset["cost_price"] or 0))
    wdv      = round(cost - accum, 2)
    gain_loss = round(proceeds - wdv, 2)   # positive = gain, negative = loss

    # Zero-cost asset (no source transaction, never capitalised in GL) — record
    # disposal in the register only, no journal required.
    if cost == 0:
        conn.close()
        conn2 = get_connection(db_path)
        conn2.execute("""UPDATE fixed_assets
            SET status='Disposed', disposal_date=?, disposal_proceeds=?,
                updated_at=datetime('now','localtime') WHERE id=?""",
            (disposal_date, proceeds, asset_id))
        conn2.execute("""INSERT INTO fixed_asset_disposal
            (asset_id, disposal_date, disposal_proceeds, disposal_method,
             gain_loss, journal_id, notes)
            VALUES (?,?,?,?,0,NULL,?)""",
            (asset_id, disposal_date, proceeds, method, notes))
        conn2.commit()
        conn2.close()
        return {"journal_id": None, "gain_loss": 0,
                "wdv_at_disposal": 0, "accum_depn": 0}

    # Accounts
    asset_acc      = asset.get("asset_account_id")
    accum_depn_acc = asset.get("accum_depn_account_id")
    bank_row = conn.execute(
        "SELECT id FROM accounts WHERE is_bank=1 LIMIT 1").fetchone()
    bank_acc = bank_row["id"] if bank_row else None
    disposal_row = conn.execute(
        "SELECT id FROM accounts WHERE code='4-1300' LIMIT 1").fetchone()
    disposal_acc = disposal_row["id"] if disposal_row else None
    # Fetch gain/loss accounts while connection is still open
    gain_row = conn.execute(
        "SELECT id FROM accounts WHERE code='4-1400' LIMIT 1").fetchone()
    gain_acc_id = gain_row["id"] if gain_row else disposal_acc
    loss_row = conn.execute(
        "SELECT id FROM accounts WHERE code='5-2530' LIMIT 1").fetchone()
    loss_acc_id = loss_row["id"] if loss_row else None
    conn.close()

    if not asset_acc or not accum_depn_acc:
        missing = []
        if not asset_acc:      missing.append("Asset Cost account (set on asset record)")
        if not accum_depn_acc: missing.append("Accumulated Depreciation account (set on asset record)")
        raise ValueError(
            "Cannot post disposal — missing GL accounts: " + ", ".join(missing))

    if not bank_acc and proceeds > 0:
        raise ValueError("Cannot post disposal proceeds — no bank account found")

    from core.ledger import post_journal
    desc  = f"Disposal — {asset['description']} ({method})"
    ref   = f"DISP-{asset.get('asset_number') or asset_id}"
    lines = [
        {"account_id": accum_depn_acc, "debit": accum,    "credit": 0,    "description": desc},
        {"account_id": asset_acc,      "debit": 0,        "credit": cost, "description": desc},
    ]
    if proceeds > 0:
        lines.insert(0, {"account_id": bank_acc, "debit": proceeds, "credit": 0, "description": desc})
    if gain_loss > 0:
        lines.append({"account_id": gain_acc_id, "debit": 0,
                      "credit": gain_loss, "description": "Gain on disposal"})
    elif gain_loss < 0:
        eff_loss_acc = loss_acc_id or gain_acc_id or disposal_acc
        if eff_loss_acc:
            lines.append({"account_id": eff_loss_acc, "debit": abs(gain_loss),
                          "credit": 0, "description": "Loss on disposal"})

    jid = post_journal(db_path, disposal_date, desc, ref, lines)

    conn2 = get_connection(db_path)
    conn2.execute("""UPDATE fixed_assets
        SET status='Disposed', disposal_date=?, disposal_proceeds=?,
            disposal_journal_id=?, updated_at=datetime('now','localtime')
        WHERE id=?""",
        (disposal_date, proceeds, jid, asset_id))
    conn2.execute("""INSERT INTO fixed_asset_disposal
        (asset_id, disposal_date, disposal_proceeds, disposal_method, gain_loss, journal_id, notes)
        VALUES (?,?,?,?,?,?,?)""",
        (asset_id, disposal_date, proceeds, method, gain_loss, jid, notes))
    conn2.commit()
    conn2.close()

    return {"journal_id": jid, "gain_loss": gain_loss,
            "wdv_at_disposal": wdv, "accum_depn": accum}


# ══════════════════════════════════════════════════════════════════════════════
#  REPORTS
# ══════════════════════════════════════════════════════════════════════════════

def asset_register_report(db_path):
    """Full asset register with current WDV for each active asset."""
    assets = get_fixed_assets(db_path)
    rows   = []
    for a in assets:
        conn    = get_connection(db_path)
        accum   = conn.execute("""
            SELECT COALESCE(SUM(depn_amount),0) as total
            FROM fixed_asset_depn WHERE asset_id=? AND posted=1
        """, (a["id"],)).fetchone()["total"]
        # Next unposted FY
        next_row = conn.execute("""
            SELECT fy_year, depn_amount FROM fixed_asset_depn
            WHERE asset_id=? AND posted=0 ORDER BY fy_year LIMIT 1
        """, (a["id"],)).fetchone()
        conn.close()
        cost = (a["cost_excl_gst"] if a.get("cost_excl_gst") is not None
                else (a.get("cost_price") or 0))
        rows.append({
            **a,
            "accum_depn":      round(accum, 2),
            "current_wdv":     round(cost - accum, 2),
            "next_fy":         next_row["fy_year"]     if next_row else None,
            "next_depn":       next_row["depn_amount"] if next_row else 0.0,
        })
    return rows
