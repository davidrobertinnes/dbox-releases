# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
dbox - Worksheet PDF Generator
Field work order / worksheet for on-site use.
"""

import os
import tempfile
from datetime import date

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_RIGHT, TA_CENTER
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, KeepTogether,
)
from reportlab.graphics.shapes import Drawing, Rect, PolyLine

from core.database import get_connection
from core.invoice_pdf import (
    _resolve_theme, _s, _fmt, _c, _load_doc_theme,
    _build_header, _make_page_callback,
    PAGE_W,
)

_MIN_TASK_ROWS = 4   # blank rows added if tasks < this
_MAT_ROWS      = 4   # blank material rows
_CB_PT         = 13  # checkbox size in points


def _make_ws_callback(footer_txt, watermark=None, licence_footer=None):
    """Canvas callback: draws worksheet reference + page number on every page."""
    base = _make_page_callback(watermark=watermark, footer=licence_footer)

    def _draw(canvas, doc):
        base(canvas, doc)
        w, _h = canvas._pagesize
        page_num = canvas.getPageNumber()
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(colors.HexColor("#888888"))
        y = (9 if licence_footer else 6) * mm
        canvas.drawCentredString(w / 2, y, f"{footer_txt}  —  Page {page_num}")
        canvas.restoreState()

    return _draw


def _checkbox(checked=False):
    """Draw a proper checkbox (Helvetica doesn't include ☐/✓ glyphs)."""
    d = Drawing(_CB_PT, _CB_PT)
    d.add(Rect(0.5, 0.5, _CB_PT - 1, _CB_PT - 1,
               strokeColor=colors.black, strokeWidth=0.8,
               fillColor=colors.white))
    if checked:
        d.add(PolyLine(
            [_CB_PT * 0.18, _CB_PT * 0.45,
             _CB_PT * 0.42, _CB_PT * 0.15,
             _CB_PT * 0.85, _CB_PT * 0.72],
            strokeColor=colors.black, strokeWidth=1.2,
        ))
    return d


def _fmt_iso(iso):
    try:
        return date.fromisoformat(iso).strftime("%d/%m/%Y")
    except (TypeError, ValueError):
        return iso or ""


def generate_worksheet_pdf(
    db_path,
    contact_id=None,
    job_id=None,
    output_path=None,
    watermark=None,
    footer=None,
    visit_id=None,
):
    """Generate a field worksheet PDF.

    Pass contact_id for a contact task worksheet.
    Pass job_id for a job worksheet (includes both CRM and work tasks).
    Pass visit_id for one job visit: dated for the visit, listing only the
    tasks planned for it (core/visit_tasks.py), with "qty done ___ of N"
    blanks for quantity tasks and spare rows for unplanned work.
    """
    if not contact_id and not job_id and not visit_id:
        raise ValueError("Either contact_id, job_id or visit_id is required")

    conn = get_connection(db_path)

    job = None
    contact = None
    crm_tasks = []
    work_tasks = []
    visit = None

    if visit_id:
        visit = conn.execute("SELECT * FROM schedule_events WHERE id = ?", (visit_id,)).fetchone()
        if not visit or not visit["job_id"]:
            conn.close()
            raise ValueError("Worksheets can only be printed for a job visit")
        visit = dict(visit)
        job_id = visit["job_id"]

    if job_id:
        job = conn.execute("""
            SELECT j.*,
                   c.name      AS contact_name,
                   c.email     AS contact_email,
                   c.phone     AS contact_phone,
                   c.address   AS contact_address,
                   c.city      AS contact_city,
                   c.state     AS contact_state,
                   c.postcode  AS contact_postcode
            FROM jobs j
            LEFT JOIN contacts c ON j.contact_id = c.id
            WHERE j.id = ?
        """, (job_id,)).fetchone()
        if not job:
            conn.close()
            raise ValueError(f"Job {job_id} not found")

        if visit:
            # Only this visit's tasks, with progress recorded elsewhere so the
            # sheet can say how many are already done.
            work_tasks = conn.execute("""
                SELECT wt.*, vt.completed AS visit_completed, vt.qty_done AS visit_qty,
                       (SELECT COALESCE(SUM(x.qty_done),0) FROM visit_tasks x
                         WHERE x.task_id = wt.id AND x.visit_id <> vt.visit_id) AS progress_other
                FROM visit_tasks vt JOIN work_tasks wt ON wt.id = vt.task_id
                WHERE vt.visit_id = ?
                ORDER BY vt.id
            """, (visit_id,)).fetchall()
        else:
            crm_tasks = conn.execute("""
                SELECT * FROM crm_tasks
                WHERE job_id = ?
                ORDER BY is_done, due_date, priority DESC, id
            """, (job_id,)).fetchall()

            work_tasks = conn.execute("""
                SELECT * FROM work_tasks
                WHERE job_id = ?
                ORDER BY is_done, id
            """, (job_id,)).fetchall()

    else:
        contact = conn.execute(
            "SELECT * FROM contacts WHERE id = ?", (contact_id,)
        ).fetchone()
        if not contact:
            conn.close()
            raise ValueError(f"Contact {contact_id} not found")

        work_tasks = conn.execute("""
            SELECT * FROM work_tasks
            WHERE contact_id = ?
            ORDER BY is_done, id DESC
        """, (contact_id,)).fetchall()

    company = conn.execute("SELECT * FROM company").fetchone()
    conn.close()

    co = dict(company) if company else {}
    th = _resolve_theme(_load_doc_theme(co))

    today_str = date.today().strftime("%d/%m/%Y")
    if visit:
        # A visit sheet is dated for the visit, not the day it was printed.
        today_str = _fmt_iso(visit["event_date"])
        visit_time = ("All day" if visit.get("all_day") or not visit.get("start_time")
                      else f"{visit['start_time']} – {visit.get('end_time') or ''}")

    if job_id:
        j = dict(job)
        ref = j.get("job_number") or f"JOB{job_id}"
        doc_name = j.get("name") or ""
        doc_desc = (j.get("description") or "").strip()
        client_name  = j.get("contact_name") or ""
        client_addr  = ", ".join(filter(None, [
            j.get("contact_address"), j.get("contact_city"),
            j.get("contact_state"), j.get("contact_postcode"),
        ]))
        client_phone = j.get("contact_phone") or ""
        client_email = j.get("contact_email") or ""
        site_addr    = (j.get("site_address") or "").strip()
    else:
        ct = dict(contact)
        ref = f"WS-{date.today().strftime('%Y%m%d')}"
        doc_name = ""
        doc_desc = ""
        client_name  = ct.get("name") or ""
        client_addr  = ", ".join(filter(None, [
            ct.get("address"), ct.get("city"),
            ct.get("state"), ct.get("postcode"),
        ]))
        client_phone = ct.get("phone") or ""
        client_email = ct.get("email") or ""
        site_addr    = ""

    if output_path is None:
        output_path = os.path.join(
            tempfile.mkdtemp(), f"worksheet_{ref}.pdf"
        )

    s = _s(th)

    s["section_hdr"] = ParagraphStyle(
        "section_hdr", fontName="Helvetica-Bold",
        fontSize=8, textColor=_c(th["label_colour"]),
        leading=11, spaceAfter=1, textTransform="uppercase",
    )
    s["fill_lbl"] = ParagraphStyle(
        "fill_lbl", fontName="Helvetica",
        fontSize=7, textColor=_c(th["dim_text"]),
        leading=9, textTransform="uppercase",
    )
    s["task_done"] = ParagraphStyle(
        "task_done", fontName="Helvetica",
        fontSize=9, textColor=_c(th["dim_text"]),
        leading=13,
    )

    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        leftMargin=18*mm, rightMargin=18*mm,
        topMargin=14*mm, bottomMargin=14*mm,
        title=f"Worksheet {ref}",
        author=co.get("name", ""),
    )
    story = []

    _build_header(story, co, "VISIT WORKSHEET" if visit else "WORKSHEET", s, th)

    # ── Client + reference block ───────────────────────────────────────────────
    client_elems = [Paragraph("Client", s["label"])]
    if client_name:
        client_elems.append(Paragraph(client_name, s["body_b"]))
    if client_addr:
        client_elems.append(Paragraph(client_addr, s["body"]))
    if client_phone:
        client_elems.append(Paragraph(client_phone, s["small"]))
    if client_email:
        client_elems.append(Paragraph(client_email, s["small"]))

    if site_addr:
        from xml.sax.saxutils import escape as _x
        client_elems += [
            Spacer(1, 3*mm),
            Paragraph("Site", s["fill_lbl"]),
            Paragraph(_x(site_addr).replace("\n", "<br/>"), s["body"]),
        ]
    else:
        client_elems += [
            Spacer(1, 3*mm),
            Paragraph("Site address (if different)", s["fill_lbl"]),
            Paragraph("_" * 42, s["small"]),
            Spacer(1, 1*mm),
            Paragraph("_" * 42, s["small"]),
        ]

    lbl_w = 25*mm
    val_w = PAGE_W * 0.5 - lbl_w
    ref_rows = [
        [Paragraph("Reference", s["label"]), Paragraph(ref, s["body"])],
        [Paragraph("Date", s["label"]),      Paragraph(today_str, s["body"])],
    ]
    if visit:
        ref_rows += [
            [Paragraph("Time", s["label"]),     Paragraph(visit_time, s["body"])],
            [Paragraph("On site", s["label"]),  Paragraph("Arrive ______  Leave ______", s["body"])],
            [Paragraph("Hours", s["label"]),    Paragraph("______", s["body"])],
        ]
    elif job_id:
        j = dict(job)
        ref_rows += [
            [Paragraph("Status", s["label"]),  Paragraph(j.get("status") or "—", s["body"])],
            [Paragraph("Manager", s["label"]), Paragraph(j.get("manager") or "—", s["body"])],
        ]

    ref_tbl = Table(ref_rows, colWidths=[lbl_w, val_w])
    ref_tbl.setStyle(TableStyle([
        ("TOPPADDING",    (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ("LEFTPADDING",   (0, 0), (-1, -1), 0),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 4),
        ("VALIGN",        (0, 0), (-1, -1), "TOP"),
    ]))

    identity_tbl = Table(
        [[client_elems, ref_tbl]],
        colWidths=[PAGE_W * 0.50, PAGE_W * 0.50],
    )
    identity_tbl.setStyle(TableStyle([
        ("VALIGN",       (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING",  (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))
    story.append(identity_tbl)
    story.append(Spacer(1, 3*mm))

    # ── Job name + description ─────────────────────────────────────────────────
    if visit and (visit.get("description") or "").strip():
        doc_desc = (doc_desc + "\n\n" if doc_desc else "") + "Visit notes: " + visit["description"].strip()
    if doc_name or doc_desc:
        story.append(HRFlowable(width="100%", thickness=1,
                                 color=_c(th["rule_colour"]), spaceAfter=3))
        if doc_name:
            story.append(Paragraph(doc_name, s["body_b"]))
        if doc_desc:
            story.append(Spacer(1, 1*mm))
            story.append(Paragraph(doc_desc.replace("\n", "<br/>"), s["body"]))
        story.append(Spacer(1, 3*mm))

    # ── Task table ─────────────────────────────────────────────────────────────
    all_tasks = []
    for t in crm_tasks:
        td = dict(t)
        all_tasks.append({
            "done": bool(td.get("is_done")),
            "title": td.get("title") or "",
            "description": td.get("description") or "",
        })
    for t in work_tasks:
        td = dict(t)
        task = {
            "done": bool(td.get("is_done")),
            "title": td.get("title") or "",
            "description": td.get("description") or "",
        }
        if visit:
            qty = float(td.get("qty") or 1)
            is_qty = (td.get("billing") or "fixed") == "fixed" and qty > 1
            before = float(td.get("progress_other") or 0)
            task["done"] = bool(td.get("visit_completed"))
            task["qty"] = qty if is_qty else None
            task["visit_qty"] = td.get("visit_qty")
            if is_qty and before:
                task["description"] = (task["description"] + " — " if task["description"] else "") + \
                    f"{before:g} of {qty:g} already done"
        all_tasks.append(task)

    # Pad to minimum rows so blank worksheets are still useful; a visit sheet
    # always gets spare rows for work that wasn't planned.
    min_rows = max(len(all_tasks) + 2, _MIN_TASK_ROWS) if visit else _MIN_TASK_ROWS
    while len(all_tasks) < min_rows:
        all_tasks.append({"done": False, "title": "", "description": ""})

    notes_w = PAGE_W - 8*mm - PAGE_W * 0.44 - 28*mm

    task_data = [[
        Paragraph("", s["tbl_hdr"]),
        Paragraph("Task / Description", s["tbl_hdr"]),
        Paragraph("Qty done" if visit else "Time", s["tbl_hdr"]),
        Paragraph("Notes", s["tbl_hdr"]),
    ]]

    for t in all_tasks:
        done = t["done"]
        title_style = s["task_done"] if done else s["body"]
        title_cell = [Paragraph(t["title"], title_style)]
        if t["description"]:
            title_cell.append(Paragraph(t["description"], s["small"]))

        if visit:
            if t.get("qty"):
                done_now = t.get("visit_qty")
                time_cell = [Paragraph(f"{done_now:g}" if done_now else "______", s["body"]),
                             Paragraph(f"of {t['qty']:g}", s["small"])]
            else:
                time_cell = [Paragraph("", s["small"])]
        else:
            time_cell = [
                Paragraph("Start  __________", s["small"]),
                Spacer(1, 2*mm),
                Paragraph("Finish __________", s["small"]),
            ]

        notes_cell = [
            Paragraph("_" * 28, s["small"]),
            Spacer(1, 2*mm),
            Paragraph("_" * 28, s["small"]),
        ]

        task_data.append([
            _checkbox(done),
            title_cell,
            time_cell,
            notes_cell,
        ])

    task_tbl = Table(
        task_data,
        colWidths=[8*mm, PAGE_W * 0.44, 28*mm, notes_w],
        repeatRows=1,
    )
    task_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, 0),  _c(th["header_bg"])),
        ("TEXTCOLOR",     (0, 0), (-1, 0),  _c(th["header_text"])),
        ("FONTNAME",      (0, 0), (-1, 0),  "Helvetica-Bold"),
        ("FONTSIZE",      (0, 0), (-1, 0),  8),
        ("FONTSIZE",      (0, 1), (-1, -1), 9),
        ("TOPPADDING",    (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING",   (0, 0), (-1, -1), 4),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 4),
        ("GRID",          (0, 0), (-1, -1), 0.4, _c(th["rule_colour"])),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [_c(th["row_alt"]), colors.white]),
        ("VALIGN",        (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(task_tbl)
    story.append(Spacer(1, 4*mm))

    # ── Materials used ─────────────────────────────────────────────────────────
    mat_data = [[
        Paragraph("Item / Description", s["tbl_hdr"]),
        Paragraph("Qty", s["tbl_hdr_r"]),
        Paragraph("Unit", s["tbl_hdr"]),
    ]] + [["", "", ""] for _ in range(3 if visit else _MAT_ROWS)]  # a visit sheet fits one page

    mat_tbl = Table(
        mat_data,
        colWidths=[PAGE_W * 0.60, 28*mm, PAGE_W - PAGE_W * 0.60 - 28*mm],
    )
    mat_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, 0),  _c(th["header_bg"])),
        ("TEXTCOLOR",     (0, 0), (-1, 0),  _c(th["header_text"])),
        ("FONTNAME",      (0, 0), (-1, 0),  "Helvetica-Bold"),
        ("FONTSIZE",      (0, 0), (-1, 0),  8),
        ("TOPPADDING",    (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING",   (0, 0), (-1, -1), 4),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 4),
        ("GRID",          (0, 0), (-1, -1), 0.4, _c(th["rule_colour"])),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [_c(th["row_alt"]), colors.white]),
    ]))

    story.append(KeepTogether([
        Paragraph("Materials Used", s["section_hdr"]),
        Spacer(1, 1*mm),
        mat_tbl,
        Spacer(1, 4*mm),
    ]))

    # ── Work performed fill-in ─────────────────────────────────────────────────
    story.append(Paragraph("Work Performed", s["section_hdr"]))
    story.append(Spacer(1, 1*mm))
    for _ in range(2):
        story.append(HRFlowable(width="100%", thickness=0.5,
                                 color=_c(th["rule_colour"]), spaceBefore=4, spaceAfter=5))
    story.append(Spacer(1, 4*mm))

    # ── Notes + Follow-up (two column) ─────────────────────────────────────────
    def _fill_col(title, lines=3):
        out = [Paragraph(title, s["section_hdr"]), Spacer(1, 1*mm)]
        for _ in range(lines):
            out += [
                HRFlowable(width="100%", thickness=0.5,
                            color=_c(th["rule_colour"]), spaceBefore=4, spaceAfter=5),
            ]
        return out

    half = PAGE_W * 0.50 - 3*mm
    two_col = Table(
        [[_fill_col("Notes / Comments", 2 if visit else 3),
          _fill_col("Follow-up Items", 2 if visit else 3)]],
        colWidths=[half, half],
    )
    two_col.setStyle(TableStyle([
        ("VALIGN",       (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING",  (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (0, -1),  6*mm),
        ("RIGHTPADDING", (1, 0), (1, -1),  0),
        ("TOPPADDING",   (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING",(0, 0), (-1, -1), 0),
    ]))
    story.append(two_col)
    story.append(Spacer(1, 3*mm))

    # ── Sign-off ───────────────────────────────────────────────────────────────
    # Labels go below their lines so both columns align at the same vertical level.
    # Declaration spans full width above so it doesn't offset the client column.
    def _sig_block(name_label):
        return [
            Paragraph("_" * 36, s["small"]),
            Paragraph(name_label, s["fill_lbl"]),
            Spacer(1, 12*mm),
            Paragraph("_" * 36, s["small"]),
            Paragraph("Signature", s["fill_lbl"]),
            Spacer(1, 3*mm),
            Paragraph("_" * 22, s["small"]),
            Paragraph("Date", s["fill_lbl"]),
        ]

    sig_tbl = Table(
        [[_sig_block("Worker Name"), _sig_block("Client Name")]],
        colWidths=[PAGE_W * 0.50, PAGE_W * 0.50],
    )
    sig_tbl.setStyle(TableStyle([
        ("VALIGN",       (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING",  (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6*mm),
        ("RIGHTPADDING", (1, 0), (1, -1),  0),
        ("TOPPADDING",   (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING",(0, 0), (-1, -1), 0),
    ]))

    footer_txt = "  —  ".join(
        p for p in [f"{'Visit worksheet' if visit else 'Worksheet'} {ref}",
                    doc_name or client_name, today_str] if p
    )
    story.append(KeepTogether([
        HRFlowable(width="100%", thickness=1,
                   color=_c(th["rule_colour"]), spaceAfter=2),
        Paragraph(
            "Client acknowledgment: by signing, the client confirms the above work was "
            "completed to their satisfaction.",
            s["small"],
        ),
        Spacer(1, 3*mm),
        sig_tbl,
    ]))

    _cb = _make_ws_callback(footer_txt, watermark=watermark, licence_footer=footer)
    doc.build(story, onFirstPage=_cb, onLaterPages=_cb)
    return output_path
