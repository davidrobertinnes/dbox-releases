# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Fair Work Commission Modern Awards Pay Database (MAPD) API client.

Base URL:  https://api.fwc.gov.au/api/v1
Auth:      Ocp-Apim-Subscription-Key header (obtain from developer.fwc.gov.au)
Docs:      https://developer.fwc.gov.au/api-details#api=fwc-maapi-v1

Key response field names (confirmed from OpenAPI spec):
  Classifications:  classification_fixed_id, classification, classification_level,
                    clause_description, parent_classification_name, operative_from
  Pay rates:        classification_fixed_id, base_pay_rate_id, base_rate, base_rate_type,
                    calculated_rate, calculated_rate_type, employee_rate_type_code, operative_from
  Wage allowances:  wage_allowance_fixed_id, allowance, rate, rate_unit,
                    allowance_amount, payment_frequency, operative_from
  Expense allow.:   expense_allowance_fixed_id, allowance, allowance_amount,
                    payment_frequency, operative_from
  Penalties:        penalty_fixed_id, penalty_description, rate,
                    employee_rate_type_code, penalty_calculated_value, operative_from
"""

import json
import urllib.error
import urllib.parse
import urllib.request

FWC_BASE = "https://api.fwc.gov.au/api/v1"
_LIMIT   = 100   # max the API accepts


def _headers(api_key: str) -> dict:
    return {
        "Ocp-Apim-Subscription-Key": api_key,
        "Accept": "application/json",
    }


def _get(api_key: str, path: str, params: dict = None) -> dict:
    url = FWC_BASE + path
    if params:
        url += "?" + urllib.parse.urlencode(
            {k: v for k, v in params.items() if v is not None}
        )
    req = urllib.request.Request(url, headers=_headers(api_key))
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="ignore")
        raise RuntimeError(f"FWC API error {e.code}: {body[:200]}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"FWC connection error: {e.reason}") from e


def search_awards(api_key: str, name: str = None,
                  page: int = 1, limit: int = 50) -> dict:
    """GET /awards — search/list awards by name."""
    params = {"page": page, "limit": limit, "sort": "name asc"}
    if name:
        params["name"] = name.strip().replace(" ", "+")
    data = _get(api_key, "/awards", params)
    return {
        "meta":    data.get("_meta", {}),
        "results": data.get("results", []),
    }


def get_fwc_award(api_key: str, code: str) -> dict | None:
    """Fetch a single award by MA code. Tries direct lookup then search fallback."""
    try:
        data = _get(api_key, f"/awards/{code}")
        results = data.get("results", [])
        if results:
            return results[0]
        if data.get("code") or data.get("name"):
            return data
    except RuntimeError:
        pass
    try:
        hit = search_awards(api_key, name=code)
        for r in hit.get("results", []):
            if str(r.get("code", "")).upper() == code.upper():
                return r
    except RuntimeError:
        pass
    return None


def _get_all_pages(api_key: str, path: str, params: dict = None) -> list:
    """Fetch all pages from a paginated FWC endpoint, returning merged results."""
    params = dict(params or {})
    params["limit"] = _LIMIT
    results = []
    page = 1
    while True:
        params["page"] = page
        try:
            data = _get(api_key, path, params)
        except RuntimeError:
            break
        results.extend(data.get("results") or [])
        if not data.get("_meta", {}).get("has_more_results"):
            break
        page += 1
    return results


def get_fwc_classifications(api_key: str, code: str) -> list:
    """GET /awards/{code}/classifications
    Fields: classification_fixed_id, classification, classification_level,
            clause_description, parent_classification_name, operative_from
    Sorted by clause document position first, then level within each clause.
    """
    return _get_all_pages(api_key, f"/awards/{code}/classifications",
                          {"sort": "clause_fixed_id asc, classification_level asc"})


def get_fwc_payrates_for_classification(api_key: str, code: str,
                                         classification_fixed_id) -> list:
    """GET /awards/{code}/classifications/{id}/pay-rates
    Returns all current pay rate rows for one classification.
    Fields: classification_fixed_id, base_pay_rate_id, base_rate, base_rate_type,
            calculated_rate, calculated_rate_type, employee_rate_type_code, operative_from
    """
    try:
        data = _get(
            api_key,
            f"/awards/{code}/classifications/{classification_fixed_id}/pay-rates",
            {"limit": _LIMIT},
        )
        return data.get("results", [])
    except RuntimeError:
        return []


def get_fwc_wage_allowances(api_key: str, code: str) -> list:
    """GET /awards/{code}/wage-allowances
    Fields: wage_allowance_fixed_id, allowance, rate, rate_unit,
            allowance_amount, payment_frequency, operative_from
    """
    try:
        data = _get(api_key, f"/awards/{code}/wage-allowances", {"limit": _LIMIT})
        return data.get("results", [])
    except RuntimeError:
        return []


def get_fwc_expense_allowances(api_key: str, code: str) -> list:
    """GET /awards/{code}/expense-allowances
    Fields: expense_allowance_fixed_id, allowance, allowance_amount,
            payment_frequency, operative_from
    """
    try:
        data = _get(api_key, f"/awards/{code}/expense-allowances", {"limit": _LIMIT})
        return data.get("results", [])
    except RuntimeError:
        return []


def get_fwc_penalties(api_key: str, code: str) -> list:
    """GET /awards/{code}/penalties — all pages.
    Fields: penalty_fixed_id, penalty_description, rate,
            employee_rate_type_code, penalty_calculated_value, operative_from
    """
    return _get_all_pages(api_key, f"/awards/{code}/penalties")
