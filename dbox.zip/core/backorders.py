# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from datetime import date as _date
from core.database import get_connection


def _ensure_table(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS backorders (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_id      INTEGER REFERENCES invoices(id),
        item_id         INTEGER REFERENCES items(id),
        item_code       TEXT,
        item_name       TEXT,
        qty_ordered     REAL NOT NULL,
        qty_fulfilled   REAL NOT NULL DEFAULT 0,
        status          TEXT NOT NULL DEFAULT 'Pending',
        created_date    TEXT NOT NULL,
        expected_date   TEXT,
        fulfilled_date  TEXT,
        po_id           INTEGER,
        notes           TEXT,
        created_at      TEXT DEFAULT (datetime('now','localtime'))
    )""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_backorders_status ON backorders(status)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_backorders_item   ON backorders(item_id)")


def create_backorder(db_path, invoice_id, item_id, item_code, item_name,
                     qty_ordered, created_date, notes=None):
    conn = get_connection(db_path)
    _ensure_table(conn)
    cur = conn.execute(
        """INSERT INTO backorders
               (invoice_id, item_id, item_code, item_name, qty_ordered, created_date, notes)
           VALUES (?,?,?,?,?,?,?)""",
        (invoice_id, item_id, item_code, item_name,
         float(qty_ordered), created_date, notes)
    )
    bo_id = cur.lastrowid
    conn.commit()
    conn.close()
    return bo_id


def get_all_backorders(db_path):
    conn = get_connection(db_path)
    _ensure_table(conn)
    rows = conn.execute("""
        SELECT b.*,
               i.invoice_number,
               c.name AS contact_name,
               b.qty_ordered - b.qty_fulfilled AS qty_outstanding
        FROM backorders b
        LEFT JOIN invoices i ON i.id = b.invoice_id
        LEFT JOIN contacts c ON c.id = i.contact_id
        ORDER BY
            CASE b.status
                WHEN 'Pending'             THEN 0
                WHEN 'Partially Fulfilled' THEN 1
                WHEN 'Fulfilled'           THEN 2
                ELSE 3
            END,
            b.created_date, b.id
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_pending_backorders(db_path):
    conn = get_connection(db_path)
    _ensure_table(conn)
    rows = conn.execute("""
        SELECT b.*,
               i.invoice_number,
               c.name AS contact_name,
               b.qty_ordered - b.qty_fulfilled AS qty_outstanding
        FROM backorders b
        LEFT JOIN invoices i ON i.id = b.invoice_id
        LEFT JOIN contacts c ON c.id = i.contact_id
        WHERE b.status IN ('Pending','Partially Fulfilled')
        ORDER BY b.created_date, b.id
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_backorder_count(db_path):
    conn = get_connection(db_path)
    _ensure_table(conn)
    row = conn.execute(
        "SELECT COUNT(*) FROM backorders WHERE status IN ('Pending','Partially Fulfilled')"
    ).fetchone()
    conn.close()
    return row[0] if row else 0


def fulfill_backorder(db_path, backorder_id, qty, fulfilled_date=None):
    if not fulfilled_date:
        fulfilled_date = str(_date.today())
    conn = get_connection(db_path)
    _ensure_table(conn)
    row = conn.execute("SELECT * FROM backorders WHERE id=?", (backorder_id,)).fetchone()
    if not row:
        conn.close()
        raise ValueError("Backorder not found")
    bo = dict(row)
    if bo["status"] in ("Fulfilled", "Cancelled"):
        conn.close()
        raise ValueError(f"Backorder is already {bo['status']}")
    qty = float(qty)
    if qty <= 0:
        conn.close()
        raise ValueError("Fulfillment quantity must be greater than zero")
    outstanding = bo["qty_ordered"] - bo["qty_fulfilled"]
    qty = min(qty, outstanding)
    new_fulfilled = bo["qty_fulfilled"] + qty
    remaining = bo["qty_ordered"] - new_fulfilled
    status = "Fulfilled" if remaining <= 0.001 else "Partially Fulfilled"
    conn.execute(
        """UPDATE backorders
           SET qty_fulfilled = ?,
               status        = ?,
               fulfilled_date = CASE WHEN ? = 'Fulfilled' THEN ? ELSE fulfilled_date END
           WHERE id = ?""",
        (new_fulfilled, status, status, fulfilled_date, backorder_id)
    )
    conn.commit()
    conn.close()
    return {
        "status": status,
        "qty_fulfilled": new_fulfilled,
        "qty_outstanding": max(0.0, remaining),
    }


def cancel_backorder(db_path, backorder_id):
    conn = get_connection(db_path)
    _ensure_table(conn)
    conn.execute(
        "UPDATE backorders SET status='Cancelled' WHERE id=? AND status NOT IN ('Fulfilled','Cancelled')",
        (backorder_id,)
    )
    conn.commit()
    conn.close()


def get_backorders_for_items(db_path, item_ids):
    """Return pending backorders for a list of item_ids — called after PO receive."""
    if not item_ids:
        return []
    conn = get_connection(db_path)
    _ensure_table(conn)
    placeholders = ",".join("?" * len(item_ids))
    rows = conn.execute(f"""
        SELECT b.*,
               i.invoice_number,
               c.name AS contact_name,
               b.qty_ordered - b.qty_fulfilled AS qty_outstanding
        FROM backorders b
        LEFT JOIN invoices i ON i.id = b.invoice_id
        LEFT JOIN contacts c ON c.id = i.contact_id
        WHERE b.item_id IN ({placeholders})
          AND b.status IN ('Pending','Partially Fulfilled')
        ORDER BY b.created_date, b.id
    """, item_ids).fetchall()
    conn.close()
    return [dict(r) for r in rows]
