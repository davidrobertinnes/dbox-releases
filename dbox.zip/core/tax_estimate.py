# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Tax estimate engine for sole traders.

Annualises YTD net profit, applies current-year ATO individual income tax
rates (with optional LITO, Medicare levy, and HELP/HECS repayment), then
pro-rates the result back to the number of days elapsed in the financial year.

Settings stored in app_settings table:
  tax_est_tfr        — '1'/'0'  tax-free threshold claimed (default 1)
  tax_est_help       — '1'/'0'  HELP/HECS debt (default 0)
  tax_est_account_id — account ID for tax savings account (default '')
"""

from datetime import date
from core.database import get_connection
from core.payroll import load_payg_rates, current_fy
from core.ledger import profit_and_loss


# ── App settings helpers ──────────────────────────────────────────────────────

def _ensure_settings_table(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS app_settings (
        key        TEXT PRIMARY KEY,
        value      TEXT,
        updated_at TEXT DEFAULT (datetime('now','localtime')))""")


def _read_settings(conn):
    try:
        rows = conn.execute(
            "SELECT key, value FROM app_settings WHERE key LIKE 'tax_est_%'"
        ).fetchall()
        s = {r['key']: r['value'] for r in rows}
    except Exception:
        s = {}
    return {
        'tfr':        s.get('tax_est_tfr', '1') not in ('0', 'false', ''),
        'help_debt':  s.get('tax_est_help', '0') in ('1', 'true'),
        'account_id': int(s['tax_est_account_id'])
                      if s.get('tax_est_account_id', '').isdigit() else None,
    }


def get_tax_settings(db_path):
    conn = get_connection(db_path)
    _ensure_settings_table(conn)
    s = _read_settings(conn)
    if s['account_id']:
        row = conn.execute(
            "SELECT name FROM accounts WHERE id=?", (s['account_id'],)
        ).fetchone()
        s['account_name'] = row['name'] if row else None
    else:
        s['account_name'] = None
    conn.close()
    return s


def save_tax_settings(db_path, data):
    conn = get_connection(db_path)
    _ensure_settings_table(conn)
    pairs = {
        'tax_est_tfr':        '1' if data.get('tfr', True) else '0',
        'tax_est_help':       '1' if data.get('help_debt', False) else '0',
        'tax_est_account_id': str(data['account_id'])
                              if data.get('account_id') else '',
    }
    for k, v in pairs.items():
        conn.execute("""INSERT INTO app_settings (key, value)
            VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET
                value=excluded.value,
                updated_at=datetime('now','localtime')""", (k, v))
    conn.commit()
    conn.close()


# ── Tax calculation functions ─────────────────────────────────────────────────

def _calc_income_tax(income, brackets):
    """
    Marginal bracket calculation.
    Format: [[threshold, base_tax_at_threshold, marginal_rate], ...]
    """
    if income <= 0 or not brackets:
        return 0.0
    tax = 0.0
    for i in range(len(brackets) - 1, -1, -1):
        thresh, base, rate = brackets[i]
        if income > thresh:
            tax = base + (income - thresh) * rate
            break
    return max(0.0, tax)


def _calc_medicare(income, medicare):
    full_rate      = medicare.get('full_rate', 0.02)
    full_start     = medicare.get('full_start', 35013.0)
    shade_start    = medicare.get('shade_in_start', 28011.0)
    shade_rate     = medicare.get('shade_in_rate', 0.10)
    if income < shade_start:
        return 0.0
    if income < full_start:
        return (income - shade_start) * shade_rate
    return income * full_rate


def _calc_lito(income):
    """LITO — unchanged since 2020-21. Max $700."""
    if income <= 37500:
        return 700.0
    if income <= 45000:
        return max(0.0, 700.0 - (income - 37500) * 0.05)
    if income <= 66667:
        return max(0.0, 325.0 - (income - 45000) * 0.015)
    return 0.0


def _calc_help(income, help_table, help_method):
    """
    HELP/VSL repayment on annualised income.

    Marginal method (from FY2025-26):
      [[threshold, rate], ...] — negative rate sentinel triggers whole-income 10%.
    Whole-income method (pre-FY2025-26):
      [[threshold, rate], ...] — find highest applicable band, apply to full income.
    """
    if not help_table or income <= 0:
        return 0.0

    if help_method == 'marginal':
        # Check whole-income sentinel (negative rate)
        for thresh, rate in help_table:
            if rate < 0 and income > thresh:
                return income * abs(rate)
        # Marginal bands — positive rates only
        bands = [(t, r) for t, r in help_table if r > 0]
        repayment = 0.0
        for i, (thresh, rate) in enumerate(bands):
            if income <= thresh:
                break
            next_thresh = bands[i + 1][0] if i + 1 < len(bands) else income
            band_income = min(income, next_thresh) - thresh
            if band_income > 0:
                repayment += band_income * rate
        return max(0.0, repayment)
    else:
        # Whole-income method
        applicable = 0.0
        for thresh, rate in help_table:
            if income >= thresh:
                applicable = rate
        return income * applicable


# ── Main estimate ─────────────────────────────────────────────────────────────

def get_tax_estimate(db_path):
    """
    Returns a full tax estimate dict for the current financial year.
    All monetary values in AUD, rounded to 2 dp.
    """
    today        = date.today()
    fy           = current_fy()                         # e.g. 2026 for FY2026-27
    fy_start     = date(fy, 7, 1)
    fy_end       = date(fy + 1, 6, 30)
    days_in_fy   = (fy_end - fy_start).days + 1
    days_elapsed = max(1, (today - fy_start).days + 1)
    fy_label     = f"FY{str(fy)[2:]}/{str(fy + 1)[2:]}"

    conn = get_connection(db_path)
    _ensure_settings_table(conn)
    s = _read_settings(conn)

    # Tax account balance
    account_id      = s['account_id']
    account_name    = None
    account_balance = None
    if account_id:
        acc = conn.execute(
            "SELECT name, account_type, opening_balance FROM accounts WHERE id=?",
            (account_id,)
        ).fetchone()
        if acc:
            account_name = acc['name']
            net_row = conn.execute(
                "SELECT COALESCE(SUM(debit),0)-COALESCE(SUM(credit),0) AS net "
                "FROM journal_lines WHERE account_id=?", (account_id,)
            ).fetchone()
            net = float(net_row['net'] or 0.0) if net_row else 0.0
            ob  = float(acc['opening_balance'] or 0.0)
            account_balance = round(
                ob + net if acc['account_type'] in ('Asset', 'Expense')
                else ob - net, 2
            )
    conn.close()

    # YTD net profit
    try:
        pl             = profit_and_loss(db_path, str(fy_start), str(today))
        net_profit_ytd = round(float(pl.get('net_profit', 0.0) or 0.0), 2)
    except Exception:
        net_profit_ytd = 0.0

    # Annualise
    annualised = round(net_profit_ytd / days_elapsed * days_in_fy, 2)

    # Load ATO rates for current FY from payg_tax_rates (fy_year = fy+1)
    rates = load_payg_rates(db_path, fy + 1)

    income_tax = medicare = lito = help_amt = annual_tax = 0.0
    if rates and annualised > 0:
        brackets   = rates['brackets'] if s['tfr'] else rates['brackets_no_thresh']
        medicare_p = rates['medicare']
        help_p     = rates['help']     if s['help_debt'] else []
        help_meth  = rates['help_method']

        income_tax = round(_calc_income_tax(annualised, brackets), 2)
        medicare   = round(_calc_medicare(annualised, medicare_p), 2)
        lito       = round(_calc_lito(annualised) if s['tfr'] else 0.0, 2)
        help_amt   = round(_calc_help(annualised, help_p, help_meth), 2)
        annual_tax = max(0.0, round(income_tax - lito + medicare + help_amt, 2))

    tax_accrued = round(annual_tax * days_elapsed / days_in_fy, 2) \
                  if days_in_fy > 0 else 0.0

    shortfall = None
    warning   = False
    if account_balance is not None and tax_accrued > 0:
        shortfall = round(tax_accrued - account_balance, 2)
        warning   = account_balance < tax_accrued

    return {
        'fy_label':             fy_label,
        'fy_start':             str(fy_start),
        'fy_end':               str(fy_end),
        'days_elapsed':         days_elapsed,
        'days_in_fy':           days_in_fy,
        'net_profit_ytd':       net_profit_ytd,
        'annualised_income':    annualised,
        'estimated_annual_tax': annual_tax,
        'tax_accrued':          tax_accrued,
        'breakdown': {
            'income_tax': income_tax,
            'medicare':   medicare,
            'lito':       lito,
            'help':       help_amt,
        },
        'account_id':       account_id,
        'account_name':     account_name,
        'account_balance':  account_balance,
        'shortfall':        shortfall,
        'warning':          warning,
        'settings':         s,
    }
