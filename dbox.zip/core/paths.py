# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
core/paths.py — where dbox keeps its own files.

dbox's own files (licence, logs, launcher settings, browser profile, update
backups) live in a per-user folder, outside the install folder, so a
read-only install (e.g. Microsoft Store) still works. Company .dbox files
are not affected — they live wherever the user keeps them.

Standard library only, so any module (including core/logger.py, which is
set up before anything else) can import it.
"""

import os
import shutil
import sys


def user_data_dir() -> str:
    """
    Per-user folder for dbox's own files.

      Windows: %LOCALAPPDATA%\\Dogbox
      macOS:   ~/Library/Application Support/Dogbox
      Linux:   $XDG_DATA_HOME/dogbox (default ~/.local/share/dogbox)
    """
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or os.path.join(
            os.path.expanduser("~"), "AppData", "Local")
        return os.path.join(base, "Dogbox")
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~"), "Library",
                            "Application Support", "Dogbox")
    base = os.environ.get("XDG_DATA_HOME") or os.path.join(
        os.path.expanduser("~"), ".local", "share")
    return os.path.join(base, "dogbox")


_store_install: bool | None = None


def is_store_install() -> bool:
    """
    True when running from an MSIX package (the Microsoft Store build).
    The Store updates the app itself, so dbox's own updater stays off.

    Set DBOX_STORE_BUILD=1 to test the Store behaviour from a normal install.
    """
    global _store_install
    if _store_install is None:
        _store_install = (os.environ.get("DBOX_STORE_BUILD") == "1"
                          or _has_package_identity())
    return _store_install


def _has_package_identity() -> bool:
    if sys.platform != "win32":
        return False
    try:
        import ctypes
        length = ctypes.c_uint32(0)
        rc = ctypes.windll.kernel32.GetCurrentPackageFullName(
            ctypes.byref(length), None)
        # ERROR_INSUFFICIENT_BUFFER (122): packaged; APPMODEL_ERROR_NO_PACKAGE
        # (15700): not. Missing before Windows 8 → AttributeError → not packaged.
        return rc == 122
    except Exception:
        return False


def user_data_path(name: str, legacy_path: str | None = None) -> str:
    """
    Path of `name` (a file or folder) inside user_data_dir(), creating the
    folder.

    If `name` isn't there yet but `legacy_path` (where older versions kept it)
    exists, it is moved across first. Folders are renamed, never copied, so
    a large folder moves instantly. If the move fails (e.g. a browser still
    has the folder open, it's on another drive, or the folder can't be
    created), `legacy_path` is returned so nothing is lost; the move is
    retried on the next launch.
    """
    d = user_data_dir()
    path = os.path.join(d, name)
    if os.path.exists(path):
        return path
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        if legacy_path and os.path.exists(legacy_path):
            return legacy_path
        raise
    if legacy_path and os.path.exists(legacy_path):
        try:
            if os.path.isdir(legacy_path):
                # Rename only: shutil.move's copy-then-delete fallback could
                # half-delete a folder whose files are open (e.g. the browser
                # profile while dbox is already running) or on another drive
                os.rename(legacy_path, path)
            else:
                shutil.move(legacy_path, path)
        except (OSError, shutil.Error):
            # A failed cross-drive move can leave a partial copy behind
            if os.path.exists(legacy_path) and os.path.exists(path):
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    try:
                        os.remove(path)
                    except OSError:
                        pass
            return legacy_path
    return path
