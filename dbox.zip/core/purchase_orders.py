# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Accounting — Purchase Orders

Workflow:
  Draft → Sent → Partially Received → Received → Billed
  (or)  → Cancelled

A PO can be:
  • Created manually from Bills screen
  • Created from a CRM Quote (supplier PO for fulfilment)
  • Converted to a Bill once goods/services are received
  • Linked to inventory items — receiving triggers stock movements
"""


from __future__ import annotations
from datetime import date as _date, timedelta as _td
from core.database import get_connection


# ─────────────────────────────────────────────────────────────────────────────
#  MIGRATION
# ─────────────────────────────────────────────────────────────────────────────

def migrate_purchase_orders(conn):
    """Create PO tables. Safe to call on existing databases."""

    conn.execute("""CREATE TABLE IF NOT EXISTS purchase_orders (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        po_number       TEXT NOT NULL,
        contact_id      INTEGER NOT NULL REFERENCES contacts(id),
        contact_name    TEXT,
        po_date         TEXT NOT NULL,
        expected_date   TEXT,
        status          TEXT NOT NULL DEFAULT 'Draft',
        -- Draft | Sent | Partially Received | Received | Billed | Cancelled
        subtotal        REAL NOT NULL DEFAULT 0,
        gst_total       REAL NOT NULL DEFAULT 0,
        total           REAL NOT NULL DEFAULT 0,
        notes           TEXT,
        internal_notes  TEXT,
        delivery_address TEXT,
        -- Links
        crm_quote_id    INTEGER,   -- source CRM quote if generated from CRM
        bill_id         INTEGER REFERENCES bills(id),   -- resulting bill
        created_by      TEXT,
        created_at      TEXT DEFAULT (datetime('now','localtime')),
        updated_at      TEXT DEFAULT (datetime('now','localtime'))
    )""")

    conn.execute("""CREATE TABLE IF NOT EXISTS po_lines (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        po_id           INTEGER NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
        item_id         INTEGER REFERENCES items(id),
        description     TEXT NOT NULL,
        quantity        REAL NOT NULL DEFAULT 1,
        unit_price      REAL NOT NULL DEFAULT 0,
        tax_code        TEXT NOT NULL DEFAULT 'GST',
        gst_amount      REAL DEFAULT 0,
        line_total      REAL DEFAULT 0,
        qty_received    REAL NOT NULL DEFAULT 0,   -- receiving tracking
        account_id      INTEGER REFERENCES accounts(id)
    )""")

    conn.execute("""CREATE INDEX IF NOT EXISTS idx_po_contact
        ON purchase_orders(contact_id)""")
    conn.execute("""CREATE INDEX IF NOT EXISTS idx_po_status
        ON purchase_orders(status)""")
    conn.execute("""CREATE INDEX IF NOT EXISTS idx_po_date
        ON purchase_orders(po_date)""")

    # Migration-safe: add po_id to bills if not present
    try:
        conn.execute("ALTER TABLE bills ADD COLUMN po_id INTEGER REFERENCES purchase_orders(id)")
    except Exception:
        pass

    # Migration-safe: job and opportunity links
    for col_sql in [
        "ALTER TABLE purchase_orders ADD COLUMN job_id INTEGER REFERENCES jobs(id)",
        "ALTER TABLE purchase_orders ADD COLUMN opportunity_id INTEGER",
    ]:
        try:
            conn.execute(col_sql)
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
#  NUMBERING
# ─────────────────────────────────────────────────────────────────────────────

def _next_po_number(conn) -> str:
    co = conn.execute("SELECT po_prefix, po_next FROM company WHERE id=1").fetchone()
    prefix = (co["po_prefix"] or "PO-") if co else "PO-"
    floor  = max(1, int(co["po_next"] or 1001)) if co else 1001
    row = conn.execute(
        "SELECT po_number FROM purchase_orders ORDER BY id DESC LIMIT 1"
    ).fetchone()
    num = floor
    if row and row["po_number"]:
        last = row["po_number"]
        stripped = last[len(prefix):] if last.startswith(prefix) else last
        try:
            num = max(int(stripped) + 1, floor)
        except ValueError:
            pass
    return f"{prefix}{num:04d}"


# ─────────────────────────────────────────────────────────────────────────────
#  CRUD
# ─────────────────────────────────────────────────────────────────────────────

def get_purchase_orders(db_path, status=None, contact_id=None, job_id=None) -> list:
    conn = get_connection(db_path)
    q = """SELECT po.*, c.name as contact_name_live,
                  j.name as job_name, j.job_number as job_number
           FROM purchase_orders po
           JOIN contacts c ON po.contact_id = c.id
           LEFT JOIN jobs j ON po.job_id = j.id
           WHERE 1=1"""
    params = []
    if status:
        q += " AND po.status = ?"
        params.append(status)
    if contact_id:
        q += " AND po.contact_id = ?"
        params.append(contact_id)
    if job_id:
        q += " AND po.job_id = ?"
        params.append(job_id)
    q += " ORDER BY po.po_date DESC, po.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_purchase_order(db_path, po_id: int) -> dict | None:
    conn = get_connection(db_path)
    po = conn.execute("""
        SELECT po.*, c.name as contact_name_live,
               j.name as job_name, j.job_number as job_number
        FROM purchase_orders po
        JOIN contacts c ON po.contact_id = c.id
        LEFT JOIN jobs j ON po.job_id = j.id
        WHERE po.id = ?
    """, (po_id,)).fetchone()
    if not po:
        conn.close()
        return None
    lines = conn.execute("""
        SELECT pl.*, i.name as item_name, i.code as item_code,
               a.name as account_name, a.code as account_code
        FROM po_lines pl
        LEFT JOIN items i ON pl.item_id = i.id
        LEFT JOIN accounts a ON pl.account_id = a.id
        WHERE pl.po_id = ?
        ORDER BY pl.id
    """, (po_id,)).fetchall()
    conn.close()
    return {"po": dict(po), "lines": [dict(l) for l in lines]}


def save_purchase_order(db_path, po_data: dict, lines: list,
                        created_by: str = None) -> int:
    """
    Save (create or update) a purchase order.
    po_data keys: id (optional), contact_id, po_date, expected_date,
                  status, notes, internal_notes, delivery_address,
                  crm_quote_id
    lines: list of dicts with item_id, description, quantity, unit_price,
                              tax_code, account_id
    Returns po_id.
    """
    from core.database import get_connection as _gc
    conn = _gc(db_path)
    conn.execute("BEGIN IMMEDIATE")

    # Compute totals
    subtotal = 0.0
    gst_total = 0.0
    processed = []
    for l in lines:
        qty   = float(l.get("quantity", 1) or 1)
        price = float(l.get("unit_price", 0) or 0)
        ex    = round(qty * price, 2)
        tax   = l.get("tax_code", "GST")
        # GST: 10% if GST, 0% otherwise
        gst   = round(ex * 0.1, 2) if tax == "GST" else 0.0
        lt    = round(ex + gst, 2)
        subtotal  += ex
        gst_total += gst
        processed.append({**l, "gst_amount": gst, "line_total": lt})

    total = round(subtotal + gst_total, 2)

    po_id = po_data.get("id")
    now   = _date.today().isoformat()

    job_id         = po_data.get("job_id") or None
    opportunity_id = po_data.get("opportunity_id") or None

    if po_id:
        conn.execute("""
            UPDATE purchase_orders
            SET contact_id=?, po_date=?, expected_date=?, status=?,
                subtotal=?, gst_total=?, total=?, notes=?, internal_notes=?,
                delivery_address=?, job_id=?, opportunity_id=?,
                updated_at=datetime('now','localtime')
            WHERE id=?
        """, (po_data["contact_id"], po_data["po_date"],
              po_data.get("expected_date"), po_data.get("status", "Draft"),
              subtotal, gst_total, total,
              po_data.get("notes"), po_data.get("internal_notes"),
              po_data.get("delivery_address"),
              job_id, opportunity_id, po_id))
        conn.execute("DELETE FROM po_lines WHERE po_id=?", (po_id,))
    else:
        po_num = _next_po_number(conn)
        conn.execute("""
            INSERT INTO purchase_orders
                (po_number, contact_id, po_date, expected_date, status,
                 subtotal, gst_total, total, notes, internal_notes,
                 delivery_address, crm_quote_id, job_id, opportunity_id,
                 created_by)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (po_num, po_data["contact_id"], po_data["po_date"],
              po_data.get("expected_date"),
              po_data.get("status", "Draft"),
              subtotal, gst_total, total,
              po_data.get("notes"), po_data.get("internal_notes"),
              po_data.get("delivery_address"),
              po_data.get("crm_quote_id"),
              job_id, opportunity_id,
              created_by))
        po_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    for l in processed:
        conn.execute("""
            INSERT INTO po_lines
                (po_id, item_id, description, quantity, unit_price,
                 tax_code, gst_amount, line_total, account_id)
            VALUES (?,?,?,?,?,?,?,?,?)
        """, (po_id,
              l.get("item_id"),
              l["description"],
              float(l.get("quantity", 1) or 1),
              float(l.get("unit_price", 0) or 0),
              l.get("tax_code", "GST"),
              l["gst_amount"],
              l["line_total"],
              l.get("account_id")))

    conn.commit()
    conn.close()
    return po_id


def approve_purchase_order(db_path, po_id: int):
    """Advance a Draft PO to Approved (internal sign-off before sending to supplier)."""
    conn = get_connection(db_path)
    conn.execute("UPDATE purchase_orders SET status='Approved' WHERE id=? AND status='Draft'",
                 (po_id,))
    conn.commit()
    conn.close()


def cancel_purchase_order(db_path, po_id: int):
    conn = get_connection(db_path)
    conn.execute("UPDATE purchase_orders SET status='Cancelled' WHERE id=?", (po_id,))
    conn.commit()
    conn.close()


# ─────────────────────────────────────────────────────────────────────────────
#  RECEIVING
# ─────────────────────────────────────────────────────────────────────────────

def receive_po_lines(db_path, po_id: int,
                     received: dict,   # {line_id: qty_received_now}
                     received_date: str = None,
                     created_by: str = None) -> str:
    """
    Record receipt of goods against a PO.
    Updates qty_received per line, triggers inventory movements,
    and updates PO status to 'Partially Received' or 'Received'.
    Returns new status.
    """
    if received_date is None:
        received_date = _date.today().isoformat()

    conn = get_connection(db_path)
    lines = conn.execute(
        "SELECT * FROM po_lines WHERE po_id=?", (po_id,)).fetchall()
    conn.close()

    total_ordered  = 0.0
    total_received = 0.0

    for ln in lines:
        ln = dict(ln)
        lid = ln["id"]
        add = float(received.get(lid, 0) or 0)
        if add > 0:
            new_recv = float(ln["qty_received"] or 0) + add
            conn2 = get_connection(db_path)
            conn2.execute(
                "UPDATE po_lines SET qty_received=? WHERE id=?",
                (new_recv, lid))
            conn2.commit()
            conn2.close()

            # Trigger inventory movement if item is tracked
            if ln.get("item_id"):
                try:
                    from core.inventory import post_stock_movement
                    post_stock_movement(
                        db_path,
                        ln["item_id"],
                        "PURCHASE",
                        received_date,
                        add,
                        unit_cost=float(ln["unit_price"] or 0),
                        reference=f"PO-{po_id}",
                        source_doc_type="purchase_order",
                        source_doc_id=po_id,
                        notes=f"Received against PO line {lid}",
                        created_by=created_by,
                        post_gl=True,
                    )
                except Exception:
                    pass

            total_received += new_recv
        else:
            total_received += float(ln["qty_received"] or 0)
        total_ordered += float(ln["quantity"] or 0)

    # Update PO status
    if total_ordered <= 0:
        new_status = "Received"
    elif total_received >= total_ordered:
        new_status = "Received"
    elif total_received > 0:
        new_status = "Partially Received"
    else:
        new_status = "Sent"   # nothing yet received

    conn3 = get_connection(db_path)
    conn3.execute(
        "UPDATE purchase_orders SET status=? WHERE id=?",
        (new_status, po_id))
    conn3.commit()
    conn3.close()
    return new_status


# ─────────────────────────────────────────────────────────────────────────────
#  CONVERT TO BILL
# ─────────────────────────────────────────────────────────────────────────────

def convert_po_to_bill(db_path, po_id: int,
                        bill_date: str = None,
                        due_date:  str = None,
                        bill_number: str = "",
                        status: str = "Draft") -> int:
    """
    Convert a PO into a Bill. Returns bill_id.
    """
    from core.ledger import save_bill

    data = get_purchase_order(db_path, po_id)
    if not data:
        raise ValueError(f"PO {po_id} not found")
    po    = data["po"]
    lines = data["lines"]

    if not bill_date:
        bill_date = _date.today().isoformat()
    if not due_date:
        due_date = (_date.fromisoformat(bill_date) + _td(days=30)).isoformat()

    bill_lines = [{
        "description": l["description"],
        "quantity":    l["quantity"],
        "unit_price":  l["unit_price"],
        "tax_code":    l["tax_code"],
        "account_id":  l.get("account_id"),
        "item_id":     l.get("item_id"),
    } for l in lines]

    bill_data = {
        "contact_id":   po["contact_id"],
        "bill_date":    bill_date,
        "due_date":     due_date,
        "bill_number":  bill_number or f"From {po['po_number']}",
        "status":       status,
        "notes":        f"Generated from {po['po_number']}",
    }
    bill_id = save_bill(db_path, bill_data, bill_lines)

    # Link bill to job if the PO was job-linked
    po_job_id = po.get("job_id")
    if po_job_id:
        try:
            from core.jobs import set_bill_job
            set_bill_job(db_path, bill_id, po_job_id)
        except Exception:
            pass

    # Link PO → Bill and update status
    conn = get_connection(db_path)
    conn.execute(
        "UPDATE purchase_orders SET bill_id=?, status='Billed' WHERE id=?",
        (bill_id, po_id))
    conn.execute(
        "UPDATE bills SET po_id=? WHERE id=?",
        (po_id, bill_id))
    conn.commit()
    conn.close()

    return bill_id


# ─────────────────────────────────────────────────────────────────────────────
#  CRM INTEGRATION — generate PO from accepted quote
# ─────────────────────────────────────────────────────────────────────────────

def create_po_from_crm_quote(db_path, quote_id: int,
                              supplier_contact_id: int,
                              po_date: str = None,
                              expected_date: str = None,
                              created_by: str = None) -> int:
    """
    Generate a supplier Purchase Order from an accepted CRM quote.
    The quote defines what needs to be delivered; the PO is sent to
    the supplier to procure those items.
    Returns po_id.
    """
    from core.jobs import get_quote

    quote, q_lines = get_quote(db_path, quote_id)
    if not quote:
        raise ValueError(f"Quote {quote_id} not found")

    if not po_date:
        po_date = _date.today().isoformat()
    if not expected_date:
        expected_date = (_date.fromisoformat(po_date) + _td(days=14)).isoformat()

    po_lines = [{
        "description": l["description"],
        "quantity":    l["quantity"],
        "unit_price":  l.get("unit_price", 0),
        "tax_code":    l.get("tax_code", "GST"),
        "account_id":  l.get("account_id"),
        "item_id":     l.get("item_id"),
    } for l in q_lines]

    po_data = {
        "contact_id":     supplier_contact_id,
        "po_date":        po_date,
        "expected_date":  expected_date,
        "status":         "Draft",
        "notes":          f"Generated from Quote {quote.get('quote_number', quote_id)}",
        "crm_quote_id":   quote_id,
    }

    po_id = save_purchase_order(db_path, po_data, po_lines, created_by=created_by)

    # Link quote → PO
    conn = get_connection(db_path)
    try:
        conn.execute(
            "ALTER TABLE crm_quotes ADD COLUMN po_id INTEGER")
    except Exception:
        pass
    conn.execute("UPDATE crm_quotes SET po_id=? WHERE id=?", (po_id, quote_id))
    conn.commit()
    conn.close()

    return po_id


# ─────────────────────────────────────────────────────────────────────────────
#  PDF GENERATION
# ─────────────────────────────────────────────────────────────────────────────


def render_po_pdf(db_path: str, po_id: int, out_path: str):
    """Generate a professional Purchase Order PDF."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors as rl_colors
    from reportlab.lib.units import mm
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_RIGHT, TA_LEFT
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                     Table, TableStyle, HRFlowable)
    from core.database import get_connection as _gc
    from core.invoice_pdf import (
        _resolve_theme, _c, _load_doc_theme, _logo_image,
        _build_header, _build_footer, _s, WHITE, PAGE_W,
    )

    conn = _gc(db_path)
    co   = dict(conn.execute("SELECT * FROM company").fetchone() or {})
    conn.close()

    data = get_purchase_order(db_path, po_id)
    if not data:
        raise ValueError(f"PO {po_id} not found")
    po    = data["po"]
    lines = data["lines"]

    th   = _resolve_theme(_load_doc_theme(co))
    s    = _s(th)
    NAVY  = _c(th["header_bg"])
    LTGR  = _c(th["row_alt"])
    RULE  = _c(th["rule_colour"])
    PANEL = _c(th["payment_box_bg"])

    def P(txt, style="body"):
        d = dict(fontName="Helvetica", fontSize=9, leading=12,
                 textColor=_c(th["body_text"]))
        overrides = {
            "right": dict(alignment=TA_RIGHT),
            "rbold": dict(fontName="Helvetica-Bold", alignment=TA_RIGHT),
            "hdr":   dict(fontName="Helvetica-Bold", fontSize=8.5, textColor=WHITE),
            "bold":  dict(fontName="Helvetica-Bold"),
            "small": dict(fontSize=8),
            "dim":   dict(fontSize=7.5, textColor=_c(th["dim_text"])),
        }
        d.update(overrides.get(style, {}))
        return Paragraph(str(txt or ""), ParagraphStyle(f"po_{style}", **d))

    doc   = SimpleDocTemplate(out_path, pagesize=A4,
                               leftMargin=18*mm, rightMargin=18*mm,
                               topMargin=14*mm, bottomMargin=14*mm)
    story = []
    supplier = po.get("contact_name_live") or po.get("contact_name", "")

    # ── Header (logo left, doc title right, accent HR rule) ───────────────────
    co_name, co_abn, co_addr, co_phone, co_email, co_web = \
        _build_header(story, co, "PURCHASE ORDER", s, th)

    # PO meta block below header
    meta_data = [[
        Paragraph(f"<b>TO:</b> {supplier}",
                  ParagraphStyle("po_sup", fontName="Helvetica-Bold",
                                 fontSize=9, leading=12,
                                 textColor=_c(th["body_text"]))),
        Paragraph(f"<b>PO#:</b> {po['po_number']}  &nbsp;&nbsp; "
                  f"<b>Date:</b> {po['po_date']}  &nbsp;&nbsp; "
                  f"<b>Expected:</b> {po.get('expected_date') or '—'}  &nbsp;&nbsp; "
                  f"<b>Status:</b> {po['status']}",
                  ParagraphStyle("po_meta", fontName="Helvetica",
                                 fontSize=8.5, leading=12,
                                 textColor=_c(th["body_text"]), alignment=TA_RIGHT)),
    ]]
    meta_tbl = Table(meta_data, colWidths=[PAGE_W * 0.5, PAGE_W * 0.5])
    meta_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, -1), LTGR),
        ("TOPPADDING",    (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("LEFTPADDING",   (0, 0), (-1, -1), 10),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 10),
        ("BOX",           (0, 0), (-1, -1), 0.5, RULE),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story.append(meta_tbl)
    story.append(Spacer(1, 4*mm))

    # ── Lines table ───────────────────────────────────────────────────────────
    col_w = [PAGE_W*0.08, PAGE_W*0.40, PAGE_W*0.10, PAGE_W*0.14,
             PAGE_W*0.13, PAGE_W*0.15]
    rows  = [[P(h, "hdr") for h in ("Code", "Description", "Qty", "Unit Price", "GST", "Total")]]
    for ln in lines:
        rows.append([
            P(ln.get("item_code") or ""),
            P(ln["description"]),
            P(f"{float(ln['quantity']):,.2f}", "right"),
            P(f"${float(ln['unit_price']):,.2f}", "right"),
            P(f"${float(ln.get('gst_amount') or 0):,.2f}", "right"),
            P(f"${float(ln['line_total']):,.2f}", "rbold"),
        ])

    n = len(lines)
    rows.append(["", "", "", P("Subtotal:",     "right"), "", P(f"${po['subtotal']:,.2f}", "rbold")])
    rows.append(["", "", "", P("GST (10%):",    "right"), "", P(f"${po['gst_total']:,.2f}", "right")])
    rows.append(["", "", "", P("<b>TOTAL:</b>", "rbold"), "", P(f"<b>${po['total']:,.2f}</b>", "rbold")])

    tbl = Table(rows, colWidths=col_w, repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0),   (-1, 0),    NAVY),
        ("ROWBACKGROUNDS",(0, 1),   (-1, n),    [WHITE, LTGR]),
        ("BACKGROUND",    (0, n+1), (-1, n+3),  PANEL),
        ("LINEABOVE",     (0, n+1), (-1, n+1),  1, NAVY),
        ("SPAN",          (0, n+1), (2, n+1)),
        ("SPAN",          (0, n+2), (2, n+2)),
        ("SPAN",          (0, n+3), (2, n+3)),
        ("TOPPADDING",    (0, 0),   (-1, -1),   4),
        ("BOTTOMPADDING", (0, 0),   (-1, -1),   4),
        ("LEFTPADDING",   (0, 0),   (-1, -1),   5),
        ("RIGHTPADDING",  (0, 0),   (-1, -1),   5),
        ("BOX",           (0, 0),   (-1, -1),   0.5, RULE),
        ("INNERGRID",     (0, 0),   (-1, n),    0.25, RULE),
    ]))
    story.append(tbl)

    if po.get("notes"):
        story.append(Spacer(1, 4*mm))
        story.append(P(f"<b>Notes:</b> {po['notes']}", "small"))

    if po.get("delivery_address"):
        story.append(Spacer(1, 3*mm))
        story.append(P(f"<b>Deliver to:</b> {po['delivery_address']}", "small"))

    # ── Footer ────────────────────────────────────────────────────────────────
    _build_footer(story, co_name, co_abn, co_email, co_phone,
                  f"Purchase Order {po['po_number']}  —  {po['po_date']}", th, s)

    doc.build(story)
