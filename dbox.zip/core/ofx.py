# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Accounting — OFX bank statement files (.ofx, .qfx, .qbo)

Reads both OFX 1.x (SGML: leaf tags have no closing tag, e.g. "<TRNAMT>-75.00")
and OFX 2.x (XML). QFX (Quicken) and QBO (QuickBooks) are OFX with a
different extension. Bank and credit card statements are both read; every
<STMTTRN> becomes one statement row.

Banks fill these files in differently, so nothing here relies on optional
parts being right:
  • FITID (the bank's transaction id) is kept for reference only — some
    banks number transactions per day ("29OCT2026.1"), which can change
    between downloads, so duplicates are found by date and amount instead
    (core.ledger.import_bank_ofx).
  • LEDGERBAL is only used when it is dated at or after the statement end;
    some banks send 0 dated at the start.
"""

from __future__ import annotations

import html
import re

_TAG = re.compile(r"<(/?)([A-Za-z0-9_.]+)>([^<]*)")


def is_ofx(text: str) -> bool:
    head = text[:2000].upper()
    return "OFXHEADER" in head or "<OFX>" in head


def _leaf(block: str, tag: str) -> str:
    """Text of the first <tag> in block (SGML or XML)."""
    m = re.search(rf"<{tag}>([^<\r\n]*)", block, re.IGNORECASE)
    return html.unescape(m.group(1).strip()) if m else ""


def _date(s: str) -> str:
    """OFX dates are YYYYMMDD[HHMMSS[.XXX]][TZ] — keep the day."""
    d = re.sub(r"\D", "", s[:8])
    if len(d) != 8:
        return ""
    return f"{d[:4]}-{d[4:6]}-{d[6:]}"


def _amount(s: str) -> float | None:
    s = s.strip().replace(" ", "")
    if "," in s and "." not in s:   # decimal comma (some European banks)
        s = s.replace(",", ".")
    s = s.replace(",", "")
    try:
        return float(s)
    except ValueError:
        return None


def _blocks(text: str, tag: str) -> list[str]:
    """Contents of each <tag>…</tag> aggregate (these always close, in 1.x too)."""
    return re.findall(rf"<{tag}>(.*?)</{tag}>", text, re.IGNORECASE | re.DOTALL)


def parse_ofx(text: str) -> dict:
    """Parse an OFX file. Returns
      {"account": "11495S3.2", "account_type": "SAVINGS"|"CREDITCARD"|…,
       "currency": "AUD", "start": iso, "end": iso,
       "balance": float|None, "balance_date": iso|None,
       "rows": [{"date", "description", "reference", "debit", "credit", "fitid"}]}
    Rows are in file order. Raises ValueError if it isn't a readable OFX
    statement."""
    if not is_ofx(text):
        raise ValueError("This isn't an OFX file")
    body = text[text.upper().find("<OFX>"):]

    stmts = _blocks(body, "STMTRS") + _blocks(body, "CCSTMTRS")
    if not stmts:
        raise ValueError("No bank or credit card statement found in the OFX file")
    accounts = {(_leaf(s, "ACCTID") or "?") for s in stmts}
    if len(accounts) > 1:
        raise ValueError(f"This OFX file has {len(accounts)} accounts in it — download one account at a time")
    s0 = stmts[0]
    is_cc = bool(_blocks(body, "CCSTMTRS"))

    rows = []
    for st in stmts:
        for t in _blocks(st, "STMTTRN"):
            d = _date(_leaf(t, "DTPOSTED"))
            amt = _amount(_leaf(t, "TRNAMT"))
            if not d or amt is None:
                continue
            name, memo = _leaf(t, "NAME"), _leaf(t, "MEMO")
            if name and memo and not memo.startswith(name):
                desc = f"{name} {memo}"
            else:
                desc = memo or name
            rows.append({
                "date": d,
                "description": desc,
                "reference": _leaf(t, "CHECKNUM") or _leaf(t, "REFNUM"),
                "debit": round(-amt, 2) if amt < 0 else 0.0,
                "credit": round(amt, 2) if amt > 0 else 0.0,
                "fitid": _leaf(t, "FITID"),
            })
    start, end = _date(_leaf(s0, "DTSTART")), _date(_leaf(s0, "DTEND"))
    if rows:
        start = start or min(r["date"] for r in rows)
        end = end or max(r["date"] for r in rows)

    balance = balance_date = None
    lb = _blocks(s0, "LEDGERBAL")
    if lb:
        b, bd = _amount(_leaf(lb[0], "BALAMT")), _date(_leaf(lb[0], "DTASOF"))
        if b is not None and bd and end and bd >= end:
            balance, balance_date = round(b, 2), bd

    return {
        "account": _leaf(s0, "ACCTID"),
        "account_type": "CREDITCARD" if is_cc else (_leaf(s0, "ACCTTYPE") or ""),
        "currency": _leaf(s0, "CURDEF"),
        "start": start, "end": end,
        "balance": balance, "balance_date": balance_date,
        "rows": rows,
    }
