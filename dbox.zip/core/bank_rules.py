# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Accounting — Bank Categorisation Rules
Auto-categorise bank transactions by description pattern.
"""

import json

from core.database import get_connection


def get_rules(db_path):
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT r.*, a.code as account_code, a.name as account_name,
               c.name as contact_name
        FROM bank_rules r
        LEFT JOIN accounts a ON r.account_id = a.id
        LEFT JOIN contacts c ON r.contact_id = c.id
        WHERE r.is_active = 1
        ORDER BY r.priority DESC, r.id
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_all_rules(db_path):
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT r.*, a.code as account_code, a.name as account_name,
               c.name as contact_name
        FROM bank_rules r
        LEFT JOIN accounts a ON r.account_id = a.id
        LEFT JOIN contacts c ON r.contact_id = c.id
        ORDER BY r.priority DESC, r.id
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def rule_splits(rule):
    """A rule's percentage split as a list ([] when it posts to one account)."""
    raw = rule.get("splits")
    if not raw:
        return []
    try:
        rows = json.loads(raw) if isinstance(raw, str) else raw
        return [r for r in rows if r.get("account_id")] if isinstance(rows, list) else []
    except (ValueError, TypeError):
        return []


def _clean_splits(splits):
    """Check a split: two or more lines, each with an account and a percentage,
    adding up to 100. Returns the JSON to store, or None for no split."""
    if not splits:
        return None
    rows = []
    for s in splits:
        acc = int(s.get("account_id") or 0)
        pct = round(float(s.get("percent") or 0), 2)
        if not acc:
            raise ValueError("Choose an account for every line of the split")
        if pct <= 0:
            raise ValueError("Every line of the split needs a percentage above 0")
        rows.append({"account_id": acc, "tax_code": s.get("tax_code") or None, "percent": pct})
    if len(rows) < 2:
        raise ValueError("A split needs at least two lines")
    if abs(sum(r["percent"] for r in rows) - 100) > 0.01:
        raise ValueError("The split's percentages must add up to 100")
    return json.dumps(rows)


def split_amounts(amount, splits):
    """Share amount by the split's percentages, to the cent; the last line takes
    the rounding so the lines always add up to amount."""
    out, left = [], round(abs(amount), 2)
    for i, s in enumerate(splits):
        a = left if i == len(splits) - 1 else round(abs(amount) * s["percent"] / 100, 2)
        left = round(left - a, 2)
        out.append(a)
    return out


def save_rule(db_path, data):
    data = dict(data)
    data["splits"] = _clean_splits(data.get("splits"))
    if data["splits"]:
        data["account_id"] = json.loads(data["splits"])[0]["account_id"]
        data["tax_code"] = None
    data["tax_code"] = data.get("tax_code") or None
    conn = get_connection(db_path)
    rid = data.get("id")
    fields = ["rule_name", "match_field", "match_type", "match_value",
              "direction", "account_id", "contact_id", "is_active", "priority",
              "tax_code", "splits"]
    vals = [data.get(f) for f in fields]
    if rid:
        sets = ", ".join(f"{f}=?" for f in fields)
        conn.execute(f"UPDATE bank_rules SET {sets} WHERE id=?", vals + [rid])
    else:
        cols = ", ".join(fields)
        ph   = ", ".join("?" for _ in fields)
        conn.execute(f"INSERT INTO bank_rules ({cols}) VALUES ({ph})", vals)
        rid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit(); conn.close()
    return rid


def delete_rule(db_path, rule_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM bank_rules WHERE id=?", (rule_id,))
    conn.commit(); conn.close()


def match_rule(rule, txn):
    """
    Return True if the rule matches the transaction dict.
    txn keys: description, reference, debit, credit
    """
    # Direction check
    direction = rule.get("direction", "both")
    debit  = float(txn.get("debit")  or 0)
    credit = float(txn.get("credit") or 0)
    if direction == "debit"  and debit  == 0: return False
    if direction == "credit" and credit == 0: return False

    # Text match
    field = rule.get("match_field", "description")
    haystack = (txn.get(field) or "").lower()
    pattern  = (rule.get("match_value") or "").lower()
    if not pattern:
        return False

    match_type = rule.get("match_type", "contains")
    if match_type == "contains":
        return pattern in haystack
    elif match_type == "startswith":
        return haystack.startswith(pattern)
    elif match_type == "exact":
        return haystack == pattern
    return False


def apply_rules(db_path, txns):
    """
    Apply all active rules to a list of transaction dicts.
    Returns list of (txn, rule) pairs for each match.
    Each txn that matches gets _rule_account_id and _rule_contact_id injected.
    Only the highest-priority matching rule is applied per transaction.
    """
    rules = get_rules(db_path)
    matches = []
    for txn in txns:
        for rule in rules:   # already ordered by priority DESC
            if match_rule(rule, txn):
                txn["_rule_account_id"] = rule.get("account_id")
                txn["_rule_contact_id"] = rule.get("contact_id")
                txn["_rule_name"]       = rule.get("rule_name")
                matches.append((txn, rule))
                break
    return matches
