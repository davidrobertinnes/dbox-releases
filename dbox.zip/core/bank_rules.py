# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Accounting — Bank Categorisation Rules
Auto-categorise bank transactions by description pattern.
"""

from core.database import get_connection


def get_rules(db_path):
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT r.*, a.code as account_code, a.name as account_name,
               c.name as contact_name
        FROM bank_rules r
        LEFT JOIN accounts a ON r.account_id = a.id
        LEFT JOIN contacts c ON r.contact_id = c.id
        WHERE r.is_active = 1
        ORDER BY r.priority DESC, r.id
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_all_rules(db_path):
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT r.*, a.code as account_code, a.name as account_name,
               c.name as contact_name
        FROM bank_rules r
        LEFT JOIN accounts a ON r.account_id = a.id
        LEFT JOIN contacts c ON r.contact_id = c.id
        ORDER BY r.priority DESC, r.id
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_rule(db_path, data):
    conn = get_connection(db_path)
    rid = data.get("id")
    fields = ["rule_name", "match_field", "match_type", "match_value",
              "direction", "account_id", "contact_id", "is_active", "priority"]
    vals = [data.get(f) for f in fields]
    if rid:
        sets = ", ".join(f"{f}=?" for f in fields)
        conn.execute(f"UPDATE bank_rules SET {sets} WHERE id=?", vals + [rid])
    else:
        cols = ", ".join(fields)
        ph   = ", ".join("?" for _ in fields)
        conn.execute(f"INSERT INTO bank_rules ({cols}) VALUES ({ph})", vals)
        rid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.commit(); conn.close()
    return rid


def delete_rule(db_path, rule_id):
    conn = get_connection(db_path)
    conn.execute("DELETE FROM bank_rules WHERE id=?", (rule_id,))
    conn.commit(); conn.close()


def match_rule(rule, txn):
    """
    Return True if the rule matches the transaction dict.
    txn keys: description, reference, debit, credit
    """
    # Direction check
    direction = rule.get("direction", "both")
    debit  = float(txn.get("debit")  or 0)
    credit = float(txn.get("credit") or 0)
    if direction == "debit"  and debit  == 0: return False
    if direction == "credit" and credit == 0: return False

    # Text match
    field = rule.get("match_field", "description")
    haystack = (txn.get(field) or "").lower()
    pattern  = (rule.get("match_value") or "").lower()
    if not pattern:
        return False

    match_type = rule.get("match_type", "contains")
    if match_type == "contains":
        return pattern in haystack
    elif match_type == "startswith":
        return haystack.startswith(pattern)
    elif match_type == "exact":
        return haystack == pattern
    return False


def apply_rules(db_path, txns):
    """
    Apply all active rules to a list of transaction dicts.
    Returns list of (txn, rule) pairs for each match.
    Each txn that matches gets _rule_account_id and _rule_contact_id injected.
    Only the highest-priority matching rule is applied per transaction.
    """
    rules = get_rules(db_path)
    matches = []
    for txn in txns:
        for rule in rules:   # already ordered by priority DESC
            if match_rule(rule, txn):
                txn["_rule_account_id"] = rule.get("account_id")
                txn["_rule_contact_id"] = rule.get("contact_id")
                txn["_rule_name"]       = rule.get("rule_name")
                matches.append((txn, rule))
                break
    return matches
