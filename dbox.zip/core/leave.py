"""
Dogbox Accounting — Leave Management Backend

Tables:
  leave_types       — configurable leave type definitions
  leave_balances    — current balance per employee per leave type
  leave_accruals    — audit log of every accrual/deduction
  leave_requests    — request/approval workflow
  medical_certs     — medical certificates linked to leave requests

Accrual methods:
  per_hour          — accrues each pay period proportional to hours worked
                      (Annual Leave: 4 weeks / 152 hrs per year for full-time)
  fixed_date        — credited in one lump on a specific anniversary/date
                      (Long Service: e.g. 8.67 weeks after 10 years)
  manual            — HR enters adjustments manually (Parental, TOIL, etc.)
  none              — no automatic accrual (Unpaid, Community Service, etc.)

Australian FW Act defaults seeded automatically.
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.


import json
from datetime import date, timedelta
from .database import get_connection


# ── Default leave types (Australian FW Act / NES) ─────────────────────────────

LEAVE_TYPE_DEFAULTS = [
    # code, name, paid, accrual_method, accrual_rate_hrs_per_hr_worked,
    # accrual_days_per_year (for reference), max_balance_weeks,
    # requires_evidence, carryover, stp_code, colour, notes
    dict(
        code="ANN",
        name="Annual Leave",
        paid=1,
        accrual_method="per_hour",
        accrual_rate=0.076923,   # 4 weeks / 52 weeks = 1/13 hr per hr worked
        accrual_days_per_year=20,
        max_balance_weeks=None,
        requires_evidence=0,
        carryover=1,
        stp_code="A",
        colour="#27ae60",
        notes="4 weeks per year (NES). Accrues per hour worked.",
    ),
    dict(
        code="LSL",
        name="Long Service Leave",
        paid=1,
        accrual_method="per_hour",
        accrual_rate=0.016667,   # 0.8667 weeks/year ÷ 52 = 0.016667 hrs per hr worked (NSW LSL Corp)
        accrual_days_per_year=4.33,
        max_balance_weeks=None,
        requires_evidence=0,
        carryover=1,
        stp_code="L",
        colour="#8e44ad",
        notes="Typically 8.67 weeks after 10 years continuous service. State-based rules vary.",
    ),
    dict(
        code="SIC",
        name="Sick / Personal / Carer's Leave",
        paid=1,
        accrual_method="per_hour",
        accrual_rate=0.038462,   # 10 days / year = 2/52
        accrual_days_per_year=10,
        max_balance_weeks=None,
        requires_evidence=0,
        carryover=1,
        stp_code="O",
        colour="#e74c3c",
        notes="10 days per year (NES). Includes carer's leave. Medical certificate may be required after 2 days.",
    ),
    dict(
        code="COM",
        name="Compassionate Leave",
        paid=1,
        accrual_method="none",
        accrual_rate=0.0,
        accrual_days_per_year=0,
        max_balance_weeks=None,
        requires_evidence=0,
        carryover=0,
        stp_code="O",
        colour="#c0392b",
        notes="2 days per occasion. Immediate family member serious illness or death (does not include the employee themselves).",
    ),
    dict(
        code="BER",
        name="Bereavement Leave",
        paid=1,
        accrual_method="none",
        accrual_rate=0.0,
        accrual_days_per_year=0,
        max_balance_weeks=None,
        requires_evidence=0,
        carryover=0,
        stp_code="O",
        colour="#7f8c8d",
        notes="2 days paid (NES). Death of immediate family or household member.",
    ),
    dict(
        code="PAR",
        name="Parental Leave (Paid)",
        paid=1,
        accrual_method="manual",
        accrual_rate=0.0,
        accrual_days_per_year=0,
        max_balance_weeks=None,
        requires_evidence=1,
        carryover=0,
        stp_code="O",
        colour="#2980b9",
        notes="Up to 18 weeks paid parental leave (government scheme via Services Australia). May be employer-funded.",
    ),
    dict(
        code="PAU",
        name="Parental Leave (Unpaid)",
        paid=0,
        accrual_method="manual",
        accrual_rate=0.0,
        accrual_days_per_year=0,
        max_balance_weeks=None,
        requires_evidence=1,
        carryover=0,
        stp_code="O",
        colour="#3498db",
        notes="Up to 12 months unpaid (NES). Can be extended a further 12 months by request.",
    ),
    dict(
        code="FAM",
        name="Family & Domestic Violence Leave",
        paid=1,
        accrual_method="fixed_date",
        accrual_rate=0.0,
        accrual_days_per_year=10,
        max_balance_weeks=None,
        requires_evidence=0,
        carryover=0,
        stp_code="O",
        colour="#e67e22",
        notes="10 days paid per year (Fair Work Act 2022, effective Feb 2023 for large employers). Non-accumulating.",
    ),
    dict(
        code="COM_SRV",
        name="Community Service Leave",
        paid=0,
        accrual_method="none",
        accrual_rate=0.0,
        accrual_days_per_year=0,
        max_balance_weeks=None,
        requires_evidence=1,
        carryover=0,
        stp_code="O",
        colour="#16a085",
        notes="Jury duty (up to 10 days makeup pay) and emergency management activities. Unpaid beyond jury duty.",
    ),
    dict(
        code="DEF",
        name="Defence / Reservist Leave",
        paid=0,
        accrual_method="none",
        accrual_rate=0.0,
        accrual_days_per_year=0,
        max_balance_weeks=None,
        requires_evidence=1,
        carryover=0,
        stp_code="O",
        colour="#1abc9c",
        notes="ADF reserve service. Unpaid, job-protected. Defence Reserve Support Council recommends employer top-up.",
    ),
    dict(
        code="STU",
        name="Study / Education Leave",
        paid=1,
        accrual_method="manual",
        accrual_rate=0.0,
        accrual_days_per_year=0,
        max_balance_weeks=None,
        requires_evidence=1,
        carryover=0,
        stp_code="O",
        colour="#f39c12",
        notes="Employer discretion. Typically for approved courses, exams, or training.",
    ),
    dict(
        code="PUB",
        name="Public Holiday",
        paid=1,
        accrual_method="none",
        accrual_rate=0.0,
        accrual_days_per_year=0,
        max_balance_weeks=None,
        requires_evidence=0,
        carryover=0,
        stp_code="O",
        colour="#f1c40f",
        notes="State/territory public holidays. Paid if would have worked that day.",
    ),
    dict(
        code="TOIL",
        name="Time Off in Lieu (TOIL)",
        paid=1,
        accrual_method="manual",
        accrual_rate=0.0,
        accrual_days_per_year=0,
        max_balance_weeks=None,
        requires_evidence=0,
        carryover=1,
        stp_code="O",
        colour="#d35400",
        notes="Time off substituted for overtime pay. Accrued manually when overtime approved as TOIL.",
    ),
    dict(
        code="WKC",
        name="Workers Compensation Leave",
        paid=1,
        accrual_method="none",
        accrual_rate=0.0,
        accrual_days_per_year=0,
        max_balance_weeks=None,
        requires_evidence=1,
        carryover=0,
        stp_code="O",
        colour="#c0392b",
        notes="Work-related injury/illness. Insurer-funded after waiting period. Job protected per state WC legislation.",
    ),
    dict(
        code="PUR",
        name="Purchased Leave",
        paid=1,
        accrual_method="manual",
        accrual_rate=0.0,
        accrual_days_per_year=0,
        max_balance_weeks=None,
        requires_evidence=0,
        carryover=0,
        stp_code="A",
        colour="#9b59b6",
        notes="Employee purchases additional leave via salary sacrifice. Typically up to 4 extra weeks.",
    ),
    dict(
        code="UNP",
        name="Unpaid Leave",
        paid=0,
        accrual_method="none",
        accrual_rate=0.0,
        accrual_days_per_year=0,
        max_balance_weeks=None,
        requires_evidence=0,
        carryover=0,
        stp_code="O",
        colour="#95a5a6",
        notes="General unpaid leave by agreement. Annual leave accrual may pause depending on award/agreement.",
    ),
]


# ── Schema migration ───────────────────────────────────────────────────────────

def migrate_leave(conn):
    """Create leave tables. Safe to call multiple times."""

    conn.execute("""CREATE TABLE IF NOT EXISTS leave_types (
        id                      INTEGER PRIMARY KEY AUTOINCREMENT,
        code                    TEXT NOT NULL UNIQUE,
        name                    TEXT NOT NULL,
        paid                    INTEGER NOT NULL DEFAULT 1,
        accrual_method          TEXT NOT NULL DEFAULT 'per_hour',
        accrual_rate            REAL NOT NULL DEFAULT 0.0,
        accrual_days_per_year   REAL NOT NULL DEFAULT 0.0,
        max_balance_weeks       REAL,
        requires_evidence       INTEGER NOT NULL DEFAULT 0,
        carryover               INTEGER NOT NULL DEFAULT 1,
        stp_code                TEXT NOT NULL DEFAULT 'O',
        colour                  TEXT NOT NULL DEFAULT '#95a5a6',
        is_active               INTEGER NOT NULL DEFAULT 1,
        is_system               INTEGER NOT NULL DEFAULT 0,
        notes                   TEXT,
        sort_order              INTEGER NOT NULL DEFAULT 99)""")

    conn.execute("""CREATE TABLE IF NOT EXISTS leave_balances (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id     INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
        leave_type_id   INTEGER NOT NULL REFERENCES leave_types(id),
        accrued_hours   REAL NOT NULL DEFAULT 0.0,
        taken_hours     REAL NOT NULL DEFAULT 0.0,
        adjustment_hours REAL NOT NULL DEFAULT 0.0,
        balance_hours   REAL GENERATED ALWAYS AS
                            (accrued_hours + adjustment_hours - taken_hours) VIRTUAL,
        as_of_date      TEXT NOT NULL DEFAULT (date('now')),
        updated_at      TEXT DEFAULT (datetime('now','localtime')),
        UNIQUE(employee_id, leave_type_id))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS leave_accruals (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id     INTEGER NOT NULL REFERENCES employees(id),
        leave_type_id   INTEGER NOT NULL REFERENCES leave_types(id),
        accrual_date    TEXT NOT NULL,
        hours           REAL NOT NULL,          -- positive=accrual, negative=deduction
        accrual_type    TEXT NOT NULL DEFAULT 'auto',  -- auto, manual, taken, adjustment, opening
        reference       TEXT,                   -- pay_run_id, leave_request_id, etc.
        notes           TEXT,
        created_by      TEXT,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS leave_requests (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id     INTEGER NOT NULL REFERENCES employees(id),
        leave_type_id   INTEGER NOT NULL REFERENCES leave_types(id),
        start_date      TEXT NOT NULL,
        end_date        TEXT NOT NULL,
        hours_requested REAL NOT NULL DEFAULT 0.0,
        status          TEXT NOT NULL DEFAULT 'Pending',  -- Pending,Approved,Declined,Cancelled,Taken
        return_date     TEXT,
        reason          TEXT,
        approved_by     TEXT,
        approved_at     TEXT,
        decline_reason  TEXT,
        payslip_id      INTEGER REFERENCES payslips(id),
        notes           TEXT,
        created_at      TEXT DEFAULT (datetime('now','localtime')),
        updated_at      TEXT DEFAULT (datetime('now','localtime')))""")

    conn.execute("""CREATE TABLE IF NOT EXISTS medical_certs (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id     INTEGER NOT NULL REFERENCES employees(id),
        leave_request_id INTEGER REFERENCES leave_requests(id),
        cert_date       TEXT NOT NULL,
        practitioner    TEXT,
        practice_name   TEXT,
        cert_from_date  TEXT NOT NULL,
        cert_to_date    TEXT NOT NULL,
        condition_notes TEXT,          -- e.g. 'unable to perform duties' — not diagnosis
        file_data       BLOB,
        file_name       TEXT,
        mime_type       TEXT,
        created_at      TEXT DEFAULT (datetime('now','localtime')))""")

    # Indexes
    for name, defn in [
        ("idx_leave_bal_emp",    "leave_balances(employee_id)"),
        ("idx_leave_acc_emp",    "leave_accruals(employee_id, accrual_date)"),
        ("idx_leave_acc_ref",    "leave_accruals(reference, accrual_type)"),  # idempotency guard
        ("idx_leave_req_emp",    "leave_requests(employee_id, status)"),
        ("idx_leave_req_dates",  "leave_requests(start_date, end_date)"),
        ("idx_med_cert_emp",     "medical_certs(employee_id)"),
    ]:
        try:
            conn.execute(f"CREATE INDEX IF NOT EXISTS {name} ON {defn}")
        except Exception:
            pass

    # Seed default leave types (insert if code not present)
    for i, lt in enumerate(LEAVE_TYPE_DEFAULTS):
        try:
            conn.execute("""INSERT OR IGNORE INTO leave_types
                (code, name, paid, accrual_method, accrual_rate,
                 accrual_days_per_year, max_balance_weeks, requires_evidence,
                 carryover, stp_code, colour, is_active, is_system, notes, sort_order)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,1,1,?,?)""",
                (lt["code"], lt["name"], lt["paid"], lt["accrual_method"],
                 lt["accrual_rate"], lt["accrual_days_per_year"],
                 lt["max_balance_weeks"], lt["requires_evidence"],
                 lt["carryover"], lt["stp_code"], lt["colour"],
                 lt["notes"], i))
        except Exception:
            pass

    # ── Public Holidays table (migration-safe) ────────────────────────────────
    conn.execute("""CREATE TABLE IF NOT EXISTS public_holidays (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        holiday_date    TEXT NOT NULL,
        state           TEXT NOT NULL DEFAULT 'NAT',
        name            TEXT NOT NULL,
        UNIQUE(holiday_date, state))""")
    try:
        conn.execute("CREATE INDEX IF NOT EXISTS idx_pub_hol_state_date "
                     "ON public_holidays(state, holiday_date)")
    except Exception:
        pass

    # Seed Australian public holidays — national + all states/territories
    # FY2024-25 and FY2025-26.  INSERT OR IGNORE so re-runs are safe.
    _PH_SEED = [
        # ── National (NAT) ────────────────────────────────────────────────────
        # 2024-25
        ("2025-01-01", "NAT", "New Year's Day"),
        ("2025-01-27", "NAT", "Australia Day (substitute)"),
        ("2025-04-18", "NAT", "Good Friday"),
        ("2025-04-19", "NAT", "Easter Saturday"),
        ("2025-04-20", "NAT", "Easter Sunday"),
        ("2025-04-21", "NAT", "Easter Monday"),
        ("2025-04-25", "NAT", "ANZAC Day"),
        ("2025-12-25", "NAT", "Christmas Day"),
        ("2025-12-26", "NAT", "Boxing Day"),
        # 2025-26
        ("2026-01-01", "NAT", "New Year's Day"),
        ("2026-01-26", "NAT", "Australia Day"),
        ("2026-04-03", "NAT", "Good Friday"),
        ("2026-04-04", "NAT", "Easter Saturday"),
        ("2026-04-05", "NAT", "Easter Sunday"),
        ("2026-04-06", "NAT", "Easter Monday"),
        ("2026-04-25", "NAT", "ANZAC Day"),
        ("2026-12-25", "NAT", "Christmas Day"),
        ("2026-12-28", "NAT", "Boxing Day (substitute)"),

        # ── New South Wales (NSW) ─────────────────────────────────────────────
        ("2025-06-09", "NSW", "King's Birthday"),
        ("2025-08-04", "NSW", "Bank Holiday"),
        ("2025-10-06", "NSW", "Labour Day"),
        ("2026-06-08", "NSW", "King's Birthday"),
        ("2026-08-03", "NSW", "Bank Holiday"),
        ("2026-10-05", "NSW", "Labour Day"),

        # ── Victoria (VIC) ────────────────────────────────────────────────────
        ("2025-03-10", "VIC", "Labour Day"),
        ("2025-06-09", "VIC", "King's Birthday"),
        ("2025-09-26", "VIC", "AFL Grand Final Friday"),
        ("2025-11-04", "VIC", "Melbourne Cup Day"),
        ("2026-03-09", "VIC", "Labour Day"),
        ("2026-06-08", "VIC", "King's Birthday"),
        ("2026-11-03", "VIC", "Melbourne Cup Day"),

        # ── Queensland (QLD) ─────────────────────────────────────────────────
        ("2025-05-05", "QLD", "Labour Day"),
        ("2025-08-13", "QLD", "Royal Queensland Show (Brisbane)"),
        ("2025-10-06", "QLD", "King's Birthday"),
        ("2026-05-04", "QLD", "Labour Day"),
        ("2026-10-05", "QLD", "King's Birthday"),

        # ── South Australia (SA) ─────────────────────────────────────────────
        ("2025-03-10", "SA",  "Adelaide Cup"),
        ("2025-06-09", "SA",  "King's Birthday"),
        ("2025-10-06", "SA",  "Labour Day"),
        ("2025-12-24", "SA",  "Christmas Eve (from 7pm — partial)"),
        ("2025-12-31", "SA",  "New Year's Eve (from 7pm — partial)"),
        ("2026-03-09", "SA",  "Adelaide Cup"),
        ("2026-06-08", "SA",  "King's Birthday"),
        ("2026-10-05", "SA",  "Labour Day"),

        # ── Western Australia (WA) ────────────────────────────────────────────
        ("2025-03-03", "WA",  "Labour Day"),
        ("2025-06-02", "WA",  "Western Australia Day"),
        ("2025-09-22", "WA",  "King's Birthday"),
        ("2026-03-02", "WA",  "Labour Day"),
        ("2026-06-01", "WA",  "Western Australia Day"),
        ("2026-09-28", "WA",  "King's Birthday"),

        # ── Tasmania (TAS) ────────────────────────────────────────────────────
        ("2025-02-10", "TAS", "Royal Hobart Regatta (south)"),
        ("2025-03-10", "TAS", "Eight Hours Day"),
        ("2025-06-09", "TAS", "King's Birthday"),
        ("2026-02-09", "TAS", "Royal Hobart Regatta (south)"),
        ("2026-03-09", "TAS", "Eight Hours Day"),
        ("2026-06-08", "TAS", "King's Birthday"),

        # ── Northern Territory (NT) ───────────────────────────────────────────
        ("2025-05-05", "NT",  "May Day"),
        ("2025-06-09", "NT",  "King's Birthday"),
        ("2025-08-04", "NT",  "Picnic Day"),
        ("2026-05-04", "NT",  "May Day"),
        ("2026-06-08", "NT",  "King's Birthday"),
        ("2026-08-03", "NT",  "Picnic Day"),

        # ── Australian Capital Territory (ACT) ────────────────────────────────
        ("2025-03-10", "ACT", "Canberra Day"),
        ("2025-05-26", "ACT", "Reconciliation Day"),
        ("2025-06-09", "ACT", "King's Birthday"),
        ("2025-08-04", "ACT", "Family & Community Day"),
        ("2026-03-09", "ACT", "Canberra Day"),
        ("2026-05-25", "ACT", "Reconciliation Day"),
        ("2026-06-08", "ACT", "King's Birthday"),
        ("2026-08-03", "ACT", "Family & Community Day"),
    ]
    for hdate, hstate, hname in _PH_SEED:
        try:
            conn.execute(
                "INSERT OR IGNORE INTO public_holidays (holiday_date, state, name) VALUES (?,?,?)",
                (hdate, hstate, hname))
        except Exception:
            pass

    conn.commit()


# ── Public Holiday CRUD ────────────────────────────────────────────────────────

def get_public_holidays(db_path, state: str = None,
                        year_from: int = None, year_to: int = None) -> list:
    """Return public holidays, optionally filtered by state and year range.
    Always includes NAT (national) holidays alongside state-specific ones."""
    conn = get_connection(db_path)
    params = []
    clauses = []
    if state and state != "NAT":
        clauses.append("state IN ('NAT', ?)")
        params.append(state)
    if year_from:
        clauses.append("strftime('%Y', holiday_date) >= ?")
        params.append(str(year_from))
    if year_to:
        clauses.append("strftime('%Y', holiday_date) <= ?")
        params.append(str(year_to))
    q = "SELECT * FROM public_holidays"
    if clauses:
        q += " WHERE " + " AND ".join(clauses)
    q += " ORDER BY holiday_date, state"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_public_holiday(db_path, data: dict) -> int:
    """Insert or update a public holiday. Returns id."""
    conn = get_connection(db_path)
    ph_id = data.get("id")
    if ph_id:
        conn.execute(
            "UPDATE public_holidays SET holiday_date=?, state=?, name=? WHERE id=?",
            (data["holiday_date"], data["state"], data["name"], ph_id))
    else:
        cur = conn.execute(
            "INSERT OR REPLACE INTO public_holidays (holiday_date, state, name) VALUES (?,?,?)",
            (data["holiday_date"], data["state"], data["name"]))
        ph_id = cur.lastrowid
    conn.commit()
    conn.close()
    return ph_id


def delete_public_holiday(db_path, ph_id: int) -> None:
    conn = get_connection(db_path)
    conn.execute("DELETE FROM public_holidays WHERE id=?", (ph_id,))
    conn.commit()
    conn.close()


def get_holiday_dates_for_state(db_path, state: str,
                                 start_date: str, end_date: str) -> set:
    """
    Return a set of ISO date strings that are public holidays (national or
    state-specific) between start_date and end_date inclusive.
    """
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT holiday_date FROM public_holidays
        WHERE state IN ('NAT', ?)
          AND holiday_date BETWEEN ? AND ?""",
        (state or "NAT", start_date, end_date)).fetchall()
    conn.close()
    return {r["holiday_date"] for r in rows}


# ── Leave Type CRUD ────────────────────────────────────────────────────────────

def get_leave_types(db_path, active_only=True) -> list:
    conn = get_connection(db_path)
    q = "SELECT * FROM leave_types"
    if active_only:
        q += " WHERE is_active=1"
    q += " ORDER BY sort_order, name"
    rows = conn.execute(q).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_leave_type(db_path, lt_id) -> dict | None:
    conn = get_connection(db_path)
    row = conn.execute("SELECT * FROM leave_types WHERE id=?", (lt_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_leave_type(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    lt_id = data.get("id")
    fields = ["code","name","paid","accrual_method","accrual_rate",
              "accrual_days_per_year","max_balance_weeks","requires_evidence",
              "carryover","stp_code","colour","is_active","notes","sort_order"]
    vals = [data.get(f) for f in fields]
    if lt_id:
        sets = ", ".join(f"{f}=?" for f in fields)
        conn.execute(f"UPDATE leave_types SET {sets} WHERE id=?", vals + [lt_id])
        conn.commit(); conn.close()
        return lt_id
    else:
        cols = ", ".join(fields)
        ph   = ", ".join("?" for _ in fields)
        cur  = conn.execute(f"INSERT INTO leave_types ({cols}) VALUES ({ph})", vals)
        new_id = cur.lastrowid
        conn.commit(); conn.close()
        return new_id


# ── Balance management ─────────────────────────────────────────────────────────

def get_leave_balances(db_path, employee_id: int) -> list:
    """Return all leave balances for an employee, joined to leave_type details."""
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT lb.*, lt.code, lt.name AS type_name, lt.colour,
               lt.paid, lt.accrual_method, lt.accrual_rate
        FROM leave_balances lb
        JOIN leave_types lt ON lt.id = lb.leave_type_id
        WHERE lb.employee_id=?
        ORDER BY lt.sort_order, lt.name""", (employee_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _ensure_balance_row(conn, employee_id: int, leave_type_id: int):
    """Create a balance row for this employee/type if it doesn't exist."""
    conn.execute("""INSERT OR IGNORE INTO leave_balances
        (employee_id, leave_type_id, accrued_hours, taken_hours, adjustment_hours, as_of_date)
        VALUES (?,?,0,0,0,date('now'))""", (employee_id, leave_type_id))


def initialise_employee_leave(db_path, employee_id: int):
    """Create balance rows for all active leave types for a new employee."""
    conn = get_connection(db_path)
    types = conn.execute("SELECT id FROM leave_types WHERE is_active=1").fetchall()
    for lt in types:
        _ensure_balance_row(conn, employee_id, lt["id"])
    conn.commit()
    conn.close()


def post_accrual(db_path, employee_id: int, leave_type_id: int,
                 hours: float, accrual_date: str,
                 accrual_type: str = "auto",
                 reference: str = None,
                 notes: str = None,
                 created_by: str = None):
    """
    Post a leave accrual (positive) or deduction (negative).
    Updates leave_balances and inserts into leave_accruals audit log.
    """
    conn = get_connection(db_path)
    _ensure_balance_row(conn, employee_id, leave_type_id)

    if accrual_type == "taken":
        conn.execute("""UPDATE leave_balances
            SET taken_hours = taken_hours + ?, as_of_date=?, updated_at=datetime('now','localtime')
            WHERE employee_id=? AND leave_type_id=?""",
            (hours, accrual_date, employee_id, leave_type_id))
    elif accrual_type in ("manual", "adjustment", "opening"):
        conn.execute("""UPDATE leave_balances
            SET adjustment_hours = adjustment_hours + ?,
                as_of_date=?, updated_at=datetime('now','localtime')
            WHERE employee_id=? AND leave_type_id=?""",
            (hours, accrual_date, employee_id, leave_type_id))
    else:  # auto
        conn.execute("""UPDATE leave_balances
            SET accrued_hours = accrued_hours + ?,
                as_of_date=?, updated_at=datetime('now','localtime')
            WHERE employee_id=? AND leave_type_id=?""",
            (hours, accrual_date, employee_id, leave_type_id))

    conn.execute("""INSERT INTO leave_accruals
        (employee_id, leave_type_id, accrual_date, hours,
         accrual_type, reference, notes, created_by)
        VALUES (?,?,?,?,?,?,?,?)""",
        (employee_id, leave_type_id, accrual_date, hours,
         accrual_type, reference, notes, created_by))
    conn.commit()
    conn.close()


def accrue_for_payrun(db_path, payrun_id: int, payrun_end_date: str):
    """
    Automatically accrue per_hour leave types for all payslips in a pay run,
    and post taken deductions for any leave hours included in the payslip.
    Called when a pay run is finalised.

    Accrual base = ordinary_hours + leave_hours (FW Act s.87(2)).
    Overtime is excluded — leave does not accrue on overtime hours.
    Leave hours are included because an employee on approved leave continues
    to accrue entitlements as if they were at work.

    Leave deduction occurs here (at point of payment) not at approval.
    A negative leave_hours value represents a reversal/cancellation adjustment.

    Idempotent — safe to call multiple times for the same pay run.
    Subsequent calls are a no-op if accruals already exist for this run.
    """
    ref = f"payrun:{payrun_id}"

    conn = get_connection(db_path)

    # ── Stage 3: Idempotency guard ────────────────────────────────────────────
    already_run = conn.execute(
        "SELECT 1 FROM leave_accruals WHERE reference=? AND accrual_type='auto' LIMIT 1",
        (ref,)
    ).fetchone()
    if already_run:
        conn.close()
        return  # Already processed — do nothing

    payslips = conn.execute(
        "SELECT employee_id, ordinary_hours, leave_hours, leave_type FROM payslips WHERE pay_run_id=?",
        (payrun_id,)).fetchall()
    leave_types = conn.execute(
        "SELECT * FROM leave_types WHERE accrual_method='per_hour' AND is_active=1"
    ).fetchall()
    # Build name→id map for matching payslip leave_type string to leave_type_id
    lt_name_map = {lt["name"]: lt["id"] for lt in leave_types}
    # Also fetch all leave types (including non-per_hour) for taken deduction lookup
    all_leave_types = conn.execute(
        "SELECT id, name FROM leave_types WHERE is_active=1"
    ).fetchall()
    lt_all_name_map = {lt["name"]: lt["id"] for lt in all_leave_types}
    conn.close()

    for ps in payslips:
        # ── Accrual (per_hour types) ──────────────────────────────────────────
        # FW Act s.87(2): accrual is based on ordinary hours of work only.
        # Leave hours count as ordinary hours for accrual purposes.
        # Overtime hours are excluded.
        hours_worked = (ps["ordinary_hours"] or 0) + max(ps["leave_hours"] or 0, 0)
        for lt in leave_types:
            accrual_hrs = round(hours_worked * lt["accrual_rate"], 4)
            if accrual_hrs > 0:
                post_accrual(db_path,
                             employee_id   = ps["employee_id"],
                             leave_type_id = lt["id"],
                             hours         = accrual_hrs,
                             accrual_date  = payrun_end_date,
                             accrual_type  = "auto",
                             reference     = f"payrun:{payrun_id}",
                             notes         = f"Auto-accrual for pay run #{payrun_id}")

        # ── Taken deduction (at point of payment) ─────────────────────────────
        # leave_hours > 0: deduct from balance (leave taken this period)
        # leave_hours < 0: reverse a prior deduction (cancellation adjustment)
        leave_hrs  = ps["leave_hours"] or 0
        leave_name = ps["leave_type"]
        if leave_hrs != 0 and leave_name:
            lt_id = lt_all_name_map.get(leave_name)
            if lt_id:
                post_accrual(db_path,
                             employee_id   = ps["employee_id"],
                             leave_type_id = lt_id,
                             hours         = leave_hrs,
                             accrual_date  = payrun_end_date,
                             accrual_type  = "taken",
                             reference     = f"payrun:{payrun_id}",
                             notes         = (f"Leave taken in pay run #{payrun_id}"
                                              if leave_hrs > 0 else
                                              f"Leave reversal in pay run #{payrun_id}"))


def get_accrual_history(db_path, employee_id: int,
                        leave_type_id: int = None,
                        limit: int = 100) -> list:
    conn = get_connection(db_path)
    q = """SELECT la.*, lt.name AS type_name, lt.colour
           FROM leave_accruals la
           JOIN leave_types lt ON lt.id = la.leave_type_id
           WHERE la.employee_id=?"""
    params = [employee_id]
    if leave_type_id:
        q += " AND la.leave_type_id=?"
        params.append(leave_type_id)
    q += " ORDER BY la.accrual_date DESC, la.id DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ── Leave Requests ─────────────────────────────────────────────────────────────

def get_leave_requests(db_path, employee_id: int = None,
                       status: str = None,
                       date_from: str = None,
                       date_to: str = None) -> list:
    conn = get_connection(db_path)
    q = """SELECT lr.*, lt.name AS type_name, lt.colour, lt.paid,
                  e.first_name||' '||e.last_name AS employee_name,
                  e.employee_number
           FROM leave_requests lr
           JOIN leave_types lt ON lt.id = lr.leave_type_id
           JOIN employees   e  ON e.id  = lr.employee_id
           WHERE 1=1"""
    params = []
    if employee_id:
        q += " AND lr.employee_id=?"; params.append(employee_id)
    if status:
        q += " AND lr.status=?"; params.append(status)
    if date_from:
        q += " AND lr.end_date>=?"; params.append(date_from)
    if date_to:
        q += " AND lr.start_date<=?"; params.append(date_to)
    q += " ORDER BY lr.start_date DESC, lr.id DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_leave_request(db_path, request_id: int) -> dict | None:
    conn = get_connection(db_path)
    row = conn.execute("""SELECT lr.*, lt.name AS type_name, lt.colour, lt.paid,
                  e.first_name||' '||e.last_name AS employee_name
           FROM leave_requests lr
           JOIN leave_types lt ON lt.id = lr.leave_type_id
           JOIN employees   e  ON e.id  = lr.employee_id
           WHERE lr.id=?""", (request_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_leave_request(db_path, data: dict) -> int:
    """Insert or update a leave request. Returns request id."""
    conn = get_connection(db_path)
    req_id = data.get("id")
    fields = ["employee_id","leave_type_id","start_date","end_date",
              "hours_requested","status","return_date","reason",
              "approved_by","approved_at","decline_reason","notes"]
    vals = [data.get(f) for f in fields]
    if req_id:
        sets = ", ".join(f"{f}=?" for f in fields)
        sets += ", updated_at=datetime('now','localtime')"
        conn.execute(f"UPDATE leave_requests SET {sets} WHERE id=?", vals + [req_id])
        conn.commit(); conn.close()
        return req_id
    else:
        cols = ", ".join(fields)
        ph   = ", ".join("?" for _ in fields)
        cur  = conn.execute(f"INSERT INTO leave_requests ({cols}) VALUES ({ph})", vals)
        new_id = cur.lastrowid
        conn.commit(); conn.close()
        return new_id


def approve_leave(db_path, request_id: int, approved_by: str) -> None:
    """Approve a leave request — status change only.

    Leave balance deduction occurs when leave is included in a pay run
    (via accrue_for_payrun), not at approval. This reflects the correct
    accounting treatment: leave reduces the balance when it is paid,
    not when it is committed. Approving leave months in advance must not
    affect the balance until the leave is actually taken and paid.
    """
    conn = get_connection(db_path)
    req = conn.execute("SELECT * FROM leave_requests WHERE id=?",
                       (request_id,)).fetchone()
    if not req:
        conn.close()
        raise ValueError(f"Leave request {request_id} not found")
    conn.execute("""UPDATE leave_requests SET status='Approved',
        approved_by=?, approved_at=datetime('now','localtime'),
        updated_at=datetime('now','localtime')
        WHERE id=?""", (approved_by, request_id))
    conn.commit()
    conn.close()


def decline_leave(db_path, request_id: int,
                  declined_by: str, reason: str = "") -> None:
    conn = get_connection(db_path)
    conn.execute("""UPDATE leave_requests SET status='Declined',
        approved_by=?, approved_at=datetime('now','localtime'),
        decline_reason=?, updated_at=datetime('now','localtime')
        WHERE id=?""", (declined_by, reason, request_id))
    conn.commit()
    conn.close()


def cancel_leave(db_path, request_id: int) -> None:
    """Cancel a leave request — status change only.

    Since leave balances are deducted at payrun (not at approval), cancelling
    a request before it has been included in a pay run requires no balance
    adjustment. If leave has already been paid in a pay run, the correction
    is handled in the next pay run as a negative leave adjustment
    (e.g. −20 hrs leave + 38 hrs ordinary = net 18 hrs pay for that period).
    """
    conn = get_connection(db_path)
    conn.execute("""UPDATE leave_requests SET status='Cancelled',
        updated_at=datetime('now','localtime') WHERE id=?""", (request_id,))
    conn.commit()
    conn.close()


# ── Medical Certificates ───────────────────────────────────────────────────────

def get_medical_certs(db_path, employee_id: int = None,
                      leave_request_id: int = None) -> list:
    conn = get_connection(db_path)
    q = """SELECT mc.id, mc.employee_id, mc.leave_request_id, mc.cert_date,
                  mc.practitioner, mc.practice_name,
                  mc.cert_from_date, mc.cert_to_date,
                  mc.condition_notes, mc.file_name, mc.mime_type, mc.created_at,
                  e.first_name||' '||e.last_name AS employee_name
           FROM medical_certs mc
           JOIN employees e ON e.id=mc.employee_id
           WHERE 1=1"""
    params = []
    if employee_id:
        q += " AND mc.employee_id=?"; params.append(employee_id)
    if leave_request_id:
        q += " AND mc.leave_request_id=?"; params.append(leave_request_id)
    q += " ORDER BY mc.cert_date DESC"
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_medical_cert(db_path, data: dict) -> int:
    conn = get_connection(db_path)
    cert_id = data.get("id")
    text_fields = ["employee_id","leave_request_id","cert_date","practitioner",
                   "practice_name","cert_from_date","cert_to_date","condition_notes"]
    file_fields = ["file_data","file_name","mime_type"]
    # Only write file columns when at least one is explicitly provided.
    # This prevents a save-without-new-file from wiping an existing attachment.
    include_file = any(f in data for f in file_fields)
    fields = text_fields + (file_fields if include_file else [])
    vals = [data.get(f) for f in fields]
    if cert_id:
        sets = ", ".join(f"{f}=?" for f in fields)
        conn.execute(f"UPDATE medical_certs SET {sets} WHERE id=?", vals + [cert_id])
        conn.commit(); conn.close()
        return cert_id
    else:
        cols = ", ".join(fields)
        ph   = ", ".join("?" for _ in fields)
        cur  = conn.execute(f"INSERT INTO medical_certs ({cols}) VALUES ({ph})", vals)
        new_id = cur.lastrowid
        conn.commit(); conn.close()
        return new_id


def delete_medical_cert(db_path, cert_id: int) -> None:
    conn = get_connection(db_path)
    conn.execute("DELETE FROM medical_certs WHERE id=?", (cert_id,))
    conn.commit()
    conn.close()


# ── Utility ────────────────────────────────────────────────────────────────────

def calc_leave_hours(start_date: str, end_date: str,
                     hours_per_day: float = 7.6,
                     holiday_dates: set = None) -> float:
    """
    Calculate working hours between two dates (Mon-Fri, excludes weekends
    and any dates in holiday_dates).
    hours_per_day defaults to 7.6 (38hr week / 5 days).
    holiday_dates: optional set of ISO date strings (e.g. {'2025-04-18'})
                   to exclude from the count.
    """
    d1 = date.fromisoformat(start_date)
    d2 = date.fromisoformat(end_date)
    holidays = holiday_dates or set()
    total = 0.0
    cur = d1
    while cur <= d2:
        if cur.weekday() < 5 and cur.isoformat() not in holidays:  # Mon=0..Fri=4
            total += hours_per_day
        cur += timedelta(days=1)
    return round(total, 2)


def hours_to_days(hours: float, hours_per_day: float = 7.6) -> str:
    """Format hours as a plain hours string. Displays in hours only — industry standard."""
    return f"{hours:.2f}h"
