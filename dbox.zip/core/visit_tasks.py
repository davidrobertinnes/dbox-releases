# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Accounting — Tasks on job visits

The job's work_tasks are the master list. A visit (a schedule_events row
with event_type 'Visit') references some of them — the plan for that trip —
and records what was done there:

  visit_tasks(visit_id, task_id, completed, qty_done, invoice_id)

Progress totals onto the task, which stays the single source of status:
  • quantity tasks (qty > 1): progress = sum of qty_done across visits;
    done once progress reaches qty, or when any visit ticks it completed
  • other tasks: done when any visit ticks it completed
A task made done by visits is flagged work_tasks.done_by_visit, so unticking
it later reopens it — but a task marked Done by hand is never reopened here.

visit_tasks.invoice_id is set when a claim bills that visit's progress
(claim by visit); claimed rows are locked until the invoice is voided.
"""

from __future__ import annotations
from core.database import get_connection


# ─────────────────────────────────────────────────────────────────────────────
#  MIGRATION
# ─────────────────────────────────────────────────────────────────────────────

def migrate_visit_tasks(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS visit_tasks (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        visit_id    INTEGER NOT NULL REFERENCES schedule_events(id) ON DELETE CASCADE,
        task_id     INTEGER NOT NULL REFERENCES work_tasks(id) ON DELETE CASCADE,
        completed   INTEGER NOT NULL DEFAULT 0,
        qty_done    REAL,
        invoice_id  INTEGER REFERENCES invoices(id),
        created_at  TEXT DEFAULT (datetime('now','localtime')),
        UNIQUE(visit_id, task_id))""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_vt_task ON visit_tasks(task_id)")
    for stmt in (
        "ALTER TABLE work_tasks ADD COLUMN done_by_visit INTEGER NOT NULL DEFAULT 0",
        # Set when a claim bills the visit (with schedule_events.invoice_id):
        # 1 = its hours went on the invoice as labour, 0 = "not charged" —
        # the time was built into fixed prices and is never offered again.
        "ALTER TABLE schedule_events ADD COLUMN time_charged INTEGER",
    ):
        try:
            conn.execute(stmt)
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
#  STATUS
# ─────────────────────────────────────────────────────────────────────────────

def _is_qty_task(task) -> bool:
    return (task["billing"] or "fixed") == "fixed" and float(task["qty"] or 1) > 1


def recompute_task(conn, task_id: int) -> dict | None:
    """Re-derive a task's done status from its visit progress, inside the
    caller's transaction. Returns the task row if this call newly completed
    it (so a recurring task can offer its next occurrence), else None."""
    t = conn.execute("SELECT * FROM work_tasks WHERE id=?", (task_id,)).fetchone()
    if not t or t["invoice_id"]:
        return None  # fully invoiced — its status is settled
    rows = conn.execute("""SELECT vt.completed, vt.qty_done, e.event_date
        FROM visit_tasks vt JOIN schedule_events e ON e.id = vt.visit_id
        WHERE vt.task_id=?""", (task_id,)).fetchall()
    progress = sum(float(r["qty_done"] or 0) for r in rows)
    done_rows = [r for r in rows if r["completed"]]
    done = bool(done_rows) or (_is_qty_task(t) and progress >= float(t["qty"] or 1) - 1e-9)

    if done and not t["is_done"]:
        dates = [r["event_date"] for r in (done_rows or rows) if r["event_date"]]
        conn.execute("""UPDATE work_tasks SET is_done=1, done_by_visit=1, done_at=? WHERE id=?""",
                     (max(dates) if dates else None, task_id))
        return dict(t)
    if not done and t["is_done"] and t["done_by_visit"]:
        conn.execute("UPDATE work_tasks SET is_done=0, done_by_visit=0, done_at=NULL WHERE id=?",
                     (task_id,))
    return None


def visit_has_progress(conn, visit_id: int) -> bool:
    return bool(conn.execute("""SELECT 1 FROM visit_tasks WHERE visit_id=?
        AND (completed=1 OR COALESCE(qty_done,0) > 0) LIMIT 1""", (visit_id,)).fetchone())


def task_ids_for_visit(conn, visit_id: int) -> list:
    return [r["task_id"] for r in conn.execute(
        "SELECT task_id FROM visit_tasks WHERE visit_id=?", (visit_id,))]


# ─────────────────────────────────────────────────────────────────────────────
#  READ
# ─────────────────────────────────────────────────────────────────────────────

def get_visit_tasks(db_path, visit_id: int) -> dict:
    """A visit's task list plus the job's other open tasks that could be
    added to it."""
    conn = get_connection(db_path)
    try:
        v = conn.execute("SELECT id, job_id, event_date, title, event_type FROM schedule_events WHERE id=?",
                         (visit_id,)).fetchone()
        if not v:
            raise ValueError("Visit not found")
        linked = [dict(r) for r in conn.execute("""SELECT vt.task_id, vt.completed, vt.qty_done,
                vt.invoice_id AS claimed_invoice_id,
                wt.title, wt.description, wt.qty, wt.unit_price, COALESCE(wt.billing,'fixed') AS billing,
                wt.is_done, wt.invoice_id,
                (SELECT COALESCE(SUM(x.qty_done),0) FROM visit_tasks x WHERE x.task_id=wt.id) AS progress
            FROM visit_tasks vt JOIN work_tasks wt ON wt.id = vt.task_id
            WHERE vt.visit_id=? ORDER BY vt.id""", (visit_id,)).fetchall()]
        linked_ids = {r["task_id"] for r in linked}
        available = []
        if v["job_id"]:
            available = [dict(r) for r in conn.execute("""SELECT wt.id AS task_id, wt.title, wt.description,
                    wt.qty, wt.unit_price, COALESCE(wt.billing,'fixed') AS billing, wt.is_done,
                    (SELECT COALESCE(SUM(x.qty_done),0) FROM visit_tasks x WHERE x.task_id=wt.id) AS progress
                FROM work_tasks wt
                WHERE (wt.job_id=? OR wt.opp_id=?) AND wt.is_done=0 AND wt.invoice_id IS NULL
                ORDER BY wt.id""", (v["job_id"], v["job_id"])).fetchall()
                if r["task_id"] not in linked_ids]
        return {"visit": dict(v), "tasks": linked, "available": available}
    finally:
        conn.close()


def get_job_task_visits(db_path, job_id: int) -> dict:
    """{task_id: {"progress": qty, "visits": [{visit_id, event_date, completed, qty_done}]}}
    for the job's Tasks tab."""
    conn = get_connection(db_path)
    try:
        out = {}
        for r in conn.execute("""SELECT vt.task_id, vt.visit_id, vt.completed, vt.qty_done, e.event_date
                FROM visit_tasks vt
                JOIN schedule_events e ON e.id = vt.visit_id
                JOIN work_tasks wt ON wt.id = vt.task_id
                WHERE wt.job_id=? OR wt.opp_id=?
                ORDER BY e.event_date, vt.id""", (job_id, job_id)).fetchall():
            d = out.setdefault(r["task_id"], {"progress": 0.0, "visits": []})
            d["progress"] += float(r["qty_done"] or 0)
            d["visits"].append({"visit_id": r["visit_id"], "event_date": r["event_date"],
                                "completed": bool(r["completed"]), "qty_done": r["qty_done"]})
        return out
    finally:
        conn.close()


def get_visit_task_counts(db_path, job_id: int) -> dict:
    """{visit_id: {"tasks": n, "done": n}} for the Visits tab."""
    conn = get_connection(db_path)
    try:
        return {r["visit_id"]: {"tasks": r["n"], "done": r["d"]} for r in conn.execute("""
            SELECT vt.visit_id, COUNT(*) AS n,
                   SUM(CASE WHEN vt.completed=1 OR COALESCE(vt.qty_done,0)>0 THEN 1 ELSE 0 END) AS d
            FROM visit_tasks vt JOIN schedule_events e ON e.id = vt.visit_id
            WHERE e.job_id=? GROUP BY vt.visit_id""", (job_id,)).fetchall()}
    finally:
        conn.close()


# ─────────────────────────────────────────────────────────────────────────────
#  WRITE
# ─────────────────────────────────────────────────────────────────────────────

def save_visit_tasks(db_path, visit_id: int, tasks: list, new_tasks: list | None = None) -> dict:
    """Set a visit's task list and progress in one go.

      tasks     = [{"task_id", "completed": bool, "qty_done": n | None}, ...]
                  — the complete list: tasks not in it are taken off the visit
      new_tasks = [{"title", "qty", "unit_price", "billing"}, ...]
                  — created on the job (the master list) and added to the visit

    Claimed rows (billed on a claim) can't be changed or removed. Returns
    {"recurring": [...tasks newly completed that recur]}."""
    from core.jobs import save_work_task
    conn = get_connection(db_path)
    try:
        v = conn.execute("SELECT id, job_id, event_type FROM schedule_events WHERE id=?",
                         (visit_id,)).fetchone()
        if not v or v["event_type"] != "Visit" or not v["job_id"]:
            raise ValueError("Tasks can only be added to a job visit")
        job = conn.execute("SELECT id, contact_id FROM jobs WHERE id=?", (v["job_id"],)).fetchone()
        existing = {r["task_id"]: dict(r) for r in conn.execute(
            "SELECT * FROM visit_tasks WHERE visit_id=?", (visit_id,))}
    finally:
        conn.close()

    # New tasks go on the job first (their own connection, via the normal path).
    created = []
    for nt in (new_tasks or []):
        title = (nt.get("title") or "").strip()
        if not title:
            continue
        if not job["contact_id"]:
            raise ValueError("Set a client on the job before adding tasks")
        billing = nt.get("billing") or "fixed"
        tid = save_work_task(db_path, {
            "contact_id": job["contact_id"], "job_id": job["id"], "title": title,
            "qty": float(nt.get("qty") or 1) if billing == "fixed" else 1,
            "unit_price": float(nt.get("unit_price") or 0) if billing == "fixed" else 0,
            "billing": billing})
        created.append({"task_id": tid, "completed": bool(nt.get("completed")),
                        "qty_done": nt.get("qty_done")})

    wanted = {}
    for t in list(tasks or []) + created:
        tid = int(t["task_id"])
        q = t.get("qty_done")
        q = float(q) if q not in (None, "") else None
        if q is not None and q < 0:
            raise ValueError("Qty done can't be negative")
        wanted[tid] = {"completed": 1 if t.get("completed") else 0, "qty_done": q}

    conn = get_connection(db_path)
    try:
        touched = set(existing) | set(wanted)
        for tid in touched:
            row = conn.execute("SELECT id, title, job_id, opp_id, qty, billing FROM work_tasks WHERE id=?",
                               (tid,)).fetchone()
            old = existing.get(tid)
            if old and old["invoice_id"]:
                new = wanted.get(tid)
                if not new or new["completed"] != old["completed"] or new["qty_done"] != old["qty_done"]:
                    raise ValueError(f"'{row['title'] if row else tid}' on this visit has been claimed — "
                                     "void the invoice to change it")
                continue
            if tid not in wanted:
                conn.execute("DELETE FROM visit_tasks WHERE visit_id=? AND task_id=?", (visit_id, tid))
                continue
            if not row or v["job_id"] not in (row["job_id"], row["opp_id"]):
                raise ValueError("A task isn't on this visit's job")
            w = wanted[tid]
            if w["qty_done"] is not None and (row["billing"] or "fixed") == "fixed":
                others = conn.execute("""SELECT COALESCE(SUM(qty_done),0) AS s FROM visit_tasks
                    WHERE task_id=? AND visit_id<>?""", (tid, visit_id)).fetchone()["s"]
                if others + w["qty_done"] > float(row["qty"] or 1) + 1e-9:
                    raise ValueError(f"'{row['title']}': {w['qty_done']:g} would take it past its "
                                     f"{float(row['qty'] or 1):g} total ({others:g} done on other visits)")
            if old:
                conn.execute("UPDATE visit_tasks SET completed=?, qty_done=? WHERE id=?",
                             (w["completed"], w["qty_done"], old["id"]))
            else:
                conn.execute("""INSERT INTO visit_tasks (visit_id, task_id, completed, qty_done)
                    VALUES (?,?,?,?)""", (visit_id, tid, w["completed"], w["qty_done"]))
        recurring = []
        for tid in touched:
            newly = recompute_task(conn, tid)
            if newly and newly.get("is_recurring"):
                recurring.append(newly)
        conn.commit()
        return {"recurring": recurring, "created": [c["task_id"] for c in created]}
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def delete_visit_progress(db_path, visit_id: int) -> list:
    """Remove a visit's task rows and re-derive those tasks' status — called
    just before the visit itself is deleted. Returns the affected task ids."""
    conn = get_connection(db_path)
    try:
        tids = task_ids_for_visit(conn, visit_id)
        conn.execute("DELETE FROM visit_tasks WHERE visit_id=?", (visit_id,))
        for tid in tids:
            recompute_task(conn, tid)
        conn.commit()
        return tids
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
