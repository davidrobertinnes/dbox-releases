"""
Dogbox Accounting — Payment Confirmation & ABA Batch Report PDF Generator
================================================================
Two PDF document types:

1. generate_payment_confirmation()
   A single-payment confirmation / remittance advice for one payment
   or receipt. Shows company details, contact, payment meta, and the
   invoices/bills allocated to that payment. Styled to match invoices.

2. generate_aba_report()
   A batch payment summary report for an ABA file run. Shows all
   payments included, their destinations, and a grand total. Suitable
   for internal records and audit trails.
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.


import os
import json
import tempfile
from datetime import date as _date

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_RIGHT, TA_LEFT, TA_CENTER
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, KeepTogether,
)

from core.database import get_connection
from core.invoice_pdf import (
    DEFAULT_DOC_THEME, _c, _resolve_theme, _s, _fmt,
    _logo_image, _logo_from_co, _load_doc_theme, _make_watermark_callback, WHITE,
)

W, H = A4
GREEN = colors.HexColor("#27ae60")
BLUE  = colors.HexColor("#3d7eff")


# ── Shared helpers ────────────────────────────────────────────────────────────



def _load_company(conn):
    row = conn.execute("SELECT * FROM company").fetchone()
    return dict(row) if row else {}


def _co_details(co, s, logo_img):
    """Return (left_header_elem, from_elems_list) for use in address block."""
    co_name  = co.get("name") or "Your Company"
    co_abn   = co.get("abn") or ""
    co_addr  = ", ".join(filter(None, [
        co.get("address"), co.get("city"),
        co.get("state"),   co.get("postcode")]))
    co_phone = co.get("phone") or ""
    co_email = co.get("email") or ""
    co_web   = co.get("website") or ""

    left_hdr = logo_img if logo_img else Paragraph(co_name, s["co_name"])

    from_elems = [Paragraph("From", s["label"])]
    if not logo_img:
        from_elems.append(Paragraph(co_name, s["body_b"]))
    if co_abn:
        from_elems.append(Paragraph(f"ABN: {co_abn}", s["body"]))
    if co_addr:
        from_elems.append(Paragraph(co_addr, s["body"]))
    for val, prefix in [(co_phone, "T: "), (co_email, "E: "), (co_web, "")]:
        if val:
            from_elems.append(Paragraph(f"{prefix}{val}", s["small"]))

    return left_hdr, from_elems, co_name, co_abn, co_email, co_phone


def _footer(story, s, co_name, co_abn, co_email, co_phone, th, note=""):
    story.append(Spacer(1, 5*mm))
    story.append(HRFlowable(width="100%", thickness=0.5,
                              color=_c(th["rule_colour"]), spaceAfter=2*mm))
    parts = [co_name]
    if co_abn:   parts.append(f"ABN: {co_abn}")
    if co_email: parts.append(co_email)
    if co_phone: parts.append(co_phone)
    story.append(Paragraph("  |  ".join(parts), s["ctr"]))
    if note:
        story.append(Paragraph(note, s["ctr"]))


# ══════════════════════════════════════════════════════════════════════════════
# 1. SINGLE PAYMENT CONFIRMATION / REMITTANCE ADVICE
# ══════════════════════════════════════════════════════════════════════════════

def generate_payment_confirmation(db_path, payment_id,
                                   output_path=None, doc_theme=None, watermark=None):
    _wm_text = watermark
    """
    Generate a payment confirmation / remittance advice PDF for one payment.

    For a Receipt: "Payment Received" — sent to customer confirming we received
    their money and which invoices it's been allocated to.

    For a Payment: "Remittance Advice" — sent to supplier confirming we have
    paid them and which bills the payment covers.

    Returns the path to the generated PDF.
    """
    conn = get_connection(db_path)

    pmt = conn.execute("""
        SELECT p.*,
               c.name        as contact_name,
               c.email       as contact_email,
               c.abn         as contact_abn,
               c.address     as contact_address,
               c.city        as contact_city,
               c.state       as contact_state,
               c.postcode    as contact_postcode,
               c.phone       as contact_phone,
               a.name        as bank_name,
               a.bsb         as bank_bsb,
               a.account_number as bank_account_number
        FROM payments p
        LEFT JOIN contacts c ON p.contact_id  = c.id
        LEFT JOIN accounts a ON p.bank_account_id = a.id
        WHERE p.id = ?""", (payment_id,)).fetchone()

    if not pmt:
        raise ValueError(f"Payment {payment_id} not found")

    pmt = dict(pmt)
    is_receipt = (pmt["payment_type"] == "Receipt")

    # Load allocations — invoices for receipts, bills for payments
    if is_receipt:
        allocs = conn.execute("""
            SELECT pa.amount as alloc_amount,
                   i.invoice_number as doc_number,
                   i.invoice_date   as doc_date,
                   i.total          as doc_total,
                   i.amount_paid    as doc_paid,
                   i.status         as doc_status
            FROM payment_allocations pa
            JOIN invoices i ON pa.invoice_id = i.id
            WHERE pa.payment_id = ?
            ORDER BY i.invoice_date""", (payment_id,)).fetchall()
    else:
        allocs = conn.execute("""
            SELECT pa.amount as alloc_amount,
                   b.bill_number    as doc_number,
                   b.bill_date      as doc_date,
                   b.total          as doc_total,
                   b.amount_paid    as doc_paid,
                   b.status         as doc_status
            FROM payment_allocations pa
            JOIN bills b ON pa.bill_id = b.id
            WHERE pa.payment_id = ?
            ORDER BY b.bill_date""", (payment_id,)).fetchall()

    allocs = [dict(a) for a in allocs]
    co     = _load_company(conn)
    conn.close()

    # Theme
    if doc_theme is None:
        try:
            raw = co.get("doc_theme")
            if raw:
                doc_theme = json.loads(raw)
        except Exception:
            pass
    th = _resolve_theme(doc_theme)
    s  = _s(th)

    # Extra styles
    s["doc_title"] = ParagraphStyle(
        "doc_title", fontName="Helvetica-Bold",
        fontSize=20, textColor=_c(th["accent_bar"]),
        leading=24, alignment=TA_RIGHT)
    s["confirm_box"] = ParagraphStyle(
        "confirm_box", fontName="Helvetica-Bold",
        fontSize=11, textColor=GREEN, leading=15)

    logo_img = _logo_from_co(co)
    left_hdr, from_elems, co_name, co_abn, co_email, co_phone = \
        _co_details(co, s, logo_img)

    # Output
    if output_path is None:
        ref = pmt.get("reference") or str(payment_id)
        safe = ref.replace("/", "-").replace("\\", "-")
        output_path = os.path.join(tempfile.mkdtemp(), f"confirmation_{safe}.pdf")

    doc_title  = "PAYMENT RECEIVED" if is_receipt else "REMITTANCE ADVICE"
    contact_lbl = "Received From" if is_receipt else "Paid To"

    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        leftMargin=18*mm, rightMargin=18*mm,
        topMargin=14*mm,  bottomMargin=14*mm,
        title=f"{doc_title} — {pmt.get('reference', '')}",
        author=co_name,
    )
    story = []

    # ── Header ────────────────────────────────────────────────────────────────
    hdr_tbl = Table(
        [[left_hdr, Paragraph(doc_title, s["doc_title"])]],
        colWidths=[95*mm, 80*mm])
    hdr_tbl.setStyle(TableStyle([
        ("VALIGN",        (0,0), (-1,-1), "BOTTOM"),
        ("BOTTOMPADDING", (0,0), (-1,-1), 3),
    ]))
    story.append(hdr_tbl)
    if logo_img:
        story.append(Paragraph(co_name, s["body_b"]))
    story.append(HRFlowable(width="100%", thickness=2,
                              color=_c(th["accent_bar"]),
                              spaceAfter=4*mm, spaceBefore=2*mm))

    # ── Address block: From | To | Meta ──────────────────────────────────────
    contact_elems = [Paragraph(contact_lbl, s["label"])]
    contact_elems.append(Paragraph(pmt["contact_name"] or "—", s["body_b"]))
    if pmt.get("contact_abn"):
        contact_elems.append(Paragraph(f"ABN: {pmt['contact_abn']}", s["body"]))
    caddr = ", ".join(filter(None, [
        pmt.get("contact_address"), pmt.get("contact_city"),
        pmt.get("contact_state"),   pmt.get("contact_postcode")]))
    if caddr:
        contact_elems.append(Paragraph(caddr, s["body"]))
    if pmt.get("contact_email"):
        contact_elems.append(Paragraph(pmt["contact_email"], s["small"]))
    if pmt.get("contact_phone"):
        contact_elems.append(Paragraph(pmt["contact_phone"], s["small"]))

    left_col = from_elems + [Spacer(1, 3*mm)] + contact_elems

    # Meta box
    meta_rows = [
        ["Date",      pmt["payment_date"]],
        ["Reference", pmt.get("reference") or "—"],
        ["Bank",      pmt.get("bank_name") or "—"],
        ["Type",      pmt["payment_type"]],
    ]
    if pmt.get("description"):
        meta_rows.append(["Description", pmt["description"]])

    meta_tbl = Table(meta_rows, colWidths=[28*mm, 47*mm])
    meta_tbl.setStyle(TableStyle([
        ("FONTNAME",  (0,0), (0,-1), "Helvetica-Bold"),
        ("FONTNAME",  (1,0), (1,-1), "Helvetica"),
        ("FONTSIZE",  (0,0), (-1,-1), 9),
        ("TEXTCOLOR", (0,0), (0,-1), _c(th["label_colour"])),
        ("TEXTCOLOR", (1,0), (1,-1), _c(th["body_text"])),
        ("ROWBACKGROUNDS", (0,0), (-1,-1), [WHITE, _c(th["row_alt"])]),
        ("TOPPADDING",    (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
        ("LEFTPADDING",   (0,0), (-1,-1), 6),
        ("RIGHTPADDING",  (0,0), (-1,-1), 6),
        ("BOX",  (0,0), (-1,-1), 0.5, _c(th["rule_colour"])),
        ("GRID", (0,0), (-1,-1), 0.25, _c(th["rule_colour"])),
    ]))

    addr_tbl = Table([[left_col, meta_tbl]], colWidths=[95*mm, 80*mm])
    addr_tbl.setStyle(TableStyle([("VALIGN", (0,0), (-1,-1), "TOP")]))
    story.append(addr_tbl)
    story.append(Spacer(1, 5*mm))

    # ── Allocations table ─────────────────────────────────────────────────────
    doc_label = "Invoice" if is_receipt else "Bill"
    cw = [55*mm, 35*mm, 35*mm, 35*mm, 15*mm]

    def _rh(text, align=TA_LEFT):
        return Paragraph(text, ParagraphStyle(
            "rh", fontName="Helvetica-Bold", fontSize=7,
            textColor=_c(th["header_text"]), leading=10,
            alignment=align, textTransform="uppercase"))

    tbl_data = [[
        _rh(f"{doc_label} Number"),
        _rh("Date"),
        _rh(f"{doc_label} Total", TA_RIGHT),
        _rh("Amount Paid", TA_RIGHT),
        _rh("Status"),
    ]]

    for a in allocs:
        tbl_data.append([
            Paragraph(a["doc_number"] or "—", s["body_b"]),
            Paragraph(a.get("doc_date") or "—", s["body"]),
            Paragraph(_fmt(a.get("doc_total", 0)), s["right"]),
            Paragraph(_fmt(a["alloc_amount"]), s["right_b"]),
            Paragraph(a.get("doc_status") or "", ParagraphStyle(
                "st", fontName="Helvetica", fontSize=8,
                textColor=GREEN if a.get("doc_status") == "Paid"
                else _c(th["body_text"]), leading=11)),
        ])

    if not allocs:
        tbl_data.append([
            Paragraph("No invoice/bill allocations recorded", s["body"]),
            "", "", "", ""])

    alloc_tbl = Table(tbl_data, colWidths=cw, repeatRows=1)
    alloc_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,0), _c(th["header_bg"])),
        ("TOPPADDING",    (0,0), (-1,0), 6),
        ("BOTTOMPADDING", (0,0), (-1,0), 6),
        ("LEFTPADDING",   (0,0), (-1,0), 6),
        ("RIGHTPADDING",  (0,0), (-1,0), 6),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), [WHITE, _c(th["row_alt"])]),
        ("FONTSIZE",      (0,1), (-1,-1), 9),
        ("TOPPADDING",    (0,1), (-1,-1), 5),
        ("BOTTOMPADDING", (0,1), (-1,-1), 5),
        ("LEFTPADDING",   (0,1), (-1,-1), 6),
        ("RIGHTPADDING",  (0,1), (-1,-1), 6),
        ("VALIGN",  (0,0), (-1,-1), "MIDDLE"),
        ("GRID",    (0,0), (-1,-1), 0.25, _c(th["rule_colour"])),
        ("SPAN",    (0,1), (-1,1)) if not allocs else ("NOP", (0,0), (0,0)),
    ]))
    story.append(alloc_tbl)
    story.append(Spacer(1, 4*mm))

    # ── Total block ───────────────────────────────────────────────────────────
    total = pmt["amount"]
    alloc_total = sum(a["alloc_amount"] for a in allocs)
    unalloc = total - alloc_total

    totals_rows = []
    if allocs:
        totals_rows.append([
            Paragraph("Allocated", s["small"]),
            Paragraph(_fmt(alloc_total), s["right"])
        ])
    if abs(unalloc) > 0.005:
        totals_rows.append([
            Paragraph("Unallocated", s["small"]),
            Paragraph(_fmt(unalloc), s["right"])
        ])

    grand_lbl = "AMOUNT RECEIVED" if is_receipt else "AMOUNT PAID"
    grand_tbl = Table(
        [[Paragraph(grand_lbl, s["tot_lbl"]),
          Paragraph(_fmt(total), s["tot_val"])]],
        colWidths=[38*mm, 30*mm])
    grand_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,-1), _c(th["total_bar_bg"])),
        ("TOPPADDING",    (0,0), (-1,-1), 8),
        ("BOTTOMPADDING", (0,0), (-1,-1), 8),
        ("LEFTPADDING",   (0,0), (-1,-1), 8),
        ("RIGHTPADDING",  (0,0), (-1,-1), 8),
    ]))

    if totals_rows:
        sub_tbl = Table(totals_rows, colWidths=[38*mm, 30*mm])
        sub_tbl.setStyle(TableStyle([
            ("TOPPADDING",    (0,0), (-1,-1), 3),
            ("BOTTOMPADDING", (0,0), (-1,-1), 3),
            ("ALIGN",  (1,0), (1,-1), "RIGHT"),
            ("LINEBELOW", (0,-1), (-1,-1), 0.5, _c(th["rule_colour"])),
        ]))
        totals_block = Table([[sub_tbl],[grand_tbl]], colWidths=[68*mm])
    else:
        totals_block = Table([[grand_tbl]], colWidths=[68*mm])

    # Confirmation stamp
    stamp_text  = "RECEIVED" if is_receipt else "PAID"
    stamp_style = ParagraphStyle(
        "stamp_c", fontName="Helvetica-Bold",
        fontSize=26, textColor=GREEN, leading=30)
    summary = Table(
        [[Paragraph(stamp_text, stamp_style), totals_block]],
        colWidths=[100*mm, 75*mm])
    summary.setStyle(TableStyle([
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("ALIGN",  (1,0), (1,0),  "RIGHT"),
    ]))
    story.append(summary)

    # ── Thank-you message box ─────────────────────────────────────────────────
    if is_receipt:
        msg = (f"Thank you for your payment of {_fmt(total)}. "
               "Please retain this confirmation for your records.")
    else:
        msg = (f"This remittance advice confirms payment of {_fmt(total)} "
               f"to {pmt.get('contact_name','your account')}. "
               "Please apply this payment to the items listed above.")

    story.append(Spacer(1, 5*mm))
    msg_tbl = Table(
        [[Paragraph(msg, s["pmt_body"])]],
        colWidths=[175*mm])
    msg_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,-1), _c(th["payment_box_bg"])),
        ("TOPPADDING",    (0,0), (-1,-1), 8),
        ("BOTTOMPADDING", (0,0), (-1,-1), 8),
        ("LEFTPADDING",   (0,0), (-1,-1), 10),
        ("RIGHTPADDING",  (0,0), (-1,-1), 10),
        ("BOX", (0,0), (-1,-1), 1, _c(th["payment_box_border"])),
    ]))
    story.append(KeepTogether(msg_tbl))

    _footer(story, s, co_name, co_abn, co_email, co_phone, th,
            note=f"Payment reference: {pmt.get('reference') or payment_id}  "
                 f"—  {doc_title}")
    doc.build(story, onFirstPage=_make_watermark_callback(_wm_text), onLaterPages=_make_watermark_callback(_wm_text))
    return output_path


# ══════════════════════════════════════════════════════════════════════════════
# 2. ABA BATCH PAYMENT REPORT
# ══════════════════════════════════════════════════════════════════════════════

def generate_aba_report(db_path, payments, process_date,
                         description="PAYMENT", output_path=None,
                         doc_theme=None, skipped=None, watermark=None):
    _wm_text = watermark
    """
    Generate a batch payment summary report for an ABA file run.

    payments: list of dicts from generate_aba() (those actually included)
    skipped:  optional list of payments that were excluded (no bank details)
    process_date: YYYY-MM-DD string
    Returns path to generated PDF.
    """
    conn = get_connection(db_path)
    co   = _load_company(conn)
    conn.close()

    if doc_theme is None:
        try:
            raw = co.get("doc_theme")
            if raw:
                doc_theme = json.loads(raw)
        except Exception:
            pass
    th = _resolve_theme(doc_theme)
    s  = _s(th)

    s["doc_title"] = ParagraphStyle(
        "doc_title", fontName="Helvetica-Bold",
        fontSize=20, textColor=_c(th["accent_bar"]),
        leading=24, alignment=TA_RIGHT)
    s["warn"] = ParagraphStyle(
        "warn", fontName="Helvetica",
        fontSize=9, textColor=colors.HexColor("#e67e22"), leading=13)

    logo_img = _logo_from_co(co)
    left_hdr, from_elems, co_name, co_abn, co_email, co_phone = \
        _co_details(co, s, logo_img)

    if output_path is None:
        safe_date = process_date.replace("-", "")
        output_path = os.path.join(
            tempfile.mkdtemp(), f"aba_report_{safe_date}.pdf")

    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        leftMargin=18*mm, rightMargin=18*mm,
        topMargin=14*mm,  bottomMargin=14*mm,
        title=f"ABA Batch Payment Report — {process_date}",
        author=co_name,
    )
    story = []

    # ── Header ────────────────────────────────────────────────────────────────
    hdr_tbl = Table(
        [[left_hdr, Paragraph("BATCH PAYMENT REPORT", s["doc_title"])]],
        colWidths=[95*mm, 80*mm])
    hdr_tbl.setStyle(TableStyle([
        ("VALIGN",        (0,0), (-1,-1), "BOTTOM"),
        ("BOTTOMPADDING", (0,0), (-1,-1), 3),
    ]))
    story.append(hdr_tbl)
    if logo_img:
        story.append(Paragraph(co_name, s["body_b"]))
    story.append(HRFlowable(width="100%", thickness=2,
                              color=_c(th["accent_bar"]),
                              spaceAfter=4*mm, spaceBefore=2*mm))

    # ── Run details block ─────────────────────────────────────────────────────
    total_amount = sum(p["amount"] for p in payments)
    meta_rows = [
        ["Process Date",  process_date],
        ["Description",   description],
        ["Payments",      str(len(payments))],
        ["Total Amount",  _fmt(total_amount)],
        ["Generated",     str(_date.today())],
    ]
    if skipped:
        meta_rows.append(["Excluded", f"{len(skipped)} (no bank details)"])

    meta_tbl = Table(meta_rows, colWidths=[35*mm, 55*mm])
    meta_tbl.setStyle(TableStyle([
        ("FONTNAME",  (0,0), (0,-1), "Helvetica-Bold"),
        ("FONTNAME",  (1,0), (1,-1), "Helvetica"),
        ("FONTSIZE",  (0,0), (-1,-1), 9),
        ("TEXTCOLOR", (0,0), (0,-1), _c(th["label_colour"])),
        ("TEXTCOLOR", (1,0), (1,-1), _c(th["body_text"])),
        ("ROWBACKGROUNDS", (0,0), (-1,-1), [WHITE, _c(th["row_alt"])]),
        ("TOPPADDING",    (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
        ("LEFTPADDING",   (0,0), (-1,-1), 6),
        ("RIGHTPADDING",  (0,0), (-1,-1), 6),
        ("BOX",  (0,0), (-1,-1), 0.5, _c(th["rule_colour"])),
        ("GRID", (0,0), (-1,-1), 0.25, _c(th["rule_colour"])),
    ]))

    from_block = from_elems
    addr_tbl = Table([[from_block, meta_tbl]], colWidths=[95*mm, 95*mm])
    addr_tbl.setStyle(TableStyle([("VALIGN", (0,0), (-1,-1), "TOP")]))
    story.append(addr_tbl)
    story.append(Spacer(1, 6*mm))

    # ── Payments table ────────────────────────────────────────────────────────
    story.append(Paragraph("Payments Included", s["h3"]))
    story.append(Spacer(1, 2*mm))

    cw_pmt = [25*mm, 50*mm, 28*mm, 38*mm, 34*mm]

    def _rh(text, align=TA_LEFT):
        return Paragraph(text, ParagraphStyle(
            "rh", fontName="Helvetica-Bold", fontSize=7,
            textColor=_c(th["header_text"]), leading=10,
            alignment=align, textTransform="uppercase"))

    pmt_data = [[
        _rh("Date"),
        _rh("Supplier"),
        _rh("BSB"),
        _rh("Reference"),
        _rh("Amount", TA_RIGHT),
    ]]
    for p in payments:
        pmt_data.append([
            Paragraph(p.get("payment_date", ""), s["body"]),
            Paragraph(p.get("dest_name", ""), s["body"]),
            Paragraph(p.get("dest_bsb", ""), s["small"]),
            Paragraph(p.get("lodgement_ref", ""), s["small"]),
            Paragraph(_fmt(p["amount"]), s["right_b"]),
        ])

    pmt_tbl = Table(pmt_data, colWidths=cw_pmt, repeatRows=1)
    pmt_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,0), _c(th["header_bg"])),
        ("TOPPADDING",    (0,0), (-1,0), 6),
        ("BOTTOMPADDING", (0,0), (-1,0), 6),
        ("LEFTPADDING",   (0,0), (-1,0), 6),
        ("RIGHTPADDING",  (0,0), (-1,0), 6),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), [WHITE, _c(th["row_alt"])]),
        ("FONTSIZE",      (0,1), (-1,-1), 9),
        ("TOPPADDING",    (0,1), (-1,-1), 5),
        ("BOTTOMPADDING", (0,1), (-1,-1), 5),
        ("LEFTPADDING",   (0,1), (-1,-1), 6),
        ("RIGHTPADDING",  (0,1), (-1,-1), 6),
        ("VALIGN",  (0,0), (-1,-1), "MIDDLE"),
        ("GRID",    (0,0), (-1,-1), 0.25, _c(th["rule_colour"])),
    ]))
    story.append(pmt_tbl)
    story.append(Spacer(1, 3*mm))

    # Grand total bar
    grand_tbl = Table(
        [[Paragraph("TOTAL", s["tot_lbl"]),
          Paragraph(_fmt(total_amount), s["tot_val"])]],
        colWidths=[135*mm, 40*mm])
    grand_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,-1), _c(th["total_bar_bg"])),
        ("TOPPADDING",    (0,0), (-1,-1), 8),
        ("BOTTOMPADDING", (0,0), (-1,-1), 8),
        ("LEFTPADDING",   (0,0), (-1,-1), 10),
        ("RIGHTPADDING",  (0,0), (-1,-1), 8),
    ]))
    story.append(grand_tbl)

    # ── Excluded payments (if any) ────────────────────────────────────────────
    if skipped:
        story.append(Spacer(1, 6*mm))
        story.append(Paragraph("Excluded Payments (no bank details)", s["h3"]))
        story.append(Spacer(1, 2*mm))

        excl_data = [[
            _rh("Date"),
            _rh("Supplier"),
            _rh("Reference"),
            _rh("Amount", TA_RIGHT),
            _rh("Reason"),
        ]]
        for p in skipped:
            excl_data.append([
                Paragraph(p.get("payment_date", ""), s["body"]),
                Paragraph(p.get("dest_name", ""), s["body"]),
                Paragraph(p.get("lodgement_ref", ""), s["small"]),
                Paragraph(_fmt(p["amount"]), s["right"]),
                Paragraph("No BSB / account", s["warn"]),
            ])
        excl_tbl = Table(excl_data, colWidths=[25*mm, 55*mm, 38*mm, 30*mm, 27*mm],
                          repeatRows=1)
        excl_tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0,0), (-1,0), _c(th["header_bg"])),
            ("TOPPADDING",    (0,0), (-1,0), 6),
            ("BOTTOMPADDING", (0,0), (-1,0), 6),
            ("LEFTPADDING",   (0,0), (-1,-1), 6),
            ("RIGHTPADDING",  (0,0), (-1,-1), 6),
            ("ROWBACKGROUNDS",(0,1), (-1,-1), [WHITE, _c(th["row_alt"])]),
            ("FONTSIZE",      (0,1), (-1,-1), 9),
            ("TOPPADDING",    (0,1), (-1,-1), 5),
            ("BOTTOMPADDING", (0,1), (-1,-1), 5),
            ("VALIGN",  (0,0), (-1,-1), "MIDDLE"),
            ("GRID",    (0,0), (-1,-1), 0.25, _c(th["rule_colour"])),
        ]))
        story.append(KeepTogether(excl_tbl))
        story.append(Spacer(1, 2*mm))
        story.append(Paragraph(
            "These payments were not included in the ABA file. "
            "Edit each supplier's contact record to add their BSB and Account Number, "
            "then re-generate the ABA file to include them.",
            s["small"]))

    _footer(story, s, co_name, co_abn, co_email, co_phone, th,
            note=f"ABA Batch Payment Report  —  Process Date: {process_date}  "
                 f"—  {len(payments)} payments  —  Total: {_fmt(total_amount)}")
    doc.build(story, onFirstPage=_make_watermark_callback(_wm_text), onLaterPages=_make_watermark_callback(_wm_text))
    return output_path


# ══════════════════════════════════════════════════════════════════════════════
# 3. EMAIL HELPER — send confirmation/remittance
# ══════════════════════════════════════════════════════════════════════════════

def send_payment_confirmation_email(db_path, payment_id, pdf_path, to_email,
                                     subject_override=None, body_override=None):
    """
    Email a payment confirmation / remittance advice PDF.
    Returns (True, None) on success, (False, error_message) on failure.
    """
    from core.email_invoice import get_email_settings, _dec_pw
    import smtplib, ssl, os as _os
    from email.mime.multipart import MIMEMultipart
    from email.mime.text      import MIMEText
    from email.mime.base      import MIMEBase
    from email                import encoders

    settings = get_email_settings(db_path)
    if not settings.get("smtp_user") or not settings.get("smtp_password"):
        return False, "Email not configured. Go to File → Email Settings."

    conn = get_connection(db_path)
    pmt  = conn.execute("""
        SELECT p.*, c.name as contact_name, c.email as contact_email
        FROM payments p
        LEFT JOIN contacts c ON p.contact_id = c.id
        WHERE p.id = ?""", (payment_id,)).fetchone()
    co   = conn.execute("SELECT name FROM company").fetchone()
    conn.close()

    if not pmt:
        return False, "Payment not found"

    pmt     = dict(pmt)
    co_name = co["name"] if co else "Your Company"
    is_receipt = (pmt["payment_type"] == "Receipt")

    tmpl_vars = {
        "company_name":   co_name,
        "contact_name":   pmt.get("contact_name") or "",
        "amount":         f"${pmt['amount']:,.2f}",
        "payment_date":   pmt.get("payment_date") or "",
        "reference":      pmt.get("reference") or "",
        "payment_type":   pmt["payment_type"],
    }

    if is_receipt:
        def_subj = "Payment Received — {reference} from {company_name}"
        def_body = (
            "Dear {contact_name},\n\n"
            "Thank you for your payment of {amount} received on {payment_date}.\n\n"
            "Please find attached your payment confirmation.\n\n"
            "Kind regards,\n{company_name}"
        )
    else:
        def_subj = "Remittance Advice — {reference} from {company_name}"
        def_body = (
            "Dear {contact_name},\n\n"
            "Please find attached our remittance advice confirming payment "
            "of {amount} on {payment_date}.\n\n"
            "Please apply this to your records accordingly.\n\n"
            "Kind regards,\n{company_name}"
        )

    subject = subject_override or def_subj
    body    = body_override    or def_body
    for k, v in tmpl_vars.items():
        subject = subject.replace("{" + k + "}", str(v))
        body    = body.replace("{" + k + "}", str(v))

    msg = MIMEMultipart()
    from_addr = settings.get("from_email") or settings.get("smtp_user", "")
    from_name = settings.get("from_name") or co_name
    msg["From"]    = f"{from_name} <{from_addr}>"
    msg["To"]      = to_email
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    fname = _os.path.basename(pdf_path)
    with open(pdf_path, "rb") as f:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(f.read())
    encoders.encode_base64(part)
    part.add_header("Content-Disposition", f'attachment; filename="{fname}"')
    msg.attach(part)

    try:
        context = ssl.create_default_context()
        port    = int(settings.get("smtp_port", 587))
        host    = settings.get("smtp_host", "smtp.gmail.com")
        use_tls = int(settings.get("use_tls", 1))
        if port == 465:
            with smtplib.SMTP_SSL(host, port, context=context) as server:
                server.login(settings["smtp_user"],
                             _dec_pw(settings["smtp_password"]))
                server.sendmail(from_addr, to_email, msg.as_string())
        else:
            with smtplib.SMTP(host, port) as server:
                if use_tls:
                    server.starttls(context=context)
                server.login(settings["smtp_user"],
                             _dec_pw(settings["smtp_password"]))
                server.sendmail(from_addr, to_email, msg.as_string())
        return True, None
    except smtplib.SMTPAuthenticationError:
        return False, (
            "Authentication failed.\n\n"
            "For Gmail: use an App Password "
            "(Google Account → Security → 2-Step Verification → App passwords).")
    except smtplib.SMTPException as e:
        return False, f"SMTP error: {e}"
    except Exception as e:
        return False, f"Error: {e}"


# ══════════════════════════════════════════════════════════════════════════════
#  PAYG PAYMENT SUMMARY PDF
# ══════════════════════════════════════════════════════════════════════════════

def render_payment_summary_pdf(record: dict, company: dict,
                                out_path: str = None) -> str:
    """
    Generate a single PAYG Payment Summary PDF for one employee.
    Styled to resemble the ATO's INB Payment Summary layout.
    Returns path to the generated PDF.
    """
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Spacer
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.platypus import Paragraph

    if out_path is None:
        fd, out_path = tempfile.mkstemp(suffix=".pdf",
            prefix=f"payment_summary_{record['employee_id']}_")
        os.close(fd)

    th    = _resolve_theme(_load_doc_theme(company) if company else None)
    NAVY  = _c(th["header_bg"])
    WHITE = colors.white
    PANEL = _c(th["row_alt"])
    RULE  = _c(th["rule_colour"])
    BLACK = colors.black
    RED   = colors.HexColor("#c0392b")
    DIM   = _c(th["dim_text"])

    W, H = A4
    doc = SimpleDocTemplate(out_path, pagesize=A4,
                             leftMargin=18*mm, rightMargin=18*mm,
                             topMargin=14*mm, bottomMargin=14*mm)

    def ps(name, **kw):
        d = dict(fontName="Helvetica", fontSize=9, leading=12, textColor=BLACK)
        d.update(kw)
        return ParagraphStyle(name, **d)

    sTitle  = ps("paysum_title",  fontSize=16, textColor=WHITE,
                 fontName="Helvetica-Bold", leading=20)
    sSub    = ps("paysum_sub",    fontSize=9,  textColor=WHITE,
                 fontName="Helvetica", leading=12)
    sLabel  = ps("paysum_label",  fontSize=8,  textColor=NAVY,
                 fontName="Helvetica-Bold", leading=11)
    sValue  = ps("paysum_value",  fontSize=10, textColor=BLACK,
                 fontName="Helvetica", leading=13)
    sSmall  = ps("paysum_small",  fontSize=7,  textColor=DIM,
                 fontName="Helvetica", leading=10)
    sFooter = ps("paysum_footer", fontSize=7,  textColor=DIM,
                 fontName="Helvetica", leading=10)

    def money(v):
        return f"${float(v or 0):,.2f}"

    def field_row(label_txt, value_txt, bg=WHITE):
        return [
            Paragraph(label_txt, sLabel),
            Paragraph(str(value_txt), sValue),
        ]

    fy   = record["fy_year"]
    emp  = record["name"]
    co   = company.get("name", "")
    abn  = company.get("abn", "")

    story = []

    # ── Banner ───────────────────────────────────────────────────────────────
    banner_data = [[
        Paragraph(f"PAYG Payment Summary — Individual non-business", sTitle),
        Paragraph(f"Income year 1 July {fy-1} to 30 June {fy}", sSub),
    ]]
    banner = Table(banner_data, colWidths=[130*mm, 55*mm])
    banner.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), NAVY),
        ("VALIGN",     (0,0), (-1,-1), "MIDDLE"),
        ("TOPPADDING", (0,0), (-1,-1), 6),
        ("BOTTOMPADDING",(0,0),(-1,-1), 6),
        ("LEFTPADDING", (0,0),(0,-1),  8),
    ]))
    story.append(banner)
    story.append(Spacer(1, 6*mm))

    # ── Employer details ─────────────────────────────────────────────────────
    emp_data = [
        [Paragraph("Payer name (employer)", sLabel),
         Paragraph(co, sValue),
         Paragraph("Payer ABN", sLabel),
         Paragraph(abn or "—", sValue)],
    ]
    emp_tbl = Table(emp_data, colWidths=[40*mm, 70*mm, 30*mm, 40*mm])
    emp_tbl.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), PANEL),
        ("BOX",  (0,0), (-1,-1), 0.5, NAVY),
        ("GRID", (0,0), (-1,-1), 0.25, RULE),
        ("TOPPADDING",    (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
        ("LEFTPADDING",   (0,0), (-1,-1), 4),
    ]))
    story.append(emp_tbl)
    story.append(Spacer(1, 4*mm))

    # ── Employee details ─────────────────────────────────────────────────────
    payee_data = [
        [Paragraph("Payee name", sLabel),
         Paragraph(emp, sValue),
         Paragraph("TFN", sLabel),
         Paragraph(record.get("tfn_display", "Not on file"), sValue)],
        [Paragraph("Address", sLabel),
         Paragraph(str(record.get("address") or "—"), sValue),
         Paragraph("Employment type", sLabel),
         Paragraph(str(record.get("employment_type") or "—"), sValue)],
    ]
    payee_tbl = Table(payee_data, colWidths=[30*mm, 80*mm, 30*mm, 40*mm])
    payee_tbl.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), WHITE),
        ("BOX",  (0,0), (-1,-1), 0.5, NAVY),
        ("GRID", (0,0), (-1,-1), 0.25, RULE),
        ("TOPPADDING",    (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
        ("LEFTPADDING",   (0,0), (-1,-1), 4),
    ]))
    story.append(payee_tbl)
    story.append(Spacer(1, 5*mm))

    # ── Income & Tax ─────────────────────────────────────────────────────────
    def amount_row(code, desc, val, highlight=False):
        bg = colors.HexColor("#fff3cd") if highlight else WHITE
        return ([
            Paragraph(code, sLabel),
            Paragraph(desc, sLabel),
            Paragraph(money(val), ps("paysum_income_val", fontSize=11,
                      fontName="Helvetica-Bold",
                      textColor=NAVY if highlight else BLACK,
                      leading=14)),
        ], bg)

    rows_data = []
    styles_data = []

    for row, bg in [
        amount_row("1", "Gross payments", record["gross_wages"]),
        amount_row("2", "PAYG tax withheld", record["payg_withheld"], highlight=True),
        amount_row("3", "Reportable fringe benefits amount",
                   record["reportable_fringe_benefits"]),
        amount_row("4", "Reportable employer super contributions",
                   record["reportable_super"]),
        amount_row("5", "Total allowances", record["total_allowances"]),
        amount_row("6", "Lump sum A", record["lump_sum_a"]),
        amount_row("7", "Lump sum B", record["lump_sum_b"]),
        amount_row("8", "Lump sum D", record["lump_sum_d"]),
        amount_row("9", "Lump sum E", record["lump_sum_e"]),
        amount_row("10","Deductible amount of UPP",
                   record["deductible_expenses"]),
    ]:
        rows_data.append(row)
        styles_data.append(bg)

    income_tbl = Table(rows_data, colWidths=[12*mm, 110*mm, 58*mm])
    ts = TableStyle([
        ("BOX",  (0,0), (-1,-1), 0.5, NAVY),
        ("LINEBELOW", (0,0), (-1,-2), 0.25, RULE),
        ("TOPPADDING",    (0,0), (-1,-1), 3),
        ("BOTTOMPADDING", (0,0), (-1,-1), 3),
        ("LEFTPADDING",   (0,0), (-1,-1), 4),
        ("ALIGN", (2,0), (2,-1), "RIGHT"),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
    ])
    for i, bg in enumerate(styles_data):
        ts.add("BACKGROUND", (0,i), (-1,i), bg)
    income_tbl.setStyle(ts)
    story.append(Paragraph("Income and tax details", sLabel))
    story.append(Spacer(1, 1*mm))
    story.append(income_tbl)

    # ── Allowances itemised ───────────────────────────────────────────────────
    detail = record.get("allowances_detail", {})
    if detail:
        story.append(Spacer(1, 4*mm))
        story.append(Paragraph("Allowances (itemised)", sLabel))
        story.append(Spacer(1, 1*mm))
        allow_data = [[Paragraph("Type", sLabel),
                       Paragraph("Amount", sLabel)]]
        for atype, amt in sorted(detail.items()):
            allow_data.append([Paragraph(atype, sValue),
                               Paragraph(money(amt), sValue)])
        allow_tbl = Table(allow_data, colWidths=[120*mm, 60*mm])
        allow_tbl.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), PANEL),
            ("BOX",  (0,0), (-1,-1), 0.5, NAVY),
            ("GRID", (0,0), (-1,-1), 0.25, RULE),
            ("TOPPADDING",  (0,0), (-1,-1), 3),
            ("BOTTOMPADDING",(0,0),(-1,-1), 3),
            ("LEFTPADDING", (0,0), (-1,-1), 4),
            ("ALIGN", (1,0), (1,-1), "RIGHT"),
        ]))
        story.append(allow_tbl)

    # ── Footer ───────────────────────────────────────────────────────────────
    story.append(Spacer(1, 8*mm))
    story.append(Paragraph(
        "This payment summary shows the income and tax for the financial year shown above. "
        "Include this information in your income tax return. "
        "Generated by dbox accounting software.",
        sFooter))
    story.append(Spacer(1, 2*mm))
    story.append(Paragraph(
        f"Generated: {_date.today():%d %B %Y}    "
        f"Payer: {co}    ABN: {abn or 'not provided'}",
        sFooter))

    doc.build(story)
    return out_path
