# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
core/licence.py — dbox licence file reader and verifier.

Licence file format (dbox.lic, plain text, in user_data_dir(); older
versions kept it next to the app):

    issued_to   = Acme Accounting Pty Ltd
    contact     = jane@acme.com.au
    issue_date  = 2026-03-17
    eval_expiry = 2026-04-16
    tier        = full
    build       = 3.1b
    issued_by   = Dogbox Software
    hmac        = <hex>

Rules:
  - Fields are case-insensitive keys, values trimmed of whitespace.
  - The hmac is computed over the canonical form of all other fields
    (sorted by key, "key=value" joined by newline) using HMAC-SHA256
    with the shared secret.
  - Any modification to any field — including eval_expiry — invalidates
    the hmac and the licence is treated as tampered.
  - eval_expiry absent or blank → permanent licence (registered).
  - tier absent → defaults to "full".
  - build field is informational — the app decides how to handle
    licences from different build series.

Licence status values:
  "valid"     — present, signature OK, not expired
  "lapsed"    — present, signature OK, eval_expiry passed
  "tampered"  — present but signature does not verify
  "missing"   — no licence file found
  "malformed" — file exists but cannot be parsed

This module has NO imports from the rest of the dbox codebase.
It can be copied verbatim into any future version.
"""


import hmac as _hmac
import hashlib
import os
from datetime import date, timedelta

FREE_UNTIL = date(2027, 3, 31)  # extended during licence model redesign

# ── Phone-home server ─────────────────────────────────────────────────────────
VALIDATION_URL   = "https://license.dogboxsoftware.com.au"
CHECK_UPDATE_URL = "https://license.dogboxsoftware.com.au/api/check-update"

# ── Secret key ────────────────────────────────────────────────────────────────
# This key is embedded in the app. Anyone who can read the source can find it,
# but for a small known userbase this provides adequate deterrence.
# Rotate the key in a new build if a leak is suspected (old licences issued
# against the old key will then fail — you reissue them).
_SECRET = b"dbox-2026-K7x#mP9qR2nL4vW8jT"   # keep private

# ── Field names that form the signed payload ──────────────────────────────────
_SIGNED_FIELDS = [
    "issued_to",
    "contact",
    "issue_date",
    "eval_expiry",
    "tier",
    "build",
    "issued_by",
    # ── Milestone 2: phone-home validation ───────────────────────────────────
    # licence_id is a UUID4 assigned at issuance and included in the signed
    # payload. Currently informational only — the app reads and logs it but
    # does not validate it against a server.
    # When Milestone 2 (Update Server) is built, the app will POST this UUID
    # to the validation endpoint on startup (non-blocking, silent fail if
    # offline) to confirm the licence is active and not revoked.
    # See: NOTES.md — Milestone 2 (Update Server / Licence Validation)
    "licence_id",
]

# Optional fields — included in the signed payload only when present in the
# licence file. This keeps old licences (which lack these fields) valid while
# preventing a user from adding the field to a V1 licence: adding "features"
# to an old file switches it to V2 signing, and the stored HMAC (computed
# without "features") no longer matches → detected as tampered.
# "maintenance_expires" is an ISO date string (YYYY-MM-DD) or absent.
# When present: software updates/support are entitled up to this date.
# When absent or blank: no maintenance expiry (permanent entitlement).
_SIGNED_FIELDS_OPTIONAL = ["features", "maintenance_expires"]


def _canonical(fields: dict) -> str:
    """
    Build the canonical string that is signed.
    Sorted by key, "key=value" joined by newline.
    Includes _SIGNED_FIELDS always, plus any _SIGNED_FIELDS_OPTIONAL that are
    present in the file (backward-compatible: old licences omit these fields).
    """
    active = list(_SIGNED_FIELDS)
    for f in _SIGNED_FIELDS_OPTIONAL:
        if f in fields:
            active.append(f)
    lines = []
    for key in sorted(active):
        lines.append(f"{key}={fields.get(key, '').strip()}")
    return "\n".join(lines)


def _compute_hmac(fields: dict) -> str:
    """Compute HMAC-SHA256 over the canonical field string."""
    payload = _canonical(fields).encode("utf-8")
    return _hmac.new(_SECRET, payload, hashlib.sha256).hexdigest()


def _parse_licence_text(text: str) -> dict:
    """Parse key=value lines into a dict. Ignores blank lines and # comments."""
    result = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        result[key.strip().lower()] = value.strip()
    return result


from core.paths import user_data_dir  # noqa: E402  (re-exported for callers)


def licence_save_path() -> str:
    """Where a new or refreshed dbox.lic is written. Creates the folder."""
    d = user_data_dir()
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "dbox.lic")


def save_licence_text(text: str) -> str:
    """Write licence text to licence_save_path(). Returns the path written."""
    path = licence_save_path()
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)
    return path


def find_licence_file(app_dir: str = None) -> str | None:
    """
    Search for dbox.lic in priority order:

      0. user_data_dir() — where licences are saved now
      1. app_dir if explicitly provided (caller's best guess at app root)
      2. Beside the running executable — sys.executable directory.
         Covers PyInstaller --onefile EXE: licence sits next to dbox.exe
      3. Parent of this file (project root when running from source zip)
      4. Directory of this file (core/) — fallback

    1–4 are where older versions saved it. A licence found only there is
    copied to user_data_dir() so it survives a move to a read-only install.

    Returns the normalised absolute path of the first dbox.lic found,
    or None if not found in any location.
    """
    import sys
    new_path = os.path.join(user_data_dir(), "dbox.lic")
    if os.path.isfile(new_path):
        return os.path.normpath(new_path)

    candidates = []

    # 1. Explicit app_dir from caller
    if app_dir:
        candidates.append(os.path.join(app_dir, "dbox.lic"))

    # 2. Beside the running executable (essential for PyInstaller --onefile)
    #    sys.executable = path to the .exe or the python interpreter
    #    For frozen builds: C:\Users\david\dbox\dbox.exe
    #    For source runs:   C:\Python312\python.exe  (not useful, skip)
    if getattr(sys, "frozen", False):
        # Running as a compiled executable — licence must be beside the exe
        exe_dir = os.path.dirname(os.path.abspath(sys.executable))
        candidates.append(os.path.join(exe_dir, "dbox.lic"))
    else:
        # Running from source — look at project root (parent of core/)
        this_dir = os.path.dirname(os.path.abspath(__file__))
        candidates.append(os.path.join(this_dir, "..", "dbox.lic"))
        candidates.append(os.path.join(this_dir, "dbox.lic"))

    for path in candidates:
        norm = os.path.normpath(path)
        if os.path.isfile(norm):
            # Legacy location — copy forward; keep using it if the copy fails
            try:
                with open(norm, "r", encoding="utf-8") as fh:
                    return save_licence_text(fh.read())
            except Exception:
                return norm
    return None


def read_licence(path: str) -> dict:
    """
    Read and parse a licence file. Returns a raw field dict.
    Raises FileNotFoundError if path does not exist.
    Raises ValueError if the file cannot be parsed.
    """
    with open(path, "r", encoding="utf-8") as fh:
        text = fh.read()
    fields = _parse_licence_text(text)
    if not fields:
        raise ValueError("Licence file is empty or unreadable")
    return fields


def verify_licence(fields: dict) -> bool:
    """
    Verify the HMAC signature in fields["hmac"] against the other fields.
    Returns True if the signature is valid, False if tampered or missing.
    """
    stored = fields.get("hmac", "").strip().lower()
    if not stored:
        return False
    expected = _compute_hmac(fields)
    # Constant-time comparison to prevent timing attacks
    return _hmac.compare_digest(stored, expected)


def get_licence_status(app_dir: str = None) -> dict:
    """
    Locate, read, and verify the licence file. Returns a status dict:

    {
        "status":     "valid" | "lapsed" | "tampered" | "missing" | "malformed",
        "tier":       "full" | "payroll" | "invoices" | "cashbook" | None,
        "issued_to":  str | None,
        "contact":    str | None,
        "issue_date": str | None,
        "eval_expiry":str | None,      # ISO date string or None (permanent)
        "build":      str | None,
        "issued_by":  str | None,
        "path":       str | None,      # path of the licence file found
        "days_remaining": int | None,  # None if permanent or not valid
        "is_eval":    bool,            # True if eval_expiry is set
        "is_permanent": bool,          # True if no expiry (registered)
    }
    """
    result = {
        "status": "missing",
        "tier": None,
        "features": [],       # list of enabled feature strings, e.g. ["payroll"]
        "issued_to": None,
        "contact": None,
        "issue_date": None,
        "eval_expiry": None,
        "build": None,
        "issued_by": None,
        "licence_id": None,   # UUID4 — phone-home lookup key
        "path": None,
        "days_remaining": None,
        "is_eval": False,
        "is_permanent": False,
        "revoked": False,
        "maintenance_expires": None,   # ISO date or None (no expiry = permanent)
        "maintenance_active": True,    # False when maintenance_expires is in the past
        "lapsed_reason": None,         # "trial" | "subscription" when status is lapsed
        "subscription_days_remaining": None,  # days until maintenance_expires (paid licences)
    }

    path = find_licence_file(app_dir)
    if not path:
        return result

    result["path"] = path

    try:
        fields = read_licence(path)
    except Exception:
        result["status"] = "malformed"
        return result

    # Populate known fields
    result["issued_to"]   = fields.get("issued_to")
    result["contact"]     = fields.get("contact")
    result["issue_date"]  = fields.get("issue_date")
    result["eval_expiry"] = fields.get("eval_expiry") or None
    result["build"]       = fields.get("build")
    result["issued_by"]   = fields.get("issued_by")
    result["tier"]        = fields.get("tier", "full").lower()
    result["licence_id"]  = fields.get("licence_id") or None  # Milestone 2
    raw_features          = fields.get("features", "")
    result["features"]    = [f.strip().lower() for f in raw_features.split(",") if f.strip()]
    mx_str = fields.get("maintenance_expires") or None
    result["maintenance_expires"] = mx_str
    if mx_str:
        try:
            result["maintenance_active"] = date.today() <= date.fromisoformat(mx_str)
        except ValueError:
            result["maintenance_active"] = True  # malformed date — don't penalise user
    else:
        result["maintenance_active"] = True  # absent = no expiry

    # Verify signature
    if not verify_licence(fields):
        result["status"] = "tampered"
        return result

    # Check expiry
    expiry_str = result["eval_expiry"]
    if expiry_str:
        result["is_eval"] = True
        try:
            expiry = date.fromisoformat(expiry_str)
            today = date.today()
            remaining = (expiry - today).days
            result["days_remaining"] = remaining
            if today > expiry:
                result["status"] = "lapsed"
                result["lapsed_reason"] = "trial"
            else:
                result["status"] = "valid"
        except ValueError:
            result["status"] = "malformed"
    else:
        result["is_permanent"] = True
        result["status"] = "valid"
        # Paid licence with a subscription end date: once it passes, Pro features
        # lock (back to the free tier), the same as an ended trial. Store installs
        # can't hold back updates, so the subscription gates features instead.
        if mx_str and not result["maintenance_active"]:
            result["status"] = "lapsed"
            result["lapsed_reason"] = "subscription"
        elif mx_str:
            try:
                result["subscription_days_remaining"] = (
                    date.fromisoformat(mx_str) - date.today()).days
            except ValueError:
                pass

    return result


# ── Phone-home validation (Milestone 2) ──────────────────────────────────────

def validate_online(licence_id: str, server_url: str,
                    timeout: int = 4) -> tuple[bool, bool, str | None]:
    """
    POST licence_id to the validation server.
    Returns (revoked, online, lic_content).
    lic_content is the updated signed .lic text if the server has a newer
    version, or None if unchanged / offline.
    Returns (False, False, None) on any network error — never blocks the app.
    Uses only stdlib urllib — no extra dependencies.
    """
    try:
        import urllib.request
        import json as _json
        data = _json.dumps({"licence_id": licence_id}).encode("utf-8")
        req = urllib.request.Request(
            f"{server_url.rstrip('/')}/api/validate",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result = _json.loads(resp.read().decode("utf-8"))
            revoked     = bool(result.get("revoked", False))
            lic_content = result.get("lic_content") or None
            return revoked, True, lic_content
    except Exception:
        return False, False, None


# ── Update check (Milestone 2) ───────────────────────────────────────────────

def check_for_update(licence_id: str, current_version: str,
                     timeout: int = 4) -> dict:
    """
    POST to /api/check-update on the licence server.
    Returns a dict with keys:
        ok, update_available, latest_version, maintenance_active, entitled_to_update
    Returns a safe default (no update) on any network error — never blocks the app.
    """
    try:
        import urllib.request
        import json as _json
        data = _json.dumps({
            "licence_id":      licence_id,
            "current_version": current_version,
        }).encode("utf-8")
        req = urllib.request.Request(
            CHECK_UPDATE_URL,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result = _json.loads(resp.read().decode("utf-8"))
            return {
                "ok":                True,
                "update_available":  bool(result.get("update_available", False)),
                "latest_version":    result.get("latest_version", ""),
                "maintenance_active": bool(result.get("maintenance_active", True)),
                "entitled_to_update": bool(result.get("entitled_to_update", False)),
            }
    except Exception:
        return {"ok": False, "update_available": False, "latest_version": "",
                "maintenance_active": True, "entitled_to_update": False}


# ── Convenience helpers ───────────────────────────────────────────────────────

def is_valid(status: dict) -> bool:
    """Return True if the licence is present and not expired/tampered."""
    return status.get("status") == "valid"


def is_lapsed(status: dict) -> bool:
    """Return True if the licence was valid but the eval period has ended."""
    return status.get("status") == "lapsed"


def has_feature(status: dict, feature: str) -> bool:
    """Return True if the named feature is enabled on this licence."""
    if status.get("status") != "valid":
        return False
    f = feature.lower()
    # Payroll is a separately licensed module with its own pricing — never
    # auto-enabled by tier or trial. Requires explicit "payroll" in features.
    if f == "payroll":
        return "payroll" in status.get("features", [])
    # Active trial = full paid access for all non-payroll features
    if status.get("is_eval"):
        return True
    if f in status.get("features", []):
        return True
    # LAN is included in all valid paid licences
    if f == "lan":
        return True
    return False


def sign_licence(issued_to: str, contact: str, tier: str,
                 days: int | None = None, build: str = "alpha",
                 issued_by: str = "Dogbox Software",
                 licence_id: str | None = None,
                 issue_date: str | None = None,
                 eval_expiry_date: str | None = None,
                 features: str = "",
                 maintenance_expires: str | None = None) -> tuple[str, str]:
    """
    Generate and sign a licence file.
    Returns (licence_id, lic_content) where lic_content is the full .lic text.

    Expiry priority: eval_expiry_date (ISO string) > days from today > permanent.
    issue_date defaults to today if not supplied (preserve original on edits).
    licence_id is preserved if supplied (required for edits — same UUID).
    features is a comma-separated string of enabled features, e.g. "payroll".
    When non-empty it is included in the signed payload (V2 signing).
    When absent/empty it is omitted entirely (V1 signing — old licences remain valid).
    """
    import uuid as _uuid
    from datetime import timedelta

    today = date.today()
    if eval_expiry_date:
        expiry = eval_expiry_date
    elif days:
        expiry = str(today + timedelta(days=days))
    else:
        expiry = ""

    lic_id     = licence_id or str(_uuid.uuid4())
    issue_date = issue_date or str(today)
    feat       = features.strip().lower() if features else ""
    mx         = (maintenance_expires or "").strip()

    fields: dict = {
        "issued_to":  issued_to.strip(),
        "contact":    contact.strip() if contact else "",
        "issue_date": issue_date,
        "eval_expiry": expiry,
        "tier":       tier.strip().lower(),
        "build":      build.strip(),
        "issued_by":  issued_by,
        "licence_id": lic_id,
    }
    if feat:
        fields["features"] = feat
    if mx:
        fields["maintenance_expires"] = mx

    sig = _compute_hmac(fields)

    lines = [
        "# dbox Licence File",
        "# Do not modify — any change will invalidate this licence.",
        "#",
        f"issued_to   = {fields['issued_to']}",
        f"contact     = {fields['contact']}",
        f"issue_date  = {fields['issue_date']}",
        f"eval_expiry = {fields['eval_expiry']}",
        f"tier        = {fields['tier']}",
        f"build       = {fields['build']}",
        f"issued_by   = {fields['issued_by']}",
        f"licence_id  = {lic_id}",
    ]
    if feat:
        lines.append(f"features    = {feat}")
    if mx:
        lines.append(f"maintenance_expires = {mx}")
    lines.append(f"hmac        = {sig}")

    return lic_id, "\n".join(lines) + "\n"


def watermark_text(status: dict) -> str | None:
    """
    Return the diagonal watermark string to embed in PDFs, or None if clean.
    Called by every PDF renderer.
    Missing/lapsed licences are Free tier — pdf_branding_footer() handles those.
    Watermark is reserved for tampered, malformed, or revoked licences only.
    """
    s = status.get("status")
    if s in ("tampered", "malformed", "revoked"):
        return "Unregistered"
    return None


def pdf_footer_text(status: dict) -> str | None:
    """
    Return an extra bottom-of-page footer string for PDFs, or None.
    Previously a "subscription lapsed" notice; a lapsed subscription now drops
    to the free tier instead (which gets pdf_branding_footer), so this is
    always None. Kept so existing callers don't need changing.
    """
    return None


def pdf_branding_footer(status: dict) -> str | None:
    """
    Return the Dogbox branding footer text.
    Caller is responsible for suppressing it (e.g. Pro users who have opted out).
    """
    return "Created with Dogbox Accounting · dogboxsoftware.com.au"


def status_banner(status: dict) -> "tuple[str, str, bool] | None":
    """
    Return (message, severity, register_cta) for the in-app banner, or None.
    severity: "warn" | "danger"
    register_cta: True shows a "Register free" button in the banner.
    Called by the dashboard on load.
    """
    s = status.get("status")
    remaining = status.get("days_remaining")

    if s == "missing":
        return (
            "Not registered — you won't receive ATO or tax table updates. "
            "Register free to unlock a 6-month Pro trial and stay current.",
            "warn", True,
        )
    if s == "tampered":
        return ("Licence file has been modified and cannot be verified.  Contact Dogbox Software.", "danger", False)
    if s == "malformed":
        return ("Licence file could not be read.  Contact Dogbox Software.", "danger", False)
    if s == "revoked":
        return ("This licence has been revoked.  Contact Dogbox Software.", "danger", False)
    if s == "lapsed" and status.get("lapsed_reason") == "subscription":
        return (
            f"Your Pro subscription ended on {status.get('maintenance_expires')}.  "
            "Renew at dogboxsoftware.com.au to restore Pro features, or continue "
            "with the free tier.",
            "warn", False,
        )
    if s == "lapsed":
        return (
            "Your 6-month Pro trial has ended.  Subscribe at dogboxsoftware.com.au "
            "to restore full access, or continue with the free tier.",
            "warn", False,
        )
    if s == "valid" and remaining is not None:
        if remaining <= 7:
            return (f"Your Pro trial expires in {remaining} day{'s' if remaining != 1 else ''}.  Subscribe at dogboxsoftware.com.au to keep access.", "danger", False)
        if remaining <= 14:
            return (f"Your Pro trial expires in {remaining} days.  Subscribe at dogboxsoftware.com.au to keep access.", "warn", False)
    sub_left = status.get("subscription_days_remaining")
    if s == "valid" and sub_left is not None and sub_left <= 14:
        when = "today" if sub_left == 0 else f"in {sub_left} day{'s' if sub_left != 1 else ''}"
        return (f"Your Pro subscription ends {when}.  Renew at dogboxsoftware.com.au to keep Pro features.",
                "danger" if sub_left <= 7 else "warn", False)
    return None


# ── Licence event logging ─────────────────────────────────────────────────────

# Action constants — used in licence_log.action
ACTION_APP_START    = "APP_START"       # app launched
ACTION_FILE_OPEN    = "FILE_OPEN"       # company file opened
ACTION_FILE_NEW     = "FILE_NEW"        # new company file created
ACTION_EULA_ACCEPT  = "EULA_ACCEPT"     # user accepted EULA
ACTION_LIC_VALID    = "LIC_VALID"       # licence verified valid on startup
ACTION_LIC_LAPSED   = "LIC_LAPSED"      # licence detected as lapsed
ACTION_LIC_MISSING  = "LIC_MISSING"     # no licence file found
ACTION_LIC_TAMPERED = "LIC_TAMPERED"    # licence file failed HMAC check
ACTION_DEV_LOGIN    = "DEV_LOGIN"       # developer admin login (future)


def _os_info() -> str:
    """Return a short OS description string for logging."""
    try:
        import platform
        return f"{platform.system()} {platform.release()} ({platform.machine()})"
    except Exception:
        return "unknown"


def log_licence_event(db_path: str, action: str,
                      licence_status: dict | None = None,
                      detail: str | None = None,
                      app_version: str | None = None,
                      eula_version: str | None = None) -> None:
    """
    Write a row to licence_log in the given company file.

    db_path:         path to the .dbox file
    action:          one of the ACTION_* constants above
    licence_status:  dict returned by get_licence_status() — used to
                     populate licence_id and build columns
    detail:          optional free-text detail (e.g. company name on FILE_NEW)
    app_version:     APP_VERSION string from ui/app.py
    eula_version:    EULA version accepted (for EULA_ACCEPT events)

    Failures are silently swallowed — logging must never crash the app.
    """
    try:
        from core.database import get_connection
        conn = get_connection(db_path)

        lic    = licence_status or {}
        # Milestone 2: licence_id is the UUID from the .lic file.
        # Falls back to issued_to for licences issued before UUID was added.
        lic_id = lic.get("licence_id") or lic.get("issued_to") or ""
        build  = app_version or lic.get("build") or ""

        conn.execute("""INSERT INTO licence_log
            (action, licence_id, build, eula_version, os_info, detail)
            VALUES (?,?,?,?,?,?)""",
            (action, lic_id, build, eula_version or "",
             _os_info(), detail or ""))
        conn.commit()
        conn.close()
    except Exception:
        pass  # logging must never crash the app


def get_licence_log(db_path: str, limit: int = 100) -> list:
    """
    Return recent licence log entries, newest first.
    Each entry is a dict with keys:
        id, event_at, action, licence_id, build, eula_version, os_info, detail
    """
    try:
        from core.database import get_connection
        conn = get_connection(db_path)
        rows = conn.execute("""
            SELECT id, event_at, action, licence_id, build,
                   eula_version, os_info, detail
            FROM licence_log
            ORDER BY id DESC LIMIT ?""", (limit,)).fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except Exception:
        return []
