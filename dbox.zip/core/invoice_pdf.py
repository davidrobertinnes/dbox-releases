"""
dbox - Invoice PDF Generator
Professional A4 Tax Invoice — Australian GST compliant.
Logo left-justified, company details in header, theme-aware colours.
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.


import os
import tempfile
from io import BytesIO
from datetime import date as dt

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_RIGHT, TA_LEFT, TA_CENTER
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, Image, KeepTogether
)

from core.database import get_connection

# ── Fixed semantic colours ────────────────────────────────────────────────────
WHITE = colors.white
GREEN = colors.HexColor("#27ae60")
RED   = colors.HexColor("#e74c3c")
GREY  = colors.HexColor("#8892a4")

# ── Default doc theme — Ocean Light palette ───────────────────────────────────
DEFAULT_DOC_THEME = {
    "header_bg":          "#1A2E45",   # deep navy — header row bg
    "header_text":        "#ffffff",   # white text on header_bg
    "accent_bar":         "#185FA5",   # blue HR rule & borders
    "total_bar_bg":       "#1A2E45",   # grand total bar
    "total_bar_text":     "#ffffff",
    "rule_colour":        "#C8DCEE",   # blue-tinted grid lines
    "payment_box_bg":     "#EBF2FA",   # pale blue payment box
    "payment_box_border": "#185FA5",
    "label_colour":       "#6B8BAA",   # muted blue-grey labels
    "row_alt":            "#F0F6FB",   # subtle blue row stripe
    "body_text":          "#1A2E45",   # deep navy body text
    "dim_text":           "#6B8BAA",
}

W, H = A4
PAGE_W = W - 36*mm   # usable width (18mm margins each side)




def _make_watermark_callback(text):
    """
    Returns a ReportLab canvas callback that draws a diagonal watermark
    across every page. Pass as onFirstPage= and onLaterPages= to doc.build().
    text=None means no watermark is drawn.
    """
    def _draw(canvas, doc):
        if not text:
            return
        from reportlab.lib import colors
        from reportlab.lib.units import mm
        canvas.saveState()
        canvas.setFont("Helvetica-Bold", 52)
        canvas.setFillColor(colors.Color(0.35, 0.35, 0.35, alpha=0.30))
        w, h = canvas._pagesize
        canvas.translate(w / 2, h / 2)
        canvas.rotate(45)
        canvas.setStrokeColor(colors.Color(0.35, 0.35, 0.35, alpha=0.0))
        canvas.drawCentredString(0, 0, text)
        canvas.restoreState()
    return _draw

def _c(hex_colour):
    return colors.HexColor(str(hex_colour))


def _resolve_theme(doc_theme):
    merged = dict(DEFAULT_DOC_THEME)
    if doc_theme:
        merged.update(doc_theme)
    return merged


def _s(th):
    """Build all paragraph styles from theme dict."""
    hdr  = th["header_bg"]
    acc  = th["accent_bar"]
    lbl  = th["label_colour"]
    body = th["body_text"]
    dim  = th["dim_text"]
    htxt = th["header_text"]
    pbdr = th["payment_box_border"]
    return {
        "co_name":    ParagraphStyle("co_name",  fontName="Helvetica-Bold",
                      fontSize=18, textColor=_c(hdr), leading=22),
        "co_detail":  ParagraphStyle("co_detail", fontName="Helvetica",
                      fontSize=8, textColor=_c(dim), leading=11),
        "co_detail_b":ParagraphStyle("co_detail_b", fontName="Helvetica-Bold",
                      fontSize=9, textColor=_c(body), leading=12),
        "doc_type":   ParagraphStyle("doc_type",  fontName="Helvetica-Bold",
                      fontSize=22, textColor=_c(acc), leading=26,
                      alignment=TA_RIGHT),
        "h3":         ParagraphStyle("h3", fontName="Helvetica-Bold",
                      fontSize=9, textColor=_c(hdr), leading=12, spaceAfter=2),
        "label":      ParagraphStyle("label", fontName="Helvetica-Bold",
                      fontSize=7, textColor=_c(lbl), leading=10, spaceAfter=1,
                      textTransform="uppercase"),
        "body":       ParagraphStyle("body", fontName="Helvetica",
                      fontSize=9, textColor=_c(body), leading=13),
        "body_b":     ParagraphStyle("body_b", fontName="Helvetica-Bold",
                      fontSize=9, textColor=_c(body), leading=13),
        "small":      ParagraphStyle("small", fontName="Helvetica",
                      fontSize=8, textColor=_c(lbl), leading=11),
        "small_b":    ParagraphStyle("small_b", fontName="Helvetica-Bold",
                      fontSize=8, textColor=_c(dim), leading=11),
        "right":      ParagraphStyle("right", fontName="Helvetica",
                      fontSize=9, textColor=_c(body), leading=13,
                      alignment=TA_RIGHT),
        "right_b":    ParagraphStyle("right_b", fontName="Helvetica-Bold",
                      fontSize=9, textColor=_c(body), leading=13,
                      alignment=TA_RIGHT),
        "ctr":        ParagraphStyle("ctr", fontName="Helvetica",
                      fontSize=8, textColor=_c(lbl), leading=11,
                      alignment=TA_CENTER),
        "tot_lbl":    ParagraphStyle("tot_lbl", fontName="Helvetica-Bold",
                      fontSize=10, textColor=_c(htxt), leading=14,
                      alignment=TA_RIGHT),
        "tot_val":    ParagraphStyle("tot_val", fontName="Helvetica-Bold",
                      fontSize=14, textColor=_c(htxt), leading=18,
                      alignment=TA_RIGHT),
        "stamp_paid": ParagraphStyle("stamp_paid", fontName="Helvetica-Bold",
                      fontSize=26, textColor=GREEN, leading=30),
        "stamp_od":   ParagraphStyle("stamp_od", fontName="Helvetica-Bold",
                      fontSize=26, textColor=RED, leading=30),
        "pmt_head":   ParagraphStyle("pmt_head", fontName="Helvetica-Bold",
                      fontSize=9, textColor=_c(pbdr), leading=13),
        "pmt_body":   ParagraphStyle("pmt_body", fontName="Helvetica",
                      fontSize=9, textColor=_c(dim), leading=13),
        "tbl_hdr":    ParagraphStyle("tbl_hdr", fontName="Helvetica-Bold",
                      fontSize=7, textColor=_c(htxt), leading=10,
                      textTransform="uppercase"),
        "tbl_hdr_r":  ParagraphStyle("tbl_hdr_r", fontName="Helvetica-Bold",
                      fontSize=7, textColor=_c(htxt), leading=10,
                      alignment=TA_RIGHT, textTransform="uppercase"),
        "tbl_hdr_c":  ParagraphStyle("tbl_hdr_c", fontName="Helvetica-Bold",
                      fontSize=7, textColor=_c(htxt), leading=10,
                      alignment=TA_CENTER, textTransform="uppercase"),
        "footer":     ParagraphStyle("footer", fontName="Helvetica",
                      fontSize=7.5, textColor=_c(lbl), leading=10,
                      alignment=TA_CENTER),
    }


def _fmt(v):
    try:
        return f"${float(v):,.2f}"
    except Exception:
        return "$0.00"


def _logo_image(logo_path, max_w=60*mm, max_h=22*mm):
    if not logo_path or not os.path.exists(logo_path):
        return None
    try:
        img = Image(logo_path)
        ratio = min(max_w / img.imageWidth, max_h / img.imageHeight)
        img.drawWidth  = img.imageWidth  * ratio
        img.drawHeight = img.imageHeight * ratio
        img.hAlign = 'LEFT'
        return img
    except Exception:
        return None


def _logo_from_co(co, max_w=60*mm, max_h=22*mm):
    """Load logo from DB blob (web upload) or fall back to file path (desktop)."""
    blob = co.get("logo_blob")
    if blob:
        try:
            img = Image(BytesIO(bytes(blob)))
            ratio = min(max_w / img.imageWidth, max_h / img.imageHeight)
            img.drawWidth  = img.imageWidth  * ratio
            img.drawHeight = img.imageHeight * ratio
            img.hAlign = 'LEFT'
            return img
        except Exception:
            pass
    return _logo_image(co.get("logo_path"), max_w, max_h)


def _load_doc_theme(co):
    """Load saved doc theme from company row, fallback to defaults."""
    try:
        import json
        raw = co.get("doc_theme")
        if raw:
            return json.loads(raw)
    except Exception:
        pass
    return None


def ui_theme_to_doc_theme(ui_colours):
    """
    Derive a PDF document theme from a UI colour scheme dict.
    Maps ACCENT, HEADER, PANEL, TEXT, TEXT_DIM, BORDER, ROW_ALT
    to the PDF theme slots used by generate_invoice_pdf.
    """
    accent  = ui_colours.get("ACCENT",  "#185FA5")
    header  = ui_colours.get("HEADER",  "#1A2E45")
    panel   = ui_colours.get("PANEL",   "#ffffff")
    text    = ui_colours.get("TEXT",    "#1A2E45")
    dim     = ui_colours.get("TEXT_DIM","#6B8BAA")
    border  = ui_colours.get("BORDER",  "#C8DCEE")
    row_alt = ui_colours.get("ROW_ALT", "#F0F6FB")

    def _lum(hex_c):
        h = hex_c.lstrip("#")
        r, g, b = int(h[0:2],16)/255, int(h[2:4],16)/255, int(h[4:6],16)/255
        return 0.299*r + 0.587*g + 0.114*b

    header_text = "#ffffff" if _lum(header) < 0.5 else "#1a1a1a"
    return {
        "header_bg":          header,
        "header_text":        header_text,
        "accent_bar":         accent,
        "total_bar_bg":       header,
        "total_bar_text":     header_text,
        "rule_colour":        border,
        "payment_box_bg":     panel,
        "payment_box_border": accent,
        "label_colour":       dim,
        "row_alt":            row_alt,
        "body_text":          text,
        "dim_text":           dim,
    }


def _build_header(story, co, doc_type_text, s, th):
    """
    Shared header builder used by all customer-facing PDFs.
    Left: logo (if set) + company name + ABN + address + contact
    Right: document type label (TAX INVOICE / QUOTE / etc.)
    Below: accent HR rule
    """
    co_name  = co.get("name") or "Your Company"
    co_abn   = co.get("abn") or ""
    co_addr  = ", ".join(filter(None, [co.get("address"), co.get("city"),
                                       co.get("state"), co.get("postcode")]))
    co_phone = co.get("phone") or ""
    co_email = co.get("email") or ""
    co_web   = co.get("website") or ""
    logo_img = _logo_from_co(co)

    # Left cell: logo (if any) stacked above company details
    left_elems = []
    if logo_img:
        left_elems.append(logo_img)
        left_elems.append(Spacer(1, 2*mm))
    left_elems.append(Paragraph(co_name, s["co_name"] if not logo_img
                                 else s["co_detail_b"]))
    if co_abn:
        left_elems.append(Paragraph(f"ABN: {co_abn}", s["co_detail"]))
    if co_addr:
        left_elems.append(Paragraph(co_addr, s["co_detail"]))
    contact_line = "  |  ".join(filter(None, [
        (f"T: {co_phone}" if co_phone else ""),
        (f"E: {co_email}" if co_email else ""),
        co_web,
    ]))
    if contact_line:
        left_elems.append(Paragraph(contact_line, s["co_detail"]))

    # Right cell: document type
    right_elem = Paragraph(doc_type_text, s["doc_type"])

    hdr_tbl = Table([[left_elems, right_elem]],
                    colWidths=[PAGE_W * 0.6, PAGE_W * 0.4])
    hdr_tbl.setStyle(TableStyle([
        ("VALIGN",        (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING",   (0, 0), (-1, -1), 0),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 0),
        ("TOPPADDING",    (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.append(hdr_tbl)
    story.append(HRFlowable(width="100%", thickness=2,
                             color=_c(th["accent_bar"]),
                             spaceAfter=4*mm, spaceBefore=2*mm))
    return co_name, co_abn, co_addr, co_phone, co_email, co_web


def _build_from_block(co_name, co_abn, co_addr, co_phone, co_email, co_web,
                      logo_img, s):
    """Build the FROM column elements for the address table."""
    elems = [Paragraph("From", s["label"])]
    elems.append(Paragraph(co_name, s["body_b"]))
    if co_abn:
        elems.append(Paragraph(f"ABN: {co_abn}", s["body"]))
    if co_addr:
        elems.append(Paragraph(co_addr, s["body"]))
    for val, prefix in [(co_phone, "T: "), (co_email, "E: "), (co_web, "")]:
        if val:
            elems.append(Paragraph(f"{prefix}{val}", s["small"]))
    return elems


def _build_meta_table(rows, th, status_row=None, status_colour=None):
    """Build a themed key-value meta table (Invoice No, Date, etc.)."""
    tbl = Table(rows, colWidths=[28*mm, 44*mm])
    style = [
        ("FONTNAME",  (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME",  (1, 0), (1, -1), "Helvetica"),
        ("FONTSIZE",  (0, 0), (-1, -1), 9),
        ("TEXTCOLOR", (0, 0), (0, -1), _c(th["label_colour"])),
        ("TEXTCOLOR", (1, 0), (1, -1), _c(th["body_text"])),
        ("ROWBACKGROUNDS", (0, 0), (-1, -1), [WHITE, _c(th["row_alt"])]),
        ("TOPPADDING",    (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING",   (0, 0), (-1, -1), 6),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 6),
        ("BOX",  (0, 0), (-1, -1), 0.5, _c(th["rule_colour"])),
        ("GRID", (0, 0), (-1, -1), 0.25, _c(th["rule_colour"])),
    ]
    if status_row is not None and status_colour is not None:
        style += [
            ("TEXTCOLOR", (1, status_row), (1, status_row), status_colour),
            ("FONTNAME",  (1, status_row), (1, status_row), "Helvetica-Bold"),
        ]
    tbl.setStyle(TableStyle(style))
    return tbl


def _build_line_table(tbl_data, col_widths, th):
    """Shared line-items table builder."""
    tbl = Table(tbl_data, colWidths=col_widths, repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, 0), _c(th["header_bg"])),
        ("TOPPADDING",    (0, 0), (-1, 0), 6),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 6),
        ("LEFTPADDING",   (0, 0), (-1, 0), 6),
        ("RIGHTPADDING",  (0, 0), (-1, 0), 6),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, _c(th["row_alt"])]),
        ("FONTNAME",      (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE",      (0, 1), (-1, -1), 9),
        ("TOPPADDING",    (0, 1), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 5),
        ("LEFTPADDING",   (0, 1), (-1, -1), 6),
        ("RIGHTPADDING",  (0, 1), (-1, -1), 6),
        ("VALIGN",  (0, 0), (-1, -1), "MIDDLE"),
        ("GRID",    (0, 0), (-1, -1), 0.25, _c(th["rule_colour"])),
    ]))
    return tbl


def _build_totals_block(sub, gst, total, paid, th, s,
                         grand_label="TOTAL DUE"):
    """Build the subtotal / GST / grand-total block."""
    rows = [
        [Paragraph("Subtotal (ex GST)", s["small"]),
         Paragraph(_fmt(sub), s["right"])],
        [Paragraph("GST (10%)", s["small"]),
         Paragraph(_fmt(gst), s["right"])],
        [Paragraph("Invoice Total", s["small"]),
         Paragraph(_fmt(total), s["right"])],
    ]
    if paid > 0:
        rows.append([Paragraph("Amount Paid", s["small"]),
                     Paragraph(f"({_fmt(paid)})", s["right"])])

    sub_tbl = Table(rows, colWidths=[40*mm, 30*mm])
    sub_tbl.setStyle(TableStyle([
        ("TOPPADDING",    (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("ALIGN",  (1, 0), (1, -1), "RIGHT"),
        ("LINEBELOW", (0, -1), (-1, -1), 0.5, _c(th["rule_colour"])),
        ("FONTNAME", (0, 2), (-1, 2), "Helvetica-Bold"),
    ]))

    grand_val = round(total - paid, 2)
    grand_tbl = Table(
        [[Paragraph(grand_label, s["tot_lbl"]),
          Paragraph(_fmt(grand_val), s["tot_val"])]],
        colWidths=[40*mm, 30*mm])
    grand_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, -1), _c(th["total_bar_bg"])),
        ("TOPPADDING",    (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("LEFTPADDING",   (0, 0), (-1, -1), 8),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 8),
    ]))
    return Table([[sub_tbl], [grand_tbl]], colWidths=[70*mm])


def _build_footer(story, co_name, co_abn, co_email, co_phone, footnote, th, s):
    story.append(Spacer(1, 5*mm))
    story.append(HRFlowable(width="100%", thickness=0.5,
                             color=_c(th["rule_colour"]), spaceAfter=2*mm))
    parts = [co_name]
    if co_abn:   parts.append(f"ABN: {co_abn}")
    if co_email: parts.append(co_email)
    if co_phone: parts.append(co_phone)
    story.append(Paragraph("  |  ".join(parts), s["footer"]))
    story.append(Paragraph(footnote, s["footer"]))


# ══════════════════════════════════════════════════════════════════════════════
# INVOICE
# ══════════════════════════════════════════════════════════════════════════════

def generate_invoice_pdf(db_path, invoice_id, output_path=None, doc_theme=None, watermark=None):
    _wm_text = watermark
    conn = get_connection(db_path)
    inv = conn.execute("""
        SELECT i.*, c.name as cname, c.abn as cabn, c.email as cemail,
               c.address as caddress, c.city as ccity,
               c.state as cstate, c.postcode as cpostcode, c.phone as cphone
        FROM invoices i JOIN contacts c ON i.contact_id=c.id
        WHERE i.id=?""", (invoice_id,)).fetchone()
    lines = conn.execute("""
        SELECT il.*, a.name as aname
        FROM invoice_lines il LEFT JOIN accounts a ON il.account_id=a.id
        WHERE il.invoice_id=? ORDER BY il.id""", (invoice_id,)).fetchall()
    company = conn.execute("SELECT * FROM company").fetchone()
    conn.close()

    if not inv:
        raise ValueError(f"Invoice {invoice_id} not found")

    inv   = dict(inv)
    lines = [dict(l) for l in lines]
    co    = dict(company) if company else {}

    if doc_theme is None:
        doc_theme = _load_doc_theme(co)
    # If still no stored doc_theme, derive from current UI colour scheme
    if doc_theme is None:
        try:
            from ui.shared import load_theme, THEMES, THEME
            theme_name, custom = load_theme(db_path)
            ui_colours = dict(THEMES.get(theme_name, THEME))
            if custom:
                ui_colours.update(custom)
            doc_theme = ui_theme_to_doc_theme(ui_colours)
        except Exception:
            pass   # Fall through to DEFAULT_DOC_THEME
    th = _resolve_theme(doc_theme)
    s  = _s(th)

    if output_path is None:
        output_path = os.path.join(tempfile.mkdtemp(),
                                   f"{inv['invoice_number']}.pdf")

    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        leftMargin=18*mm, rightMargin=18*mm,
        topMargin=14*mm, bottomMargin=14*mm,
        title=f"Tax Invoice {inv['invoice_number']}",
        author=co.get("name", ""),
    )
    story = []

    # ── Header ────────────────────────────────────────────────────────────────
    co_name, co_abn, co_addr, co_phone, co_email, co_web = \
        _build_header(story, co, "TAX INVOICE", s, th)

    # ── Address block ─────────────────────────────────────────────────────────
    today_str  = str(dt.today())
    is_overdue = (inv["status"] not in ("Paid", "Void", "Draft") and
                  inv["due_date"] < today_str)
    status_col = (GREEN if inv["status"] == "Paid" else
                  RED   if is_overdue            else
                  GREY  if inv["status"] == "Void" else
                  _c(th["header_bg"]))

    bill_elems = [Paragraph("Bill To", s["label"]),
                  Paragraph(inv["cname"], s["body_b"])]
    if inv.get("cabn"):
        bill_elems.append(Paragraph(f"ABN: {inv['cabn']}", s["body"]))
    cust_addr = ", ".join(filter(None, [inv.get("caddress"), inv.get("ccity"),
                                         inv.get("cstate"), inv.get("cpostcode")]))
    if cust_addr:
        bill_elems.append(Paragraph(cust_addr, s["body"]))
    if inv.get("cemail"):
        bill_elems.append(Paragraph(inv["cemail"], s["small"]))

    left_col = bill_elems

    meta_rows = [
        ["Invoice No",   inv["invoice_number"]],
        ["Invoice Date", inv["invoice_date"]],
        ["Due Date",     inv["due_date"]],
        ["Status",       inv["status"]],
    ]
    if inv["amount_paid"] > 0:
        meta_rows.append(["Amount Paid", _fmt(inv["amount_paid"])])

    meta_tbl = _build_meta_table(meta_rows, th,
                                  status_row=3, status_colour=status_col)
    addr_tbl = Table([[left_col, meta_tbl]],
                     colWidths=[PAGE_W * 0.55, PAGE_W * 0.45])
    addr_tbl.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                                   ("LEFTPADDING",  (0, 0), (-1, -1), 0),
                                   ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    story.append(addr_tbl)
    story.append(Spacer(1, 5*mm))

    # ── Line items ────────────────────────────────────────────────────────────
    cw = [PAGE_W * 0.40, PAGE_W * 0.09, PAGE_W * 0.14,
          PAGE_W * 0.08, PAGE_W * 0.12, PAGE_W * 0.17]
    tbl_data = [[
        Paragraph("Description",  s["tbl_hdr"]),
        Paragraph("Qty",          s["tbl_hdr_r"]),
        Paragraph("Unit Price",   s["tbl_hdr_r"]),
        Paragraph("Tax",          s["tbl_hdr_c"]),
        Paragraph("GST",          s["tbl_hdr_r"]),
        Paragraph("Amount",       s["tbl_hdr_r"]),
    ]]
    span_cmds = []
    for row_idx, l in enumerate(lines, start=1):
        if l.get("line_type", "item") == "comment":
            tbl_data.append([
                Paragraph(l["description"],
                          ParagraphStyle("cmt", parent=s["body"],
                                         textColor=_c(th["dim_text"]),
                                         fontName="Helvetica-Oblique")),
                "", "", "", "", "",
            ])
            span_cmds.append(("SPAN", (0, row_idx), (-1, row_idx)))
        else:
            tbl_data.append([
                Paragraph(l["description"], s["body"]),
                Paragraph(f"{l['quantity']:g}", s["right"]),
                Paragraph(_fmt(l["unit_price"]), s["right"]),
                Paragraph(l.get("tax_code", "GST"),
                          ParagraphStyle("tc", fontName="Helvetica",
                                         fontSize=9, alignment=TA_CENTER)),
                Paragraph(_fmt(l["gst_amount"]), s["right"]),
                Paragraph(_fmt(l["line_total"]), s["right_b"]),
            ])
    tbl = _build_line_table(tbl_data, cw, th)
    if span_cmds:
        tbl.setStyle(TableStyle(span_cmds))
    story.append(tbl)
    story.append(Spacer(1, 4*mm))

    # ── Totals + stamp ────────────────────────────────────────────────────────
    sub   = inv["subtotal"]
    gst   = inv["gst_total"]
    total = inv["total"]
    paid  = inv["amount_paid"]

    grand_lbl = ("AMOUNT DUE" if paid > 0 and (total - paid) > 0 else
                 "PAID IN FULL" if paid > 0 else "TOTAL DUE")
    totals = _build_totals_block(sub, gst, total, paid, th, s, grand_lbl)

    stamp = Spacer(1, 1)
    if inv["status"] == "Paid":
        stamp = Paragraph("PAID", s["stamp_paid"])
    elif is_overdue:
        stamp = Paragraph("OVERDUE", s["stamp_od"])

    summary = Table([[stamp, totals]],
                    colWidths=[PAGE_W * 0.57, PAGE_W * 0.43])
    summary.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN",  (1, 0), (1, 0),  "RIGHT"),
        ("LEFTPADDING",  (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))
    story.append(summary)

    # ── Payment instructions ──────────────────────────────────────────────────
    pmt = (inv.get("payment_instructions") or co.get("default_payment_instructions") or "").strip()
    if pmt:
        story.append(Spacer(1, 5*mm))
        pmt_tbl = Table(
            [[Paragraph("Payment Instructions", s["pmt_head"]),
              Paragraph(pmt.replace("\n", "<br/>"), s["pmt_body"])]],
            colWidths=[38*mm, PAGE_W - 38*mm])
        pmt_tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0, 0), (-1, -1), _c(th["payment_box_bg"])),
            ("TOPPADDING",    (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ("LEFTPADDING",   (0, 0), (-1, -1), 10),
            ("RIGHTPADDING",  (0, 0), (-1, -1), 10),
            ("VALIGN",  (0, 0), (-1, -1), "TOP"),
            ("BOX",     (0, 0), (-1, -1), 1, _c(th["payment_box_border"])),
            ("LINEBEFORE", (1, 0), (1, 0), 0.5, _c(th["payment_box_border"])),
        ]))
        story.append(KeepTogether(pmt_tbl))

    # ── Notes ──────────────────────────────────────────────────────────────────
    notes = (inv.get("notes") or "").strip()
    if notes:
        story.append(Spacer(1, 4*mm))
        story.append(HRFlowable(width="100%", thickness=0.5,
                                 color=_c(th["rule_colour"]), spaceAfter=2*mm))
        story.append(Paragraph("Notes", s["label"]))
        story.append(Paragraph(notes.replace("\n", "<br/>"), s["body"]))

    # ── Footer ────────────────────────────────────────────────────────────────
    _build_footer(story, co_name, co_abn, co_email, co_phone,
                  "This document is a Tax Invoice for GST purposes. "
                  "Please retain for your records.", th, s)

    doc.build(story, onFirstPage=_make_watermark_callback(_wm_text), onLaterPages=_make_watermark_callback(_wm_text))
    return output_path
