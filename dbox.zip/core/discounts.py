"""
core/discounts.py — Discount authorisation system.

discount_limits table: per-role maximum discount percentage.
When a user sells an item below its standard unit_price, the discount
percentage is computed and checked against their role's ceiling.

Roles and sensible defaults:
  Staff      → 5%   (small courtesy discount only)
  Accountant → 15%  (reasonable operational discount)
  Admin      → 100% (no ceiling — full authority)
  ReadOnly   → 0%   (read-only users can't create invoices anyway)

If no record exists for a role, that role's ceiling is treated as 0%.
A line is flagged if:
  discount_pct > role_ceiling
  where discount_pct = (list_price - line_price) / list_price * 100
  and list_price = item.unit_price (the catalogue price).
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from core.database import get_connection

ROLE_DEFAULTS = {
    "Admin":       100.0,
    "Accountant":   15.0,
    "Staff":         5.0,
    "ReadOnly":      0.0,
}


def migrate_discount_limits(conn):
    """Create discount_limits table. Safe to call on existing DBs."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS discount_limits (
            role     TEXT PRIMARY KEY,
            max_pct  REAL NOT NULL DEFAULT 0
        )
    """)
    # Seed defaults if table was just created / rows missing
    for role, pct in ROLE_DEFAULTS.items():
        conn.execute("""
            INSERT OR IGNORE INTO discount_limits (role, max_pct)
            VALUES (?, ?)
        """, (role, pct))


def get_discount_limits(db_path) -> dict:
    """Return {role: max_pct} for all roles."""
    conn = get_connection(db_path)
    rows = conn.execute("SELECT role, max_pct FROM discount_limits").fetchall()
    conn.close()
    result = dict(ROLE_DEFAULTS)   # start with defaults
    for r in rows:
        result[r["role"]] = float(r["max_pct"])
    return result


def save_discount_limits(db_path, limits: dict):
    """
    Persist {role: max_pct} mappings.
    Clamps values to 0–100.
    """
    conn = get_connection(db_path)
    for role, pct in limits.items():
        pct = max(0.0, min(100.0, float(pct)))
        conn.execute("""
            INSERT INTO discount_limits (role, max_pct) VALUES (?, ?)
            ON CONFLICT(role) DO UPDATE SET max_pct = excluded.max_pct
        """, (role, pct))
    conn.commit()
    conn.close()


def get_role_ceiling(db_path, role: str) -> float:
    """Return the max discount % for a role. Falls back to ROLE_DEFAULTS."""
    limits = get_discount_limits(db_path)
    return limits.get(role, ROLE_DEFAULTS.get(role, 0.0))


def compute_discount_pct(list_price: float, line_price: float) -> float:
    """
    Compute discount % relative to list_price.
    Returns 0 if list_price <= 0 or line_price >= list_price.
    """
    if list_price <= 0 or line_price >= list_price:
        return 0.0
    return round((list_price - line_price) / list_price * 100, 4)


def check_line_discounts(db_path, lines: list, role: str) -> list:
    """
    Check invoice lines for discount violations.
    Only checks lines with item_id (catalogue items have a known list price).

    Returns a list of violation dicts:
      {item_id, item_name, item_code, list_price, line_price,
       discount_pct, ceiling, excess_pct}
    Empty list = all lines within ceiling.
    """
    ceiling = get_role_ceiling(db_path, role)
    violations = []

    conn = get_connection(db_path)
    for l in lines:
        item_id = l.get("item_id")
        if not item_id:
            continue
        line_price = float(l.get("unit_price") or 0)
        row = conn.execute(
            "SELECT id, code, name, unit_price FROM items WHERE id=?",
            (item_id,)).fetchone()
        if not row:
            continue
        list_price = float(row["unit_price"] or 0)
        disc_pct = compute_discount_pct(list_price, line_price)
        if disc_pct > ceiling:
            violations.append({
                "item_id":     item_id,
                "item_name":   row["name"],
                "item_code":   row["code"] or "",
                "list_price":  list_price,
                "line_price":  line_price,
                "discount_pct": disc_pct,
                "ceiling":     ceiling,
                "excess_pct":  round(disc_pct - ceiling, 2),
            })
    conn.close()
    return violations


def log_discount_override(db_path, user_id, username, invoice_id, violations,
                           approved_by=None):
    """
    Write an audit log entry for a discount override.
    Called after the user/admin acknowledges the warning.
    """
    import json
    conn = get_connection(db_path)
    detail = json.dumps({
        "approved_by": approved_by or username,
        "violations": violations,
    })
    conn.execute("""
        INSERT INTO audit_log (user_id, username, action, target_type,
                               target_id, detail)
        VALUES (?, ?, 'DISCOUNT_OVERRIDE', 'invoice', ?, ?)
    """, (user_id, username, invoice_id, detail))
    conn.commit()
    conn.close()
