# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Accounting — ABA File Generator
================================
Produces an Australian Banking Association (ABA) file (also called a Direct Entry
or DE file) for bulk electronic payment uploads to any Australian bank.

Format spec: APCA DE Standard 2, published by Australian Payments Clearing Association.
  - Fixed-width 120-character records
  - Record Type 0: File header (1 record)
  - Record Type 1: Detail records (1 per payment)
  - Record Type 7: File total / trailer (1 record)

Transaction codes:
  13  Externally initiated debit  (we are debiting someone else — not used here)
  50  Externally initiated credit  (supplier payment — most common)
  51  Australian Government Security interest
  52  Family allowance
  53  Pay
  54  Pension
  55  Allotment
  56  Dividend
  57  Debenture / note interest
"""


import re
from datetime import date as _date
from core.database import get_connection


# ── Validation helpers ────────────────────────────────────────────────────────

def _clean_bsb(raw: str) -> str:
    """Normalise BSB to 'NNN-NNN' format. Raises ValueError if invalid."""
    digits = re.sub(r"[^0-9]", "", raw or "")
    if len(digits) != 6:
        raise ValueError(f"BSB must be 6 digits, got: {raw!r}")
    return f"{digits[:3]}-{digits[3:]}"


def _clean_account(raw: str) -> str:
    """Strip spaces/hyphens, max 9 chars (right-justified in record)."""
    acc = re.sub(r"[^0-9]", "", raw or "")
    if not acc:
        raise ValueError(f"Account number is empty: {raw!r}")
    if len(acc) > 9:
        raise ValueError(f"Account number too long (max 9 digits): {raw!r}")
    return acc


def _alpha(s: str, n: int) -> str:
    """Left-justified, space-padded, max n characters, ASCII only."""
    safe = re.sub(r"[^A-Za-z0-9 &',-./]", " ", str(s or ""))
    return safe[:n].ljust(n)


def _right(s: str, n: int) -> str:
    """Right-justified, space-padded, max n characters."""
    safe = re.sub(r"[^A-Za-z0-9 &',-./]", " ", str(s or ""))
    return safe[:n].rjust(n)


def _numeric(v, n: int) -> str:
    """Zero-padded integer string of width n. v is a float in dollars."""
    cents = round(float(v) * 100)
    s = str(abs(int(cents)))
    if len(s) > n:
        raise ValueError(f"Amount {v} overflows {n}-digit field")
    return s.zfill(n)


# ── Record builders ───────────────────────────────────────────────────────────

def _record_0(
    reel_sequence:     str,   # 2 chars e.g. "01"
    financial_inst:    str,   # 3 chars  e.g. "ANZ"
    user_preferred_id: str,   # 26 chars (company name on bank statement)
    user_id:           str,   # 6 digits  APCA user ID (use "999999" if not registered)
    description:       str,   # 12 chars  e.g. "PAYROLL"
    process_date:      str,   # DDMMYY
) -> str:
    """120-char Type-0 (header) record."""
    assert len(process_date) == 6, "process_date must be DDMMYY"
    rec = (
        "0"                              # record type     pos  1
        + " " * 17                       # blank           pos  2-18
        + reel_sequence[:2].rjust(2)     # reel sequence   pos 19-20
        + _alpha(financial_inst, 3)      # bank code       pos 21-23
        + " " * 7                        # blank           pos 24-30
        + _alpha(user_preferred_id, 26)  # user name       pos 31-56
        + str(user_id)[:6].rjust(6, "0")# user id         pos 57-62
        + _alpha(description, 12)        # description     pos 63-74
        + process_date                   # date DDMMYY     pos 75-80
        + " " * 40                       # blank           pos 81-120
    )
    assert len(rec) == 120, f"Header record length {len(rec)} != 120"
    return rec


def _record_1(
    bsb:              str,   # "NNN-NNN"
    account:          str,   # up to 9 chars (right-justified)
    indicator:        str,   # " " = no withholding, "W"/"X"/"Y" = withheld
    txn_code:         str,   # 2 chars  "50" = credit, "13" = debit
    amount_cents:     int,   # integer, no decimal
    account_name:     str,   # 32 chars beneficiary name
    lodgement_ref:    str,   # 18 chars  appears on recipient statement
    trace_bsb:        str,   # "NNN-NNN"  our bank BSB
    trace_account:    str,   # 9 chars   our bank account
    remitter_name:    str,   # 16 chars  our name on recipient's statement
    withholding_tax:  int,   # 8 chars amount in cents (0 if none)
) -> str:
    """120-char Type-1 (detail) record."""
    rec = (
        "1"                                        # record type     pos   1
        + bsb[:7]                                  # dest BSB        pos  2-8
        + _right(account, 9)                       # dest account    pos  9-17
        + (indicator or " ")[0]                    # indicator       pos 18
        + txn_code[:2]                             # txn code        pos 19-20
        + str(amount_cents).zfill(10)              # amount cents    pos 21-30
        + _alpha(account_name, 32)                 # account name    pos 31-62
        + _alpha(lodgement_ref, 18)                # lodgement ref   pos 63-80
        + trace_bsb[:7]                            # trace BSB       pos 81-87
        + _right(trace_account, 9)                 # trace account   pos 88-96
        + _alpha(remitter_name, 16)                # remitter        pos 97-112
        + str(abs(withholding_tax)).zfill(8)       # withhold tax    pos 113-120
    )
    assert len(rec) == 120, f"Detail record length {len(rec)} != 120"
    return rec


def _record_7(
    bsb_total:        str,   # "999-999" filler
    net_total_cents:  int,   # file net total
    credit_total_cents: int,
    debit_total_cents:  int,
    record_count:     int,   # number of type-1 records
) -> str:
    """120-char Type-7 (trailer) record."""
    rec = (
        "7"                                         # record type     pos   1
        + "999-999"                                 # BSB filler      pos  2-8
        + " " * 12                                  # blank           pos  9-20
        + str(abs(net_total_cents)).zfill(10)       # net total       pos 21-30
        + str(abs(credit_total_cents)).zfill(10)    # credit total    pos 31-40
        + str(abs(debit_total_cents)).zfill(10)     # debit total     pos 41-50
        + " " * 24                                  # blank           pos 51-74
        + str(record_count).zfill(6)                # count           pos 75-80
        + " " * 40                                  # blank           pos 81-120
    )
    assert len(rec) == 120, f"Trailer record length {len(rec)} != 120"
    return rec


# ── Public API ────────────────────────────────────────────────────────────────

class ABAError(ValueError):
    """Raised when ABA generation fails due to missing/invalid data."""
    pass


def get_aba_settings(db_path: str) -> dict:
    """
    Load ABA configuration from the company + bank account records.
    Returns a dict with keys:
      user_id, user_name, description, financial_inst,
      bsb, account_number, account_name
    """
    conn = get_connection(db_path)
    co = conn.execute("SELECT * FROM company").fetchone()
    # Pick the first bank account with a BSB
    bank = conn.execute("""
        SELECT * FROM accounts
        WHERE is_bank=1 AND bsb IS NOT NULL AND bsb != ''
        ORDER BY code LIMIT 1""").fetchone()
    conn.close()

    co   = dict(co)   if co   else {}
    bank = dict(bank) if bank else {}

    return {
        "user_id":       co.get("aba_user_id", ""),
        "user_name":     co.get("name", ""),
        "description":   co.get("aba_description", "PAYMENT"),
        "financial_inst": bank.get("bsb", "")[:3].replace("-", "") if bank.get("bsb") else "",
        "bsb":           bank.get("bsb", ""),
        "account_number": bank.get("account_number", ""),
        "account_name":  bank.get("name", co.get("name", "")),
    }


def save_aba_settings(db_path: str, data: dict):
    """Persist ABA-specific company settings."""
    conn = get_connection(db_path)
    # Add columns if they don't exist (migration-safe)
    for col, default in [("aba_user_id", "''"), ("aba_description", "'PAYMENT'")]:
        try:
            conn.execute(f"ALTER TABLE company ADD COLUMN {col} TEXT DEFAULT {default}")
        except Exception:
            pass
    conn.execute(
        "UPDATE company SET aba_user_id=?, aba_description=? WHERE id=1",
        (data.get("user_id", ""), data.get("description", "PAYMENT")))
    conn.commit()
    conn.close()


def generate_aba(
    db_path:     str,
    payments:    list,   # list of dicts from get_payments_for_aba()
    process_date: str,   # YYYY-MM-DD
    description: str = "PAYMENT",
    reel_sequence: str = "01",
) -> str:
    """
    Build and return the full ABA file content as a string.

    Each payment dict must have:
      dest_bsb, dest_account, dest_name, amount (float dollars),
      lodgement_ref (str, up to 18 chars)

    Our own BSB/account are loaded from the first bank account with a BSB.
    """
    if not payments:
        raise ABAError("No payments provided.")

    settings = get_aba_settings(db_path)

    # Validate our own bank details
    if not settings.get("bsb"):
        raise ABAError(
            "Your bank account has no BSB recorded.\n\n"
            "Go to Accounts, edit your bank account, and enter the BSB and Account Number.")
    if not settings.get("account_number"):
        raise ABAError(
            "Your bank account has no Account Number recorded.\n\n"
            "Go to Accounts, edit your bank account, and enter the Account Number.")

    try:
        our_bsb     = _clean_bsb(settings["bsb"])
        our_account = _clean_account(settings["account_number"])
    except ValueError as e:
        raise ABAError(f"Your bank account details are invalid: {e}")

    our_name   = settings.get("account_name") or settings.get("user_name") or "COMPANY"
    user_id    = str(settings.get("user_id") or "999999").strip()
    user_name  = (settings.get("user_name") or "COMPANY")[:26]

    # Parse process date YYYY-MM-DD → DDMMYY
    try:
        d = _date.fromisoformat(process_date)
        ddmmyy = d.strftime("%d%m%y")
    except Exception:
        raise ABAError(f"Invalid process date: {process_date}")

    # Derive financial institution from our BSB
    fin_inst = our_bsb[:3]

    lines = []

    # Header
    lines.append(_record_0(
        reel_sequence     = reel_sequence,
        financial_inst    = fin_inst,
        user_preferred_id = user_name,
        user_id           = user_id,
        description       = description[:12],
        process_date      = ddmmyy,
    ))

    credit_total = 0
    debit_total  = 0

    for idx, pmt in enumerate(payments, start=1):
        # Validate destination bank details
        raw_bsb = pmt.get("dest_bsb", "")
        raw_acc = pmt.get("dest_account", "")
        name    = pmt.get("dest_name", f"PAYMENT {idx}")
        amount  = float(pmt.get("amount", 0))
        ref     = str(pmt.get("lodgement_ref", ""))[:18]

        if not raw_bsb:
            raise ABAError(
                f"Payment to '{name}' has no BSB.\n\n"
                f"Edit the contact in Contacts and enter their BSB and Account Number.")
        if not raw_acc:
            raise ABAError(
                f"Payment to '{name}' has no Account Number.\n\n"
                f"Edit the contact in Contacts and enter their Account Number.")
        if amount <= 0:
            raise ABAError(f"Payment to '{name}' has invalid amount: {amount}")

        try:
            dest_bsb = _clean_bsb(raw_bsb)
            dest_acc = _clean_account(raw_acc)
        except ValueError as e:
            raise ABAError(f"Payment to '{name}': {e}")

        cents = round(amount * 100)
        credit_total += cents

        lines.append(_record_1(
            bsb             = dest_bsb,
            account         = dest_acc,
            indicator       = " ",
            txn_code        = "50",          # externally initiated credit
            amount_cents    = cents,
            account_name    = name,
            lodgement_ref   = ref,
            trace_bsb       = our_bsb,
            trace_account   = our_account,
            remitter_name   = our_name,
            withholding_tax = 0,
        ))

    # Trailer
    net_total = credit_total - debit_total
    lines.append(_record_7(
        bsb_total          = "999-999",
        net_total_cents    = net_total,
        credit_total_cents = credit_total,
        debit_total_cents  = debit_total,
        record_count       = len(payments),
    ))

    return "\r\n".join(lines) + "\r\n"


def get_payments_for_aba(db_path: str, date_from: str, date_to: str) -> list:
    """
    Retrieve supplier payments in a date range that have contact BSB/account data.
    Returns list of dicts ready for generate_aba().
    """
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT p.id, p.payment_date, p.amount, p.reference, p.description,
               c.name   as contact_name,
               c.bsb    as dest_bsb,
               c.account_number as dest_account
        FROM payments p
        JOIN contacts c ON p.contact_id = c.id
        WHERE p.payment_type = 'Payment'
          AND p.payment_date BETWEEN ? AND ?
        ORDER BY p.payment_date, p.id""",
        (date_from, date_to)).fetchall()
    conn.close()

    results = []
    for r in rows:
        r = dict(r)
        results.append({
            "payment_id":    r["id"],
            "dest_bsb":      r["dest_bsb"] or "",
            "dest_account":  r["dest_account"] or "",
            "dest_name":     r["contact_name"],
            "amount":        r["amount"],
            "lodgement_ref": r["reference"] or r["description"] or f"PMT{r['id']}",
            "payment_date":  r["payment_date"],
        })
    return results


def get_bills_for_aba(db_path: str, due_before: str = None,
                       supplier_ids: list = None) -> list:
    """
    Retrieve unpaid/partially-paid Approved bills with supplier bank details.
    Returns list of dicts ready for generate_aba() plus extra display fields.
    due_before: ISO date string, only bills with due_date <= this date
    """
    from core.database import get_connection as _gc
    conn = _gc(db_path)
    q = """
        SELECT b.id, b.bill_number, b.bill_date, b.due_date,
               b.total, b.amount_paid,
               b.total - b.amount_paid  AS balance_due,
               b.contact_id,
               c.name                   AS supplier_name,
               c.bsb                    AS dest_bsb,
               c.account_number         AS dest_account,
               c.bank_account_name      AS dest_name_override
        FROM bills b
        JOIN contacts c ON b.contact_id = c.id
        WHERE b.status IN ('Approved','Overdue')
          AND (b.total - b.amount_paid) > 0.005
    """
    params = []
    if due_before:
        q += " AND (b.due_date IS NULL OR b.due_date <= ?)"
        params.append(due_before)
    if supplier_ids:
        placeholders = ",".join("?" * len(supplier_ids))
        q += f" AND b.contact_id IN ({placeholders})"
        params.extend(supplier_ids)
    q += " ORDER BY b.due_date ASC NULLS LAST, c.name ASC"
    rows = conn.execute(q, params).fetchall()
    conn.close()

    results = []
    for r in rows:
        r = dict(r)
        dest_name = (r.get("dest_name_override") or r["supplier_name"])[:32]
        results.append({
            "bill_id":       r["id"],
            "bill_number":   r["bill_number"],
            "bill_date":     r["bill_date"],
            "due_date":      r["due_date"] or "",
            "supplier_name": r["supplier_name"],
            "balance_due":   round(r["balance_due"], 2),
            "contact_id":    r["contact_id"],
            # ABA fields
            "dest_bsb":      r.get("dest_bsb") or "",
            "dest_account":  r.get("dest_account") or "",
            "dest_name":     dest_name,
            "amount":        round(r["balance_due"], 2),
            "lodgement_ref": r["bill_number"] or f"BILL{r['id']}",
        })
    return results


def get_expiry_alerts(db_path: str, days_ahead: int = 30) -> dict:
    """
    Return quotes and warranties expiring within days_ahead days,
    plus already-expired ones.
    """
    from core.database import get_connection as _gc
    import datetime as _dt
    conn = _gc(db_path)
    today = _dt.date.today().isoformat()
    horizon = (_dt.date.today() + _dt.timedelta(days=days_ahead)).isoformat()

    # Quotes expiring or expired
    quotes_expiring = [dict(r) for r in conn.execute("""
        SELECT q.id, q.quote_number, q.expiry_date, q.total, q.status,
               c.name as contact_name
        FROM crm_quotes q
        JOIN contacts c ON q.contact_id = c.id
        WHERE q.status IN ('Draft','Sent')
          AND q.expiry_date IS NOT NULL
          AND q.expiry_date <= ?
        ORDER BY q.expiry_date ASC
    """, (horizon,)).fetchall()]

    # Warranties expiring or expired
    warranties_expiring = [dict(r) for r in conn.execute("""
        SELECT w.id,
               w.item_description,
               w.serial_number,
               w.provider,
               w.source_type,
               w.warranty_expiry,
               w.claim_status,
               CAST(julianday(w.warranty_expiry) - julianday('now') AS INTEGER)
                   AS days_remaining
        FROM warranties w
        WHERE w.warranty_expiry IS NOT NULL
          AND w.warranty_expiry <= ?
          AND (w.claim_status IS NULL OR w.claim_status = 'active')
        ORDER BY w.warranty_expiry ASC
    """, (horizon,)).fetchall()]

    conn.close()

    # Split into expired vs expiring-soon
    def split(items, date_key):
        expired = [i for i in items if i[date_key] < today]
        soon    = [i for i in items if today <= i[date_key] <= horizon]
        return expired, soon

    q_expired, q_soon = split(quotes_expiring,     "expiry_date")
    w_expired, w_soon = split(warranties_expiring,  "warranty_expiry")

    return {
        "quotes_expired":    q_expired,
        "quotes_expiring":   q_soon,
        "warranties_expired": w_expired,
        "warranties_expiring": w_soon,
        "total_alerts": len(q_expired) + len(q_soon) + len(w_expired) + len(w_soon),
    }
