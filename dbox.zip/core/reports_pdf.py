# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Accounting — Financial Reports via ReportLab
==========================================
Generates PDF reports styled identically to the tax invoice:
  same fonts, same colour palette, same header/footer layout.

Reports:  Profit & Loss · Balance Sheet · Trial Balance · BAS Summary
"""

from __future__ import annotations
import os, tempfile
from datetime import date as _date, datetime

from reportlab.lib.pagesizes  import A4, landscape as _landscape
from reportlab.lib             import colors
from reportlab.lib.units       import mm
from reportlab.lib.styles      import ParagraphStyle
from reportlab.lib.enums       import TA_RIGHT, TA_LEFT, TA_CENTER
from reportlab.platypus        import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, KeepTogether
)
from reportlab.platypus.flowables import HRFlowable

from core.database import get_connection
from core.invoice_pdf import _make_watermark_canvas

# ── colour helpers ────────────────────────────────────────────────────────────


def _c(h: str):
    return colors.HexColor(str(h))

# Fixed semantic colours — used outside the theme palette
WHITE  = colors.white
GREEN  = _c("#27ae60")
RED    = _c("#e74c3c")
GREY   = _c("#8892a4")

# ── Theme-aware PDF palette ───────────────────────────────────────────────────
#
# All 7 app themes are mapped to a print-safe PDF palette.  Dark themes are
# adapted: backgrounds become white/near-white so they print well on paper,
# but accent, green, and danger hues are preserved so the PDF still "feels"
# like the chosen theme.  Ocean Light is the fallback.
#
# Keys returned by _pdf_palette():
#   HEADER_BG   — column/section header background (dark strip)
#   HEADER_TEXT — text on dark header background (always near-white)
#   ACCENT      — primary accent (rules, highlights, totals bar)
#   ACCENT2     — secondary accent / positive amounts (green-ish)
#   DANGER      — negative / warning colour
#   SURFACE     — page / card background
#   PANEL       — slightly darker surface (subtotal bands, footer)
#   BORDER      — table rules and HR lines
#   TEXT        — body text
#   MUTED       — secondary / dimmed text
#   INK2        — mid-weight labels
#   ROW_ALT     — alternating table row stripe
#   GREEN_LT    — light tint of ACCENT2 (for gross-profit band)
#   RED_LT      — light tint of DANGER (for loss band)
#   ACCENT_LT   — light tint of ACCENT (for subtotal band fill)

# Ocean Light colours — canonical fallback, matches web UI exactly
_OL = {
    "HEADER_BG":   "#185FA5",   # accent used as header bg
    "HEADER_TEXT": "#FFFFFF",
    "ACCENT":      "#185FA5",
    "ACCENT2":     "#3B6D11",
    "DANGER":      "#A32D2D",
    "SURFACE":     "#FFFFFF",
    "PANEL":       "#F0F6FB",
    "BORDER":      "#C8DCEE",
    "TEXT":        "#1A2E45",
    "MUTED":       "#6B8BAA",
    "INK2":        "#3a5068",
    "ROW_ALT":     "#EBF2FA",
    "GREEN_LT":    "#EAF4E2",
    "RED_LT":      "#FDEAEA",
    "ACCENT_LT":   "#EAF0F9",
}

# Per-theme overrides keyed by the EXACT names used in the web UI's THEMES dict.
# Each theme overrides every key so body rows, panels, and text are all
# distinctly tinted — pale pastels derived from each theme's accent hue.
# SURFACE is always white (prints cleanly). BORDER is solid hex (no rgba).
# TEXT/MUTED/INK2 are near-black tinted toward the theme hue — readable on
# paper but still feel like the theme.
_THEME_OVERRIDES = {
    "Ocean Light": {},  # _OL is the default — no overrides needed

    "Dark": {
        # amber/gold accent — pale amber tint for body rows
        "HEADER_BG":  "#13161e",
        "ACCENT":     "#b87a00",   # darkened amber for contrast on white
        "ACCENT2":    "#2e7a50",
        "DANGER":     "#b83030",
        "SURFACE":    "#ffffff",
        "PANEL":      "#fdf8ed",   # pale amber
        "ROW_ALT":    "#fef9f0",   # very pale amber stripe
        "BORDER":     "#d4c89a",
        "TEXT":       "#2a1e00",   # near-black with amber tint
        "MUTED":      "#7a6030",
        "INK2":       "#4a3810",
        "ACCENT_LT":  "#fdf0c8",
        "GREEN_LT":   "#e8f5e9",
        "RED_LT":     "#fdeaea",
    },
    "Midnight Blue": {
        # blue accent — pale blue tint for body rows
        "HEADER_BG":  "#0f1729",
        "ACCENT":     "#1a4a9e",   # darkened blue for contrast on white
        "ACCENT2":    "#1a6e44",
        "DANGER":     "#b83030",
        "SURFACE":    "#ffffff",
        "PANEL":      "#edf3ff",   # pale blue
        "ROW_ALT":    "#f2f6ff",   # very pale blue stripe
        "BORDER":     "#a8bedd",
        "TEXT":       "#0a1428",   # near-black with blue tint
        "MUTED":      "#3a5070",
        "INK2":       "#1e3050",
        "ACCENT_LT":  "#dbe8ff",
        "GREEN_LT":   "#e6f4ec",
        "RED_LT":     "#fdeaea",
    },
    "Forest": {
        # green accent — pale green tint for body rows
        "HEADER_BG":  "#1a2318",
        "ACCENT":     "#2d6e18",   # darkened green for contrast on white
        "ACCENT2":    "#1e6e30",
        "DANGER":     "#b83030",
        "SURFACE":    "#ffffff",
        "PANEL":      "#eef7ea",   # pale green
        "ROW_ALT":    "#f3faf0",   # very pale green stripe
        "BORDER":     "#a0c498",
        "TEXT":       "#0e1e0a",   # near-black with green tint
        "MUTED":      "#3e5e38",
        "INK2":       "#1e3e18",
        "ACCENT_LT":  "#d8f0d0",
        "GREEN_LT":   "#d8f0d0",
        "RED_LT":     "#fdeaea",
    },
    "Warm Slate": {
        # terracotta/orange accent — pale warm tint for body rows
        "HEADER_BG":  "#231f1c",
        "ACCENT":     "#9e4a10",   # darkened terracotta for contrast on white
        "ACCENT2":    "#2e6e30",
        "DANGER":     "#b83030",
        "SURFACE":    "#ffffff",
        "PANEL":      "#fdf3ec",   # pale terracotta
        "ROW_ALT":    "#fef7f2",   # very pale warm stripe
        "BORDER":     "#ccb09c",
        "TEXT":       "#241208",   # near-black with warm tint
        "MUTED":      "#7a5038",
        "INK2":       "#4a2a18",
        "ACCENT_LT":  "#fce4cc",
        "GREEN_LT":   "#e8f5e8",
        "RED_LT":     "#fdeaea",
    },
    "Light": {
        # cool blue — slightly cooler/crisper than Ocean Light
        "HEADER_BG":  "#2563eb",
        "ACCENT":     "#2563eb",
        "ACCENT2":    "#16a34a",
        "DANGER":     "#dc2626",
        "SURFACE":    "#ffffff",
        "PANEL":      "#f1f5f9",
        "ROW_ALT":    "#f8fafc",
        "BORDER":     "#94a3b8",
        "TEXT":       "#1e293b",
        "MUTED":      "#64748b",
        "INK2":       "#334155",
        "ACCENT_LT":  "#eff6ff",
        "GREEN_LT":   "#f0fdf4",
        "RED_LT":     "#fef2f2",
    },
    "Purple Haze": {
        # violet/purple accent — pale lavender tint for body rows
        "HEADER_BG":  "#120e1e",
        "ACCENT":     "#5b21b6",   # darkened purple for contrast on white
        "ACCENT2":    "#047857",
        "DANGER":     "#dc2626",
        "SURFACE":    "#ffffff",
        "PANEL":      "#f2eeff",   # pale lavender
        "ROW_ALT":    "#f7f3ff",   # very pale violet stripe
        "BORDER":     "#c0aae0",
        "TEXT":       "#160e2e",   # near-black with violet tint
        "MUTED":      "#6040a0",
        "INK2":       "#3a2068",
        "ACCENT_LT":  "#e8d8ff",
        "GREEN_LT":   "#ecfdf5",
        "RED_LT":     "#fef2f2",
    },
}


def _pdf_palette(db_path: str = None, theme_name: str = None) -> dict:
    """
    Return a resolved colour dict for PDF rendering.

    Resolution order:
      1. theme_name argument (explicit override — used by web server)
      2. .dbox.theme file alongside the company file (desktop app)
      3. Ocean Light fallback

    All returned values are reportlab Color objects.
    """
    resolved = "Ocean Light"

    # 1. Explicit override takes priority
    if theme_name and theme_name in _THEME_OVERRIDES:
        resolved = theme_name
    elif db_path:
        # 2. Try the .dbox.theme file written by the desktop app
        theme_path = db_path + ".dbox.theme"
        try:
            import json as _json
            with open(theme_path) as _f:
                _data = _json.load(_f)
            _name = _data.get("name", "Ocean Light")
            if _name in _THEME_OVERRIDES:
                resolved = _name
        except Exception:
            pass

    merged = dict(_OL)
    merged.update(_THEME_OVERRIDES.get(resolved, {}))
    return {k: (_c(v) if isinstance(v, str) else v) for k, v in merged.items()}


# Module-level palette — defaults to Ocean Light.
# Kept for any code that still references the old global names directly
# (aged report, cash flow, statement of account — each has its own locals).
def _default_C():
    return _pdf_palette(None)

# Legacy module-level aliases — resolved at import time to Ocean Light.
# render_* functions now call _pdf_palette(db_path) for their own C dict.
HEADER_BG   = _c(_OL["HEADER_BG"])
HEADER_TEXT = _c(_OL["HEADER_TEXT"])
ACCENT      = _c(_OL["ACCENT"])
ACCENT2     = _c(_OL["ACCENT2"])
SURFACE     = _c(_OL["SURFACE"])
PANEL       = _c(_OL["PANEL"])
BORDER      = _c(_OL["BORDER"])
TEXT        = _c(_OL["TEXT"])
MUTED       = _c(_OL["MUTED"])
INK2        = _c(_OL["INK2"])
ROW_ALT     = _c(_OL["ROW_ALT"])
GREEN_LT    = _c(_OL["GREEN_LT"])
RED_LT      = _c(_OL["RED_LT"])
ACCENT_LT   = _c(_OL["ACCENT_LT"])

W, H = A4

# ── paragraph styles ──────────────────────────────────────────────────────────

def _styles(C: dict = None):
    if C is None: C = _default_C()
    # ReportLab caches ParagraphStyle objects by name in a global registry.
    # Using a palette-derived suffix prevents stale cached colours from a
    # previous call bleeding into a different theme.
    _sfx = id(C)
    def PS(name, **kw):
        return ParagraphStyle(f"{name}_{_sfx}", **kw)
    return {
        "co_name":   PS("co_name",  fontName="Helvetica-Bold",
                     fontSize=20, textColor=C["TEXT"], leading=24),
        "rpt_title": PS("rpt_title", fontName="Helvetica-Bold",
                     fontSize=18, textColor=C["ACCENT"], leading=22,
                     alignment=TA_RIGHT),
        "label":     PS("label", fontName="Helvetica-Bold",
                     fontSize=7, textColor=C["MUTED"], leading=10,
                     textTransform="uppercase"),
        "meta":      PS("meta", fontName="Helvetica",
                     fontSize=8.5, textColor=C["MUTED"], leading=13),
        "period":    PS("period", fontName="Helvetica",
                     fontSize=8.5, textColor=C["MUTED"], leading=13,
                     alignment=TA_RIGHT),
        "body":      PS("body", fontName="Helvetica",
                     fontSize=9, textColor=C["TEXT"], leading=13),
        "body_b":    PS("body_b", fontName="Helvetica-Bold",
                     fontSize=9, textColor=C["TEXT"], leading=13),
        "body_r":    PS("body_r", fontName="Helvetica",
                     fontSize=9, textColor=C["TEXT"], leading=13,
                     alignment=TA_RIGHT),
        "body_rb":   PS("body_rb", fontName="Helvetica-Bold",
                     fontSize=9, textColor=C["TEXT"], leading=13,
                     alignment=TA_RIGHT),
        "code":      PS("code", fontName="Courier",
                     fontSize=8, textColor=C["MUTED"], leading=12),
        "section":   PS("section", fontName="Helvetica-Bold",
                     fontSize=8, textColor=C["HEADER_TEXT"], leading=11,
                     textTransform="uppercase"),
        "col_hdr":   PS("col_hdr", fontName="Helvetica-Bold",
                     fontSize=7.5, textColor=C["HEADER_TEXT"], leading=10,
                     textTransform="uppercase"),
        "col_hdr_r": PS("col_hdr_r", fontName="Helvetica-Bold",
                     fontSize=7.5, textColor=C["HEADER_TEXT"], leading=10,
                     textTransform="uppercase", alignment=TA_RIGHT),
        "total_lbl": PS("total_lbl", fontName="Helvetica-Bold",
                     fontSize=9, textColor=C["MUTED"], leading=13),
        "total_val": PS("total_val", fontName="Helvetica-Bold",
                     fontSize=9, textColor=C["TEXT"], leading=13,
                     alignment=TA_RIGHT),
        "grand_lbl": PS("grand_lbl", fontName="Helvetica-Bold",
                     fontSize=10, textColor=WHITE, leading=14),
        "grand_val": PS("grand_val", fontName="Helvetica-Bold",
                     fontSize=16, textColor=WHITE, leading=20,
                     alignment=TA_RIGHT),
        "footer":    PS("footer", fontName="Helvetica",
                     fontSize=7.5, textColor=C["MUTED"], leading=11,
                     alignment=TA_CENTER),
        "footer_b":  PS("footer_b", fontName="Helvetica-Bold",
                     fontSize=7.5, textColor=C["ACCENT"], leading=11,
                     alignment=TA_CENTER),
        "neg":       PS("neg", fontName="Helvetica",
                     fontSize=9, textColor=RED, leading=13,
                     alignment=TA_RIGHT),
        "neg_b":     PS("neg_b", fontName="Helvetica-Bold",
                     fontSize=9, textColor=RED, leading=13,
                     alignment=TA_RIGHT),
        "bas_field": PS("bas_field", fontName="Courier-Bold",
                     fontSize=8, textColor=C["MUTED"], leading=12),
        "bas_lbl":   PS("bas_lbl", fontName="Helvetica",
                     fontSize=9, textColor=C["INK2"], leading=13),
        "bas_val":   PS("bas_val", fontName="Helvetica-Bold",
                     fontSize=9, textColor=C["TEXT"], leading=13,
                     alignment=TA_RIGHT),
        "bas_hdr":   PS("bas_hdr", fontName="Helvetica-Bold",
                     fontSize=8, textColor=C["ACCENT"], leading=11,
                     textTransform="uppercase"),
        "bas_net_lbl": PS("bas_net_lbl", fontName="Helvetica-Bold",
                     fontSize=12, textColor=WHITE, leading=16),
        "bas_net_sub": PS("bas_net_sub", fontName="Helvetica",
                     fontSize=8, textColor=colors.Color(1,1,1,.6), leading=12),
        "bas_net_amt": PS("bas_net_amt", fontName="Helvetica-Bold",
                     fontSize=22, textColor=WHITE, leading=26,
                     alignment=TA_RIGHT),
        "disc":      PS("disc", fontName="Helvetica",
                     fontSize=8, textColor=C["MUTED"], leading=12),
        "disc_b":    PS("disc_b", fontName="Helvetica-Bold",
                     fontSize=8, textColor=C["INK2"], leading=12),
    }


# ── formatting ────────────────────────────────────────────────────────────────

def _d(d: str) -> str:
    if not d: return "—"
    try:
        dt = datetime.strptime(d, "%Y-%m-%d")
        return f"{dt.day} {dt.strftime('%b %Y')}"
    except: return d

def _money(n, bold=False, negative_parens=True) -> str:
    """Format as currency string for Paragraph."""
    if n is None: return "—"
    n = float(n)
    s = f"${abs(n):,.2f}"
    if n < 0:
        return f"({s})" if negative_parens else f"-{s}"
    return s

def _logo_img(logo_path, max_w=45*mm, max_h=18*mm):
    if not logo_path or not os.path.exists(logo_path): return None
    try:
        from reportlab.platypus import Image
        img = Image(logo_path)
        ratio = min(max_w / img.imageWidth, max_h / img.imageHeight)
        img.drawWidth  = img.imageWidth  * ratio
        img.drawHeight = img.imageHeight * ratio
        img.hAlign = 'LEFT'
        return img
    except Exception: return None


def _logo_from_co(co, max_w=45*mm, max_h=18*mm):
    """Load logo from DB blob (web upload) or fall back to file path (desktop)."""
    from io import BytesIO as _BytesIO
    from reportlab.platypus import Image as _Image
    blob = co.get("logo_blob")
    if blob:
        try:
            img = _Image(_BytesIO(bytes(blob)))
            ratio = min(max_w / img.imageWidth, max_h / img.imageHeight)
            img.drawWidth  = img.imageWidth  * ratio
            img.drawHeight = img.imageHeight * ratio
            img.hAlign = 'LEFT'
            return img
        except Exception:
            pass
    return _logo_img(co.get("logo_path", ""), max_w, max_h)

def _load_company(db_path):
    conn = get_connection(db_path)
    row  = conn.execute("SELECT * FROM company WHERE id=1").fetchone()
    conn.close()
    return dict(row) if row else {}


# ── shared page builder ───────────────────────────────────────────────────────

def _make_doc(out_path: str) -> SimpleDocTemplate:
    return SimpleDocTemplate(
        out_path,
        pagesize=A4,
        leftMargin=16*mm, rightMargin=16*mm,
        topMargin=14*mm,  bottomMargin=14*mm,
        title="dbox Report",
    )

def _header_block(co: dict, title: str, period: str, s: dict, C: dict = None,
                  page_width: float = None) -> list:
    """Invoice-style header: company name left, report title right, accent rule."""
    if C is None: C = _default_C()
    co_name  = co.get("name", "Your Company")
    abn      = co.get("abn", "")
    addr     = ", ".join(filter(None, [co.get("address"), co.get("city"),
                                        co.get("state"), co.get("postcode")]))
    phone    = co.get("phone", "")
    email    = co.get("email", "")
    logo     = _logo_from_co(co)

    meta_lines = []
    if abn:   meta_lines.append(f"ABN {abn}")
    if addr:  meta_lines.append(addr)
    if phone: meta_lines.append(f"T: {phone}")
    if email: meta_lines.append(f"E: {email}")
    meta_txt = "<br/>".join(meta_lines)

    now = datetime.now()
    ts  = f"Generated {now.day} {now.strftime('%b %Y')} at {now.strftime('%I:%M %p')}"

    left_content = []
    if logo:
        left_content.append(logo)
        left_content.append(Spacer(1, 3*mm))
    left_content.append(Paragraph(co_name, s["co_name"]))
    if meta_txt:
        left_content.append(Spacer(1, 2*mm))
        left_content.append(Paragraph(meta_txt, s["meta"]))

    right_content = [
        Paragraph(title, s["rpt_title"]),
        Spacer(1, 3*mm),
        Paragraph(period, s["period"]),
        Paragraph(ts, s["period"]),
    ]

    from reportlab.platypus import KeepInFrame
    _PW     = page_width or W
    left_w  = _PW * 0.54 - 16*mm
    right_w = _PW * 0.46 - 16*mm
    left_frame  = KeepInFrame(left_w,  200*mm, left_content,  hAlign="LEFT")
    right_frame = KeepInFrame(right_w, 200*mm, right_content, hAlign="RIGHT")
    tbl = Table(
        [[left_frame, right_frame]],
        colWidths=[left_w, right_w],
    )
    tbl.setStyle(TableStyle([
        ("VALIGN",       (0,0), (-1,-1), "TOP"),
        ("LEFTPADDING",  (0,0), (-1,-1), 0),
        ("RIGHTPADDING", (0,0), (-1,-1), 0),
        ("TOPPADDING",   (0,0), (-1,-1), 0),
        ("BOTTOMPADDING",(0,0), (-1,-1), 0),
    ]))

    rule = HRFlowable(width="100%", thickness=3, color=C["ACCENT"],
                      spaceAfter=8*mm, spaceBefore=4*mm)
    return [tbl, rule]


def _section_label(text: str, s: dict, C: dict = None) -> list:
    """Full-width accent section bar."""
    if C is None: C = _default_C()
    tbl = Table([[Paragraph(text, s["section"])]], colWidths=[W - 32*mm])
    tbl.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,-1), C["HEADER_BG"]),
        ("TOPPADDING",   (0,0), (-1,-1), 5),
        ("BOTTOMPADDING",(0,0), (-1,-1), 5),
        ("LEFTPADDING",  (0,0), (-1,-1), 10),
        ("RIGHTPADDING", (0,0), (-1,-1), 10),
        ("LINEABOVE",    (0,0), (-1,0),  1, C["BORDER"]),
        ("LINEBELOW",    (0,-1),(-1,-1), 1, C["BORDER"]),
    ]))
    return [tbl]


def _account_table(rows_data: list, s: dict,
                   col_header=("Code", "Account", "Amount"),
                   col_widths=None, C: dict = None) -> Table:
    """Styled account data table."""
    if C is None: C = _default_C()
    usable = W - 32*mm
    if col_widths is None:
        col_widths = [18*mm, usable - 18*mm - 35*mm, 35*mm]

    hdrs = [Paragraph(h, s["col_hdr_r"] if i == len(col_header)-1 else s["col_hdr"])
            for i, h in enumerate(col_header)]

    table_rows = [hdrs] + rows_data
    num_cols = len(col_header)
    tbl = Table(table_rows, colWidths=col_widths, repeatRows=1)

    style = [
        ("BACKGROUND",    (0,0),  (-1,0),   C["HEADER_BG"]),
        ("LINEBELOW",     (0,0),  (-1,0),   2, C["ACCENT"]),
        ("TOPPADDING",    (0,0),  (-1,0),   6),
        ("BOTTOMPADDING", (0,0),  (-1,0),   6),
        ("FONTNAME",      (0,1),  (-1,-1),  "Helvetica"),
        ("FONTSIZE",      (0,1),  (-1,-1),  9),
        ("TEXTCOLOR",     (0,1),  (-1,-1),  C["TEXT"]),
        ("TOPPADDING",    (0,1),  (-1,-1),  5),
        ("BOTTOMPADDING", (0,1),  (-1,-1),  5),
        ("LINEBELOW",     (0,1),  (-1,-2),  0.5, C["BORDER"]),
        ("VALIGN",        (0,0),  (-1,-1),  "MIDDLE"),
        ("LEFTPADDING",   (0,0),  (-1,-1),  8),
        ("RIGHTPADDING",  (0,0),  (-1,-1),  8),
    ]
    for i in range(1, len(table_rows)):
        if i % 2 == 0:
            style.append(("BACKGROUND", (0,i), (-1,i), C["ROW_ALT"]))
    style.append(("ALIGN", (num_cols-1, 0), (num_cols-1, -1), "RIGHT"))

    tbl.setStyle(TableStyle(style))
    return tbl


def _subtotal_row(label: str, amount: float, s: dict, num_cols=3,
                  color=None, bg=None, grand=False, C: dict = None) -> Table:
    """Accent subtotal band."""
    if C is None: C = _default_C()
    if color is None: color = C["ACCENT"]
    if bg    is None: bg    = C["ACCENT_LT"]
    if grand:
        # For grand totals, derive a darker shade of the header bg
        color = C["HEADER_BG"]
        bg    = C["ROW_ALT"]
    usable = W - 32*mm
    col_widths = [18*mm] + [usable - 18*mm - 35*mm] + [35*mm]
    row = ["", Paragraph(f"<b>{label}</b>",
                          ParagraphStyle("st", fontName="Helvetica-Bold",
                                         fontSize=9, textColor=color, leading=13)),
           Paragraph(f"<b>{_money(amount)}</b>",
                      ParagraphStyle("sv", fontName="Helvetica-Bold",
                                     fontSize=9, textColor=color, leading=13,
                                     alignment=TA_RIGHT))]
    tbl = Table([row], colWidths=col_widths)
    tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,-1), bg),
        ("LINEABOVE",     (0,0), (-1,0),  1.5, color),
        ("LINEBELOW",     (0,-1),(-1,-1), 1.5, color),
        ("TOPPADDING",    (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
        ("LEFTPADDING",   (0,0), (-1,-1), 8),
        ("RIGHTPADDING",  (0,0), (-1,-1), 8),
        ("ALIGN",         (2,0), (2,0),   "RIGHT"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
    ]))
    return tbl


def _total_bar(rows: list, grand_label: str, grand_amount: float,
               grand_color=None, s: dict = None, C: dict = None) -> list:
    """Right-aligned total block with grand-total bar."""
    if C is None: C = _default_C()
    if s is None: s = _styles(C)
    grand_color = grand_color or C["ACCENT"]
    usable = W - 32*mm
    sp_w   = usable * 0.44
    lbl_w  = usable * 0.32
    val_w  = usable * 0.24

    table_rows = []
    style_cmds = [
        ("LEFTPADDING",   (0,0), (-1,-1), 0),
        ("RIGHTPADDING",  (0,0), (-1,-1), 8),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("ALIGN",         (2,0), (2,-1),  "RIGHT"),
        ("LEFTPADDING",   (1,0), (2,-1),  10),
    ]
    for i, (lbl, val) in enumerate(rows):
        table_rows.append([
            Paragraph("", s["body"]),
            Paragraph(lbl, s["total_lbl"]),
            Paragraph(_money(val), s["total_val"]),
        ])
        style_cmds += [
            ("BACKGROUND", (1,i), (2,i), C["PANEL"]),
            ("LINEBELOW",  (1,i), (2,i), 0.5, C["BORDER"]),
        ]
    g = len(table_rows)
    table_rows.append([
        Paragraph("", s["body"]),
        Paragraph(grand_label.upper(), s["grand_lbl"]),
        Paragraph(_money(grand_amount), s["grand_val"]),
    ])
    style_cmds += [
        ("BACKGROUND",    (1,g), (2,g), grand_color),
        ("TOPPADDING",    (1,g), (2,g), 9),
        ("BOTTOMPADDING", (1,g), (2,g), 9),
    ]
    tbl = Table(table_rows, colWidths=[sp_w, lbl_w, val_w])
    tbl.setStyle(TableStyle(style_cmds))
    return [Spacer(1, 4*mm), tbl, Spacer(1, 6*mm)]


def _footer(co: dict, s: dict, C: dict = None) -> list:
    if C is None: C = _default_C()
    name  = co.get("name", "")
    abn   = co.get("abn",  "")
    email = co.get("email","")
    parts = [x for x in [name, f"ABN {abn}" if abn else "", email] if x]
    line1 = " \u00a0|\u00a0 ".join(parts)
    rule  = HRFlowable(width="100%", thickness=0.5, color=C["BORDER"],
                       spaceBefore=4*mm, spaceAfter=3*mm)
    return [rule,
            Paragraph(line1, s["footer"]),
            Paragraph("dbox Accounting", s["footer_b"])]


# ── Profit & Loss ─────────────────────────────────────────────────────────────

def render_pl_pdf(db_path, date_from, date_to, out_path=None, hide_zeros=True, basis="accrual", theme=None, watermark=None, footer=None):
    _wm_text = watermark
    from core.ledger import profit_and_loss
    C  = _pdf_palette(db_path, theme_name=theme)
    co = _load_company(db_path)
    d  = profit_and_loss(db_path, date_from, date_to, basis=basis)
    s  = _styles(C)

    if out_path is None:
        out_path = os.path.join(tempfile.mkdtemp(), "profit_loss.pdf")

    doc   = _make_doc(out_path)
    basis_label = "Cash Basis" if basis == "cash" else "Accrual Basis"
    story = _header_block(co, "Profit & Loss Statement",
                          f"{_d(date_from)} – {_d(date_to)}  •  {basis_label}", s, C)

    def _section(label, items, amt_key="amount"):
        active = [r for r in items
                  if not hide_zeros or abs(float(r.get(amt_key,0) or 0)) >= 0.005]
        if not active: return [], 0.0
        total = sum(float(r.get(amt_key,0) or 0) for r in active)
        rows  = []
        for r in active:
            amt = float(r.get(amt_key,0) or 0)
            rows.append([
                Paragraph(r.get("code",""), s["code"]),
                Paragraph(r.get("name",""), s["body"]),
                Paragraph(_money(amt), s["neg_b"] if amt < 0 else s["body_rb"]),
            ])
        story.extend(_section_label(label, s, C))
        story.append(_account_table(rows, s, C=C))
        story.append(_subtotal_row(f"Total {label}", total, s, C=C))
        story.append(Spacer(1, 3*mm))
        return rows, total

    inc_rows, tot_inc = _section("Income",   d.get("income",[]))
    cos_rows, tot_cos = _section("Cost of Sales", d.get("cost_of_sales",[]))
    if cos_rows:
        gross = tot_inc - tot_cos
        story.extend(_section_label("Gross Profit", s, C))
        story.append(_subtotal_row("Gross Profit", gross, s,
                                   color=C["ACCENT2"], bg=C["GREEN_LT"], C=C))
        story.append(Spacer(1, 3*mm))
    exp_rows, tot_exp = _section("Expenses", d.get("expense",[]))

    net = d.get("net_profit", tot_inc - tot_cos - tot_exp)
    grand_color = C["ACCENT2"] if net >= 0 else C["DANGER"]
    label_txt   = "Net Profit" if net >= 0 else "Net Loss"

    story.extend(_total_bar(
        [("Total Income", tot_inc), ("Total Expenses", tot_exp)],
        label_txt, net, grand_color=grand_color, s=s, C=C))
    story.extend(_footer(co, s, C))

    doc.build(story, canvasmaker=_make_watermark_canvas(_wm_text, footer))
    return out_path


# ── Balance Sheet ─────────────────────────────────────────────────────────────

def render_bs_pdf(db_path, as_at_date=None, out_path=None, hide_zeros=True, theme=None, watermark=None, footer=None):
    _wm_text = watermark
    from core.ledger import balance_sheet
    if not as_at_date: as_at_date = str(_date.today())
    C  = _pdf_palette(db_path, theme_name=theme)
    co = _load_company(db_path)
    d  = balance_sheet(db_path, as_at_date)
    s  = _styles(C)

    if out_path is None:
        out_path = os.path.join(tempfile.mkdtemp(), "balance_sheet.pdf")

    doc   = _make_doc(out_path)
    story = _header_block(co, "Balance Sheet", f"As at {_d(as_at_date)}", s, C)

    def _acct_section(label, items):
        active = ([r for r in items
                   if abs(float(r.get("balance", 0) or 0)) >= 0.005]
                  if hide_zeros else items)
        if not active: return 0.0
        total = sum(float(r.get("balance", 0) or 0) for r in active)
        rows  = []
        for r in active:
            bal = float(r.get("balance", 0) or 0)
            rows.append([
                Paragraph(r.get("code", ""), s["code"]),
                Paragraph(r.get("name", ""), s["body"]),
                Paragraph(_money(bal), s["neg_b"] if bal < 0 else s["body_rb"]),
            ])
        story.extend(_section_label(label, s, C))
        story.append(_account_table(rows, s, col_header=("Code", "Account", "Balance"), C=C))
        story.append(_subtotal_row(f"Total {label}", total, s, C=C))
        story.append(Spacer(1, 2*mm))
        return total

    def _ppe_section(ppe_classes):
        if not ppe_classes: return 0.0
        story.extend(_section_label("Property, Plant & Equipment", s, C))

        C_DARK  = C["HEADER_BG"]
        C_HEAD  = C["ROW_ALT"]
        C_RULE  = C["BORDER"]
        C_ALT   = C["PANEL"]
        cw      = [(W-32*mm)*p for p in (0.42, 0.19, 0.20, 0.19)]

        hdr_ps  = ParagraphStyle("ppe_h", fontName="Helvetica-Bold",
                                  fontSize=7.5, textColor=C["HEADER_TEXT"], leading=10)
        hdr_r   = ParagraphStyle("ppe_hr", fontName="Helvetica-Bold",
                                  fontSize=7.5, textColor=C["HEADER_TEXT"], leading=10,
                                  alignment=TA_RIGHT)
        cell_ps = ParagraphStyle("ppe_c", fontName="Helvetica",
                                  fontSize=8, textColor=C["TEXT"], leading=10)
        cell_r  = ParagraphStyle("ppe_cr", fontName="Helvetica",
                                  fontSize=8, textColor=C["TEXT"], leading=10,
                                  alignment=TA_RIGHT)
        neg_r   = ParagraphStyle("ppe_nr", fontName="Helvetica",
                                  fontSize=8, textColor=C["DANGER"], leading=10,
                                  alignment=TA_RIGHT)

        hdr = Table([[Paragraph("Asset Class",         hdr_ps),
                      Paragraph("Cost",                hdr_r),
                      Paragraph("Accum Depreciation",  hdr_r),
                      Paragraph("Net Book Value",      hdr_r)]],
                    colWidths=cw)
        hdr.setStyle(TableStyle([
            ("BACKGROUND",    (0,0),(-1,-1), C_DARK),
            ("LINEBELOW",     (0,0),(-1,-1), 0.5, C_RULE),
            ("TOPPADDING",    (0,0),(-1,-1), 3),
            ("BOTTOMPADDING", (0,0),(-1,-1), 3),
            ("LEFTPADDING",   (0,0),(0,-1),  6),
        ]))
        story.append(hdr)

        total_net = 0.0
        for i, c in enumerate(ppe_classes):
            if hide_zeros and abs(c["net_wdv"]) < 0.005:
                continue
            bg = C_ALT if i % 2 else colors.white
            accum_str = (f"({_money(c['accum_depn'])})" if c["accum_depn"] else "—")
            row = Table([[
                Paragraph(c["label"],          cell_ps),
                Paragraph(_money(c["cost"]),    cell_r),
                Paragraph(accum_str,            neg_r if c["accum_depn"] else cell_r),
                Paragraph(_money(c["net_wdv"]), neg_r if c["net_wdv"] < 0 else cell_r),
            ]], colWidths=cw)
            row.setStyle(TableStyle([
                ("BACKGROUND",    (0,0),(-1,-1), bg),
                ("LINEBELOW",     (0,0),(-1,-1), 0.25, C_RULE),
                ("TOPPADDING",    (0,0),(-1,-1), 2),
                ("BOTTOMPADDING", (0,0),(-1,-1), 2),
                ("LEFTPADDING",   (0,0),(0,-1),  10),
            ]))
            story.append(row)
            total_net += c["net_wdv"]

        story.append(_subtotal_row(
            "Total Property, Plant & Equipment (Net)", total_net, s, C=C))
        story.append(Spacer(1, 2*mm))
        return total_net

    tCurr = _acct_section("Current Assets",          d.get("current_assets", []))
    tPPE  = _ppe_section(d.get("ppe_classes", []))
    tOth  = _acct_section("Other Non-Current Assets", d.get("other_noncurrent", []))
    tA    = round(tCurr + tPPE + tOth, 2)

    story.append(_subtotal_row("TOTAL ASSETS", tA, s, grand=True, C=C))
    story.append(Spacer(1, 4*mm))

    tL = _acct_section("Liabilities", d.get("liabilities", []))
    tE = _acct_section("Equity",      d.get("equity",      []))

    balanced  = abs(tA - tL - tE) < 0.005
    chk_color = C["ACCENT2"] if balanced else C["DANGER"]
    chk_txt   = "✓ Balance sheet is balanced" \
                if balanced else f"⚠ Out of balance by {_money(abs(tA - tL - tE))}"

    story.extend(_total_bar(
        [("Total Assets", tA), ("Total Liabilities", tL), ("Total Equity", tE)],
        "Total Liabilities & Equity", tL + tE,
        grand_color=C["ACCENT"], s=s, C=C))

    tbl = Table([[Paragraph(chk_txt,
                             ParagraphStyle("chk", fontName="Helvetica-Bold",
                                            fontSize=8.5, textColor=chk_color,
                                            leading=12, alignment=TA_RIGHT))]],
                colWidths=[W - 32*mm])
    tbl.setStyle(TableStyle([("ALIGN",         (0,0), (-1,-1), "RIGHT"),
                              ("TOPPADDING",    (0,0), (-1,-1), 0),
                              ("BOTTOMPADDING", (0,0), (-1,-1), 2)]))
    story.append(tbl)
    story.extend(_footer(co, s, C))
    doc.build(story, canvasmaker=_make_watermark_canvas(_wm_text, footer))
    return out_path


# ── Trial Balance ─────────────────────────────────────────────────────────────

def render_tb_pdf(db_path, out_path=None, hide_zeros=True, theme=None, watermark=None, footer=None):
    _wm_text = watermark
    from core.ledger import trial_balance
    C  = _pdf_palette(db_path, theme_name=theme)
    co = _load_company(db_path)
    tb = trial_balance(db_path)
    s  = _styles(C)

    if hide_zeros:
        tb = [r for r in tb
              if abs(float(r.get("balance",0) or 0)) >= 0.005
              or (r.get("total_debit") or 0) > 0
              or (r.get("total_credit") or 0) > 0]

    if out_path is None:
        out_path = os.path.join(tempfile.mkdtemp(), "trial_balance.pdf")

    total_dr = sum(float(r.get("total_debit",0)  or 0) for r in tb)
    total_cr = sum(float(r.get("total_credit",0) or 0) for r in tb)
    balanced = abs(total_dr - total_cr) < 0.005

    doc   = _make_doc(out_path)
    story = _header_block(co, "Trial Balance",
                          f"As at {_d(str(_date.today()))}", s, C)

    order = ["Asset","Liability","Equity","Income","Revenue",
             "Cost of Sales","Expense","Other"]
    by_type: dict = {}
    for r in tb:
        by_type.setdefault(r.get("account_type","Other"), []).append(r)

    usable = W - 32*mm
    cw = [18*mm, usable - 18*mm - 28*mm - 34*mm - 34*mm, 28*mm, 34*mm, 34*mm]
    hdr = ("Code","Account","Type","Debit","Credit")

    for atype in order + [k for k in by_type if k not in order]:
        grp = by_type.get(atype, [])
        if not grp: continue
        story.extend(_section_label(atype, s, C))
        rows = []
        for r in grp:
            dr = float(r.get("total_debit",0)  or 0)
            cr = float(r.get("total_credit",0) or 0)
            rows.append([
                Paragraph(r["code"], s["code"]),
                Paragraph(r["name"], s["body"]),
                Paragraph(atype[:10], s["meta"]),
                Paragraph(_money(dr) if dr else "—", s["body_r"]),
                Paragraph(_money(cr) if cr else "—", s["body_r"]),
            ])
        story.append(_account_table(rows, s, col_header=hdr,
                                    col_widths=cw, C=C))
        story.append(Spacer(1, 2*mm))

    grand_color = C["ACCENT2"] if balanced else C["DANGER"]
    grand_label = "✓  Balanced" if balanced else "⚠  Out of Balance"
    story.extend(_total_bar(
        [("Total Debits", total_dr), ("Total Credits", total_cr)],
        grand_label,
        abs(total_dr - total_cr) if not balanced else 0,
        grand_color=grand_color, s=s, C=C))
    story.extend(_footer(co, s, C))

    doc.build(story, canvasmaker=_make_watermark_canvas(_wm_text, footer))
    return out_path


# ── BAS ───────────────────────────────────────────────────────────────────────
# Uses ReportLab canvas directly for precise ATO form layout



def _ato_colours():
    """ATO form colour palette - white form, ATO blue/grey branding."""
    return {
        "form_bg":    colors.white,
        "ato_blue":   colors.HexColor("#003A6D"),   # ATO dark navy
        "ato_mid":    colors.HexColor("#005EA2"),   # ATO medium blue
        "ato_light":  colors.HexColor("#D6E4F0"),   # light blue fill for section headers
        "field_bg":   colors.HexColor("#F5F7FA"),   # very light grey field background
        "field_bdr":  colors.HexColor("#6B7C93"),   # field border grey
        "code_bg":    colors.HexColor("#1A3A5C"),   # dark navy for field code box
        "code_text":  colors.white,
        "label_text": colors.HexColor("#1A1A1A"),   # near-black label text
        "value_text": colors.HexColor("#003A6D"),   # navy for values
        "total_bg":   colors.HexColor("#003A6D"),   # dark nav for totals bar
        "total_text": colors.white,
        "positive":   colors.HexColor("#1B5E20"),   # dark green
        "negative":   colors.HexColor("#B71C1C"),   # dark red
        "divider":    colors.HexColor("#B0BEC5"),   # light grey divider
        "section_bg": colors.HexColor("#E8F0FE"),   # pale blue section header
        "payable_bg": colors.HexColor("#FFF3E0"),   # pale amber for payable amount
        "refund_bg":  colors.HexColor("#E8F5E9"),   # pale green for refund amount
        "note_bg":    colors.HexColor("#FFFDE7"),   # pale yellow for notes
    }


def _ato_styles():
    """Paragraph styles for ATO form."""
    C = _ato_colours()
    return {
        "form_title":  ParagraphStyle("form_title",
                        fontName="Helvetica-Bold", fontSize=14,
                        textColor=C["ato_blue"], leading=18),
        "sub_title":   ParagraphStyle("sub_title",
                        fontName="Helvetica", fontSize=9,
                        textColor=C["ato_mid"], leading=13),
        "co_name":     ParagraphStyle("co_name",
                        fontName="Helvetica-Bold", fontSize=11,
                        textColor=C["ato_blue"], leading=15),
        "co_meta":     ParagraphStyle("co_meta",
                        fontName="Helvetica", fontSize=8,
                        textColor=C["field_bdr"], leading=12),
        "period":      ParagraphStyle("period",
                        fontName="Helvetica-Bold", fontSize=8.5,
                        textColor=C["ato_blue"], leading=12),
        "section_hdr": ParagraphStyle("section_hdr",
                        fontName="Helvetica-Bold", fontSize=8,
                        textColor=C["ato_blue"], leading=11,
                        textTransform="uppercase"),
        "field_code":  ParagraphStyle("field_code",
                        fontName="Helvetica-Bold", fontSize=10,
                        textColor=colors.white, leading=14,
                        alignment=TA_CENTER),
        "field_label": ParagraphStyle("field_label",
                        fontName="Helvetica", fontSize=8.5,
                        textColor=C["label_text"], leading=12),
        "field_value": ParagraphStyle("field_value",
                        fontName="Helvetica-Bold", fontSize=11,
                        textColor=C["value_text"], leading=14,
                        alignment=TA_RIGHT),
        "total_label": ParagraphStyle("total_label",
                        fontName="Helvetica-Bold", fontSize=8.5,
                        textColor=colors.white, leading=12),
        "total_value": ParagraphStyle("total_value",
                        fontName="Helvetica-Bold", fontSize=13,
                        textColor=colors.white, leading=16,
                        alignment=TA_RIGHT),
        "net_label":   ParagraphStyle("net_label",
                        fontName="Helvetica-Bold", fontSize=10,
                        textColor=C["ato_blue"], leading=14),
        "net_value":   ParagraphStyle("net_value",
                        fontName="Helvetica-Bold", fontSize=18,
                        textColor=C["ato_blue"], leading=22,
                        alignment=TA_RIGHT),
        "note":        ParagraphStyle("note",
                        fontName="Helvetica", fontSize=7.5,
                        textColor=C["field_bdr"], leading=11),
        "footer":      ParagraphStyle("footer",
                        fontName="Helvetica", fontSize=7,
                        textColor=C["field_bdr"], leading=10,
                        alignment=TA_CENTER),
        "footer_b":    ParagraphStyle("footer_b",
                        fontName="Helvetica-Bold", fontSize=7,
                        textColor=C["ato_blue"], leading=10,
                        alignment=TA_CENTER),
        "gen_date":    ParagraphStyle("gen_date",
                        fontName="Helvetica", fontSize=7.5,
                        textColor=C["field_bdr"], leading=10,
                        alignment=TA_RIGHT),
    }


def _ato_header(co, form_title, subtitle, period_str, s, C):
    """ATO-style form header: ATO blue banner with form title + company panel."""
    usable = W - 32*mm

    # Top banner: form name left, ATO branding right
    banner = Table(
        [[Paragraph(form_title,
                    ParagraphStyle("ft2", fontName="Helvetica-Bold", fontSize=14,
                                   textColor=colors.white, leading=18)),
          Paragraph("Australian Taxation Office",
                    ParagraphStyle("ato_brand", fontName="Helvetica-Bold", fontSize=9,
                                   textColor=colors.HexColor("#A8C8E8"), leading=12,
                                   alignment=TA_RIGHT))]],
        colWidths=[usable*0.72, usable*0.28])
    banner.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,-1), C["ato_blue"]),
        ("TEXTCOLOR",     (0,0), (-1,-1), colors.white),
        ("TOPPADDING",    (0,0), (-1,-1), 10),
        ("BOTTOMPADDING", (0,0), (-1,-1), 10),
        ("LEFTPADDING",   (0,0), (-1,-1), 12),
        ("RIGHTPADDING",  (0,0), (-1,-1), 12),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("ALIGN",         (1,0), (1,0),   "RIGHT"),
    ]))

    # Company info panel below banner
    co_name  = co.get("name", "")
    abn      = co.get("abn", "")
    addr     = ", ".join(filter(None, [co.get("address"), co.get("city"),
                                        co.get("state"), co.get("postcode")]))
    now = datetime.now()
    gen_str  = f"Generated {now.day} {now.strftime('%b %Y at %I:%M %p')}"

    left_cell = [
        Paragraph(co_name, s["co_name"]),
    ]
    if abn:
        left_cell.append(Paragraph(f"ABN  {abn}", s["co_meta"]))
    if addr:
        left_cell.append(Paragraph(addr, s["co_meta"]))

    right_cell = [
        Paragraph(subtitle, s["sub_title"]),
        Spacer(1, 2*mm),
        Paragraph(period_str, s["period"]),
        Spacer(1, 1*mm),
        Paragraph(gen_str, s["gen_date"]),
    ]

    from reportlab.platypus import KeepInFrame
    lw = usable * 0.6
    rw = usable * 0.4
    info = Table(
        [[KeepInFrame(lw - 24*mm, 200*mm, left_cell,  hAlign="LEFT"),
          KeepInFrame(rw - 24*mm, 200*mm, right_cell, hAlign="RIGHT")]],
        colWidths=[lw, rw])
    info.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,-1), C["ato_light"]),
        ("TOPPADDING",    (0,0), (-1,-1), 8),
        ("BOTTOMPADDING", (0,0), (-1,-1), 8),
        ("LEFTPADDING",   (0,0), (-1,-1), 12),
        ("RIGHTPADDING",  (0,0), (-1,-1), 12),
        ("VALIGN",        (0,0), (-1,-1), "TOP"),
        ("ALIGN",         (1,0), (1,0),   "RIGHT"),
        ("BOX",           (0,0), (-1,-1), 1, C["ato_blue"]),
    ]))

    return [banner, info, Spacer(1, 5*mm)]


def _ato_section_header(title, s, C):
    """Full-width ATO section header band."""
    usable = W - 32*mm
    tbl = Table([[Paragraph(title, s["section_hdr"])]], colWidths=[usable])
    tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,-1), C["section_bg"]),
        ("LINEABOVE",     (0,0), (-1,0),  1.5, C["ato_blue"]),
        ("LINEBELOW",     (0,-1),(-1,-1), 0.5, C["divider"]),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("LEFTPADDING",   (0,0), (-1,-1), 10),
        ("RIGHTPADDING",  (0,0), (-1,-1), 10),
    ]))
    return tbl


def _ato_field_row(code, label, value, s, C, usable,
                   is_total=False, code_w=None, val_w=None):
    """One ATO field row: [CODE BOX] | label text | $ amount box."""
    code_w = code_w or 14*mm
    val_w  = val_w  or 38*mm
    lbl_w  = usable - code_w - val_w

    # Format value
    if value is None or value == 0.0:
        val_str  = "—"
        val_col  = C["divider"]
    else:
        val_str  = f"${abs(float(value)):,.2f}"
        val_col  = C["positive"] if float(value) >= 0 else C["negative"]

    code_para = Paragraph(code, s["field_code"])
    lbl_para  = Paragraph(label,
                           ParagraphStyle("fl", fontName="Helvetica-Bold" if is_total else "Helvetica",
                                          fontSize=8.5, textColor=C["label_text"], leading=12))
    val_para  = Paragraph(val_str,
                           ParagraphStyle("fv",
                                          fontName="Helvetica-Bold",
                                          fontSize=11 if is_total else 10,
                                          textColor=val_col if not is_total else C["ato_blue"],
                                          leading=14, alignment=TA_RIGHT))

    row = [[code_para, lbl_para, val_para]]
    tbl = Table(row, colWidths=[code_w, lbl_w, val_w])
    style = [
        # Code box — dark navy bg
        ("BACKGROUND",    (0,0), (0,0),   C["code_bg"]),
        ("TEXTCOLOR",     (0,0), (0,0),   colors.white),
        # Label cell
        ("BACKGROUND",    (1,0), (1,0),
         C["section_bg"] if is_total else C["form_bg"]),
        # Value cell
        ("BACKGROUND",    (2,0), (2,0),   C["field_bg"]),
        ("BOX",           (2,0), (2,0),   0.75, C["field_bdr"]),
        # All cells
        ("TOPPADDING",    (0,0), (-1,-1), 7),
        ("BOTTOMPADDING", (0,0), (-1,-1), 7),
        ("LEFTPADDING",   (0,0), (0,0),   0),
        ("RIGHTPADDING",  (0,0), (0,0),   0),
        ("LEFTPADDING",   (1,0), (1,0),   8),
        ("RIGHTPADDING",  (1,0), (1,0),   6),
        ("LEFTPADDING",   (2,0), (2,0),   6),
        ("RIGHTPADDING",  (2,0), (2,0),   8),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("ALIGN",         (2,0), (2,0),   "RIGHT"),
        ("LINEBELOW",     (0,0), (-1,-1), 0.5, C["divider"]),
    ]
    if is_total:
        style += [
            ("LINEABOVE",  (0,0), (-1,0), 1, C["ato_blue"]),
            ("LINEBELOW",  (0,-1),(-1,-1),1, C["ato_blue"]),
            ("FONTNAME",   (1,0), (1,0),  "Helvetica-Bold"),
        ]
    tbl.setStyle(TableStyle(style))
    return tbl


def _ato_summary_box(rows, net_amount, is_payable, s, C):
    """ATO summary/net-amount box — right-aligned, matches ATO 'Amount payable' section."""
    usable = W - 32*mm
    box_w  = usable * 0.56
    sp_w   = usable - box_w

    detail_rows = []
    for lbl, val in rows:
        val_str = f"${abs(float(val)):,.2f}" if val else "—"
        detail_rows.append([
            Paragraph(lbl, ParagraphStyle("sl", fontName="Helvetica",
                                           fontSize=8, textColor=C["ato_blue"], leading=12)),
            Paragraph(val_str, ParagraphStyle("sv", fontName="Helvetica-Bold",
                                               fontSize=8, textColor=C["ato_blue"], leading=12,
                                               alignment=TA_RIGHT)),
        ])

    if detail_rows:
        det_tbl = Table(detail_rows, colWidths=[box_w*0.62, box_w*0.38])
        det_tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0,0), (-1,-1), C["ato_light"]),
            ("LINEBELOW",     (0,0), (-1,-2), 0.5, C["divider"]),
            ("TOPPADDING",    (0,0), (-1,-1), 5),
            ("BOTTOMPADDING", (0,0), (-1,-1), 5),
            ("LEFTPADDING",   (0,0), (-1,-1), 10),
            ("RIGHTPADDING",  (0,0), (-1,-1), 10),
            ("ALIGN",         (1,0), (1,-1),  "RIGHT"),
            ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
            ("LINEABOVE",     (0,0), (-1,0),  1, C["ato_blue"]),
        ]))

    # Net payable/refund bar
    net_str   = f"${abs(net_amount):,.2f}"
    net_label = "Amount payable to ATO" if is_payable else "Refund from ATO"
    net_bg    = C["payable_bg"] if is_payable else C["refund_bg"]
    net_col   = C["negative"]   if is_payable else C["positive"]

    net_tbl = Table(
        [[Paragraph(net_label, ParagraphStyle("nl", fontName="Helvetica-Bold",
                                               fontSize=10, textColor=net_col, leading=14)),
          Paragraph(net_str,   ParagraphStyle("nv", fontName="Helvetica-Bold",
                                               fontSize=16, textColor=net_col, leading=20,
                                               alignment=TA_RIGHT))]],
        colWidths=[box_w*0.62, box_w*0.38])
    net_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,-1), net_bg),
        ("LINEABOVE",     (0,0), (-1,0),  1.5, net_col),
        ("LINEBELOW",     (0,-1),(-1,-1), 1.5, net_col),
        ("BOX",           (0,0), (-1,-1), 1,   net_col),
        ("TOPPADDING",    (0,0), (-1,-1), 9),
        ("BOTTOMPADDING", (0,0), (-1,-1), 9),
        ("LEFTPADDING",   (0,0), (-1,-1), 10),
        ("RIGHTPADDING",  (0,0), (-1,-1), 10),
        ("ALIGN",         (1,0), (1,0),   "RIGHT"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
    ]))

    from reportlab.platypus import KeepInFrame
    inner_flowables = ([det_tbl] if detail_rows else []) + [net_tbl]
    kif = KeepInFrame(box_w, 200*mm, inner_flowables, hAlign="LEFT")
    spacer_cell = Paragraph("", ParagraphStyle("sp", fontName="Helvetica", fontSize=1))
    wrapper = Table([[spacer_cell, kif]], colWidths=[sp_w, box_w])
    wrapper.setStyle(TableStyle([
        ("VALIGN",       (0,0), (-1,-1), "TOP"),
        ("LEFTPADDING",  (0,0), (-1,-1), 0),
        ("RIGHTPADDING", (0,0), (-1,-1), 0),
        ("TOPPADDING",   (0,0), (-1,-1), 0),
        ("BOTTOMPADDING",(0,0), (-1,-1), 0),
    ]))
    return [Spacer(1, 4*mm), wrapper, Spacer(1, 5*mm)]


def _ato_footer(co, form_title, s, C):
    """Footer rule + company + dbox brand."""
    usable = W - 32*mm
    name  = co.get("name", "")
    abn   = co.get("abn",  "")
    email = co.get("email","")
    parts = [x for x in [name, f"ABN {abn}" if abn else "", email] if x]
    line1 = "  |  ".join(parts)
    rule  = HRFlowable(width="100%", thickness=0.75, color=C["ato_blue"],
                       spaceBefore=4*mm, spaceAfter=2*mm)
    disc  = Paragraph(
        "This document is a summary generated by dbox Accounting software for reference purposes. "
        "Verify all figures before lodging with the ATO. Not a substitute for professional tax advice.",
        s["note"])
    return [rule,
            Paragraph(line1, s["footer"]),
            Paragraph("dbox Accounting  |  " + form_title, s["footer_b"]),
            Spacer(1, 2*mm),
            disc]


def render_bas_pdf(db_path, date_from, date_to, out_path=None, basis="accrual", theme=None, watermark=None, footer=None):
    _wm_text = watermark
    """BAS — ATO Business Activity Statement layout."""
    from core.ledger import bas_report
    co  = _load_company(db_path)
    bas = bas_report(db_path, date_from, date_to, basis=basis)
    C   = _ato_colours()
    s   = _ato_styles()
    usable = W - 32*mm

    if out_path is None:
        out_path = os.path.join(tempfile.mkdtemp(), "bas.pdf")

    basis_label = "Cash Basis" if basis == "cash" else "Accrual Basis"
    doc   = _make_doc(out_path)
    story = _ato_header(co, "Business Activity Statement",
                        f"Simpler BAS  •  {basis_label}",
                        f"Period: {_d(date_from)} – {_d(date_to)}", s, C)

    # ── GST on Sales section ──────────────────────────────────────────────────
    story.append(_ato_section_header("GST on Sales", s, C))
    story.append(_ato_field_row("G1",
        "Total sales (including any GST)",
        bas["G1_total_sales"], s, C, usable))
    story.append(_ato_field_row("1A",
        "GST on sales",
        bas["1A_GST_on_sales"], s, C, usable))
    story.append(Spacer(1, 4*mm))

    # ── GST on Purchases section ──────────────────────────────────────────────
    story.append(_ato_section_header("GST on Purchases", s, C))
    story.append(_ato_field_row("G11",
        "Non-capital purchases (including any GST)",
        bas["G11_total_purchases"], s, C, usable))
    story.append(_ato_field_row("1B",
        "GST on purchases",
        bas["1B_GST_on_purchases"], s, C, usable))
    story.append(Spacer(1, 4*mm))

    # ── PAYG Withholding (if payroll exists) ──────────────────────────────────
    story.append(_ato_section_header("PAYG Tax Withheld", s, C))
    story.append(_ato_field_row("W1",
        "Total salary, wages and other payments",
        None, s, C, usable))
    story.append(_ato_field_row("W2",
        "Amount withheld from salary, wages and other payments",
        None, s, C, usable))
    story.append(_ato_field_row("W3",
        "Amount withheld where no ABN is quoted",
        None, s, C, usable))
    story.append(_ato_field_row("W5",
        "Total amounts withheld (W2 + W3 + W4)",
        None, s, C, usable, is_total=True))
    story.append(Spacer(1, 4*mm))

    # ── Summary / Net amount ──────────────────────────────────────────────────
    story.append(_ato_section_header("Summary", s, C))
    gst_net = bas["GST_payable"]
    is_pay  = gst_net >= 0
    story.append(_ato_field_row("1A",
        "GST collected on sales",
        bas["1A_GST_on_sales"], s, C, usable))
    story.append(_ato_field_row("1B",
        "Less: GST credits on purchases",
        bas["1B_GST_on_purchases"], s, C, usable))

    story.extend(_ato_summary_box(
        [("GST on Sales (1A)",    bas["1A_GST_on_sales"]),
         ("Less GST Credits (1B)",bas["1B_GST_on_purchases"])],
        gst_net, is_pay, s, C))

    # ── Disclaimer note ───────────────────────────────────────────────────────
    note_tbl = Table([[Paragraph(
        "<b>Note:</b> W1/W2/W5 PAYG withholding fields appear on the ATO BAS form. "
        "Complete these from your payroll records or use the IAS report. "
        "Lodge your BAS via the ATO Business Portal or through a registered BAS agent.",
        s["note"])]], colWidths=[usable])
    note_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0),(-1,-1), C["note_bg"]),
        ("LINEABOVE",     (0,0),(-1, 0), 1.5, colors.HexColor("#F9A825")),
        ("TOPPADDING",    (0,0),(-1,-1), 7),
        ("BOTTOMPADDING", (0,0),(-1,-1), 7),
        ("LEFTPADDING",   (0,0),(-1,-1), 10),
        ("RIGHTPADDING",  (0,0),(-1,-1), 10),
    ]))
    story.append(note_tbl)
    story.extend(_ato_footer(co, "Business Activity Statement", s, C))

    doc.build(story, canvasmaker=_make_watermark_canvas(_wm_text, footer))
    return out_path


def render_ias_pdf(db_path, date_from, date_to, out_path=None, theme=None, watermark=None, footer=None):
    _wm_text = watermark
    """IAS — ATO Instalment Activity Statement layout."""
    from core.ledger import ias_report
    co  = _load_company(db_path)
    ias = ias_report(db_path, date_from, date_to)
    C   = _ato_colours()
    s   = _ato_styles()
    usable = W - 32*mm

    if out_path is None:
        out_path = os.path.join(tempfile.mkdtemp(), "ias.pdf")

    doc   = _make_doc(out_path)
    story = _ato_header(co, "Instalment Activity Statement",
                        "IAS  •  PAYG Withholding",
                        f"Period: {_d(date_from)} – {_d(date_to)}", s, C)

    # ── PAYG Withholding section ──────────────────────────────────────────────
    story.append(_ato_section_header(
        "Section 1 — PAYG Tax Withheld", s, C))
    story.append(_ato_field_row("W1",
        "Total salary, wages and other payments on which withholding was payable",
        ias["W1_total_wages"], s, C, usable))
    story.append(_ato_field_row("W2",
        "Amount withheld from salary, wages and other payments shown at W1",
        ias["W2_payg_withheld"], s, C, usable))
    story.append(_ato_field_row("W3",
        "Amount withheld where no ABN is quoted",
        ias["W3_no_abn_withholding"] or None, s, C, usable))
    story.append(_ato_field_row("W4",
        "Amount withheld from investment distributions where no TFN quoted",
        ias["W4_investment_withholding"] or None, s, C, usable))
    story.append(_ato_field_row("W5",
        "Total amounts withheld (W2 + W3 + W4)  — copy to field 4 in Summary",
        ias["W5_total_withheld"], s, C, usable, is_total=True))
    story.append(Spacer(1, 5*mm))

    # ── PAYG Income Tax Instalments ───────────────────────────────────────────
    story.append(_ato_section_header(
        "Section 2 — PAYG Income Tax Instalments (if applicable)", s, C))
    story.append(_ato_field_row("T1",
        "PAYG income tax instalment",
        ias["T1_tax_instalment"] or None, s, C, usable))
    story.append(Spacer(1, 5*mm))

    # ── Pay runs in period ────────────────────────────────────────────────────
    runs = ias.get("pay_runs", [])
    if runs:
        story.append(_ato_section_header("Pay Runs Included in This Period", s, C))
        rc  = ParagraphStyle("rc",  fontName="Helvetica",      fontSize=8, textColor=C["label_text"], leading=12)
        rv  = ParagraphStyle("rv",  fontName="Helvetica-Bold", fontSize=8, textColor=C["value_text"], leading=12, alignment=TA_RIGHT)
        rvr = ParagraphStyle("rvr", fontName="Helvetica-Bold", fontSize=8, textColor=C["negative"],   leading=12, alignment=TA_RIGHT)
        rh  = ParagraphStyle("rh",  fontName="Helvetica-Bold", fontSize=7.5, textColor=C["ato_blue"], leading=10)
        rhr = ParagraphStyle("rhr", fontName="Helvetica-Bold", fontSize=7.5, textColor=C["ato_blue"], leading=10, alignment=TA_RIGHT)

        # 5 columns: Run# | Period | Pay Date | Gross Pay | PAYG Tax
        run_widths = [28*mm, usable - 28*mm - 32*mm - 38*mm - 38*mm, 32*mm, 38*mm, 38*mm]

        run_data = [[
            Paragraph("Run #",     rh),
            Paragraph("Pay Period",rh),
            Paragraph("Pay Date",  rh),
            Paragraph("Gross Pay", rhr),
            Paragraph("PAYG Tax",  rhr),
        ]]
        for r in runs:
            period = f"{r.get('pay_period_start','')[:10]}  to  {r.get('pay_period_end','')[:10]}"
            run_data.append([
                Paragraph(r["run_number"],             rc),
                Paragraph(period,                      rc),
                Paragraph(r["payment_date"],           rc),
                Paragraph(f'${r["total_gross"]:,.2f}', rv),
                Paragraph(f'${r["total_tax"]:,.2f}',   rvr),
            ])

        run_tbl = Table(run_data, colWidths=run_widths, repeatRows=1)
        run_style = [
            ("BACKGROUND",    (0,0), (-1,0),   C["ato_light"]),
            ("LINEABOVE",     (0,0), (-1,0),   1, C["ato_blue"]),
            ("LINEBELOW",     (0,0), (-1,0),   1, C["ato_blue"]),
            ("BACKGROUND",    (0,1), (-1,-1),  C["form_bg"]),
            ("LINEBELOW",     (0,1), (-1,-2),  0.5, C["divider"]),
            ("TOPPADDING",    (0,0), (-1,-1),  5),
            ("BOTTOMPADDING", (0,0), (-1,-1),  5),
            ("LEFTPADDING",   (0,0), (-1,-1),  8),
            ("RIGHTPADDING",  (0,0), (-1,-1),  8),
            ("VALIGN",        (0,0), (-1,-1),  "MIDDLE"),
            ("BOX",           (0,0), (-1,-1),  1, C["field_bdr"]),
        ]
        for i in range(1, len(run_data)):
            if i % 2 == 0:
                run_style.append(("BACKGROUND",(0,i),(-1,i), C["field_bg"]))
        run_tbl.setStyle(TableStyle(run_style))
        story.append(run_tbl)
        story.append(Spacer(1, 5*mm))
    else:
        note = Table([[Paragraph(
            "No finalised pay runs found in this period. "
            "Finalise payroll in the Payroll module to populate W1 and W2.",
            s["note"])]], colWidths=[usable])
        note.setStyle(TableStyle([
            ("BACKGROUND",    (0,0),(-1,-1), C["note_bg"]),
            ("LINEABOVE",     (0,0),(-1, 0), 1.5, colors.HexColor("#F9A825")),
            ("TOPPADDING",    (0,0),(-1,-1), 7),
            ("BOTTOMPADDING", (0,0),(-1,-1), 7),
            ("LEFTPADDING",   (0,0),(-1,-1), 10),
            ("RIGHTPADDING",  (0,0),(-1,-1), 10),
        ]))
        story.append(note)
        story.append(Spacer(1, 5*mm))

    # ── Summary ───────────────────────────────────────────────────────────────
    story.append(_ato_section_header("Summary", s, C))
    story.append(_ato_field_row("4",
        "PAYG tax withheld  (copy of W5)",
        ias["W5_total_withheld"], s, C, usable))
    story.append(_ato_field_row("T1",
        "PAYG income tax instalment",
        ias["T1_tax_instalment"] or None, s, C, usable))

    net = ias["net_payable"]
    story.extend(_ato_summary_box(
        [("W5  PAYG withheld",    ias["W5_total_withheld"]),
         ("T1  Tax instalment",   ias["T1_tax_instalment"])],
        net, net >= 0, s, C))

    story.extend(_ato_footer(co, "Instalment Activity Statement", s, C))
    doc.build(story, canvasmaker=_make_watermark_canvas(_wm_text, footer))
    return out_path




def render_fa_register_pdf(db_path, out_path=None, theme=None, watermark=None, footer=None):
    """Fixed Asset Register PDF — styled identically to other financial reports."""
    from core.fixed_assets import asset_register_report
    C   = _pdf_palette(db_path, theme_name=theme)
    co  = _load_company(db_path)
    s   = _styles(C)
    rows = asset_register_report(db_path)

    if out_path is None:
        out_path = os.path.join(tempfile.mkdtemp(), "asset_register.pdf")

    doc   = _make_doc(out_path)
    story = _header_block(co, "Fixed Asset Register",
                          f"As at {_d(str(_date.today()))}", s, C)

    usable = W - 32*mm
    # Columns: No | Description | Category | Acquired | Cost | Method | Accum | WDV
    col_w = [18*mm, 40*mm, 20*mm, 18*mm, 22*mm, 20*mm, 20*mm, 20*mm]
    hdrs  = ["Asset No", "Description", "Category", "Acquired",
             "Cost (ex GST)", "Method", "Accum Depr", "Net WDV"]
    hdr_row = [Paragraph(h, s["col_hdr_r"] if i >= 4 else s["col_hdr"])
               for i, h in enumerate(hdrs)]

    data = [hdr_row]
    for a in rows:
        cost  = float(a.get("cost_excl_gst") or a.get("cost_price") or 0)
        accum = float(a.get("accum_depn", 0))
        wdv   = float(a.get("current_wdv", 0))
        status = a.get("status", "")
        # Dim disposed assets
        txt_color = C["MUTED"] if status == "Disposed" else C["TEXT"]
        def _p(v, align="left"):
            st = ParagraphStyle("_", fontName="Helvetica", fontSize=8,
                                textColor=txt_color, leading=11,
                                alignment=TA_RIGHT if align == "right" else TA_LEFT)
            return Paragraph(str(v), st)
        data.append([
            _p(a.get("asset_number") or f"#{a['id']}"),
            _p(a.get("description", "")),
            _p(a.get("category") or ""),
            _p(a.get("acquisition_date", "")),
            _p(_money(cost), "right"),
            _p(a.get("depn_method", "")),
            _p(_money(accum), "right"),
            _p(_money(wdv), "right"),
        ])

    tbl_style = [
        ("BACKGROUND",    (0, 0), (-1, 0),  C["HEADER_BG"]),
        ("LINEBELOW",     (0, 0), (-1, 0),  2, C["ACCENT"]),
        ("TOPPADDING",    (0, 0), (-1, 0),  6),
        ("BOTTOMPADDING", (0, 0), (-1, 0),  6),
        ("TOPPADDING",    (0, 1), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 4),
        ("LINEBELOW",     (0, 1), (-1, -2), 0.5, C["BORDER"]),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING",   (0, 0), (-1, -1), 5),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 5),
    ]
    for i in range(1, len(data)):
        if i % 2 == 0:
            tbl_style.append(("BACKGROUND", (0, i), (-1, i), C["ROW_ALT"]))

    tbl = Table(data, colWidths=col_w, repeatRows=1)
    tbl.setStyle(TableStyle(tbl_style))
    story.append(tbl)

    # Totals row
    total_cost  = sum(float(a.get("cost_excl_gst") or a.get("cost_price") or 0) for a in rows)
    total_accum = sum(float(a.get("accum_depn", 0)) for a in rows)
    total_wdv   = sum(float(a.get("current_wdv", 0)) for a in rows)
    story.append(Spacer(1, 2*mm))
    totals_tbl = Table([[
        Paragraph("<b>Totals</b>", ParagraphStyle("_", fontName="Helvetica-Bold",
                  fontSize=8, textColor=C["ACCENT"], leading=11)),
        "", "",
        Paragraph(f"<b>{len(rows)} assets</b>",
                  ParagraphStyle("_", fontName="Helvetica-Bold", fontSize=8,
                                 textColor=C["MUTED"], leading=11, alignment=TA_RIGHT)),
        Paragraph(f"<b>{_money(total_cost)}</b>",
                  ParagraphStyle("_", fontName="Helvetica-Bold", fontSize=8,
                                 textColor=C["ACCENT"], leading=11, alignment=TA_RIGHT)),
        "",
        Paragraph(f"<b>{_money(total_accum)}</b>",
                  ParagraphStyle("_", fontName="Helvetica-Bold", fontSize=8,
                                 textColor=C["ACCENT"], leading=11, alignment=TA_RIGHT)),
        Paragraph(f"<b>{_money(total_wdv)}</b>",
                  ParagraphStyle("_", fontName="Helvetica-Bold", fontSize=8,
                                 textColor=C["ACCENT"], leading=11, alignment=TA_RIGHT)),
    ]], colWidths=col_w)
    totals_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, 0), C["ACCENT_LT"]),
        ("LINEABOVE",     (0, 0), (-1, 0), 1.5, C["ACCENT"]),
        ("TOPPADDING",    (0, 0), (-1, 0), 5),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 5),
        ("LEFTPADDING",   (0, 0), (-1, 0), 5),
        ("RIGHTPADDING",  (0, 0), (-1, 0), 5),
        ("VALIGN",        (0, 0), (-1, 0), "MIDDLE"),
    ]))
    story.append(totals_tbl)
    story.extend(_footer(co, s, C))

    doc.build(story, canvasmaker=_make_watermark_canvas(watermark, footer))
    return out_path


def render_pl_html(db_path, date_from, date_to, **kw):
    return render_pl_pdf(db_path, date_from, date_to, **kw)
def render_bs_html(db_path, as_at_date=None, **kw):
    return render_bs_pdf(db_path, as_at_date, **kw)
def render_tb_html(db_path, **kw):
    return render_tb_pdf(db_path, **kw)
def render_bas_html(db_path, date_from, date_to, **kw):
    return render_bas_pdf(db_path, date_from, date_to, **kw)

# Legacy generate_* compat
def generate_pl_pdf(db_path, date_from, date_to, out_path=None, **kw):
    return render_pl_pdf(db_path, date_from, date_to, out_path, **kw)
def generate_bs_pdf(db_path, as_at_date, out_path=None, **kw):
    return render_bs_pdf(db_path, as_at_date, out_path, **kw)
def generate_tb_pdf(db_path, out_path=None, **kw):
    return render_tb_pdf(db_path, out_path, **kw)
def generate_bas_pdf(db_path, date_from, date_to, out_path=None, **kw):
    return render_bas_pdf(db_path, date_from, date_to, out_path, **kw)


def render_aged_pdf(db_path, as_at_date: str, report_type: str = "receivables",
                    out_path: str = None, theme=None, watermark=None, footer=None) -> str:
    _wm_text = watermark
    """
    Generate an Aged Receivables or Aged Payables PDF.
    report_type: "receivables" | "payables"
    """
    import tempfile, os
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib import colors as rl_colors
    from reportlab.lib.units import mm
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_RIGHT, TA_CENTER
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                     Table, TableStyle, HRFlowable,
                                     KeepTogether)
    from core.ledger import aged_receivables, aged_payables
    from core.database import get_connection

    fn = aged_receivables if report_type == "receivables" else aged_payables
    data = fn(db_path, as_at_date)

    conn = get_connection(db_path)
    co   = dict(conn.execute("SELECT * FROM company").fetchone() or {})
    conn.close()

    if out_path is None:
        label = "AR" if report_type == "receivables" else "AP"
        out_path = os.path.join(tempfile.mkdtemp(),
                                f"aged_{label}_{as_at_date}.pdf")

    C     = _pdf_palette(db_path, theme_name=theme)
    NAVY  = C["HEADER_BG"]
    BLUE  = C["ACCENT"]
    GREEN = C["ACCENT2"]
    RED   = C["DANGER"]
    AMBER = rl_colors.HexColor("#e67e22")   # fixed semantic — not in theme
    LTGR  = C["ROW_ALT"]
    WHITE = rl_colors.white
    DIM   = C["MUTED"]

    def sty(name, **kw):
        d = dict(fontName="Helvetica", fontSize=8, leading=11,
                 textColor=rl_colors.HexColor("#1a1a2e"))
        d.update(kw)
        return ParagraphStyle(name, **d)

    S = {
        "title": sty("t",  fontName="Helvetica-Bold", fontSize=13, textColor=NAVY),
        "h2":    sty("h2", fontName="Helvetica-Bold", fontSize=9,  textColor=NAVY),
        "body":  sty("bo"),
        "bold":  sty("bd", fontName="Helvetica-Bold"),
        "dim":   sty("dm", textColor=DIM, fontSize=7),
        "right": sty("ri", alignment=TA_RIGHT),
        "rbold": sty("rb", fontName="Helvetica-Bold", alignment=TA_RIGHT),
        "rred":  sty("rr", fontName="Helvetica-Bold", alignment=TA_RIGHT, textColor=RED),
        "ramb":  sty("ra", fontName="Helvetica-Bold", alignment=TA_RIGHT, textColor=AMBER),
        "rgrn":  sty("rg", fontName="Helvetica-Bold", alignment=TA_RIGHT, textColor=GREEN),
        "ctr":   sty("ct", alignment=TA_CENTER, fontSize=7, textColor=DIM),
    }

    def P(text, style="body"): return Paragraph(str(text or ""), S[style])
    def fmt(v):
        v = float(v or 0)
        return f"${v:,.2f}" if v else "—"
    def hdr(text, align="left"):
        return Paragraph(text, ParagraphStyle("hh",
            fontName="Helvetica-Bold", fontSize=7.5,
            textColor=WHITE, leading=10,
            alignment={"left":0,"right":2,"center":1}.get(align,0)))

    doc = SimpleDocTemplate(out_path, pagesize=landscape(A4),
                            leftMargin=12*mm, rightMargin=12*mm,
                            topMargin=10*mm, bottomMargin=10*mm)
    W   = 269*mm
    story = []

    # ── Header ────────────────────────────────────────────────────────────────
    title_text = ("AGED RECEIVABLES" if report_type == "receivables"
                  else "AGED PAYABLES")
    co_name    = co.get("name","") or "Company"
    abn        = co.get("abn","")

    hdr_tbl = Table([[
        Paragraph(f"{co_name}" + (f"\nABN: {abn}" if abn else ""),
                  ParagraphStyle("ch", fontName="Helvetica-Bold", fontSize=9,
                                 textColor=NAVY, leading=13)),
        Paragraph(f"{title_text}\nAs at {data['as_at']}",
                  ParagraphStyle("th", fontName="Helvetica-Bold", fontSize=13,
                                 textColor=NAVY, leading=17, alignment=2)),
    ]], colWidths=[W*0.5, W*0.5])
    hdr_tbl.setStyle(TableStyle([
        ("VALIGN",(0,0),(-1,-1),"BOTTOM"),
        ("BOTTOMPADDING",(0,0),(-1,-1),4),
    ]))
    story.append(hdr_tbl)
    story.append(HRFlowable(width="100%", thickness=2,
                             color=(BLUE if report_type=="receivables" else RED),
                             spaceAfter=3*mm))

    # ── Summary banner ────────────────────────────────────────────────────────
    tot    = data["totals"]
    b_lbls = ["Current", "1–30 days", "31–60 days", "61–90 days", "90+ days", "TOTAL"]
    b_keys = ["current", "b0", "b1", "b2", "b3", "total"]
    b_cols = [GREEN, AMBER, AMBER, RED, RED, NAVY]

    ban_hdr = [hdr(l, "center") for l in b_lbls]
    ban_val = []
    for key, col in zip(b_keys, b_cols):
        v = tot.get(key, 0)
        ban_val.append(Paragraph(fmt(v),
            ParagraphStyle("bv", fontName="Helvetica-Bold", fontSize=9,
                           textColor=col, alignment=1)))
    ban_tbl = Table([ban_hdr, ban_val],
                    colWidths=[W/6]*6)
    ban_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("BACKGROUND",(0,1),(-1,1),LTGR),
        ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
        ("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#ccd0e0")),
    ]))
    story.append(ban_tbl)
    story.append(Spacer(1,4*mm))

    # ── Per-contact rows ──────────────────────────────────────────────────────
    col_w = [W*0.22, W*0.10, W*0.10, W*0.10, W*0.10, W*0.10, W*0.10, W*0.18]
    doc_label = "Invoice" if report_type == "receivables" else "Bill"

    table_hdr = [
        hdr("Contact"),
        hdr("Current","right"),
        hdr("1–30 days","right"),
        hdr("31–60 days","right"),
        hdr("61–90 days","right"),
        hdr("90+ days","right"),
        hdr("Total","right"),
        hdr(f"Oldest {doc_label}","right"),
    ]

    table_rows = [table_hdr]
    rows_data  = data["rows"]

    for i, row in enumerate(rows_data):
        bg = WHITE if i % 2 == 0 else LTGR
        oldest_doc = ""
        inv_key = "invoices" if report_type == "receivables" else "bills"
        inv_date_key = "invoice_date" if report_type == "receivables" else "bill_date"
        inv_num_key  = "invoice_number" if report_type == "receivables" else "bill_number"
        invs = sorted(row.get(inv_key, []), key=lambda x: x["due_date"])
        if invs:
            oldest = invs[0]
            oldest_doc = (f"{oldest.get(inv_num_key,'')}  "
                          f"{oldest['due_date']}\n{fmt(oldest['owing'])}")

        def amt(key, warn=False):
            v = row[key]
            if v <= 0: return P("—","dim")
            style = "rred" if warn else "rbold"
            return P(fmt(v), style)

        table_rows.append([
            P(row["contact_name"], "bold"),
            amt("current"),
            amt("b0"),
            amt("b1", warn=True),
            amt("b2", warn=True),
            amt("b3", warn=True),
            P(fmt(row["total"]), "rbold"),
            P(oldest_doc, "dim"),
        ])

    # Totals row
    table_rows.append([
        P("TOTAL", "bold"),
        P(fmt(tot["current"]), "rgrn"),
        P(fmt(tot["b0"]),      "ramb"),
        P(fmt(tot["b1"]),      "ramb"),
        P(fmt(tot["b2"]),      "rred"),
        P(fmt(tot["b3"]),      "rred"),
        P(fmt(tot["total"]),   "rbold"),
        P("", "dim"),
    ])

    main_tbl = Table(table_rows, colWidths=col_w, repeatRows=1)
    main_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("ROWBACKGROUNDS",(0,1),(-1,-2),[WHITE, LTGR]),
        ("BACKGROUND",(0,-1),(-1,-1),rl_colors.HexColor("#e8ecf5")),
        ("LINEABOVE",(0,-1),(-1,-1),1,NAVY),
        ("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4),
        ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
        ("BOX",(0,0),(-1,-1),0.5,rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",(0,0),(-1,-1),0.25,rl_colors.HexColor("#dde0ea")),
        ("ALIGN",(1,0),(-1,-1),"RIGHT"),
        ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
    ]))
    story.append(main_tbl)

    # ── Footer ─────────────────────────────────────────────────────────────────
    story.append(Spacer(1,4*mm))
    story.append(HRFlowable(width="100%", thickness=0.5,
                             color=rl_colors.HexColor("#ccd0e0"), spaceAfter=2*mm))
    from datetime import datetime as _dt
    story.append(Paragraph(
        f"Generated {_dt.now().strftime('%d/%m/%Y %H:%M')}  •  {co_name}"
        + (f"  •  ABN {abn}" if abn else "")
        + f"  •  {len(rows_data)} contact(s)  •  CONFIDENTIAL",
        S["dim"]))

    doc.build(story, canvasmaker=_make_watermark_canvas(_wm_text, footer))
    return out_path


# ══════════════════════════════════════════════════════════════════════════════
#  CASH FLOW STATEMENT PDF
# ══════════════════════════════════════════════════════════════════════════════


def render_cash_flow_pdf(db_path: str, date_from: str, date_to: str,
                          out_path: str = None, theme=None, watermark=None, footer=None) -> str:
    _wm_text = watermark
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors as rl_colors
    from reportlab.lib.units import mm
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_RIGHT, TA_CENTER
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                     Table, TableStyle, HRFlowable)
    from core.ledger import cash_flow_statement
    from core.database import get_connection as _gc
    import tempfile
    if out_path is None:
        out_path = tempfile.mktemp(suffix="_cashflow.pdf")

    conn = _gc(db_path)
    co   = dict(conn.execute("SELECT * FROM company").fetchone() or {})
    conn.close()
    data = cash_flow_statement(db_path, date_from, date_to)

    C     = _pdf_palette(db_path, theme_name=theme)
    NAVY  = C["HEADER_BG"]
    GREEN = C["ACCENT2"]
    RED   = C["DANGER"]
    LTGR  = C["ROW_ALT"]
    WHITE = rl_colors.white
    DIM   = C["MUTED"]

    def sty(name, **kw):
        d = dict(fontName="Helvetica", fontSize=9, leading=13, textColor=NAVY)
        d.update(kw)
        return ParagraphStyle(name, **d)

    def P(txt, s="body"):
        _s = {
            "body":  sty("b"),
            "bold":  sty("bd", fontName="Helvetica-Bold"),
            "right": sty("r",  alignment=TA_RIGHT),
            "rbold": sty("rb", fontName="Helvetica-Bold", alignment=TA_RIGHT),
            "rpos":  sty("rp", fontName="Helvetica-Bold", alignment=TA_RIGHT, textColor=GREEN),
            "rneg":  sty("rn", fontName="Helvetica-Bold", alignment=TA_RIGHT, textColor=RED),
            "hdr":   sty("hh", fontName="Helvetica-Bold", fontSize=9, textColor=WHITE),
            "sect":  sty("sc", fontName="Helvetica-Bold", fontSize=10),
            "dim":   sty("dm", textColor=DIM, fontSize=7.5),
            "ctr":   sty("ct", alignment=TA_CENTER),
            "cbold": sty("cb", fontName="Helvetica-Bold", alignment=TA_CENTER),
        }
        return Paragraph(str(txt or ""), _s.get(s, _s["body"]))

    def money(v, bold=False):
        v = float(v or 0)
        s = "rbold" if bold else ("rpos" if v >= 0 else "rneg")
        txt = f"${v:,.2f}" if v >= 0 else f"(${abs(v):,.2f})"
        return P(txt, s)

    W   = 174*mm
    doc = SimpleDocTemplate(out_path, pagesize=A4,
                             leftMargin=18*mm, rightMargin=18*mm,
                             topMargin=15*mm, bottomMargin=15*mm)
    story = []
    co_name = co.get("name", "") or "Company"

    story.append(P(f"<b>{co_name}</b>", "bold"))
    story.append(P(f"<b>CASH FLOW STATEMENT</b>  —  {date_from} to {date_to}", "sect"))
    story.append(HRFlowable(width="100%", thickness=2, color=GREEN, spaceAfter=4*mm))

    # Summary banner (flat cells, no nested Tables)
    net = float(data["net_change"])
    net_color = GREEN if net >= 0 else RED
    net_txt = f"${net:,.2f}" if net >= 0 else f"(${abs(net):,.2f})"
    ban_data = [[
        Paragraph(f"<b>${data['opening_cash']:,.2f}</b><br/>Opening Cash",
                  sty("bc", fontName="Helvetica-Bold", alignment=TA_CENTER, leading=14)),
        Paragraph(f"<b>${data['closing_cash']:,.2f}</b><br/>Closing Cash",
                  sty("bc2", fontName="Helvetica-Bold", alignment=TA_CENTER, leading=14)),
        Paragraph(f"<b>{net_txt}</b><br/>Net Change",
                  sty("bc3", fontName="Helvetica-Bold", alignment=TA_CENTER, leading=14, textColor=net_color)),
        Paragraph(f"<b>${data['operating']['subtotal']:,.2f}</b><br/>From Operations",
                  sty("bc4", fontName="Helvetica-Bold", alignment=TA_CENTER, leading=14)),
    ]]
    ban = Table(ban_data, colWidths=[W/4]*4)
    ban.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, -1), LTGR),
        ("TOPPADDING",    (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("BOX",           (0, 0), (-1, -1), 0.5, rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",     (0, 0), (-1, -1), 0.25, rl_colors.HexColor("#ccd0e0")),
    ]))
    story.append(ban)
    story.append(Spacer(1, 5*mm))

    def section_table(title, section):
        rows = [[P(f"<b>{title}</b>", "hdr"), P("")]]
        for item in section["items"]:
            rows.append([P(f"    {item['label']}"), money(item["amount"])])
        rows.append([P(f"Net Cash from {title}", "bold"), money(section["subtotal"], bold=True)])
        tbl = Table(rows, colWidths=[W*0.72, W*0.28])
        n   = len(section["items"]) + 1
        tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0, 0),  (-1, 0),   NAVY),
            ("ROWBACKGROUNDS",(0, 1),  (-1, -2),  [WHITE, LTGR]),
            ("BACKGROUND",    (0, -1), (-1, -1),  rl_colors.HexColor("#e8ecf5")),
            ("LINEABOVE",     (0, -1), (-1, -1),  1, NAVY),
            ("TOPPADDING",    (0, 0),  (-1, -1),  4),
            ("BOTTOMPADDING", (0, 0),  (-1, -1),  4),
            ("LEFTPADDING",   (0, 0),  (-1, -1),  8),
            ("RIGHTPADDING",  (0, 0),  (-1, -1),  8),
            ("BOX",           (0, 0),  (-1, -1),  0.5, rl_colors.HexColor("#ccd0e0")),
        ]))
        return tbl

    story.append(section_table("Operating Activities", data["operating"]))
    story.append(Spacer(1, 4*mm))
    story.append(section_table("Investing Activities", data["investing"]))
    story.append(Spacer(1, 4*mm))
    story.append(section_table("Financing Activities", data["financing"]))
    story.append(Spacer(1, 4*mm))

    rec = Table([
        [P("Net increase / (decrease) in cash", "bold"), money(data["net_change"], bold=True)],
        [P("Opening cash balance"),                       money(data["opening_cash"])],
        [P("<b>Closing cash balance</b>", "bold"),        money(data["closing_cash"], bold=True)],
    ], colWidths=[W*0.72, W*0.28])
    rec.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, 0),  LTGR),
        ("LINEABOVE",     (0, 2), (-1, 2),  1.5, NAVY),
        ("TOPPADDING",    (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING",   (0, 0), (-1, -1), 8),
        ("BOX",           (0, 0), (-1, -1), 0.5, rl_colors.HexColor("#ccd0e0")),
    ]))
    story.append(rec)
    story.append(Spacer(1, 6*mm))
    from datetime import datetime as _dt
    story.append(P(f"Generated {_dt.now().strftime('%d/%m/%Y %H:%M')}  •  {co_name}  •  CONFIDENTIAL", "dim"))
    doc.build(story, canvasmaker=_make_watermark_canvas(_wm_text, footer))
    return out_path


def render_statement_of_account_pdf(db_path: str, contact_id: int,
                                     date_from: str = None,
                                     date_to: str = None,
                                     out_path: str = None,
                                     theme=None, watermark=None, footer=None) -> str:
    _wm_text = watermark
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors as rl_colors
    from reportlab.lib.units import mm
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_RIGHT, TA_CENTER
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                     Table, TableStyle, HRFlowable)
    from core.ledger import statement_of_account
    from core.database import get_connection as _gc
    import tempfile
    if out_path is None:
        out_path = tempfile.mktemp(suffix="_statement.pdf")

    conn = _gc(db_path)
    co   = dict(conn.execute("SELECT * FROM company").fetchone() or {})
    conn.close()
    data = statement_of_account(db_path, contact_id, date_from, date_to)
    if not data:
        raise ValueError("Contact not found")
    contact = data["contact"]

    C     = _pdf_palette(db_path, theme_name=theme)
    NAVY  = C["HEADER_BG"]
    GREEN = C["ACCENT2"]
    RED   = C["DANGER"]
    LTGR  = C["ROW_ALT"]
    WHITE = rl_colors.white
    DIM   = C["MUTED"]

    def sty(name, **kw):
        d = dict(fontName="Helvetica", fontSize=9, leading=12, textColor=NAVY)
        d.update(kw)
        return ParagraphStyle(name, **d)

    def P(txt, s="body"):
        _s = {
            "body":  sty("b"),
            "bold":  sty("bd", fontName="Helvetica-Bold"),
            "right": sty("r",  alignment=TA_RIGHT),
            "rbold": sty("rb", fontName="Helvetica-Bold", alignment=TA_RIGHT),
            "rpos":  sty("rp", fontName="Helvetica-Bold", alignment=TA_RIGHT, textColor=GREEN),
            "rneg":  sty("rn", fontName="Helvetica-Bold", alignment=TA_RIGHT, textColor=RED),
            "hdr":   sty("hh", fontName="Helvetica-Bold", fontSize=8.5, textColor=WHITE),
            "dim":   sty("dm", textColor=DIM, fontSize=7.5),
            "ctr":   sty("ct", alignment=TA_CENTER),
        }
        return Paragraph(str(txt or ""), _s.get(s, _s["body"]))

    def money_p(v, pos_style="right", neg_style="rneg"):
        v = float(v or 0)
        if v == 0:
            return P("")
        s = pos_style if v >= 0 else neg_style
        return P(f"${v:,.2f}", s)

    W   = A4[0] - 32*mm   # usable width for _make_doc (16 mm margins)
    doc = _make_doc(out_path)
    s   = _styles(C)

    period = f"{_d(date_from)} – {_d(date_to)}" if date_from and date_to else "All transactions"

    # ── Header: logo left, company info right-aligned ─────────────────────────
    logo_img = _logo_from_co(co)
    co_name  = co.get("name", "Your Company")
    co_abn   = co.get("abn", "")
    co_addr  = ", ".join(filter(None, [co.get("address"), co.get("city"),
                                        co.get("state"), co.get("postcode")]))
    co_phone = co.get("phone", "")
    co_email = co.get("email", "")

    co_lines = [f"<b>{co_name}</b>"]
    if co_abn:  co_lines.append(f"ABN: {co_abn}")
    if co_addr: co_lines.append(co_addr)
    co_contact = "  ".join(filter(None, [
        f"T: {co_phone}" if co_phone else "",
        f"E: {co_email}" if co_email else "",
    ]))
    if co_contact: co_lines.append(co_contact)

    co_info = Paragraph("<br/>".join(co_lines),
                        sty("co_r", fontSize=9, leading=13, alignment=TA_RIGHT))
    left_hdr_cell = logo_img if logo_img else Paragraph("", sty("_emp"))
    hdr_tbl = Table([[left_hdr_cell, co_info]], colWidths=[W * 0.45, W * 0.55])
    hdr_tbl.setStyle(TableStyle([
        ("VALIGN",        (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING",   (0, 0), (-1, -1), 0),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 0),
        ("TOPPADDING",    (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
    ]))
    story = [
        hdr_tbl,
        HRFlowable(width="100%", thickness=2, color=C["ACCENT"],
                   spaceAfter=5*mm, spaceBefore=3*mm),
    ]

    # ── Address / document-details block ──────────────────────────────────────
    # Left column: contact address sized for DL envelope window (~90 mm wide)
    to_lines = [f"<b>{contact['name']}</b>"]
    c_addr = ", ".join(filter(None, [contact.get("address"), contact.get("city"),
                                      contact.get("state"), contact.get("postcode")]))
    if c_addr: to_lines.append(c_addr)
    if contact.get("contact_person"): to_lines.append(contact.get("contact_person"))

    addr_block = [
        Paragraph("To", sty("to_lbl", fontSize=7, leading=10, textColor=DIM,
                              textTransform="uppercase")),
        Paragraph("<br/>".join(to_lines), sty("to_body", fontSize=9.5, leading=14)),
    ]

    # Right column: document title + period + timestamp (right-aligned)
    now = datetime.now()
    ts  = f"Generated {now.day} {now.strftime('%b %Y')} at {now.strftime('%I:%M %p')}"
    doc_block = [
        Paragraph("Statement of Account",
                  sty("doc_ttl", fontName="Helvetica-Bold", fontSize=14, leading=18,
                      alignment=TA_RIGHT)),
        Paragraph(f"Period: {period}",
                  sty("doc_per", fontSize=9, leading=13, textColor=DIM,
                      alignment=TA_RIGHT)),
        Paragraph(ts, sty("doc_ts", fontSize=7.5, leading=11, textColor=DIM,
                           alignment=TA_RIGHT)),
    ]

    ADDR_W = 90 * mm
    info_tbl = Table([[addr_block, doc_block]], colWidths=[ADDR_W, W - ADDR_W])
    info_tbl.setStyle(TableStyle([
        ("VALIGN",        (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING",   (0, 0), (-1, -1), 0),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 0),
        ("TOPPADDING",    (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
    ]))
    story.append(info_tbl)
    story.append(Spacer(1, 6*mm))

    bal = float(data["closing_balance"])
    bal_txt = f"${bal:,.2f}" if bal >= 0 else f"(${abs(bal):,.2f})"
    cash_total = float(data.get("total_cash_sales", 0))
    ban_cols = 4 if cash_total else 3
    ban_data_row = [
        Paragraph(f"<b>${data['total_invoiced']:,.2f}</b><br/>Total Invoiced",
                  sty("b1", fontName="Helvetica-Bold", alignment=TA_CENTER, leading=14)),
        Paragraph(f"<b>${data['total_received']:,.2f}</b><br/>Total Received",
                  sty("b2", fontName="Helvetica-Bold", alignment=TA_CENTER, leading=14)),
    ]
    if cash_total:
        ban_data_row.append(
            Paragraph(f"<b>${cash_total:,.2f}</b><br/>Cash Sales",
                      sty("b4", fontName="Helvetica-Bold", alignment=TA_CENTER, leading=14,
                          textColor=rl_colors.HexColor("#2980b9"))))
    ban_data_row.append(
        Paragraph(f"<b>{bal_txt}</b><br/>Balance Owing",
                  sty("b3", fontName="Helvetica-Bold", alignment=TA_CENTER, leading=14,
                      textColor=RED if bal > 0 else GREEN)))
    ban_data = [ban_data_row]
    ban = Table(ban_data, colWidths=[W/ban_cols]*ban_cols)
    ban.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, -1), LTGR),
        ("TOPPADDING",    (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("BOX",           (0, 0), (-1, -1), 0.5, rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",     (0, 0), (-1, -1), 0.25, rl_colors.HexColor("#ccd0e0")),
    ]))
    story.append(ban)
    story.append(Spacer(1, 4*mm))

    CASH_TINT = rl_colors.HexColor("#eaf4fb")
    col_w = [W*0.10, W*0.10, W*0.22, W*0.14, W*0.14, W*0.16, W*0.14]
    rows  = [[P(h, "hdr") for h in ("Date", "Due", "Reference", "Invoice", "Payment", "Balance", "Type/Status")]]

    opening_balance = float(data.get("opening_balance", 0))
    if date_from:
        ob_fmt = f"${opening_balance:,.2f}" if opening_balance >= 0 else f"(${abs(opening_balance):,.2f})"
        ob_style = "rneg" if opening_balance > 0 else "rpos"
        rows.append([P(""), P(""), P("Opening Balance", "bold"),
                     P(""), P(""), P(ob_fmt, ob_style), P("B/F", "dim")])

    # +1 for header row, +1 more if opening balance row was inserted
    _row_offset = 2 if date_from else 1
    cash_row_indices = []
    for i, txn in enumerate(data["transactions"]):
        bv = float(txn["balance"])
        type_label = txn["txn_type"] if txn.get("cash_sale") else txn["status"]
        rows.append([
            P(txn["date"]),
            P(txn.get("due_date") or ""),
            P(txn["ref"]),
            money_p(txn["debit"])  if txn["debit"]  else P(""),
            money_p(txn["credit"]) if txn["credit"] else P(""),
            P(f"${bv:,.2f}" if bv >= 0 else f"(${abs(bv):,.2f})",
              "rneg" if bv > 0 else "rpos"),
            P(type_label, "dim"),
        ])
        if txn.get("cash_sale"):
            cash_row_indices.append(i + _row_offset)

    tbl_style = [
        ("BACKGROUND",    (0, 0),  (-1, 0),  NAVY),
        ("ROWBACKGROUNDS",(0, 1),  (-1, -1), [WHITE, LTGR]),
        ("TOPPADDING",    (0, 0),  (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0),  (-1, -1), 4),
        ("LEFTPADDING",   (0, 0),  (-1, -1), 4),
        ("BOX",           (0, 0),  (-1, -1), 0.5, rl_colors.HexColor("#ccd0e0")),
        ("INNERGRID",     (0, 0),  (-1, -1), 0.25, rl_colors.HexColor("#dde0ea")),
    ]
    for ri in cash_row_indices:
        tbl_style.append(("BACKGROUND", (0, ri), (-1, ri), CASH_TINT))

    tbl = Table(rows, colWidths=col_w, repeatRows=1)
    tbl.setStyle(TableStyle(tbl_style))
    story.append(tbl)
    story.append(Spacer(1, 5*mm))
    if bal > 0:
        story.append(P(f"<b>Amount outstanding: ${bal:,.2f}</b>  — Please arrange payment.", "bold"))
    else:
        story.append(P("Your account is up to date. Thank you for your business.", "bold"))
    story.extend(_footer(co, s, C))
    doc.build(story, canvasmaker=_make_watermark_canvas(_wm_text, footer))
    return out_path


# ── Tax Return Summary PDF ──────────────────────────────────────────────────

def render_tax_pdf(db_path, date_from, date_to, out_path=None,
                   basis="accrual", theme=None, watermark=None, footer=None):
    _wm_text = watermark
    from core.ledger import tax_return_summary
    C  = _pdf_palette(db_path, theme_name=theme)
    co = _load_company(db_path)
    d  = tax_return_summary(db_path, date_from, date_to, basis=basis)
    s  = _styles(C)

    if out_path is None:
        out_path = os.path.join(tempfile.mkdtemp(), "tax_return_summary.pdf")

    doc        = _make_doc(out_path)
    basis_label = "Cash Basis" if basis == "cash" else "Accrual Basis"
    fy_label    = f"Period {_d(date_from)} – {_d(date_to)}"
    story = _header_block(co, "Tax Return Summary",
                          f"{fy_label}  •  {basis_label}", s, C)

    def _section(label, items, amt_key="amount"):
        active = [r for r in items if abs(float(r.get(amt_key, 0) or 0)) >= 0.005]
        if not active:
            return 0.0
        total = sum(float(r.get(amt_key, 0) or 0) for r in active)
        rows  = [[
            Paragraph(r.get("code", ""), s["code"]),
            Paragraph(r.get("name", ""), s["body"]),
            Paragraph(_money(float(r.get(amt_key, 0) or 0)),
                      s["neg_b"] if float(r.get(amt_key, 0) or 0) < 0 else s["body_rb"]),
        ] for r in active]
        story.extend(_section_label(label, s, C))
        story.append(_account_table(rows, s, C=C))
        story.append(_subtotal_row(f"Total {label}", total, s, C=C))
        story.append(Spacer(1, 3*mm))
        return total

    # Income
    tot_inc = _section("Business Income", d.get("income", []))
    tot_cos = _section("Cost of Sales",   d.get("cost_of_sales", []))
    if d.get("cost_of_sales"):
        gross = tot_inc - tot_cos
        story.extend(_section_label("Gross Profit", s, C))
        story.append(_subtotal_row("Gross Profit", gross, s,
                                   color=C["ACCENT2"], bg=C["GREEN_LT"], C=C))
        story.append(Spacer(1, 3*mm))
    else:
        gross = tot_inc

    # ATO expense categories
    tot_exp = 0.0
    for grp in d.get("expense_groups", []):
        label    = grp["label"]
        accounts = grp["accounts"]
        subtotal = float(grp["total"])
        if not accounts:
            continue
        rows = [[
            Paragraph(a.get("code", ""), s["code"]),
            Paragraph(a.get("name", ""), s["body"]),
            Paragraph(_money(float(a.get("amount", 0) or 0)),
                      s["neg_b"] if float(a.get("amount", 0) or 0) < 0 else s["body_rb"]),
        ] for a in accounts if abs(float(a.get("amount", 0) or 0)) >= 0.005]
        if not rows:
            continue
        story.extend(_section_label(label, s, C))
        story.append(_account_table(rows, s, C=C))
        story.append(_subtotal_row(f"Total {label}", subtotal, s, C=C))
        story.append(Spacer(1, 3*mm))
        tot_exp += subtotal

    net = gross - tot_exp
    grand_color = C["ACCENT2"] if net >= 0 else C["DANGER"]
    net_label   = "Net Profit" if net >= 0 else "Net Loss"
    story.extend(_total_bar(
        [("Total Income", tot_inc), ("Total Expenses", tot_exp)],
        net_label, net, grand_color=grand_color, s=s, C=C))

    # GST Summary
    gst = d.get("gst", {})
    _1a = float(gst.get("1A_GST_on_sales", 0))
    _1b = float(gst.get("1B_GST_on_purchases", 0))
    net_gst = float(gst.get("GST_payable", 0))
    story.append(Spacer(1, 6*mm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=C["BORDER"]))
    story.append(Spacer(1, 4*mm))
    story.extend(_section_label("GST Summary", s, C))
    gst_rows = [
        [Paragraph("G1",  s["code"]), Paragraph("Total Sales / Gross Income", s["body"]),
         Paragraph(_money(float(gst.get("G1_total_sales", 0))), s["body_rb"])],
        [Paragraph("1A",  s["code"]), Paragraph("GST on Sales (GST Collected)", s["body"]),
         Paragraph(_money(_1a), s["body_rb"])],
        [Paragraph("1B",  s["code"]), Paragraph("GST on Purchases (GST Paid)", s["body"]),
         Paragraph(_money(_1b), s["body_rb"])],
    ]
    story.append(_account_table(gst_rows, s, C=C))
    net_gst_color = C["DANGER"] if net_gst > 0 else C["ACCENT2"]
    net_gst_label = "GST Payable to ATO" if net_gst > 0 else "GST Refund Due"
    story.append(_subtotal_row(net_gst_label, abs(net_gst), s,
                               color=net_gst_color, bg=C.get("GREEN_LT", C["SURFACE"]), C=C))
    story.append(Spacer(1, 3*mm))

    story.extend(_footer(co, s, C))
    doc.build(story, canvasmaker=_make_watermark_canvas(_wm_text, footer))


# ── P&L Monthly (landscape, months as columns) ────────────────────────────────

def render_pl_monthly_pdf(data, date_from, date_to, basis="accrual",
                           db_path=None, theme=None, out_path=None,
                           watermark=None, footer=None):
    """Landscape A4 monthly P&L — one column per calendar month."""
    C  = _pdf_palette(db_path, theme_name=theme) if db_path else _default_C()
    co = _load_company(db_path) if db_path else {}
    s  = _styles(C)

    if out_path is None:
        out_path = os.path.join(tempfile.mkdtemp(), "pl_monthly.pdf")

    W_L, _H_L = _landscape(A4)
    doc = SimpleDocTemplate(
        out_path,
        pagesize=_landscape(A4),
        leftMargin=16*mm, rightMargin=16*mm,
        topMargin=14*mm,  bottomMargin=14*mm,
    )

    basis_label = "Cash Basis" if basis == "cash" else "Accrual Basis"
    story = _header_block(co, "Profit & Loss — Monthly",
                           f"{_d(date_from)} – {_d(date_to)}  ·  {basis_label}",
                           s, C, page_width=W_L)

    months = data.get("months", [])
    n      = len(months)
    if n == 0:
        story.extend(_footer(co, s, C))
        doc.build(story, canvasmaker=_make_watermark_canvas(watermark, footer))
        return out_path

    # Column widths
    usable  = W_L - 32*mm
    code_w  = 11*mm
    total_w = 30*mm
    month_w = max(14*mm, (usable - code_w - total_w - 50*mm) / n)
    name_w  = usable - code_w - n * month_w - total_w
    col_widths = [code_w, name_w] + [month_w] * n + [total_w]
    n_cols = len(col_widths)

    # Adaptive font size: smaller for more months
    fs = 8.0 if n <= 6 else (7.0 if n > 9 else 7.5)
    ld = fs + 3.0

    # Style cache — avoids duplicate ParagraphStyle registration
    _sfx = id(C)
    _sc  = {}

    def _ps(bold, color, align=TA_LEFT):
        fname = "Helvetica-Bold" if bold else "Helvetica"
        key   = "plm_{}_{}_{}_{}".format(fname, id(color), align, _sfx)
        if key not in _sc:
            _sc[key] = ParagraphStyle(key, fontName=fname, fontSize=fs,
                                       textColor=color, leading=ld, alignment=align)
        return _sc[key]

    _ck = "plm_code_{}".format(_sfx)
    if _ck not in _sc:
        _sc[_ck] = ParagraphStyle(_ck, fontName="Courier",
                                   fontSize=max(fs - 1.0, 6.0),
                                   textColor=C["MUTED"], leading=ld)

    p_code  = _sc[_ck]
    p_name  = _ps(False, C["TEXT"])
    p_hdr   = _ps(True,  C["HEADER_TEXT"])
    p_hdr_r = _ps(True,  C["HEADER_TEXT"], TA_RIGHT)
    p_sec   = _ps(True,  C["HEADER_TEXT"])
    p_amt   = _ps(False, C["TEXT"],    TA_RIGHT)
    p_amtb  = _ps(True,  C["TEXT"],    TA_RIGHT)
    p_neg   = _ps(False, RED,          TA_RIGHT)
    p_negb  = _ps(True,  RED,          TA_RIGHT)
    p_sub   = _ps(True,  C["ACCENT"],  TA_LEFT)
    p_subr  = _ps(True,  C["ACCENT"],  TA_RIGHT)
    p_gp    = _ps(True,  C["ACCENT2"], TA_LEFT)
    p_gpr   = _ps(True,  C["ACCENT2"], TA_RIGHT)

    def _mshort(v):
        """Short money — no cents, parens for negatives."""
        if v is None:
            return "—"
        v = float(v)
        if abs(v) < 0.5:
            return "—"
        s_val = "${:,.0f}".format(abs(v))
        return "({})".format(s_val) if v < 0 else s_val

    rows   = []
    tstyle = []

    # Table header row
    hdr = [Paragraph("Code", p_hdr), Paragraph("Account", p_hdr)]
    for m in months:
        hdr.append(Paragraph(m, p_hdr_r))
    hdr.append(Paragraph("Total", p_hdr_r))
    rows.append(hdr)

    def _sec_row(label):
        ri = len(rows)
        rows.append([Paragraph(label, p_sec)] + [""] * (n_cols - 1))
        tstyle.extend([
            ("SPAN",          (0, ri), (-1, ri)),
            ("BACKGROUND",    (0, ri), (-1, ri), C["HEADER_BG"]),
            ("TOPPADDING",    (0, ri), (-1, ri), 4),
            ("BOTTOMPADDING", (0, ri), (-1, ri), 4),
            ("LEFTPADDING",   (0, ri), (-1, ri), 8),
            ("LINEABOVE",     (0, ri), (-1, ri), 0.5, C["BORDER"]),
        ])

    def _acc_row(r):
        amounts = r.get("amounts", [])
        total   = float(r.get("total", 0) or 0)
        row = [Paragraph(r.get("code", "") or "", p_code),
               Paragraph(r.get("name", "") or "", p_name)]
        for amt in amounts:
            a = float(amt or 0)
            row.append(Paragraph(_mshort(a), p_neg if a < 0 else p_amt))
        row.append(Paragraph(_money(total), p_negb if total < 0 else p_amtb))
        rows.append(row)

    def _sub_row(label, col_amounts, grand, pl, pr, bg):
        ri = len(rows)
        row = ["", Paragraph(label, pl)]
        for amt in col_amounts:
            row.append(Paragraph(_mshort(float(amt or 0)), pr))
        row.append(Paragraph(_money(float(grand or 0)), pr))
        rows.append(row)
        color = pl.textColor
        tstyle.extend([
            ("BACKGROUND",    (0, ri), (-1, ri), bg),
            ("LINEABOVE",     (0, ri), (-1, ri), 1.5, color),
            ("LINEBELOW",     (0, ri), (-1, ri), 1.5, color),
            ("TOPPADDING",    (0, ri), (-1, ri), 5),
            ("BOTTOMPADDING", (0, ri), (-1, ri), 5),
        ])

    # Income section
    income_rows = data.get("income", [])
    if income_rows:
        _sec_row("Income")
        for r in income_rows:
            _acc_row(r)
        _sub_row("Total Income",
                  data.get("total_income", []), data.get("grand_income", 0),
                  p_sub, p_subr, C["ACCENT_LT"])

    # Cost of Sales section
    cos_rows_data = data.get("cost_of_sales", [])
    if cos_rows_data:
        _sec_row("Cost of Sales")
        for r in cos_rows_data:
            _acc_row(r)
        _sub_row("Total Cost of Sales",
                  data.get("total_cos", []), data.get("grand_cos", 0),
                  p_sub, p_subr, C["ACCENT_LT"])
        _sub_row("Gross Profit",
                  data.get("gross_profit", []), data.get("grand_gross_profit", 0),
                  p_gp, p_gpr, C["GREEN_LT"])

    # Expenses section
    expense_rows = data.get("expenses", [])
    if expense_rows:
        _sec_row("Expenses")
        for r in expense_rows:
            _acc_row(r)
        _sub_row("Total Expenses",
                  data.get("total_expenses", []), data.get("grand_expenses", 0),
                  p_sub, p_subr, C["ACCENT_LT"])

    # Net Profit / Net Loss row
    grand_net = float(data.get("grand_net_profit", 0) or 0)
    net_color = C["ACCENT2"] if grand_net >= 0 else C["DANGER"]
    net_bg    = C["GREEN_LT"] if grand_net >= 0 else C["RED_LT"]
    net_label = "Net Profit" if grand_net >= 0 else "Net Loss"
    p_net_l   = _ps(True, net_color, TA_LEFT)
    p_net_r   = _ps(True, net_color, TA_RIGHT)
    _sub_row(net_label, data.get("net_profit", []), grand_net,
              p_net_l, p_net_r, net_bg)

    # Assemble table
    base_style = [
        ("BACKGROUND",    (0, 0), (-1, 0), C["HEADER_BG"]),
        ("LINEBELOW",     (0, 0), (-1, 0), 2,   C["ACCENT"]),
        ("TOPPADDING",    (0, 0), (-1, 0), 5),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 5),
        ("FONTNAME",      (0, 0), (-1, -1), "Helvetica"),
        ("FONTSIZE",      (0, 0), (-1, -1), fs),
        ("TEXTCOLOR",     (0, 1), (-1, -1), C["TEXT"]),
        ("TOPPADDING",    (0, 1), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 3),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING",   (0, 0), (-1, -1), 4),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 4),
        ("ALIGN",         (2, 0), (-1, -1), "RIGHT"),
        ("LINEBELOW",     (0, 1), (-1, -2), 0.3, C["BORDER"]),
    ]
    for i in range(1, len(rows)):
        if i % 2 == 0:
            base_style.append(("BACKGROUND", (0, i), (-1, i), C["ROW_ALT"]))
    base_style.extend(tstyle)  # section/subtotal overrides win

    tbl = Table(rows, colWidths=col_widths, repeatRows=1)
    tbl.setStyle(TableStyle(base_style))
    story.append(tbl)
    story.append(Spacer(1, 4*mm))
    story.extend(_footer(co, s, C))

    doc.build(story, canvasmaker=_make_watermark_canvas(watermark, footer))
    return out_path


# ── Budget vs Actual ──────────────────────────────────────────────────────────

def render_budget_pdf(data, db_path=None, theme=None, out_path=None,
                      watermark=None, footer=None):
    """Portrait A4 Budget vs Actual report — accounts grouped by type."""
    C  = _pdf_palette(db_path, theme_name=theme) if db_path else _default_C()
    co = _load_company(db_path) if db_path else {}
    s  = _styles(C)

    if out_path is None:
        out_path = os.path.join(tempfile.mkdtemp(), "budget_vs_actual.pdf")

    doc = _make_doc(out_path)

    period      = data.get("period") or {}
    period_name = period.get("name", "Budget")
    df          = data.get("date_from") or ""
    dt          = data.get("date_to")   or ""
    sub         = period_name
    if df or dt:
        sub += "  ·  {} – {}".format(_d(df) if df else "—", _d(dt) if dt else "—")

    story = _header_block(co, "Budget vs Actual", sub, s, C)

    rows = data.get("rows", [])
    if not rows:
        story.append(Paragraph("No data for this budget period.", s["body"]))
        story.extend(_footer(co, s, C))
        doc.build(story, canvasmaker=_make_watermark_canvas(watermark, footer))
        return out_path

    # Group rows by account_type, preserving order
    sections, sec_order = {}, []
    for r in rows:
        t = r.get("account_type", "Other")
        if t not in sections:
            sections[t] = []
            sec_order.append(t)
        sections[t].append(r)

    usable    = W - 32*mm
    code_w    = 14*mm
    vp_w      = 17*mm
    amt_w     = 27*mm
    name_w    = usable - code_w - 3*amt_w - vp_w
    col_widths = [code_w, name_w, amt_w, amt_w, amt_w, vp_w]
    n_cols    = 6

    # Reusable right-aligned muted style for Var %
    _sfx = id(C)
    _vp_key = "bvap_vp_{}".format(_sfx)
    _vp_neg_key = "bvap_vp_neg_{}".format(_sfx)
    _sc = {}
    def _cached_ps(key, **kw):
        if key not in _sc:
            _sc[key] = ParagraphStyle(key, **kw)
        return _sc[key]

    p_vp     = _cached_ps(_vp_key,     fontName="Helvetica",      fontSize=8,
                           textColor=C["MUTED"], leading=12, alignment=TA_RIGHT)
    p_vp_neg = _cached_ps(_vp_neg_key, fontName="Helvetica-Bold", fontSize=8,
                           textColor=RED, leading=12, alignment=TA_RIGHT)
    p_var_pos = _cached_ps("bvap_vpos_{}".format(_sfx), fontName="Helvetica-Bold",
                            fontSize=9, textColor=C["ACCENT2"], leading=13, alignment=TA_RIGHT)
    p_var_neg = _cached_ps("bvap_vneg_{}".format(_sfx), fontName="Helvetica-Bold",
                            fontSize=9, textColor=C["DANGER"], leading=13, alignment=TA_RIGHT)
    p_sub_lbl = _cached_ps("bvap_sublbl_{}".format(_sfx), fontName="Helvetica-Bold",
                            fontSize=9, textColor=C["ACCENT"], leading=13)
    p_sub_amt = _cached_ps("bvap_subamt_{}".format(_sfx), fontName="Helvetica-Bold",
                            fontSize=9, textColor=C["ACCENT"], leading=13, alignment=TA_RIGHT)

    tbl_rows = []
    tstyle   = []

    # Header row
    tbl_rows.append([
        Paragraph("Code",     s["col_hdr"]),
        Paragraph("Account",  s["col_hdr"]),
        Paragraph("Budget",   s["col_hdr_r"]),
        Paragraph("Actual",   s["col_hdr_r"]),
        Paragraph("Variance", s["col_hdr_r"]),
        Paragraph("Var %",    s["col_hdr_r"]),
    ])

    # Income types contribute positively; expense types are subtracted for the net
    _INCOME_TYPES = {"Revenue", "Income"}

    grand_bud = grand_act = 0.0

    for stype in sec_order:
        srows = sections[stype]
        is_income = stype in _INCOME_TYPES

        # Section header
        ri = len(tbl_rows)
        tbl_rows.append([Paragraph(stype, s["section"])] + [""] * (n_cols - 1))
        tstyle.extend([
            ("SPAN",          (0, ri), (-1, ri)),
            ("BACKGROUND",    (0, ri), (-1, ri), C["HEADER_BG"]),
            ("TOPPADDING",    (0, ri), (-1, ri), 4),
            ("BOTTOMPADDING", (0, ri), (-1, ri), 4),
            ("LEFTPADDING",   (0, ri), (-1, ri), 8),
            ("LINEABOVE",     (0, ri), (-1, ri), 0.5, C["BORDER"]),
        ])

        tot_b = tot_a = tot_v = 0.0
        for r in srows:
            bud = float(r.get("total_budget",   0) or 0)
            act = float(r.get("total_actual",   0) or 0)
            var = float(r.get("total_variance", 0) or 0)
            vp  = float(r.get("total_variance_pct", 0) or 0)
            tot_b += bud; tot_a += act; tot_v += var
            tbl_rows.append([
                Paragraph(r.get("code", "") or "", s["code"]),
                Paragraph(r.get("name", "") or "", s["body"]),
                Paragraph(_money(bud), s["body_rb"]),
                Paragraph(_money(act), s["body_rb"]),
                Paragraph(_money(var), p_var_pos if var >= 0 else p_var_neg),
                Paragraph("{:.1f}%".format(vp), p_vp if var >= 0 else p_vp_neg),
            ])

        # Section subtotal
        tot_vp = (tot_v / tot_b * 100) if tot_b else 0.0
        ri = len(tbl_rows)
        tbl_rows.append([
            "",
            Paragraph("Total {}".format(stype), p_sub_lbl),
            Paragraph(_money(tot_b), p_sub_amt),
            Paragraph(_money(tot_a), p_sub_amt),
            Paragraph(_money(tot_v), p_var_pos if tot_v >= 0 else p_var_neg),
            Paragraph("{:.1f}%".format(tot_vp), p_vp if tot_v >= 0 else p_vp_neg),
        ])
        tstyle.extend([
            ("BACKGROUND",    (0, ri), (-1, ri), C["ACCENT_LT"]),
            ("LINEABOVE",     (0, ri), (-1, ri), 1.5, C["ACCENT"]),
            ("LINEBELOW",     (0, ri), (-1, ri), 1.5, C["ACCENT"]),
            ("TOPPADDING",    (0, ri), (-1, ri), 5),
            ("BOTTOMPADDING", (0, ri), (-1, ri), 5),
        ])
        # Net: income adds, expenses subtract
        if is_income:
            grand_bud += tot_b; grand_act += tot_a
        else:
            grand_bud -= tot_b; grand_act -= tot_a

    # Net Profit grand row (income minus expenses)
    grand_var   = grand_act - grand_bud
    grand_vp    = (grand_var / abs(grand_bud) * 100) if grand_bud else 0.0
    grand_color = C["ACCENT2"] if grand_act >= 0 else C["DANGER"]
    net_label   = "Net Profit" if grand_act >= 0 else "Net Loss"
    _gkey   = "bvap_grand_{}".format(_sfx)
    _gkey_r = "bvap_grandr_{}".format(_sfx)
    p_g     = _cached_ps(_gkey,   fontName="Helvetica-Bold", fontSize=10,
                          textColor=WHITE, leading=14)
    p_gr    = _cached_ps(_gkey_r, fontName="Helvetica-Bold", fontSize=10,
                          textColor=WHITE, leading=14, alignment=TA_RIGHT)
    ri = len(tbl_rows)
    tbl_rows.append([
        "",
        Paragraph(net_label, p_g),
        Paragraph(_money(grand_bud), p_gr),
        Paragraph(_money(grand_act), p_gr),
        Paragraph(_money(grand_var), p_gr),
        Paragraph("{:.1f}%".format(grand_vp), p_gr),
    ])
    tstyle.extend([
        ("BACKGROUND",    (0, ri), (-1, ri), grand_color),
        ("TOPPADDING",    (0, ri), (-1, ri), 8),
        ("BOTTOMPADDING", (0, ri), (-1, ri), 8),
    ])

    # Assemble
    base_style = [
        ("BACKGROUND",    (0, 0), (-1, 0), C["HEADER_BG"]),
        ("LINEBELOW",     (0, 0), (-1, 0), 2, C["ACCENT"]),
        ("TOPPADDING",    (0, 0), (-1, 0), 5),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 5),
        ("FONTNAME",      (0, 0), (-1, -1), "Helvetica"),
        ("FONTSIZE",      (0, 0), (-1, -1), 9),
        ("TEXTCOLOR",     (0, 1), (-1, -1), C["TEXT"]),
        ("TOPPADDING",    (0, 1), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 4),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING",   (0, 0), (-1, -1), 6),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 6),
        ("ALIGN",         (2, 0), (-1, -1), "RIGHT"),
        ("LINEBELOW",     (0, 1), (-1, -2), 0.3, C["BORDER"]),
    ]
    for i in range(1, len(tbl_rows)):
        if i % 2 == 0:
            base_style.append(("BACKGROUND", (0, i), (-1, i), C["ROW_ALT"]))
    base_style.extend(tstyle)

    tbl = Table(tbl_rows, colWidths=col_widths, repeatRows=1)
    tbl.setStyle(TableStyle(base_style))
    story.append(tbl)
    story.append(Spacer(1, 4*mm))
    story.extend(_footer(co, s, C))

    doc.build(story, canvasmaker=_make_watermark_canvas(watermark, footer))
    return out_path


# ── Jobs Summary Report ────────────────────────────────────────────────────────

def render_jobs_pdf(data, date_from=None, date_to=None, db_path=None,
                    out_path=None, theme=None, watermark=None, footer=None):
    """Landscape A4 jobs summary table."""
    if out_path is None:
        out_path = os.path.join(tempfile.mkdtemp(), "jobs_report.pdf")

    C  = _pdf_palette(db_path, theme)
    s  = _styles(C)
    co = _load_company(db_path) if db_path else {}

    W_L, _H = _landscape(A4)
    doc = SimpleDocTemplate(
        out_path,
        pagesize=_landscape(A4),
        leftMargin=16*mm, rightMargin=16*mm,
        topMargin=14*mm,  bottomMargin=14*mm,
    )

    if date_from and date_to:
        period = f"{_d(date_from)} – {_d(date_to)}"
    elif date_from:
        period = f"From {_d(date_from)}"
    elif date_to:
        period = f"To {_d(date_to)}"
    else:
        period = "All jobs"

    story = _header_block(co, "Jobs Summary", period, s, C, page_width=W_L)

    rows = data.get("rows", [])
    summary = data.get("summary", {})

    # ── styles ─────────────────────────────────────────────────────────────────
    fs, ld = 8.0, 11.0
    _sfx = id(C)

    def _ps(bold=False, align=TA_LEFT, color=None):
        fname = "Helvetica-Bold" if bold else "Helvetica"
        col   = color or C["TEXT"]
        key   = f"jr_{fname}_{id(col)}_{align}_{_sfx}"
        if key not in _ps.__dict__:
            _ps.__dict__[key] = ParagraphStyle(
                key, fontName=fname, fontSize=fs,
                textColor=col, leading=ld, alignment=align)
        return _ps.__dict__[key]

    def P(txt, style=None):
        return Paragraph(str(txt), style or _ps())

    def money(v):
        if v is None or v == "" or v == 0:
            return P("—", _ps(align=TA_RIGHT))
        return P(f"${v:,.0f}", _ps(align=TA_RIGHT))

    def money_bold(v):
        if v is None:
            v = 0
        return P(f"${v:,.0f}", _ps(bold=True, align=TA_RIGHT))

    # ── column widths (landscape usable ≈ 261 mm) ─────────────────────────────
    usable = W_L - 32*mm
    col_w = {
        "job":     18*mm,
        "client":  42*mm,
        "name":    62*mm,
        "stage":   20*mm,
        "owner":   28*mm,
        "start":   18*mm,
        "value":   22*mm,
        "invoiced":22*mm,
        "costs":   18*mm,
        "margin":  22*mm,
    }
    col_widths = list(col_w.values())

    # ── header row ─────────────────────────────────────────────────────────────
    hdr_style = _ps(bold=True)
    hdr_r     = _ps(bold=True, align=TA_RIGHT)
    headers   = [
        Paragraph("Job #",     hdr_style),
        Paragraph("Client",    hdr_style),
        Paragraph("Name",      hdr_style),
        Paragraph("Stage",     hdr_style),
        Paragraph("Owner",     hdr_style),
        Paragraph("Start",     hdr_style),
        Paragraph("Value",     hdr_r),
        Paragraph("Invoiced",  hdr_r),
        Paragraph("Costs",     hdr_r),
        Paragraph("Margin",    hdr_r),
    ]

    # ── data rows ──────────────────────────────────────────────────────────────
    tbl_rows = [headers]
    for r in rows:
        invoiced = r.get("total_invoiced") or 0
        costs    = r.get("total_costs") or 0
        margin   = invoiced - costs
        tbl_rows.append([
            P(r.get("job_number","") or ""),
            P(r.get("contact_name","") or ""),
            P(r.get("name","") or ""),
            P(r.get("stage","") or ""),
            P(r.get("owner","") or ""),
            P(r.get("start_date","") or ""),
            money(r.get("value")),
            money(invoiced),
            money(costs),
            money(margin),
        ])

    # ── totals row ─────────────────────────────────────────────────────────────
    tbl_rows.append([
        Paragraph("TOTALS", _ps(bold=True)),
        P(""),
        P(f"{summary.get('count',0)} jobs", _ps(bold=True)),
        P(""), P(""), P(""),
        money_bold(summary.get("total_value")),
        money_bold(summary.get("total_invoiced")),
        money_bold(summary.get("total_costs")),
        money_bold(summary.get("total_margin")),
    ])

    n_data = len(tbl_rows)
    tot_ri = n_data - 1

    style = [
        # Header
        ("BACKGROUND",    (0, 0),         (-1, 0),      C["HEADER_BG"]),
        ("LINEBELOW",     (0, 0),         (-1, 0),      2, C["ACCENT"]),
        ("TOPPADDING",    (0, 0),         (-1, 0),      5),
        ("BOTTOMPADDING", (0, 0),         (-1, 0),      5),
        # Data rows
        ("FONTNAME",      (0, 1),         (-1, -1),     "Helvetica"),
        ("FONTSIZE",      (0, 0),         (-1, -1),     fs),
        ("TEXTCOLOR",     (0, 1),         (-1, -1),     C["TEXT"]),
        ("TOPPADDING",    (0, 1),         (-1, -1),     4),
        ("BOTTOMPADDING", (0, 1),         (-1, -1),     4),
        ("LINEBELOW",     (0, 1),         (-1, -2),     0.3, C["BORDER"]),
        ("VALIGN",        (0, 0),         (-1, -1),     "MIDDLE"),
        ("LEFTPADDING",   (0, 0),         (-1, -1),     4),
        ("RIGHTPADDING",  (0, 0),         (-1, -1),     4),
        # Totals row
        ("BACKGROUND",    (0, tot_ri),    (-1, tot_ri), C["HEADER_BG"]),
        ("TOPPADDING",    (0, tot_ri),    (-1, tot_ri), 6),
        ("BOTTOMPADDING", (0, tot_ri),    (-1, tot_ri), 6),
        ("LINEABOVE",     (0, tot_ri),    (-1, tot_ri), 1.5, C["ACCENT"]),
    ]
    # Alternating row background
    for i in range(1, n_data - 1):
        if i % 2 == 0:
            style.append(("BACKGROUND", (0, i), (-1, i), C["ROW_ALT"]))

    tbl = Table(tbl_rows, colWidths=col_widths, repeatRows=1)
    tbl.setStyle(TableStyle(style))
    story.append(tbl)
    story.append(Spacer(1, 4*mm))
    story.extend(_footer(co, s, C))

    doc.build(story, canvasmaker=_make_watermark_canvas(watermark, footer))
    return out_path
