# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
dbox - Quote PDF Generator
Professional A4 Quote / Scope of Works document.
Matches the invoice PDF styling — same theme system, same layout language.
"""


import os
import tempfile
import json
from datetime import date as dt

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_RIGHT, TA_LEFT, TA_CENTER
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, Image, KeepTogether
)

from core.database import get_connection
from core.invoice_pdf import (
    _resolve_theme, _s, _fmt, _c, _load_doc_theme,
    _logo_image, _build_header, _build_meta_table,
    _build_line_table, _build_totals_block, _build_footer,
    _make_page_callback,
    WHITE, GREEN, RED, GREY, PAGE_W
)

W, H = A4

# Status badge colours
ORANGE = colors.HexColor("#f39c12")   # Draft
BLUE   = colors.HexColor("#3d7eff")   # Sent
GREEN  = colors.HexColor("#27ae60")   # Accepted
RED    = colors.HexColor("#e74c3c")   # Declined
GREY   = colors.HexColor("#8892a4")   # Superseded




def _status_colour(status):
    return {
        "Draft":      GREY,
        "Sent":       BLUE,
        "Accepted":   GREEN,
        "Declined":   RED,
        "Superseded": GREY,
    }.get(status, GREY)


def generate_quote_pdf(db_path, quote_id, output_path=None, doc_theme=None, watermark=None, footer=None):
    _wm_text = watermark
    """
    Generate a professional PDF for a CRM quote.

    Args:
        db_path:     path to .dbox SQLite file
        quote_id:    crm_quotes.id
        output_path: where to write the PDF (temp file if None)
        doc_theme:   optional colour theme dict (uses company theme if None)

    Returns:
        Absolute path to the generated PDF file.
    """
    # ── Load data ─────────────────────────────────────────────────────────────
    conn = get_connection(db_path)

    quote = conn.execute("""
        SELECT q.*,
               c.name    as cname,
               c.abn     as cabn,
               c.email   as cemail,
               c.phone   as cphone,
               c.address as caddress,
               c.city    as ccity,
               c.state   as cstate,
               c.postcode as cpostcode
        FROM crm_quotes q
        LEFT JOIN contacts c ON q.contact_id = c.id
        WHERE q.id = ?""", (quote_id,)).fetchone()

    lines = conn.execute("""
        SELECT ql.*, a.name as account_name
        FROM crm_quote_lines ql
        LEFT JOIN accounts a ON ql.account_id = a.id
        WHERE ql.quote_id = ?
        ORDER BY ql.sort_order, ql.id""", (quote_id,)).fetchall()

    # Opportunity / job title (optional, for header context)
    opp_title = None
    if quote:
        try:
            job_id = quote["job_id"]
        except (IndexError, KeyError):
            job_id = None
        if job_id:
            job_row = conn.execute(
                "SELECT name, opp_number FROM jobs WHERE id=?",
                (job_id,)).fetchone()
            if job_row:
                num = job_row["opp_number"]
                opp_title = f"{num}  —  {job_row['name']}" if num else job_row["name"]

    company = conn.execute("SELECT * FROM company").fetchone()
    conn.close()

    if not quote:
        raise ValueError(f"Quote {quote_id} not found")

    q   = dict(quote)
    lns = [dict(l) for l in lines]
    co  = dict(company) if company else {}

    # ── Resolve theme ─────────────────────────────────────────────────────────
    if doc_theme is None:
        doc_theme = _load_doc_theme(co)
    th = _resolve_theme(doc_theme)

    # ── Output path ───────────────────────────────────────────────────────────
    if output_path is None:
        output_path = os.path.join(
            tempfile.mkdtemp(), f"{q['quote_number']}.pdf")

    # ── Styles ────────────────────────────────────────────────────────────────
    s = _s(th)

    # Extra styles specific to quotes
    s["quote_title"] = ParagraphStyle(
        "quote_title", fontName="Helvetica-Bold",
        fontSize=20, textColor=_c(th["accent_bar"]),
        leading=24, alignment=TA_RIGHT)
    s["intro"] = ParagraphStyle(
        "intro", fontName="Helvetica",
        fontSize=9, textColor=_c(th["dim_text"]),
        leading=14, spaceAfter=2)
    s["terms"] = ParagraphStyle(
        "terms", fontName="Helvetica",
        fontSize=8, textColor=_c(th["dim_text"]),
        leading=12)
    s["section_hdr"] = ParagraphStyle(
        "section_hdr", fontName="Helvetica-Bold",
        fontSize=8, textColor=_c(th["label_colour"]),
        leading=11, spaceAfter=1, textTransform="uppercase")
    s["opp_ref"] = ParagraphStyle(
        "opp_ref", fontName="Helvetica",
        fontSize=8, textColor=_c(th["dim_text"]),
        leading=11, alignment=TA_RIGHT)

    # ── Company details ───────────────────────────────────────────────────────
    doc = SimpleDocTemplate(
        output_path, pagesize=A4,
        leftMargin=18*mm, rightMargin=18*mm,
        topMargin=14*mm, bottomMargin=14*mm,
        title=f"Quote {q['quote_number']}",
        author=co.get("name", ""),
    )
    story = []

    co_name, co_abn, co_addr, co_phone, co_email, co_web = \
        _build_header(story, co, "QUOTE", s, th)

    prep_elems = [Paragraph("Prepared For", s["label"])]
    if q.get("cname"):
        prep_elems.append(Paragraph(q["cname"], s["body_b"]))
    if q.get("cabn"):
        prep_elems.append(Paragraph(f"ABN: {q['cabn']}", s["body"]))
    cust_addr = ", ".join(filter(None, [
        q.get("caddress"), q.get("ccity"),
        q.get("cstate"),   q.get("cpostcode")]))
    if cust_addr:
        prep_elems.append(Paragraph(cust_addr, s["body"]))
    if q.get("cemail"):
        prep_elems.append(Paragraph(q["cemail"], s["small"]))
    if q.get("cphone"):
        prep_elems.append(Paragraph(q["cphone"], s["small"]))

    left_col = prep_elems

    status    = q.get("status", "Draft")
    status_col = _status_colour(status)
    meta_rows = [
        ["Quote No",    q["quote_number"]],
        ["Date",        q.get("quote_date", "")],
        ["Valid Until", q.get("expiry_date") or "—"],
        ["Status",      status],
    ]
    if q.get("accepted_date"):
        meta_rows.append(["Accepted", q["accepted_date"]])
    if opp_title:
        _ref_style = ParagraphStyle("ref_val", fontName="Helvetica", fontSize=9,
                                     textColor=_c(th["body_text"]), leading=11)
        meta_rows.append(["Reference", Paragraph(opp_title, _ref_style)])

    meta_tbl = _build_meta_table(meta_rows, th,
                                  status_row=3, status_colour=status_col)
    addr_tbl = Table([[left_col, meta_tbl]],
                     colWidths=[PAGE_W * 0.55, PAGE_W * 0.45])
    addr_tbl.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                                   ("LEFTPADDING",  (0, 0), (-1, -1), 0),
                                   ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    story.append(addr_tbl)
    story.append(Spacer(1, 5*mm))

    # ══════════════════════════════════════════════════════════════════════════
    # INTRO / SCOPE DESCRIPTION
    # ══════════════════════════════════════════════════════════════════════════
    intro = (q.get("intro_text") or "").strip()
    if intro:
        story.append(Paragraph("Scope of Works", s["section_hdr"]))
        story.append(Paragraph(intro.replace("\n", "<br/>"), s["intro"]))
        story.append(Spacer(1, 4*mm))

    # ══════════════════════════════════════════════════════════════════════════
    # LINE ITEMS TABLE
    # ══════════════════════════════════════════════════════════════════════════
    cw = [PAGE_W * 0.40, PAGE_W * 0.09, PAGE_W * 0.14,
          PAGE_W * 0.08, PAGE_W * 0.12, PAGE_W * 0.17]
    tbl_data = [[
        Paragraph("Description", s["tbl_hdr"]),
        Paragraph("Qty",         s["tbl_hdr_r"]),
        Paragraph("Unit Price",  s["tbl_hdr_r"]),
        Paragraph("Tax",         s["tbl_hdr_c"]),
        Paragraph("GST",         s["tbl_hdr_r"]),
        Paragraph("Amount",      s["tbl_hdr_r"]),
    ]]
    comment_rows = []
    for row_i, l in enumerate(lns, start=1):
        if l.get("line_type") == "comment":
            tbl_data.append([
                Paragraph(l["description"],
                          ParagraphStyle("cmt", fontName="Helvetica-Oblique",
                                         fontSize=9, textColor=_c(th.get("body_text","#444444")))),
                "", "", "", "", "",
            ])
            comment_rows.append(row_i)
        else:
            tbl_data.append([
                Paragraph(l["description"], s["body"]),
                Paragraph(f"{l.get('quantity', 1):g}", s["right"]),
                Paragraph(_fmt(l.get("unit_price", 0)), s["right"]),
                Paragraph(l.get("tax_code", "GST"),
                          ParagraphStyle("tc", fontName="Helvetica",
                                         fontSize=9, alignment=TA_CENTER)),
                Paragraph(_fmt(l.get("gst_amount", 0)), s["right"]),
                Paragraph(_fmt(l.get("line_total", 0)), s["right_b"]),
            ])
    line_tbl = _build_line_table(tbl_data, cw, th)
    for r in comment_rows:
        line_tbl.setStyle(TableStyle([("SPAN", (0, r), (-1, r))]))
    story.append(line_tbl)
    story.append(Spacer(1, 4*mm))

    sub   = q.get("subtotal",  0)
    gst   = q.get("gst_total", 0)
    total = q.get("total",     0)
    totals_block = _build_totals_block(sub, gst, total, 0, th, s,
                                        "TOTAL (inc GST)")

    # Status badge (Accepted / Declined) displayed opposite totals
    badge_text = ""
    badge_style = None
    if status == "Accepted":
        badge_text  = "ACCEPTED"
        badge_style = ParagraphStyle(
            "badge_acc", fontName="Helvetica-Bold",
            fontSize=26, textColor=GREEN, leading=30)
    elif status == "Declined":
        badge_text  = "DECLINED"
        badge_style = ParagraphStyle(
            "badge_dec", fontName="Helvetica-Bold",
            fontSize=26, textColor=RED, leading=30)

    badge_elem = (Paragraph(badge_text, badge_style)
                  if badge_style else Spacer(1, 1))

    summary = Table(
        [[badge_elem, totals_block]],
        colWidths=[100*mm, 75*mm])
    summary.setStyle(TableStyle([
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("ALIGN",  (1,0), (1,0),  "RIGHT"),
    ]))
    story.append(summary)

    # ══════════════════════════════════════════════════════════════════════════
    # TERMS & CONDITIONS
    # ══════════════════════════════════════════════════════════════════════════
    terms = (q.get("terms_text") or "").strip()
    if terms:
        story.append(Spacer(1, 5*mm))
        terms_box = Table(
            [[Paragraph("Terms & Conditions", s["pmt_head"]),
              Paragraph(terms.replace("\n", "<br/>"), s["terms"])]],
            colWidths=[38*mm, 134*mm])
        terms_box.setStyle(TableStyle([
            ("BACKGROUND",  (0,0), (-1,-1), _c(th["payment_box_bg"])),
            ("TOPPADDING",    (0,0), (-1,-1), 8),
            ("BOTTOMPADDING", (0,0), (-1,-1), 8),
            ("LEFTPADDING",   (0,0), (-1,-1), 10),
            ("RIGHTPADDING",  (0,0), (-1,-1), 10),
            ("VALIGN",  (0,0), (-1,-1), "TOP"),
            ("BOX",     (0,0), (-1,-1), 1, _c(th["payment_box_border"])),
            ("LINEBEFORE", (1,0), (1,0), 0.5, _c(th["payment_box_border"])),
        ]))
        story.append(KeepTogether(terms_box))

    # ══════════════════════════════════════════════════════════════════════════
    # ACCEPTANCE BLOCK (shown when status is Draft or Sent)
    # ══════════════════════════════════════════════════════════════════════════
    if status in ("Draft", "Sent"):
        story.append(Spacer(1, 6*mm))
        _sig_line = lambda w: HRFlowable(width=w, thickness=0.5, color=colors.black, spaceAfter=1)
        acc_rows = [
            [Paragraph("To accept this quote, please sign below and return:", s["small_b"]),
             "", ""],
            ["", "", ""],
            [_sig_line("95%"), _sig_line("95%"), _sig_line("95%")],
            [Paragraph("Authorised Signature", s["section_hdr"]),
             Paragraph("Print Name", s["section_hdr"]),
             Paragraph("Date", s["section_hdr"])],
        ]
        acc_tbl = Table(acc_rows, colWidths=[65*mm, 65*mm, 45*mm])
        acc_tbl.setStyle(TableStyle([
            ("SPAN",       (0,0), (2,0)),
            ("TOPPADDING", (0,0), (-1,-1), 4),
            ("BOTTOMPADDING", (0,0), (-1,-1), 4),
        ]))
        story.append(KeepTogether(acc_tbl))

    # ══════════════════════════════════════════════════════════════════════════
    # FOOTER
    # ══════════════════════════════════════════════════════════════════════════
    _build_footer(story, co_name, co_abn, co_email, co_phone,
                  f"Quote {q['quote_number']}  —  Valid until "
                  f"{q.get('expiry_date') or 'further notice'}  "
                  f"—  Prices include GST where applicable.", th, s)
    _cb = _make_page_callback(watermark=_wm_text, footer=footer)
    doc.build(story, onFirstPage=_cb, onLaterPages=_cb)
    return output_path


def send_quote_email(db_path, quote_id, pdf_path, to_email,
                     subject_override=None, body_override=None):
    """
    Send a quote PDF by email using the saved SMTP settings.
    Returns (True, None) on success, (False, error_message) on failure.
    """
    from core.email_invoice import get_email_settings, _dec_pw
    import smtplib, ssl
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email import encoders

    settings = get_email_settings(db_path)
    if not settings.get("smtp_user") or not settings.get("smtp_password"):
        return False, "Email not configured. Go to File → Email Settings."

    conn = get_connection(db_path)
    quote = conn.execute("""
        SELECT q.*, c.name as cname
        FROM crm_quotes q
        LEFT JOIN contacts c ON q.contact_id=c.id
        WHERE q.id=?""", (quote_id,)).fetchone()
    company = conn.execute("SELECT * FROM company").fetchone()
    conn.close()

    if not quote:
        return False, "Quote not found"

    q  = dict(quote)
    co = dict(company) if company else {}
    co_name = co.get("name", "Your Company")

    tmpl_vars = {
        "quote_number":  q["quote_number"],
        "company_name":  co_name,
        "total":         f"${q.get('total', 0):,.2f}",
        "expiry_date":   q.get("expiry_date") or "—",
        "customer":      q.get("cname") or "",
    }

    default_subject = "Quote {quote_number} from {company_name}"
    default_body    = (
        "Dear {customer},\n\n"
        "Please find attached Quote {quote_number} "
        "for the amount of {total} (inc GST).\n\n"
        "This quote is valid until {expiry_date}.\n\n"
        "Please don't hesitate to contact us if you have any questions.\n\n"
        "Kind regards,\n{company_name}"
    )

    subject = subject_override or default_subject
    body    = body_override    or default_body

    for k, v in tmpl_vars.items():
        subject = subject.replace("{" + k + "}", str(v))
        body    = body.replace("{" + k + "}", str(v))

    # Build MIME message
    msg = MIMEMultipart()
    from_addr = settings.get("from_email") or settings.get("smtp_user", "")
    from_name = settings.get("from_name") or co_name
    msg["From"]    = f"{from_name} <{from_addr}>"
    msg["To"]      = to_email
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    # Attach PDF
    fname = os.path.basename(pdf_path)
    with open(pdf_path, "rb") as f:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(f.read())
    encoders.encode_base64(part)
    part.add_header("Content-Disposition", f'attachment; filename="{fname}"')
    msg.attach(part)

    # Send
    try:
        context = ssl.create_default_context()
        port    = int(settings.get("smtp_port", 587))
        host    = settings.get("smtp_host", "smtp.gmail.com")
        use_tls = int(settings.get("use_tls", 1))

        if port == 465:
            with smtplib.SMTP_SSL(host, port, context=context) as server:
                server.login(settings["smtp_user"],
                             _dec_pw(settings["smtp_password"]))
                server.sendmail(from_addr, to_email, msg.as_string())
        else:
            with smtplib.SMTP(host, port) as server:
                if use_tls:
                    server.starttls(context=context)
                server.login(settings["smtp_user"],
                             _dec_pw(settings["smtp_password"]))
                server.sendmail(from_addr, to_email, msg.as_string())

        return True, None

    except smtplib.SMTPAuthenticationError:
        return False, (
            "Authentication failed.\n\n"
            "For Gmail: use an App Password "
            "(Google Account → Security → 2-Step Verification → App passwords).\n"
            "For Outlook: enable SMTP AUTH in your account settings."
        )
    except smtplib.SMTPException as e:
        return False, f"SMTP error: {e}"
    except Exception as e:
        return False, f"Error: {e}"
