"""
Dogbox Accounting — Warranty management backend.
Warranties are linked to any transaction (invoice, bill, journal entry)
by source_type + source_id, and are searchable across financial years.
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.


from .database import get_connection


def get_warranties(db_path: str,
                   search: str = "",
                   status: str = "all",       # 'active', 'expired', 'expiring', 'all'
                   source_type: str = "",      # 'invoice', 'bill', 'journal', '' = all
                   date_from: str = "",
                   date_to: str = "") -> list:
    """
    Return warranties matching filters, joined to source transaction details.
    Each row dict includes:
      id, source_type, source_id, source_ref, source_date, contact_name,
      item_description, serial_number, provider, purchase_date,
      warranty_expiry, notes, days_remaining, status_label
    """
    conn = get_connection(db_path)

    # Build the UNION source join
    sql = """
        WITH src AS (
            SELECT 'invoice' AS stype, i.id AS sid,
                   i.invoice_number AS ref, i.invoice_date AS sdate,
                   c.name AS contact_name
            FROM invoices i LEFT JOIN contacts c ON c.id = i.contact_id
            UNION ALL
            SELECT 'bill', b.id, COALESCE(b.bill_number, 'Bill #'||b.id), b.bill_date,
                   c.name
            FROM bills b LEFT JOIN contacts c ON c.id = b.contact_id
            UNION ALL
            SELECT 'payment', p.id,
                   'PMT-'||p.id, p.payment_date, c.name
            FROM payments p LEFT JOIN contacts c ON c.id = p.contact_id
            UNION ALL
            SELECT 'journal', j.id,
                   'JNL-'||j.id, j.entry_date, c.name
            FROM journal_entries j LEFT JOIN contacts c ON c.id = j.contact_id
        )
        SELECT w.*,
               s.ref        AS source_ref,
               s.sdate      AS source_date,
               s.contact_name,
               CAST(julianday(w.warranty_expiry) - julianday('now') AS INTEGER)
                             AS days_remaining
        FROM warranties w
        LEFT JOIN src s ON s.stype = w.source_type AND s.sid = w.source_id
        WHERE 1=1
    """
    params = []

    if search:
        sql += """ AND (
            w.item_description LIKE ? OR w.serial_number LIKE ?
            OR w.provider LIKE ? OR w.notes LIKE ?
            OR s.ref LIKE ? OR s.contact_name LIKE ?
        )"""
        like = f"%{search}%"
        params += [like, like, like, like, like, like]

    if source_type:
        sql += " AND w.source_type = ?"
        params.append(source_type)

    if date_from:
        sql += " AND w.warranty_expiry >= ?"
        params.append(date_from)

    if date_to:
        sql += " AND w.warranty_expiry <= ?"
        params.append(date_to)

    if status == "active":
        sql += " AND (w.claim_status='active' OR w.claim_status IS NULL) AND w.warranty_expiry >= date('now')"
    elif status == "expired":
        sql += " AND (w.claim_status='active' OR w.claim_status IS NULL) AND w.warranty_expiry < date('now')"
    elif status == "expiring":
        sql += (" AND (w.claim_status='active' OR w.claim_status IS NULL)"
                " AND w.warranty_expiry >= date('now')"
                " AND w.warranty_expiry <= date('now','+90 days')")
    elif status == "claimed":
        sql += " AND w.claim_status IN ('voided','repair_logged','rejected')"

    sql += " ORDER BY w.warranty_expiry ASC"

    rows = conn.execute(sql, params).fetchall()
    conn.close()

    result = []
    for r in rows:
        d = dict(r)
        claim = d.get("claim_status") or "active"
        days  = d.get("days_remaining")

        if claim == "voided":
            outcome = d.get("claim_outcome", "")
            label_map = {
                "replace":        "Replaced",
                "refund":         "Refunded",
                "partial_refund": "Partial Refund",
                "exchange":       "Exchanged",
                "rejected_void":  "Rejected — Voided",
            }
            d["status_label"] = label_map.get(outcome, "Voided")
        elif claim == "repair_logged":
            d["status_label"] = "Repair Lodged"
        elif claim == "rejected":
            d["status_label"] = "Claim Rejected"
        elif days is None:
            d["status_label"] = "Unknown"
        elif days < 0:
            d["status_label"] = f"Expired {abs(days)}d ago"
        elif days == 0:
            d["status_label"] = "Expires today"
        elif days <= 30:
            d["status_label"] = f"Expiring in {days}d"
        elif days <= 90:
            d["status_label"] = f"Expiring in {days}d"
        else:
            d["status_label"] = f"{days}d remaining"
        result.append(d)
    return result


def get_warranty(db_path: str, warranty_id: int) -> dict | None:
    conn = get_connection(db_path)
    row = conn.execute(
        "SELECT * FROM warranties WHERE id=?", (warranty_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_warranties_for_source(db_path: str, source_type: str, source_id: int) -> list:
    conn = get_connection(db_path)
    rows = conn.execute(
        """SELECT * FROM warranties WHERE source_type=? AND source_id=?
           ORDER BY warranty_expiry""",
        (source_type, source_id)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_warranty(db_path: str,
                  source_type: str, source_id: int,
                  item_description: str,
                  warranty_expiry: str,
                  serial_number: str = "",
                  provider: str = "",
                  purchase_date: str = "",
                  notes: str = "",
                  warranty_id: int = None) -> int:
    """Insert or update a warranty. Returns the warranty id."""
    conn = get_connection(db_path)
    if warranty_id:
        conn.execute("""UPDATE warranties SET
            source_type=?, source_id=?, item_description=?, serial_number=?,
            provider=?, purchase_date=?, warranty_expiry=?, notes=?,
            updated_at=datetime('now','localtime')
            WHERE id=?""",
            (source_type, source_id, item_description, serial_number,
             provider, purchase_date, warranty_expiry, notes, warranty_id))
        conn.commit()
        conn.close()
        return warranty_id
    else:
        cur = conn.execute("""INSERT INTO warranties
            (source_type, source_id, item_description, serial_number,
             provider, purchase_date, warranty_expiry, notes, claim_status)
            VALUES (?,?,?,?,?,?,?,?,'active')""",
            (source_type, source_id, item_description, serial_number,
             provider, purchase_date, warranty_expiry, notes))
        new_id = cur.lastrowid
        conn.commit()
        conn.close()
        return new_id


# Claim outcome labels shown in UI
CLAIM_OUTCOMES = {
    "replace":             "Replacement — new unit, new serial number",
    "refund":              "Full Refund — warranty voided, full amount back",
    "partial_refund":      "Partial Refund — partial amount returned, warranty voided",
    "partial_refund_keep": "Partial Refund — partial amount returned, warranty stays active",
    "repair":              "Repair / Service — item repaired, warranty continues",
    "exchange":            "Exchange — swapped for different model",
    "rejected":            "Claim Rejected — supplier declined, warranty still active",
    "rejected_void":       "Claim Rejected — voided (e.g. tampering, broken seal)",
    "withdraw":            "Withdraw Claim — cancel/undo a lodged claim",
}


def lodge_claim(db_path: str,
                warranty_id: int,
                outcome: str,          # key from CLAIM_OUTCOMES
                claim_date: str,
                claim_notes: str = "",
                claim_amount: float = None,
                # For replace / exchange — new warranty details
                new_serial: str = "",
                new_item_description: str = "",
                new_expiry: str = "",
                new_notes: str = "") -> dict:
    """
    Lodge a warranty claim.  Returns {"original_id": int, "new_warranty_id": int|None}.

    Outcomes and their effect on the original warranty:
      replace             → original voided, new warranty created (new serial/expiry)
      refund              → original voided (claimed)
      partial_refund      → original voided (claimed), claim_amount recorded
      partial_refund_keep → original stays active, claim_amount recorded
      repair              → original stays active (claim_status='repair_logged')
      exchange            → original voided, new warranty created (new item/serial/expiry)
      rejected            → original stays active (claim_status='active'), outcome noted
      rejected_void       → original voided (e.g. tampering, broken seal)
      withdraw            → original reset to active, claim cleared
    """
    conn = get_connection(db_path)
    orig = conn.execute("SELECT * FROM warranties WHERE id=?", (warranty_id,)).fetchone()
    if not orig:
        conn.close()
        raise ValueError(f"Warranty {warranty_id} not found")
    orig = dict(orig)

    void_statuses = {"replace", "refund", "partial_refund", "exchange", "rejected_void"}
    keep_active   = {"repair", "rejected", "partial_refund_keep", "withdraw"}

    new_status = "voided" if outcome in void_statuses else (
                 "repair_logged" if outcome == "repair" else "active")

    conn.execute("""UPDATE warranties SET
        claim_status=?, claim_date=?, claim_outcome=?,
        claim_notes=?, claim_amount=?,
        updated_at=datetime('now','localtime')
        WHERE id=?""",
        (new_status, claim_date, outcome,
         claim_notes, claim_amount, warranty_id))
    conn.commit()

    new_id = None
    if outcome in {"replace", "exchange"}:
        desc = new_item_description or orig["item_description"]
        expiry = new_expiry or orig["warranty_expiry"]
        notes = new_notes or f"Replacement for warranty #{warranty_id}"
        cur = conn.execute("""INSERT INTO warranties
            (source_type, source_id, item_description, serial_number,
             provider, purchase_date, warranty_expiry, notes,
             claim_status, parent_warranty_id)
            VALUES (?,?,?,?,?,?,?,?,'active',?)""",
            (orig["source_type"], orig["source_id"],
             desc, new_serial,
             orig["provider"], orig["purchase_date"],
             expiry, notes, warranty_id))
        new_id = cur.lastrowid
        conn.commit()

    conn.close()
    return {"original_id": warranty_id, "new_warranty_id": new_id}




def delete_warranty(db_path: str, warranty_id: int) -> None:
    conn = get_connection(db_path)
    # Clear attachment links before deleting
    conn.execute("DELETE FROM warranty_attachments WHERE warranty_id=?", (warranty_id,))
    # Clear parent reference on any replacement warranties pointing to this one
    conn.execute("UPDATE warranties SET parent_warranty_id=NULL WHERE parent_warranty_id=?", (warranty_id,))
    conn.execute("DELETE FROM warranties WHERE id=?", (warranty_id,))
    conn.commit()
    conn.close()


# ── Warranty ↔ Attachment links ───────────────────────────────────────────────

def get_linked_attachments(db_path: str, warranty_id: int) -> list:
    """Return attachment IDs linked to this warranty."""
    conn = get_connection(db_path)
    rows = conn.execute(
        "SELECT attachment_id FROM warranty_attachments WHERE warranty_id=?",
        (warranty_id,)).fetchall()
    conn.close()
    return [r[0] for r in rows]


def set_linked_attachments(db_path: str, warranty_id: int,
                           attachment_ids: list) -> None:
    """Replace the full set of attachment links for a warranty."""
    conn = get_connection(db_path)
    conn.execute(
        "DELETE FROM warranty_attachments WHERE warranty_id=?", (warranty_id,))
    for att_id in attachment_ids:
        try:
            conn.execute(
                "INSERT OR IGNORE INTO warranty_attachments (warranty_id, attachment_id)"
                " VALUES (?,?)", (warranty_id, att_id))
        except Exception:
            pass
    conn.commit()
    conn.close()
