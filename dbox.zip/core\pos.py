# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
dbox - Point of Sale
Core POS logic: sale creation, payment terminal adapters (Tyro, Square, Mock).
"""

import time as _time
import uuid as _uuid
from datetime import date as _date

from core.database import get_connection
from core.items import get_items
from core.ledger import save_invoice, record_payment, post_journal, create_credit_note
from core.pos_settings import get_pos_settings


# ── Session management ────────────────────────────────────────────────────────

def _ensure_pos_session_tables(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS pos_sessions (
        id             INTEGER PRIMARY KEY,
        opened_at      TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        closed_at      TEXT,
        note           TEXT DEFAULT '',
        opening_float  REAL DEFAULT 0,
        cash_counted   REAL,
        banked         REAL DEFAULT 0,
        float_kept     REAL DEFAULT 0,
        variance       REAL
    )""")
    for col, defn in [
        ("opening_float",      "REAL DEFAULT 0"),
        ("cash_counted",       "REAL"),
        ("banked",             "REAL DEFAULT 0"),
        ("float_kept",         "REAL DEFAULT 0"),
        ("variance",           "REAL"),
        ("opened_by_user_id",  "INTEGER"),
        ("opened_by_name",     "TEXT"),
    ]:
        try:
            conn.execute(f"ALTER TABLE pos_sessions ADD COLUMN {col} {defn}")
        except Exception:
            pass
    conn.execute("""CREATE TABLE IF NOT EXISTS pos_sales (
        id         INTEGER PRIMARY KEY,
        session_id INTEGER REFERENCES pos_sessions(id),
        invoice_id INTEGER NOT NULL,
        tender     TEXT NOT NULL,
        total      REAL NOT NULL DEFAULT 0,
        gst        REAL NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    )""")
    for col, defn in [
        ("cash_amount",       "REAL"),
        ("card_amount",       "REAL"),
        ("terminal_provider", "TEXT"),
        ("terminal_rfn",      "TEXT"),
    ]:
        try:
            conn.execute(f"ALTER TABLE pos_sales ADD COLUMN {col} {defn}")
        except Exception:
            pass
    conn.commit()


def get_active_pos_session(db_path):
    """Return the currently open session or None."""
    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)
    row = conn.execute(
        "SELECT id, opened_at, opening_float, opened_by_name "
        "FROM pos_sessions WHERE closed_at IS NULL ORDER BY id DESC LIMIT 1"
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def get_last_pos_float(db_path) -> float:
    """Return the float_kept from the most recently closed session (0 if none)."""
    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)
    row = conn.execute(
        "SELECT COALESCE(float_kept, 0) AS f FROM pos_sessions WHERE closed_at IS NOT NULL ORDER BY id DESC LIMIT 1"
    ).fetchone()
    conn.close()
    return round(row["f"], 2) if row else 0.0


def open_pos_session(db_path, note="", opening_float=0.0,
                     opened_by_user_id=None, opened_by_name=None):
    """Open a new register session and return {id, opened_at, opening_float, opened_by_name}."""
    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)
    conn.execute(
        "INSERT INTO pos_sessions (note, opening_float, opened_by_user_id, opened_by_name) VALUES (?,?,?,?)",
        (note, round(float(opening_float), 2), opened_by_user_id, opened_by_name),
    )
    conn.commit()
    row = conn.execute(
        "SELECT id, opened_at, opening_float, opened_by_user_id, opened_by_name "
        "FROM pos_sessions ORDER BY id DESC LIMIT 1"
    ).fetchone()
    conn.close()
    return dict(row)


def _build_z_report(conn, session_id):
    sess = conn.execute(
        "SELECT id, opened_at, closed_at, opening_float, cash_counted, banked, float_kept, variance FROM pos_sessions WHERE id=?",
        (session_id,)
    ).fetchone()
    if not sess:
        raise ValueError("Session not found")
    rows = conn.execute("""
        SELECT ps.tender,
               COUNT(*) AS count,
               SUM(ps.total) AS total,
               SUM(COALESCE(il.gst_total, 0)) AS gst,
               COALESCE(SUM(ps.cash_amount), 0) AS split_cash,
               COALESCE(SUM(ps.card_amount), 0) AS split_card
        FROM pos_sales ps
        LEFT JOIN (
            SELECT invoice_id, SUM(gst_amount) AS gst_total
            FROM invoice_lines
            GROUP BY invoice_id
        ) il ON il.invoice_id = ps.invoice_id
        WHERE ps.session_id=?
        GROUP BY ps.tender
    """, (session_id,)).fetchall()
    by = {r["tender"]: r for r in rows}
    cash_row  = by.get("cash",    {"count": 0, "total": 0, "gst": 0, "split_cash": 0, "split_card": 0})
    card_row  = by.get("card",    {"count": 0, "total": 0, "gst": 0, "split_cash": 0, "split_card": 0})
    split_row = by.get("split",   {"count": 0, "total": 0, "gst": 0, "split_cash": 0, "split_card": 0})
    acct_row  = by.get("account", {"count": 0, "total": 0, "gst": 0, "split_cash": 0, "split_card": 0})

    split_cash_amt = round(float(split_row["split_cash"] or 0), 2)
    split_card_amt = round(float(split_row["split_card"] or 0), 2)
    split_gst_amt  = round(float(split_row["gst"] or 0), 2)
    split_count    = int(split_row["count"] or 0)
    split_total    = round(float(split_row["total"] or 0), 2)

    # TOTAL SALES = cash collected only (account sales are AR, not collected yet)
    total = round(
        float(cash_row["total"] or 0) + float(card_row["total"] or 0) + split_total, 2
    )
    gst = round(
        float(cash_row["gst"] or 0) + float(card_row["gst"] or 0) + split_gst_amt, 2
    )
    # Cash in drawer includes cash portions of split transactions
    cash_drawer_total = round(float(cash_row["total"] or 0) + split_cash_amt, 2)

    return {
        "session_id": sess["id"],
        "opened_at":  sess["opened_at"],
        "closed_at":  sess["closed_at"],
        "cash": {
            "count": int(cash_row["count"] or 0),
            "total": round(float(cash_row["total"] or 0), 2),
            "gst":   round(float(cash_row["gst"] or 0), 2),
        },
        "card": {
            "count": int(card_row["count"] or 0),
            "total": round(float(card_row["total"] or 0), 2),
            "gst":   round(float(card_row["gst"] or 0), 2),
        },
        "split": {
            "count": split_count,
            "total": split_total,
            "cash":  split_cash_amt,
            "card":  split_card_amt,
            "gst":   split_gst_amt,
        },
        "account": {
            "count": int(acct_row["count"] or 0),
            "total": round(float(acct_row["total"] or 0), 2),
            "gst":   round(float(acct_row["gst"] or 0), 2),
        },
        "cash_drawer_total": cash_drawer_total,
        "total":         total,
        "gst":           gst,
        "ex_gst":        round(total - gst, 2),
        "tx_count":      int(cash_row["count"] or 0) + int(card_row["count"] or 0) + split_count,
        "opening_float": round(float(sess["opening_float"] or 0), 2),
        "cash_counted":  round(float(sess["cash_counted"]), 2) if sess["cash_counted"] is not None else None,
        "banked":        round(float(sess["banked"] or 0), 2),
        "float_kept":    round(float(sess["float_kept"] or 0), 2),
        "variance":      round(float(sess["variance"]), 2) if sess["variance"] is not None else None,
    }


def get_pos_session_report(db_path, session_id):
    """Return current Z-report data without closing the session."""
    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)
    report = _build_z_report(conn, session_id)
    conn.close()
    return report


def close_pos_session(db_path, session_id,
                      cash_counted=None, banked=0.0, float_kept=0.0,
                      banking_account_id=None):
    """Close the session, record till balance, post banking journal if needed."""
    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)

    # calculate variance if cash was counted
    variance = None
    if cash_counted is not None:
        opening_float = (conn.execute(
            "SELECT opening_float FROM pos_sessions WHERE id=?", (session_id,)
        ).fetchone() or {"opening_float": 0})["opening_float"] or 0
        cash_sales = (conn.execute(
            "SELECT COALESCE(SUM(CASE WHEN tender='cash' THEN total ELSE 0 END),0)"
            " + COALESCE(SUM(CASE WHEN tender='split' THEN COALESCE(cash_amount,0) ELSE 0 END),0)"
            " FROM pos_sales WHERE session_id=?",
            (session_id,)
        ).fetchone() or (0,))[0] or 0
        expected = round(opening_float + cash_sales, 2)
        variance = round(float(cash_counted) - expected, 2)

    conn.execute("""UPDATE pos_sessions
        SET closed_at=datetime('now','localtime'),
            cash_counted=?, banked=?, float_kept=?, variance=?
        WHERE id=? AND closed_at IS NULL""",
        (cash_counted, round(float(banked), 2),
         round(float(float_kept), 2), variance, session_id))
    conn.commit()
    conn.close()

    from datetime import date as _d
    settings  = get_pos_settings(db_path)
    cash_acct = settings.get("cash_account_id")
    card_acct = settings.get("card_account_id")

    # Cash banking journal: Cash Drawer → Main Bank
    if banked and float(banked) > 0 and banking_account_id and cash_acct:
        post_journal(db_path, _d.today().isoformat(),
                     f"Till banking — Session #{session_id}",
                     f"TILLBANK-{session_id}",
                     [
                         {"account_id": int(banking_account_id),
                          "debit": round(float(banked), 2), "credit": 0},
                         {"account_id": int(cash_acct),
                          "debit": 0, "credit": round(float(banked), 2)},
                     ])

    # EFT clearing journal: EFTPOS Clearing → Main Bank
    if banking_account_id and card_acct:
        conn2 = get_connection(db_path)
        card_total = (conn2.execute(
            "SELECT COALESCE(SUM(CASE WHEN tender='card' THEN total ELSE 0 END),0)"
            " + COALESCE(SUM(CASE WHEN tender='split' THEN COALESCE(card_amount,0) ELSE 0 END),0)"
            " FROM pos_sales WHERE session_id=?",
            (session_id,)
        ).fetchone() or (0,))[0] or 0
        conn2.close()
        card_total = round(float(card_total), 2)
        if card_total > 0:
            post_journal(db_path, _d.today().isoformat(),
                         f"EFTPOS settlement — Session #{session_id}",
                         f"EFTSETTLE-{session_id}",
                         [
                             {"account_id": int(banking_account_id),
                              "debit": card_total, "credit": 0},
                             {"account_id": int(card_acct),
                              "debit": 0, "credit": card_total},
                         ])

    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)
    report = _build_z_report(conn, session_id)
    conn.close()

    # end-of-day email
    settings = get_pos_settings(db_path)
    if settings.get("eod_email_enabled") and settings.get("eod_email_address"):
        try:
            _send_eod_email(db_path, report, settings["eod_email_address"])
        except Exception:
            pass  # never let email failure block the session close

    return report


def _send_eod_email(db_path, report: dict, to_email: str):
    """Send a plain-text Z-report summary email when a POS session closes."""
    import smtplib, ssl as _ssl
    from core.email_invoice import get_email_settings, _dec_pw

    es = get_email_settings(db_path)
    if not es.get("smtp_user") or not es.get("smtp_password"):
        return

    conn = get_connection(db_path)
    co = conn.execute("SELECT name FROM company LIMIT 1").fetchone()
    conn.close()
    co_name = (co["name"] if co else "") or "Your Business"

    opened = report.get("opened_at", "")[:16].replace("T", " ")
    closed = report.get("closed_at", "")[:16].replace("T", " ")
    sid    = report.get("session_id", "")

    def money(v):
        return f"${float(v):,.2f}"

    lines = [
        f"POS End-of-Day Summary — {co_name}",
        f"Session #{sid}  |  Opened: {opened}  |  Closed: {closed}",
        "",
        f"{'Tender':<12} {'Sales':>6}  {'Total':>10}  {'GST':>8}",
        "-" * 42,
        f"{'Cash':<12} {report['cash']['count']:>6}  {money(report['cash']['total']):>10}  {money(report['cash']['gst']):>8}",
        f"{'Card':<12} {report['card']['count']:>6}  {money(report['card']['total']):>10}  {money(report['card']['gst']):>8}",
    ]
    if report["split"]["count"]:
        lines.append(
            f"{'Split':<12} {report['split']['count']:>6}  {money(report['split']['total']):>10}  {money(report['split']['gst']):>8}"
        )
    if report["account"]["count"]:
        lines.append(
            f"{'On Account':<12} {report['account']['count']:>6}  {money(report['account']['total']):>10}  {money(report['account']['gst']):>8}"
        )
    lines += [
        "-" * 42,
        f"{'TOTAL':<12} {report['tx_count']:>6}  {money(report['total']):>10}  {money(report['gst']):>8}",
        "",
        f"Ex-GST: {money(report['ex_gst'])}",
        f"Cash drawer: {money(report['cash_drawer_total'])}",
    ]
    if report.get("opening_float") is not None:
        lines.append(f"Opening float: {money(report['opening_float'])}")
    if report.get("cash_counted") is not None:
        lines.append(f"Cash counted: {money(report['cash_counted'])}")
    if report.get("variance") is not None:
        v = report["variance"]
        lines.append(f"Variance: {money(v)} {'(over)' if v > 0 else '(short)' if v < 0 else '(exact)'}")
    if report.get("banked"):
        lines.append(f"Banked: {money(report['banked'])}")

    body = "\n".join(lines)

    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    msg = MIMEMultipart()
    from_addr = es.get("from_email") or es.get("smtp_user", "")
    from_name = es.get("from_name") or co_name
    msg["From"]    = f"{from_name} <{from_addr}>"
    msg["To"]      = to_email
    msg["Subject"] = f"POS End-of-Day — {co_name} (Session #{sid})"
    msg.attach(MIMEText(body, "plain"))

    ctx  = _ssl.create_default_context()
    port = int(es.get("smtp_port", 587))
    host = es.get("smtp_host", "smtp.gmail.com")
    pw   = _dec_pw(es["smtp_password"])
    if port == 465:
        with smtplib.SMTP_SSL(host, port, context=ctx) as srv:
            srv.login(es["smtp_user"], pw)
            srv.sendmail(from_addr, to_email, msg.as_string())
    else:
        with smtplib.SMTP(host, port) as srv:
            if int(es.get("use_tls", 1)):
                srv.starttls(context=ctx)
            srv.login(es["smtp_user"], pw)
            srv.sendmail(from_addr, to_email, msg.as_string())


# ── Default accounts / contacts ───────────────────────────────────────────────

def _ensure_pos_defaults(db_path) -> dict:
    """
    Create Walk-In Customer contact, Cash Drawer account, and EFTPOS Clearing
    account if they don't exist. Returns their IDs.
    """
    conn = get_connection(db_path)

    # Walk-In Customer system contact
    row = conn.execute(
        "SELECT id FROM contacts WHERE is_system=1 AND name='Walk-In Customer'"
    ).fetchone()
    if not row:
        conn.execute("""INSERT INTO contacts
            (contact_type, name, is_system, is_active, notes)
            VALUES ('Customer','Walk-In Customer',1,1,
                    'System contact — POS walk-in sales')""")
        conn.commit()
        row = conn.execute(
            "SELECT id FROM contacts WHERE is_system=1 AND name='Walk-In Customer'"
        ).fetchone()
    walkin_id = row[0]

    # Cash Drawer bank account (1-1120)
    row = conn.execute("SELECT id FROM accounts WHERE code='1-1120'").fetchone()
    if not row:
        conn.execute("""INSERT OR IGNORE INTO accounts
            (code, name, account_type, account_subtype, is_bank, tax_code)
            VALUES ('1-1120','Cash Drawer','Asset','Bank',1,'N-T')""")
        conn.commit()
        row = conn.execute("SELECT id FROM accounts WHERE code='1-1120'").fetchone()
    cash_account_id = row[0]

    # EFTPOS Clearing bank account (1-1130)
    row = conn.execute("SELECT id FROM accounts WHERE code='1-1130'").fetchone()
    if not row:
        conn.execute("""INSERT OR IGNORE INTO accounts
            (code, name, account_type, account_subtype, is_bank, tax_code)
            VALUES ('1-1130','EFTPOS Clearing','Asset','Bank',1,'N-T')""")
        conn.commit()
        row = conn.execute("SELECT id FROM accounts WHERE code='1-1130'").fetchone()
    card_account_id = row[0]

    conn.close()
    return {
        "walkin_contact_id": walkin_id,
        "cash_account_id": cash_account_id,
        "card_account_id": card_account_id,
    }


# ── Item catalogue ────────────────────────────────────────────────────────────

def get_pos_items(db_path, search: str = None) -> list:
    """Return active, POS-visible items with active promo prices applied."""
    items = [i for i in get_items(db_path, active_only=True)
             if i.get("pos_visible", 1)]
    if items:
        today = _date.today().isoformat()
        conn = get_connection(db_path)
        try:
            rows = conn.execute("""
                SELECT item_id, promo_name, promo_price
                FROM promotions
                WHERE is_active=1 AND start_date<=? AND end_date>=?
                ORDER BY promo_price ASC
            """, (today, today)).fetchall()
            promos = {}
            for r in rows:
                if r["item_id"] not in promos:
                    promos[r["item_id"]] = r
        except Exception:
            promos = {}
        finally:
            conn.close()
        for item in items:
            p = promos.get(item.get("id"))
            if p:
                item["standard_price"] = item["unit_price"]
                item["unit_price"]     = round(p["promo_price"], 2)
                item["promo_name"]     = p["promo_name"]
    if search:
        q = search.lower()
        items = [
            i for i in items
            if q in (i.get("name") or "").lower()
            or q in (i.get("code") or "").lower()
            or q in (i.get("barcode") or "").lower()
        ]
    return items


# ── Sale creation ─────────────────────────────────────────────────────────────

def create_pos_sale(
    db_path,
    lines: list,
    tender: str,
    tendered_amount: float = None,
    terminal_tx_id: str = None,
    terminal_provider: str = None,
    terminal_rfn: str = None,
    note: str = "",
    session_id: int = None,
    contact_id: int = None,
    gst: float = 0.0,
    split_tenders: dict = None,
    basket_discount: float = 0.0,
) -> dict:
    """
    Create an invoice + immediate payment for a POS sale.

    lines: [{item_id, description, qty, unit_price, tax_code, account_id}]
    tender: 'cash' | 'card'
    tendered_amount: float — cash given by customer (cash only)
    terminal_tx_id: str — terminal transaction ID (card only)
    terminal_provider: str — 'tyro' | 'square' | 'mock' (card only)

    Returns {invoice_id, invoice_number, payment_id, total, change}
    """
    defaults = _ensure_pos_defaults(db_path)
    settings = get_pos_settings(db_path)

    walkin_id    = contact_id or settings.get("walkin_contact_id") or defaults["walkin_contact_id"]
    cash_acct_id = settings.get("cash_account_id")  or defaults["cash_account_id"]
    card_acct_id = settings.get("card_account_id")  or defaults["card_account_id"]
    bank_acct_id = cash_acct_id if tender == "cash" else card_acct_id

    # Resolve fallback income account
    conn = get_connection(db_path)
    _def_inc = conn.execute("SELECT id FROM accounts WHERE code='4-1100'").fetchone()
    default_income_id = _def_inc[0] if _def_inc else None
    conn.close()

    today = _date.today().isoformat()

    inv_lines = [
        {
            "item_id":     l.get("item_id"),
            "description": l.get("description", ""),
            "quantity":    l.get("qty", 1),
            "unit_price":  l.get("unit_price", 0),
            "tax_code":    l.get("tax_code", "GST"),
            "account_id":  l.get("account_id") or default_income_id,
            "line_type":   "item",
        }
        for l in lines
    ]

    comments = f"tender={tender}"
    if terminal_tx_id:
        comments += f" provider={terminal_provider} tx={terminal_tx_id}"
    if note:
        comments += f" {note}"

    inv_data = {
        "contact_id":        walkin_id,
        "invoice_date":      today,
        "due_date":          today,
        "status":            "Sent",
        "notes":             "POS sale",
        "internal_comments": comments,
    }
    if basket_discount and float(basket_discount) > 0:
        inv_data["discount_type"]  = "percent"
        inv_data["discount_value"] = round(float(basket_discount), 2)

    invoice_id = save_invoice(db_path, inv_data, inv_lines)

    conn = get_connection(db_path)
    inv = conn.execute(
        "SELECT total, invoice_number FROM invoices WHERE id=?", (invoice_id,)
    ).fetchone()
    conn.close()
    total          = inv["total"]
    invoice_number = inv["invoice_number"]

    change = 0.0
    payment_id = None

    if split_tenders:
        cash_amt   = round(float(split_tenders.get("cash", 0)), 2)
        card_amt   = round(float(split_tenders.get("card", 0)), 2)
        sp_tx_id   = split_tenders.get("terminal_tx_id")
        sp_prov    = split_tenders.get("terminal_provider")
        # Cash leg
        record_payment(db_path, {
            "payment_type":    "Receipt",
            "contact_id":      walkin_id,
            "payment_date":    today,
            "amount":          cash_amt,
            "bank_account_id": cash_acct_id,
            "reference":       f"POS-{invoice_number}",
            "description":     "POS sale — cash (split)",
        }, [{"invoice_id": invoice_id, "amount": cash_amt}])
        # Card leg
        card_desc = "POS sale — card (split)"
        if sp_tx_id:
            card_desc += f" provider={sp_prov} tx={sp_tx_id}"
        payment_id = record_payment(db_path, {
            "payment_type":    "Receipt",
            "contact_id":      walkin_id,
            "payment_date":    today,
            "amount":          card_amt,
            "bank_account_id": card_acct_id,
            "reference":       f"POS-{invoice_number}",
            "description":     card_desc,
        }, [{"invoice_id": invoice_id, "amount": card_amt}])
        if session_id is not None:
            conn2 = get_connection(db_path)
            _ensure_pos_session_tables(conn2)
            conn2.execute(
                "INSERT INTO pos_sales (session_id, invoice_id, tender, total, gst, cash_amount, card_amount,"
                " terminal_provider, terminal_rfn) VALUES (?,?,?,?,?,?,?,?,?)",
                (session_id, invoice_id, "split", total, round(float(gst), 2), cash_amt, card_amt,
                 split_tenders.get("terminal_provider") if split_tenders else None,
                 split_tenders.get("terminal_rfn") if split_tenders else None)
            )
            conn2.commit()
            conn2.close()
    elif tender == "account":
        # On-account sale: invoice stays as Sent (unpaid) in AR — no payment recorded
        if session_id is not None:
            conn2 = get_connection(db_path)
            _ensure_pos_session_tables(conn2)
            conn2.execute(
                "INSERT INTO pos_sales (session_id, invoice_id, tender, total, gst) VALUES (?,?,?,?,?)",
                (session_id, invoice_id, "account", total, round(float(gst), 2))
            )
            conn2.commit()
            conn2.close()
    else:
        pmt_data = {
            "payment_type":    "Receipt",
            "contact_id":      walkin_id,
            "payment_date":    today,
            "amount":          total,
            "bank_account_id": bank_acct_id,
            "reference":       f"POS-{invoice_number}",
            "description":     f"POS sale — {tender}",
        }
        payment_id = record_payment(db_path, pmt_data, [{"invoice_id": invoice_id, "amount": total}])

        if tender == "cash" and tendered_amount is not None:
            change = round(float(tendered_amount) - total, 2)

        if session_id is not None:
            conn2 = get_connection(db_path)
            _ensure_pos_session_tables(conn2)
            conn2.execute(
                "INSERT INTO pos_sales (session_id, invoice_id, tender, total, gst,"
                " terminal_provider, terminal_rfn) VALUES (?,?,?,?,?,?,?)",
                (session_id, invoice_id, tender, total, round(float(gst), 2),
                 terminal_provider or None, terminal_rfn or None)
            )
            conn2.commit()
            conn2.close()

    return {
        "invoice_id":     invoice_id,
        "invoice_number": invoice_number,
        "payment_id":     payment_id,
        "total":          total,
        "change":         change,
    }


def get_pos_sales(db_path, limit: int = 50) -> list:
    """Return recent POS sales with tender type and contact name."""
    conn = get_connection(db_path)
    rows = conn.execute("""
        SELECT i.id, i.invoice_number, i.invoice_date, i.total, i.status,
               COALESCE(ps.tender,
                   CASE WHEN i.internal_comments LIKE 'tender=cash%' THEN 'cash' ELSE 'card' END
               ) AS tender,
               COALESCE(c.name, 'Walk-In Customer') AS contact_name,
               CASE WHEN cn.id IS NOT NULL THEN 1 ELSE 0 END AS refunded,
               ps.terminal_provider
        FROM invoices i
        LEFT JOIN pos_sales ps ON ps.invoice_id = i.id
        LEFT JOIN contacts c ON c.id = i.contact_id
        LEFT JOIN invoices cn ON cn.source_invoice_id = i.id
                              AND cn.is_credit_note = 1
                              AND cn.status != 'Void'
        WHERE i.notes = 'POS sale'
        ORDER BY i.id DESC
        LIMIT ?
    """, (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def create_pos_refund(db_path, invoice_id: int, lines: list, tender: str) -> dict:
    """
    Process a POS refund against a completed sale.

    GL flow:
      create_credit_note() → DR Income, DR GST Collected, CR AR  (reverses revenue/GST)
      post_journal()       → DR AR, CR Cash/Card               (cash leaves the drawer)

    Returns {cn_id, cn_number, total, tender}.
    """
    defaults = _ensure_pos_defaults(db_path)
    settings = get_pos_settings(db_path)

    cash_acct = settings.get("cash_account_id") or defaults["cash_account_id"]
    card_acct = settings.get("card_account_id") or defaults["card_account_id"]
    bank_acct = int(cash_acct if tender == "cash" else card_acct)

    today = _date.today().isoformat()

    cn_id = create_credit_note(
        db_path, invoice_id, lines, today,
        memo=f"POS refund — {tender}",
    )

    conn = get_connection(db_path)
    cn  = conn.execute("SELECT invoice_number, total FROM invoices WHERE id=?", (cn_id,)).fetchone()
    ar  = conn.execute("SELECT id FROM accounts WHERE code='1-1200'").fetchone()
    conn.close()

    cn_number = cn["invoice_number"]
    cn_total  = round(float(cn["total"]), 2)
    ar_id     = int(ar["id"]) if ar else None

    if ar_id and bank_acct:
        post_journal(
            db_path, today,
            f"POS refund {cn_number}",
            f"POSREF-{cn_id}",
            [
                {"account_id": ar_id,    "debit": cn_total, "credit": 0},
                {"account_id": bank_acct, "debit": 0,        "credit": cn_total},
            ],
        )

    # Mark CN as settled so it doesn't show as an open credit
    conn2 = get_connection(db_path)
    conn2.execute(
        "UPDATE invoices SET amount_paid=?, amount_applied=? WHERE id=?",
        (cn_total, cn_total, cn_id),
    )
    conn2.commit()
    conn2.close()

    return {"cn_id": cn_id, "cn_number": cn_number, "total": cn_total, "tender": tender}


def get_pos_summary_report(db_path, date_from: str, date_to: str) -> dict:
    """Aggregate POS sales across all sessions whose opened_at falls in [date_from, date_to]."""
    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)

    sessions = conn.execute("""
        SELECT id, opened_at, closed_at, note, opened_by_name
        FROM pos_sessions
        WHERE date(opened_at) BETWEEN ? AND ?
        ORDER BY id ASC
    """, (date_from, date_to)).fetchall()

    empty = {"count": 0, "total": 0.0, "gst": 0.0, "split_cash": 0.0, "split_card": 0.0}
    if not sessions:
        conn.close()
        return {
            "date_from": date_from, "date_to": date_to,
            "session_count": 0, "sessions": [],
            "cash": empty, "card": empty, "split": empty, "account": empty,
            "total": 0.0, "gst": 0.0, "ex_gst": 0.0, "tx_count": 0,
        }

    sess_ids = [s["id"] for s in sessions]
    ph = ",".join("?" * len(sess_ids))

    rows = conn.execute(f"""
        SELECT ps.tender,
               COUNT(*) AS count,
               SUM(ps.total) AS total,
               SUM(COALESCE(il.gst_total, 0)) AS gst,
               COALESCE(SUM(ps.cash_amount), 0) AS split_cash,
               COALESCE(SUM(ps.card_amount), 0) AS split_card
        FROM pos_sales ps
        LEFT JOIN (
            SELECT invoice_id, SUM(gst_amount) AS gst_total
            FROM invoice_lines GROUP BY invoice_id
        ) il ON il.invoice_id = ps.invoice_id
        WHERE ps.session_id IN ({ph})
        GROUP BY ps.tender
    """, sess_ids).fetchall()

    sess_rows = conn.execute(f"""
        SELECT session_id,
               COUNT(*) AS tx_count,
               COALESCE(SUM(total), 0) AS total
        FROM pos_sales
        WHERE session_id IN ({ph})
        GROUP BY session_id
    """, sess_ids).fetchall()
    conn.close()

    by = {r["tender"]: r for r in rows}
    cash_r  = by.get("cash",    empty)
    card_r  = by.get("card",    empty)
    split_r = by.get("split",   empty)
    acct_r  = by.get("account", empty)

    split_cash = round(float(split_r["split_cash"] or 0), 2)
    split_card = round(float(split_r["split_card"] or 0), 2)
    split_gst  = round(float(split_r["gst"] or 0), 2)
    split_tot  = round(float(split_r["total"] or 0), 2)
    split_cnt  = int(split_r["count"] or 0)

    total = round(float(cash_r["total"] or 0) + float(card_r["total"] or 0) + split_tot, 2)
    gst   = round(float(cash_r["gst"] or 0)   + float(card_r["gst"] or 0)   + split_gst, 2)

    st = {r["session_id"]: dict(r) for r in sess_rows}
    session_list = [{
        "id":              s["id"],
        "opened_at":       s["opened_at"],
        "closed_at":       s["closed_at"],
        "note":            s["note"],
        "opened_by_name":  s["opened_by_name"],
        "tx_count":        int((st.get(s["id"]) or {}).get("tx_count") or 0),
        "total":           round(float((st.get(s["id"]) or {}).get("total") or 0), 2),
    } for s in sessions]

    return {
        "date_from":     date_from,
        "date_to":       date_to,
        "session_count": len(sessions),
        "sessions":      session_list,
        "cash":    {"count": int(cash_r["count"] or 0),  "total": round(float(cash_r["total"] or 0), 2),  "gst": round(float(cash_r["gst"] or 0), 2)},
        "card":    {"count": int(card_r["count"] or 0),  "total": round(float(card_r["total"] or 0), 2),  "gst": round(float(card_r["gst"] or 0), 2)},
        "split":   {"count": split_cnt, "total": split_tot, "cash": split_cash, "card": split_card, "gst": split_gst},
        "account": {"count": int(acct_r["count"] or 0), "total": round(float(acct_r["total"] or 0), 2),  "gst": round(float(acct_r["gst"] or 0), 2)},
        "total":   total,
        "gst":     gst,
        "ex_gst":  round(total - gst, 2),
        "tx_count": int(cash_r["count"] or 0) + int(card_r["count"] or 0) + split_cnt,
    }


def get_pos_sessions(db_path, limit: int = 30) -> list:
    """Return recent sessions with aggregated sales totals."""
    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)
    rows = conn.execute("""
        SELECT s.id, s.opened_at, s.closed_at, s.note,
               s.opening_float, s.banked, s.float_kept,
               s.opened_by_name,
               COUNT(ps.id) AS tx_count,
               COALESCE(SUM(ps.total), 0) AS total
        FROM pos_sessions s
        LEFT JOIN pos_sales ps ON ps.session_id = s.id
        GROUP BY s.id
        ORDER BY s.id DESC
        LIMIT ?
    """, (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def open_cash_drawer(db_path) -> tuple:
    """Send ESC/POS cash drawer kick command. Returns (True, 'Opened') or (False, error_msg)."""
    import socket
    settings = get_pos_settings(db_path)
    if not settings.get("printer_enabled"):
        return False, "Printer not enabled in POS settings"
    host = (settings.get("printer_host") or "").strip()
    port = int(settings.get("printer_port") or 9100)
    if not host:
        return False, "Printer host/IP not configured"
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5)
            s.connect((host, port))
            s.sendall(b'\x1b\x70\x00\x19\xfa')  # ESC p 0 — pin 2 kick
        return True, "Opened"
    except socket.timeout:
        return False, f"Printer timeout — could not connect to {host}:{port}"
    except OSError as e:
        return False, f"Drawer error: {e}"


# ── Terminal payment adapters ─────────────────────────────────────────────────

def charge_terminal(db_path, amount_cents: int, reference: str, idempotency_key: str) -> dict:
    """
    Initiate a card payment on the configured terminal.
    Returns {checkout_id, provider} immediately — poll get_terminal_status() for result.
    Linkly uses synchronous mode: this call blocks until the card is tapped (~5–30 s).
    """
    settings = get_pos_settings(db_path)
    settings["_db_path"] = db_path
    provider = settings.get("provider", "")
    if provider == "tyro":
        return _charge_tyro(settings, amount_cents, reference, idempotency_key)
    if provider == "square":
        return _charge_square(settings, amount_cents, reference, idempotency_key)
    if provider == "linkly":
        return _charge_linkly(settings, amount_cents, reference, idempotency_key)
    if provider == "mock":
        return _charge_mock(settings, amount_cents, reference, idempotency_key)
    raise ValueError("No payment terminal configured. Set provider in POS Settings.")


def get_terminal_status(db_path, provider: str, checkout_id: str) -> dict:
    """
    Poll the terminal for payment status.
    Returns {status: 'pending'|'completed'|'declined'|'error', tx_id, method, message}
    """
    settings = get_pos_settings(db_path)
    if provider == "tyro":
        return _get_tyro_status(settings, checkout_id)
    if provider == "square":
        return _get_square_status(settings, checkout_id)
    if provider == "linkly":
        return _get_linkly_status(settings, checkout_id)
    if provider == "mock":
        return _get_mock_status(checkout_id)
    return {"status": "error", "message": f"Unknown provider: {provider}"}


# ── Mock adapter (development / demo — no hardware needed) ───────────────────

_mock_checkouts: dict = {}  # checkout_id -> {created_at, amount}


def _charge_mock(settings, amount_cents, reference, idempotency_key) -> dict:
    cid = f"mock-{_uuid.uuid4().hex[:8]}"
    _mock_checkouts[cid] = {"created_at": _time.time(), "amount": amount_cents}
    return {"checkout_id": cid, "provider": "mock"}


def _get_mock_status(checkout_id) -> dict:
    entry = _mock_checkouts.get(checkout_id)
    if not entry:
        return {"status": "error", "message": "Unknown checkout ID"}
    age = _time.time() - entry["created_at"]
    if age >= 3:
        return {"status": "completed", "tx_id": checkout_id, "method": "visa"}
    return {"status": "pending"}


# ── Tyro adapter (AU primary) ─────────────────────────────────────────────────

def _charge_tyro(settings, amount_cents, reference, idempotency_key) -> dict:
    import urllib.request, json as _json
    url = "https://api.tyro.com/connect/integrations/integrations/transactions"
    payload = {
        "merchantId":              settings.get("device_id", ""),
        "amount":                  str(amount_cents),
        "reference":               reference,
        "integratedReceiptPrinting": False,
        "requestType":             "PURCHASE",
    }
    headers = {
        "Content-Type": "application/json",
        "apiKey":        settings.get("api_key", ""),
    }
    req = urllib.request.Request(
        url, data=_json.dumps(payload).encode(), headers=headers, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = _json.loads(resp.read())
        return {"checkout_id": data.get("transactionId"), "provider": "tyro"}
    except Exception as e:
        raise RuntimeError(f"Tyro: {e}")


def _get_tyro_status(settings, checkout_id) -> dict:
    import urllib.request, json as _json
    url = f"https://api.tyro.com/connect/integrations/integrations/transactions/{checkout_id}"
    req = urllib.request.Request(url, headers={"apiKey": settings.get("api_key", "")})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = _json.loads(resp.read())
        status = data.get("status", "")
        if status == "APPROVED":
            return {
                "status": "completed",
                "tx_id":  checkout_id,
                "method": (data.get("cardType") or "card").lower(),
            }
        if status in ("DECLINED", "FAILED", "CANCELLED"):
            return {"status": "declined", "message": data.get("responseText", "Declined")}
        return {"status": "pending"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


# ── Linkly adapter (AU bank terminals — CBA, NAB, Westpac, ANZ, etc.) ────────

_LINKLY_AUTH = "https://auth.sandbox.cloud.pceftpos.com/v1/tokens/cloudpos"
_LINKLY_TXN  = "https://rest.pos.sandbox.cloud.pceftpos.com/v1/sessions"
_LINKLY_PAIR = "https://auth.sandbox.cloud.pceftpos.com/v1/pairing/cloudpos"

# Permanent UUID identifying Dogbox as the POS vendor to Linkly (self-generated, do not change)
_LINKLY_VENDOR_ID = "1bc05112-2afe-42c8-b0ca-070ed3093e18"

_linkly_token_cache:   dict = {}  # pos_id -> {token, expires_at}
_linkly_checkouts:     dict = {}  # session_uuid -> {status, tx_id, method, rfn}
_linkly_active:        dict = {}  # {session_id, token} for the in-flight transaction (cancel)


def _linkly_get_token(settings) -> str:
    import urllib.request, urllib.error, json as _json
    pos_id = settings.get("device_id") or ""
    if not pos_id:
        raise RuntimeError("Linkly: Register ID not set — re-pair the terminal")
    try:
        _uuid.UUID(pos_id)
    except ValueError:
        pos_id = str(_uuid.uuid5(_uuid.NAMESPACE_DNS, pos_id))
    cache = _linkly_token_cache.get(pos_id)
    if cache and cache["expires_at"] > _time.time() + 60:
        return cache["token"]
    secret = settings.get("api_key", "")
    if not secret:
        raise RuntimeError("Linkly: terminal not paired (no secret stored)")
    payload = {
        "secret":      secret,
        "posName":     "Dogbox Accounting",
        "posVersion":  "1.0",
        "posId":       pos_id,
        "posVendorId": _LINKLY_VENDOR_ID,
    }
    req = urllib.request.Request(
        _LINKLY_AUTH,
        data=_json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = _json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Linkly auth failed: HTTP {e.code} — {body}")
    token = data.get("token") or data.get("Token")
    if not token:
        raise RuntimeError(f"Linkly auth: no token in response — {data}")
    expiry = int(data.get("expirySeconds") or 82800)
    _linkly_token_cache[pos_id] = {"token": token, "expires_at": _time.time() + expiry}
    return token


def _linkly_save_last_session(db_path, session_id: str):
    """Persist the in-flight session ID so power-fail recovery can find it."""
    try:
        from core.database import get_connection as _gc
        conn = _gc(db_path)
        conn.execute("UPDATE pos_settings SET linkly_last_session=? WHERE id=1", (session_id,))
        if conn.execute("SELECT changes()").fetchone()[0] == 0:
            conn.execute("INSERT OR IGNORE INTO pos_settings (id, linkly_last_session) VALUES (1,?)", (session_id,))
        conn.commit()
        conn.close()
    except Exception:
        pass


def _linkly_clear_last_session(db_path):
    try:
        from core.database import get_connection as _gc
        conn = _gc(db_path)
        conn.execute("UPDATE pos_settings SET linkly_last_session='' WHERE id=1")
        conn.commit()
        conn.close()
    except Exception:
        pass


def _linkly_get(d, *keys):
    """Case-insensitive dict get — tries PascalCase then camelCase keys."""
    for k in keys:
        if k in d:
            return d[k]
    return None


_LINKLY_DECLINE_MSGS = {
    "TO": "Payment timed out",
    "51": "Insufficient funds",
    "54": "Card expired",
    "55": "Incorrect PIN",
    "91": "Bank unavailable — please try again",
    "92": "Bank unavailable — please try again",
}


def _linkly_store_result(session_id: str, resp_obj: dict):
    """Parse a Linkly response object and store in _linkly_checkouts."""
    pad  = _linkly_get(resp_obj, "PurchaseAnalysisData", "purchaseAnalysisData") or {}
    code = _linkly_get(resp_obj, "ResponseCode", "responseCode") or ""
    success = _linkly_get(resp_obj, "Success", "success") or False
    if success and code in ("00", "08"):
        card = _linkly_get(resp_obj, "CardType", "cardType") or "card"
        _linkly_checkouts[session_id] = {
            "status":             "completed",
            "tx_id":              session_id,
            "method":             card.strip().lower(),
            "rfn":                pad.get("RFN") or pad.get("rfn") or "",
            "signature_required": code == "08",
        }
    else:
        raw  = _linkly_get(resp_obj, "ResponseText", "responseText") or ""
        msg  = _LINKLY_DECLINE_MSGS.get(code) or ("Declined" if raw.upper() == raw else raw) or "Declined"
        _linkly_checkouts[session_id] = {
            "status":  "declined",
            "message": msg,
        }


def _charge_linkly(settings, amount_cents, reference, idempotency_key) -> dict:
    import urllib.request, urllib.error, json as _json
    db_path    = settings.get("_db_path")
    token      = _linkly_get_token(settings)
    session_id = str(_uuid.uuid4())
    url        = f"{_LINKLY_TXN}/{session_id}/transaction?async=false"
    payload    = {
        "Request": {
            "Merchant":          "00",
            "Application":       "00",
            "TxnType":           "P",
            "AmtPurchase":       amount_cents,
            "TxnRef":            idempotency_key.replace('-', '')[:16],
            "CurrencyCode":      "AUD",
            "CutReceipt":        "0",
            "ReceiptAutoPrint":  "0",
            "PurchaseAnalysisData": {
                "OPR": "00|Dogbox POS",
                "AMT": str(amount_cents).zfill(9),
                "PCM": "0000",
            },
        }
    }
    req = urllib.request.Request(
        url,
        data=_json.dumps(payload).encode(),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"},
        method="POST",
    )
    _linkly_active["session_id"] = session_id
    _linkly_active["token"]      = token
    if db_path:
        _linkly_save_last_session(db_path, session_id)
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = _json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        code = e.code
        if code == 408:
            raise RuntimeError(f"Linkly: request timed out (408) — use 'Recover Last Transaction' to check status")
        if 500 <= code <= 599:
            raise RuntimeError(f"Linkly: server error ({code}) — use 'Recover Last Transaction' to check status")
        raise RuntimeError(f"Linkly: HTTP {code} — {body}")
    finally:
        _linkly_active.clear()
        if db_path:
            _linkly_clear_last_session(db_path)
    _linkly_store_result(session_id, data.get("Response") or data.get("response") or {})
    return {"checkout_id": session_id, "provider": "linkly"}


def cancel_linkly_transaction(db_path) -> dict:
    """Send Key=0 (cancel) to the currently in-flight Linkly transaction."""
    import urllib.request, urllib.error, json as _json
    session_id = _linkly_active.get("session_id")
    token      = _linkly_active.get("token")
    if not session_id or not token:
        return {"cancelled": False, "message": "No active Linkly transaction"}
    url     = f"{_LINKLY_TXN}/{session_id}/sendkey?async=false"
    payload = {"Request": {"Key": "0"}}
    req     = urllib.request.Request(
        url,
        data=_json.dumps(payload).encode(),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            _json.loads(resp.read())
        return {"cancelled": True}
    except urllib.error.HTTPError as e:
        return {"cancelled": False, "message": f"Linkly: HTTP {e.code}"}
    except Exception as e:
        return {"cancelled": False, "message": str(e)}


def settle_linkly(db_path) -> dict:
    """Trigger an end-of-day settlement on the Linkly terminal."""
    import urllib.request, urllib.error, json as _json
    settings   = get_pos_settings(db_path)
    token      = _linkly_get_token(settings)
    session_id = str(_uuid.uuid4())
    url        = f"{_LINKLY_TXN}/{session_id}/settlement?async=false"
    payload    = {
        "Request": {
            "Merchant":          "00",
            "SettlementType":    "S",
            "Application":       "00",
            "ReceiptAutoPrint":  "0",
            "CutReceipt":        "0",
        }
    }
    req = urllib.request.Request(
        url,
        data=_json.dumps(payload).encode(),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = _json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Linkly settlement: HTTP {e.code} — {body}")
    resp_obj = data.get("Response") or data.get("response") or {}
    success  = _linkly_get(resp_obj, "Success", "success") or False
    return {
        "success": success,
        "response_code": _linkly_get(resp_obj, "ResponseCode", "responseCode") or "",
        "response_text": _linkly_get(resp_obj, "ResponseText", "responseText") or "",
    }


def _get_linkly_status(settings, checkout_id) -> dict:
    entry = _linkly_checkouts.get(checkout_id)
    if entry:
        return entry
    # Recovery path: app restarted mid-transaction — query Linkly with exponential backoff
    import urllib.request, urllib.error, json as _json
    token   = _linkly_get_token(settings)
    url     = f"{_LINKLY_TXN}/{checkout_id}/transaction"
    delay   = 1
    for attempt in range(6):
        try:
            req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
            with urllib.request.urlopen(req, timeout=15) as resp:
                if resp.status == 202:
                    return {"status": "pending"}
                data     = _json.loads(resp.read())
                resp_obj = data.get("Response") or data.get("response") or {}
                code     = _linkly_get(resp_obj, "ResponseCode", "responseCode") or ""
                pad      = _linkly_get(resp_obj, "PurchaseAnalysisData", "purchaseAnalysisData") or {}
                if (_linkly_get(resp_obj, "Success", "success") or False) and code in ("00", "08"):
                    card = _linkly_get(resp_obj, "CardType", "cardType") or "card"
                    return {"status": "completed", "tx_id": checkout_id,
                            "method": card.strip().lower(),
                            "rfn":    pad.get("RFN") or pad.get("rfn") or "",
                            "signature_required": code == "08"}
                return {"status": "declined", "message": resp_obj.get("ResponseText", "Declined")}
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return {"status": "error", "message": "Transaction not found on Linkly"}
            if e.code == 408 or 500 <= e.code <= 599:
                if attempt < 5:
                    _time.sleep(delay)
                    delay = min(delay * 2, 64)
                    continue
            return {"status": "error", "message": f"Linkly: HTTP {e.code}"}
        except Exception as e:
            return {"status": "error", "message": str(e)}
    return {"status": "error", "message": "Linkly: recovery failed after retries"}


def refund_linkly_terminal(db_path, invoice_id: int, amount_cents: int) -> dict:
    """Issue a card refund via Linkly, using the RFN from the original purchase if available."""
    import urllib.request, urllib.error, json as _json
    from core.database import get_connection as _gc
    conn = _gc(db_path)
    row  = conn.execute(
        "SELECT terminal_rfn FROM pos_sales WHERE invoice_id=? AND terminal_provider='linkly' LIMIT 1",
        (invoice_id,)
    ).fetchone()
    conn.close()
    rfn = (row["terminal_rfn"] if row else None) or ""
    pad = {"OPR": "00|Dogbox POS", "AMT": str(amount_cents).zfill(9), "PCM": "0000"}
    if rfn:
        pad["RFN"] = rfn
    settings   = get_pos_settings(db_path)
    token      = _linkly_get_token(settings)
    session_id = str(_uuid.uuid4())
    url        = f"{_LINKLY_TXN}/{session_id}/transaction?async=false"
    payload    = {
        "Request": {
            "Merchant":             "00",
            "Application":          "00",
            "TxnType":              "R",
            "AmtPurchase":          amount_cents,
            "TxnRef":               f"REF-{session_id[:12]}",
            "CurrencyCode":         "AUD",
            "CutReceipt":           "0",
            "ReceiptAutoPrint":     "0",
            "PurchaseAnalysisData": pad,
        }
    }
    req = urllib.request.Request(
        url,
        data=_json.dumps(payload).encode(),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = _json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Linkly refund: HTTP {e.code} — {body}")
    resp_obj = data.get("Response") or data.get("response") or {}
    code = _linkly_get(resp_obj, "ResponseCode", "responseCode") or ""
    text = _linkly_get(resp_obj, "ResponseText", "responseText") or "Declined"
    if (_linkly_get(resp_obj, "Success", "success") or False) and code == "00":
        return {"approved": True, "response_text": text}
    raise RuntimeError(f"Terminal refund declined: {text} ({code})" if code else f"Terminal refund declined: {text}")


def recover_linkly_startup(db_path) -> dict:
    """
    Called on POS startup. If a charge was in-flight when the app last stopped,
    do a recovery GET to find the result. Returns the transaction status or None.
    """
    import urllib.request, urllib.error, json as _json
    settings   = get_pos_settings(db_path)
    session_id = (settings.get("linkly_last_session") or "").strip()
    if not session_id:
        return {"pending": False}
    token = _linkly_get_token(settings)
    url   = f"{_LINKLY_TXN}/{session_id}/transaction"
    delay = 1
    for attempt in range(6):
        try:
            req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
            with urllib.request.urlopen(req, timeout=15) as resp:
                if resp.status == 202:
                    return {"pending": True, "session_id": session_id, "status": "pending"}
                data     = _json.loads(resp.read())
                resp_obj = data.get("Response") or data.get("response") or {}
                code     = _linkly_get(resp_obj, "ResponseCode", "responseCode") or ""
                pad      = _linkly_get(resp_obj, "PurchaseAnalysisData", "purchaseAnalysisData") or {}
                _linkly_clear_last_session(db_path)
                txn_ref = _linkly_get(resp_obj, "TxnRef", "txnRef") or session_id[:16]
                if (_linkly_get(resp_obj, "Success", "success") or False) and code in ("00", "08"):
                    return {
                        "pending":    True,
                        "session_id": session_id,
                        "tx_id":      txn_ref,
                        "status":     "completed",
                        "rfn":        pad.get("RFN") or pad.get("rfn") or "",
                        "amount":     _linkly_get(resp_obj, "AmtPurchase", "amtPurchase") or 0,
                        "card_type":  _linkly_get(resp_obj, "CardType", "cardType") or "",
                        "response_text": _linkly_get(resp_obj, "ResponseText", "responseText") or "Approved",
                        "signature_required": code == "08",
                    }
                return {
                    "pending":    True,
                    "session_id": session_id,
                    "tx_id":      txn_ref,
                    "status":     "declined",
                    "response_text": _linkly_get(resp_obj, "ResponseText", "responseText") or "Declined",
                }
        except urllib.error.HTTPError as e:
            if e.code == 404:
                _linkly_clear_last_session(db_path)
                return {"pending": False}
            if e.code == 408 or 500 <= e.code <= 599:
                if attempt < 5:
                    _time.sleep(delay)
                    delay = min(delay * 2, 64)
                    continue
            _linkly_clear_last_session(db_path)
            return {"pending": False}
        except Exception:
            _linkly_clear_last_session(db_path)
            return {"pending": False}
    _linkly_clear_last_session(db_path)
    return {"pending": False}


def pair_linkly_terminal(db_path, username: str, password: str, pair_code: str) -> dict:
    """Pair with a Linkly terminal. Stores the returned secret as api_key in pos_settings."""
    import urllib.request, urllib.error, json as _json
    from core.pos_settings import get_pos_settings, save_pos_settings
    payload = {"username": username, "password": password, "pairCode": pair_code}
    req = urllib.request.Request(
        _LINKLY_PAIR,
        data=_json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = _json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Pairing failed: HTTP {e.code} — {body}")
    secret = data.get("secret") or data.get("Secret")
    if not secret:
        raise RuntimeError(f"Pairing failed: no secret in response — {data}")
    settings = get_pos_settings(db_path)
    pos_id   = settings.get("device_id") or str(_uuid.uuid4())
    settings["api_key"]  = secret
    settings["device_id"] = pos_id
    settings["provider"] = "linkly"
    save_pos_settings(db_path, settings)
    _linkly_token_cache.pop(pos_id, None)
    return {"paired": True, "pos_id": pos_id}


# ── Square adapter (secondary) ────────────────────────────────────────────────

_SQUARE_VERSION = "2024-01-17"


def _square_base(settings) -> str:
    if settings.get("square_sandbox"):
        return "https://connect.squareupsandbox.com/v2"
    return "https://connect.squareup.com/v2"


def _charge_square(settings, amount_cents, reference, idempotency_key) -> dict:
    import urllib.request, urllib.error, json as _json
    url = f"{_square_base(settings)}/terminals/checkouts"
    checkout = {
        "amount_money":   {"amount": amount_cents, "currency": "AUD"},
        "reference_id":   reference,
        "device_options": {"device_id": settings.get("device_id", "")},
        "payment_type":   "CARD_PRESENT",
    }
    if settings.get("location_id"):
        checkout["location_id"] = settings["location_id"]
    payload = {"idempotency_key": idempotency_key, "checkout": checkout}
    headers = {
        "Content-Type":   "application/json",
        "Authorization":  f"Bearer {settings.get('api_key', '')}",
        "Square-Version": _SQUARE_VERSION,
    }
    req = urllib.request.Request(
        url, data=_json.dumps(payload).encode(), headers=headers, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = _json.loads(resp.read())
        checkout_id = (data.get("checkout") or {}).get("id")
        return {"checkout_id": checkout_id, "provider": "square"}
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Square {e.code}: {body}")
    except Exception as e:
        raise RuntimeError(f"Square: {e}")


# ── Thermal receipt printing ──────────────────────────────────────────────────

_ESC = b'\x1b'
_GS  = b'\x1d'
_LF  = b'\x0a'


def _ep(cmd: bytes) -> bytes:
    return _ESC + cmd


def get_receipt_data(db_path, invoice_id, tender: str, tendered: float, change: float,
                     split_tenders: dict = None) -> dict:
    from core.ledger import get_invoice
    from core.database import get_connection as _gc
    inv_data = get_invoice(db_path, invoice_id)
    if not inv_data:
        raise ValueError(f"Invoice {invoice_id} not found")
    inv   = inv_data["invoice"]
    lines = inv_data["lines"]
    conn  = _gc(db_path)
    co    = conn.execute("SELECT * FROM company LIMIT 1").fetchone()
    conn.close()
    co = dict(co) if co else {}
    item_lines = [l for l in lines if (l.get("line_type") or "item") != "comment"]
    subtotal   = sum(float(l.get("quantity", 0)) * float(l.get("unit_price", 0)) for l in item_lines)
    gst_total  = sum(float(l.get("gst_amount") or 0) for l in item_lines)
    return {
        "company_name":   co.get("name", ""),
        "abn":            co.get("abn", ""),
        "address":        co.get("address", ""),
        "phone":          co.get("phone", ""),
        "invoice_number": inv.get("invoice_number", ""),
        "invoice_date":   inv.get("invoice_date", ""),
        "lines": [
            {
                "description": l.get("description", ""),
                "qty":         float(l.get("quantity", 0)),
                "unit_price":  float(l.get("unit_price", 0)),
                "gst_amount":  float(l.get("gst_amount") or 0),
                "line_total":  float(l.get("line_total", 0)),
                "line_type":   l.get("line_type") or "item",
            }
            for l in lines
        ],
        "subtotal":  round(subtotal, 2),
        "gst_total": round(gst_total, 2),
        "total":     float(inv.get("total", 0)),
        "tender":        tender,
        "tendered":      float(tendered or 0),
        "change":        float(change or 0),
        "split_tenders": split_tenders,
    }


def _format_receipt_escpos(r: dict, width: int = 48, is_refund: bool = False,
                           is_credit_note: bool = False, footer: str = "") -> bytes:
    """Build an ESC/POS byte sequence for a 80mm (48-char) thermal receipt."""
    from datetime import datetime

    def pad(left: str, right: str) -> str:
        gap = width - len(left) - len(right)
        return left + " " * max(1, gap) + right

    out = bytearray()

    def txt(s: str = ""):
        out.extend(s.encode("ascii", errors="replace") + _LF)

    def div():
        txt("-" * width)

    def bold(on: bool):
        out.extend(_ep(b'E' + bytes([1 if on else 0])))

    def align(n: int):   # 0=left, 1=centre, 2=right
        out.extend(_ep(b'a' + bytes([n])))

    def dbl_height(on: bool):
        out.extend(_ep(b'!' + bytes([0x10 if on else 0x00])))

    def feed(n: int):
        out.extend(_ep(b'd' + bytes([n])))

    # init
    out.extend(_ep(b'@'))
    feed(1)

    # company header — centred
    align(1)
    bold(True)
    dbl_height(True)
    name = r.get("company_name", "")[:24]
    txt(name)
    dbl_height(False)
    bold(False)
    if r.get("abn"):
        txt(f"ABN {r['abn']}")
    if r.get("address"):
        txt(r["address"][:width])
    if r.get("phone"):
        txt(r["phone"][:width])
    align(0)

    div()
    align(1)
    bold(True)
    if is_refund:
        txt("REFUND RECEIPT")
    elif is_credit_note:
        txt("CREDIT NOTE")
    else:
        txt("TAX INVOICE")
    bold(False)
    align(0)
    div()

    now = datetime.now()
    txt(f"Date: {now.strftime('%d/%m/%Y')}  Time: {now.strftime('%H:%M')}")
    txt(f"Receipt: {r.get('invoice_number', '')}")
    div()

    # line items
    txt(pad("DESCRIPTION", "TOTAL"))
    div()
    for line in r.get("lines", []):
        if line["line_type"] == "comment":
            txt(line["description"][:width])
            continue
        desc      = line["description"]
        qty       = line["qty"]
        uprice    = line["unit_price"]
        ltotal    = line["line_total"]
        total_str = f"${ltotal:.2f}"
        qty_str   = f"  {qty:g} x ${uprice:.2f}"
        if len(desc) + len(total_str) + 1 <= width:
            txt(pad(desc, total_str))
        else:
            txt(desc[:width])
            txt(pad(qty_str, total_str))

    div()
    txt(pad("Subtotal:", f"${r['subtotal']:.2f}"))
    txt(pad("GST (10%):", f"${r['gst_total']:.2f}"))
    bold(True)
    txt(pad("TOTAL:", f"${r['total']:.2f}"))
    bold(False)
    div()

    tender_label = r.get("tender", "cash").upper()
    split = r.get("split_tenders")
    if is_credit_note:
        txt(pad("STORE CREDIT:", f"${r['tendered']:.2f}"))
    elif is_refund:
        txt(pad(f"REFUNDED VIA {tender_label}:", f"${r['tendered']:.2f}"))
    elif split:
        txt(pad("CASH:", f"${float(split.get('cash', 0)):.2f}"))
        txt(pad("CARD:", f"${float(split.get('card', 0)):.2f}"))
    else:
        txt(pad(f"{tender_label}:", f"${r['tendered']:.2f}"))
        if r.get("change", 0) > 0.005:
            txt(pad("CHANGE:", f"${r['change']:.2f}"))
    div()

    align(1)
    txt(footer.strip() if footer and footer.strip() else "Thank you for your business!")
    txt()
    align(0)

    feed(4)
    # full cut
    out.extend(_GS + b'V\x41\x00')
    return bytes(out)


def print_receipt(db_path, invoice_id, tender: str, tendered: float, change: float,
                  split_tenders: dict = None):
    """Send a formatted ESC/POS receipt to the configured network printer.

    Returns (True, 'Printed') or (False, error_message).
    """
    import socket
    from core.pos_settings import get_pos_settings
    settings = get_pos_settings(db_path)
    if not settings.get("printer_enabled"):
        return False, "Printer not enabled in POS settings"
    if settings.get("printer_type", "network") != "network":
        return False, "Only network printers are currently supported"
    host = (settings.get("printer_host") or "").strip()
    port = int(settings.get("printer_port") or 9100)
    if not host:
        return False, "Printer host/IP not configured"
    receipt = get_receipt_data(db_path, invoice_id, tender, tendered, change, split_tenders)
    data    = _format_receipt_escpos(receipt, footer=settings.get("receipt_footer", ""))
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5)
            s.connect((host, port))
            s.sendall(data)
        return True, "Printed"
    except socket.timeout:
        return False, f"Printer timeout — could not connect to {host}:{port}"
    except OSError as e:
        return False, f"Printer error: {e}"


def print_refund_receipt(db_path, cn_id: int, tender: str, amount: float):
    """Print a REFUND RECEIPT for a credit note. Returns (True, 'Printed') or (False, msg)."""
    import socket
    from core.pos_settings import get_pos_settings
    settings = get_pos_settings(db_path)
    if not settings.get("printer_enabled"):
        return False, "Printer not enabled in POS settings"
    if settings.get("printer_type", "network") != "network":
        return False, "Only network printers are currently supported"
    host = (settings.get("printer_host") or "").strip()
    port = int(settings.get("printer_port") or 9100)
    if not host:
        return False, "Printer host/IP not configured"
    receipt = get_receipt_data(db_path, cn_id, tender, amount, 0)
    data = _format_receipt_escpos(receipt, is_refund=True, footer=settings.get("receipt_footer", ""))
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5)
            s.connect((host, port))
            s.sendall(data)
        return True, "Printed"
    except socket.timeout:
        return False, f"Printer timeout — could not connect to {host}:{port}"
    except OSError as e:
        return False, f"Printer error: {e}"


def print_recovery_receipt(db_path, amount_cents: int, rfn: str, tx_id: str, response_text: str) -> tuple:
    """Print a minimal ESC/POS slip for a power-fail recovered terminal transaction."""
    import socket
    from datetime import datetime
    settings = get_pos_settings(db_path)
    if not settings.get("printer_enabled"):
        return False, "Printer not enabled in POS settings"
    host = (settings.get("printer_host") or "").strip()
    port = int(settings.get("printer_port") or 9100)
    if not host:
        return False, "Printer host/IP not configured"

    W = 48
    def centre(s): return s.center(W)
    def line(s=""):  return (s[:W] + "\n").encode()

    out = bytearray()
    out += b'\x1b\x40'                        # ESC @ — init
    out += b'\x1b\x61\x01'                    # centre align
    out += b'\x1b\x21\x30'                    # double-height + bold
    out += "TERMINAL RECOVERY\n".encode()
    out += b'\x1b\x21\x00'                    # normal
    out += b'\x1b\x61\x00'                    # left align
    out += b'\x1b\x45\x01'                    # bold on
    out += f"{'STATUS':<16}{response_text[:32]}\n".encode()
    out += b'\x1b\x45\x00'                    # bold off
    out += f"{'AMOUNT':<16}${amount_cents / 100:.2f}\n".encode()
    out += f"{'TXN REF':<16}{tx_id[:16]}\n".encode()
    if rfn:
        out += f"{'RFN':<16}{rfn}\n".encode()
    out += f"{'PRINTED':<16}{datetime.now().strftime('%Y-%m-%d %H:%M')}\n".encode()
    out += b'\x1b\x61\x01'                    # centre
    out += b'\n' * 2
    out += "Check if corresponding sale was recorded.\n".encode()
    out += "If not, record manually.\n".encode()
    out += b'\n' * 4
    out += b'\x1d\x56\x41\x05'               # partial cut

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5)
            s.connect((host, port))
            s.sendall(bytes(out))
        return True, "Printed"
    except socket.timeout:
        return False, f"Printer timeout — could not connect to {host}:{port}"
    except OSError as e:
        return False, f"Printer error: {e}"


def create_pos_store_credit(db_path, invoice_id: int, lines: list) -> dict:
    """
    Issue a store credit (open credit note) against a completed sale.
    No cash movement — the CN is left unapplied for use against future invoices.
    Returns {cn_id, cn_number, total}.
    """
    today = _date.today().isoformat()
    cn_id = create_credit_note(
        db_path, invoice_id, lines, today,
        memo="POS store credit",
    )
    conn = get_connection(db_path)
    cn = conn.execute("SELECT invoice_number, total FROM invoices WHERE id=?", (cn_id,)).fetchone()
    conn.close()
    return {"cn_id": cn_id, "cn_number": cn["invoice_number"], "total": round(float(cn["total"]), 2)}


def print_credit_note_receipt(db_path, cn_id: int, amount: float):
    """Print a CREDIT NOTE receipt for a store credit. Returns (True, 'Printed') or (False, msg)."""
    import socket
    from core.pos_settings import get_pos_settings
    settings = get_pos_settings(db_path)
    if not settings.get("printer_enabled"):
        return False, "Printer not enabled in POS settings"
    if settings.get("printer_type", "network") != "network":
        return False, "Only network printers are currently supported"
    host = (settings.get("printer_host") or "").strip()
    port = int(settings.get("printer_port") or 9100)
    if not host:
        return False, "Printer host/IP not configured"
    receipt = get_receipt_data(db_path, cn_id, "credit", amount, 0)
    data = _format_receipt_escpos(receipt, is_credit_note=True, footer=settings.get("receipt_footer", ""))
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(5)
            s.connect((host, port))
            s.sendall(data)
        return True, "Printed"
    except socket.timeout:
        return False, f"Printer timeout — could not connect to {host}:{port}"
    except OSError as e:
        return False, f"Printer error: {e}"


def get_pos_analytics(db_path, date_from: str, date_to: str) -> dict:
    """Return analytics data for a date range: daily totals, top items, hourly pattern."""
    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)

    sess_rows = conn.execute(
        "SELECT id FROM pos_sessions WHERE date(opened_at) BETWEEN ? AND ?",
        (date_from, date_to)
    ).fetchall()

    empty = {
        "date_from": date_from, "date_to": date_to,
        "summary": {"total": 0, "tx_count": 0, "avg_tx": 0,
                    "cash_total": 0, "card_total": 0, "gst": 0},
        "daily": [], "top_items": [], "hourly": [],
    }
    if not sess_rows:
        conn.close()
        return empty

    ph = ",".join("?" * len(sess_rows))
    ids = [r["id"] for r in sess_rows]

    daily = conn.execute(f"""
        SELECT date(ps.created_at) AS day,
               COUNT(*) AS tx_count,
               COALESCE(SUM(ps.total), 0) AS total,
               COALESCE(SUM(CASE WHEN ps.tender='cash' THEN ps.total ELSE 0 END), 0) AS cash,
               COALESCE(SUM(CASE WHEN ps.tender='card' THEN ps.total ELSE 0 END), 0) AS card
        FROM pos_sales ps
        WHERE ps.session_id IN ({ph})
        GROUP BY day ORDER BY day
    """, ids).fetchall()

    hourly = conn.execute(f"""
        SELECT CAST(strftime('%H', ps.created_at) AS INTEGER) AS hour,
               COUNT(*) AS tx_count,
               COALESCE(SUM(ps.total), 0) AS total
        FROM pos_sales ps
        WHERE ps.session_id IN ({ph})
        GROUP BY hour ORDER BY hour
    """, ids).fetchall()

    top_items = conn.execute(f"""
        SELECT il.description,
               ROUND(SUM(il.quantity), 2) AS qty,
               ROUND(SUM(il.line_total), 2) AS revenue
        FROM invoice_lines il
        WHERE il.invoice_id IN (
            SELECT invoice_id FROM pos_sales WHERE session_id IN ({ph})
        )
        AND (il.line_type IS NULL OR il.line_type = 'item')
        GROUP BY il.description
        ORDER BY revenue DESC
        LIMIT 10
    """, ids).fetchall()

    tender_rows = conn.execute(f"""
        SELECT tender, COUNT(*) AS count, COALESCE(SUM(total), 0) AS total
        FROM pos_sales WHERE session_id IN ({ph})
        GROUP BY tender
    """, ids).fetchall()

    gst_row = conn.execute(f"""
        SELECT COALESCE(SUM(il.gst_amount), 0) AS gst
        FROM invoice_lines il
        WHERE il.invoice_id IN (
            SELECT invoice_id FROM pos_sales WHERE session_id IN ({ph})
        )
    """, ids).fetchone()

    conn.close()

    tb = {r["tender"]: dict(r) for r in tender_rows}
    grand = sum(round(float(r["total"] or 0), 2) for r in tender_rows if r["tender"] != "account")
    tx_n  = sum(int(r["count"] or 0) for r in tender_rows if r["tender"] != "account")

    return {
        "date_from": date_from,
        "date_to":   date_to,
        "summary": {
            "total":      round(grand, 2),
            "tx_count":   tx_n,
            "avg_tx":     round(grand / tx_n, 2) if tx_n else 0,
            "cash_total": round(float((tb.get("cash") or {}).get("total") or 0), 2),
            "card_total": round(float((tb.get("card") or {}).get("total") or 0), 2),
            "gst":        round(float((gst_row["gst"] if gst_row else 0) or 0), 2),
        },
        "daily":     [{"day": r["day"], "tx_count": int(r["tx_count"]),
                       "total": round(float(r["total"]), 2),
                       "cash":  round(float(r["cash"]),  2),
                       "card":  round(float(r["card"]),  2)} for r in daily],
        "top_items": [{"description": r["description"],
                       "qty":     float(r["qty"] or 0),
                       "revenue": round(float(r["revenue"] or 0), 2)} for r in top_items],
        "hourly":    [{"hour": int(r["hour"]), "tx_count": int(r["tx_count"]),
                       "total": round(float(r["total"]), 2)} for r in hourly],
    }


def get_pos_staff_report(db_path, date_from: str, date_to: str) -> dict:
    """Return POS sales aggregated by operator (opened_by_name) for a date range."""
    conn = get_connection(db_path)
    _ensure_pos_session_tables(conn)
    rows = conn.execute("""
        SELECT COALESCE(ses.opened_by_name, 'Unknown') AS operator,
               COUNT(DISTINCT ses.id) AS session_count,
               COUNT(ps.id) AS tx_count,
               COALESCE(SUM(ps.total), 0) AS total
        FROM pos_sessions ses
        LEFT JOIN pos_sales ps ON ps.session_id = ses.id
        WHERE date(ses.opened_at) BETWEEN ? AND ?
        GROUP BY operator
        ORDER BY total DESC
    """, (date_from, date_to)).fetchall()
    conn.close()
    staff = []
    for r in rows:
        tx  = int(r["tx_count"] or 0)
        tot = round(float(r["total"] or 0), 2)
        staff.append({
            "operator":      r["operator"],
            "session_count": int(r["session_count"] or 0),
            "tx_count":      tx,
            "total":         tot,
            "avg_tx":        round(tot / tx, 2) if tx else 0,
        })
    return {"date_from": date_from, "date_to": date_to, "staff": staff}


def _get_square_status(settings, checkout_id) -> dict:
    import urllib.request, json as _json
    url = f"{_square_base(settings)}/terminals/checkouts/{checkout_id}"
    headers = {
        "Authorization":  f"Bearer {settings.get('api_key', '')}",
        "Square-Version": _SQUARE_VERSION,
    }
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = _json.loads(resp.read())
        checkout = data.get("checkout") or {}
        status = checkout.get("status", "")
        if status == "COMPLETED":
            return {"status": "completed", "tx_id": checkout_id, "method": "card"}
        if status in ("CANCELED", "CANCEL_REQUESTED"):
            return {"status": "declined", "message": "Payment cancelled"}
        return {"status": "pending"}
    except Exception as e:
        return {"status": "error", "message": str(e)}
