#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
#  dbox.sh  —  Dogbox Accounting Linux Launcher
#  Supports: Ubuntu, Debian, Linux Mint, Pop!_OS, and any apt-based distro.
#  Usage:  ./dbox.sh   or   bash dbox.sh
# ─────────────────────────────────────────────────────────────────────────────

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'
info()  { echo -e "${CYAN}[Dogbox Accounting]${RESET} $*"; }
ok()    { echo -e "${GREEN}[  OK  ]${RESET} $*"; }
warn()  { echo -e "${YELLOW}[ WARN ]${RESET} $*"; }
error() { echo -e "${RED}[ERROR ]${RESET} $*"; }

echo -e "${BOLD}Dogbox Accounting — Australian Accounting${RESET}"
echo "────────────────────────────────────"

# ── 1. Find Python 3.9+ ───────────────────────────────────────────────────────
PYTHON=""
for cmd in python3 python3.13 python3.12 python3.11 python3.10 python3.9; do
    if command -v "$cmd" &>/dev/null; then
        VER=$("$cmd" -c "import sys; print(sys.version_info >= (3,9))" 2>/dev/null)
        if [ "$VER" = "True" ]; then
            PYTHON="$cmd"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    error "Python 3.9 or later is required but was not found."
    echo
    echo "Install it with:"
    echo "  sudo apt install python3"
    exit 1
fi

PY_VER=$("$PYTHON" --version 2>&1)
ok "Found $PY_VER  ($PYTHON)"

# ── 2. Check required packages ────────────────────────────────────────────────
MISSING_PKGS=()
"$PYTHON" -c "import flask"          2>/dev/null || MISSING_PKGS+=("flask")
"$PYTHON" -c "import reportlab"      2>/dev/null || MISSING_PKGS+=("reportlab")
"$PYTHON" -c "from PIL import Image" 2>/dev/null || MISSING_PKGS+=("pillow")

if [ ${#MISSING_PKGS[@]} -gt 0 ]; then
    warn "Missing packages: ${MISSING_PKGS[*]}"
    echo "  Run lininstall.sh to install them, or:"
    echo "    pip3 install ${MISSING_PKGS[*]}"
    echo
fi

# ── 3. Launch dbox ────────────────────────────────────────────────────────────
echo
info "Starting Dogbox..."
exec "$PYTHON" dbox.py "$@"
