import os
import tempfile
from datetime import date, timedelta
from collections import defaultdict
from flask import Blueprint, request, jsonify, send_file

from web.shared import db, ok, err, login_required, tier_required, current_user, dict_rows, _get_pdf_watermark, _get_combined_pdf_footer
from core.ledger import (
    get_contacts, get_bills, get_bill, save_bill, void_bill,
    mark_bill_approved, record_payment, copy_bill,
)
from core.jobs import get_job_for_bill, get_job, set_bill_job
from core.database import get_connection
from core.inventory import get_stock_receipts, receive_bill_stock
from core.budget import audit
from core.bill_pdf import generate_bill_pdf
from core.email_invoice import send_pdf_email

bp = Blueprint('bills', __name__)


@bp.route("/api/bills")
@login_required
def api_bills():
    contacts = {c["id"]: c["name"] for c in get_contacts(db())}
    result = []
    for b in dict_rows(get_bills(db())):
        b["contact_name"] = contacts.get(b.get("contact_id"), "—")
        b["total_amount"] = b.get("total", 0)
        b["bill_date"]    = b.get("bill_date") or b.get("created_at","")[:10]
        result.append(b)
    return ok(result)


@bp.route("/api/bills/<int:bid>")
@login_required
def api_bill(bid):
    data = get_bill(db(), bid)
    if not data:
        return err("Not found", 404)
    bill  = dict(data["bill"])
    lines = [dict(l) for l in data["lines"]]
    contacts = {c["id"]: c["name"] for c in get_contacts(db())}
    bill["contact_name"] = contacts.get(bill.get("contact_id"), "—")
    job_id = get_job_for_bill(db(), bid)
    bill["job_id"] = job_id
    if job_id:
        job = get_job(db(), job_id)
        bill["job_name"] = f"{job['job_number']}  {job['name']}" if job else None
    else:
        bill["job_name"] = None
    # Enrich with PO number if this bill was converted from a PO
    if bill.get("po_id"):
        conn = get_connection(db())
        po_row = conn.execute(
            "SELECT po_number FROM purchase_orders WHERE id=?", (bill["po_id"],)
        ).fetchone()
        conn.close()
        bill["po_number"] = po_row["po_number"] if po_row else None
    else:
        bill["po_number"] = None
    return ok({"bill": bill, "lines": lines})


@bp.route("/api/bills/<int:bid>", methods=["PUT"])
@login_required
def api_bill_update(bid):
    data = request.get_json() or {}
    data["id"] = bid
    try:
        save_bill(db(), data, data.get("lines", []))
        if "job_id" in data:
            set_bill_job(db(), bid, data["job_id"] if data["job_id"] else None)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/bills/<int:bid>/void", methods=["POST"])
@login_required
def api_bill_void(bid):
    try:
        void_bill(db(), bid)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "VoidBill", "bills", bid, "voided via web")
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/bills/<int:bid>/copy", methods=["POST"])
@login_required
def api_bill_copy(bid):
    try:
        new_id = copy_bill(db(), bid)
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "CopyBill", "bills", bid, f"new_id={new_id}")
        return ok({"id": new_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/bills/<int:bid>/mark-approved", methods=["POST"])
@login_required
def api_bill_mark_approved(bid):
    try:
        mark_bill_approved(db(), bid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/bills/<int:bid>/pdf", methods=["GET"])
@login_required
def api_bill_pdf(bid):
    try:
        bill_data = get_bill(db(), bid)
        if not bill_data:
            return err("Bill not found", 404)
        bill = bill_data["bill"]
        num = bill.get("bill_number") or f"BILL-{bid}"
        tmp = tempfile.mktemp(suffix=".pdf", prefix=f"{num}_")
        generate_bill_pdf(db(), bid, tmp, watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db()))
        return send_file(tmp, mimetype="application/pdf",
                         as_attachment=True,
                         download_name=f"{num}.pdf")
    except Exception as e:
        return err(str(e))


@bp.route("/api/bills/<int:bid>/email", methods=["POST"])
@login_required
@tier_required("email_docs")
def api_bill_email(bid):
    data = request.get_json() or {}
    to_email = (data.get("to") or "").strip()
    if not to_email:
        return err("Recipient email is required", 400)
    bill_data = get_bill(db(), bid)
    if not bill_data:
        return err("Bill not found", 404)
    bill = bill_data["bill"]
    num = bill.get("bill_number") or f"BILL-{bid}"
    tmp = tempfile.mktemp(suffix=".pdf", prefix=f"{num}_")
    try:
        generate_bill_pdf(db(), bid, tmp, watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db()))
        subject = data.get("subject") or f"Bill {num}"
        body    = data.get("body") or f"Please find attached bill {num}."
        ok_flag, msg = send_pdf_email(db(), tmp, to_email, subject, body)
        if not ok_flag:
            return err(msg)
        return ok()
    except Exception as e:
        return err(str(e))
    finally:
        try: os.unlink(tmp)
        except Exception: pass


@bp.route("/api/bills/<int:bid>/payment", methods=["POST"])
@login_required
def api_bill_payment(bid):
    data = request.get_json() or {}
    try:
        bill_data = get_bill(db(), bid)
        if not bill_data:
            return err("Bill not found", 404)
        bill = bill_data["bill"]
        pid = record_payment(db(), {
            "payment_type":  "Payment",
            "contact_id":    bill.get("contact_id"),
            "payment_date":  data.get("payment_date", str(date.today())),
            "amount":        float(data.get("amount", 0)),
            "bank_account_id": data.get("account_id"),
            "reference":     data.get("reference", ""),
            "description":   f"Bill payment — {bill.get('bill_number','')}",
        }, [{"bill_id": bid, "amount": float(data.get("amount", 0))}])
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "RecordBillPayment", "bills", bid,
              f"amount={data.get('amount')} ref={data.get('reference','')}")
        return ok({"id": pid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/bills/<int:bid>/receive-lines")
@login_required
def api_bill_receive_lines(bid):
    try:
        bill_data = get_bill(db(), bid)
        if not bill_data:
            return err("Bill not found", 404)
        bill     = dict(bill_data["bill"])
        bill_num = bill.get("bill_number") or str(bid)
        conn     = get_connection(db())
        rows = conn.execute("""
            SELECT bl.id                          AS line_id,
                   bl.item_id,
                   bl.description,
                   COALESCE(bl.quantity,     0)   AS ordered,
                   COALESCE(bl.qty_received, 0)   AS received,
                   COALESCE(bl.unit_price,   0)   AS unit_price,
                   i.name                         AS item_name,
                   COALESCE(i.is_inventoried, 0)  AS is_inventoried
            FROM   bill_lines bl
            JOIN   items i ON i.id = bl.item_id
            WHERE  bl.bill_id       = ?
              AND  bl.item_id       IS NOT NULL
              AND  i.is_inventoried = 1
            ORDER  BY bl.id
        """, (bid,)).fetchall()
        conn.close()
        lines = []
        for r in rows:
            ordered  = float(r["ordered"])
            received = float(r["received"])
            lines.append({
                "line_id":     r["line_id"],
                "item_id":     r["item_id"],
                "item_name":   r["item_name"],
                "description": r["description"] or r["item_name"],
                "ordered":     ordered,
                "received":    received,
                "outstanding": max(0.0, ordered - received),
                "unit_price":  float(r["unit_price"]),
            })
        return ok({"lines": lines, "bill_number": bill_num,
                   "contact_name": bill.get("contact_name", "")})
    except Exception as e:
        return err(str(e))


@bp.route("/api/bills/<int:bid>/receipts", methods=["GET"])
@login_required
def api_bill_receipts_get(bid):
    try:
        rows = get_stock_receipts(db(), bill_id=bid)
        return ok({"receipts": [dict(r) for r in rows]})
    except Exception as e:
        return err(str(e))


@bp.route("/api/bills/<int:bid>/receipts", methods=["POST"])
@login_required
def api_bill_receipts_post(bid):
    data = request.get_json() or {}
    lines = data.get("lines", [])
    if not lines:
        return err("No lines provided")
    try:
        bill_data = get_bill(db(), bid)
        if not bill_data:
            return err("Bill not found", 404)
        bill_num     = dict(bill_data["bill"]).get("bill_number") or str(bid)
        receipt_date = data.get("receipt_date", str(date.today()))
        reference    = data.get("reference", "BILL-" + bill_num)
        user         = current_user()
        result = receive_bill_stock(
            db(), bid, lines, receipt_date, reference,
            notes=data.get("notes", ""),
            created_by=user.get("username", "?"),
        )
        audit(db(), user.get("id"), user.get("username", "?"),
              "ReceiveStock", "bills", bid,
              f"receipt_id={result['receipt_id']} lines={len(lines)}")
        return ok(result)
    except Exception as e:
        return err(str(e))


@bp.route("/api/bills", methods=["POST"])
@login_required
def api_bill_save():
    data = request.get_json() or {}
    try:
        bid = save_bill(db(), data, data.get("lines", []))
        job_id = data.get("job_id")
        set_bill_job(db(), bid, job_id if job_id else None)
        return ok({"id": bid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/bills/<int:bid>/job", methods=["GET"])
@login_required
def api_bill_job_get(bid):
    job_id = get_job_for_bill(db(), bid)
    return ok({"job_id": job_id})


@bp.route("/api/bills/<int:bid>/job", methods=["PUT"])
@login_required
def api_bill_job_set(bid):
    data   = request.get_json() or {}
    job_id = data.get("job_id")
    try:
        set_bill_job(db(), bid, job_id if job_id else None)
        return ok()
    except Exception as e:
        return err(str(e))


# ── Supplier Payment Run ──────────────────────────────────────────────────────

@bp.route("/api/bills/payment-run/candidates")
@login_required
def api_bills_payment_run_candidates():
    from core.aba import get_bills_for_aba
    rows = get_bills_for_aba(db())
    rows.sort(key=lambda r: (r.get("due_date") or "9999-99-99", r.get("supplier_name") or ""))
    for r in rows:
        r["has_bank"] = bool(r.get("dest_bsb") and r.get("dest_account"))
    return ok(rows)


@bp.route("/api/bills/payment-run", methods=["POST"])
@login_required
def api_bills_payment_run():
    from collections import defaultdict
    from core.aba import generate_aba, get_payments_for_aba, ABAError

    body            = request.json or {}
    bill_ids        = [int(i) for i in (body.get("bill_ids") or [])]
    bank_account_id = body.get("bank_account_id")
    payment_date    = body.get("payment_date") or str(date.today())
    want_aba        = bool(body.get("generate_aba"))
    description     = (body.get("aba_description") or "SUPPLIERS")[:12]

    if not bill_ids:
        return err("No bills selected", 400)
    if not bank_account_id:
        return err("No bank account selected", 400)

    from core.aba import get_bills_for_aba
    all_candidates = {r["bill_id"]: r for r in get_bills_for_aba(db())}
    selected = [all_candidates[i] for i in bill_ids if i in all_candidates]
    if not selected:
        return err("No valid payable bills found for the selected IDs", 400)

    by_supplier = defaultdict(list)
    for b in selected:
        by_supplier[b["contact_id"]].append(b)

    posted = []; errors = []; pmt_ids = []

    for contact_id, bills in by_supplier.items():
        amount      = sum(b["balance_due"] for b in bills)
        allocations = [{"bill_id": b["bill_id"], "amount": b["balance_due"]} for b in bills]
        try:
            pid = record_payment(db(), {
                "payment_type":    "Payment",
                "contact_id":      contact_id,
                "payment_date":    payment_date,
                "amount":          round(amount, 2),
                "bank_account_id": bank_account_id,
                "reference":       f"Pmt run {payment_date}",
                "description":     (
                    f"Payment run — {len(bills)} bill"
                    f"{'s' if len(bills) != 1 else ''}"
                ),
            }, allocations)
            pmt_ids.append(pid)
            posted.append({
                "contact_id":  contact_id,
                "amount":      round(amount, 2),
                "payment_id":  pid,
                "supplier":    bills[0].get("supplier_name", ""),
            })
        except Exception as e:
            errors.append(f"{bills[0].get('supplier_name','?')}: {e}")

    aba_content  = None
    missing_bank = []

    if want_aba and pmt_ids:
        try:
            pmts = get_payments_for_aba(db(), payment_date, payment_date)
            pmts = [p for p in pmts if p.get("payment_id") in pmt_ids]

            ok_pmts = [p for p in pmts if p.get("dest_bsb") and p.get("dest_account")]
            no_bank = [p for p in pmts if not (p.get("dest_bsb") and p.get("dest_account"))]
            missing_bank = [p["dest_name"] for p in no_bank]

            if ok_pmts:
                aba_content = generate_aba(db(), ok_pmts, payment_date, description)
        except ABAError as e:
            errors.append(f"ABA: {e}")
        except Exception as e:
            errors.append(f"ABA (unexpected): {e}")

    return ok({
        "posted":       posted,
        "pmt_ids":      pmt_ids,
        "aba_content":  aba_content,
        "errors":       errors,
        "missing_bank": missing_bank,
    })


# ── ABA Export ────────────────────────────────────────────────────────────────

@bp.route("/api/bills/aba-candidates")
@login_required
def api_bills_aba_candidates():
    from core.aba import get_payments_for_aba
    date_from = request.args.get("from") or str(date.today())
    date_to   = request.args.get("to")   or str(date.today())
    rows = get_payments_for_aba(db(), date_from, date_to)
    return ok(rows)


@bp.route("/api/bills/aba-generate", methods=["POST"])
@login_required
def api_bills_aba_generate():
    from core.aba import generate_aba, get_payments_for_aba, ABAError
    from datetime import date as _date, timedelta

    body         = request.json or {}
    payment_ids  = set(int(i) for i in (body.get("payment_ids") or []))
    process_date = body.get("process_date") or str(date.today())
    description  = (body.get("description") or "SUPPLIERS")[:12]

    if not payment_ids:
        return err("No payment IDs provided", 400)

    wide_from = (_date.fromisoformat(process_date) - timedelta(days=90)).isoformat()
    wide_to   = (_date.fromisoformat(process_date) + timedelta(days=1)).isoformat()

    all_pmts = get_payments_for_aba(db(), wide_from, wide_to)
    pmts     = [p for p in all_pmts if p.get("payment_id") in payment_ids]

    if not pmts:
        return err("No matching payments found for the supplied IDs", 400)

    ok_pmts = [p for p in pmts if p.get("dest_bsb") and p.get("dest_account")]
    no_bank = [p["dest_name"] for p in pmts if not (p.get("dest_bsb") and p.get("dest_account"))]

    if not ok_pmts:
        return err(
            "None of the selected payments have bank details on file. "
            "Edit each supplier's contact record and add BSB and Account Number.", 422)

    try:
        aba_content = generate_aba(db(), ok_pmts, process_date, description)
    except ABAError as e:
        return err(str(e), 422)

    total = sum(float(p.get("amount", 0)) for p in ok_pmts)

    return ok({
        "aba_content":   aba_content,
        "payment_count": len(ok_pmts),
        "total":         round(total, 2),
        "missing_bank":  no_bank,
    })
