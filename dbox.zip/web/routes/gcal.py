# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import webbrowser
from flask import Blueprint, request

from web.shared import db, ok, err, login_required, current_user
from core.gcal import (
    get_gcal_settings, start_auth, exchange_code, get_user_email,
    save_connection, disconnect, list_calendars, set_calendar, get_access_token,
    pull_events,
)

bp = Blueprint('gcal', __name__)


@bp.before_request
def _check_access():
    # Google's redirect lands here without our session cookie (it opens in
    # the system default browser, not the dbox app window) — state-param
    # validation in exchange_code() is this route's actual security check.
    if request.path.endswith('/oauth/callback'):
        return None
    from core.auth import ROLE_MODULES
    user = current_user()
    if not user:
        return None
    caps = set(user.get("tier_caps") or [])
    if "jobs" not in caps:
        return err("Jobs & CRM requires the Paid tier.", 403)
    role = user.get("role", "")
    allowed = ROLE_MODULES.get(role)
    if allowed is not None and "jobs" not in allowed:
        return err("Your role does not have access to Jobs & CRM.", 403)


def _redirect_uri() -> str:
    # The OAuth client is a Google "Desktop app", which only accepts loopback
    # redirects (any port). Always use 127.0.0.1 and the port this server is
    # listening on — not the host the page was opened with, which in LAN mode
    # is a network address Google rejects. The sign-in browser is opened on
    # this machine (webbrowser.open), so the loopback address reaches us, and
    # the server listens on loopback in LAN mode too (0.0.0.0).
    port = request.environ.get('SERVER_PORT') or request.host.rsplit(':', 1)[-1]
    return f"http://127.0.0.1:{port}/api/gcal/oauth/callback"


@bp.route("/api/gcal/status")
@login_required
def api_gcal_status():
    return ok(get_gcal_settings(db()))


@bp.route("/api/gcal/connect", methods=["POST"])
@login_required
def api_gcal_connect():
    try:
        url = start_auth(_redirect_uri())
    except Exception as e:
        return err(str(e))
    webbrowser.open(url)
    return ok()


@bp.route("/api/gcal/oauth/callback")
def api_gcal_oauth_callback():
    error = request.args.get('error')
    if error:
        return f"<h3>Google sign-in was cancelled or failed.</h3><p>{error}</p><p>You can close this tab and try again from dbox.</p>"
    code = request.args.get('code')
    state = request.args.get('state')
    if not code or not state:
        return "<h3>Missing sign-in details.</h3><p>You can close this tab and try again from dbox.</p>"
    try:
        tokens = exchange_code(code, state, _redirect_uri())
        refresh_token = tokens.get('refresh_token')
        access_token = tokens.get('access_token')
        if not refresh_token:
            return ("<h3>Google didn't grant offline access.</h3>"
                    "<p>Remove dbox's prior access at "
                    "<a href=\"https://myaccount.google.com/permissions\">myaccount.google.com/permissions</a> "
                    "and try connecting again.</p>")
        email = get_user_email(access_token)
        save_connection(db(), email, refresh_token)
        return f"<h3>Connected — {email}</h3><p>You can close this tab and return to dbox.</p>"
    except Exception as e:
        return f"<h3>Something went wrong connecting Google Calendar.</h3><p>{e}</p>"


@bp.route("/api/gcal/disconnect", methods=["POST"])
@login_required
def api_gcal_disconnect():
    disconnect(db())
    return ok()


@bp.route("/api/gcal/calendars")
@login_required
def api_gcal_calendars():
    token = get_access_token(db())
    if not token:
        return err("Not connected to Google Calendar")
    try:
        return ok(list_calendars(token))
    except Exception as e:
        return err(str(e))


@bp.route("/api/gcal/calendar", methods=["POST"])
@login_required
def api_gcal_calendar_set():
    data = request.get_json() or {}
    calendar_id = data.get('calendar_id')
    if not calendar_id:
        return err("calendar_id required")
    set_calendar(db(), calendar_id)
    return ok()


@bp.route("/api/gcal/sync", methods=["POST"])
@login_required
def api_gcal_sync():
    try:
        result = pull_events(db())
    except Exception as e:
        return err(str(e))
    if not result.get('ok'):
        return err(result.get('error', 'Sync failed'))
    return ok(result)
