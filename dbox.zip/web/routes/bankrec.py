# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from datetime import date
from flask import Blueprint, request, jsonify

from web.shared import db, ok, err, login_required
from core.ledger import (
    get_accounts, get_account_balance, get_bank_transactions, import_bank_csv,
    get_bank_journal_transactions, allocate_bank_transaction,
    allocate_bank_transaction_multi, deallocate_bank_transaction,
    get_last_reconciliation, complete_reconciliation,
)
from core.database import get_connection
from core.bank_rules import get_all_rules, save_rule, delete_rule, apply_rules

bp = Blueprint('bankrec', __name__)


@bp.route("/api/bankrec/accounts")
@login_required
def api_bankrec_accounts():
    RECONCILABLE_SUBTYPES = {
        "Bank", "Savings", "Cash", "Credit Card",
        "PayPal", "Electronic Clearing", "Term Deposit",
        "Non-Current Liability",   # bank loans, mortgages, lines of credit
    }
    all_accs = get_accounts(db())  # all types — CC and loans are Liability accounts
    result = []
    for a in all_accs:
        a = dict(a)
        if a.get("is_bank") or a.get("is_credit_card") \
                or a.get("account_subtype") in RECONCILABLE_SUBTYPES:
            result.append(a)
    result.sort(key=lambda a: (
        0 if a.get("is_bank") else 1 if a.get("is_credit_card") else 2,
        a.get("code", "")
    ))
    return ok(result)


@bp.route("/api/bankrec/<int:acc_id>/transactions")
@login_required
def api_bankrec_transactions(acc_id):
    txns = get_bank_journal_transactions(db(), acc_id)
    for t in txns:
        t["_source"] = "journal"

    csv_txns = get_bank_transactions(db(), acc_id)
    for t in csv_txns:
        t["_source"] = "csv"

    alloc_jids = {t["journal_id"] for t in csv_txns if t.get("journal_id")}

    j_by_key = {}
    for t in txns:
        if t.get("journal_id") in alloc_jids:
            continue
        key = (t["transaction_date"],
               round(float(t.get("debit") or 0), 2),
               round(float(t.get("credit") or 0), 2))
        j_by_key.setdefault(key, []).append(t["id"])

    dup_ids = set()
    for t in csv_txns:
        if t.get("journal_id"):
            continue
        key = (t["transaction_date"],
               round(float(t.get("credit") or 0), 2),
               round(float(t.get("debit")  or 0), 2))
        if key in j_by_key:
            dup_ids.add(f"csv:{t['id']}")
            for jid in j_by_key[key]:
                dup_ids.add(f"journal:{jid}")

    all_txns = txns + csv_txns
    for t in all_txns:
        iid = f"{t['_source']}:{t['id']}"
        t["_iid"]       = iid
        t["_duplicate"] = iid in dup_ids

    all_txns.sort(key=lambda x: (x["transaction_date"], x.get("id", 0)))
    return ok(all_txns)


@bp.route("/api/bankrec/<int:acc_id>/last-reconciliation")
@login_required
def api_bankrec_last_rec(acc_id):
    rec = get_last_reconciliation(db(), acc_id)
    return ok(rec)


@bp.route("/api/bankrec/<int:acc_id>/reconciliations")
@login_required
def api_bankrec_all_recs(acc_id):
    conn = get_connection(db())
    rows = conn.execute(
        "SELECT * FROM bank_reconciliations WHERE account_id=? ORDER BY id DESC",
        (acc_id,)
    ).fetchall()
    conn.close()
    return ok([dict(r) for r in rows])


@bp.route("/api/bankrec/reconcile", methods=["POST"])
@login_required
def api_bankrec_reconcile():
    data = request.get_json() or {}
    items     = data.get("items", [])
    reconcile = data.get("reconcile", True)
    rec_date  = data.get("rec_date") or str(date.today())
    conn = get_connection(db())
    try:
        for item in items:
            src = item.get("source")
            rid = item.get("id")
            if src == "journal":
                if reconcile:
                    conn.execute(
                        "UPDATE journal_lines SET is_reconciled=1, reconciled_date=? WHERE id=?",
                        (rec_date, rid))
                else:
                    conn.execute(
                        "UPDATE journal_lines SET is_reconciled=0, reconciled_date=NULL WHERE id=?",
                        (rid,))
            else:
                if reconcile:
                    conn.execute(
                        "UPDATE bank_transactions SET is_reconciled=1, reconciled_date=? WHERE id=?",
                        (rec_date, rid))
                else:
                    conn.execute(
                        "UPDATE bank_transactions SET is_reconciled=0, reconciled_date=NULL WHERE id=?",
                        (rid,))
        conn.commit()
        return ok()
    except Exception as e:
        return err(str(e))
    finally:
        conn.close()


@bp.route("/api/bankrec/reject", methods=["POST"])
@login_required
def api_bankrec_reject():
    data  = request.get_json() or {}
    items = data.get("items", [])
    conn  = get_connection(db())
    try:
        for item in items:
            src = item.get("source")
            rid = item.get("id")
            if src == "journal":
                conn.execute("UPDATE journal_lines SET is_rejected=1 WHERE id=?", (rid,))
            else:
                conn.execute("UPDATE bank_transactions SET is_rejected=1 WHERE id=?", (rid,))
        conn.commit()
        return ok()
    except Exception as e:
        return err(str(e))
    finally:
        conn.close()


@bp.route("/api/bankrec/unreject", methods=["POST"])
@login_required
def api_bankrec_unreject():
    data  = request.get_json() or {}
    items = data.get("items", [])
    conn  = get_connection(db())
    try:
        for item in items:
            src = item.get("source")
            rid = item.get("id")
            if src == "journal":
                conn.execute("UPDATE journal_lines SET is_rejected=0 WHERE id=?", (rid,))
            else:
                conn.execute("UPDATE bank_transactions SET is_rejected=0 WHERE id=?", (rid,))
        conn.commit()
        return ok()
    except Exception as e:
        return err(str(e))
    finally:
        conn.close()


@bp.route("/api/bankrec/allocate", methods=["POST"])
@login_required
def api_bankrec_allocate():
    data = request.get_json() or {}
    bank_txn_id = data.get("bank_txn_id")
    mode        = data.get("mode")
    alloc_data  = data.get("alloc_data", {})
    try:
        jid = allocate_bank_transaction(db(), bank_txn_id, mode, alloc_data)
        return ok({"journal_id": jid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/bankrec/allocate-multi", methods=["POST"])
@login_required
def api_bankrec_allocate_multi():
    data        = request.get_json() or {}
    bank_txn_id = data.get("bank_txn_id")
    lines       = data.get("lines", [])
    if not lines:
        return err("At least one allocation line is required")
    try:
        jid = allocate_bank_transaction_multi(db(), bank_txn_id, lines)
        return ok({"journal_id": jid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/bankrec/deallocate", methods=["POST"])
@login_required
def api_bankrec_deallocate():
    data = request.get_json() or {}
    bank_txn_id = data.get("bank_txn_id")
    try:
        deallocate_bank_transaction(db(), bank_txn_id)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/bankrec/<int:acc_id>/complete", methods=["POST"])
@login_required
def api_bankrec_complete(acc_id):
    data            = request.get_json() or {}
    reconcile_date  = data.get("reconcile_date")
    closing_balance = data.get("closing_balance")
    if not reconcile_date or closing_balance is None:
        return err("reconcile_date and closing_balance are required")
    expected_opening = data.get("opening_balance")
    selected_iids = data.get("selected_iids")
    journal_line_ids = None
    bank_txn_ids = None
    if selected_iids is not None:
        journal_line_ids, bank_txn_ids = [], []
        for iid in selected_iids:
            try:
                source, id_str = iid.split(":", 1)
                id_val = int(id_str)
            except (ValueError, AttributeError):
                continue
            if source == "journal":
                journal_line_ids.append(id_val)
            elif source == "csv":
                bank_txn_ids.append(id_val)
    try:
        complete_reconciliation(db(), acc_id, reconcile_date, float(closing_balance),
                                expected_opening=expected_opening,
                                journal_line_ids=journal_line_ids,
                                bank_txn_ids=bank_txn_ids)
        conn = get_connection(db())
        rec = conn.execute(
            "SELECT id FROM bank_reconciliations WHERE account_id=? ORDER BY id DESC LIMIT 1",
            (acc_id,)
        ).fetchone()
        conn.close()
        return ok({"id": rec["id"] if rec else None})
    except Exception as e:
        return err(str(e))


@bp.route("/api/bankrec/<int:acc_id>/rec-report")
@login_required
def api_bankrec_rec_report(acc_id):
    conn = get_connection(db())
    acc = conn.execute("SELECT * FROM accounts WHERE id=?", (acc_id,)).fetchone()
    if not acc:
        conn.close()
        return err("Account not found")
    last_rec = conn.execute("""SELECT * FROM bank_reconciliations
        WHERE account_id=? AND status='Completed'
        ORDER BY reconcile_date DESC, id DESC LIMIT 1""", (acc_id,)).fetchone()
    unrgl = conn.execute("""
        SELECT jl.id, je.entry_date AS date,
               COALESCE(jl.description, je.description, '') AS description,
               COALESCE(je.reference, '') AS reference,
               jl.debit, jl.credit
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id = je.id
        WHERE jl.account_id = ?
          AND jl.is_reconciled = 0
          AND (jl.is_rejected IS NULL OR jl.is_rejected = 0)
        ORDER BY je.entry_date, je.id
    """, (acc_id,)).fetchall()
    unrbank = conn.execute("""
        SELECT id, transaction_date AS date, description, reference, debit, credit
        FROM bank_transactions
        WHERE account_id = ?
          AND is_reconciled = 0
          AND (is_rejected IS NULL OR is_rejected = 0)
        ORDER BY transaction_date, id
    """, (acc_id,)).fetchall()
    conn.close()

    gl_balance   = get_account_balance(db(), acc_id)
    last_rec_bal = float(last_rec["closing_balance"]) if last_rec else 0.0
    is_asset     = acc["account_type"] in ("Asset", "Expense")
    sign         = 1 if is_asset else -1
    unrgl_net    = sum((float(r["debit"] or 0) - float(r["credit"] or 0)) * sign for r in unrgl)
    unrbank_net  = sum((float(r["credit"] or 0) - float(r["debit"] or 0)) * sign for r in unrbank)
    bank_balance = round(last_rec_bal + unrbank_net, 2)
    difference   = round(gl_balance - bank_balance, 2)

    return ok({
        "account":               {"id": acc_id, "code": acc["code"], "name": acc["name"]},
        "as_at":                 str(date.today()),
        "gl_balance":            round(gl_balance, 2),
        "last_rec":              dict(last_rec) if last_rec else None,
        "last_rec_balance":      round(last_rec_bal, 2),
        "unreconciled_gl":       [dict(r) for r in unrgl],
        "unreconciled_gl_net":   round(unrgl_net, 2),
        "unreconciled_bank":     [dict(r) for r in unrbank],
        "unreconciled_bank_net": round(unrbank_net, 2),
        "bank_balance":          bank_balance,
        "difference":            difference,
    })


@bp.route("/api/bankrec/<int:acc_id>/reconciliations/<int:rec_id>/report")
@login_required
def api_bankrec_period_report(acc_id, rec_id):
    conn = get_connection(db())
    rec = conn.execute(
        "SELECT * FROM bank_reconciliations WHERE id=? AND account_id=?", (rec_id, acc_id)
    ).fetchone()
    if not rec:
        conn.close()
        return err("Reconciliation not found")
    acc = conn.execute("SELECT * FROM accounts WHERE id=?", (acc_id,)).fetchone()
    prev = conn.execute("""SELECT * FROM bank_reconciliations
        WHERE account_id=? AND id < ? AND status='Completed'
        ORDER BY id DESC LIMIT 1""", (acc_id, rec_id)).fetchone()
    rec_date = rec["reconcile_date"]
    gl_items = conn.execute("""
        SELECT jl.id, je.entry_date AS date,
               COALESCE(jl.description, je.description, '') AS description,
               COALESCE(je.reference, '') AS reference,
               jl.debit, jl.credit
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id = je.id
        WHERE jl.account_id = ?
          AND jl.is_reconciled = 1
          AND jl.reconciled_date = ?
        ORDER BY je.entry_date, je.id
    """, (acc_id, rec_date)).fetchall()
    bank_items = conn.execute("""
        SELECT id, transaction_date AS date, description, reference, debit, credit
        FROM bank_transactions
        WHERE account_id = ?
          AND is_reconciled = 1
          AND reconciled_date = ?
        ORDER BY transaction_date, id
    """, (acc_id, rec_date)).fetchall()
    conn.close()
    return ok({
        "account":             {"id": acc_id, "code": acc["code"], "name": acc["name"]},
        "reconciliation":      dict(rec),
        "prev_reconciliation": dict(prev) if prev else None,
        "reconciled_gl":       [dict(r) for r in gl_items],
        "reconciled_bank":     [dict(r) for r in bank_items],
    })


@bp.route("/api/bankrec/<int:acc_id>/date-report")
@login_required
def api_bankrec_date_report(acc_id):
    from_date = request.args.get('from')
    to_date   = request.args.get('to')
    if not from_date or not to_date:
        return err("from and to dates are required")

    conn = get_connection(db())
    try:
        acc = conn.execute("SELECT * FROM accounts WHERE id=?", (acc_id,)).fetchone()
        if not acc:
            return err("Account not found")

        # Opening GL balance: account opening_balance + all lines before from_date
        open_row = conn.execute("""
            SELECT COALESCE(SUM(jl.debit), 0) - COALESCE(SUM(jl.credit), 0) AS net
            FROM journal_lines jl
            JOIN journal_entries je ON jl.journal_id = je.id
            WHERE jl.account_id = ? AND je.entry_date < ?
        """, (acc_id, from_date)).fetchone()
        acct_opening = float(acc["opening_balance"] or 0)
        net_before   = float(open_row["net"] or 0)
        is_asset     = acc["account_type"] in ("Asset", "Expense")
        gl_opening   = round(
            acct_opening + net_before if is_asset else acct_opening - net_before, 2)

        # GL items in range
        gl_items = conn.execute("""
            SELECT jl.id, je.entry_date AS date,
                   COALESCE(jl.description, je.description, '') AS description,
                   COALESCE(je.reference, '') AS reference,
                   jl.debit, jl.credit
            FROM journal_lines jl
            JOIN journal_entries je ON jl.journal_id = je.id
            WHERE jl.account_id = ? AND je.entry_date >= ? AND je.entry_date <= ?
            ORDER BY je.entry_date, je.id
        """, (acc_id, from_date, to_date)).fetchall()

        # Outstanding GL items as at to_date (in books, not yet cleared on bank)
        outstanding_gl = conn.execute("""
            SELECT jl.id, je.entry_date AS date,
                   COALESCE(jl.description, je.description, '') AS description,
                   COALESCE(je.reference, '') AS reference,
                   jl.debit, jl.credit
            FROM journal_lines jl
            JOIN journal_entries je ON jl.journal_id = je.id
            WHERE jl.account_id = ?
              AND jl.is_reconciled = 0
              AND (jl.is_rejected IS NULL OR jl.is_rejected = 0)
              AND je.entry_date <= ?
            ORDER BY je.entry_date, je.id
        """, (acc_id, to_date)).fetchall()

        # Outstanding bank items as at to_date (on statement, not yet in books)
        outstanding_bank = conn.execute("""
            SELECT id, transaction_date AS date, description, reference, debit, credit
            FROM bank_transactions
            WHERE account_id = ?
              AND is_reconciled = 0
              AND (is_rejected IS NULL OR is_rejected = 0)
              AND transaction_date <= ?
            ORDER BY transaction_date, id
        """, (acc_id, to_date)).fetchall()

        # Latest completed reconciliation on or before to_date
        last_rec = conn.execute("""
            SELECT * FROM bank_reconciliations
            WHERE account_id = ? AND status = 'Completed' AND reconcile_date <= ?
            ORDER BY reconcile_date DESC, id DESC LIMIT 1
        """, (acc_id, to_date)).fetchone()

        if last_rec and last_rec["reconcile_date"] == to_date:
            # Exact match: authoritative closing balance from rec
            bank_balance       = float(last_rec["closing_balance"])
            bank_authoritative = True
        elif last_rec:
            # Prior rec exists: estimate by adding bank transactions since that rec.
            # For liabilities (CC/loan): debit = charge (balance increases), credit = payment (decreases),
            # so use SUM(debit-credit); assets use SUM(credit-debit) (deposit = credit on statement).
            bridge = conn.execute("""
                SELECT COALESCE(SUM(credit), 0) - COALESCE(SUM(debit), 0) AS net
                FROM bank_transactions
                WHERE account_id = ? AND transaction_date > ? AND transaction_date <= ?
            """, (acc_id, last_rec["reconcile_date"], to_date)).fetchone()
            bridge_net         = float(bridge["net"] or 0) * (1 if is_asset else -1)
            bank_balance       = round(float(last_rec["closing_balance"]) + bridge_net, 2)
            bank_authoritative = False
        else:
            # No rec at all: sum all bank transactions up to to_date
            all_row = conn.execute("""
                SELECT COALESCE(SUM(credit), 0) - COALESCE(SUM(debit), 0) AS net
                FROM bank_transactions
                WHERE account_id = ? AND transaction_date <= ?
            """, (acc_id, to_date)).fetchone()
            bank_balance       = round(float(all_row["net"] or 0) * (1 if is_asset else -1), 2)
            bank_authoritative = False

    finally:
        conn.close()

    def dr_cr(r):
        return float(r["debit"] or 0) - float(r["credit"] or 0)

    gl_net              = sum(dr_cr(r) for r in gl_items) if is_asset \
                          else sum(-dr_cr(r) for r in gl_items)
    gl_closing          = round(gl_opening + gl_net, 2)
    outstanding_gl_net  = sum(dr_cr(r) for r in outstanding_gl) if is_asset \
                          else sum(-dr_cr(r) for r in outstanding_gl)
    # Bank items: for assets credit = money in; for liabilities debit = charge (balance increases)
    outstanding_bank_net = sum(
        (float(r["credit"] or 0) - float(r["debit"] or 0)) * (1 if is_asset else -1)
        for r in outstanding_bank
    )
    # Adjusted GL: remove outstanding GL items, add outstanding bank items
    adjusted_gl  = round(gl_closing - outstanding_gl_net + outstanding_bank_net, 2)
    difference   = round(adjusted_gl - bank_balance, 2)

    return ok({
        "account":             {"id": acc_id, "code": acc["code"], "name": acc["name"]},
        "from_date":           from_date,
        "to_date":             to_date,
        "gl_opening":          gl_opening,
        "gl_items":            [dict(r) for r in gl_items],
        "gl_closing":          gl_closing,
        "outstanding_gl":      [dict(r) for r in outstanding_gl],
        "outstanding_gl_net":  round(outstanding_gl_net, 2),
        "outstanding_bank":    [dict(r) for r in outstanding_bank],
        "outstanding_bank_net": round(outstanding_bank_net, 2),
        "adjusted_gl":         adjusted_gl,
        "bank_balance":        bank_balance,
        "bank_authoritative":  bank_authoritative,
        "last_rec":            dict(last_rec) if last_rec else None,
        "difference":          difference,
    })


@bp.route("/api/bankrec/<int:acc_id>/import-csv", methods=["POST"])
@login_required
def api_bankrec_import_csv(acc_id):
    data = request.get_json() or {}
    rows = data.get("rows", [])
    if not rows:
        return err("No rows supplied")
    try:
        inserted = import_bank_csv(db(), acc_id, rows)
        return ok({"inserted": inserted})
    except Exception as e:
        return err(str(e))


# ── Bank Rules ────────────────────────────────────────────────────────────────

@bp.route("/api/bankrec/rules")
@login_required
def api_bankrec_rules_list():
    return ok(get_all_rules(db()))


@bp.route("/api/bankrec/rules", methods=["POST"])
@login_required
def api_bankrec_rules_save():
    data = request.get_json() or {}
    try:
        rid = save_rule(db(), data)
        return ok({"id": rid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/bankrec/rules/<int:rid>", methods=["PUT"])
@login_required
def api_bankrec_rules_update(rid):
    data = request.get_json() or {}
    data["id"] = rid
    try:
        save_rule(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/bankrec/rules/<int:rid>", methods=["DELETE"])
@login_required
def api_bankrec_rules_delete(rid):
    try:
        delete_rule(db(), rid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/bankrec/apply-rules", methods=["POST"])
@login_required
def api_bankrec_apply_rules():
    data       = request.get_json() or {}
    candidates = data.get("transactions", [])
    if not candidates:
        return ok({"applied": 0})
    matched_pairs = apply_rules(db(), candidates)
    applied = 0
    errors  = []
    for txn, rule in matched_pairs:
        acc_id = rule.get("account_id")
        if not acc_id:
            continue
        try:
            allocate_bank_transaction(
                db(), txn["id"], "account",
                {"account_id": acc_id,
                 "amount": float(txn.get("debit") or txn.get("credit") or 0),
                 "contact_id": rule.get("contact_id")})
            applied += 1
        except Exception as e:
            errors.append(str(e))
    return ok({"applied": applied, "errors": errors})
