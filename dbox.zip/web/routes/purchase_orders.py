import os
import tempfile
from datetime import date
from flask import Blueprint, request, send_file, session

from web.shared import db, ok, err, login_required, current_user
from core.purchase_orders import (
    get_purchase_orders, get_purchase_order, save_purchase_order,
    approve_purchase_order, cancel_purchase_order, receive_po_lines,
    convert_po_to_bill, render_po_pdf, create_po_from_crm_quote,
)

bp = Blueprint('purchase_orders', __name__)


@bp.before_request
def _check_pro_tier():
    user = current_user()
    if not user:
        return None
    caps = set(user.get("tier_caps") or [])
    if "purchase_orders" not in caps:
        return err("Purchase Orders requires a Pro licence — visit dogboxsoftware.com.au to upgrade.", 403)


@bp.route("/api/purchase-orders")
@login_required
def api_po_list():
    status     = request.args.get("status") or None
    contact_id = request.args.get("contact_id", type=int)
    rows = get_purchase_orders(db(), status=status, contact_id=contact_id)
    return ok(rows)


@bp.route("/api/purchase-orders/<int:po_id>")
@login_required
def api_po_get(po_id):
    data = get_purchase_order(db(), po_id)
    if not data:
        return err("Not found", 404)
    return ok(data)


@bp.route("/api/purchase-orders", methods=["POST"])
@login_required
def api_po_create():
    body  = request.get_json(force=True)
    po_d  = body.get("po",    {})
    lines = body.get("lines", [])
    try:
        po_id = save_purchase_order(db(), po_d, lines,
                                    created_by=session.get("username"))
        return ok({"po_id": po_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/purchase-orders/<int:po_id>", methods=["PUT"])
@login_required
def api_po_update(po_id):
    body  = request.get_json(force=True)
    po_d  = body.get("po",    {})
    lines = body.get("lines", [])
    po_d["id"] = po_id
    try:
        save_purchase_order(db(), po_d, lines,
                            created_by=session.get("username"))
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/purchase-orders/<int:po_id>/receive", methods=["POST"])
@login_required
def api_po_receive(po_id):
    body  = request.get_json(force=True)
    received_raw  = body.get("received", {})
    received      = {int(k): float(v) for k, v in received_raw.items()}
    received_date = body.get("received_date") or None
    try:
        new_status = receive_po_lines(db(), po_id, received,
                                      received_date=received_date,
                                      created_by=session.get("username"))
        return ok({"status": new_status})
    except Exception as e:
        return err(str(e))


@bp.route("/api/purchase-orders/<int:po_id>/receive-all", methods=["POST"])
@login_required
def api_po_receive_all(po_id):
    data = get_purchase_order(db(), po_id)
    if not data:
        return err("Not found", 404)
    lines = data.get("lines", [])
    to_receive = {}
    for ln in lines:
        outstanding = float(ln.get("quantity") or 0) - float(ln.get("qty_received") or 0)
        if outstanding > 0:
            to_receive[ln["id"]] = outstanding
    if not to_receive:
        return err("All lines already received")
    try:
        new_status = receive_po_lines(db(), po_id, to_receive,
                                      received_date=str(date.today()),
                                      created_by=session.get("username"))
        return ok({"status": new_status})
    except Exception as e:
        return err(str(e))


@bp.route("/api/purchase-orders/<int:po_id>/convert-bill", methods=["POST"])
@login_required
def api_po_convert_bill(po_id):
    body = request.get_json(silent=True) or {}
    try:
        bill_id = convert_po_to_bill(
            db(), po_id,
            bill_date=body.get("bill_date"),
            due_date=body.get("due_date"),
            bill_number=body.get("bill_number", ""),
            status=body.get("status", "Draft"),
        )
        return ok({"id": bill_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/purchase-orders/<int:po_id>/approve", methods=["POST"])
@login_required
def api_po_approve(po_id):
    try:
        approve_purchase_order(db(), po_id)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/purchase-orders/<int:po_id>/cancel", methods=["POST"])
@login_required
def api_po_cancel(po_id):
    try:
        cancel_purchase_order(db(), po_id)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/purchase-orders/<int:po_id>/pdf")
@login_required
def api_po_pdf(po_id):
    data = get_purchase_order(db(), po_id)
    if not data:
        return err("Not found", 404)
    po_num = data["po"].get("po_number", str(po_id))
    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
        tmp_path = tmp.name
    try:
        render_po_pdf(db(), po_id, tmp_path)
        return send_file(tmp_path, mimetype="application/pdf",
                         as_attachment=True,
                         download_name=f"{po_num}.pdf")
    except Exception as e:
        return err(str(e), 500)
    finally:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass


@bp.route("/api/crm/quotes/<int:qid>/create-po", methods=["POST"])
@login_required
def api_crm_quote_create_po(qid):
    body = request.get_json(force=True) or {}
    supplier_id   = body.get("supplier_id")
    po_date       = body.get("po_date") or None
    expected_date = body.get("expected_date") or None
    if not supplier_id:
        return err("supplier_id required", 400)
    try:
        po_id = create_po_from_crm_quote(
            db(), qid, int(supplier_id),
            po_date=po_date, expected_date=expected_date,
            created_by=session.get("username"),
        )
        return ok({"po_id": po_id})
    except Exception as e:
        return err(str(e), 400)
