import os
import sys
import json
import pathlib
import string as _str
from flask import Blueprint, request, redirect, jsonify, current_app

from web.shared import _load_prefs, _save_prefs
from core.database import initialise_database, seed_defaults
from core.budget import ensure_default_admin

bp = Blueprint('startup', __name__)

_RECENT_PATH = os.path.join(os.path.expanduser('~'), '.dbox_recent.json')

_FILE_SVG = (
    '<svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"'
    ' style="width:14px;height:14px;fill:none;stroke:#185FA5;'
    'stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round">'
    '<path d="M3 2h7l3 3v9H3z"/><path d="M10 2v3h3"/>'
    '</svg>'
)

_LOGO_SVG = (
    '<svg viewBox="88 24 136 88" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'
    '<rect x="112" y="24" width="88" height="88" rx="14" fill="#185FA5"/>'
    '<rect x="88"  y="32" width="18" height="70" rx="9"  fill="#185FA5"/>'
    '<rect x="206" y="32" width="18" height="70" rx="9"  fill="#185FA5"/>'
    '<circle cx="140" cy="58" r="8"   fill="white"/>'
    '<circle cx="172" cy="58" r="8"   fill="white"/>'
    '<circle cx="141" cy="59" r="4"   fill="#185FA5"/>'
    '<circle cx="173" cy="59" r="4"   fill="#185FA5"/>'
    '<circle cx="142.5" cy="57" r="1.5" fill="white"/>'
    '<circle cx="174.5" cy="57" r="1.5" fill="white"/>'
    '<ellipse cx="156" cy="94" rx="10" ry="7"   fill="white"/>'
    '<ellipse cx="156" cy="93" rx="5"  ry="3.5" fill="#185FA5"/>'
    '</svg>'
)

_STARTUP_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>dbox &mdash; Open Company</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Mono:wght@300;400;500&family=Instrument+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;background:#EBF2FA;font-family:'Instrument Sans',sans-serif;color:#1A2E45;-webkit-font-smoothing:antialiased}
.page{min-height:100vh;display:grid;grid-template-columns:1fr 1fr}
.left{background:#1A2E45;display:flex;flex-direction:column;justify-content:center;padding:80px 72px;position:relative;overflow:hidden}
.left::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 70% 50% at 10% 90%,rgba(24,95,165,.4) 0%,transparent 60%),radial-gradient(ellipse 50% 40% at 90% 10%,rgba(24,95,165,.2) 0%,transparent 55%);pointer-events:none}
.left::after{content:'';position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.03) 1px,transparent 1px);background-size:32px 32px;pointer-events:none}
.left-content{position:relative;z-index:1}
.brand-wordmark{display:flex;align-items:center;gap:12px;margin-bottom:56px}
.brand-wordmark svg{width:40px;height:40px;flex-shrink:0}
.brand-wordmark-text{font-family:'Syne',sans-serif;font-size:26px;font-weight:800;letter-spacing:-.5px;color:#fff}
.brand-wordmark-text span{color:#185FA5}
.left h1{font-family:'Syne',sans-serif;font-size:42px;line-height:1.1;font-weight:700;color:#fff;letter-spacing:-1px;margin-bottom:18px}
.left h1 em{font-style:normal;color:#5b8dee}
.left-desc{font-size:15px;line-height:1.65;color:#6B8BAA;max-width:340px;margin-bottom:52px}
.features{display:flex;flex-direction:column;gap:11px}
.feature{display:flex;align-items:center;gap:10px;font-size:13px;color:#8facc8;font-family:'DM Mono',monospace}
.feature-dot{width:5px;height:5px;background:#185FA5;border-radius:50%;flex-shrink:0}
.right{display:flex;flex-direction:column;justify-content:center;align-items:center;padding:80px 72px;background:#EBF2FA}
.form-card{width:100%;max-width:360px;animation:fadeUp .3s ease both}
.form-heading{font-family:'Syne',sans-serif;font-size:28px;font-weight:700;letter-spacing:-.5px;color:#1A2E45;margin-bottom:6px}
.form-sub{font-size:13px;color:#6B8BAA;margin-bottom:28px;font-family:'DM Mono',monospace}
.btn-open{width:100%;padding:12px;background:#185FA5;color:#fff;border:none;border-radius:9px;font-family:'Syne',sans-serif;font-size:14px;font-weight:700;letter-spacing:.2px;cursor:pointer;margin-bottom:10px;transition:opacity .15s,transform .1s}
.btn-open:hover{opacity:.88}
.btn-open:active{transform:scale(.99)}
.btn-open:disabled{opacity:.5;cursor:not-allowed}
.btn-new{width:100%;padding:11px;background:transparent;color:#1A2E45;border:1.5px solid #C8DCEE;border-radius:9px;font-family:'Syne',sans-serif;font-size:14px;font-weight:600;cursor:pointer;transition:border-color .15s,color .15s}
.btn-new:hover{border-color:#185FA5;color:#185FA5}
.btn-new:disabled{opacity:.5;cursor:not-allowed}
.confirm-box{margin-top:16px;padding:14px 16px;background:#fff;border:1.5px solid #C8DCEE;border-radius:9px;display:none}
.confirm-label{font-size:9px;font-weight:500;letter-spacing:1.2px;text-transform:uppercase;font-family:'DM Mono',monospace;color:#6B8BAA;margin-bottom:6px}
.confirm-path{font-size:12px;font-family:'DM Mono',monospace;color:#1A2E45;word-break:break-all;margin-bottom:14px;line-height:1.5}
.confirm-btns{display:flex;gap:8px}
.confirm-btns .btn-open{flex:1;margin-bottom:0}
.btn-cancel{flex:1;padding:11px;background:transparent;color:#6B8BAA;border:1.5px solid #C8DCEE;border-radius:9px;font-family:'Syne',sans-serif;font-size:13px;font-weight:600;cursor:pointer;transition:border-color .15s,color .15s}
.btn-cancel:hover{border-color:#1A2E45;color:#1A2E45}
.error-msg{color:#A32D2D;font-size:12px;font-family:'DM Mono',monospace;margin-top:10px;min-height:18px}
.recent-sep{margin-top:28px;padding-top:22px;border-top:1px solid #C8DCEE;font-size:9px;font-weight:500;letter-spacing:1.2px;text-transform:uppercase;font-family:'DM Mono',monospace;color:#6B8BAA;margin-bottom:12px}
.recent-list{list-style:none;display:flex;flex-direction:column;gap:4px}
.recent-item{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;cursor:pointer;border:1.5px solid transparent;transition:border-color .12s,background .12s}
.recent-item:hover{background:#fff;border-color:#C8DCEE}
.recent-icon{width:30px;height:30px;flex-shrink:0;background:rgba(24,95,165,.10);border-radius:7px;display:flex;align-items:center;justify-content:center}
.recent-name{font-size:13px;font-weight:600;color:#1A2E45}
.recent-path{font-size:11px;font-family:'DM Mono',monospace;color:#6B8BAA;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:270px}
.form-logo{display:none;align-items:center;gap:10px;margin-bottom:32px}
.form-logo svg{width:36px;height:36px}
.form-logo-text{font-family:'Syne',sans-serif;font-size:22px;font-weight:800;letter-spacing:-.5px;color:#1A2E45}
.form-logo-text span{color:#185FA5}
@media(max-width:768px){.form-logo{display:flex}.page{grid-template-columns:1fr}.left{display:none}.right{padding:48px 28px}}
@keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
/* ── File browser modal ── */
#fbModal{display:none;position:fixed;inset:0;background:rgba(26,46,69,.55);backdrop-filter:blur(3px);z-index:999;align-items:center;justify-content:center}
.fb-box{background:#fff;border-radius:14px;width:540px;max-width:94vw;max-height:78vh;display:flex;flex-direction:column;box-shadow:0 24px 64px rgba(0,0,0,.22);overflow:hidden}
.fb-hdr{padding:16px 18px 12px;border-bottom:1px solid #C8DCEE;display:flex;align-items:flex-start;gap:10px}
.fb-htitle{font-family:'Syne',sans-serif;font-weight:700;font-size:15px;color:#1A2E45;flex:1}
.fb-crumb{font-size:11px;font-family:'DM Mono',monospace;color:#6B8BAA;margin-top:3px;word-break:break-all;line-height:1.4}
.fb-close{background:none;border:none;cursor:pointer;color:#6B8BAA;font-size:20px;line-height:1;padding:0 4px;border-radius:4px;transition:color .12s}
.fb-close:hover{color:#1A2E45}
.fb-list{overflow-y:auto;flex:1;padding:6px 8px;min-height:180px}
.fb-entry{display:flex;align-items:center;gap:9px;padding:7px 10px;border-radius:7px;cursor:pointer;font-size:13px;color:#1A2E45;transition:background .1s;user-select:none}
.fb-entry:hover{background:#EBF2FA}
.fb-entry.fb-file{color:#185FA5;font-family:'DM Mono',monospace}
.fb-entry.fb-up{color:#6B8BAA;font-family:'DM Mono',monospace}
.fb-entry.fb-selected{background:#dceaf7;font-weight:600}
.fb-icon{flex-shrink:0}
.fb-new-row{padding:12px 18px;border-top:1px solid #C8DCEE}
.fb-new-label{font-size:9px;font-weight:500;letter-spacing:1.2px;text-transform:uppercase;font-family:'DM Mono',monospace;color:#6B8BAA;margin-bottom:5px}
.fb-new-input{width:100%;padding:9px 11px;border:1.5px solid #C8DCEE;border-radius:7px;font-family:'DM Mono',monospace;font-size:13px;color:#1A2E45;outline:none;transition:border-color .12s;box-sizing:border-box}
.fb-new-input:focus{border-color:#185FA5}
.fb-foot{padding:12px 18px;border-top:1px solid #C8DCEE;display:flex;gap:8px;justify-content:flex-end}
.fb-btn-ok{padding:9px 20px;background:#185FA5;color:#fff;border:none;border-radius:7px;font-family:'Syne',sans-serif;font-size:13px;font-weight:700;cursor:pointer;transition:opacity .15s}
.fb-btn-ok:hover{opacity:.87}
.fb-btn-ok:disabled{opacity:.4;cursor:not-allowed}
.fb-btn-cancel{padding:9px 16px;background:transparent;color:#6B8BAA;border:1.5px solid #C8DCEE;border-radius:7px;font-family:'Syne',sans-serif;font-size:13px;font-weight:600;cursor:pointer;transition:border-color .15s,color .15s}
.fb-btn-cancel:hover{border-color:#1A2E45;color:#1A2E45}
.fb-msg{padding:28px;text-align:center;color:#6B8BAA;font-size:12px;font-family:'DM Mono',monospace}
.fb-err{padding:20px;color:#A32D2D;font-size:12px;font-family:'DM Mono',monospace}
.fb-set-default{font-size:11px;font-family:'DM Mono',monospace;color:#6B8BAA;background:none;border:none;cursor:pointer;padding:0;margin-right:auto;transition:color .12s}
.fb-set-default:hover{color:#185FA5}
.fb-set-default.fb-set-done{color:#2a7a45}
</style>
</head>
<body>
<div class="page">
  <div class="left">
    <div class="left-content">
      <div class="brand-wordmark">
        __LOGO__
        <div class="brand-wordmark-text">dog<span>box</span></div>
      </div>
      <h1>Australian<br>accounting,<br><em>made simple.</em></h1>
      <p class="left-desc">A complete double-entry bookkeeping system built for Australian small businesses &mdash; invoices, payroll, BAS, and more. No subscription. No cloud. Your data stays yours.</p>
      <div class="features">
        <div class="feature"><div class="feature-dot"></div>STP Phase 2 payroll compliance</div>
        <div class="feature"><div class="feature-dot"></div>GST &amp; BAS reporting</div>
        <div class="feature"><div class="feature-dot"></div>Job costing &amp; project P&amp;L</div>
        <div class="feature"><div class="feature-dot"></div>Multi-user with full audit trail</div>
        <div class="feature"><div class="feature-dot"></div>Works offline &mdash; single file</div>
      </div>
    </div>
  </div>
  <div class="right">
    <div class="form-card">
      <div class="form-logo" aria-hidden="true">
        __LOGO__
        <div class="form-logo-text">dog<span>box</span></div>
      </div>
      <div class="form-heading">Open company file</div>
      <div class="form-sub">Select an existing file or create a new one</div>
      <button class="btn-open" id="btnOpen" onclick="browse('open')">Open existing file&hellip;</button>
      <button class="btn-new"  id="btnNew"  onclick="browse('new')">Create new file&hellip;</button>
      <div class="confirm-box" id="confirmBox">
        <div class="confirm-label">Selected file</div>
        <div class="confirm-path" id="confirmPath"></div>
        <div class="confirm-btns">
          <button class="btn-open" onclick="openFile()">Open &rarr;</button>
          <button class="btn-cancel" onclick="cancelConfirm()">Cancel</button>
        </div>
      </div>
      <div class="error-msg" id="errMsg"></div>
      __RECENT__
    </div>
  </div>
</div>
<div id="fbModal">
  <div class="fb-box">
    <div class="fb-hdr">
      <div style="flex:1">
        <div class="fb-htitle" id="fbTitle">Open existing file</div>
        <div class="fb-crumb" id="fbCrumb"></div>
      </div>
      <button class="fb-close" onclick="fbClose()" title="Close">&times;</button>
    </div>
    <div id="fbList" class="fb-list"></div>
    <div id="fbNewRow" class="fb-new-row" style="display:none">
      <div class="fb-new-label">Filename</div>
      <input class="fb-new-input" id="fbFilename" type="text" value="company.dbox" placeholder="company.dbox">
    </div>
    <div class="fb-foot">
      <button class="fb-set-default" id="fbSetDefault" onclick="fbSaveDefault()" style="display:none">&#x1F4CC; Set as default folder</button>
      <button class="fb-btn-cancel" onclick="fbClose()">Cancel</button>
      <button class="fb-btn-ok" id="fbOkBtn" onclick="fbConfirm()" disabled>Open</button>
    </div>
  </div>
</div>
<script>
const _FB_DIR  = `<svg class="fb-icon" width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M1 5a1.5 1.5 0 0 1 1.5-1.5H6l1 1.5h7c.276 0 .5.224.5.5V12a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 1 12V5z" fill="rgba(24,95,165,.1)" stroke="#185FA5" stroke-width="1.3"/></svg>`;
const _FB_FILE = `<svg class="fb-icon" width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 2h7l3 3v9H3z" stroke="#185FA5" stroke-width="1.4"/><path d="M10 2v3h3" stroke="#185FA5" stroke-width="1.4"/></svg>`;
const _FB_DRV  = `<svg class="fb-icon" width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="1.5" y="5" width="13" height="8" rx="1.5" stroke="#6B8BAA" stroke-width="1.3"/><path d="M1.5 9h13" stroke="#6B8BAA" stroke-width="1.3"/><circle cx="12" cy="11" r="1" fill="#6B8BAA"/></svg>`;
let _DEFAULT_DIR = __DEFAULT_DIR_JSON__;

let _path = "", _busy = false;
let _fbMode = 'open', _fbCurPath = '', _fbSelFile = '';
let _startupNavigating = false;

window.addEventListener('pagehide', () => {
  if (!_startupNavigating) navigator.sendBeacon('/api/system/close-beacon', '');
});

function setBusy(on) {
  _busy = on;
  ["btnOpen","btnNew"].forEach(id => { const el = document.getElementById(id); if (el) el.disabled = on; });
}
function _esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function browse(mode) {
  _fbMode = mode;
  _fbSelFile = '';
  document.getElementById('fbTitle').textContent = mode === 'open' ? 'Open existing file' : 'Choose folder for new file';
  document.getElementById('fbNewRow').style.display = mode === 'new' ? 'block' : 'none';
  const okBtn = document.getElementById('fbOkBtn');
  okBtn.textContent = mode === 'open' ? 'Open' : 'Create here';
  okBtn.disabled = true;
  document.getElementById('fbModal').style.display = 'flex';
  fbNavigate(_DEFAULT_DIR || '');
}
function fbClose() {
  document.getElementById('fbModal').style.display = 'none';
}
document.getElementById('fbModal').addEventListener('click', function(e) { if (e.target === this) fbClose(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') fbClose(); });

async function fbNavigate(path) {
  _fbCurPath = path;
  _fbSelFile = '';
  document.getElementById('fbOkBtn').disabled = true;
  const list = document.getElementById('fbList');
  list.innerHTML = '<div class="fb-msg">Loading…</div>';
  let d;
  try {
    const r = await fetch('/startup/fs?path=' + encodeURIComponent(path));
    d = await r.json();
  } catch(e) {
    list.innerHTML = '<div class="fb-err">Could not read directory.</div>';
    return;
  }
  if (d.error) {
    list.innerHTML = `<div class="fb-err">${_esc(d.error)}</div>`;
    return;
  }
  let html = '';
  const setDefBtn = document.getElementById('fbSetDefault');
  if (d.drives) {
    _fbCurPath = '';
    document.getElementById('fbCrumb').textContent = 'This PC';
    html = d.drives.map(drv => `<div class="fb-entry fb-dir" data-nav="${_esc(drv)}">${_FB_DRV}<span>${_esc(drv)}</span></div>`).join('');
    if (setDefBtn) { setDefBtn.style.display = 'none'; setDefBtn.className = 'fb-set-default'; setDefBtn.textContent = '📌 Set as default folder'; }
  } else {
    _fbCurPath = d.path;
    document.getElementById('fbCrumb').textContent = d.path;
    if (d.show_drives) {
      html += `<div class="fb-entry fb-up" data-nav="">${_FB_DRV}<span>This PC</span></div>`;
    } else if (d.parent !== null && d.parent !== undefined) {
      html += `<div class="fb-entry fb-up" data-nav="${_esc(d.parent)}">${_FB_DIR}<span>&#x2191; ..</span></div>`;
    }
    html += d.dirs.map(n => `<div class="fb-entry fb-dir" data-nav="${_esc(d.path + '/' + n)}">${_FB_DIR}<span>${_esc(n)}</span></div>`).join('');
    if (_fbMode === 'open') {
      html += d.files.map(n => `<div class="fb-entry fb-file" data-file="${_esc(d.path + '/' + n)}">${_FB_FILE}<span>${_esc(n)}</span></div>`).join('');
    }
    if (_fbMode === 'new' && _fbCurPath) document.getElementById('fbOkBtn').disabled = false;
    const isDefault = _fbCurPath.replace(/\\\\/g,'/') === _DEFAULT_DIR;
    if (setDefBtn) {
      setDefBtn.style.display = 'inline';
      setDefBtn.className = 'fb-set-default' + (isDefault ? ' fb-set-done' : '');
      setDefBtn.textContent = isDefault ? '✓ Default folder' : '📌 Set as default folder';
    }
  }
  list.innerHTML = html || '<div class="fb-msg">Empty folder</div>';
  list.querySelectorAll('[data-nav]').forEach(el => el.addEventListener('click', () => fbNavigate(el.dataset.nav)));
  list.querySelectorAll('[data-file]').forEach(el => el.addEventListener('click', () => fbSelectFile(el, el.dataset.file)));
}

async function fbSaveDefault() {
  const btn = document.getElementById('fbSetDefault');
  if (!_fbCurPath || !btn) return;
  btn.disabled = true;
  try {
    await fetch('/startup/set-default-dir', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({path: _fbCurPath}),
    });
    _DEFAULT_DIR = _fbCurPath.replace(/\\\\/g, '/');
    btn.className = 'fb-set-default fb-set-done';
    btn.textContent = '✓ Default folder';
  } catch(e) { /* silent */ }
  btn.disabled = false;
}

function fbSelectFile(el, filePath) {
  document.querySelectorAll('#fbList .fb-selected').forEach(e => e.classList.remove('fb-selected'));
  el.classList.add('fb-selected');
  _fbSelFile = filePath;
  document.getElementById('fbOkBtn').disabled = false;
}
function fbConfirm() {
  let chosen;
  if (_fbMode === 'open') {
    chosen = _fbSelFile;
    if (!chosen) return;
  } else {
    if (!_fbCurPath) return;
    let fname = (document.getElementById('fbFilename').value || '').trim() || 'company.dbox';
    if (!fname.toLowerCase().endsWith('.dbox')) fname += '.dbox';
    chosen = _fbCurPath + '/' + fname;
  }
  fbClose();
  showConfirm(chosen);
}

function showConfirm(path) {
  _path = path;
  document.getElementById("confirmPath").textContent = path;
  document.getElementById("confirmBox").style.display = "block";
}
function cancelConfirm() {
  _path = "";
  document.getElementById("confirmBox").style.display = "none";
}
async function openFile(path) {
  const p = path || _path;
  if (!p || _busy) return;
  setBusy(true);
  setErr("");
  try {
    const r = await fetch("/startup/open", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({path:p})});
    const d = await r.json();
    if (d.ok) { _startupNavigating = true; window.location.href = "/"; return; }
    setErr(d.error || "Could not open file.");
  } catch(e) {
    setErr("Server error — please try again.");
  }
  setBusy(false);
}
function setErr(msg) { document.getElementById("errMsg").textContent = msg; }
</script>
</body>
</html>"""


def _load_recent() -> list:
    try:
        with open(_RECENT_PATH, encoding='utf-8') as fh:
            items = json.load(fh)
        return [p for p in items if isinstance(p, str) and os.path.isfile(p)][:8]
    except Exception:
        return []


def _add_recent(path: str):
    recent = _load_recent()
    path = os.path.abspath(path)
    if path in recent:
        recent.remove(path)
    recent.insert(0, path)
    try:
        with open(_RECENT_PATH, 'w', encoding='utf-8') as fh:
            json.dump(recent[:8], fh)
    except Exception:
        pass


def _render_startup_page() -> str:
    import json as _json
    import html as _html
    recent = _load_recent()
    recent_block = ''
    if recent:
        items = ''.join(
            f'<li class="recent-item"'
            f' data-path="{_html.escape(p, quote=True)}"'
            f' title="Double-click to open"'
            f' onclick="showConfirm(this.dataset.path)"'
            f' ondblclick="openFile(this.dataset.path)">'
            f'<div class="recent-icon">{_FILE_SVG}</div>'
            f'<div><div class="recent-name">{_html.escape(os.path.basename(p))}</div>'
            f'<div class="recent-path">{_html.escape(p)}</div></div>'
            f'</li>'
            for p in recent
        )
        recent_block = (
            '<div class="recent-sep">Recently opened</div>'
            f'<ul class="recent-list">{items}</ul>'
        )
    default_dir = _load_prefs().get('default_file_dir', '').replace('\\', '/')
    return (_STARTUP_HTML
            .replace('__LOGO__', _LOGO_SVG)
            .replace('__RECENT__', recent_block)
            .replace('__DEFAULT_DIR_JSON__', _json.dumps(default_dir)))


@bp.route('/startup')
def startup_page():
    if current_app.config.get('DB_PATH') is not None:
        return redirect('/')
    return _render_startup_page()


@bp.route('/startup/fs')
def startup_fs():
    """Return directory listing for the HTML file browser."""
    raw = request.args.get('path', '').strip()

    if not raw and sys.platform == 'win32':
        drives = [f'{d}:\\' for d in _str.ascii_uppercase if os.path.exists(f'{d}:\\')]
        return jsonify({'drives': drives, 'path': ''})

    path = os.path.abspath(raw) if raw else str(pathlib.Path.home())
    if not os.path.isdir(path):
        return jsonify({'error': 'Not a directory'}), 400

    dirs, files = [], []
    try:
        with os.scandir(path) as it:
            for e in sorted(it, key=lambda x: x.name.lower()):
                try:
                    if e.is_dir(follow_symlinks=False) and not e.name.startswith('.'):
                        dirs.append(e.name)
                    elif e.is_file() and e.name.lower().endswith('.dbox'):
                        files.append(e.name)
                except OSError:
                    pass
    except PermissionError:
        return jsonify({'error': 'Permission denied'}), 403

    pp = pathlib.Path(path)
    at_root = pp == pp.parent
    return jsonify({
        'path': path,
        'parent': None if at_root else str(pp.parent),
        'show_drives': at_root and sys.platform == 'win32',
        'dirs': dirs,
        'files': files,
    })


@bp.route('/startup/set-default-dir', methods=['POST'])
def startup_set_default_dir():
    path = ((request.json or {}).get('path') or '').strip()
    if not path or not os.path.isdir(path):
        return jsonify({'ok': False})
    p = _load_prefs()
    p['default_file_dir'] = os.path.normpath(path)
    try:
        _save_prefs(p)
    except Exception:
        pass
    return jsonify({'ok': True})


@bp.route('/startup/open', methods=['POST'])
def startup_open():
    path = ((request.json or {}).get('path') or '').strip()
    if not path:
        return jsonify({'ok': False, 'error': 'No file path provided.'})
    path = os.path.abspath(path)
    if not os.path.isdir(os.path.dirname(path)):
        return jsonify({'ok': False, 'error': f'Directory not found: {os.path.dirname(path)}'})
    try:
        initialise_database(path)
        seed_defaults(path)
        ensure_default_admin(path)
    except Exception as exc:
        return jsonify({'ok': False, 'error': str(exc)})
    import hashlib
    import time as _t
    current_app.config['DB_PATH'] = path
    current_app.secret_key = hashlib.sha256(f'dbox-web-{path}-{_t.time()}'.encode()).digest()
    _add_recent(path)
    return jsonify({'ok': True})
