import os
from flask import Blueprint, request, Response

from web.shared import db, ok, err, login_required
from core.attachments import get_attachments, add_attachment, delete_attachment, get_attachment_data

bp = Blueprint('attachments', __name__)

_ATTACH_TYPES = {"invoice", "bill", "payment", "purchase_order",
                 "job", "warranty", "payslip", "journal"}


@bp.route("/api/attachments/<source_type>/<int:source_id>")
@login_required
def api_attachments_list(source_type, source_id):
    if source_type not in _ATTACH_TYPES:
        return err("Invalid source type", 400)
    rows = get_attachments(db(), source_type, source_id)
    return ok(rows)


@bp.route("/api/attachments/<source_type>/<int:source_id>", methods=["POST"])
@login_required
def api_attachments_upload(source_type, source_id):
    if source_type not in _ATTACH_TYPES:
        return err("Invalid source type", 400)
    f = request.files.get("file")
    if not f:
        return err("No file provided", 400)
    description = request.form.get("description", "")
    MAX_BYTES = 20 * 1024 * 1024
    data = f.read()
    if len(data) > MAX_BYTES:
        return err("File exceeds 20 MB limit", 400)
    import mimetypes as _mt, tempfile as _tmp
    filename = f.filename or "upload"
    tmp = _tmp.NamedTemporaryFile(delete=False, suffix=os.path.splitext(filename)[1])
    dest = None
    try:
        tmp.write(data); tmp.close()
        dest = os.path.join(os.path.dirname(tmp.name), filename)
        os.rename(tmp.name, dest)
        add_attachment(db(), source_type, source_id, dest, description)
    finally:
        for p in [tmp.name, dest]:
            if p:
                try: os.unlink(p)
                except: pass
    rows = get_attachments(db(), source_type, source_id)
    return ok(rows)


@bp.route("/api/attachments/<int:att_id>", methods=["DELETE"])
@login_required
def api_attachment_delete(att_id):
    delete_attachment(db(), att_id)
    return ok()


@bp.route("/api/attachments/<int:att_id>/download")
@login_required
def api_attachment_download(att_id):
    att = get_attachment_data(db(), att_id)
    if not att:
        return err("Not found", 404)
    return Response(
        att["file_data"],
        mimetype=att["mime_type"] or "application/octet-stream",
        headers={"Content-Disposition": f'attachment; filename="{att["filename"]}"'})
