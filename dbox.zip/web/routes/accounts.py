# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from flask import Blueprint, request

from web.shared import db, ok, err, login_required
from core.ledger import get_accounts, save_account, get_account_balance, get_account_balances_batch
from core.database import get_connection

bp = Blueprint('accounts', __name__)


@bp.route("/api/accounts")
@login_required
def api_accounts():
    accs = get_accounts(db(), active_only=False)
    return ok([dict(a) for a in accs])


@bp.route("/api/accounts", methods=["POST"])
@login_required
def api_account_save():
    data = request.get_json() or {}
    try:
        save_account(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/accounts/<int:aid>")
@login_required
def api_account(aid):
    conn = get_connection(db())
    row = conn.execute("SELECT * FROM accounts WHERE id=?", (aid,)).fetchone()
    conn.close()
    if not row:
        return err("Not found", 404)
    a = dict(row)
    a["balance"] = round(get_account_balance(db(), aid), 2)
    return ok(a)


@bp.route("/api/accounts/<int:aid>", methods=["PUT"])
@login_required
def api_account_update(aid):
    data = request.get_json() or {}
    data["id"] = aid
    try:
        save_account(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/accounts/<int:aid>/balance")
@login_required
def api_account_balance(aid):
    bal = get_account_balance(db(), aid)
    return ok(round(bal, 2))


@bp.route("/api/accounts/balances", methods=["POST"])
@login_required
def api_account_balances_batch():
    ids = request.get_json() or []
    try:
        balances = get_account_balances_batch(db(), ids)
        return ok({str(k): round(v, 2) for k, v in balances.items()})
    except Exception as e:
        return err(str(e))
