import os, io, json
from datetime import date
from flask import Blueprint, request, session, jsonify, send_file, Response, abort

from web.shared import db, ok, err, login_required, tier_required, current_user, dict_rows
from core.database import get_connection
from core.payroll import (
    get_employees, get_employee, save_employee,
    get_pay_runs, get_pay_run, calculate_payslip,
    create_pay_run, finalise_pay_run, void_pay_run,
    super_rate, current_fy, PAY_FREQUENCIES, EMPLOYMENT_TYPES,
    next_employee_number, LEAVE_TYPES, ALLOWANCE_TYPES as PAYROLL_ALLOWANCE_TYPES,
    get_stp_submissions, lodge_stp, lodge_stp_finalisation,
    generate_payslip_pdf,
    get_super_payments, get_super_payment, get_super_accruals,
    create_super_payment, finalise_super_payment,
    generate_super_remittance_pdf, _super_quarter,
    get_payslips_for_employee,
    load_payg_rates, save_payg_rates, list_payg_rate_years,
    payg_for_period,
    get_payg_summary, render_payg_summary_pdf, reset_ytd,
    generate_payrun_report_pdf,
    generate_outstanding_leave_pdf, generate_outstanding_leave_csv,
)
from core.awards import (
    get_awards, get_award, save_award, delete_award,
    get_classifications, get_classification, save_classification, delete_classification,
    get_pay_rates, get_current_rate, save_pay_rate, delete_pay_rate,
    get_award_allowances, save_award_allowance, delete_award_allowance,
    get_penalty_rates, save_penalty_rate, delete_penalty_rate,
    resolve_rate_from_classification, get_employees_by_award,
    bulk_apply_wage_increase,
    INSTRUMENT_TYPES, ALLOWANCE_TYPES, PENALTY_TYPES,
)
from core.leave import (
    get_leave_types, get_leave_type, save_leave_type,
    get_leave_balances, initialise_employee_leave,
    get_leave_requests, get_leave_request, save_leave_request,
    approve_leave, decline_leave, cancel_leave,
    get_medical_certs, save_medical_cert, delete_medical_cert,
    get_public_holidays, save_public_holiday, delete_public_holiday,
    post_accrual, get_accrual_history,
)
from core.licence import get_licence_status, watermark_text, pdf_footer_text, has_feature
from web.shared import _get_licence_status
import sqlite3

bp = Blueprint('payroll', __name__)


@bp.before_request
def _check_payroll_feature():
    if not has_feature(_get_licence_status(), "payroll"):
        return err("Payroll is not enabled on this licence", 403)


def _get_pdf_watermark() -> str | None:
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
        return watermark_text(status)
    except Exception:
        return "Unregistered"


def _get_pdf_footer() -> str | None:
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
        return pdf_footer_text(status)
    except Exception:
        return None


# ── Payroll ────────────────────────────────────────────────────────────────────
@bp.route("/api/payroll/employees")
@login_required
@tier_required("payroll")
def api_employees():
    return ok([dict(e) for e in get_employees(db())])

@bp.route("/api/payroll/pay-runs")
@login_required
@tier_required("payroll")
def api_pay_runs():
    return ok([dict(r) for r in get_pay_runs(db())])

@bp.route("/api/payroll/pay-runs/<int:rid>")
@login_required
@tier_required("payroll")
def api_pay_run(rid):
    run, slips = get_pay_run(db(), rid)
    return ok({"run": dict(run), "slips": [dict(s) for s in slips]})

@bp.route("/api/payroll/employees/<int:eid>")
@login_required
@tier_required("payroll")
def api_employee(eid):
    emp = get_employee(db(), eid)
    if not emp:
        return err("Employee not found", 404)
    return ok(dict(emp))

@bp.route("/api/payroll/employees/<int:eid>", methods=["POST"])
@login_required
@tier_required("payroll")
def api_employee_save(eid):
    data = request.get_json(force=True)
    data["id"] = eid
    new_id = save_employee(db(), data)
    emp = get_employee(db(), new_id)
    return ok(dict(emp))

@bp.route("/api/payroll/employees", methods=["POST"])
@login_required
@tier_required("payroll")
def api_employee_create():
    data = request.get_json(force=True)
    data.pop("id", None)   # ensure insert
    new_id = save_employee(db(), data)
    emp = get_employee(db(), new_id)
    return ok(dict(emp))

@bp.route("/api/payroll/next-employee-number")
@login_required
@tier_required("payroll")
def api_next_employee_number():
    return ok({"number": next_employee_number(db())})


@bp.route("/api/payroll/awards")
@login_required
@tier_required("payroll")
def api_payroll_awards():
    """Return awards/agreements. Pass ?active_only=0 to include inactive."""
    active_only = request.args.get("active_only", "1") != "0"
    awards = get_awards(db(), active_only=active_only)
    return ok([{"id": a["id"], "name": a["name"],
                "instrument_type": a.get("instrument_type", ""),
                "code": a.get("code", ""),
                "is_active": a.get("is_active", 1),
                "employee_count": a.get("employee_count", 0)} for a in awards])

@bp.route("/api/payroll/awards/<int:award_id>/classifications")
@login_required
@tier_required("payroll")
def api_payroll_classifications(award_id):
    """Return active classifications for an award, with current resolved pay rate."""
    clss = get_classifications(db(), award_id)
    result = []
    for c in clss:
        resolved = resolve_rate_from_classification(db(), c["id"], pay_point=1)
        result.append({
            "id":         c["id"],
            "name":       c["name"],
            "code":       c.get("code", ""),
            "sort_order": c.get("sort_order", 0),
            "hourly_rate": resolved.get("hourly_rate"),
        })
    return ok(result)

@bp.route("/api/payroll/awards/<int:award_id>/classifications/<int:cls_id>/rate")
@login_required
@tier_required("payroll")
def api_payroll_cls_rate(award_id, cls_id):
    """Resolve award pay rate for a classification + pay point."""
    pay_point = request.args.get("pay_point", 1, type=int)
    resolved = resolve_rate_from_classification(db(), cls_id, pay_point=pay_point)
    return ok({
        "hourly_rate":  resolved.get("hourly_rate"),
        "award_name":   resolved.get("award_name", ""),
        "cls_name":     resolved.get("classification_name", ""),
    })


# ── Awards Management — full CRUD (Stage 5M) ─────────────────────────────────

@bp.route("/api/payroll/awards", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payroll_awards_create():
    """Create a new award/agreement."""
    data = request.get_json() or {}
    new_id = save_award(db(), data)
    return ok({"id": new_id})

@bp.route("/api/payroll/awards/<int:award_id>")
@login_required
@tier_required("payroll")
def api_payroll_award_get(award_id):
    """Return full award detail."""
    a = get_award(db(), award_id)
    if not a:
        return err("Award not found", 404)
    a.pop("file_data", None)   # never send blob over JSON
    return ok(a)

@bp.route("/api/payroll/awards/<int:award_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_payroll_award_update(award_id):
    """Update an award/agreement."""
    data = request.get_json() or {}
    data["id"] = award_id
    save_award(db(), data)
    return ok({"id": award_id})

@bp.route("/api/payroll/awards/<int:award_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_payroll_award_delete(award_id):
    """Soft-delete (deactivate) an award."""
    delete_award(db(), award_id)
    return ok({})

@bp.route("/api/payroll/awards/<int:award_id>/employees")
@login_required
@tier_required("payroll")
def api_payroll_award_employees(award_id):
    """Return employees assigned to this award."""
    emps = get_employees_by_award(db(), award_id)
    return ok(emps)

@bp.route("/api/payroll/awards/<int:award_id>/wage-increase", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payroll_award_wage_increase(award_id):
    """Bulk apply an annual wage increase to all classifications."""
    data = request.get_json() or {}
    effective_date   = data.get("effective_date")
    increase_percent = data.get("increase_percent")
    source_note      = data.get("source_note", "")
    if not effective_date or increase_percent is None:
        return err("effective_date and increase_percent required")
    try:
        count = bulk_apply_wage_increase(db(), award_id, effective_date,
                                         float(increase_percent), source_note)
    except Exception as e:
        return err(str(e), 500)
    return ok({"rows_created": count})

@bp.route("/api/payroll/awards/meta")
@login_required
@tier_required("payroll")
def api_payroll_awards_meta():
    """Return dropdown constants for the awards UI."""
    return ok({
        "instrument_types": INSTRUMENT_TYPES,
        "allowance_types":  ALLOWANCE_TYPES,
        "penalty_types":    [{"code": c, "label": l} for c, l in PENALTY_TYPES],
    })

# ── Classifications ────────────────────────────────────────────────────────────

@bp.route("/api/payroll/awards/<int:award_id>/classifications", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payroll_classifications_create(award_id):
    data = request.get_json() or {}
    data["award_id"] = award_id
    new_id = save_classification(db(), data)
    return ok({"id": new_id})

@bp.route("/api/payroll/classifications/<int:cls_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_payroll_classification_update(cls_id):
    data = request.get_json() or {}
    data["id"] = cls_id
    save_classification(db(), data)
    return ok({"id": cls_id})

@bp.route("/api/payroll/classifications/<int:cls_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_payroll_classification_delete(cls_id):
    delete_classification(db(), cls_id)
    return ok({})

# ── Pay Rates ─────────────────────────────────────────────────────────────────

@bp.route("/api/payroll/classifications/<int:cls_id>/pay-rates")
@login_required
@tier_required("payroll")
def api_payroll_pay_rates(cls_id):
    rows = get_pay_rates(db(), cls_id)
    return ok(rows)

@bp.route("/api/payroll/classifications/<int:cls_id>/pay-rates", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payroll_pay_rates_create(cls_id):
    data = request.get_json() or {}
    data["classification_id"] = cls_id
    try:
        new_id = save_pay_rate(db(), data)
    except sqlite3.IntegrityError:
        return err("A rate for this pay point and effective date already exists.", 409)
    return ok({"id": new_id})

@bp.route("/api/payroll/pay-rates/<int:rate_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_payroll_pay_rate_update(rate_id):
    data = request.get_json() or {}
    data["id"] = rate_id
    try:
        save_pay_rate(db(), data)
    except sqlite3.IntegrityError:
        return err("A rate for this pay point and effective date already exists.", 409)
    return ok({"id": rate_id})

@bp.route("/api/payroll/pay-rates/<int:rate_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_payroll_pay_rate_delete(rate_id):
    delete_pay_rate(db(), rate_id)
    return ok({})

# ── Allowances ────────────────────────────────────────────────────────────────

@bp.route("/api/payroll/awards/<int:award_id>/allowances")
@login_required
@tier_required("payroll")
def api_payroll_allowances(award_id):
    rows = get_award_allowances(db(), award_id)
    return ok(rows)

@bp.route("/api/payroll/awards/<int:award_id>/allowances", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payroll_allowances_create(award_id):
    data = request.get_json() or {}
    data["award_id"] = award_id
    try:
        new_id = save_award_allowance(db(), data)
    except Exception as e:
        return err(str(e), 500)
    return ok({"id": new_id})

@bp.route("/api/payroll/allowances/<int:allowance_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_payroll_allowance_update(allowance_id):
    data = request.get_json() or {}
    data["id"] = allowance_id
    try:
        save_award_allowance(db(), data)
    except Exception as e:
        return err(str(e), 500)
    return ok({"id": allowance_id})

@bp.route("/api/payroll/allowances/<int:allowance_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_payroll_allowance_delete(allowance_id):
    delete_award_allowance(db(), allowance_id)
    return ok({})

# ── Penalty Rates ─────────────────────────────────────────────────────────────

@bp.route("/api/payroll/awards/<int:award_id>/penalties")
@login_required
@tier_required("payroll")
def api_payroll_penalties(award_id):
    rows = get_penalty_rates(db(), award_id)
    return ok(rows)

@bp.route("/api/payroll/awards/<int:award_id>/penalties", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payroll_penalties_create(award_id):
    data = request.get_json() or {}
    data["award_id"] = award_id
    try:
        new_id = save_penalty_rate(db(), data)
    except Exception as e:
        return err(str(e), 500)
    return ok({"id": new_id})

@bp.route("/api/payroll/penalties/<int:penalty_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_payroll_penalty_update(penalty_id):
    data = request.get_json() or {}
    data["id"] = penalty_id
    try:
        save_penalty_rate(db(), data)
    except Exception as e:
        return err(str(e), 500)
    return ok({"id": penalty_id})

@bp.route("/api/payroll/penalties/<int:penalty_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_payroll_penalty_delete(penalty_id):
    delete_penalty_rate(db(), penalty_id)
    return ok({})

# ── End Stage 5M ──────────────────────────────────────────────────────────────

@bp.route("/api/payroll/pay-runs/preview", methods=["POST"])
@login_required
@tier_required("payroll")
def api_pay_run_preview():
    """
    Calculate payslips for a proposed pay run without saving anything.
    Body: {
      period_start, period_end, payment_date, frequency,
      employee_ids: [int, ...],          // subset; omit or [] = all active
      adjustments: {                     // keyed by employee_id (string)
        "42": {
          ordinary_hours, overtime_hours,
          leave_type, leave_hours,
          salary_sacrifice,
          allowances: [{type, amount}, ...]
        }
      }
    }
    Returns: { slips: [...], totals: {gross, tax, net, super} }
    """
    body = request.get_json(force=True) or {}
    period_start  = body.get("period_start")
    period_end    = body.get("period_end")
    payment_date  = body.get("payment_date")
    frequency     = body.get("frequency", "Fortnightly")
    emp_ids       = body.get("employee_ids") or []
    adjustments   = body.get("adjustments") or {}

    if not all([period_start, period_end, payment_date]):
        return err("period_start, period_end, and payment_date are required", 400)

    # Resolve employee list
    if emp_ids:
        employees = [get_employee(db(), eid) for eid in emp_ids]
        employees = [e for e in employees if e]
    else:
        employees = get_employees(db(), active_only=True)

    slips = []
    errors = []
    for emp in employees:
        adj = adjustments.get(str(emp["id"])) or {}
        try:
            slip = calculate_payslip(
                db_path       = db(),
                employee_id   = emp["id"],
                period_start  = period_start,
                period_end    = period_end,
                payment_date  = payment_date,
                frequency     = frequency,
                ordinary_hours     = adj.get("ordinary_hours"),        # None = auto
                overtime_hours     = float(adj.get("overtime_hours") or 0),
                leave_type         = adj.get("leave_type") or None,
                leave_hours        = float(adj.get("leave_hours") or 0),
                allowances         = adj.get("allowances") or [],
                salary_sacrifice   = adj.get("salary_sacrifice"),      # None = employee default
            )
            # Strip internal-only keys before sending to client
            clean = {k: v for k, v in slip.items() if not k.startswith("_")}
            clean["employee_name"] = f"{emp['first_name']} {emp['last_name']}"
            clean["employee_number"] = emp.get("employee_number", "")
            clean["pay_frequency"] = emp.get("pay_frequency", frequency)
            slips.append(clean)
        except Exception as ex:
            errors.append({"employee_id": emp["id"],
                           "employee_name": f"{emp['first_name']} {emp['last_name']}",
                           "error": str(ex)})

    totals = {
        "gross": sum(s["gross_pay"]    for s in slips),
        "tax":   sum(s["payg_tax"]     for s in slips),
        "net":   sum(s["net_pay"]      for s in slips),
        "super": sum(s["super_amount"] for s in slips),
    }
    return ok({"slips": slips, "totals": totals, "errors": errors})


@bp.route("/api/payroll/pay-runs", methods=["POST"])
@login_required
@tier_required("payroll")
def api_pay_run_create():
    """
    Create a draft pay run from confirmed preview data.
    Body: same shape as preview — re-calculates and saves atomically.
    Returns: saved pay run id + run_number.
    """
    body = request.get_json(force=True) or {}
    period_start  = body.get("period_start")
    period_end    = body.get("period_end")
    payment_date  = body.get("payment_date")
    frequency     = body.get("frequency", "Fortnightly")
    emp_ids       = body.get("employee_ids") or []
    adjustments   = body.get("adjustments") or {}

    if not all([period_start, period_end, payment_date]):
        return err("period_start, period_end, and payment_date are required", 400)

    employees = [get_employee(db(), eid) for eid in emp_ids] if emp_ids \
                else get_employees(db(), active_only=True)
    employees = [e for e in employees if e]

    payslips_data = []
    for emp in employees:
        adj = adjustments.get(str(emp["id"])) or {}
        try:
            slip = calculate_payslip(
                db_path       = db(),
                employee_id   = emp["id"],
                period_start  = period_start,
                period_end    = period_end,
                payment_date  = payment_date,
                frequency     = frequency,
                ordinary_hours   = adj.get("ordinary_hours"),
                overtime_hours   = float(adj.get("overtime_hours") or 0),
                leave_type       = adj.get("leave_type") or None,
                leave_hours      = float(adj.get("leave_hours") or 0),
                allowances       = adj.get("allowances") or [],
                salary_sacrifice = adj.get("salary_sacrifice"),
            )
            payslips_data.append(slip)
        except Exception as ex:
            return err(f"Could not calculate payslip for "
                       f"{emp['first_name']} {emp['last_name']}: {ex}", 400)

    if not payslips_data:
        return err("No employees to include in pay run", 400)

    user_id = session.get("user_id")
    run_id  = create_pay_run(db(), period_start, period_end, payment_date,
                              frequency, payslips_data, created_by=user_id)
    run, _ = get_pay_run(db(), run_id)
    return ok({"id": run_id, "run_number": run["run_number"]})


@bp.route("/api/payroll/pay-runs/<int:rid>/finalise", methods=["POST"])
@login_required
@tier_required("payroll")
def api_pay_run_finalise(rid):
    """Finalise a draft pay run: update YTD, post GL journal, mark Finalised."""
    run, _ = get_pay_run(db(), rid)
    if not run:
        return err("Pay run not found", 404)
    if run["status"] != "Draft":
        return err(f"Pay run is already {run['status']} — cannot finalise", 400)
    try:
        finalise_pay_run(db(), rid)
    except Exception as ex:
        return err(str(ex), 400)
    run, slips = get_pay_run(db(), rid)
    return ok({"run": dict(run), "slips": [dict(s) for s in slips]})


@bp.route("/api/payroll/pay-runs/<int:rid>/void", methods=["POST"])
@login_required
@tier_required("payroll")
def api_pay_run_void(rid):
    """Void a finalised pay run: reverse GL journal, unwind YTD."""
    run, _ = get_pay_run(db(), rid)
    if not run:
        return err("Pay run not found", 404)
    username = (session.get("user", {}) or {}).get("username", "web")
    try:
        void_pay_run(db(), rid, voided_by=username)
    except ValueError as ex:
        return err(str(ex), 400)
    except Exception as ex:
        return err(str(ex), 500)
    run, slips = get_pay_run(db(), rid)
    return ok({"run": dict(run), "slips": [dict(s) for s in slips]})


@bp.route("/api/payroll/pay-runs/<int:rid>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_pay_run_delete(rid):
    """Delete a draft pay run and its payslips. Finalised runs cannot be deleted."""
    run, _ = get_pay_run(db(), rid)
    if not run:
        return err("Pay run not found", 404)
    if run["status"] != "Draft":
        return err("Only Draft pay runs can be deleted", 400)
    conn = get_connection(db())
    try:
        conn.execute("DELETE FROM payslips  WHERE pay_run_id=?", (rid,))
        conn.execute("DELETE FROM pay_runs  WHERE id=?", (rid,))
        conn.commit()
    finally:
        conn.close()
    return ok({"deleted": rid})


@bp.route("/api/payroll/meta")
@login_required
@tier_required("payroll")
def api_payroll_meta():
    """Return constants the UI needs: leave types, allowance types, frequencies."""
    return ok({
        "leave_types":    LEAVE_TYPES,
        "allowance_types": PAYROLL_ALLOWANCE_TYPES,
        "pay_frequencies": PAY_FREQUENCIES,
    })


# ── STP Submissions ────────────────────────────────────────────────────────────

@bp.route("/api/payroll/stp-submissions")
@login_required
@tier_required("payroll")
def api_stp_submissions():
    """List all STP submissions, newest first."""
    try:
        subs = get_stp_submissions(db())
        return ok(subs)
    except Exception as e:
        return err(str(e), 500)


@bp.route("/api/payroll/pay-runs/<int:rid>/lodge-stp", methods=["POST"])
@login_required
@tier_required("payroll")
def api_lodge_stp(rid):
    """Generate STP Phase 2 XML, record in stp_submissions, mark run STP_Lodged."""
    body = request.get_json() or {}
    abn  = body.get("abn", "").replace(" ", "")
    if not abn or not abn.isdigit() or len(abn) != 11:
        return err("Invalid ABN — must be 11 digits", 400)
    try:
        result = lodge_stp(db(), rid, abn)
        # Retrieve the submission id that lodge_stp just inserted
        subs   = get_stp_submissions(db())
        sub_id = next((s["id"] for s in subs if s["pay_run_id"] == rid), None)
        return ok({
            "submission_id": sub_id,
            "status":        result["status"],
            "message":       result["message"],
        })
    except Exception as e:
        return err(str(e), 500)


@bp.route("/api/payroll/stp-submissions/<int:sub_id>/xml")
@login_required
@tier_required("payroll")
def api_stp_xml_download(sub_id):
    """Return the stored STP XML payload as a downloadable file."""
    from flask import Response
    conn = get_connection(db())
    row  = conn.execute(
        "SELECT payload_xml, pay_run_id FROM stp_submissions WHERE id=?",
        (sub_id,)
    ).fetchone()
    conn.close()
    if not row or not row["payload_xml"]:
        return err("STP submission not found or has no XML", 404)
    filename = f"stp_submission_{sub_id}_run_{row['pay_run_id']}.xml"
    return Response(
        row["payload_xml"],
        mimetype="application/xml",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@bp.route("/api/payroll/pay-runs/<int:run_id>/payslips/<int:slip_id>/pdf")
@login_required
@tier_required("payroll")
def api_payslip_pdf(run_id, slip_id):
    """Download a single payslip as a Fair Work Act compliant PDF."""
    import os as _os
    try:
        watermark = _get_pdf_watermark()
        pdf_path = generate_payslip_pdf(db(), payslip_id=slip_id,
                                        watermark=watermark, footer=_get_pdf_footer())
    except ValueError as e:
        return err(str(e), 404)
    except ImportError as e:
        return err(str(e), 500)
    except Exception as e:
        return err(f"PDF generation failed: {e}", 500)
    filename = _os.path.basename(pdf_path)
    return send_file(pdf_path, mimetype="application/pdf",
                     as_attachment=True, download_name=filename)


@bp.route("/api/payroll/pay-runs/<int:run_id>/payslips/pdf")
@login_required
@tier_required("payroll")
def api_payslips_bulk_pdf(run_id):
    """Download all payslips for a pay run merged into a single PDF."""
    import io as _io
    import os as _os
    try:
        from pypdf import PdfWriter
    except ImportError:
        return err("pypdf not installed. Run: pip install pypdf", 500)
    try:
        conn = get_connection(db())
        run  = conn.execute("SELECT run_number FROM pay_runs WHERE id=?",
                            (run_id,)).fetchone()
        if not run:
            return err("Pay run not found", 404)
        run_number = run["run_number"]
        slip_ids = [r["id"] for r in conn.execute(
            "SELECT id FROM payslips WHERE pay_run_id=? ORDER BY id",
            (run_id,)).fetchall()]
        conn.close()
        if not slip_ids:
            return err("No payslips in this pay run", 404)

        watermark = _get_pdf_watermark()
        writer = PdfWriter()
        tmp_paths = []
        for sid in slip_ids:
            path = generate_payslip_pdf(db(), payslip_id=sid, watermark=watermark, footer=_get_pdf_footer())
            tmp_paths.append(path)
            from pypdf import PdfReader
            reader = PdfReader(path)
            for page in reader.pages:
                writer.add_page(page)

        buf = _io.BytesIO()
        writer.write(buf)
        buf.seek(0)

        # Clean up temp files
        for p in tmp_paths:
            try: _os.remove(p)
            except OSError: pass

        filename = f"payslips_{run_number}.pdf"
        return send_file(buf, mimetype="application/pdf",
                         as_attachment=True, download_name=filename)
    except (ValueError, ImportError) as e:
        return err(str(e), 400)
    except Exception as e:
        return err(f"Bulk PDF generation failed: {e}", 500)


@bp.route("/api/payroll/pay-runs/<int:run_id>/report")
@login_required
@tier_required("payroll")
def api_payrun_report_pdf(run_id):
    """Download the pay run summary report as a PDF."""
    import os as _os
    try:
        watermark = _get_pdf_watermark()
        pdf_path = generate_payrun_report_pdf(db(), run_id, watermark=watermark, footer=_get_pdf_footer())
    except ValueError as e:
        return err(str(e), 404)
    except ImportError as e:
        return err(str(e), 500)
    except Exception as e:
        return err(f"PDF generation failed: {e}", 500)
    filename = _os.path.basename(pdf_path)
    return send_file(pdf_path, mimetype="application/pdf",
                     as_attachment=True, download_name=filename)


@bp.route("/api/payroll/stp-submissions/<int:sub_id>/mark-lodged", methods=["POST"])
@login_required
@tier_required("payroll")
def api_stp_mark_lodged(sub_id):
    """Manually mark a submission as Lodged (used after filing via tax agent)."""
    import datetime as _dt
    conn = get_connection(db())
    conn.execute(
        "UPDATE stp_submissions SET status='Lodged', message=? WHERE id=?",
        (f"Manually marked as lodged {_dt.date.today()}", sub_id)
    )
    conn.commit()
    conn.close()
    return ok({})


@bp.route("/api/payroll/stp-submissions/<int:sub_id>/status", methods=["PATCH"])
@login_required
@tier_required("payroll")
def api_stp_update_status(sub_id):
    """Update status and append a timestamped note to an STP submission."""
    import datetime as _dt
    body   = request.get_json(force=True) or {}
    status = (body.get("status") or "").strip()
    note   = (body.get("note")   or "").strip()

    allowed = {"Pending", "Submitted", "Lodged", "Rejected"}
    if status not in allowed:
        return err(f"Invalid status — must be one of: {', '.join(sorted(allowed))}", 400)

    conn = get_connection(db())
    row  = conn.execute(
        "SELECT message FROM stp_submissions WHERE id=?", (sub_id,)
    ).fetchone()
    if not row:
        conn.close()
        return err("Submission not found", 404)

    existing    = (row["message"] or "").strip()
    ts          = _dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    new_message = (f"{existing}\n[{ts}] {note}".strip()) if note else existing

    conn.execute(
        "UPDATE stp_submissions SET status=?, message=? WHERE id=?",
        (status, new_message, sub_id)
    )
    conn.commit()
    conn.close()
    return ok({})


@bp.route("/api/payroll/stp-finalisation", methods=["POST"])
@login_required
@tier_required("payroll")
def api_lodge_stp_finalisation():
    """
    Generate an STP Phase 2 Finalisation declaration for the current FY.
    Uses YTD totals from the most recent finalised pay run.
    Not tied to a specific pay run — this is the end-of-year declaration.
    """
    body = request.get_json() or {}
    abn  = body.get("abn", "").replace(" ", "")
    if not abn or not abn.isdigit() or len(abn) != 11:
        return err("Invalid ABN — must be 11 digits", 400)
    try:
        result = lodge_stp_finalisation(db(), abn)
        if result["status"] == "Error":
            return err(result["message"], 400)
        return ok({
            "submission_id": result["submission_id"],
            "status":        result["status"],
            "message":       result["message"],
        })
    except Exception as e:
        return err(str(e), 500)


@bp.route("/api/payroll/super-payments", methods=["GET", "POST"])
@login_required
@tier_required("payroll")
def api_super_payments():
    """
    GET  — Return all super payment batches, newest first.
    POST — Create a super payment batch from accruals.
           Body: { payment_date, payment_method, reference, notes, lines: [...] }
           lines shape mirrors get_super_accruals rows: employee_id, fund_name,
           fund_abn, fund_usi, member_number, sgc_amount, salary_sacrifice,
           voluntary_amount, period_start, period_end, pay_run_ids (list of ints).
    """
    if request.method == "GET":
        return ok(get_super_payments(db()))

    # POST — create batch
    body = request.json or {}
    payment_date = body.get("payment_date")
    if not payment_date:
        return err("payment_date is required")
    lines = body.get("lines")
    if not lines:
        return err("lines cannot be empty")
    quarter, due_date = _super_quarter(payment_date)
    try:
        pmt_id = create_super_payment(
            db(),
            payment_date=payment_date,
            quarter=quarter,
            due_date=due_date,
            lines=lines,
            payment_method=body.get("payment_method", "SuperStream"),
            reference=body.get("reference") or None,
            notes=body.get("notes") or None,
            created_by=session.get("user_id"),
        )
    except Exception as e:
        return err(str(e))
    pmt, pmt_lines = get_super_payment(db(), pmt_id)
    return ok({"payment": pmt, "lines": pmt_lines})


@bp.route("/api/payroll/super-payments/<int:payment_id>")
@login_required
@tier_required("payroll")
def api_super_payment(payment_id):
    """Return a single super payment batch with its employee lines."""
    pmt, lines = get_super_payment(db(), payment_id)
    if not pmt:
        return err("Super payment not found", 404)
    return ok({"payment": pmt, "lines": lines})


@bp.route("/api/payroll/super-accruals")
@login_required
@tier_required("payroll")
def api_super_accruals():
    """Return unremitted super accruals from finalised pay runs."""
    return ok(get_super_accruals(db()))


@bp.route("/api/payroll/super-payments/<int:payment_id>/finalise", methods=["POST"])
@login_required
@tier_required("payroll")
def api_super_payment_finalise(payment_id):
    """Mark a super payment batch as Paid and post the GL journal."""
    try:
        finalise_super_payment(db(), payment_id, post_journal=True)
    except (ValueError, Exception) as e:
        return err(str(e))
    pmt, lines = get_super_payment(db(), payment_id)
    return ok({"payment": pmt, "lines": lines})


@bp.route("/api/payroll/super-payments/<int:payment_id>/remittance-pdf")
@login_required
@tier_required("payroll")
def api_super_remittance_pdf(payment_id):
    """Download a SuperStream-style remittance advice PDF."""
    try:
        pdf_path = generate_super_remittance_pdf(db(), payment_id)
    except Exception as e:
        return err(str(e))
    from flask import send_file
    pmt, _ = get_super_payment(db(), payment_id)
    filename = (f"super_remittance_{pmt['payment_number']}.pdf"
                if pmt else "super_remittance.pdf")
    return send_file(pdf_path, mimetype="application/pdf",
                     as_attachment=True, download_name=filename)


# ── Payslip History  (Stage 5R) ───────────────────────────────────────────────

@bp.route("/api/payroll/employees/<int:employee_id>/payslips")
@login_required
@tier_required("payroll")
def api_employee_payslips(employee_id):
    """Return recent payslips for an employee (default last 20)."""
    limit = int(request.args.get("limit", 20))
    return ok(get_payslips_for_employee(db(), employee_id, limit=limit))


# ── ABA File Export  (Stage 5P) ───────────────────────────────────────────────

@bp.route("/api/payroll/aba-settings")
@login_required
@tier_required("payroll")
def api_aba_settings_get():
    """Return ABA configuration (user_id, description, plus bank account details)."""
    from core.aba import get_aba_settings
    return ok(get_aba_settings(db()))


@bp.route("/api/payroll/aba-settings", methods=["POST"])
@login_required
@tier_required("payroll")
def api_aba_settings_save():
    """Persist ABA-specific settings (user_id, description) to company record."""
    from core.aba import save_aba_settings
    save_aba_settings(db(), request.json or {})
    return ok({})


@bp.route("/api/payroll/pay-runs/<int:rid>/aba", methods=["POST"])
@login_required
@tier_required("payroll")
def api_pay_run_aba(rid):
    """
    Build and stream an ABA direct-entry file for the net pay of all payslips
    in this pay run.

    POST body: { process_date: "YYYY-MM-DD", description: "PAYROLL" }

    Bank details (BSB, account_number) are read from the contact record linked
    to each employee.  Returns 422 with a plain-text error if any employee is
    missing bank details or if the company bank account is not configured.
    """
    from core.aba import generate_aba, ABAError
    from flask import Response

    body         = request.json or {}
    process_date = body.get("process_date", date.today().isoformat())
    description  = (body.get("description") or "PAYROLL")[:12]

    run, slips = get_pay_run(db(), rid)
    if not run:
        return err("Pay run not found", 404)

    run_dict = dict(run)

    conn     = get_connection(db())
    payments = []
    missing  = []

    for slip in slips:
        slip = dict(slip)
        row  = conn.execute(
            """SELECT e.id, e.bank_bsb, e.bank_account, e.bank_name,
                      e.first_name, e.last_name
               FROM employees e
               WHERE e.id = ?""",
            (slip["employee_id"],)
        ).fetchone()
        emp = dict(row) if row else {}

        bsb  = (emp.get("bank_bsb")     or "").strip()
        acct = (emp.get("bank_account") or "").strip()
        name = (emp.get("bank_name") or
                " ".join(filter(None, [emp.get("first_name"), emp.get("last_name")])) or
                f"Employee {slip['employee_id']}")

        if not bsb or not acct:
            missing.append(name)
            continue

        net = round(float(slip.get("net_pay") or 0), 2)
        if net <= 0:
            continue   # skip $0 payslips silently

        payments.append({
            "dest_bsb":      bsb,
            "dest_account":  acct,
            "dest_name":     name[:32],
            "amount":        net,
            "lodgement_ref": f"PAY{rid:04d}",
        })

    conn.close()

    if missing:
        return err(
            f"Missing BSB/account for: {', '.join(missing)}.\n\n"
            f"Edit each employee in Payroll → Employees and add their "
            f"BSB and Account Number.", 422)

    if not payments:
        return err("No payable employees in this run (all net pay is $0).", 422)

    try:
        content = generate_aba(db(), payments, process_date, description)
    except ABAError as e:
        return err(str(e), 422)

    period_end = run_dict.get("pay_period_end", "").replace("-", "") or str(rid)
    filename   = f"payroll_{period_end}.aba"

    return Response(
        content,
        mimetype="text/plain",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ── Leave Management ─────────────────────────────────────────────────────────

@bp.route("/api/leave/types")
@login_required
@tier_required("payroll")
def api_leave_types():
    active_only = request.args.get("active_only", "1") != "0"
    return ok(get_leave_types(db(), active_only=active_only))


@bp.route("/api/leave/requests")
@login_required
@tier_required("payroll")
def api_leave_requests():
    emp_id    = request.args.get("employee_id", type=int)
    status    = request.args.get("status")
    date_from = request.args.get("date_from")
    date_to   = request.args.get("date_to")
    return ok(get_leave_requests(db(), employee_id=emp_id, status=status,
                                  date_from=date_from, date_to=date_to))


@bp.route("/api/leave/requests/<int:req_id>")
@login_required
@tier_required("payroll")
def api_leave_request(req_id):
    r = get_leave_request(db(), req_id)
    if not r:
        return err("Not found", 404)
    return ok(r)


@bp.route("/api/leave/requests", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_request_create():
    data = request.json or {}
    try:
        new_id = save_leave_request(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": new_id})


@bp.route("/api/leave/requests/<int:req_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_leave_request_update(req_id):
    data = request.json or {}
    data["id"] = req_id
    try:
        save_leave_request(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": req_id})


@bp.route("/api/leave/requests/<int:req_id>/approve", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_approve(req_id):
    approved_by = (request.json or {}).get("approved_by", "Web UI")
    try:
        approve_leave(db(), req_id, approved_by)
    except Exception as e:
        return err(str(e))
    return ok({})


@bp.route("/api/leave/requests/<int:req_id>/decline", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_decline(req_id):
    body = request.json or {}
    try:
        decline_leave(db(), req_id, body.get("declined_by", "Web UI"),
                      body.get("reason", ""))
    except Exception as e:
        return err(str(e))
    return ok({})


@bp.route("/api/leave/requests/<int:req_id>/cancel", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_cancel(req_id):
    try:
        cancel_leave(db(), req_id)
    except Exception as e:
        return err(str(e))
    return ok({})


@bp.route("/api/leave/balances")
@login_required
@tier_required("payroll")
def api_leave_balances():
    emp_id = request.args.get("employee_id", type=int)
    if not emp_id:
        return err("employee_id required", 400)
    return ok(get_leave_balances(db(), emp_id))



# ── Leave Types CRUD ──────────────────────────────────────────────────────────

@bp.route("/api/leave/types/<int:type_id>")
@login_required
@tier_required("payroll")
def api_leave_type(type_id):
    lt = get_leave_type(db(), type_id)
    if not lt:
        return err("Not found", 404)
    return ok(lt)


@bp.route("/api/leave/types", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_type_create():
    data = request.json or {}
    try:
        new_id = save_leave_type(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": new_id})


@bp.route("/api/leave/types/<int:type_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_leave_type_update(type_id):
    data = request.json or {}
    data["id"] = type_id
    try:
        save_leave_type(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": type_id})


@bp.route("/api/leave/types/<int:type_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_leave_type_delete(type_id):
    lt = get_leave_type(db(), type_id)
    if not lt:
        return err("Not found", 404)
    if lt.get("is_system"):
        return err("System leave types cannot be deleted", 400)
    try:
        conn = db()
        conn.execute("DELETE FROM leave_types WHERE id = ?", (type_id,))
        conn.commit()
    except Exception as e:
        return err(str(e))
    return ok({})


# ── Medical Certificates CRUD ─────────────────────────────────────────────────

@bp.route("/api/leave/certs")
@login_required
@tier_required("payroll")
def api_leave_certs():
    emp_id = request.args.get("employee_id", type=int)
    return ok(get_medical_certs(db(), employee_id=emp_id))


@bp.route("/api/leave/certs/<int:cert_id>")
@login_required
@tier_required("payroll")
def api_leave_cert(cert_id):
    conn = db()
    row = conn.execute(
        """SELECT mc.*, e.first_name || ' ' || e.last_name AS employee_name
           FROM medical_certs mc
           LEFT JOIN employees e ON e.id = mc.employee_id
           WHERE mc.id = ?""", (cert_id,)
    ).fetchone()
    if not row:
        return err("Not found", 404)
    return ok(dict(row))


def _cert_decode_file(data):
    """Decode base64 file_data from JSON payload to bytes in-place."""
    import base64 as _b64
    if data.get("file_data") and isinstance(data["file_data"], str):
        data["file_data"] = _b64.b64decode(data["file_data"])


@bp.route("/api/leave/certs", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_cert_create():
    data = request.json or {}
    _cert_decode_file(data)
    try:
        new_id = save_medical_cert(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": new_id})


@bp.route("/api/leave/certs/<int:cert_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_leave_cert_update(cert_id):
    data = request.json or {}
    data["id"] = cert_id
    _cert_decode_file(data)
    try:
        save_medical_cert(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": cert_id})


@bp.route("/api/leave/certs/<int:cert_id>/file")
@login_required
@tier_required("payroll")
def api_leave_cert_file(cert_id):
    row = db().execute(
        "SELECT file_data, file_name, mime_type FROM medical_certs WHERE id=?",
        (cert_id,)).fetchone()
    if not row or not row["file_data"]:
        return err("No file attached", 404)
    from flask import Response
    return Response(
        bytes(row["file_data"]),
        mimetype=row["mime_type"] or "application/octet-stream",
        headers={"Content-Disposition": f'attachment; filename="{row["file_name"] or "cert_file"}"'})


@bp.route("/api/leave/certs/<int:cert_id>/file", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_leave_cert_file_delete(cert_id):
    conn = db()
    conn.execute(
        "UPDATE medical_certs SET file_data=NULL, file_name=NULL, mime_type=NULL WHERE id=?",
        (cert_id,))
    conn.commit()
    return ok()


@bp.route("/api/leave/certs/<int:cert_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_leave_cert_delete(cert_id):
    try:
        delete_medical_cert(db(), cert_id)
    except Exception as e:
        return err(str(e))
    return ok({})


# ── Public Holidays CRUD ──────────────────────────────────────────────────────

@bp.route("/api/leave/holidays")
@login_required
@tier_required("payroll")
def api_leave_holidays():
    state     = request.args.get("state")
    year_from = request.args.get("year_from", type=int)
    year_to   = request.args.get("year_to",   type=int)
    return ok(get_public_holidays(db(), state=state,
                                  year_from=year_from, year_to=year_to))


@bp.route("/api/leave/holidays", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_holiday_create():
    data = request.json or {}
    try:
        new_id = save_public_holiday(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": new_id})


@bp.route("/api/leave/holidays/<int:hol_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_leave_holiday_update(hol_id):
    data = request.json or {}
    data["id"] = hol_id
    try:
        save_public_holiday(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": hol_id})


@bp.route("/api/leave/holidays/<int:hol_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_leave_holiday_delete(hol_id):
    try:
        delete_public_holiday(db(), hol_id)
    except Exception as e:
        return err(str(e))
    return ok({})


@bp.route("/api/leave/holidays/export-csv")
@login_required
@tier_required("payroll")
def api_leave_holidays_export_csv():
    import csv, io
    state     = request.args.get("state")
    year_from = request.args.get("year_from", type=int)
    year_to   = request.args.get("year_to",   type=int)
    rows = get_public_holidays(db(), state=state,
                               year_from=year_from, year_to=year_to)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["holiday_date", "state", "name"])
    for r in rows:
        w.writerow([r["holiday_date"], r["state"], r["name"]])
    output = buf.getvalue()
    from flask import Response
    return Response(
        output,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=public_holidays.csv"},
    )


@bp.route("/api/leave/holidays/import-csv", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_holidays_import_csv():
    body     = request.json or {}
    rows     = body.get("rows", [])
    overwrite = body.get("overwrite", False)
    if not rows:
        return err("No rows provided", 400)
    imported = skipped = 0
    try:
        # Fetch existing keys for duplicate detection when not overwriting
        existing_keys = set()
        if not overwrite:
            existing = get_public_holidays(db())
            existing_keys = {(r["holiday_date"], r["state"]) for r in existing}
        for row in rows:
            key = (row.get("holiday_date"), row.get("state", "NAT"))
            if not overwrite and key in existing_keys:
                skipped += 1
                continue
            save_public_holiday(db(), {
                "holiday_date": row["holiday_date"],
                "state":        row.get("state", "NAT"),
                "name":         row["name"],
            })
            imported += 1
    except Exception as e:
        return err(str(e))
    return ok({"imported": imported, "skipped": skipped})




@bp.route("/api/leave/balances/<int:employee_id>/adjust", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_adjust(employee_id):
    """Post a manual leave balance adjustment (opening, correction, purchased leave)."""
    body     = request.json or {}
    type_id  = body.get("leave_type_id")
    hours    = body.get("hours")
    adj_type = body.get("accrual_type", "manual")
    notes    = body.get("notes", "")
    if not type_id:
        return err("leave_type_id is required", 400)
    if hours is None:
        return err("hours is required", 400)
    try:
        hours = float(hours)
    except (TypeError, ValueError):
        return err("hours must be a number", 400)
    import datetime
    username = (session.get("username") or "Web UI")
    post_accrual(
        db(), employee_id, type_id,
        hours        = hours,
        accrual_date = str(datetime.date.today()),
        accrual_type = adj_type,
        notes        = notes,
        created_by   = username,
    )
    return ok({"adjusted": hours})


@bp.route("/api/leave/balances/<int:employee_id>/history")
@login_required
@tier_required("payroll")
def api_leave_history(employee_id):
    """Return accrual/deduction history for an employee (up to 200 rows)."""
    limit = int(request.args.get("limit", 200))
    rows  = get_accrual_history(db(), employee_id, limit=limit)
    return ok(rows)


@bp.route("/api/leave/outstanding-leave/pdf")
@login_required
@tier_required("payroll")
def api_outstanding_leave_pdf():
    """Download the outstanding leave balances report as a PDF."""
    import os as _os
    try:
        watermark = _get_pdf_watermark()
        pdf_path = generate_outstanding_leave_pdf(db(), watermark=watermark, footer=_get_pdf_footer())
    except ImportError as e:
        return err(str(e), 500)
    except Exception as e:
        return err(f"PDF generation failed: {e}", 500)
    filename = _os.path.basename(pdf_path)
    return send_file(pdf_path, mimetype="application/pdf",
                     as_attachment=True, download_name=filename)


@bp.route("/api/leave/outstanding-leave/csv")
@login_required
@tier_required("payroll")
def api_outstanding_leave_csv():
    """Download the outstanding leave balances as a CSV file."""
    import tempfile as _tmp, os as _os
    try:
        out = _tmp.mktemp(suffix=".csv", prefix="outstanding_leave_")
        generate_outstanding_leave_csv(db(), output_path=out)
    except Exception as e:
        return err(f"CSV generation failed: {e}", 500)
    return send_file(out, mimetype="text/csv",
                     as_attachment=True,
                     download_name="outstanding_leave_balances.csv")


# ── PAYG Tax Rates ────────────────────────────────────────────────────────────

@bp.route("/api/payroll/payg-rates")
@login_required
@tier_required("payroll")
def api_payg_rates_list():
    """List all FY years that have saved PAYG rates."""
    return ok(list_payg_rate_years(db()))


@bp.route("/api/payroll/payg-rates/<int:fy_year>")
@login_required
@tier_required("payroll")
def api_payg_rates_get(fy_year):
    """Return full rate set for a given FY year."""
    r = load_payg_rates(db(), fy_year)
    if not r:
        return err("No PAYG rates found for that year", 404)
    r["fy_year"] = fy_year
    return ok(r)


@bp.route("/api/payroll/payg-rates", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payg_rates_save():
    """Save or update a full rate set for a FY year."""
    data = request.get_json(force=True)
    try:
        save_payg_rates(
            db(),
            fy_year           = int(data["fy_year"]),
            label             = data.get("label", str(data["fy_year"])),
            brackets          = data.get("brackets", []),
            brackets_no_thresh= data.get("brackets_no_thresh", []),
            medicare          = data.get("medicare", {}),
            lito              = data.get("lito", []),
            lito_no_thresh    = data.get("lito_no_thresh", []),
            help_table        = data.get("help", []),
            sapto             = data.get("sapto", {}),
            no_tfn_rate       = float(data.get("no_tfn_rate", 0.47)),
            help_method       = data.get("help_method", "whole"),
            notes             = data.get("notes", ""),
        )
        return ok({"fy_year": data["fy_year"]})
    except Exception as e:
        return err(str(e), 400)


@bp.route("/api/payroll/payg-rates/<int:fy_year>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_payg_rates_delete(fy_year):
    """Delete a FY year's PAYG rates (revert to built-in defaults for that year)."""
    try:
        conn = get_connection(db())
        conn.execute("DELETE FROM payg_tax_rates WHERE fy_year=?", (fy_year,))
        conn.commit()
        conn.close()
        return ok({"deleted": fy_year})
    except Exception as e:
        return err(str(e), 400)


@bp.route("/api/payroll/payg-rates/calculate", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payg_rates_calculate():
    """
    Test calculator: given gross period earnings + employee flags, return
    withholding amount.  Uses DB rates if available for the requested FY year,
    otherwise falls back to built-in defaults.
    """
    data = request.get_json(force=True)
    try:
        gross      = float(data.get("gross_period", 0))
        frequency  = data.get("frequency", "Fortnightly")
        fy_year    = data.get("fy_year")
        wh = payg_for_period(
            gross_period       = gross,
            frequency          = frequency,
            has_tfn            = data.get("has_tfn", True),
            has_threshold      = data.get("has_threshold", True),
            db_path            = db() if fy_year else None,
            fy_year            = int(fy_year) if fy_year else None,
            has_study_loan     = data.get("has_study_loan", False),
            is_senior          = data.get("is_senior", False),
            senior_couple      = data.get("senior_couple", False),
            is_foreign_resident= data.get("is_foreign_resident", False),
            medicare_exemption = data.get("medicare_exemption", "none"),
        )
        periods = {"Weekly": 52, "Fortnightly": 26, "Monthly": 12}.get(frequency, 26)
        annual_gross = round(gross * periods, 2)
        annual_wh    = round(wh * periods, 2)
        return ok({
            "gross_period":  gross,
            "withholding":   wh,
            "annual_gross":  annual_gross,
            "annual_wh":     annual_wh,
            "effective_rate": round(annual_wh / annual_gross * 100, 2) if annual_gross else 0,
        })
    except Exception as e:
        return err(str(e), 400)


# ── PAYG Payment Summaries ────────────────────────────────────────────────────

@bp.route("/api/payroll/payment-summaries")
@login_required
@tier_required("payroll")
def api_payment_summaries_list():
    """
    Return PAYG Payment Summary figures for all employees in a given FY.
    Query param: fy_year (int, e.g. 2025 = FY 2024-25). Defaults to current FY.
    """
    try:
        fy_year = int(request.args.get("fy_year") or current_fy())
        rows = get_payg_summary(db(), fy_year)
        return ok(rows)
    except Exception as e:
        return err(str(e), 400)


@bp.route("/api/payroll/payment-summaries/pdf")
@login_required
@tier_required("payroll")
def api_payment_summaries_pdf():
    """
    Stream a PAYG Payment Summary PDF.
    Query params:
        fy_year     (int)  — required
        employee_id (int)  — optional; omit for bulk (all employees)
    """
    import os
    try:
        fy_year     = int(request.args.get("fy_year") or current_fy())
        employee_id = request.args.get("employee_id")
        emp_ids     = [int(employee_id)] if employee_id else None

        out_path = render_payg_summary_pdf(db(), fy_year, employee_ids=emp_ids)

        fy_label = f"{fy_year-1}-{str(fy_year)[2:]}"
        if emp_ids and len(emp_ids) == 1:
            summaries = get_payg_summary(db(), fy_year, employee_id=emp_ids[0])
            emp_name  = summaries[0]["employee_name"].replace(" ", "_") if summaries else "employee"
            filename  = f"PAYG_Summary_{emp_name}_FY{fy_label}.pdf"
        else:
            filename = f"PAYG_Summaries_FY{fy_label}.pdf"

        with open(out_path, "rb") as f:
            data = f.read()
        try:
            os.unlink(out_path)
        except Exception:
            pass

        from flask import Response
        return Response(
            data,
            mimetype="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except ValueError as e:
        return err(str(e), 404)
    except Exception as e:
        return err(str(e), 400)


@bp.route("/api/payroll/reset-ytd", methods=["POST"])
@login_required
@tier_required("payroll")
def api_reset_ytd():
    """Reset all employee YTD accumulators to zero. Run once at 1 July each year."""
    try:
        reset_ytd(db())
        return ok()
    except Exception as e:
        return err(str(e), 400)
