from flask import Blueprint, request
from web.shared import db, ok, err, login_required, current_user
from core.expense_claims import (
    get_expense_claims, get_expense_claim, save_expense_claim,
    post_expense_claim, void_expense_claim, delete_expense_claim,
    EXPENSE_CATEGORIES,
)

bp = Blueprint('expense_claims', __name__)


@bp.route("/api/expense-claims")
@login_required
def api_expense_claims_list():
    status = request.args.get('status') or None
    return ok(get_expense_claims(db(), status=status))


@bp.route("/api/expense-claims/<int:cid>")
@login_required
def api_expense_claim_get(cid):
    c = get_expense_claim(db(), cid)
    return ok(c) if c else err("Not found", 404)


@bp.route("/api/expense-claims", methods=["POST"])
@login_required
def api_expense_claim_create():
    data = request.get_json() or {}
    data['created_by'] = current_user().get('username')
    try:
        cid = save_expense_claim(db(), data)
        return ok({"id": cid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/expense-claims/<int:cid>", methods=["PUT"])
@login_required
def api_expense_claim_update(cid):
    data = request.get_json() or {}
    data['id'] = cid
    try:
        save_expense_claim(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/expense-claims/<int:cid>/post", methods=["POST"])
@login_required
def api_expense_claim_post(cid):
    try:
        jid = post_expense_claim(db(), cid)
        return ok({"journal_id": jid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/expense-claims/<int:cid>/void", methods=["POST"])
@login_required
def api_expense_claim_void(cid):
    try:
        void_expense_claim(db(), cid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/expense-claims/<int:cid>", methods=["DELETE"])
@login_required
def api_expense_claim_delete(cid):
    try:
        delete_expense_claim(db(), cid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/expense-claims/categories")
@login_required
def api_expense_categories():
    return ok(EXPENSE_CATEGORIES)
