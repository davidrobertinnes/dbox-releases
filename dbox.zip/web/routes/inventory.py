import io
import os
from datetime import date
from flask import Blueprint, request, send_file

from web.shared import db, ok, err, login_required
from core.items import get_items, get_item, save_item, delete_item
from core.inventory import (
    get_inventory_items, get_inventory_item, get_stock_movements, get_stock_summary,
    get_inventory_analytics, adjust_stock, stock_valuation_report,
    save_inventory_settings, post_stock_movement, get_low_stock_items,
)
from core.promotions import (
    get_all_promotions_with_status, get_promotions,
    save_promotion, delete_promotion,
)
from core.database import get_connection

bp = Blueprint('inventory', __name__)


# ── Items ─────────────────────────────────────────────────────────────────────

@bp.route("/api/items")
@login_required
def api_items():
    return ok(get_items(db(), active_only=True))


@bp.route("/api/items/<int:iid>/stock")
@login_required
def api_item_stock(iid):
    item = get_item(db(), iid)
    if not item:
        return err("Not found", 404)
    return ok({"qty_on_hand": item.get("qty_on_hand", 0),
               "is_inventoried": bool(item.get("is_inventoried"))})


@bp.route("/api/items/all")
@login_required
def api_items_all():
    return ok(get_items(db(), active_only=False))


@bp.route("/api/items/<int:iid>")
@login_required
def api_item(iid):
    item = get_item(db(), iid)
    if not item:
        return err("Not found", 404)
    return ok(dict(item))


@bp.route("/api/items", methods=["POST"])
@login_required
def api_item_save():
    data = request.get_json() or {}
    try:
        iid = save_item(db(), data)
        return ok({"id": iid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/items/<int:iid>", methods=["PUT"])
@login_required
def api_item_update(iid):
    data = request.get_json() or {}
    data["id"] = iid
    try:
        save_item(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/items/<int:iid>", methods=["DELETE"])
@login_required
def api_item_delete(iid):
    try:
        delete_item(db(), iid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── Inventory ──────────────────────────────────────────────────────────────────

@bp.route("/api/inventory/summary")
@login_required
def api_inventory_summary():
    return ok(get_stock_summary(db()))


@bp.route("/api/inventory/low-stock")
@login_required
def api_inventory_low_stock():
    return ok(get_low_stock_items(db()))


@bp.route("/api/inventory/items")
@login_required
def api_inventory_items():
    return ok(get_inventory_items(db()))


@bp.route("/api/inventory/analytics")
@login_required
def api_inventory_analytics():
    months = request.args.get("months", 6, type=int)
    result = get_inventory_analytics(db(), months=months)
    return ok({str(k): v for k, v in result.items()})


@bp.route("/api/inventory/movements")
@login_required
def api_inventory_movements():
    item_id  = request.args.get("item_id", type=int)
    date_from = request.args.get("from")
    date_to   = request.args.get("to")
    mov_type  = request.args.get("type")
    limit     = request.args.get("limit", type=int)
    rows = get_stock_movements(db(),
                               item_id=item_id,
                               date_from=date_from,
                               date_to=date_to,
                               movement_type=mov_type)
    if limit:
        rows = rows[:limit]
    return ok(rows)


@bp.route("/api/inventory/adjust", methods=["POST"])
@login_required
def api_inventory_adjust():
    data = request.get_json() or {}
    item_id = data.get("item_id")
    new_qty = data.get("new_qty")
    if item_id is None or new_qty is None:
        return err("item_id and new_qty required")
    try:
        mov_id = adjust_stock(
            db(),
            item_id=int(item_id),
            new_qty=float(new_qty),
            adjustment_date=data.get("adjustment_date"),
            reason=data.get("reason", "Stock count correction"),
        )
        return ok({"movement_id": mov_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/inventory/valuation/pdf")
@login_required
def api_inventory_valuation_pdf():
    from core.inventory_pdf import render_stock_valuation_pdf
    report = stock_valuation_report(db())
    buf = render_stock_valuation_pdf(report, db_path=db())
    return send_file(io.BytesIO(buf), mimetype="application/pdf",
                     as_attachment=True,
                     download_name=f"stock-valuation-{report['as_at']}.pdf")


@bp.route("/api/inventory/item/<int:iid>")
@login_required
def api_inventory_item_get(iid):
    item = get_inventory_item(db(), iid)
    if not item:
        return err("Item not found", 404)
    return ok(dict(item))


@bp.route("/api/inventory/item/<int:iid>/settings", methods=["PUT"])
@login_required
def api_inventory_item_settings_put(iid):
    data = request.get_json() or {}
    try:
        is_livestock = int(bool(data.get("is_livestock")))
        stock_acc_id = int(data["stock_account_id"]) if data.get("stock_account_id") else None
        cogs_acc_id  = int(data["cogs_account_id"])  if data.get("cogs_account_id")  else None

        valid_cats = {"cattle_horses_deer", "pigs", "emus", "sheep_goats", "poultry"}
        valid_ni   = {"prescribed", "actual"}
        valid_pu   = {"market", "cost"}
        save_inventory_settings(db(), iid, {
            "is_inventoried":      int(bool(data.get("is_inventoried"))),
            "is_livestock":        is_livestock,
            "livestock_category":  data.get("livestock_category") if data.get("livestock_category") in valid_cats else None,
            "livestock_ni_method": data.get("livestock_ni_method") if data.get("livestock_ni_method") in valid_ni else "prescribed",
            "livestock_pu_method": data.get("livestock_pu_method") if data.get("livestock_pu_method") in valid_pu else "market",
            "reorder_level":       float(data.get("reorder_level") or 0),
            "reorder_qty":         float(data.get("reorder_qty") or 0),
            "unit_cost":           float(data.get("unit_cost") or 0),
            "location":            data.get("location") or None,
            "barcode":             data.get("barcode") or None,
            "stock_account_id":    stock_acc_id,
            "cogs_account_id":     cogs_acc_id,
        })
        pricing_mode = data.get("pricing_mode", "fixed")
        markup_value = float(data.get("markup_value") or 0)
        unit_price   = float(data.get("unit_price") or 0)
        conn = get_connection(db())
        conn.execute(
            "UPDATE items SET unit_price=?, pricing_mode=?, markup_value=? WHERE id=?",
            (round(unit_price, 4), pricing_mode, markup_value, iid))
        conn.commit()
        conn.close()
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/inventory/movement", methods=["POST"])
@login_required
def api_inventory_movement_post():
    data = request.get_json() or {}
    item_id       = data.get("item_id")
    movement_type = (data.get("movement_type") or "").upper()
    allowed = {"SALE", "WRITE_OFF", "RETURN_IN", "RETURN_OUT", "PURCHASE",
               "NATURAL_INCREASE", "DEATH", "PRIVATE_USE"}
    if not item_id or movement_type not in allowed:
        return err("item_id required and movement_type must be one of: " + ", ".join(sorted(allowed)))
    try:
        qty = float(data.get("qty") or 0)
        if qty <= 0:
            return err("qty must be positive")
        source_doc_type = data.get("source_doc_type") or None
        source_doc_id   = int(data["source_doc_id"]) if data.get("source_doc_id") else None
        if movement_type == "SALE":
            item_row = get_item(db(), int(item_id))
            if item_row and item_row.get("is_livestock") and not source_doc_id:
                return err("Livestock sales must be linked to an invoice (source_doc_id required)")
        mov_id = post_stock_movement(
            db(),
            item_id=int(item_id),
            movement_type=movement_type,
            movement_date=data.get("movement_date") or str(date.today()),
            qty=qty,
            unit_cost=float(data["unit_cost"]) if data.get("unit_cost") not in (None, "") else None,
            unit_price=float(data["unit_price"]) if data.get("unit_price") not in (None, "") else None,
            reference=data.get("reference") or "",
            source_doc_type=source_doc_type,
            source_doc_id=source_doc_id,
            notes=data.get("notes") or "",
        )
        return ok({"id": mov_id})
    except Exception as e:
        return err(str(e))


# ── Promotions ────────────────────────────────────────────────────────────────

@bp.route("/api/promotions")
@login_required
def api_promotions_list():
    item_id = request.args.get("item_id", type=int)
    if item_id:
        rows = get_promotions(db(), item_id=item_id)
        import datetime
        today = str(datetime.date.today())
        for r in rows:
            if not r["is_active"]:
                r["_status"] = "Disabled"
            elif r["end_date"] < today:
                r["_status"] = "Expired"
            elif r["start_date"] > today:
                r["_status"] = "Scheduled"
            else:
                r["_status"] = "Active"
            std = float(r.get("standard_price") or 0)
            prc = float(r.get("promo_price") or 0)
            r["_discount_pct"] = round((std - prc) / std * 100, 1) if std > 0 else 0.0
        return ok(rows)
    return ok(get_all_promotions_with_status(db()))


@bp.route("/api/promotions", methods=["POST"])
@login_required
def api_promotions_save():
    from web.shared import current_user
    data = request.get_json() or {}
    data.setdefault("created_by", current_user().get("username"))
    try:
        pid = save_promotion(db(), data)
        return ok({"id": pid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/promotions/<int:pid>", methods=["PUT"])
@login_required
def api_promotions_update(pid):
    data = request.get_json() or {}
    data["id"] = pid
    try:
        save_promotion(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/promotions/<int:pid>", methods=["DELETE"])
@login_required
def api_promotions_delete(pid):
    try:
        delete_promotion(db(), pid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/inventory/stocktake", methods=["POST"])
@login_required
def api_inventory_stocktake():
    data = request.get_json() or {}
    count_date = data.get("count_date") or str(date.today())
    lines = data.get("lines", [])
    if not lines:
        return err("No items provided")
    posted = 0
    errors = []
    for line in lines:
        item_id = line.get("item_id")
        new_qty = line.get("new_qty")
        if item_id is None or new_qty is None:
            continue
        try:
            adjust_stock(db(), int(item_id), float(new_qty),
                         adjustment_date=count_date,
                         reason=f"Stocktake {count_date}")
            posted += 1
        except Exception as e:
            errors.append({"item_id": item_id, "error": str(e)})
    return ok({"posted": posted, "errors": errors})
