# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from datetime import date
from flask import Blueprint, request

from web.shared import db, ok, err, login_required, current_user
from core.ledger import get_payments, get_payment, record_payment, void_payment, amend_payment
from core.database import get_connection
from core.budget import audit

bp = Blueprint('payments', __name__)


@bp.route("/api/payments")
@login_required
def api_payments():
    return ok([dict(p) for p in get_payments(db())])


@bp.route("/api/payments/open-items")
@login_required
def api_payments_open_items():
    """Return unpaid invoices or bills for a contact, for allocation picker.
    Defined BEFORE /api/payments/<int:pid> so Flask matches it first."""
    contact_id = request.args.get("contact_id", type=int)
    pmt_type   = request.args.get("type", "Receipt")
    conn = get_connection(db())
    if pmt_type == "Receipt":
        rows = conn.execute("""
            SELECT id, invoice_number AS number, due_date,
                   total - COALESCE(amount_paid,0) AS balance
            FROM invoices
            WHERE contact_id=? AND status NOT IN ('Paid','Void')
              AND total - COALESCE(amount_paid,0) > 0.005
            ORDER BY due_date""", (contact_id,)).fetchall() if contact_id else []
    else:
        rows = conn.execute("""
            SELECT id, bill_number AS number, due_date,
                   total - COALESCE(amount_paid,0) AS balance
            FROM bills
            WHERE contact_id=? AND status NOT IN ('Paid','Void')
              AND total - COALESCE(amount_paid,0) > 0.005
            ORDER BY due_date""", (contact_id,)).fetchall() if contact_id else []
    conn.close()
    return ok([dict(r) for r in rows])


@bp.route("/api/payments/<int:pid>")
@login_required
def api_payment(pid):
    data = get_payment(db(), pid)
    if not data:
        return err("Not found", 404)
    return ok({"payment": dict(data["payment"]),
               "allocations": [dict(a) for a in data["allocations"]]})


@bp.route("/api/payments", methods=["POST"])
@login_required
def api_payment_new():
    data = request.get_json() or {}
    try:
        pmt_data = {
            "payment_type":       data.get("payment_type", "Receipt"),
            "contact_id":         data.get("contact_id"),
            "payment_date":       data.get("payment_date", str(date.today())),
            "amount":             float(data.get("amount", 0)),
            "bank_account_id":    data.get("bank_account_id"),
            "payment_method":     data.get("payment_method", "EFT"),
            "reference":          data.get("reference", ""),
            "description":        data.get("description", ""),
            "expense_account_id": data.get("expense_account_id"),
            "tax_code":           data.get("tax_code", "N-T"),
        }
        allocations = data.get("allocations", [])
        pid = record_payment(db(), pmt_data, allocations)
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "NewPayment", "payments", pid,
              f"{pmt_data['payment_type']} amount={pmt_data['amount']}")
        return ok({"id": pid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/payments/<int:pid>", methods=["PUT"])
@login_required
def api_payment_amend(pid):
    data = request.get_json() or {}
    try:
        new_data = {
            "payment_type":       data.get("payment_type", "Receipt"),
            "contact_id":         data.get("contact_id"),
            "payment_date":       data.get("payment_date", str(date.today())),
            "amount":             float(data.get("amount", 0)),
            "bank_account_id":    data.get("bank_account_id"),
            "payment_method":     data.get("payment_method", "EFT"),
            "reference":          data.get("reference", ""),
            "description":        data.get("description", ""),
            "expense_account_id": data.get("expense_account_id"),
            "tax_code":           data.get("tax_code", "N-T"),
        }
        allocations = data.get("allocations", [])
        new_id = amend_payment(db(), pid, new_data, allocations)
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "AmendPayment", "payments", pid,
              f"amended → new id={new_id}")
        return ok({"id": new_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/payments/<int:pid>/void", methods=["POST"])
@login_required
def api_payment_void(pid):
    try:
        void_payment(db(), pid)
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "VoidPayment", "payments", pid, f"Payment {pid} voided via web UI")
        return ok()
    except Exception as e:
        return err(str(e))
