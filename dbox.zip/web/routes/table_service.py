# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from flask import Blueprint, request
from web.shared import db, ok, err, login_required, tier_required

bp = Blueprint('table_service', __name__)


# ── Zones ─────────────────────────────────────────────────────────────────────

@bp.route("/api/ts/zones")
@login_required
@tier_required("pos")
def api_ts_zones_get():
    from core.table_service import get_zones
    return ok(get_zones(db()))


@bp.route("/api/ts/zones", methods=["POST"])
@login_required
@tier_required("pos")
def api_ts_zones_post():
    from core.table_service import save_zone
    data = request.get_json() or {}
    if not data.get("name", "").strip():
        return err("Zone name is required", 400)
    zone_id = save_zone(db(), data)
    return ok({"id": zone_id})


@bp.route("/api/ts/zones/<int:zone_id>", methods=["DELETE"])
@login_required
@tier_required("pos")
def api_ts_zones_delete(zone_id):
    from core.table_service import delete_zone
    delete_zone(db(), zone_id)
    return ok()


# ── Tables ────────────────────────────────────────────────────────────────────

@bp.route("/api/ts/tables")
@login_required
@tier_required("pos")
def api_ts_tables_get():
    from core.table_service import get_tables
    active_only = request.args.get("all") != "1"
    return ok(get_tables(db(), active_only=active_only))


@bp.route("/api/ts/tables", methods=["POST"])
@login_required
@tier_required("pos")
def api_ts_tables_post():
    from core.table_service import save_table
    data = request.get_json() or {}
    if not data.get("name", "").strip():
        return err("Table name is required", 400)
    table_id = save_table(db(), data)
    return ok({"id": table_id})


@bp.route("/api/ts/tables/<int:table_id>", methods=["DELETE"])
@login_required
@tier_required("pos")
def api_ts_tables_delete(table_id):
    from core.table_service import delete_table
    try:
        delete_table(db(), table_id)
        return ok()
    except ValueError as e:
        msg = str(e)
        if "deactivated instead" in msg:
            # Was deactivated, not deleted — still a success from the UI's perspective
            return ok({"warning": msg})
        return err(msg, 400)


# ── Tabs ──────────────────────────────────────────────────────────────────────

@bp.route("/api/ts/tabs/open")
@login_required
@tier_required("pos")
def api_ts_tabs_open():
    from core.table_service import get_open_tabs
    return ok(get_open_tabs(db()))


@bp.route("/api/ts/tabs", methods=["POST"])
@login_required
@tier_required("pos")
def api_ts_tabs_post():
    from core.table_service import open_tab
    data = request.get_json() or {}
    if not data.get("table_id"):
        return err("table_id is required", 400)
    try:
        tab = open_tab(
            db(),
            table_id=int(data["table_id"]),
            session_id=data.get("session_id"),
            contact_id=data.get("contact_id"),
            opened_by_user_id=data.get("opened_by_user_id"),
            opened_by_name=data.get("opened_by_name"),
            notes=data.get("notes", ""),
        )
        return ok(tab)
    except ValueError as e:
        return err(str(e), 400)


@bp.route("/api/ts/tabs/<int:tab_id>")
@login_required
@tier_required("pos")
def api_ts_tab_get(tab_id):
    from core.table_service import get_tab
    try:
        return ok(get_tab(db(), tab_id))
    except ValueError as e:
        return err(str(e), 404)


@bp.route("/api/ts/tabs/<int:tab_id>", methods=["PATCH"])
@login_required
@tier_required("pos")
def api_ts_tab_patch(tab_id):
    from core.table_service import update_tab
    data = request.get_json() or {}
    update_tab(db(), tab_id, data)
    return ok()


@bp.route("/api/ts/tabs/<int:tab_id>/void", methods=["POST"])
@login_required
@tier_required("pos")
def api_ts_tab_void(tab_id):
    from core.table_service import void_tab
    try:
        void_tab(db(), tab_id)
        return ok()
    except ValueError as e:
        return err(str(e), 400)


@bp.route("/api/ts/tabs/<int:tab_id>/settle", methods=["POST"])
@login_required
@tier_required("pos")
def api_ts_tab_settle(tab_id):
    from core.table_service import settle_tab
    data = request.get_json() or {}
    try:
        result = settle_tab(
            db(),
            tab_id=tab_id,
            tender=data.get("tender", "cash"),
            tendered_amount=data.get("tendered"),
            terminal_tx_id=data.get("terminal_tx_id"),
            terminal_provider=data.get("terminal_provider"),
            split_tenders=data.get("split_tenders"),
            basket_discount=data.get("basket_discount", 0.0),
        )
        return ok(result)
    except ValueError as e:
        return err(str(e), 400)


# ── Tab Items ─────────────────────────────────────────────────────────────────

@bp.route("/api/ts/tabs/<int:tab_id>/items", methods=["POST"])
@login_required
@tier_required("pos")
def api_ts_tab_items_post(tab_id):
    from core.table_service import add_tab_items
    data = request.get_json() or {}
    lines = data.get("lines", [])
    if not lines:
        return err("No items provided", 400)
    try:
        ids = add_tab_items(db(), tab_id, lines, fire_kitchen=data.get("fire_kitchen", True))
        return ok({"inserted": ids})
    except ValueError as e:
        return err(str(e), 400)


@bp.route("/api/ts/tab-items/<int:item_id>", methods=["DELETE"])
@login_required
@tier_required("pos")
def api_ts_tab_item_delete(item_id):
    from core.table_service import remove_tab_item
    try:
        remove_tab_item(db(), item_id)
        return ok()
    except ValueError as e:
        return err(str(e), 400)


@bp.route("/api/ts/tab-items/<int:item_id>", methods=["PATCH"])
@login_required
@tier_required("pos")
def api_ts_tab_item_patch(item_id):
    from core.table_service import update_tab_item_qty
    data = request.get_json() or {}
    try:
        update_tab_item_qty(db(), item_id, float(data.get("qty", 0)))
        return ok()
    except ValueError as e:
        return err(str(e), 400)


@bp.route("/api/ts/tabs/<int:tab_id>/fire-kitchen", methods=["POST"])
@login_required
@tier_required("pos")
def api_ts_fire_kitchen(tab_id):
    from core.table_service import fire_kitchen_docket
    try:
        success, msg = fire_kitchen_docket(db(), tab_id)
    except Exception as e:
        return err(str(e), 500)
    if success:
        return ok({"message": msg})
    return err(msg, 400)


@bp.route("/api/ts/tabs/<int:tab_id>/send-to-register", methods=["POST"])
@login_required
@tier_required("pos")
def api_ts_send_to_register(tab_id):
    from core.table_service import send_tab_to_register
    data = request.get_json() or {}
    try:
        cart_id = send_tab_to_register(db(), tab_id, session_id=data.get("session_id"))
        return ok({"cart_id": cart_id})
    except ValueError as e:
        return err(str(e), 400)


@bp.route("/api/ts/tabs/<int:tab_id>/recall", methods=["POST"])
@login_required
@tier_required("pos")
def api_ts_recall(tab_id):
    from core.table_service import recall_tab_from_register
    try:
        recall_tab_from_register(db(), tab_id)
        return ok()
    except ValueError as e:
        return err(str(e), 400)


@bp.route("/api/ts/tabs/<int:tab_id>/confirm-kitchen", methods=["POST"])
@login_required
@tier_required("pos")
def api_ts_confirm_kitchen(tab_id):
    from core.table_service import mark_kitchen_sent
    count = mark_kitchen_sent(db(), tab_id)
    return ok({"count": count})


@bp.route("/api/ts/tabs/<int:tab_id>/mark-settled", methods=["POST"])
@login_required
@tier_required("pos")
def api_ts_mark_settled(tab_id):
    from core.table_service import mark_tab_settled
    mark_tab_settled(db(), tab_id)
    return ok()


# ── Parked Carts ──────────────────────────────────────────────────────────────

@bp.route("/api/ts/parked")
@login_required
@tier_required("pos")
def api_ts_parked_get():
    from core.table_service import get_parked_carts
    session_id = request.args.get("session_id")
    return ok(get_parked_carts(db(), session_id=int(session_id) if session_id else None))


@bp.route("/api/ts/parked", methods=["POST"])
@login_required
@tier_required("pos")
def api_ts_parked_post():
    from core.table_service import park_cart
    data = request.get_json() or {}
    cart_id = park_cart(db(), data.get("session_id"), data.get("label", ""), data.get("cart_data", {}))
    return ok({"id": cart_id})


@bp.route("/api/ts/parked/<int:cart_id>", methods=["DELETE"])
@login_required
@tier_required("pos")
def api_ts_parked_delete(cart_id):
    from core.table_service import delete_parked_cart
    delete_parked_cart(db(), cart_id)
    return ok()
