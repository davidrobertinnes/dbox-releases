# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import os
import sys
import json
import threading as _threading
from flask import Blueprint, request, send_file

from web.shared import db, ok, err, login_required

bp = Blueprint('backup', __name__)

_PREFS_PATH = os.path.join(os.path.expanduser("~"), "dbox_prefs.json")


def _load_prefs():
    try:
        if os.path.exists(_PREFS_PATH):
            with open(_PREFS_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _save_prefs(data):
    with open(_PREFS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def _default_backup_dir():
    docs = os.path.join(os.path.expanduser("~"), "Documents")
    base = docs if os.path.isdir(docs) else os.path.expanduser("~")
    return os.path.join(base, "Dogbox Backups")


def _auto_on(p):
    """Auto-backup is on unless it's been turned off (on by default since 2.7.3)."""
    return p.get("auto_backup_enabled", True) is not False


def _backup_dir(p):
    """The chosen backup folder, or Documents/Dogbox Backups."""
    return (p.get("auto_backup_dir") or "").strip() or _default_backup_dir()


def _safe_copy(db_path, dest):
    """Copy the company file with SQLite's backup function: complete and consistent even
    while Dogbox is using it (a plain file copy can miss changes still in the -wal file,
    or catch the file half-written). Written to a .part file first, then renamed."""
    import sqlite3
    tmp = dest + ".part"
    src = sqlite3.connect(db_path, timeout=30)
    try:
        dst = sqlite3.connect(tmp)
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()
    os.replace(tmp, dest)


def _ro_uri(path):
    """A read-only SQLite URI for a file (handles Windows drive letters and spaces)."""
    import pathlib
    return pathlib.Path(path).resolve().as_uri() + "?mode=ro"


def _get_db_path_for_worker():
    """Return the current DB path without requiring a Flask request context."""
    try:
        import web.server as _wsrv
        with _wsrv.app.app_context():
            return _wsrv.app.config.get('DB_PATH')
    except Exception:
        return None


def _auto_backup_worker():
    import time, shutil, datetime, glob as _glob
    while True:
        time.sleep(300)
        try:
            db_path = _get_db_path_for_worker()
            if not db_path or not os.path.exists(db_path):
                continue
            p = _load_prefs()
            if not _auto_on(p):
                continue
            bdir = _backup_dir(p)
            os.makedirs(bdir, exist_ok=True)
            if not os.path.isdir(bdir):
                continue
            interval_hours = float(p.get("auto_backup_interval", 1))
            name = os.path.splitext(os.path.basename(db_path))[0]
            pattern = os.path.join(bdir, f"{name}_auto_*.abk")
            existing = sorted(_glob.glob(pattern), key=os.path.getmtime)
            now = datetime.datetime.now().timestamp()
            if existing:
                elapsed_hours = (now - os.path.getmtime(existing[-1])) / 3600
                if elapsed_hours < interval_hours:
                    continue
            ts   = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            dest = os.path.join(bdir, f"{name}_auto_{ts}.abk")
            _safe_copy(db_path, dest)
            existing = sorted(_glob.glob(pattern))
            keep = max(1, int(p.get("auto_backup_keep", 10)))
            while len(existing) > keep:
                try:
                    os.remove(existing.pop(0))
                except Exception:
                    break
        except Exception:
            pass


_threading.Thread(target=_auto_backup_worker, daemon=True).start()


@bp.route("/api/backup/status")
@login_required
def api_backup_status():
    import glob as _glob, datetime as _dt
    db_path = db()
    p = _load_prefs()
    auto_on = _auto_on(p)
    bdir    = _backup_dir(p)

    if not bdir or not os.path.isdir(bdir):
        return ok({"warn": True, "reason": "never", "last": None, "auto": auto_on})

    name     = os.path.splitext(os.path.basename(db_path or "company"))[0]
    all_abk  = _glob.glob(os.path.join(bdir, f"{name}_*.abk"))
    files    = sorted(all_abk, key=os.path.getmtime, reverse=True)
    if not files:
        return ok({"warn": True, "reason": "never", "last": None, "auto": auto_on})

    try:
        mtime    = os.path.getmtime(files[0])
        age_days = (_dt.datetime.now().timestamp() - mtime) / 86400
        last_str = _dt.datetime.fromtimestamp(mtime).strftime("%d %b %Y")
        warn     = age_days > 7
        return ok({"warn": warn, "reason": "stale" if warn else "ok",
                   "last": last_str, "age_days": int(age_days), "auto": auto_on})
    except Exception:
        return ok({"warn": False})


@bp.route("/api/backup/settings")
@login_required
def api_backup_settings_get():
    p = _load_prefs()
    return ok({
        "enabled":        _auto_on(p),
        "directory":      p.get("auto_backup_dir",      ""),
        "interval_hours": p.get("auto_backup_interval", 1),
        "keep_count":     p.get("auto_backup_keep",     10),
        "db_name":        os.path.basename(db() or ""),
        "suggested_dir":  _default_backup_dir(),
    })


@bp.route("/api/backup/settings", methods=["POST"])
@login_required
def api_backup_settings_post():
    d = request.get_json(force=True) or {}
    p = _load_prefs()
    p["auto_backup_enabled"]  = bool(d.get("enabled", False))
    p["auto_backup_dir"]      = str(d.get("directory", "")).strip()
    p["auto_backup_interval"] = float(d.get("interval_hours", 1))
    p["auto_backup_keep"]     = int(d.get("keep_count", 10))
    try:
        _save_prefs(p)
    except Exception as e:
        return err(str(e))
    return ok()


@bp.route("/api/backup/browse-dir")
@login_required
def api_backup_browse_dir():
    import subprocess
    _dialog = (
        "import tkinter as tk, tkinter.filedialog as fd, sys\n"
        "root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True)\n"
        "p = fd.askdirectory(title='Select Backup Folder')\n"
        "root.destroy()\n"
        "print(p)\n"
    )
    try:
        r = subprocess.run(
            [sys.executable, "-c", _dialog],
            capture_output=True, text=True, timeout=120,
        )
        chosen = r.stdout.strip()
        if not chosen:
            return ok({"path": None})
        return ok({"path": os.path.normpath(chosen)})
    except Exception as e:
        return err(str(e))


@bp.route("/api/backup/now", methods=["POST"])
@login_required
def api_backup_now():
    import shutil, datetime, glob
    db_path = db()
    if not db_path or not os.path.exists(db_path):
        return err("No company file open")
    p    = _load_prefs()
    body = request.get_json(silent=True) or {}
    bdir = (body.get("directory") or "").strip() or _backup_dir(p)
    os.makedirs(bdir, exist_ok=True)
    if not os.path.isdir(bdir):
        return err(f"Could not create backup directory: {bdir}")
    ts   = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    name = os.path.splitext(os.path.basename(db_path))[0]
    dest = os.path.join(bdir, f"{name}_backup_{ts}.abk")
    try:
        _safe_copy(db_path, dest)
    except Exception as e:
        return err(str(e))
    keep     = max(1, int(p.get("auto_backup_keep", 10)))
    pattern  = os.path.join(bdir, f"{name}_backup_*.abk")
    existing = sorted(glob.glob(pattern))
    while len(existing) > keep:
        try:
            os.remove(existing.pop(0))
        except Exception:
            break
    return ok({"filename": os.path.basename(dest)})


@bp.route("/api/backup/list")
@login_required
def api_backup_list():
    import glob, datetime
    db_path = db()
    p    = _load_prefs()
    bdir = _backup_dir(p)
    if not os.path.isdir(bdir):
        return ok([])
    name    = os.path.splitext(os.path.basename(db_path or "company"))[0]
    pattern = os.path.join(bdir, f"{name}_*.abk")
    files   = sorted(glob.glob(pattern), key=os.path.getmtime, reverse=True)
    result  = []
    for f in files[:50]:
        try:
            stat = os.stat(f)
            result.append({
                "filename": os.path.basename(f),
                "size":     stat.st_size,
                "modified": datetime.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
            })
        except Exception:
            pass
    return ok(result)


@bp.route("/api/backup/download")
@login_required
def api_backup_download():
    import datetime
    db_path = db()
    if not db_path or not os.path.exists(db_path):
        return err("No company file open")
    ts      = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    name    = os.path.splitext(os.path.basename(db_path))[0]
    dl_name = f"{name}_backup_{ts}.abk"
    import tempfile
    tmp = os.path.join(tempfile.mkdtemp(prefix="dbox-dl-"), dl_name)
    _safe_copy(db_path, tmp)
    return send_file(tmp, as_attachment=True, download_name=dl_name)


@bp.route("/api/backup/pick-file")
@login_required
def api_backup_pick_file():
    import subprocess
    p    = _load_prefs()
    bdir = _backup_dir(p)
    _dialog = (
        "import tkinter as tk, tkinter.filedialog as fd, sys\n"
        f"idir = {repr(bdir)}\n"
        "root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True)\n"
        "p = fd.askopenfilename(\n"
        "    title='Select Backup to Restore',\n"
        "    initialdir=idir,\n"
        "    filetypes=[('dbox Backup','*.abk'),('dbox File','*.dbox'),('All files','*.*')],\n"
        ")\n"
        "root.destroy()\n"
        "print(p)\n"
    )
    try:
        r = subprocess.run(
            [sys.executable, "-c", _dialog],
            capture_output=True, text=True, timeout=120,
        )
        chosen = r.stdout.strip()
        if not chosen:
            return ok({"path": None})
        return ok({"path": os.path.normpath(chosen)})
    except Exception as e:
        return err(str(e))


@bp.route("/api/backup/restore", methods=["POST"])
@login_required
def api_backup_restore():
    import sqlite3, datetime
    d       = request.get_json(force=True) or {}
    src     = d.get("path", "").strip()
    db_path = db()
    if not src:
        return err("No backup file specified")
    if not os.path.exists(src):
        return err(f"File not found: {src}")
    if not db_path:
        return err("No company file open")
    # Check it's a sound Dogbox company file before touching anything
    try:
        chk = sqlite3.connect(_ro_uri(src), uri=True)
        try:
            ok_db = chk.execute("PRAGMA quick_check").fetchone()[0] == "ok"
            has_company = chk.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='company'").fetchone()
        finally:
            chk.close()
    except sqlite3.Error:
        ok_db, has_company = False, None
    if not ok_db or not has_company:
        return err("That file isn't a Dogbox company file or backup, or it's damaged. Nothing was changed.")
    # Keep the current file first, in case the wrong backup was chosen
    try:
        bdir = _backup_dir(_load_prefs())
        os.makedirs(bdir, exist_ok=True)
        ts   = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        name = os.path.splitext(os.path.basename(db_path))[0]
        _safe_copy(db_path, os.path.join(bdir, f"{name}_before_restore_{ts}.abk"))
    except Exception as e:
        return err(f"Couldn't save a copy of the current file first, so nothing was restored: {e}")
    # Write the backup into the open file through SQLite, so its journal stays consistent
    try:
        source = sqlite3.connect(_ro_uri(src), uri=True)
        try:
            target = sqlite3.connect(db_path, timeout=30)
            try:
                source.backup(target)
            finally:
                target.close()
        finally:
            source.close()
    except Exception as e:
        return err(str(e))
    return ok()


# ── General settings ──────────────────────────────────────────────────────────

@bp.route("/api/general/settings")
@login_required
def api_general_settings_get():
    p = _load_prefs()
    docs = os.path.join(os.path.expanduser("~"), "Documents")
    suggested = docs if os.path.isdir(docs) else os.path.expanduser("~")
    return ok({
        "default_file_dir": p.get("default_file_dir", ""),
        "suggested_dir":    suggested,
    })


@bp.route("/api/general/settings", methods=["POST"])
@login_required
def api_general_settings_post():
    d = request.get_json(force=True) or {}
    p = _load_prefs()
    p["default_file_dir"] = str(d.get("default_file_dir", "")).strip()
    try:
        _save_prefs(p)
    except Exception as e:
        return err(str(e))
    return ok()


@bp.route("/api/general/browse-dir")
@login_required
def api_general_browse_dir():
    import subprocess
    p    = _load_prefs()
    idir = p.get("default_file_dir", "").strip()
    if not idir or not os.path.isdir(idir):
        docs = os.path.join(os.path.expanduser("~"), "Documents")
        idir = docs if os.path.isdir(docs) else os.path.expanduser("~")
    _dialog = (
        "import tkinter as tk, tkinter.filedialog as fd\n"
        f"idir = {repr(idir)}\n"
        "root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True)\n"
        "p = fd.askdirectory(title='Select Default File Folder', initialdir=idir)\n"
        "root.destroy()\n"
        "print(p)\n"
    )
    try:
        r = subprocess.run(
            [sys.executable, "-c", _dialog],
            capture_output=True, text=True, timeout=120,
        )
        chosen = r.stdout.strip()
        if not chosen:
            return ok({"path": None})
        return ok({"path": os.path.normpath(chosen)})
    except Exception as e:
        return err(str(e))
