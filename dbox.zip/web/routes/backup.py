import os
import sys
import json
import threading as _threading
from flask import Blueprint, request, send_file

from web.shared import db, ok, err, login_required

bp = Blueprint('backup', __name__)

_PREFS_PATH = os.path.join(os.path.expanduser("~"), "dbox_prefs.json")


def _load_prefs():
    try:
        if os.path.exists(_PREFS_PATH):
            with open(_PREFS_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _save_prefs(data):
    with open(_PREFS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def _default_backup_dir():
    docs = os.path.join(os.path.expanduser("~"), "Documents")
    base = docs if os.path.isdir(docs) else os.path.expanduser("~")
    return os.path.join(base, "Dogbox Backups")


def _auto_backup_worker():
    import time, shutil, datetime, glob as _glob
    while True:
        time.sleep(300)
        try:
            db_path = db()
            if not db_path or not os.path.exists(db_path):
                continue
            p = _load_prefs()
            if not p.get("auto_backup_enabled", False):
                continue
            bdir = p.get("auto_backup_dir", "").strip()
            if not bdir or not os.path.isdir(bdir):
                continue
            interval_hours = float(p.get("auto_backup_interval", 1))
            name = os.path.splitext(os.path.basename(db_path))[0]
            pattern = os.path.join(bdir, f"{name}_auto_*.abk")
            existing = sorted(_glob.glob(pattern))
            now = datetime.datetime.now().timestamp()
            if existing:
                elapsed_hours = (now - os.path.getmtime(existing[-1])) / 3600
                if elapsed_hours < interval_hours:
                    continue
            ts   = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            dest = os.path.join(bdir, f"{name}_auto_{ts}.abk")
            shutil.copy2(db_path, dest)
            existing = sorted(_glob.glob(pattern))
            keep = max(1, int(p.get("auto_backup_keep", 10)))
            while len(existing) > keep:
                try:
                    os.remove(existing.pop(0))
                except Exception:
                    break
        except Exception:
            pass


_threading.Thread(target=_auto_backup_worker, daemon=True).start()


@bp.route("/api/backup/status")
@login_required
def api_backup_status():
    import glob as _glob, datetime as _dt
    db_path = db()
    p = _load_prefs()
    auto_on = p.get("auto_backup_enabled", False)
    bdir    = p.get("auto_backup_dir", "").strip()

    if not bdir or not os.path.isdir(bdir):
        return ok({"warn": True, "reason": "never", "last": None, "auto": auto_on})

    name  = os.path.splitext(os.path.basename(db_path or "company"))[0]
    files = sorted(_glob.glob(os.path.join(bdir, f"{name}_*.abk")), reverse=True)
    if not files:
        return ok({"warn": True, "reason": "never", "last": None, "auto": auto_on})

    try:
        mtime    = os.path.getmtime(files[0])
        age_days = (_dt.datetime.now().timestamp() - mtime) / 86400
        last_str = _dt.datetime.fromtimestamp(mtime).strftime("%d %b %Y")
        warn     = not auto_on and age_days > 7
        return ok({"warn": warn, "reason": "stale" if warn else "ok",
                   "last": last_str, "age_days": int(age_days), "auto": auto_on})
    except Exception:
        return ok({"warn": False})


@bp.route("/api/backup/settings")
@login_required
def api_backup_settings_get():
    p = _load_prefs()
    return ok({
        "enabled":        p.get("auto_backup_enabled",  False),
        "directory":      p.get("auto_backup_dir",      ""),
        "interval_hours": p.get("auto_backup_interval", 1),
        "keep_count":     p.get("auto_backup_keep",     10),
        "db_name":        os.path.basename(db() or ""),
        "suggested_dir":  _default_backup_dir(),
    })


@bp.route("/api/backup/settings", methods=["POST"])
@login_required
def api_backup_settings_post():
    d = request.get_json(force=True) or {}
    p = _load_prefs()
    p["auto_backup_enabled"]  = bool(d.get("enabled", False))
    p["auto_backup_dir"]      = str(d.get("directory", "")).strip()
    p["auto_backup_interval"] = float(d.get("interval_hours", 1))
    p["auto_backup_keep"]     = int(d.get("keep_count", 10))
    try:
        _save_prefs(p)
    except Exception as e:
        return err(str(e))
    return ok()


@bp.route("/api/backup/browse-dir")
@login_required
def api_backup_browse_dir():
    import subprocess
    _dialog = (
        "import tkinter as tk, tkinter.filedialog as fd, sys\n"
        "root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True)\n"
        "p = fd.askdirectory(title='Select Backup Folder')\n"
        "root.destroy()\n"
        "print(p)\n"
    )
    try:
        r = subprocess.run(
            [sys.executable, "-c", _dialog],
            capture_output=True, text=True, timeout=120,
        )
        chosen = r.stdout.strip()
        if not chosen:
            return ok({"path": None})
        return ok({"path": os.path.normpath(chosen)})
    except Exception as e:
        return err(str(e))


@bp.route("/api/backup/now", methods=["POST"])
@login_required
def api_backup_now():
    import shutil, datetime, glob
    db_path = db()
    if not db_path or not os.path.exists(db_path):
        return err("No company file open")
    p    = _load_prefs()
    body = request.get_json(silent=True) or {}
    bdir = (body.get("directory") or p.get("auto_backup_dir", "")).strip()
    if not bdir:
        return err("Backup directory not configured — set it in Auto-Backup Settings first")
    os.makedirs(bdir, exist_ok=True)
    if not os.path.isdir(bdir):
        return err(f"Could not create backup directory: {bdir}")
    ts   = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    name = os.path.splitext(os.path.basename(db_path))[0]
    dest = os.path.join(bdir, f"{name}_backup_{ts}.abk")
    try:
        shutil.copy2(db_path, dest)
    except Exception as e:
        return err(str(e))
    keep     = max(1, int(p.get("auto_backup_keep", 10)))
    pattern  = os.path.join(bdir, f"{name}_backup_*.abk")
    existing = sorted(glob.glob(pattern))
    while len(existing) > keep:
        try:
            os.remove(existing.pop(0))
        except Exception:
            break
    return ok({"filename": os.path.basename(dest)})


@bp.route("/api/backup/list")
@login_required
def api_backup_list():
    import glob, datetime
    db_path = db()
    p    = _load_prefs()
    bdir = p.get("auto_backup_dir", "").strip()
    if not bdir or not os.path.isdir(bdir):
        return ok([])
    name    = os.path.splitext(os.path.basename(db_path or "company"))[0]
    pattern = os.path.join(bdir, f"{name}_*.abk")
    files   = sorted(glob.glob(pattern), reverse=True)
    result  = []
    for f in files[:50]:
        try:
            stat = os.stat(f)
            result.append({
                "filename": os.path.basename(f),
                "size":     stat.st_size,
                "modified": datetime.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
            })
        except Exception:
            pass
    return ok(result)


@bp.route("/api/backup/download")
@login_required
def api_backup_download():
    import datetime
    db_path = db()
    if not db_path or not os.path.exists(db_path):
        return err("No company file open")
    ts      = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    name    = os.path.splitext(os.path.basename(db_path))[0]
    dl_name = f"{name}_backup_{ts}.abk"
    return send_file(db_path, as_attachment=True, download_name=dl_name)


@bp.route("/api/backup/pick-file")
@login_required
def api_backup_pick_file():
    import subprocess
    p    = _load_prefs()
    bdir = p.get("auto_backup_dir", "").strip() or _default_backup_dir()
    _dialog = (
        "import tkinter as tk, tkinter.filedialog as fd, sys\n"
        f"idir = {repr(bdir)}\n"
        "root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True)\n"
        "p = fd.askopenfilename(\n"
        "    title='Select Backup to Restore',\n"
        "    initialdir=idir,\n"
        "    filetypes=[('dbox Backup','*.abk'),('dbox File','*.dbox'),('All files','*.*')],\n"
        ")\n"
        "root.destroy()\n"
        "print(p)\n"
    )
    try:
        r = subprocess.run(
            [sys.executable, "-c", _dialog],
            capture_output=True, text=True, timeout=120,
        )
        chosen = r.stdout.strip()
        if not chosen:
            return ok({"path": None})
        return ok({"path": os.path.normpath(chosen)})
    except Exception as e:
        return err(str(e))


@bp.route("/api/backup/restore", methods=["POST"])
@login_required
def api_backup_restore():
    import shutil
    d       = request.get_json(force=True) or {}
    src     = d.get("path", "").strip()
    db_path = db()
    if not src:
        return err("No backup file specified")
    if not os.path.exists(src):
        return err(f"File not found: {src}")
    if not db_path:
        return err("No company file open")
    try:
        shutil.copy2(src, db_path)
    except Exception as e:
        return err(str(e))
    return ok()


# ── General settings ──────────────────────────────────────────────────────────

@bp.route("/api/general/settings")
@login_required
def api_general_settings_get():
    p = _load_prefs()
    docs = os.path.join(os.path.expanduser("~"), "Documents")
    suggested = docs if os.path.isdir(docs) else os.path.expanduser("~")
    return ok({
        "default_file_dir": p.get("default_file_dir", ""),
        "suggested_dir":    suggested,
    })


@bp.route("/api/general/settings", methods=["POST"])
@login_required
def api_general_settings_post():
    d = request.get_json(force=True) or {}
    p = _load_prefs()
    p["default_file_dir"] = str(d.get("default_file_dir", "")).strip()
    try:
        _save_prefs(p)
    except Exception as e:
        return err(str(e))
    return ok()


@bp.route("/api/general/browse-dir")
@login_required
def api_general_browse_dir():
    import subprocess
    p    = _load_prefs()
    idir = p.get("default_file_dir", "").strip()
    if not idir or not os.path.isdir(idir):
        docs = os.path.join(os.path.expanduser("~"), "Documents")
        idir = docs if os.path.isdir(docs) else os.path.expanduser("~")
    _dialog = (
        "import tkinter as tk, tkinter.filedialog as fd\n"
        f"idir = {repr(idir)}\n"
        "root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True)\n"
        "p = fd.askdirectory(title='Select Default File Folder', initialdir=idir)\n"
        "root.destroy()\n"
        "print(p)\n"
    )
    try:
        r = subprocess.run(
            [sys.executable, "-c", _dialog],
            capture_output=True, text=True, timeout=120,
        )
        chosen = r.stdout.strip()
        if not chosen:
            return ok({"path": None})
        return ok({"path": os.path.normpath(chosen)})
    except Exception as e:
        return err(str(e))
