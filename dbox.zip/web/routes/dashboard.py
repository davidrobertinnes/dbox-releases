import calendar
from datetime import date, timedelta
from flask import Blueprint

from web.shared import db, ok, login_required
from core.database import get_connection
from core.ledger import (
    get_accounts, get_account_balances_batch, get_invoices, get_bills,
    profit_and_loss, get_monthly_totals,
)
from core.recurring import get_upcoming
from core.crm import get_crm_dashboard

bp = Blueprint('dashboard_api', __name__)


@bp.route('/api/dashboard')
@login_required
def api_dashboard():
    today       = date.today()
    month_start = today.replace(day=1)
    month_end   = today.replace(day=calendar.monthrange(today.year, today.month)[1])
    lm_last     = month_start - timedelta(days=1)
    lm_start    = lm_last.replace(day=1)
    fy_start    = date(today.year, 7, 1) if today.month >= 7 else date(today.year - 1, 7, 1)

    # ── Bank balance ──────────────────────────────────────────────────────────
    accounts   = get_accounts(db())
    bank_accs  = [a for a in accounts if a.get("is_bank")]
    all_ids    = [a["id"] for a in bank_accs]
    balances   = get_account_balances_batch(db(), all_ids)
    bank_total = sum(balances.get(a["id"], 0.0) for a in bank_accs)

    # ── AR ────────────────────────────────────────────────────────────────────
    invoices   = get_invoices(db())
    active_inv = [i for i in invoices if i["status"] not in ("Paid", "Void", "Draft")]
    ar_total   = sum((i.get("total") or i.get("total_amount") or 0)
                     - (i.get("amount_paid") or 0) for i in active_inv)
    ar_count   = len(active_inv)
    overdue_inv = [i for i in active_inv
                   if i.get("due_date") and i["due_date"] < str(today)]
    ar_overdue_count  = len(overdue_inv)
    ar_overdue_amount = sum((i.get("total") or i.get("total_amount") or 0)
                            - (i.get("amount_paid") or 0) for i in overdue_inv)

    # ── AP ────────────────────────────────────────────────────────────────────
    bills      = get_bills(db())
    active_bil = [b for b in bills if b["status"] not in ("Paid", "Void", "Draft")]
    ap_total   = sum((b.get("total") or b.get("total_amount") or 0)
                     - (b.get("amount_paid") or 0) for b in active_bil)
    ap_count   = len(active_bil)
    overdue_bil = [b for b in active_bil
                   if b.get("due_date") and b["due_date"] < str(today)]
    ap_overdue_count = len(overdue_bil)
    upcoming_bil = sorted(
        [b for b in active_bil if b.get("due_date") and b["due_date"] >= str(today)],
        key=lambda b: b["due_date"]
    )
    ap_next_due = upcoming_bil[0]["due_date"] if upcoming_bil else None

    # ── GST net (collected minus credits) ─────────────────────────────────────
    try:
        conn = get_connection(db())
        gst_row = conn.execute("""
            SELECT
              COALESCE(SUM(CASE WHEN a.name LIKE '%GST Collected%'
                                THEN jl.credit - jl.debit ELSE 0 END), 0) AS collected,
              COALESCE(SUM(CASE WHEN a.name LIKE '%GST Paid%'
                                THEN jl.debit - jl.credit ELSE 0 END), 0) AS credits
            FROM journal_lines jl
            JOIN accounts a ON jl.account_id = a.id
        """).fetchone()
        conn.close()
        gst_net = round((gst_row["collected"] or 0) - (gst_row["credits"] or 0), 2)
    except Exception:
        gst_net = 0.0

    # ── BAS period label (quarterly) ──────────────────────────────────────────
    q_month = ((today.month - 1) // 3) * 3 + 1
    q_names = {1: "Jan–Mar", 4: "Apr–Jun", 7: "Jul–Sep", 10: "Oct–Dec"}
    q_nums  = {1: "Q3",      4: "Q4",      7: "Q1",      10: "Q2"}
    q_label = q_names.get(q_month, "")
    q_num   = q_nums.get(q_month, "")
    q_start_year = today.year if q_month <= today.month else today.year - 1
    q_end_month  = q_month + 2
    q_end_year   = q_start_year
    if q_end_month > 12:
        q_end_month -= 12; q_end_year += 1
    bas_due_month = q_end_month + 1
    bas_due_year  = q_end_year
    if bas_due_month > 12:
        bas_due_month -= 12; bas_due_year += 1
    bas_due            = date(bas_due_year, bas_due_month, 28)
    bas_days_remaining = (bas_due - today).days
    ato_period         = f"GST · {q_num} {q_label} {q_start_year}"

    # ── P&L ───────────────────────────────────────────────────────────────────
    def _expenses(pl):
        return round(sum(r.get("amount", 0) for r in (pl.get("expense") or []))
                     + sum(r.get("amount", 0) for r in (pl.get("cost_of_sales") or [])), 2)
    try:
        pl_month  = profit_and_loss(db(), str(month_start), str(month_end))
        pl_fytd   = profit_and_loss(db(), str(fy_start),    str(today))
        pl_lm     = profit_and_loss(db(), str(lm_start),    str(lm_last))
        fytd_income    = round(pl_fytd.get("total_income", 0) or 0, 2)
        fytd_expenses  = _expenses(pl_fytd)
        fytd_net       = round(pl_fytd.get("net_profit",   0) or 0, 2)
        month_net      = round(pl_month.get("net_profit",  0) or 0, 2)
        last_month_net = round(pl_lm.get("net_profit",     0) or 0, 2)
    except Exception:
        fytd_income = fytd_expenses = fytd_net = month_net = last_month_net = 0.0

    # ── Sparklines — 6 months ─────────────────────────────────────────────────
    try:
        monthly           = get_monthly_totals(db(), months=6)
        monthly_ar        = [round(m.get("income",   0), 2) for m in monthly]
        monthly_ap        = [round(m.get("expenses", 0), 2) for m in monthly]
        monthly_bank      = [round(ar - ap, 2) for ar, ap in zip(monthly_ar, monthly_ap)]
        monthly_projected = [round(bank_total + ar - ap, 2)
                             for ar, ap in zip(monthly_ar, monthly_ap)]
    except Exception:
        monthly_bank = monthly_ar = monthly_ap = monthly_projected = [0] * 6

    # ── Recurring overdue ─────────────────────────────────────────────────────
    try:
        upcoming_rec      = get_upcoming(db(), days=0)
        recurring_overdue = len([t for t in upcoming_rec
                                  if t.get("next_due") and t["next_due"] < str(today)])
    except Exception:
        recurring_overdue = 0

    # ── CRM tasks & pipeline ──────────────────────────────────────────────────
    try:
        crm       = get_crm_dashboard(db())
        task_list = []

        if bas_days_remaining <= 60:
            task_list.append({
                "id":      0,
                "text":    "BAS lodgement due",
                "sub":     f"{q_num} {q_label} · due {bas_due.strftime('%-d %b')}",
                "bas":     True,
                "days":    bas_days_remaining,
                "overdue": bas_days_remaining < 0,
            })

        for t in crm.get("overdue_tasks", []):
            task_list.append({
                "id":      t["id"],
                "text":    t.get("title") or t.get("task_type") or "Task",
                "sub":     t.get("opp_title") or t.get("task_type", "Follow Up"),
                "due":     t.get("due_date", ""),
                "overdue": True,
            })

        for t in crm.get("upcoming_tasks", []):
            due = t.get("due_date", "")
            if due:
                days_away = (date.fromisoformat(due) - today).days
                if days_away > 14:
                    continue
            task_list.append({
                "id":      t["id"],
                "text":    t.get("title") or t.get("task_type") or "Task",
                "sub":     t.get("opp_title") or t.get("task_type", "Follow Up"),
                "due":     due,
                "overdue": False,
            })

        task_list = task_list[:6]

        pipeline_raw  = crm.get("pipeline", {})
        active_stages = {"Lead", "Qualified", "Quoted", "Accepted", "In Progress", "On Hold"}
        pipeline = [
            {"stage": stage, "amount": round(v["value"], 2), "count": v["count"]}
            for stage, v in pipeline_raw.items()
            if stage in active_stages and v["count"] > 0
        ]
        max_amt = max((p["amount"] for p in pipeline), default=1) or 1
        for p in pipeline:
            p["pct"] = round(p["amount"] / max_amt * 100)

    except Exception:
        task_list = []
        pipeline  = []

    return ok({
        # KPI row 1
        "bank_balance":       round(bank_total, 2),
        "projected_balance":  round(bank_total + ar_total - ap_total, 2),
        "gst_net":            gst_net,
        "ato_period":         ato_period,
        # KPI row 2
        "ar_total":           round(ar_total, 2),
        "ar_count":           ar_count,
        "ar_overdue_count":   ar_overdue_count,
        "ar_overdue_amount":  round(ar_overdue_amount, 2),
        "ap_total":           round(ap_total, 2),
        "ap_count":           ap_count,
        "ap_overdue_count":   ap_overdue_count,
        "ap_next_due":        ap_next_due,
        # P&L panel
        "pl_fytd_income":     fytd_income,
        "pl_fytd_expenses":   fytd_expenses,
        "pl_fytd_net":        fytd_net,
        "pl_month_net":       month_net,
        "pl_last_month_net":  last_month_net,
        "pl_fy_start":        str(fy_start),
        # Sparklines
        "monthly_bank":       monthly_bank,
        "monthly_projected":  monthly_projected,
        "monthly_ar":         monthly_ar,
        "monthly_ap":         monthly_ap,
        # Panels
        "tasks":              task_list,
        "pipeline":           pipeline,
        "recurring_overdue":  recurring_overdue,
    })
