import os
import tempfile
from datetime import date, timedelta
from flask import Blueprint, request, jsonify, send_file

from web.shared import db, ok, err, login_required, current_user
from core.jobs import (
    # Jobs
    get_jobs, get_job, save_job, delete_job, get_job_pl, get_job_transactions,
    allocate_transaction, deallocate_transaction,
    get_unallocated_invoices, get_unallocated_bills, get_unallocated_payments,
    next_job_number, get_job_time_entries, save_job_time_entry, delete_job_time_entry,
    # CRM — constants
    PIPELINE_STAGES, COMM_TYPES, TASK_TYPES, PRIORITY, QUOTE_STATUS,
    # CRM — opportunities
    get_opportunities, get_opportunity, save_opportunity, delete_opportunity,
    get_pipeline_summary, next_opp_number, next_quote_number,
    # CRM — communications
    get_communications, save_communication, delete_communication, log_email_activity,
    # CRM — tasks
    get_tasks, save_task, complete_task, delete_task,
    # CRM — quotes
    get_quotes, get_quote, save_quote, accept_quote,
    convert_quote_to_invoice, delete_quote,
    # CRM — progress claims
    get_progress_claims, save_progress_claim, claim_to_invoice,
    update_claim_status, delete_progress_claim,
    # CRM — work tasks
    get_job_work_tasks, get_work_tasks, save_work_task,
    complete_work_task, delete_work_task, invoice_work_tasks,
    # CRM — dashboard
    get_crm_dashboard,
)
from core.recurring import (
    get_templates, get_template, save_template, delete_template,
    get_upcoming, get_runs, process_due_templates,
)
from core.purchase_orders import create_po_from_crm_quote, get_purchase_orders
from core.budget import audit
from core.ledger import get_contacts, get_invoices, get_bills
from core.licence import get_licence_status, watermark_text, pdf_footer_text
from core.database import get_connection

bp = Blueprint('jobs', __name__)


@bp.before_request
def _check_pro_tier():
    from flask import request as _req
    user = current_user()
    if not user:
        return None
    caps = set(user.get("tier_caps") or [])
    path = _req.path
    if path.startswith("/api/jobs") and "jobs" not in caps:
        return err("Jobs requires a Pro licence — visit dogboxsoftware.com.au to upgrade.", 403)
    if path.startswith("/api/crm") and "jobs" not in caps:
        return err("CRM requires a Pro licence — visit dogboxsoftware.com.au to upgrade.", 403)
    if path.startswith("/api/recurring") and "recurring" not in caps:
        return err("Recurring Transactions requires a Pro licence — visit dogboxsoftware.com.au to upgrade.", 403)


def _get_pdf_watermark() -> str | None:
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
        return watermark_text(status)
    except Exception:
        return "Unregistered"


def _get_pdf_footer() -> str | None:
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
        return pdf_footer_text(status)
    except Exception:
        return None


# ── Jobs ───────────────────────────────────────────────────────────────────────

@bp.route("/api/jobs")
@login_required
def api_jobs():
    return ok([dict(j) for j in get_jobs(db())])


@bp.route("/api/jobs/<int:jid>")
@login_required
def api_job(jid):
    try:
        job = get_job(db(), jid)
        if not job:
            return err("Not found", 404)
        pl     = get_job_pl(db(), jid)
        txns   = get_job_transactions(db(), jid)
        comms  = get_communications(db(), job_id=jid)
        crm_tasks  = get_tasks(db(), job_id=jid, open_only=False)
        work_tasks = get_job_work_tasks(db(), jid)
        quotes = get_quotes(db(), job_id=jid)
        claims = get_progress_claims(db(), job_id=jid)
        pos    = get_purchase_orders(db(), job_id=jid)
        bills  = get_bills(db(), job_id=jid)
        return ok({
            "job":        dict(job),
            "pl":         pl,
            "transactions": [dict(t) for t in txns],
            "comms":      comms,
            "crm_tasks":  crm_tasks,
            "work_tasks": work_tasks,
            "quotes":     quotes,
            "claims":     claims,
            "pos":        pos,
            "bills":      bills,
        })
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs", methods=["POST"])
@login_required
def api_job_save():
    data = request.get_json() or {}
    try:
        jid = save_job(db(), data)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "SaveJob", "job", jid, data.get("name",""))
        return ok({"id": jid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/stage", methods=["PATCH"])
@login_required
def api_job_stage(jid):
    data = request.get_json() or {}
    stage = data.get("stage")
    if not stage:
        return err("stage required")
    try:
        conn = get_connection(db())
        conn.execute("UPDATE jobs SET stage=? WHERE id=?", (stage, jid))
        conn.commit(); conn.close()
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>", methods=["DELETE"])
@login_required
def api_job_delete(jid):
    try:
        delete_job(db(), jid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/allocate", methods=["POST"])
@login_required
def api_job_allocate(jid):
    d = request.get_json() or {}
    try:
        allocate_transaction(db(), jid, d["source_type"], d["source_id"],
                             float(d.get("amount", 0)),
                             d.get("notes",""),
                             current_user().get("id"))
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/allocations/<int:alloc_id>", methods=["DELETE"])
@login_required
def api_job_deallocate(alloc_id):
    try:
        conn = get_connection(db())
        row = conn.execute(
            "SELECT job_id, source_type, source_id FROM job_transactions WHERE id=?",
            (alloc_id,)).fetchone()
        conn.close()
        if not row:
            return err("Allocation not found", 404)
        deallocate_transaction(db(), row["job_id"], row["source_type"], row["source_id"])
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/invoice_from_expenses", methods=["POST"])
@login_required
def api_job_invoice_from_expenses(jid):
    from core.ledger import save_invoice, get_bill
    from core.purchase_orders import get_purchase_order
    from core.jobs import set_invoice_job
    d = request.get_json() or {}
    margin_pct = float(d.get("margin_pct", 15))
    items = d.get("items", [])
    if not items:
        return err("No items selected")
    try:
        job = get_job(db(), jid)
        if not job:
            return err("Job not found", 404)
        inv_lines = []
        for item in items:
            cost = float(item.get("cost", 0))
            sell = round(cost * (1 + margin_pct / 100), 2)
            itype = item.get("type")
            iid = int(item.get("id", 0))
            if itype == "bill":
                bill_data = get_bill(db(), iid)
                if bill_data:
                    b = bill_data["bill"]
                    desc = f"Materials — {b['bill_number']} ({b['contact_name']})"
                else:
                    desc = f"Bill #{iid}"
            elif itype == "po":
                po_data = get_purchase_order(db(), iid)
                if po_data:
                    p = po_data["po"]
                    desc = f"Materials — {p['po_number']} ({p['contact_name_live']})"
                else:
                    desc = f"PO #{iid}"
            else:
                desc = f"{itype} #{iid}"
            inv_lines.append({
                "description": desc,
                "quantity":    1,
                "unit_price":  sell,
                "tax_code":    "GST",
                "account_id":  None,
            })
        inv_data = {
            "contact_id":   job["contact_id"],
            "invoice_date": str(date.today()),
            "due_date":     str(date.today() + timedelta(days=30)),
            "status":       "Draft",
            "notes":        f"Expenses — Job {job['job_number']}",
            "job_id":       jid,
        }
        inv_id = save_invoice(db(), inv_data, inv_lines)
        set_invoice_job(db(), inv_id, jid)
        return ok({"invoice_id": inv_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/unallocated")
@login_required
def api_unallocated():
    invs  = get_unallocated_invoices(db())
    bills = get_unallocated_bills(db())
    pmts  = get_unallocated_payments(db())
    return ok({
        "invoices": [dict(i) for i in invs],
        "bills":    [dict(b) for b in bills],
        "payments": [dict(p) for p in pmts],
    })


@bp.route("/api/jobs/next-number")
@login_required
def api_job_next_number():
    return ok(next_job_number(db()))


@bp.route("/api/jobs/<int:jid>/time")
@login_required
def api_job_time_list(jid):
    try:
        return ok([dict(e) for e in get_job_time_entries(db(), jid)])
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/time/<int:eid>")
@login_required
def api_job_time_get(jid, eid):
    entries = get_job_time_entries(db(), jid)
    row = next((e for e in entries if e["id"] == eid), None)
    if not row:
        return err("Not found", 404)
    return ok(dict(row))


@bp.route("/api/jobs/<int:jid>/time", methods=["POST"])
@login_required
def api_job_time_save(jid):
    data = request.get_json() or {}
    data["job_id"] = jid
    try:
        eid = save_job_time_entry(db(), data)
        return ok({"id": eid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/time/<int:eid>", methods=["DELETE"])
@login_required
def api_job_time_delete(eid):
    try:
        delete_job_time_entry(db(), eid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/tasks")
@login_required
def api_job_tasks(jid):
    crm_tasks  = get_tasks(db(), job_id=jid, open_only=False)
    work_tasks = get_job_work_tasks(db(), jid)
    return ok({"crm_tasks": crm_tasks, "work_tasks": work_tasks})


@bp.route("/api/jobs/<int:jid>/pdf")
@login_required
def api_job_pdf(jid):
    from core.job_card_pdf import generate_job_card_pdf

    job = get_job(db(), jid)
    if not job:
        return err("Not found", 404)

    job_num = dict(job)["job_number"]
    tmp = os.path.join(tempfile.mkdtemp(), f"{job_num}.pdf")
    try:
        generate_job_card_pdf(db(), jid, output_path=tmp)
        return send_file(tmp, mimetype="application/pdf",
                         as_attachment=False,
                         download_name=f"{job_num}.pdf")
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/worksheet")
@login_required
def api_job_worksheet(jid):
    from core.worksheet_pdf import generate_worksheet_pdf

    job = get_job(db(), jid)
    if not job:
        return err("Not found", 404)

    job_num = dict(job)["job_number"]
    tmp = os.path.join(tempfile.mkdtemp(), f"worksheet_{job_num}.pdf")
    try:
        generate_worksheet_pdf(db(), job_id=jid, output_path=tmp,
                               watermark=_get_pdf_watermark(), footer=_get_pdf_footer())
        return send_file(tmp, mimetype="application/pdf",
                         as_attachment=False,
                         download_name=f"worksheet_{job_num}.pdf")
    except Exception as e:
        return err(str(e))


# ── CRM meta ───────────────────────────────────────────────────────────────────

@bp.route("/api/crm/meta")
@login_required
def api_crm_meta():
    return ok({
        "pipeline_stages": PIPELINE_STAGES,
        "comm_types":      COMM_TYPES,
        "task_types":      TASK_TYPES,
        "priority":        PRIORITY,
        "quote_status":    QUOTE_STATUS,
    })


# ── CRM Opportunities ──────────────────────────────────────────────────────────

@bp.route("/api/crm/opportunities")
@login_required
def api_crm_opps():
    stage      = request.args.get("stage")
    search     = request.args.get("search")
    contact_id = request.args.get("contact_id", type=int)
    rows = get_opportunities(db(), stage=stage or None, search=search or None,
                             contact_id=contact_id or None)
    return ok(rows)


@bp.route("/api/crm/opportunities/<int:oid>")
@login_required
def api_crm_opp(oid):
    opp = get_opportunity(db(), oid)
    if not opp:
        return err("Not found", 404)
    comms  = get_communications(db(), opp_id=oid)
    tasks  = get_tasks(db(), opp_id=oid, open_only=False)
    quotes = get_quotes(db(), opp_id=oid)
    claims = get_progress_claims(db(), opp_id=oid)
    return ok({"opp": opp, "comms": comms, "tasks": tasks,
               "quotes": quotes, "claims": claims})


@bp.route("/api/crm/opportunities", methods=["POST"])
@login_required
def api_crm_opp_save():
    data = request.get_json() or {}
    try:
        if not data.get("opp_number"):
            data["opp_number"] = next_opp_number(db())
        data["created_by"] = current_user().get("id")
        oid = save_opportunity(db(), data)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "SaveOpportunity", "crm_opportunity", oid, data.get("title",""))
        return ok({"id": oid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/opportunities/<int:oid>", methods=["PUT"])
@login_required
def api_crm_opp_update(oid):
    data = request.get_json() or {}
    data["id"] = oid
    try:
        save_opportunity(db(), data)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "UpdateOpportunity", "crm_opportunity", oid, data.get("title",""))
        return ok({"id": oid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/opportunities/<int:oid>", methods=["DELETE"])
@login_required
def api_crm_opp_delete(oid):
    try:
        delete_opportunity(db(), oid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/next-opp-number")
@login_required
def api_crm_next_opp_number():
    return ok(next_opp_number(db()))


@bp.route("/api/crm/opportunities/<int:oid>/transactions")
@login_required
def api_crm_opp_transactions(oid):
    opp = get_opportunity(db(), oid)
    if not opp:
        return err("Not found", 404)

    invoices = get_invoices(db(), opp_id=oid)
    bills    = get_bills(db(),    opp_id=oid)

    rows = []
    for inv in invoices:
        rows.append({
            "type":        "Invoice",
            "id":          inv["id"],
            "number":      inv.get("invoice_number") or "",
            "date":        inv.get("invoice_date")   or "",
            "due_date":    inv.get("due_date")        or "",
            "status":      inv.get("status")          or "",
            "total":       float(inv.get("total")     or 0),
            "balance_due": round(float(inv.get("total") or 0)
                                 - float(inv.get("amount_paid") or 0), 2),
            "contact_name": inv.get("contact_name")  or "",
        })
    for bill in bills:
        rows.append({
            "type":        "Bill",
            "id":          bill["id"],
            "number":      bill.get("bill_number")  or "",
            "date":        bill.get("bill_date")    or "",
            "due_date":    bill.get("due_date")      or "",
            "status":      bill.get("status")        or "",
            "total":       float(bill.get("total")  or 0),
            "balance_due": round(float(bill.get("total") or 0)
                                 - float(bill.get("amount_paid") or 0), 2),
            "contact_name": bill.get("contact_name") or "",
        })

    rows.sort(key=lambda r: (r["date"] or ""), reverse=True)
    return ok(rows)


# ── CRM Communications ─────────────────────────────────────────────────────────

@bp.route("/api/crm/communications", methods=["POST"])
@login_required
def api_crm_comm_save():
    data = request.get_json() or {}
    data["logged_by"] = current_user().get("id")
    try:
        cid = save_communication(db(), data)
        return ok({"id": cid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/communications/<int:cid>", methods=["DELETE"])
@login_required
def api_crm_comm_delete(cid):
    try:
        delete_communication(db(), cid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── CRM Tasks ─────────────────────────────────────────────────────────────────

@bp.route("/api/crm/tasks", methods=["POST"])
@login_required
def api_crm_task_save():
    data = request.get_json() or {}
    try:
        tid = save_task(db(), data)
        return ok({"id": tid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/tasks/<int:tid>/complete", methods=["POST"])
@login_required
def api_crm_task_complete(tid):
    try:
        complete_task(db(), tid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/tasks/<int:tid>", methods=["DELETE"])
@login_required
def api_crm_task_delete(tid):
    try:
        delete_task(db(), tid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── Standalone Quotes list ────────────────────────────────────────────────────

@bp.route("/api/quotes")
@login_required
def api_quotes_all():
    """Return all quotes regardless of opportunity, enriched with contact/opp names."""
    quotes = get_quotes(db())
    contacts = {c["id"]: c["name"] for c in get_contacts(db())}
    result = []
    for q in quotes:
        q = dict(q)
        q["contact_name"] = contacts.get(q.get("contact_id"), "—")
        result.append(q)
    return ok(result)


@bp.route("/api/crm/quotes/<int:qid>/pdf")
@login_required
def api_crm_quote_pdf(qid):
    try:
        from core.quote_pdf import generate_quote_pdf
        import tempfile
        watermark = _get_pdf_watermark()
        footer    = _get_pdf_footer()
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
            tmp_path = tmp.name
        generate_quote_pdf(db(), qid, output_path=tmp_path, watermark=watermark, footer=footer)
        q, _ = get_quote(db(), qid)
        fname = f"Quote-{q['quote_number']}.pdf" if q else "quote.pdf"
        response = send_file(tmp_path, mimetype="application/pdf",
                             as_attachment=True, download_name=fname)
        @response.call_on_close
        def _cleanup():
            try: os.unlink(tmp_path)
            except: pass
        return response
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/quotes/<int:qid>/email", methods=["POST"])
@login_required
def api_crm_quote_email(qid):
    from core.email_invoice import send_pdf_email
    data = request.get_json() or {}
    to_email = (data.get("to") or "").strip()
    if not to_email:
        return err("Recipient email is required", 400)
    q, _ = get_quote(db(), qid)
    if not q:
        return err("Quote not found", 404)
    from core.quote_pdf import generate_quote_pdf
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
            tmp_path = tmp.name
        generate_quote_pdf(db(), qid, output_path=tmp_path,
                           watermark=_get_pdf_watermark(), footer=_get_pdf_footer())
        subject = data.get("subject") or f"Quote {q.get('quote_number','')} from {q.get('contact_name','')}"
        body    = data.get("body") or f"Please find attached quote {q.get('quote_number','')}.\n\nThank you."
        ok_flag, msg = send_pdf_email(db(), tmp_path, to_email, subject, body)
        if not ok_flag:
            return err(msg)
        log_email_activity(db(), q.get("contact_id"), subject, body)
        return ok()
    except Exception as e:
        return err(str(e))
    finally:
        if tmp_path:
            try: os.unlink(tmp_path)
            except Exception: pass


# ── CRM Quotes ────────────────────────────────────────────────────────────────

@bp.route("/api/crm/quotes/<int:qid>")
@login_required
def api_crm_quote(qid):
    q, lines = get_quote(db(), qid)
    if not q:
        return err("Not found", 404)
    return ok({"quote": q, "lines": lines})


@bp.route("/api/crm/quotes", methods=["POST"])
@login_required
def api_crm_quote_save():
    body = request.get_json() or {}
    qdata = body.get("quote", {})
    lines = body.get("lines", [])
    if not qdata.get("quote_number"):
        qdata["quote_number"] = next_quote_number(db())
    qdata["created_by"] = current_user().get("id")
    try:
        qid = save_quote(db(), qdata, lines)
        return ok({"id": qid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/quotes/<int:qid>", methods=["PUT"])
@login_required
def api_crm_quote_update(qid):
    body = request.get_json() or {}
    qdata = body.get("quote", {})
    lines = body.get("lines", [])
    qdata["id"] = qid
    try:
        save_quote(db(), qdata, lines)
        return ok({"id": qid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/quotes/<int:qid>/accept", methods=["POST"])
@login_required
def api_crm_quote_accept(qid):
    try:
        opp_id = accept_quote(db(), qid, current_user().get("username",""))
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "AcceptQuote", "crm_quote", qid, "")
        return ok({"opp_id": opp_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/quotes/<int:qid>/convert", methods=["POST"])
@login_required
def api_crm_quote_convert(qid):
    try:
        inv_id = convert_quote_to_invoice(db(), qid, current_user().get("id"))
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "ConvertQuoteToInvoice", "crm_quote", qid, f"inv={inv_id}")
        return ok({"invoice_id": inv_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/quotes/<int:qid>", methods=["DELETE"])
@login_required
def api_crm_quote_delete(qid):
    try:
        delete_quote(db(), qid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── CRM Progress Claims ───────────────────────────────────────────────────────

@bp.route("/api/crm/claims", methods=["POST"])
@login_required
def api_crm_claim_save():
    data = request.get_json() or {}
    data["created_by"] = current_user().get("id")
    try:
        cid = save_progress_claim(db(), data)
        return ok({"id": cid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/claims/<int:cid>", methods=["PUT"])
@login_required
def api_crm_claim_update(cid):
    data = request.get_json() or {}
    try:
        if "status" in data and len(data) == 1:
            update_claim_status(db(), cid, data["status"])
        else:
            data["id"] = cid
            save_progress_claim(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/claims/<int:cid>/convert", methods=["POST"])
@login_required
def api_crm_claim_convert(cid):
    try:
        inv_id = claim_to_invoice(db(), cid, current_user().get("id"))
        return ok({"invoice_id": inv_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/claims/<int:cid>", methods=["DELETE"])
@login_required
def api_crm_claim_delete(cid):
    try:
        delete_progress_claim(db(), cid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── Recurring ──────────────────────────────────────────────────────────────────

@bp.route("/api/recurring")
@login_required
def api_recurring():
    templates = get_templates(db())
    return ok([dict(t) for t in templates])


@bp.route("/api/recurring/upcoming")
@login_required
def api_recurring_upcoming():
    days = max(1, min(365, int(request.args.get("days", 30) or 30)))
    return ok([dict(t) for t in get_upcoming(db(), days=days)])


@bp.route("/api/recurring/<int:tid>")
@login_required
def api_recurring_template(tid):
    t = get_template(db(), tid)
    return ok(dict(t)) if t else err("Not found", 404)


@bp.route("/api/recurring", methods=["POST"])
@login_required
def api_recurring_save():
    data = request.get_json() or {}
    try:
        tid = save_template(db(), data)
        return ok({"id": tid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/recurring/<int:tid>", methods=["DELETE"])
@login_required
def api_recurring_delete(tid):
    try:
        delete_template(db(), tid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/recurring/<int:tid>", methods=["PUT"])
@login_required
def api_recurring_update(tid):
    data = request.get_json() or {}
    data["id"] = tid
    try:
        save_template(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/recurring/process", methods=["POST"])
@login_required
def api_recurring_process():
    data = request.get_json() or {}
    try:
        results = process_due_templates(
            db(), as_of=data.get("as_of") or str(date.today()))
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "ProcessRecurring", "recurring", None,
              f"{len(results)} templates processed")
        return ok(results)
    except Exception as e:
        return err(str(e))


@bp.route("/api/recurring/<int:tid>/runs")
@login_required
def api_recurring_runs(tid):
    return ok([dict(r) for r in get_runs(db(), tid)])
