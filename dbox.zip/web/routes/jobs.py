# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import os
import tempfile
from datetime import date, timedelta
from flask import Blueprint, request, jsonify, send_file

from web.shared import db, ok, err, login_required, current_user, _get_pdf_watermark, _get_combined_pdf_footer
from core.jobs import (
    # Jobs
    get_jobs, get_job, save_job, delete_job, get_job_pl, get_job_transactions,
    allocate_transaction, deallocate_transaction,
    get_unallocated_invoices, get_unallocated_bills, get_unallocated_payments,
    next_job_number, get_job_time_entries, save_job_time_entry, delete_job_time_entry,
    get_all_time_entries, set_time_entry_status,
    get_orphan_tasks, link_work_task_to_job,
    # CRM — constants
    PIPELINE_STAGES, COMM_TYPES, TASK_TYPES, PRIORITY, QUOTE_STATUS, _STAGE_TO_STATUS,
    # CRM — opportunities
    get_opportunities, get_opportunity, save_opportunity, delete_opportunity,
    get_pipeline_summary, next_opp_number, next_quote_number,
    # CRM — communications
    get_communications, save_communication, delete_communication, log_email_activity,
    # CRM — tasks
    get_tasks, save_task, complete_task, delete_task,
    # CRM — quotes
    get_quotes, get_quote, save_quote, accept_quote,
    convert_quote_to_invoice, delete_quote,
    # CRM — progress claims
    get_progress_claims, save_progress_claim, claim_to_invoice,
    update_claim_status, delete_progress_claim, link_invoice_to_claim,
    # CRM — work tasks
    get_job_work_tasks, get_work_tasks, save_work_task,
    complete_work_task, delete_work_task, invoice_work_tasks, invoice_job_work_tasks,
    time_entry_to_work_task,
    # CRM — dashboard
    get_crm_dashboard,
    # BOM
    get_job_bom, save_bom_line, delete_bom_line, toggle_bom_on_hand, set_bom_line_po,
)
from core.purchase_orders import create_po_from_bom
from core.recurring import (
    get_templates, get_template, save_template, delete_template,
    get_upcoming, get_runs, process_due_templates,
)
from core.purchase_orders import create_po_from_crm_quote, get_purchase_orders
from core.budget import audit
from core.ledger import get_contacts, get_invoices, get_bills
from core.database import get_connection
from core.gcal import push_job, push_delete
from core.schedule import list_job_visits

bp = Blueprint('jobs', __name__)


@bp.before_request
def _check_access():
    from core.auth import ROLE_MODULES
    from flask import request as _req
    user = current_user()
    if not user:
        return None
    caps = set(user.get("tier_caps") or [])
    role = user.get("role", "")
    allowed = ROLE_MODULES.get(role)
    path = _req.path
    if path.startswith("/api/recurring"):
        if "recurring" not in caps:
            return err("Recurring requires the Paid tier.", 403)
    elif path.startswith("/api/jobs") or path.startswith("/api/crm"):
        if "jobs" not in caps:
            return err("Jobs & CRM requires the Paid tier.", 403)
        if allowed is not None and "jobs" not in allowed:
            return err("Your role does not have access to Jobs & CRM.", 403)
    elif path.startswith("/api/quotes"):
        if "quotes" not in caps:
            return err("Quotes requires the Paid tier.", 403)
        if allowed is not None and "jobs" not in allowed:
            return err("Your role does not have access to Quotes.", 403)



# ── Jobs ───────────────────────────────────────────────────────────────────────

@bp.route("/api/jobs")
@login_required
def api_jobs():
    # Reporting hook: all params optional, used by future jobs report
    contact_id = request.args.get('contact_id', type=int)
    date_from  = request.args.get('date_from')
    date_to    = request.args.get('date_to')
    owner      = request.args.get('owner')
    stage      = request.args.get('stage')
    return ok([dict(j) for j in get_jobs(
        db(), contact_id=contact_id, date_from=date_from,
        date_to=date_to, owner=owner, stage=stage,
    )])


@bp.route("/api/jobs/<int:jid>")
@login_required
def api_job(jid):
    try:
        job = get_job(db(), jid)
        if not job:
            return err("Not found", 404)
        pl     = get_job_pl(db(), jid)
        txns   = get_job_transactions(db(), jid)
        comms  = get_communications(db(), job_id=jid)
        crm_tasks  = get_tasks(db(), job_id=jid, open_only=False)
        work_tasks = get_job_work_tasks(db(), jid)
        quotes = get_quotes(db(), job_id=jid)
        claims = get_progress_claims(db(), job_id=jid)
        pos    = get_purchase_orders(db(), job_id=jid)
        bills  = get_bills(db(), job_id=jid)
        bom    = get_job_bom(db(), jid)
        visits = list_job_visits(db(), jid)
        from core.job_billing import blocked_materials, get_job_recharges
        from core.visit_tasks import get_job_task_visits, get_visit_task_counts
        conn = get_connection(db())
        try:
            blocked = blocked_materials(conn, jid)
        finally:
            conn.close()
        return ok({
            "job":        dict(job),
            "pl":         pl,
            "transactions": [dict(t) for t in txns],
            "comms":      comms,
            "crm_tasks":  crm_tasks,
            "work_tasks": work_tasks,
            "quotes":     quotes,
            "claims":     claims,
            "pos":        pos,
            "bills":      bills,
            "bom":        bom,
            "visits":     visits,
            "recharges":  get_job_recharges(db(), jid),
            "task_visits":  get_job_task_visits(db(), jid),
            "visit_task_counts": get_visit_task_counts(db(), jid),
            "recharge_blocked": {k: sorted(v) for k, v in blocked.items()},
        })
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs", methods=["POST"])
@login_required
def api_job_save():
    data = request.get_json() or {}
    try:
        jid = save_job(db(), data)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "SaveJob", "job", jid, data.get("name",""))
    except Exception as e:
        return err(str(e))
    # Best-effort — never raises, never blocks the response on a network hiccup.
    push_job(db(), jid)
    return ok({"id": jid})


@bp.route("/api/jobs/<int:jid>/stage", methods=["PATCH"])
@login_required
def api_job_stage(jid):
    data = request.get_json() or {}
    stage = data.get("stage")
    if not stage:
        return err("stage required")
    try:
        conn = get_connection(db())
        status = _STAGE_TO_STATUS.get(stage, "Active")
        conn.execute("UPDATE jobs SET stage=?, status=? WHERE id=?", (stage, status, jid))
        conn.commit(); conn.close()
    except Exception as e:
        return err(str(e))
    # Stage change can flip calendar eligibility either way (e.g. In
    # Progress -> Complete should remove it from the calendar).
    push_job(db(), jid)
    return ok()


@bp.route("/api/jobs/<int:jid>", methods=["DELETE"])
@login_required
def api_job_delete(jid):
    # Fetch before deleting — need gcal_event_id before the row is gone, and
    # the Google ids of the unbilled visits delete_job() removes with it.
    existing = get_job(db(), jid)
    visit_gids = [v['gcal_event_id'] for v in list_job_visits(db(), jid)
                  if v.get('event_type') == 'Visit' and not v.get('invoice_id')
                  and v.get('gcal_event_id')]
    try:
        delete_job(db(), jid)
    except Exception as e:
        return err(str(e))
    if existing and existing.get('gcal_event_id'):
        push_delete(db(), existing['gcal_event_id'])
    for gid in visit_gids:
        push_delete(db(), gid)
    return ok()


@bp.route("/api/jobs/<int:jid>/allocate", methods=["POST"])
@login_required
def api_job_allocate(jid):
    d = request.get_json() or {}
    try:
        allocate_transaction(db(), jid, d["source_type"], d["source_id"],
                             float(d.get("amount", 0)),
                             d.get("notes",""),
                             current_user().get("id"))
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/allocations/<int:alloc_id>", methods=["DELETE"])
@login_required
def api_job_deallocate(alloc_id):
    try:
        conn = get_connection(db())
        row = conn.execute(
            "SELECT job_id, source_type, source_id FROM job_transactions WHERE id=?",
            (alloc_id,)).fetchone()
        conn.close()
        if not row:
            return err("Allocation not found", 404)
        deallocate_transaction(db(), row["job_id"], row["source_type"], row["source_id"])
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/claim-builder")
@login_required
def api_job_claim_builder_data(jid):
    from core.job_billing import get_claim_builder_data
    try:
        return ok(get_claim_builder_data(db(), jid))
    except ValueError as e:
        return err(str(e), 404)


@bp.route("/api/jobs/<int:jid>/claim-builder", methods=["POST"])
@login_required
def api_job_claim_builder_create(jid):
    from core.job_billing import build_claim_invoice
    try:
        result = build_claim_invoice(db(), jid, request.get_json() or {},
                                     created_by=current_user().get("id"))
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "ClaimBuilder", "invoices", result["invoice_id"], result["claim_number"])
        return ok(result)
    except ValueError as e:
        return err(str(e))
    except Exception as e:
        from core.logger import log_error
        log_error(f"claim builder failed for job {jid}", e)
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/invoice_from_expenses", methods=["POST"])
@login_required
def api_job_invoice_from_expenses(jid):
    from core.ledger import save_invoice, get_bill
    from core.purchase_orders import get_purchase_order
    from core.jobs import set_invoice_job
    from core.job_billing import blocked_materials, record_recharge
    d = request.get_json() or {}
    margin_pct = float(d.get("margin_pct", 15))
    items = d.get("items", [])
    if not items:
        return err("No items selected")
    try:
        job = get_job(db(), jid)
        if not job:
            return err("Job not found", 404)
        conn = get_connection(db())
        try:
            blocked = blocked_materials(conn, jid)
            co = conn.execute(
                "SELECT default_payment_instructions FROM company WHERE id=1").fetchone()
        finally:
            conn.close()
        default_pmt = co["default_payment_instructions"] if co else None

        inv_lines, recharges = [], []
        for item in items:
            itype = item.get("type")
            iid = int(item.get("id", 0))
            if itype not in ("bill", "po"):
                return err(f"Unknown expense type {itype!r}")
            if iid in blocked[itype]:
                return err("One of the selected expenses has already been charged "
                           "to the customer — refresh and try again")
            # Cost comes from the record itself, not the browser.
            if itype == "bill":
                bill_data = get_bill(db(), iid)
                if not bill_data:
                    return err(f"Bill #{iid} not found", 404)
                b = bill_data["bill"]
                cost = float(b.get("subtotal") or 0)
                desc = f"Materials — {b['bill_number']} ({b['contact_name']})"
            else:
                po_data = get_purchase_order(db(), iid)
                if not po_data:
                    return err(f"PO #{iid} not found", 404)
                p = po_data["po"]
                cost = float(p.get("subtotal") or 0)
                desc = f"Materials — {p['po_number']} ({p['contact_name_live']})"
            sell = round(cost * (1 + margin_pct / 100), 2)
            recharges.append((itype, iid, cost, sell))
            inv_lines.append({
                "description": desc,
                "quantity":    1,
                "unit_price":  sell,
                "tax_code":    "GST",
                "account_id":  None,
            })
        inv_data = {
            "contact_id":           job["contact_id"],
            "invoice_date":         str(date.today()),
            "due_date":             str(date.today() + timedelta(days=30)),
            "status":               "Draft",
            "notes":                f"Expenses — Job {job['job_number']}",
            "job_id":               jid,
            "payment_instructions": default_pmt,
        }
        inv_id = save_invoice(db(), inv_data, inv_lines)
        set_invoice_job(db(), inv_id, jid)
        conn = get_connection(db())
        try:
            for itype, iid, cost, sell in recharges:
                record_recharge(conn, jid, itype, iid, inv_id, cost, sell)
            conn.commit()
        finally:
            conn.close()
        return ok({"invoice_id": inv_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/unallocated")
@login_required
def api_unallocated():
    invs  = get_unallocated_invoices(db())
    bills = get_unallocated_bills(db())
    pmts  = get_unallocated_payments(db())
    return ok({
        "invoices": [dict(i) for i in invs],
        "bills":    [dict(b) for b in bills],
        "payments": [dict(p) for p in pmts],
    })


@bp.route("/api/jobs/next-number")
@login_required
def api_job_next_number():
    return ok(next_job_number(db()))


@bp.route("/api/jobs/<int:jid>/time")
@login_required
def api_job_time_list(jid):
    try:
        return ok([dict(e) for e in get_job_time_entries(db(), jid)])
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/time/<int:eid>")
@login_required
def api_job_time_get(jid, eid):
    entries = get_job_time_entries(db(), jid)
    row = next((e for e in entries if e["id"] == eid), None)
    if not row:
        return err("Not found", 404)
    return ok(dict(row))


@bp.route("/api/jobs/<int:jid>/time", methods=["POST"])
@login_required
def api_job_time_save(jid):
    data = request.get_json() or {}
    data["job_id"] = jid
    try:
        eid = save_job_time_entry(db(), data)
        return ok({"id": eid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/time/<int:eid>", methods=["DELETE"])
@login_required
def api_job_time_delete(eid):
    try:
        delete_job_time_entry(db(), eid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/time/<int:eid>", methods=["PUT"])
@login_required
def api_job_time_update(eid):
    data = request.get_json() or {}
    data["id"] = eid
    try:
        if "status" in data and len(data) == 2:  # only id + status
            set_time_entry_status(db(), eid, data["status"])
        else:
            save_job_time_entry(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/time/<int:eid>/bill", methods=["POST"])
@login_required
def api_job_time_bill(jid, eid):
    try:
        task_id = time_entry_to_work_task(db(), eid, jid)
        return ok({"task_id": task_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/time-entries")
@login_required
def api_all_time_entries():
    entry_date  = request.args.get("date")
    employee_id = request.args.get("employee_id", type=int)
    date_from   = request.args.get("date_from")
    date_to     = request.args.get("date_to")
    status      = request.args.get("status")
    try:
        return ok(get_all_time_entries(
            db(), entry_date=entry_date, employee_id=employee_id,
            date_from=date_from, date_to=date_to, status=status,
        ))
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/tasks")
@login_required
def api_job_tasks(jid):
    crm_tasks  = get_tasks(db(), job_id=jid, open_only=False)
    work_tasks = get_job_work_tasks(db(), jid)
    return ok({"crm_tasks": crm_tasks, "work_tasks": work_tasks})


@bp.route("/api/jobs/<int:jid>/work-tasks/invoice", methods=["POST"])
@login_required
def api_job_work_tasks_invoice(jid):
    try:
        body = request.json or {}
        task_ids = [int(i) for i in body.get("task_ids", [])]
        create_claim = bool(body.get("create_claim", False))
        if not task_ids:
            return err("No tasks specified")
        inv_id = invoice_job_work_tasks(db(), jid, task_ids, create_claim)
        return ok({"invoice_id": inv_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/pdf")
@login_required
def api_job_pdf(jid):
    from core.job_card_pdf import generate_job_card_pdf

    job = get_job(db(), jid)
    if not job:
        return err("Not found", 404)

    job_num = dict(job)["job_number"]
    include_financials = request.args.get("financials") == "1"
    tmp = os.path.join(tempfile.mkdtemp(), f"{job_num}.pdf")
    try:
        generate_job_card_pdf(db(), jid, output_path=tmp,
                              include_financials=include_financials)
        return send_file(tmp, mimetype="application/pdf",
                         as_attachment=False,
                         download_name=f"{job_num}.pdf")
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/bom/pdf")
@login_required
def api_job_bom_pdf(jid):
    from core.bom_pdf import generate_bom_pdf
    job = get_job(db(), jid)
    if not job:
        return err("Not found", 404)
    ref = dict(job)["job_number"]
    tmp = os.path.join(tempfile.mkdtemp(), f"bom_{ref}.pdf")
    try:
        generate_bom_pdf(db(), jid, output_path=tmp,
                         watermark=_get_pdf_watermark(),
                         footer=_get_combined_pdf_footer(db()))
        return send_file(tmp, mimetype="application/pdf",
                         as_attachment=False,
                         download_name=f"bom_{ref}.pdf")
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/worksheet")
@login_required
def api_job_worksheet(jid):
    from core.worksheet_pdf import generate_worksheet_pdf

    job = get_job(db(), jid)
    if not job:
        return err("Not found", 404)

    job_num = dict(job)["job_number"]
    tmp = os.path.join(tempfile.mkdtemp(), f"worksheet_{job_num}.pdf")
    try:
        generate_worksheet_pdf(db(), job_id=jid, output_path=tmp,
                               watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db()))
        return send_file(tmp, mimetype="application/pdf",
                         as_attachment=False,
                         download_name=f"worksheet_{job_num}.pdf")
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/visits/<int:vid>/worksheet")
@login_required
def api_visit_worksheet(vid):
    from core.worksheet_pdf import generate_worksheet_pdf
    from core.schedule import get_event
    v = get_event(db(), vid)
    if not v or not v.get("job_id"):
        return err("Not found", 404)
    name = f"worksheet_{v.get('job_number') or 'job'}_{v['event_date']}.pdf"
    tmp = os.path.join(tempfile.mkdtemp(), name)
    try:
        generate_worksheet_pdf(db(), visit_id=vid, output_path=tmp,
                               watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db()))
        return send_file(tmp, mimetype="application/pdf", as_attachment=False, download_name=name)
    except ValueError as e:
        return err(str(e), 400)
    except Exception as e:
        return err(str(e))


# ── Bill of Materials ─────────────────────────────────────────────────────────

@bp.route("/api/jobs/<int:jid>/bom")
@login_required
def api_job_bom_get(jid):
    try:
        return ok(get_job_bom(db(), jid))
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/bom/create-po", methods=["POST"])
@login_required
def api_job_bom_create_po(jid):
    data = request.get_json() or {}
    contact_id = data.get("contact_id")
    line_ids   = data.get("line_ids") or []
    po_date    = data.get("po_date") or ""
    if not contact_id or not line_ids:
        return err("contact_id and line_ids are required", 400)
    try:
        result = create_po_from_bom(db(), jid, int(contact_id), po_date, line_ids)
        return ok(result)
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/bom", methods=["POST"])
@login_required
def api_job_bom_save(jid):
    data = request.get_json() or {}
    data["job_id"] = jid
    if not (data.get("description") or "").strip():
        return err("description is required", 400)
    try:
        lid = save_bom_line(db(), data)
        return ok({"id": lid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/bom/<int:lid>", methods=["DELETE"])
@login_required
def api_job_bom_delete(lid):
    try:
        delete_bom_line(db(), lid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/bom/<int:lid>/on-hand", methods=["PATCH"])
@login_required
def api_job_bom_on_hand(lid):
    try:
        now_on_hand = toggle_bom_on_hand(db(), lid)
        return ok({"is_on_hand": now_on_hand})
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/bom/<int:lid>/po", methods=["PATCH"])
@login_required
def api_job_bom_link_po(lid):
    data  = request.get_json() or {}
    po_id = data.get("po_id") or None
    try:
        set_bom_line_po(db(), lid, po_id)
        return ok()
    except Exception as e:
        return err(str(e))


# ── CRM meta ───────────────────────────────────────────────────────────────────

@bp.route("/api/crm/meta")
@login_required
def api_crm_meta():
    return ok({
        "pipeline_stages": PIPELINE_STAGES,
        "comm_types":      COMM_TYPES,
        "task_types":      TASK_TYPES,
        "priority":        PRIORITY,
        "quote_status":    QUOTE_STATUS,
    })


# ── CRM Opportunities ──────────────────────────────────────────────────────────

@bp.route("/api/crm/opportunities")
@login_required
def api_crm_opps():
    stage      = request.args.get("stage")
    search     = request.args.get("search")
    contact_id = request.args.get("contact_id", type=int)
    rows = get_opportunities(db(), stage=stage or None, search=search or None,
                             contact_id=contact_id or None)
    return ok(rows)


@bp.route("/api/crm/opportunities/<int:oid>")
@login_required
def api_crm_opp(oid):
    opp = get_opportunity(db(), oid)
    if not opp:
        return err("Not found", 404)
    comms  = get_communications(db(), opp_id=oid)
    tasks  = get_tasks(db(), opp_id=oid, open_only=False)
    quotes = get_quotes(db(), opp_id=oid)
    claims = get_progress_claims(db(), opp_id=oid)
    return ok({"opp": opp, "comms": comms, "tasks": tasks,
               "quotes": quotes, "claims": claims})


@bp.route("/api/crm/opportunities", methods=["POST"])
@login_required
def api_crm_opp_save():
    data = request.get_json() or {}
    try:
        if not data.get("opp_number"):
            data["opp_number"] = next_opp_number(db())
        data["created_by"] = current_user().get("id")
        oid = save_opportunity(db(), data)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "SaveOpportunity", "crm_opportunity", oid, data.get("title",""))
        return ok({"id": oid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/opportunities/<int:oid>", methods=["PUT"])
@login_required
def api_crm_opp_update(oid):
    data = request.get_json() or {}
    data["id"] = oid
    try:
        save_opportunity(db(), data)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "UpdateOpportunity", "crm_opportunity", oid, data.get("title",""))
        return ok({"id": oid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/opportunities/<int:oid>", methods=["DELETE"])
@login_required
def api_crm_opp_delete(oid):
    try:
        delete_opportunity(db(), oid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/next-opp-number")
@login_required
def api_crm_next_opp_number():
    return ok(next_opp_number(db()))


@bp.route("/api/crm/opportunities/<int:oid>/transactions")
@login_required
def api_crm_opp_transactions(oid):
    opp = get_opportunity(db(), oid)
    if not opp:
        return err("Not found", 404)

    invoices = get_invoices(db(), opp_id=oid)
    bills    = get_bills(db(),    opp_id=oid)

    rows = []
    for inv in invoices:
        rows.append({
            "type":        "Invoice",
            "id":          inv["id"],
            "number":      inv.get("invoice_number") or "",
            "date":        inv.get("invoice_date")   or "",
            "due_date":    inv.get("due_date")        or "",
            "status":      inv.get("status")          or "",
            "total":       float(inv.get("total")     or 0),
            "balance_due": round(float(inv.get("total") or 0)
                                 - float(inv.get("amount_paid") or 0), 2),
            "contact_name": inv.get("contact_name")  or "",
        })
    for bill in bills:
        rows.append({
            "type":        "Bill",
            "id":          bill["id"],
            "number":      bill.get("bill_number")  or "",
            "date":        bill.get("bill_date")    or "",
            "due_date":    bill.get("due_date")      or "",
            "status":      bill.get("status")        or "",
            "total":       float(bill.get("total")  or 0),
            "balance_due": round(float(bill.get("total") or 0)
                                 - float(bill.get("amount_paid") or 0), 2),
            "contact_name": bill.get("contact_name") or "",
        })

    rows.sort(key=lambda r: (r["date"] or ""), reverse=True)
    return ok(rows)


# ── CRM Communications ─────────────────────────────────────────────────────────

@bp.route("/api/crm/communications", methods=["POST"])
@login_required
def api_crm_comm_save():
    data = request.get_json() or {}
    data["logged_by"] = current_user().get("id")
    try:
        cid = save_communication(db(), data)
        return ok({"id": cid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/communications/<int:cid>", methods=["DELETE"])
@login_required
def api_crm_comm_delete(cid):
    try:
        delete_communication(db(), cid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── CRM Tasks ─────────────────────────────────────────────────────────────────

@bp.route("/api/crm/tasks", methods=["POST"])
@login_required
def api_crm_task_save():
    data = request.get_json() or {}
    try:
        tid = save_task(db(), data)
        return ok({"id": tid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/tasks/<int:tid>/complete", methods=["POST"])
@login_required
def api_crm_task_complete(tid):
    try:
        complete_task(db(), tid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/tasks/<int:tid>", methods=["DELETE"])
@login_required
def api_crm_task_delete(tid):
    try:
        delete_task(db(), tid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/tasks/<int:tid>", methods=["PATCH"])
@login_required
def api_crm_task_patch(tid):
    """Link an orphan task to a job."""
    data = request.get_json() or {}
    job_id = data.get("job_id")
    if job_id is None:
        return err("job_id required")
    try:
        link_work_task_to_job(db(), tid, int(job_id))
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/orphan-tasks")
@login_required
def api_job_orphan_tasks(jid):
    """Open tasks for the job's contact that aren't yet linked to any job."""
    job = get_job(db(), jid)
    if not job:
        return err("Job not found", 404)
    contact_id = dict(job).get("contact_id")
    if not contact_id:
        return ok([])
    try:
        return ok(get_orphan_tasks(db(), contact_id))
    except Exception as e:
        return err(str(e))


# ── Standalone Quotes list ────────────────────────────────────────────────────

@bp.route("/api/quotes")
@login_required
def api_quotes_all():
    """Return all quotes regardless of opportunity, enriched with contact/opp names."""
    quotes = get_quotes(db())
    contacts = {c["id"]: c["name"] for c in get_contacts(db())}
    result = []
    for q in quotes:
        q = dict(q)
        q["contact_name"] = contacts.get(q.get("contact_id"), "—")
        result.append(q)
    return ok(result)


@bp.route("/api/crm/quotes/<int:qid>/pdf")
@login_required
def api_crm_quote_pdf(qid):
    try:
        from core.quote_pdf import generate_quote_pdf
        import tempfile
        watermark = _get_pdf_watermark()
        footer    = _get_combined_pdf_footer(db())
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
            tmp_path = tmp.name
        generate_quote_pdf(db(), qid, output_path=tmp_path, watermark=watermark, footer=footer)
        q, _ = get_quote(db(), qid)
        fname = f"Quote-{q['quote_number']}.pdf" if q else "quote.pdf"
        response = send_file(tmp_path, mimetype="application/pdf",
                             as_attachment=True, download_name=fname)
        @response.call_on_close
        def _cleanup():
            try: os.unlink(tmp_path)
            except: pass
        return response
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/quotes/<int:qid>/email", methods=["POST"])
@login_required
def api_crm_quote_email(qid):
    from core.email_invoice import send_pdf_email
    data = request.get_json() or {}
    to_email = (data.get("to") or "").strip()
    if not to_email:
        return err("Recipient email is required", 400)
    q, _ = get_quote(db(), qid)
    if not q:
        return err("Quote not found", 404)
    from core.quote_pdf import generate_quote_pdf
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
            tmp_path = tmp.name
        generate_quote_pdf(db(), qid, output_path=tmp_path,
                           watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db()))
        subject = data.get("subject") or f"Quote {q.get('quote_number','')} from {q.get('contact_name','')}"
        body    = data.get("body") or f"Please find attached quote {q.get('quote_number','')}.\n\nThank you."
        ok_flag, msg = send_pdf_email(db(), tmp_path, to_email, subject, body)
        if not ok_flag:
            return err(msg)
        log_email_activity(db(), q.get("contact_id"), subject, body)
        return ok()
    except Exception as e:
        return err(str(e))
    finally:
        if tmp_path:
            try: os.unlink(tmp_path)
            except Exception: pass


# ── CRM Quotes ────────────────────────────────────────────────────────────────

@bp.route("/api/crm/quotes/<int:qid>")
@login_required
def api_crm_quote(qid):
    q, lines = get_quote(db(), qid)
    if not q:
        return err("Not found", 404)
    return ok({"quote": q, "lines": lines})


@bp.route("/api/crm/quotes", methods=["POST"])
@login_required
def api_crm_quote_save():
    body = request.get_json() or {}
    qdata = body.get("quote", {})
    lines = body.get("lines", [])
    if not qdata.get("quote_number"):
        qdata["quote_number"] = next_quote_number(db())
    qdata["created_by"] = current_user().get("id")
    try:
        qid = save_quote(db(), qdata, lines)
        return ok({"id": qid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/quotes/<int:qid>", methods=["PUT"])
@login_required
def api_crm_quote_update(qid):
    body = request.get_json() or {}
    qdata = body.get("quote", {})
    lines = body.get("lines", [])
    qdata["id"] = qid
    try:
        save_quote(db(), qdata, lines)
        return ok({"id": qid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/quotes/<int:qid>/accept", methods=["POST"])
@login_required
def api_crm_quote_accept(qid):
    try:
        opp_id = accept_quote(db(), qid, current_user().get("username",""))
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "AcceptQuote", "crm_quote", qid, "")
        return ok({"opp_id": opp_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/quotes/<int:qid>/convert", methods=["POST"])
@login_required
def api_crm_quote_convert(qid):
    try:
        inv_id = convert_quote_to_invoice(db(), qid, current_user().get("id"))
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "ConvertQuoteToInvoice", "crm_quote", qid, f"inv={inv_id}")
        return ok({"invoice_id": inv_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/quotes/<int:qid>", methods=["DELETE"])
@login_required
def api_crm_quote_delete(qid):
    try:
        delete_quote(db(), qid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── CRM Progress Claims ───────────────────────────────────────────────────────

@bp.route("/api/crm/claims", methods=["POST"])
@login_required
def api_crm_claim_save():
    data = request.get_json() or {}
    data["created_by"] = current_user().get("id")
    try:
        cid = save_progress_claim(db(), data)
        return ok({"id": cid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/claims/<int:cid>", methods=["PUT"])
@login_required
def api_crm_claim_update(cid):
    data = request.get_json() or {}
    try:
        if "status" in data and len(data) == 1:
            update_claim_status(db(), cid, data["status"])
        else:
            data["id"] = cid
            save_progress_claim(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/claims/<int:cid>/convert", methods=["POST"])
@login_required
def api_crm_claim_convert(cid):
    try:
        inv_id = claim_to_invoice(db(), cid, current_user().get("id"))
        return ok({"invoice_id": inv_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/claims/<int:cid>/link-invoice", methods=["POST"])
@login_required
def api_crm_claim_link_invoice(cid):
    data = request.get_json() or {}
    inv_id = data.get("invoice_id")
    if not inv_id:
        return err("invoice_id required")
    try:
        link_invoice_to_claim(db(), cid, inv_id)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/claims/<int:cid>", methods=["DELETE"])
@login_required
def api_crm_claim_delete(cid):
    try:
        delete_progress_claim(db(), cid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── Recurring ──────────────────────────────────────────────────────────────────

@bp.route("/api/recurring")
@login_required
def api_recurring():
    templates = get_templates(db())
    return ok([dict(t) for t in templates])


@bp.route("/api/recurring/upcoming")
@login_required
def api_recurring_upcoming():
    days = max(1, min(365, int(request.args.get("days", 30) or 30)))
    return ok([dict(t) for t in get_upcoming(db(), days=days)])


@bp.route("/api/recurring/<int:tid>")
@login_required
def api_recurring_template(tid):
    import json as _json
    t = get_template(db(), tid)
    if not t:
        return err("Not found", 404)
    if t.get("lines_json"):
        try:
            lines = _json.loads(t["lines_json"])
            if lines:
                conn = get_connection(db())
                accts = {r["id"]: r for r in conn.execute(
                    "SELECT id, code, name FROM accounts").fetchall()}
                conn.close()
                for ln in lines:
                    aid = ln.get("account_id")
                    if aid and aid in accts:
                        a = accts[aid]
                        ln["account_name"] = ((a["code"] + " ") if a["code"] else "") + a["name"]
            t["lines_json"] = lines
        except Exception:
            t["lines_json"] = []
    return ok(t)


@bp.route("/api/recurring", methods=["POST"])
@login_required
def api_recurring_save():
    data = request.get_json() or {}
    try:
        tid = save_template(db(), data)
        return ok({"id": tid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/recurring/<int:tid>", methods=["DELETE"])
@login_required
def api_recurring_delete(tid):
    try:
        delete_template(db(), tid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/recurring/<int:tid>", methods=["PUT"])
@login_required
def api_recurring_update(tid):
    data = request.get_json() or {}
    data["id"] = tid
    try:
        save_template(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/recurring/process", methods=["POST"])
@login_required
def api_recurring_process():
    data = request.get_json() or {}
    try:
        results = process_due_templates(
            db(), as_of=data.get("as_of") or str(date.today()))
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "ProcessRecurring", "recurring", None,
              f"{len(results)} templates processed")
        return ok(results)
    except Exception as e:
        return err(str(e))


@bp.route("/api/recurring/<int:tid>/runs")
@login_required
def api_recurring_runs(tid):
    return ok([dict(r) for r in get_runs(db(), tid)])
