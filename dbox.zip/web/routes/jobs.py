from datetime import date
from flask import Blueprint, request, jsonify

from web.shared import db, ok, err, login_required, current_user
from core.jobs import (
    get_jobs, get_job, save_job, delete_job, get_job_pl, get_job_transactions,
    allocate_transaction, deallocate_transaction,
    get_unallocated_invoices, get_unallocated_bills, get_unallocated_payments,
    next_job_number, get_job_time_entries, save_job_time_entry, delete_job_time_entry,
)
from core.recurring import (
    get_templates, get_template, save_template, delete_template,
    get_upcoming, get_runs, process_due_templates,
)
from core.database import get_connection
from core.budget import audit

bp = Blueprint('jobs', __name__)


@bp.route("/api/jobs")
@login_required
def api_jobs():
    return ok([dict(j) for j in get_jobs(db())])


@bp.route("/api/jobs/<int:jid>")
@login_required
def api_job(jid):
    job = get_job(db(), jid)
    if not job:
        return err("Not found", 404)
    pl = get_job_pl(db(), jid)
    txns = get_job_transactions(db(), jid)
    return ok({"job": dict(job), "pl": pl, "transactions": [dict(t) for t in txns]})


@bp.route("/api/jobs", methods=["POST"])
@login_required
def api_job_save():
    data = request.get_json() or {}
    try:
        jid = save_job(db(), data)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "SaveJob", "job", jid, data.get("name",""))
        return ok({"id": jid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>", methods=["DELETE"])
@login_required
def api_job_delete(jid):
    try:
        delete_job(db(), jid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/<int:jid>/allocate", methods=["POST"])
@login_required
def api_job_allocate(jid):
    d = request.get_json() or {}
    try:
        allocate_transaction(db(), jid, d["source_type"], d["source_id"],
                             float(d.get("amount", 0)),
                             d.get("notes",""),
                             current_user().get("id"))
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/allocations/<int:alloc_id>", methods=["DELETE"])
@login_required
def api_job_deallocate(alloc_id):
    try:
        conn = get_connection(db())
        row = conn.execute(
            "SELECT job_id, source_type, source_id FROM job_transactions WHERE id=?",
            (alloc_id,)).fetchone()
        conn.close()
        if not row:
            return err("Allocation not found", 404)
        deallocate_transaction(db(), row["job_id"], row["source_type"], row["source_id"])
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/unallocated")
@login_required
def api_unallocated():
    invs  = get_unallocated_invoices(db())
    bills = get_unallocated_bills(db())
    pmts  = get_unallocated_payments(db())
    return ok({
        "invoices": [dict(i) for i in invs],
        "bills":    [dict(b) for b in bills],
        "payments": [dict(p) for p in pmts],
    })


@bp.route("/api/jobs/next-number")
@login_required
def api_job_next_number():
    return ok(next_job_number(db()))


@bp.route("/api/jobs/<int:jid>/time")
@login_required
def api_job_time_list(jid):
    return ok([dict(e) for e in get_job_time_entries(db(), jid)])


@bp.route("/api/jobs/<int:jid>/time/<int:eid>")
@login_required
def api_job_time_get(jid, eid):
    entries = get_job_time_entries(db(), jid)
    row = next((e for e in entries if e["id"] == eid), None)
    if not row:
        return err("Not found", 404)
    return ok(dict(row))


@bp.route("/api/jobs/<int:jid>/time", methods=["POST"])
@login_required
def api_job_time_save(jid):
    data = request.get_json() or {}
    data["job_id"] = jid
    try:
        eid = save_job_time_entry(db(), data)
        return ok({"id": eid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/jobs/time/<int:eid>", methods=["DELETE"])
@login_required
def api_job_time_delete(eid):
    try:
        delete_job_time_entry(db(), eid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── Recurring ──────────────────────────────────────────────────────────────────

@bp.route("/api/recurring")
@login_required
def api_recurring():
    templates = get_templates(db())
    return ok([dict(t) for t in templates])


@bp.route("/api/recurring/upcoming")
@login_required
def api_recurring_upcoming():
    days = max(1, min(365, int(request.args.get("days", 30) or 30)))
    return ok([dict(t) for t in get_upcoming(db(), days=days)])


@bp.route("/api/recurring/<int:tid>")
@login_required
def api_recurring_template(tid):
    t = get_template(db(), tid)
    return ok(dict(t)) if t else err("Not found", 404)


@bp.route("/api/recurring", methods=["POST"])
@login_required
def api_recurring_save():
    data = request.get_json() or {}
    try:
        tid = save_template(db(), data)
        return ok({"id": tid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/recurring/<int:tid>", methods=["DELETE"])
@login_required
def api_recurring_delete(tid):
    try:
        delete_template(db(), tid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/recurring/<int:tid>", methods=["PUT"])
@login_required
def api_recurring_update(tid):
    data = request.get_json() or {}
    data["id"] = tid
    try:
        save_template(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/recurring/process", methods=["POST"])
@login_required
def api_recurring_process():
    data = request.get_json() or {}
    try:
        results = process_due_templates(
            db(), as_of=data.get("as_of") or str(date.today()))
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "ProcessRecurring", "recurring", None,
              f"{len(results)} templates processed")
        return ok(results)
    except Exception as e:
        return err(str(e))


@bp.route("/api/recurring/<int:tid>/runs")
@login_required
def api_recurring_runs(tid):
    return ok([dict(r) for r in get_runs(db(), tid)])
