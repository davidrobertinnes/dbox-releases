import tempfile
import os
from datetime import date
from flask import Blueprint, request, send_file

from web.shared import db, ok, err, login_required, current_user, dict_rows
from core.ledger import (
    get_invoices, get_invoice, save_invoice, void_invoice, mark_invoice_sent,
    get_contacts, record_payment,
)
from core.budget import audit

bp = Blueprint('invoices', __name__)


@bp.route("/api/invoices")
@login_required
def api_invoices():
    invs = get_invoices(db())
    contacts = {c["id"]: c["name"] for c in get_contacts(db())}
    result = []
    for i in dict_rows(invs):
        i["contact_name"] = contacts.get(i.get("contact_id"), "—")
        i["total_amount"] = i.get("total", 0)
        i["invoice_date"] = i.get("invoice_date") or i.get("created_at", "")[:10]
        result.append(i)
    return ok(result)


@bp.route("/api/invoices/<int:iid>")
@login_required
def api_invoice(iid):
    data = get_invoice(db(), iid)
    if not data:
        return err("Not found", 404)
    inv   = dict(data["invoice"])
    lines = [dict(l) for l in data["lines"]]
    contacts = {c["id"]: c["name"] for c in get_contacts(db())}
    inv["contact_name"] = contacts.get(inv.get("contact_id"), "—")
    return ok({"invoice": inv, "lines": lines})


@bp.route("/api/invoices/<int:iid>", methods=["PUT"])
@login_required
def api_invoice_update(iid):
    data = request.get_json() or {}
    data["id"] = iid
    try:
        save_invoice(db(), data, data.get("lines", []))
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/invoices/<int:iid>/void", methods=["POST"])
@login_required
def api_invoice_void(iid):
    try:
        void_invoice(db(), iid)
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "VoidInvoice", "invoices", iid, "voided via web")
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/invoices/<int:iid>/mark-sent", methods=["POST"])
@login_required
def api_invoice_mark_sent(iid):
    try:
        mark_invoice_sent(db(), iid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/invoices/<int:iid>/pdf", methods=["GET"])
@login_required
def api_invoice_pdf(iid):
    try:
        from core.invoice_pdf import generate_invoice_pdf
        inv_data = get_invoice(db(), iid)
        if not inv_data:
            return err("Invoice not found", 404)
        inv = inv_data["invoice"]
        num = inv.get("invoice_number") or f"INV-{iid}"
        tmp = tempfile.mktemp(suffix=".pdf", prefix=f"{num}_")
        generate_invoice_pdf(db(), iid, tmp)
        return send_file(tmp, mimetype="application/pdf",
                         as_attachment=True,
                         download_name=f"{num}.pdf")
    except Exception as e:
        return err(str(e))


@bp.route("/api/invoices/<int:iid>/email", methods=["POST"])
@login_required
def api_invoice_email(iid):
    from core.email_invoice import send_invoice_email
    from core.invoice_pdf import generate_invoice_pdf
    data = request.get_json() or {}
    to_email = (data.get("to") or "").strip()
    if not to_email:
        return err("Recipient email is required", 400)
    inv_data = get_invoice(db(), iid)
    if not inv_data:
        return err("Invoice not found", 404)
    inv = inv_data["invoice"]
    num = inv.get("invoice_number") or f"INV-{iid}"
    tmp = tempfile.mktemp(suffix=".pdf", prefix=f"{num}_")
    try:
        generate_invoice_pdf(db(), iid, tmp)
        ok_flag, msg = send_invoice_email(
            db(), iid, tmp, to_email,
            subject_override=data.get("subject") or None,
            body_override=data.get("body") or None,
        )
        if not ok_flag:
            return err(msg)
        return ok()
    except Exception as e:
        return err(str(e))
    finally:
        try: os.unlink(tmp)
        except Exception: pass


@bp.route("/api/invoices/<int:iid>/payment", methods=["POST"])
@login_required
def api_invoice_payment(iid):
    data = request.get_json() or {}
    try:
        inv_data = get_invoice(db(), iid)
        if not inv_data:
            return err("Invoice not found", 404)
        inv = inv_data["invoice"]
        pid = record_payment(db(), {
            "payment_type":    "Receipt",
            "contact_id":      inv.get("contact_id"),
            "payment_date":    data.get("payment_date", str(date.today())),
            "amount":          float(data.get("amount", 0)),
            "bank_account_id": data.get("account_id"),
            "reference":       data.get("reference", ""),
            "description":     f"Invoice payment — {inv.get('invoice_number', '')}",
        }, [{"invoice_id": iid, "amount": float(data.get("amount", 0))}])
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "RecordPayment", "invoices", iid,
              f"amount={data.get('amount')} ref={data.get('reference', '')}")
        return ok({"id": pid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/invoices", methods=["POST"])
@login_required
def api_invoice_save():
    data = request.get_json() or {}
    try:
        iid = save_invoice(db(), data, data.get("lines", []))
        return ok({"id": iid})
    except Exception as e:
        return err(str(e))
