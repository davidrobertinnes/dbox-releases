# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import tempfile
import os
from datetime import date
from flask import Blueprint, request, send_file

from flask import jsonify
from web.shared import db, ok, err, login_required, tier_required, current_user, dict_rows, _get_pdf_watermark, _get_combined_pdf_footer
from core.ledger import (
    get_invoices, get_invoice, save_invoice, void_invoice, mark_invoice_sent,
    approve_invoice, get_contacts, record_payment, write_off_invoice, copy_invoice,
    create_credit_note, get_unapplied_credits, apply_credit_note,
)
from core.inventory import OversellError
from core.backorders import create_backorder
from core.jobs import get_job_for_invoice, get_job, set_invoice_job, get_jobs
from core.budget import audit
from core.jobs import get_communications, log_email_activity, get_work_tasks, stamp_task_invoice

bp = Blueprint('invoices', __name__)


@bp.route("/api/invoices")
@login_required
def api_invoices():
    invs = get_invoices(db())
    contacts = {c["id"]: c["name"] for c in get_contacts(db())}
    result = []
    for i in dict_rows(invs):
        i["contact_name"] = contacts.get(i.get("contact_id"), "—")
        i["total_amount"] = i.get("total", 0)
        i["invoice_date"] = i.get("invoice_date") or i.get("created_at", "")[:10]
        result.append(i)
    return ok(result)


@bp.route("/api/invoices/<int:iid>")
@login_required
def api_invoice(iid):
    data = get_invoice(db(), iid)
    if not data:
        return err("Not found", 404)
    inv   = dict(data["invoice"])
    lines = [dict(l) for l in data["lines"]]
    contacts = {c["id"]: c["name"] for c in get_contacts(db())}
    inv["contact_name"] = contacts.get(inv.get("contact_id"), "—")
    job_id = get_job_for_invoice(db(), iid)
    inv["job_id"] = job_id
    if job_id:
        job = get_job(db(), job_id)
        inv["job_name"] = f"{job['job_number']}  {job['name']}" if job else None
    else:
        inv["job_name"] = None
    from core.database import get_connection
    conn = get_connection(db())
    if inv.get("source_invoice_id"):
        src = conn.execute(
            "SELECT invoice_number FROM invoices WHERE id=?",
            (inv["source_invoice_id"],)).fetchone()
        inv["source_invoice_number"] = src["invoice_number"] if src else None
    else:
        inv["source_invoice_number"] = None
    credit_notes = conn.execute(
        "SELECT id, invoice_number, total, invoice_date FROM invoices "
        "WHERE source_invoice_id=? AND is_credit_note=1",
        (iid,)).fetchall()
    inv["credit_notes"] = [dict(cn) for cn in credit_notes]
    conn.close()
    return ok({"invoice": inv, "lines": lines})


@bp.route("/api/work-tasks/uninvoiced")
@login_required
def api_work_tasks_uninvoiced():
    contact_id = request.args.get('contact_id', type=int)
    tasks = get_work_tasks(db(), contact_id=contact_id, uninvoiced_only=True)
    return ok(tasks)


@bp.route("/api/invoices/<int:iid>", methods=["PUT"])
@login_required
def api_invoice_update(iid):
    data = request.get_json() or {}
    data["id"] = iid
    task_ids = data.pop("task_ids", [])
    job_id = data.pop("job_id", -1)
    allow_backorder = data.pop("allow_backorder", False)
    backorder_items = data.pop("backorder_items", [])
    if allow_backorder:
        data["allow_negative_stock"] = True
    try:
        save_invoice(db(), data, data.get("lines", []))
        if allow_backorder and backorder_items:
            inv_date = data.get("invoice_date") or str(date.today())
            for item in backorder_items:
                create_backorder(db(), iid, item["item_id"],
                                 item.get("item_code", ""), item.get("item_name", ""),
                                 float(item["qty"]), inv_date)
        if task_ids:
            stamp_task_invoice(db(), iid, task_ids)
        if job_id != -1:
            set_invoice_job(db(), iid, job_id if job_id else None)
        return ok()
    except OversellError as e:
        return jsonify({"ok": False, "oversell": True, "items": e.items}), 422
    except Exception as e:
        return err(str(e))


@bp.route("/api/invoices/<int:iid>/void", methods=["POST"])
@login_required
def api_invoice_void(iid):
    try:
        void_invoice(db(), iid)
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "VoidInvoice", "invoices", iid, "voided via web")
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/invoices/<int:iid>/approve", methods=["POST"])
@login_required
def api_invoice_approve(iid):
    try:
        approve_invoice(db(), iid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/invoices/<int:iid>/mark-sent", methods=["POST"])
@login_required
def api_invoice_mark_sent(iid):
    try:
        mark_invoice_sent(db(), iid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/invoices/<int:iid>/pdf", methods=["GET"])
@login_required
def api_invoice_pdf(iid):
    try:
        from core.invoice_pdf import generate_invoice_pdf
        inv_data = get_invoice(db(), iid)
        if not inv_data:
            return err("Invoice not found", 404)
        inv = inv_data["invoice"]
        num = inv.get("invoice_number") or f"INV-{iid}"
        tmp = tempfile.mktemp(suffix=".pdf", prefix=f"{num}_")
        generate_invoice_pdf(db(), iid, tmp, watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db()))
        return send_file(tmp, mimetype="application/pdf",
                         as_attachment=True,
                         download_name=f"{num}.pdf")
    except Exception as e:
        return err(str(e))


@bp.route("/api/invoices/<int:iid>/email", methods=["POST"])
@login_required
@tier_required("email_docs")
def api_invoice_email(iid):
    from core.email_invoice import send_invoice_email
    from core.invoice_pdf import generate_invoice_pdf
    data = request.get_json() or {}
    to_email = (data.get("to") or "").strip()
    if not to_email:
        return err("Recipient email is required", 400)
    inv_data = get_invoice(db(), iid)
    if not inv_data:
        return err("Invoice not found", 404)
    inv = inv_data["invoice"]
    num = inv.get("invoice_number") or f"INV-{iid}"
    tmp = tempfile.mktemp(suffix=".pdf", prefix=f"{num}_")
    try:
        generate_invoice_pdf(db(), iid, tmp, watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db()))
        subject = data.get("subject") or None
        body    = data.get("body") or None
        ok_flag, msg = send_invoice_email(db(), iid, tmp, to_email,
                                          subject_override=subject,
                                          body_override=body)
        if not ok_flag:
            return err(msg)
        log_email_activity(db(), inv.get("contact_id"), subject or f"Invoice {num}",
                           body or "", invoice_id=iid)
        if inv.get("status") == "Approved":
            mark_invoice_sent(db(), iid)
        return ok()
    except Exception as e:
        return err(str(e))
    finally:
        try: os.unlink(tmp)
        except Exception: pass


@bp.route("/api/invoices/<int:iid>/overdue-notice", methods=["POST"])
@login_required
@tier_required("email_docs")
def api_invoice_overdue_notice(iid):
    from core.email_invoice import send_overdue_notice
    data = request.get_json() or {}
    to_email = (data.get("to") or "").strip()
    if not to_email:
        return err("Recipient email is required", 400)
    inv_data = get_invoice(db(), iid)
    if not inv_data:
        return err("Invoice not found", 404)
    inv = inv_data["invoice"]
    subject = data.get("subject") or None
    body    = data.get("body") or None
    ok_flag, msg = send_overdue_notice(db(), iid, to_email,
                                       subject_override=subject,
                                       body_override=body)
    if not ok_flag:
        return err(msg)
    log_email_activity(db(), inv.get("contact_id"),
                       subject or f"Overdue notice — {inv.get('invoice_number','')}",
                       body or "", invoice_id=iid)
    return ok()


@bp.route("/api/invoices/<int:iid>/activity")
@login_required
def api_invoice_activity(iid):
    rows = get_communications(db(), invoice_id=iid)
    return ok(rows)


@bp.route("/api/invoices/<int:iid>/suppress-stamp", methods=["POST"])
@login_required
def api_invoice_suppress_stamp(iid):
    from core.database import get_connection
    data = request.get_json() or {}
    suppress = 1 if data.get("suppress") else 0
    conn = get_connection(db())
    conn.execute("UPDATE invoices SET overdue_suppress=? WHERE id=?", (suppress, iid))
    conn.commit()
    conn.close()
    return ok()


@bp.route("/api/invoices/<int:iid>/payment", methods=["POST"])
@login_required
def api_invoice_payment(iid):
    data = request.get_json() or {}
    try:
        inv_data = get_invoice(db(), iid)
        if not inv_data:
            return err("Invoice not found", 404)
        inv = inv_data["invoice"]
        pid = record_payment(db(), {
            "payment_type":    "Receipt",
            "contact_id":      inv.get("contact_id"),
            "payment_date":    data.get("payment_date", str(date.today())),
            "amount":          float(data.get("amount", 0)),
            "bank_account_id": data.get("account_id"),
            "reference":       data.get("reference", ""),
            "description":     f"Invoice payment — {inv.get('invoice_number', '')}",
        }, [{"invoice_id": iid, "amount": float(data.get("amount", 0))}])
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "RecordPayment", "invoices", iid,
              f"amount={data.get('amount')} ref={data.get('reference', '')}")
        return ok({"id": pid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/invoices/<int:iid>/copy", methods=["POST"])
@login_required
def api_invoice_copy(iid):
    try:
        new_id = copy_invoice(db(), iid)
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "CopyInvoice", "invoices", iid, f"new_id={new_id}")
        return ok({"id": new_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/invoices/<int:iid>/write-off", methods=["GET"])
@login_required
def api_invoice_write_off_preview(iid):
    inv_data = get_invoice(db(), iid)
    if not inv_data:
        return err("Invoice not found", 404)
    inv         = inv_data["invoice"]
    total       = float(inv.get("total") or 0)
    amount_paid = float(inv.get("amount_paid") or 0)
    outstanding = round(total - amount_paid, 2)
    gst_total   = float(inv.get("gst_total") or 0)
    gst_component = round(outstanding * (gst_total / total), 2) if total > 0 else 0.0
    net_component = round(outstanding - gst_component, 2)
    return ok({
        "outstanding":    outstanding,
        "net_component":  net_component,
        "gst_component":  gst_component,
    })


@bp.route("/api/invoices/<int:iid>/write-off", methods=["POST"])
@login_required
def api_invoice_write_off(iid):
    data = request.get_json() or {}
    account_id    = data.get("write_off_account_id")
    memo          = (data.get("memo") or "").strip()
    mark_inactive = bool(data.get("mark_contact_inactive"))
    reason        = (data.get("inactive_reason") or "").strip() or None
    if not account_id:
        return err("Write-off account is required", 400)
    if not memo:
        return err("Memo is required", 400)
    try:
        jid = write_off_invoice(db(), iid, account_id, memo,
                                mark_contact_inactive=mark_inactive,
                                inactive_reason=reason)
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "WriteOffInvoice", "invoices", iid, f"memo={memo} jid={jid}")
        return ok({"journal_id": jid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/invoices", methods=["POST"])
@login_required
def api_invoice_save():
    data = request.get_json() or {}
    task_ids = data.pop("task_ids", [])
    job_id = data.pop("job_id", None)
    allow_backorder = data.pop("allow_backorder", False)
    backorder_items = data.pop("backorder_items", [])
    if allow_backorder:
        data["allow_negative_stock"] = True
    try:
        iid = save_invoice(db(), data, data.get("lines", []))
        if allow_backorder and backorder_items:
            inv_date = data.get("invoice_date") or str(date.today())
            for item in backorder_items:
                create_backorder(db(), iid, item["item_id"],
                                 item.get("item_code", ""), item.get("item_name", ""),
                                 float(item["qty"]), inv_date)
        if task_ids:
            stamp_task_invoice(db(), iid, task_ids)
        if job_id:
            set_invoice_job(db(), iid, job_id)
        return ok({"id": iid})
    except OversellError as e:
        return jsonify({"ok": False, "oversell": True, "items": e.items}), 422
    except Exception as e:
        return err(str(e))


@bp.route("/api/invoices/<int:iid>/credit-note", methods=["GET"])
@login_required
def api_credit_note_preview(iid):
    data = get_invoice(db(), iid)
    if not data:
        return err("Not found", 404)
    inv = dict(data["invoice"])
    lines = [dict(l) for l in data["lines"]]
    contacts = {c["id"]: c["name"] for c in get_contacts(db())}
    inv["contact_name"] = contacts.get(inv.get("contact_id"), "—")
    total = float(inv.get("total") or 0)
    outstanding = round(total - float(inv.get("amount_paid") or 0), 2)
    return ok({"invoice": inv, "lines": lines, "outstanding": outstanding,
               "invoice_total": total})


@bp.route("/api/contacts/<int:cid>/available-credits")
@login_required
def api_available_credits(cid):
    credits = get_unapplied_credits(db(), cid)
    return ok(credits)


@bp.route("/api/invoices/<int:iid>/apply-credit", methods=["POST"])
@login_required
def api_apply_credit(iid):
    data = request.get_json() or {}
    cn_id  = data.get("cn_id")
    amount = data.get("amount")
    if not cn_id or amount is None:
        return err("cn_id and amount are required", 400)
    try:
        applied = apply_credit_note(db(), int(cn_id), iid, float(amount))
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "ApplyCredit", "invoices", iid, f"cn_id={cn_id} amount={applied}")
        return ok({"applied": applied})
    except Exception as e:
        return err(str(e))


@bp.route("/api/invoices/<int:iid>/credit-note", methods=["POST"])
@login_required
def api_credit_note_create(iid):
    data = request.get_json() or {}
    lines = data.get("lines", [])
    note_date = data.get("date", str(date.today()))
    memo = (data.get("memo") or "").strip()
    if not lines:
        return err("At least one line is required", 400)
    if not memo:
        return err("Reason / memo is required", 400)
    try:
        cn_id = create_credit_note(db(), iid, lines, note_date, memo)
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "CreateCreditNote", "invoices", iid, f"cn_id={cn_id} memo={memo}")
        return ok({"id": cn_id})
    except Exception as e:
        return err(str(e))
