# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import os
import json as _json
import urllib.request
import urllib.parse
from flask import Blueprint, request, send_file

from web.shared import db, ok, err, login_required, _get_pdf_watermark, _get_combined_pdf_footer
from core.ledger import get_contacts, save_contact, merge_contacts
from core.reports_pdf import render_statement_of_account_pdf
from core.database import get_connection
from core.jobs import get_work_tasks, save_work_task, complete_work_task, delete_work_task, invoice_work_tasks, log_email_activity, get_contact_crm_tasks

bp = Blueprint('contacts', __name__)


def _contacts_with_employee_flag(db_path):
    conn = get_connection(db_path)
    rows = conn.execute("SELECT * FROM contacts ORDER BY name").fetchall()
    emp_contact_ids = {r[0] for r in conn.execute(
        "SELECT contact_id FROM employees "
        "WHERE contact_id IS NOT NULL AND (termination_date IS NULL OR termination_date='')"
    ).fetchall()}
    conn.close()
    result = []
    for row in rows:
        d = dict(row)
        d["has_employee"] = 1 if d["id"] in emp_contact_ids else 0
        result.append(d)
    return result


@bp.route("/api/contacts")
@login_required
def api_contacts():
    return ok(_contacts_with_employee_flag(db()))


@bp.route("/api/contacts", methods=["POST"])
@login_required
def api_contact_save():
    data = request.get_json() or {}
    try:
        cid = save_contact(db(), data)
        return ok({"id": cid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/contacts/<int:cid>")
@login_required
def api_contact(cid):
    conn = get_connection(db())
    row = conn.execute("SELECT * FROM contacts WHERE id=?", (cid,)).fetchone()
    if not row:
        conn.close()
        return err("Not found", 404)
    d = dict(row)
    emp = conn.execute(
        "SELECT id FROM employees WHERE contact_id=? "
        "AND (termination_date IS NULL OR termination_date='')", (cid,)
    ).fetchone()
    d["has_employee"] = 1 if emp else 0
    if d.get("approved_by_employee_id"):
        ae = conn.execute(
            "SELECT first_name, last_name FROM employees WHERE id=?",
            (d["approved_by_employee_id"],)
        ).fetchone()
        d["approved_by_name"] = f"{ae['first_name']} {ae['last_name']}" if ae else None
    conn.close()
    return ok(d)


@bp.route("/api/contacts/<int:cid>", methods=["PUT"])
@login_required
def api_contact_update(cid):
    data = request.get_json() or {}
    data["id"] = cid
    try:
        save_contact(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/contacts/<int:cid>/merge", methods=["POST"])
@login_required
def api_contact_merge(cid):
    data = request.get_json() or {}
    drop_id = data.get("merge_with")
    if not drop_id:
        return err("merge_with is required", 400)
    try:
        merge_contacts(db(), cid, int(drop_id))
        return ok()
    except ValueError as e:
        return err(str(e), 400)
    except Exception as e:
        return err(str(e), 500)


@bp.route("/api/contacts/<int:cid>/statement")
@login_required
def api_contact_statement(cid):
    date_from = request.args.get("date_from")
    date_to   = request.args.get("date_to")
    if not date_from or not date_to:
        return err("date_from and date_to are required", 400)
    try:
        pdf_path = render_statement_of_account_pdf(
            db(), cid, date_from, date_to, watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db())
        )
        return send_file(pdf_path, mimetype="application/pdf",
                         as_attachment=True,
                         download_name=f"statement_{cid}_{date_from}_{date_to}.pdf")
    except Exception as e:
        return err(str(e), 500)


@bp.route("/api/contacts/<int:cid>/crm-tasks")
@login_required
def api_contact_crm_tasks(cid):
    return ok(get_contact_crm_tasks(db(), cid))


@bp.route("/api/contacts/<int:cid>/work-tasks")
@login_required
def api_contact_work_tasks(cid):
    return ok(get_work_tasks(db(), contact_id=cid))


@bp.route("/api/work-tasks")
@login_required
def api_work_tasks_all():
    return ok(get_work_tasks(db()))


@bp.route("/api/work-tasks", methods=["POST"])
@login_required
def api_work_task_save():
    data = request.get_json() or {}
    if not data.get("title", "").strip():
        return err("Title is required", 400)
    try:
        tid = save_work_task(db(), data)
        return ok({"id": tid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/work-tasks/<int:tid>", methods=["PUT"])
@login_required
def api_work_task_update(tid):
    data = request.get_json() or {}
    data["id"] = tid
    if not data.get("title", "").strip():
        return err("Title is required", 400)
    try:
        save_work_task(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/work-tasks/<int:tid>/complete", methods=["POST"])
@login_required
def api_work_task_complete(tid):
    data = request.get_json(force=True, silent=True) or {}
    is_done = bool(data.get("is_done", True))
    try:
        task = complete_work_task(db(), tid, is_done)
        if is_done and task.get("is_recurring"):
            return ok({"recurring": task})
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/work-tasks/<int:tid>", methods=["DELETE"])
@login_required
def api_work_task_delete(tid):
    try:
        delete_work_task(db(), tid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/contacts/<int:cid>/work-tasks/invoice", methods=["POST"])
@login_required
def api_work_tasks_invoice(cid):
    data = request.get_json() or {}
    task_ids = data.get("task_ids", [])
    if not task_ids:
        return err("No tasks selected", 400)
    try:
        inv_id = invoice_work_tasks(db(), cid, [int(i) for i in task_ids])
        return ok({"id": inv_id})
    except Exception as e:
        return err(str(e))



@bp.route("/api/contacts/<int:cid>/statement/email", methods=["POST"])
@login_required
def api_contact_statement_email(cid):
    from core.email_invoice import send_pdf_email
    import tempfile
    data = request.get_json() or {}
    to_email  = (data.get("to") or "").strip()
    date_from = data.get("date_from", "")
    date_to   = data.get("date_to", "")
    if not to_email:
        return err("Recipient email is required", 400)
    if not date_from or not date_to:
        return err("date_from and date_to are required", 400)
    pdf_path = None
    try:
        pdf_path = render_statement_of_account_pdf(
            db(), cid, date_from, date_to, watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db())
        )
        subject = data.get("subject") or f"Statement of Account — {date_from} to {date_to}"
        body    = data.get("body") or f"Please find attached your statement of account for the period {date_from} to {date_to}."
        ok_flag, msg = send_pdf_email(db(), pdf_path, to_email, subject, body,
                                      attach_name=f"Statement {date_from} to {date_to}.pdf")
        if not ok_flag:
            return err(msg)
        log_email_activity(db(), cid, subject, body)
        return ok()
    except Exception as e:
        return err(str(e), 500)
    finally:
        if pdf_path:
            try: os.unlink(pdf_path)
            except Exception: pass


def _mailman_port():
    """The port Dogbox Mailman is running on (5200, or the next free port if that was taken)."""
    from core.ports import find_app, is_listening
    # Mailman versions before 5 Nov 2026 can't say who they are: try their fixed port
    return find_app('dogbox-mailman', 5200) or (5200 if is_listening('127.0.0.1', 5200) else None)


@bp.route('/api/contacts/<int:id>/emails')
@login_required
def api_contact_emails(id):
    conn = get_connection(db())
    row = conn.execute("SELECT email FROM contacts WHERE id=?", (id,)).fetchone()
    conn.close()
    if not row or not row['email']:
        return ok({'emails': [], 'offline': False})
    email = row['email'].strip()
    port = _mailman_port()
    if not port:
        return ok({'emails': [], 'offline': True})
    try:
        url = f'http://127.0.0.1:{port}/api/ext/emails?contact=' + urllib.parse.quote(email)
        with urllib.request.urlopen(url, timeout=2) as resp:
            data = _json.loads(resp.read())
        return ok({'emails': data.get('data', []) if data.get('ok') else [], 'offline': False})
    except Exception:
        return ok({'emails': [], 'offline': True})


@bp.route('/api/mailman/unread')
@login_required
def api_mailman_unread():
    port = _mailman_port()
    if not port:
        return ok({'unread': 0, 'offline': True})
    try:
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/api/ext/unread_count', timeout=2) as resp:
            data = _json.loads(resp.read())
        return ok({'unread': data.get('data', {}).get('unread', 0) if data.get('ok') else 0, 'offline': False})
    except Exception:
        return ok({'unread': 0, 'offline': True})


# ── External hook API (no auth, localhost trust) ───────────────────────────────

@bp.route('/api/ext/contacts')
def api_ext_contacts():
    """Mailman hook: GET /api/ext/contacts — returns slim contact list for import.
    No login (Mailman runs on the same computer), so only answer requests from this
    computer: in LAN mode the server is reachable from the whole network."""
    if (request.remote_addr or '') not in ('127.0.0.1', '::1'):
        return err('Not available from another computer', 403)
    conn = get_connection(db())
    rows = conn.execute("""
        SELECT id, name, email, phone, contact_person
        FROM contacts
        WHERE email IS NOT NULL AND email != '' AND is_active = 1
        ORDER BY name
    """).fetchall()
    conn.close()
    return ok([dict(r) for r in rows])
