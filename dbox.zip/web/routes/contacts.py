import os
from flask import Blueprint, request, send_file

from web.shared import db, ok, err, login_required
from core.ledger import get_contacts, save_contact, merge_contacts
from core.reports_pdf import render_statement_of_account_pdf
from core.database import get_connection
from core.licence import get_licence_status, watermark_text, pdf_footer_text
from core.jobs import get_work_tasks, save_work_task, complete_work_task, delete_work_task, invoice_work_tasks, log_email_activity, get_contact_crm_tasks

bp = Blueprint('contacts', __name__)


def _get_pdf_watermark() -> str | None:
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        status = get_licence_status(_app_dir)
        return watermark_text(status)
    except Exception:
        return "Unregistered"


def _get_pdf_footer() -> str | None:
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        status = get_licence_status(_app_dir)
        return pdf_footer_text(status)
    except Exception:
        return None


def _contacts_with_employee_flag(db_path):
    conn = get_connection(db_path)
    rows = conn.execute("SELECT * FROM contacts ORDER BY name").fetchall()
    emp_contact_ids = {r[0] for r in conn.execute(
        "SELECT contact_id FROM employees "
        "WHERE contact_id IS NOT NULL AND (termination_date IS NULL OR termination_date='')"
    ).fetchall()}
    conn.close()
    result = []
    for row in rows:
        d = dict(row)
        d["has_employee"] = 1 if d["id"] in emp_contact_ids else 0
        result.append(d)
    return result


@bp.route("/api/contacts")
@login_required
def api_contacts():
    return ok(_contacts_with_employee_flag(db()))


@bp.route("/api/contacts", methods=["POST"])
@login_required
def api_contact_save():
    data = request.get_json() or {}
    try:
        cid = save_contact(db(), data)
        return ok({"id": cid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/contacts/<int:cid>")
@login_required
def api_contact(cid):
    conn = get_connection(db())
    row = conn.execute("SELECT * FROM contacts WHERE id=?", (cid,)).fetchone()
    if not row:
        conn.close()
        return err("Not found", 404)
    d = dict(row)
    emp = conn.execute(
        "SELECT id FROM employees WHERE contact_id=? "
        "AND (termination_date IS NULL OR termination_date='')", (cid,)
    ).fetchone()
    d["has_employee"] = 1 if emp else 0
    conn.close()
    return ok(d)


@bp.route("/api/contacts/<int:cid>", methods=["PUT"])
@login_required
def api_contact_update(cid):
    data = request.get_json() or {}
    data["id"] = cid
    try:
        save_contact(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/contacts/<int:cid>/merge", methods=["POST"])
@login_required
def api_contact_merge(cid):
    data = request.get_json() or {}
    drop_id = data.get("merge_with")
    if not drop_id:
        return err("merge_with is required", 400)
    try:
        merge_contacts(db(), cid, int(drop_id))
        return ok()
    except ValueError as e:
        return err(str(e), 400)
    except Exception as e:
        return err(str(e), 500)


@bp.route("/api/contacts/<int:cid>/statement")
@login_required
def api_contact_statement(cid):
    date_from = request.args.get("date_from")
    date_to   = request.args.get("date_to")
    if not date_from or not date_to:
        return err("date_from and date_to are required", 400)
    try:
        pdf_path = render_statement_of_account_pdf(
            db(), cid, date_from, date_to, watermark=_get_pdf_watermark(), footer=_get_pdf_footer()
        )
        return send_file(pdf_path, mimetype="application/pdf",
                         as_attachment=True,
                         download_name=f"statement_{cid}_{date_from}_{date_to}.pdf")
    except Exception as e:
        return err(str(e), 500)


@bp.route("/api/contacts/<int:cid>/crm-tasks")
@login_required
def api_contact_crm_tasks(cid):
    return ok(get_contact_crm_tasks(db(), cid))


@bp.route("/api/contacts/<int:cid>/work-tasks")
@login_required
def api_contact_work_tasks(cid):
    return ok(get_work_tasks(db(), contact_id=cid))


@bp.route("/api/work-tasks", methods=["POST"])
@login_required
def api_work_task_save():
    data = request.get_json() or {}
    if not data.get("title", "").strip():
        return err("Title is required", 400)
    try:
        tid = save_work_task(db(), data)
        return ok({"id": tid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/work-tasks/<int:tid>", methods=["PUT"])
@login_required
def api_work_task_update(tid):
    data = request.get_json() or {}
    data["id"] = tid
    if not data.get("title", "").strip():
        return err("Title is required", 400)
    try:
        save_work_task(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/work-tasks/<int:tid>/complete", methods=["POST"])
@login_required
def api_work_task_complete(tid):
    data = request.get_json() or {}
    is_done = bool(data.get("is_done", True))
    try:
        complete_work_task(db(), tid, is_done)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/work-tasks/<int:tid>", methods=["DELETE"])
@login_required
def api_work_task_delete(tid):
    try:
        delete_work_task(db(), tid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/contacts/<int:cid>/work-tasks/invoice", methods=["POST"])
@login_required
def api_work_tasks_invoice(cid):
    data = request.get_json() or {}
    task_ids = data.get("task_ids", [])
    if not task_ids:
        return err("No tasks selected", 400)
    try:
        inv_id = invoice_work_tasks(db(), cid, [int(i) for i in task_ids])
        return ok({"id": inv_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/contacts/<int:cid>/statement/email", methods=["POST"])
@login_required
def api_contact_statement_email(cid):
    from core.email_invoice import send_pdf_email
    import tempfile
    data = request.get_json() or {}
    to_email  = (data.get("to") or "").strip()
    date_from = data.get("date_from", "")
    date_to   = data.get("date_to", "")
    if not to_email:
        return err("Recipient email is required", 400)
    if not date_from or not date_to:
        return err("date_from and date_to are required", 400)
    pdf_path = None
    try:
        pdf_path = render_statement_of_account_pdf(
            db(), cid, date_from, date_to, watermark=_get_pdf_watermark(), footer=_get_pdf_footer()
        )
        subject = data.get("subject") or f"Statement of Account — {date_from} to {date_to}"
        body    = data.get("body") or f"Please find attached your statement of account for the period {date_from} to {date_to}."
        ok_flag, msg = send_pdf_email(db(), pdf_path, to_email, subject, body)
        if not ok_flag:
            return err(msg)
        log_email_activity(db(), cid, subject, body)
        return ok()
    except Exception as e:
        return err(str(e), 500)
    finally:
        if pdf_path:
            try: os.unlink(pdf_path)
            except Exception: pass
