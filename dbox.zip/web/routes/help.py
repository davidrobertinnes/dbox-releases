# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import json
import os
from flask import Blueprint

from web.shared import ok, err, login_required

bp = Blueprint('help_api', __name__)

_help_cache = None

def _load_help():
    global _help_cache
    if _help_cache is None:
        path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static", "help_content.json")
        with open(path, encoding="utf-8") as f:
            _help_cache = json.load(f)
    return _help_cache


@bp.route('/api/help')
@login_required
def api_help():
    try:
        return ok(_load_help())
    except FileNotFoundError:
        return err("Help content not found. Run: python tools/build_guides.py --json", 404)
