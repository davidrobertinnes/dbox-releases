from functools import wraps
from flask import Blueprint, render_template, session, redirect, make_response
from flask import send_from_directory, current_app

bp = Blueprint('tablet', __name__)


def _tablet_login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("user"):
            return redirect("/tablet/login")
        return f(*args, **kwargs)
    return decorated


@bp.route("/tablet/login")
def tablet_login():
    if session.get("user"):
        return redirect("/tablet")
    return render_template("tablet_login.html")


@bp.route("/tablet")
@bp.route("/tablet/")
@_tablet_login_required
def tablet():
    return render_template("tablet.html")


@bp.route("/manifest.json")
def manifest():
    resp = make_response(
        send_from_directory(
            current_app.static_folder, "manifest.json",
            mimetype="application/manifest+json"
        )
    )
    resp.headers['Cache-Control'] = 'no-cache'
    return resp


@bp.route("/sw.js")
def service_worker():
    resp = make_response(
        send_from_directory(
            current_app.static_folder, "sw.js",
            mimetype="application/javascript"
        )
    )
    resp.headers['Service-Worker-Allowed'] = '/'
    resp.headers['Cache-Control'] = 'no-cache'
    return resp
