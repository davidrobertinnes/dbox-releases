# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from flask import Blueprint, request
from web.shared import db, ok, err, login_required, current_user
from core.schedule import (
    list_events, get_event, save_event, delete_event, convert_event_to_job,
    EVENT_TYPES,
)
from core.gcal import push_event, push_delete, push_job

bp = Blueprint('schedule', __name__)


@bp.before_request
def _check_access():
    # The Schedule nav item is gated behind the 'jobs' tier cap
    # (web/templates/dashboard.html — key:'jobs.schedule', cap:'jobs'), so
    # the API is gated to match, same shape as web/routes/jobs.py.
    from core.auth import ROLE_MODULES
    user = current_user()
    if not user:
        return None
    caps = set(user.get("tier_caps") or [])
    if "jobs" not in caps:
        return err("Jobs & CRM requires the Paid tier.", 403)
    role = user.get("role", "")
    allowed = ROLE_MODULES.get(role)
    if allowed is not None and "jobs" not in allowed:
        return err("Your role does not have access to Jobs & CRM.", 403)


@bp.route("/api/schedule/events")
@login_required
def api_schedule_events():
    return ok(list_events(db()))


@bp.route("/api/schedule/events/<int:eid>")
@login_required
def api_schedule_event_get(eid):
    e = get_event(db(), eid)
    return ok(e) if e else err("Not found", 404)


def _validate_event(data: dict):
    """Returns an error string, or None if valid. A timed (non-all-day)
    event with no start/end time produces a zero-duration Google Calendar
    event on push, which Google's API rejects — caught only as a silently
    swallowed push failure otherwise, so this is validated up front."""
    if not data.get('title'):
        return "Title required"
    if not data.get('all_day') and (not data.get('start_time') or not data.get('end_time')):
        return "Start and end time are required for a timed event"
    hours = data.get('hours')
    if hours not in (None, ''):
        try:
            if float(hours) < 0:
                return "Hours can't be negative"
        except (TypeError, ValueError):
            return "Hours must be a number"
    if data.get('event_type') == 'Visit' and not data.get('job_id'):
        return "A visit must be linked to a job"
    return None


def _normalise_hours(data: dict):
    if 'hours' in data:
        h = data['hours']
        data['hours'] = float(h) if h not in (None, '') else None


def _resync_jobs(*job_ids):
    """A job's calendar span depends on whether it has visits, so any change
    to a linked event re-checks the job(s) it was and is now linked to."""
    for jid in {j for j in job_ids if j}:
        push_job(db(), jid)


@bp.route("/api/schedule/events", methods=["POST"])
@login_required
def api_schedule_event_create():
    data = request.get_json() or {}
    error = _validate_event(data)
    if error:
        return err(error)
    data['created_by'] = current_user().get('id')
    _normalise_hours(data)
    try:
        eid = save_event(db(), data)
    except Exception as e:
        return err(str(e))
    # Best-effort — never raises, never blocks the response on a network hiccup.
    push_event(db(), eid)
    _resync_jobs(data.get('job_id'))
    return ok({"id": eid})


@bp.route("/api/schedule/events/<int:eid>", methods=["PUT"])
@login_required
def api_schedule_event_update(eid):
    data = request.get_json() or {}
    error = _validate_event(data)
    if error:
        return err(error)
    existing = get_event(db(), eid)
    if not existing:
        return err("Not found", 404)
    if existing.get('invoice_id'):
        # Its hours/date are already on an invoice — changing them here
        # would quietly make the invoice disagree with its source.
        return err("This visit has been billed — void the invoice to change it")
    data['id'] = eid
    _normalise_hours(data)
    try:
        save_event(db(), data)
    except Exception as e:
        return err(str(e))
    push_event(db(), eid)
    _resync_jobs(existing.get('job_id'), data.get('job_id'))
    return ok()


@bp.route("/api/schedule/events/<int:eid>", methods=["DELETE"])
@login_required
def api_schedule_event_delete(eid):
    from core.visit_tasks import visit_has_progress
    from core.database import get_connection
    existing = get_event(db(), eid)
    if existing and existing.get('invoice_id'):
        return err("This visit has been billed — void the invoice to delete it")
    conn = get_connection(db())
    try:
        has_progress = visit_has_progress(conn, eid)
    finally:
        conn.close()
    if has_progress and request.args.get('force') != '1':
        # The UI confirms and retries with ?force=1.
        return err("This visit has task progress recorded — deleting it will "
                   "remove that progress from the job's tasks", 409)
    try:
        delete_event(db(), eid)
    except Exception as e:
        return err(str(e))
    if existing:
        push_delete(db(), existing.get('gcal_event_id'))
        _resync_jobs(existing.get('job_id'))
    return ok()


@bp.route("/api/schedule/events/<int:eid>/convert-to-job", methods=["POST"])
@login_required
def api_schedule_event_convert(eid):
    # The event stays (it becomes the job's first Visit) along with its
    # Google event, so nothing is deleted on Google here.
    try:
        jid = convert_event_to_job(db(), eid)
    except Exception as e:
        return err(str(e))
    push_event(db(), eid)
    # convert_event_to_job() creates the job via save_job() directly, not the
    # /api/jobs POST route, so it skips that route's push_job() call. The job
    # now has a visit, so this removes/withholds its all-day span.
    push_job(db(), jid)
    return ok({"id": jid})


@bp.route("/api/schedule/events/<int:eid>/tasks")
@login_required
def api_visit_tasks_get(eid):
    from core.visit_tasks import get_visit_tasks
    try:
        return ok(get_visit_tasks(db(), eid))
    except ValueError as e:
        return err(str(e), 404)


@bp.route("/api/schedule/events/<int:eid>/tasks", methods=["PUT"])
@login_required
def api_visit_tasks_save(eid):
    from core.visit_tasks import save_visit_tasks
    data = request.get_json() or {}
    try:
        return ok(save_visit_tasks(db(), eid, data.get("tasks") or [], data.get("new_tasks") or []))
    except ValueError as e:
        return err(str(e))


@bp.route("/api/schedule/event-types")
@login_required
def api_schedule_event_types():
    return ok(EVENT_TYPES)
