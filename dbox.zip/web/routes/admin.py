# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from datetime import date
from flask import Blueprint, request

from web.shared import db, ok, err, login_required
from core.ledger import repair_orphaned_void_journals, repair_missing_gl_journals
from core.database import get_connection
from core.admin_tools import diagnose_balances, repair_opening_balances, repair_date_formats

bp = Blueprint('admin', __name__)


@bp.route("/api/admin/diagnose-balances")
@login_required
def api_diagnose_balances():
    return ok(diagnose_balances(db()))


@bp.route("/api/admin/future-dated-entries")
@login_required
def api_future_dated_entries():
    today = date.today().isoformat()
    conn  = get_connection(db())
    rows  = conn.execute("""
        SELECT je.id, je.entry_date, je.description, je.reference, je.entry_type,
               a.code as acc_code, a.name as acc_name,
               jl.debit, jl.credit
        FROM journal_entries je
        JOIN journal_lines jl ON jl.journal_id=je.id
        JOIN accounts a ON jl.account_id=a.id
        WHERE je.entry_date > ?
        ORDER BY je.entry_date, je.id
    """, (today,)).fetchall()
    conn.close()
    return ok([dict(r) for r in rows])


@bp.route("/api/admin/repair-void-journals", methods=["POST"])
@login_required
def api_repair_void_journals():
    result = repair_orphaned_void_journals(db())
    return ok(result)


@bp.route("/api/admin/repair-missing-gl", methods=["POST"])
@login_required
def api_repair_missing_gl():
    result = repair_missing_gl_journals(db())
    return ok(result)


@bp.route("/api/admin/repair-opening-balances", methods=["POST"])
@login_required
def api_repair_opening_balances():
    return ok(repair_opening_balances(db()))


@bp.route("/api/admin/repair-date-formats", methods=["POST"])
@login_required
def api_repair_date_formats():
    return ok(repair_date_formats(db()))


@bp.route("/api/admin/tile-overrides")
@login_required
def api_get_tile_overrides():
    conn = get_connection(db())
    rows = conn.execute("SELECT role, tile_key, enabled FROM role_tile_defaults").fetchall()
    conn.close()
    result = {}
    for r in rows:
        result.setdefault(r['role'], {})[r['tile_key']] = bool(r['enabled'])
    return ok(result)


@bp.route("/api/admin/tile-overrides", methods=["POST"])
@login_required
def api_save_tile_overrides():
    data    = request.json or {}
    role    = data.get('role', '')
    changes = data.get('changes', {})
    if not role:
        return err("role required")
    conn = get_connection(db())
    for tile_key, enabled in changes.items():
        conn.execute("""
            INSERT INTO role_tile_defaults (role, tile_key, enabled) VALUES (?,?,?)
            ON CONFLICT(role, tile_key) DO UPDATE SET enabled=excluded.enabled
        """, (role, tile_key, 1 if enabled else 0))
    conn.commit()
    conn.close()
    return ok()
