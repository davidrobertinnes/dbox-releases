import re
from datetime import date
from flask import Blueprint, request

from web.shared import db, ok, err, login_required
from core.ledger import repair_orphaned_void_journals, repair_missing_gl_journals
from core.database import get_connection

bp = Blueprint('admin', __name__)


@bp.route("/api/admin/diagnose-balances")
@login_required
def api_diagnose_balances():
    today = str(date.today())
    conn  = get_connection(db())

    accounts_raw = conn.execute(
        "SELECT id, code, name, account_type, account_subtype, is_bank, opening_balance "
        "FROM accounts WHERE is_bank=1 AND is_active=1 ORDER BY code"
    ).fetchall()

    result = []
    for a in accounts_raw:
        aid = a["id"]

        jl_all = conn.execute(
            "SELECT COALESCE(SUM(debit),0)-COALESCE(SUM(credit),0) AS net "
            "FROM journal_lines WHERE account_id=?", (aid,)
        ).fetchone()["net"] or 0.0

        jl_today = conn.execute(
            "SELECT COALESCE(SUM(jl.debit),0)-COALESCE(SUM(jl.credit),0) AS net "
            "FROM journal_lines jl "
            "JOIN journal_entries je ON jl.journal_id=je.id "
            "WHERE jl.account_id=? AND je.entry_date<=?", (aid, today)
        ).fetchone()["net"] or 0.0

        orphaned = conn.execute(
            "SELECT COALESCE(SUM(jl.debit),0)-COALESCE(SUM(jl.credit),0) AS net "
            "FROM journal_lines jl "
            "LEFT JOIN journal_entries je ON jl.journal_id=je.id "
            "WHERE jl.account_id=? AND je.id IS NULL", (aid,)
        ).fetchone()["net"] or 0.0

        ob = a["opening_balance"] or 0.0

        ob_jl = conn.execute(
            "SELECT COALESCE(SUM(jl.debit),0)-COALESCE(SUM(jl.credit),0) AS net "
            "FROM journal_lines jl "
            "JOIN journal_entries je ON jl.journal_id=je.id "
            "WHERE jl.account_id=? AND (je.reference LIKE 'OB-%' OR je.description='Opening balances')",
            (aid,)
        ).fetchone()["net"] or 0.0

        future_jl = conn.execute(
            "SELECT COALESCE(SUM(jl.debit),0)-COALESCE(SUM(jl.credit),0) AS net "
            "FROM journal_lines jl "
            "JOIN journal_entries je ON jl.journal_id=je.id "
            "WHERE jl.account_id=? AND je.entry_date>?", (aid, today)
        ).fetchone()["net"] or 0.0

        result.append({
            "id": aid, "code": a["code"], "name": a["name"],
            "account_type": a["account_type"], "subtype": a["account_subtype"],
            "opening_balance_field": ob,
            "jl_sum_all_time":        round(ob + jl_all,   2),
            "jl_sum_as_at_today":     round(ob + jl_today, 2),
            "ob_journal_contribution": round(ob_jl, 2),
            "double_counted_by": round(ob_jl, 2) if abs(ob) > 0.01 and abs(ob_jl) > 0.01 else 0,
            "orphaned_jl_net":     round(orphaned,  2),
            "future_dated_jl_net": round(future_jl, 2),
        })

    conn.close()
    return ok(result)


@bp.route("/api/admin/future-dated-entries")
@login_required
def api_future_dated_entries():
    today = date.today().isoformat()
    conn  = get_connection(db())
    rows  = conn.execute("""
        SELECT je.id, je.entry_date, je.description, je.reference, je.entry_type,
               a.code as acc_code, a.name as acc_name,
               jl.debit, jl.credit
        FROM journal_entries je
        JOIN journal_lines jl ON jl.journal_id=je.id
        JOIN accounts a ON jl.account_id=a.id
        WHERE je.entry_date > ?
        ORDER BY je.entry_date, je.id
    """, (today,)).fetchall()
    conn.close()
    return ok([dict(r) for r in rows])


@bp.route("/api/admin/repair-void-journals", methods=["POST"])
@login_required
def api_repair_void_journals():
    result = repair_orphaned_void_journals(db())
    return ok(result)


@bp.route("/api/admin/repair-missing-gl", methods=["POST"])
@login_required
def api_repair_missing_gl():
    result = repair_missing_gl_journals(db())
    return ok(result)


@bp.route("/api/admin/repair-opening-balances", methods=["POST"])
@login_required
def api_repair_opening_balances():
    conn = get_connection(db())
    affected = conn.execute("""
        SELECT DISTINCT jl.account_id
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id = je.id
        WHERE je.reference LIKE 'OB-%' OR je.description = 'Opening balances'
    """).fetchall()

    fixed = 0
    skipped = 0
    for row in affected:
        cur = conn.execute("SELECT opening_balance FROM accounts WHERE id=?",
                           (row["account_id"],)).fetchone()
        if cur and (cur["opening_balance"] or 0) != 0:
            conn.execute("UPDATE accounts SET opening_balance=0 WHERE id=?",
                         (row["account_id"],))
            fixed += 1
        else:
            skipped += 1
    conn.commit()
    conn.close()
    return ok({"accounts_fixed": fixed, "already_zero": skipped})


@bp.route("/api/admin/repair-date-formats", methods=["POST"])
@login_required
def api_repair_date_formats():
    MONTHS = {'JAN': '01', 'FEB': '02', 'MAR': '03', 'APR': '04', 'MAY': '05', 'JUN': '06',
              'JUL': '07', 'AUG': '08', 'SEP': '09', 'OCT': '10', 'NOV': '11', 'DEC': '12'}
    pattern = re.compile(r'^(\d{4})-([A-Z]{3})-(\d{2})$')

    def fix(d):
        if not d:
            return None
        m = pattern.match(str(d))
        if m:
            y, mon, day = m.groups()
            num = MONTHS.get(mon)
            return f"{y}-{num}-{day}" if num else None
        return None

    conn = get_connection(db())
    bt_rows = conn.execute(
        "SELECT id, transaction_date FROM bank_transactions").fetchall()
    je_rows = conn.execute(
        "SELECT id, entry_date FROM journal_entries").fetchall()

    bt_fixed = je_fixed = 0
    for r in bt_rows:
        iso = fix(r["transaction_date"])
        if iso:
            conn.execute("UPDATE bank_transactions SET transaction_date=? WHERE id=?",
                         (iso, r["id"]))
            bt_fixed += 1
    for r in je_rows:
        iso = fix(r["entry_date"])
        if iso:
            conn.execute("UPDATE journal_entries SET entry_date=? WHERE id=?",
                         (iso, r["id"]))
            je_fixed += 1

    conn.commit()
    conn.close()
    return ok({"bank_transactions_fixed": bt_fixed, "journal_entries_fixed": je_fixed})
