import os, io, csv
from datetime import date
from flask import Blueprint, request, jsonify, send_file, Response, session

from web.shared import db, ok, err, login_required, tier_required
from core.ledger import (
    trial_balance, profit_and_loss, balance_sheet,
    get_monthly_totals, bas_report, aged_receivables, aged_payables,
    cash_flow_statement, get_account_ledger,
)
from core.reports_pdf import (
    render_pl_pdf, render_bs_pdf, render_tb_pdf, render_bas_pdf, render_ias_pdf,
    render_aged_pdf, render_cash_flow_pdf, render_statement_of_account_pdf,
)
from core.budget import (
    get_budget_periods, get_budget_period, build_actual_vs_budget_report,
    create_budget_period, delete_budget_period,
    get_budget_lines, save_budget_lines,
    generate_budget_csv_template, import_budget_csv,
    audit,
)
from core.inventory import (
    get_livestock_trading_statement,
    get_livestock_category_list,
)
from core.database import get_connection
from core.licence import get_licence_status, watermark_text

bp = Blueprint('reports', __name__)


def _get_pdf_watermark() -> str | None:
    """
    Return a watermark string for PDFs if the licence is invalid/missing/lapsed,
    or None if fully licenced. Mirrors get_watermark() from ui/shared.py.
    The app_dir search matches app.py: one level up from server.py (web/).
    """
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
        return watermark_text(status)
    except Exception:
        return "Unregistered"


# ── Reports ────────────────────────────────────────────────────────────────────
@bp.route("/api/reports/trial-balance")
@login_required
def api_trial_balance():
    as_of = request.args.get("as_of", str(date.today()))
    return ok(trial_balance(db(), as_at_date=as_of))

@bp.route("/api/reports/profit-loss")
@login_required
def api_profit_loss():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to", str(date.today()))
    basis     = request.args.get("basis", "accrual")
    return ok(profit_and_loss(db(), date_from, date_to, basis=basis))

@bp.route("/api/reports/balance-sheet")
@login_required
def api_balance_sheet():
    as_of = request.args.get("as_of", str(date.today()))
    return ok(balance_sheet(db(), as_of))

@bp.route("/api/reports/account-ledger")
@login_required
def api_account_ledger():
    account_id = request.args.get("account_id", type=int)
    if not account_id:
        return err("account_id required", 400)
    date_from = request.args.get("from")
    date_to   = request.args.get("to") or request.args.get("as_of")
    data = get_account_ledger(db(), account_id, date_from=date_from, date_to=date_to)
    if data is None:
        return err("Account not found", 404)
    return ok(data)

@bp.route("/api/reports/budget-vs-actual")
@login_required
def api_budget_vs_actual():
    periods = get_budget_periods(db())
    if not periods:
        return ok({"rows": [], "period": None})
    pid = int(request.args.get("period_id") or periods[0]["id"])
    rows, period = build_actual_vs_budget_report(db(), pid)
    return ok({"rows": rows, "period": dict(period) if period else None})

@bp.route("/api/reports/budget-periods")
@login_required
def api_budget_periods():
    """Return list of all budget periods for the period picker."""
    periods = get_budget_periods(db())
    return ok([dict(p) for p in periods])


@bp.route("/api/budget/periods", methods=["POST"])
@login_required
def api_budget_period_create():
    d = request.json or {}
    name = (d.get("name") or "").strip()
    if not name:
        return err("Name is required", 400)
    try:
        fy = int(d.get("fy_year") or 0)
    except (TypeError, ValueError):
        return err("fy_year must be an integer", 400)
    pid = create_budget_period(
        db(), name, fy,
        d.get("period_type", "Annual"),
        d.get("start_date") or f"{fy-1}-07-01",
        d.get("end_date")   or f"{fy}-06-30",
        created_by=session.get("username"))
    audit(db(), session.get("user_id"), session.get("username"),
          "CreateBudget", "budget_period", pid, name)
    return ok({"id": pid})


@bp.route("/api/budget/periods/<int:pid>", methods=["PUT"])
@login_required
def api_budget_period_update(pid):
    d = request.json or {}
    name = (d.get("name") or "").strip()
    if not name:
        return err("Name is required", 400)
    try:
        fy = int(d.get("fy_year") or 0)
    except (TypeError, ValueError):
        return err("fy_year must be an integer", 400)
    conn = get_connection(db())
    conn.execute("""UPDATE budget_periods SET name=?,fy_year=?,period_type=?,
        start_date=?,end_date=? WHERE id=?""",
        (name, fy, d.get("period_type","Annual"),
         d.get("start_date") or f"{fy-1}-07-01",
         d.get("end_date")   or f"{fy}-06-30",
         pid))
    conn.commit()
    conn.close()
    return ok()


@bp.route("/api/budget/periods/<int:pid>", methods=["DELETE"])
@login_required
def api_budget_period_delete(pid):
    delete_budget_period(db(), pid)
    return ok()


@bp.route("/api/budget/periods/<int:pid>/lines", methods=["GET"])
@login_required
def api_budget_lines_get(pid):
    lines = get_budget_lines(db(), pid)
    # Convert integer month keys to strings for JSON safety
    for line in lines:
        line["months"] = {str(k): v for k, v in line["months"].items()}
    return ok(lines)


@bp.route("/api/budget/periods/<int:pid>/lines", methods=["POST"])
@login_required
def api_budget_lines_save(pid):
    d = request.json or {}
    lines = d.get("lines", [])
    save_budget_lines(db(), pid, lines)
    audit(db(), session.get("user_id"), session.get("username"),
          "SaveBudget", "budget_period", pid, f"{len(lines)} lines")
    return ok()


@bp.route("/api/budget/periods/<int:pid>/template")
@login_required
def api_budget_template(pid):
    csv_data = generate_budget_csv_template(db(), pid)
    period = get_budget_period(db(), pid)
    fname = f"budget_template_{period['name'] if period else pid}.csv"
    from flask import Response
    return Response(csv_data, mimetype="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{fname}"'})


@bp.route("/api/budget/periods/<int:pid>/import", methods=["POST"])
@login_required
def api_budget_import(pid):
    if "file" not in request.files:
        return err("No file uploaded", 400)
    f = request.files["file"]
    try:
        content = f.read().decode("utf-8-sig")
    except UnicodeDecodeError:
        return err("File encoding error — save as UTF-8 CSV", 400)
    n, errors = import_budget_csv(db(), pid, content)
    if errors:
        return err("; ".join(errors[:5]) + (f" (+{len(errors)-5} more)" if len(errors) > 5 else ""), 400)
    audit(db(), session.get("user_id"), session.get("username"),
          "ImportBudget", "budget_period", pid, f"imported {n} lines")
    return ok({"imported": n})


@bp.route("/api/reports/bas")
@login_required
def api_bas():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to", str(date.today()))
    basis     = request.args.get("basis", "accrual")
    try:
        data = bas_report(db(), date_from, date_to, basis=basis)
        return ok(data)
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/aged")
@login_required
def api_aged():
    as_of       = request.args.get("as_of", str(date.today()))
    report_type = request.args.get("type", "receivables")
    try:
        if report_type == "payables":
            data = aged_payables(db(), as_of)
        else:
            data = aged_receivables(db(), as_of)
        # aged_receivables/payables returns a dict: {as_at, totals, rows}
        # rows items are dicts already; just ensure they're serialisable
        result = dict(data)
        result["rows"] = [dict(r) for r in result.get("rows", [])]
        result["type"] = report_type
        return ok(result)
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/cash-flow")
@login_required
def api_cash_flow():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to", str(date.today()))
    try:
        data = cash_flow_statement(db(), date_from, date_to)
        return ok(data)
    except Exception as e:
        return err(str(e))

# ── Reports PDF downloads ──────────────────────────────────────────────────────

@bp.route("/api/reports/profit-loss/pdf")
@login_required
def api_pl_pdf():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    basis     = request.args.get("basis", "accrual")
    theme     = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix="_pl.pdf")
        render_pl_pdf(db(), date_from, date_to, out_path=out,
                      basis=basis, theme=theme, watermark=_get_pdf_watermark())
        return send_file(out, as_attachment=True,
                         download_name=f"profit_loss_{date_from}_{date_to}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/balance-sheet/pdf")
@login_required
def api_bs_pdf():
    as_of = request.args.get("as_of", str(date.today()))
    theme = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix="_bs.pdf")
        render_bs_pdf(db(), as_at_date=as_of, out_path=out,
                      theme=theme, watermark=_get_pdf_watermark())
        return send_file(out, as_attachment=True,
                         download_name=f"balance_sheet_{as_of}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/trial-balance/pdf")
@login_required
def api_tb_pdf():
    theme = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix="_tb.pdf")
        render_tb_pdf(db(), out_path=out, theme=theme, watermark=_get_pdf_watermark())
        return send_file(out, as_attachment=True,
                         download_name=f"trial_balance_{date.today()}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/bas/pdf")
@login_required
def api_bas_pdf():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    basis     = request.args.get("basis", "accrual")
    form      = request.args.get("form", "bas")
    theme     = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix=f"_{form}.pdf")
        if form == "ias":
            render_ias_pdf(db(), date_from, date_to, out_path=out,
                           theme=theme, watermark=_get_pdf_watermark())
        else:
            render_bas_pdf(db(), date_from, date_to, out_path=out,
                           basis=basis, theme=theme, watermark=_get_pdf_watermark())
        return send_file(out, as_attachment=True,
                         download_name=f"{form}_{date_from}_{date_to}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/aged/pdf")
@login_required
def api_aged_pdf():
    as_of       = request.args.get("as_of", str(date.today()))
    report_type = request.args.get("type", "receivables")
    theme       = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix=f"_aged_{report_type}.pdf")
        render_aged_pdf(db(), as_of, report_type=report_type,
                        out_path=out, theme=theme, watermark=_get_pdf_watermark())
        return send_file(out, as_attachment=True,
                         download_name=f"aged_{report_type}_{as_of}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/cash-flow/pdf")
@login_required
def api_cash_flow_pdf():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    theme     = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix="_cashflow.pdf")
        render_cash_flow_pdf(db(), date_from, date_to, out_path=out,
                             theme=theme, watermark=_get_pdf_watermark())
        return send_file(out, as_attachment=True,
                         download_name=f"cash_flow_{date_from}_{date_to}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

# ── Reports CSV exports ────────────────────────────────────────────────────────

@bp.route("/api/reports/profit-loss/csv")
@login_required
def api_pl_csv():
    import csv, io
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    basis     = request.args.get("basis", "accrual")
    try:
        d = profit_and_loss(db(), date_from, date_to, basis=basis)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Section", "Code", "Account", "Amount"])
        for r in d.get("income", []):
            w.writerow(["Income", r.get("code",""), r.get("name",""), r.get("amount",0)])
        w.writerow(["Income", "", "TOTAL INCOME", d.get("total_income", 0)])
        w.writerow([])
        for r in d.get("cost_of_sales", []):
            w.writerow(["Cost of Sales", r.get("code",""), r.get("name",""), r.get("amount",0)])
        if d.get("cost_of_sales"):
            w.writerow(["Cost of Sales", "", "TOTAL COST OF SALES",
                        sum(r.get("amount",0) for r in d.get("cost_of_sales",[]))])
            w.writerow([])
        for r in d.get("expense", []):
            w.writerow(["Expense", r.get("code",""), r.get("name",""), r.get("amount",0)])
        w.writerow(["Expense", "", "TOTAL EXPENSES", d.get("total_expense", 0)])
        w.writerow([])
        w.writerow(["", "", "NET PROFIT / (LOSS)", d.get("net_profit", 0)])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"profit_loss_{date_from}_{date_to}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/balance-sheet/csv")
@login_required
def api_bs_csv():
    import csv, io
    as_of = request.args.get("as_of", str(date.today()))
    try:
        d = balance_sheet(db(), as_of)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Section", "Code", "Account", "Balance"])
        for section in ("assets", "liabilities", "equity"):
            for r in d.get(section, []):
                if abs(r.get("balance", 0)) >= 0.005:
                    w.writerow([section.title(), r.get("code",""), r.get("name",""), r.get("balance",0)])
            w.writerow([section.title(), "", "TOTAL " + section.upper(),
                        d.get("total_" + section, 0)])
            w.writerow([])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"balance_sheet_{as_of}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/trial-balance/csv")
@login_required
def api_tb_csv():
    import csv, io
    try:
        rows = trial_balance(db())
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Code", "Account", "Type", "Debit", "Credit"])
        for r in rows:
            dr = r.get("total_debit", 0) or 0
            cr = r.get("total_credit", 0) or 0
            if dr or cr:
                w.writerow([r.get("code",""), r.get("name",""),
                             r.get("account_type",""), dr, cr])
        w.writerow(["", "TOTALS", "",
                    sum((r.get("total_debit",0) or 0) for r in rows),
                    sum((r.get("total_credit",0) or 0) for r in rows)])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"trial_balance_{date.today()}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/bas/csv")
@login_required
def api_bas_csv():
    import csv, io
    from core.ledger import ias_report
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    basis     = request.args.get("basis", "accrual")
    form      = request.args.get("form",  "bas")
    try:
        d = ias_report(db(), date_from, date_to) if form == "ias" \
            else bas_report(db(), date_from, date_to, basis=basis)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Label", "Description", "Amount"])
        for key, val in d.items():
            if key not in ("period_from", "period_to", "pay_runs") \
                    and isinstance(val, (int, float)):
                w.writerow([key, key.replace("_", " ").title(), val])
        w.writerow(["period_from", "Period From", d.get("period_from", "")])
        w.writerow(["period_to",   "Period To",   d.get("period_to",   "")])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"{form}_{date_from}_{date_to}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/aged/csv")
@login_required
def api_aged_csv():
    import csv, io
    as_of       = request.args.get("as_of", str(date.today()))
    report_type = request.args.get("type", "receivables")
    try:
        data   = aged_payables(db(), as_of) if report_type == "payables" \
                 else aged_receivables(db(), as_of)
        rows   = [dict(r) for r in data.get("rows", [])]
        totals = data.get("totals", {})
        contact_col = "Supplier" if report_type == "payables" else "Customer"
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow([contact_col, "Current", "1-30 Days", "31-60 Days",
                    "61-90 Days", "90+ Days", "Total"])
        for r in rows:
            w.writerow([r.get("contact_name",""),
                        r.get("current",0), r.get("b0",0), r.get("b1",0),
                        r.get("b2",0), r.get("b3",0), r.get("total",0)])
        w.writerow(["TOTAL",
                    totals.get("current",0), totals.get("b0",0), totals.get("b1",0),
                    totals.get("b2",0), totals.get("b3",0), totals.get("total",0)])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"aged_{report_type}_{as_of}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/cash-flow/csv")
@login_required
def api_cash_flow_csv():
    import csv, io
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    try:
        d = cash_flow_statement(db(), date_from, date_to)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Section", "Description", "Amount"])
        for section_key, section_label in [
            ("operating", "Operating Activities"),
            ("investing", "Investing Activities"),
            ("financing", "Financing Activities"),
        ]:
            sec = d.get(section_key, {})
            for item in sec.get("items", []):
                w.writerow([section_label,
                             item.get("label", item.get("description","")),
                             item.get("amount", 0)])
            w.writerow([section_label, f"Net Cash from {section_label}",
                        sec.get("subtotal", 0)])
            w.writerow([])
        w.writerow(["Summary", "Opening Cash Balance", d.get("opening_cash", 0)])
        w.writerow(["Summary", "Net Change",           d.get("net_change",   0)])
        w.writerow(["Summary", "Closing Cash Balance", d.get("closing_cash", 0)])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"cash_flow_{date_from}_{date_to}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))


@bp.route("/api/inventory/livestock-categories")
@login_required
def api_livestock_categories():
    return ok(get_livestock_category_list())


@bp.route("/api/reports/livestock-trading")
@login_required
def api_livestock_trading():
    date_from = request.args.get("from", "")
    date_to   = request.args.get("to",   "")
    if not date_from or not date_to:
        return err("from and to date parameters are required")
    try:
        return ok(get_livestock_trading_statement(db(), date_from, date_to))
    except Exception as e:
        return err(str(e))
