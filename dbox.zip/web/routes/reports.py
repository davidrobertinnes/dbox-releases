# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import os, io, csv, calendar
from datetime import date
from flask import Blueprint, request, jsonify, send_file, Response, session

from web.shared import db, ok, err, login_required, tier_required, _get_pdf_watermark, _get_combined_pdf_footer
from core.ledger import (
    trial_balance, profit_and_loss, balance_sheet,
    get_monthly_totals, bas_report, aged_receivables, aged_payables,
    cash_flow_statement, get_account_ledger, get_general_ledger,
    tax_return_summary,
)
from core.reports_pdf import (
    render_pl_pdf, render_bs_pdf, render_tb_pdf, render_bas_pdf, render_ias_pdf,
    render_aged_pdf, render_cash_flow_pdf, render_statement_of_account_pdf,
    render_tax_pdf, render_pl_monthly_pdf, render_budget_pdf,
)
from core.budget import (
    get_budget_periods, get_budget_period, build_actual_vs_budget_report,
    create_budget_period, delete_budget_period,
    get_budget_lines, save_budget_lines,
    generate_budget_csv_template, import_budget_csv,
    get_actuals_by_account_month,
    audit,
)
from core.inventory import (
    get_livestock_trading_statement,
    get_livestock_category_list,
)
from core.database import get_connection
from core.jobs import get_jobs_report
from core.reports_pdf import render_jobs_pdf
bp = Blueprint('reports', __name__)


# ── Reports ────────────────────────────────────────────────────────────────────
@bp.route("/api/reports/trial-balance")
@login_required
def api_trial_balance():
    as_of = request.args.get("as_of", str(date.today()))
    return ok(trial_balance(db(), as_at_date=as_of))

def _pl_monthly_data(db_path, date_from, date_to, basis="accrual"):
    """Build the monthly P&L data structure (shared by JSON, CSV, and PDF routes)."""
    from datetime import timedelta
    month_results = []
    cur = date.fromisoformat(date_from).replace(day=1)
    end = date.fromisoformat(date_to)
    while cur <= end:
        m_last = calendar.monthrange(cur.year, cur.month)[1]
        m_end  = min(cur.replace(day=m_last), end)
        pl     = profit_and_loss(db_path, str(cur), str(m_end), basis=basis)
        month_results.append({"label": cur.strftime("%b %y"),
                               "key":   cur.strftime("%Y-%m"), "pl": pl})
        cur = (cur.replace(day=28) + timedelta(days=4)).replace(day=1)

    n = len(month_results)

    def merge_section(section_key):
        seen, order = {}, []
        for m in month_results:
            for r in (m["pl"].get(section_key) or []):
                uid = r.get("account_id") or r["name"]
                if uid not in seen:
                    seen[uid] = {"code": r.get("code", ""), "name": r["name"],
                                 "account_id": r.get("account_id"), "amounts": [0.0] * n}
                    order.append(uid)
        for mi, m in enumerate(month_results):
            for r in (m["pl"].get(section_key) or []):
                uid = r.get("account_id") or r["name"]
                if uid in seen:
                    seen[uid]["amounts"][mi] = round(float(r.get("amount") or 0), 2)
        rows = []
        for uid in order:
            acc = seen[uid]
            acc["total"] = round(sum(acc["amounts"]), 2)
            rows.append(acc)
        return rows

    income_rows  = merge_section("income")
    cos_rows     = merge_section("cost_of_sales")
    expense_rows = merge_section("expense")

    def col_sum(rows):
        return [round(sum(r["amounts"][i] for r in rows), 2) for i in range(n)]

    total_income   = col_sum(income_rows)
    total_cos      = col_sum(cos_rows)
    gross_profit   = [round(total_income[i] - total_cos[i], 2) for i in range(n)]
    total_expenses = col_sum(expense_rows)
    net_profit     = [round(gross_profit[i] - total_expenses[i], 2) for i in range(n)]

    return {
        "months":             [m["label"] for m in month_results],
        "month_keys":         [m["key"]   for m in month_results],
        "income":             income_rows,
        "cost_of_sales":      cos_rows,
        "expenses":           expense_rows,
        "total_income":       total_income,
        "total_cos":          total_cos,
        "gross_profit":       gross_profit,
        "total_expenses":     total_expenses,
        "net_profit":         net_profit,
        "grand_income":       round(sum(total_income), 2),
        "grand_cos":          round(sum(total_cos), 2),
        "grand_gross_profit": round(sum(gross_profit), 2),
        "grand_expenses":     round(sum(total_expenses), 2),
        "grand_net_profit":   round(sum(net_profit), 2),
    }


@bp.route("/api/reports/profit-loss/monthly")
@login_required
def api_profit_loss_monthly():
    _today = date.today()
    _fy_start = str(_today.replace(month=7, day=1)
                    if _today.month >= 7
                    else _today.replace(year=_today.year - 1, month=7, day=1))
    date_from = request.args.get("from", _fy_start)
    date_to   = request.args.get("to",   str(_today))
    basis     = request.args.get("basis", "accrual")
    return ok(_pl_monthly_data(db(), date_from, date_to, basis))


@bp.route("/api/reports/profit-loss/monthly/csv")
@login_required
def api_profit_loss_monthly_csv():
    _today = date.today()
    _fy_start = str(_today.replace(month=7, day=1)
                    if _today.month >= 7
                    else _today.replace(year=_today.year - 1, month=7, day=1))
    date_from = request.args.get("from", _fy_start)
    date_to   = request.args.get("to",   str(_today))
    basis     = request.args.get("basis", "accrual")
    d = _pl_monthly_data(db(), date_from, date_to, basis)
    months = d.get("months", [])
    output = io.StringIO()
    w = csv.writer(output)
    w.writerow(["Code", "Account"] + months + ["Total"])
    for section_key, label in [("income","Income"),("cost_of_sales","Cost of Sales"),("expenses","Expenses")]:
        rows = d.get(section_key) or []
        if not rows:
            continue
        w.writerow([])
        w.writerow([label])
        for r in rows:
            w.writerow([r.get("code",""), r["name"]] + r["amounts"] + [r["total"]])
    w.writerow([])
    w.writerow(["", "Total Income"]    + d.get("total_income",[])   + [d.get("grand_income",0)])
    if d.get("cost_of_sales"):
        w.writerow(["", "Gross Profit"]+ d.get("gross_profit",[])   + [d.get("grand_gross_profit",0)])
    w.writerow(["", "Total Expenses"]  + d.get("total_expenses",[]) + [d.get("grand_expenses",0)])
    w.writerow(["", "Net Profit"]      + d.get("net_profit",[])     + [d.get("grand_net_profit",0)])
    output.seek(0)
    return Response(output.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment;filename=pl_monthly_{date_from}_{date_to}.csv"})


@bp.route("/api/reports/profit-loss/monthly/pdf")
@login_required
def api_profit_loss_monthly_pdf():
    _today = date.today()
    _fy_start = str(_today.replace(month=7, day=1)
                    if _today.month >= 7
                    else _today.replace(year=_today.year - 1, month=7, day=1))
    date_from = request.args.get("from", _fy_start)
    date_to   = request.args.get("to",   str(_today))
    basis     = request.args.get("basis", "accrual")
    theme     = request.args.get("theme", session.get("theme", "ocean"))

    data = _pl_monthly_data(db(), date_from, date_to, basis)

    wm   = _get_pdf_watermark()
    ft   = _get_combined_pdf_footer(db())
    path = render_pl_monthly_pdf(data, date_from, date_to, basis=basis,
                                  db_path=db(), theme=theme, watermark=wm, footer=ft)
    fname = f"pl_monthly_{date_from}_{date_to}.pdf"
    return send_file(path, as_attachment=False,
                     download_name=fname, mimetype="application/pdf")


@bp.route("/api/reports/profit-loss")
@login_required
def api_profit_loss():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to", str(date.today()))
    basis     = request.args.get("basis", "accrual")
    return ok(profit_and_loss(db(), date_from, date_to, basis=basis))

@bp.route("/api/reports/tax-return")
@login_required
def api_tax_return():
    _fy_start = str(date.today().replace(month=7, day=1)
                    if date.today().month >= 7
                    else date.today().replace(year=date.today().year-1, month=7, day=1))
    date_from = request.args.get("from", _fy_start)
    date_to   = request.args.get("to",   str(date.today()))
    basis     = request.args.get("basis", "accrual")
    return ok(tax_return_summary(db(), date_from, date_to, basis=basis))

@bp.route("/api/reports/tax-return/pdf")
@login_required
def api_tax_return_pdf():
    _fy_start = str(date.today().replace(month=7, day=1)
                    if date.today().month >= 7
                    else date.today().replace(year=date.today().year-1, month=7, day=1))
    date_from = request.args.get("from", _fy_start)
    date_to   = request.args.get("to",   str(date.today()))
    basis     = request.args.get("basis", "accrual")
    theme     = request.args.get("theme")
    watermark = _get_pdf_watermark()
    footer    = _get_combined_pdf_footer(db())
    try:
        path = render_tax_pdf(db(), date_from, date_to, basis=basis,
                               theme=theme, watermark=watermark, footer=footer)
        return send_file(path, mimetype="application/pdf",
                         as_attachment=True,
                         download_name=f"tax_return_summary_{date_from}_{date_to}.pdf")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/tax-return/csv")
@login_required
def api_tax_return_csv():
    _fy_start = str(date.today().replace(month=7, day=1)
                    if date.today().month >= 7
                    else date.today().replace(year=date.today().year-1, month=7, day=1))
    date_from = request.args.get("from", _fy_start)
    date_to   = request.args.get("to",   str(date.today()))
    basis     = request.args.get("basis", "accrual")
    try:
        d   = tax_return_summary(db(), date_from, date_to, basis=basis)
        buf = io.StringIO()
        w   = csv.writer(buf)
        w.writerow(["Tax Return Summary"])
        w.writerow([f"Period: {date_from} to {date_to}"])
        w.writerow([f"Basis: {'Cash' if basis=='cash' else 'Accrual'}"])
        w.writerow([])
        w.writerow(["Section", "Category", "Code", "Account", "Amount"])

        for row in (d.get("income") or []):
            amt = float(row.get("amount", 0) or 0)
            if abs(amt) >= 0.005:
                w.writerow(["Income", "Business Income",
                             row.get("code", ""), row.get("name", ""), f"{amt:.2f}"])
        w.writerow(["Income", "Total Income", "", "", f"{d['total_income']:.2f}"])
        w.writerow([])

        cos_rows = d.get("cost_of_sales") or []
        if cos_rows:
            for row in cos_rows:
                amt = float(row.get("amount", 0) or 0)
                if abs(amt) >= 0.005:
                    w.writerow(["Cost of Sales", "", row.get("code", ""),
                                 row.get("name", ""), f"{amt:.2f}"])
            w.writerow(["Cost of Sales", "Total Cost of Sales", "", "",
                         f"{d['total_cost_of_sales']:.2f}"])
            w.writerow(["Gross Profit", "", "", "", f"{d['gross_profit']:.2f}"])
            w.writerow([])

        for grp in (d.get("expense_groups") or []):
            for acct in grp["accounts"]:
                amt = float(acct.get("amount", 0) or 0)
                if abs(amt) >= 0.005:
                    w.writerow(["Expenses", grp["label"],
                                 acct.get("code", ""), acct.get("name", ""), f"{amt:.2f}"])
            w.writerow(["Expenses", f"Subtotal - {grp['label']}", "", "",
                         f"{grp['total']:.2f}"])
        w.writerow([])
        w.writerow(["Expenses", "Total Expenses", "", "", f"{d['total_expenses']:.2f}"])
        w.writerow([])
        net = d["net_profit"]
        w.writerow([("Net Profit" if net >= 0 else "Net Loss"), "", "", "",
                     f"{net:.2f}"])
        w.writerow([])

        gst = d.get("gst", {})
        w.writerow(["GST Summary"])
        w.writerow(["GST", "G1 Total Sales / Gross Income", "", "",
                     f"{float(gst.get('G1_total_sales', 0)):.2f}"])
        w.writerow(["GST", "1A GST on Sales (GST Collected)", "", "",
                     f"{float(gst.get('1A_GST_on_sales', 0)):.2f}"])
        w.writerow(["GST", "1B GST on Purchases (GST Paid)", "", "",
                     f"{float(gst.get('1B_GST_on_purchases', 0)):.2f}"])
        net_gst = float(gst.get("GST_payable", 0))
        w.writerow(["GST",
                     "Net GST Payable to ATO" if net_gst > 0 else "Net GST Refund Due",
                     "", "", f"{abs(net_gst):.2f}"])

        data = buf.getvalue().encode("utf-8-sig")
        return send_file(io.BytesIO(data), mimetype="text/csv", as_attachment=True,
                         download_name=f"tax_return_summary_{date_from}_{date_to}.csv")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/balance-sheet")
@login_required
def api_balance_sheet():
    as_of = request.args.get("as_of", str(date.today()))
    return ok(balance_sheet(db(), as_of))

@bp.route("/api/reports/account-ledger")
@login_required
def api_account_ledger():
    account_id = request.args.get("account_id", type=int)
    if not account_id:
        return err("account_id required", 400)
    date_from = request.args.get("from")
    date_to   = request.args.get("to") or request.args.get("as_of")
    data = get_account_ledger(db(), account_id, date_from=date_from, date_to=date_to)
    if data is None:
        return err("Account not found", 404)
    return ok(data)

@bp.route("/api/reports/budget-vs-actual")
@login_required
@tier_required("budget")
def api_budget_vs_actual():
    periods = get_budget_periods(db())
    if not periods:
        return ok({"rows": [], "period": None})
    pid       = int(request.args.get("period_id") or periods[0]["id"])
    date_from = request.args.get("from",  "").strip() or None
    date_to   = request.args.get("to",    "").strip() or None
    rows, period = build_actual_vs_budget_report(db(), pid, date_from, date_to)
    return ok({"rows": rows, "period": dict(period) if period else None,
               "date_from": date_from, "date_to": date_to})

@bp.route("/api/budget/prior-year-actuals")
@login_required
@tier_required("budget")
def api_budget_prior_year_actuals():
    date_from = request.args.get("from", "").strip()
    date_to   = request.args.get("to",   "").strip()
    if not date_from or not date_to:
        return err("from and to are required", 400)
    from core.ledger import get_accounts
    actuals  = get_actuals_by_account_month(db(), date_from, date_to)
    acct_map = {a["id"]: a for a in get_accounts(db())}
    result   = []
    for aid, months in actuals.items():
        annual = sum(months.values())
        if not annual:
            continue
        acct = acct_map.get(aid)
        if not acct:
            continue
        result.append({
            "id":     aid,
            "code":   acct["code"],
            "name":   acct["name"],
            "type":   acct["account_type"],
            "annual": round(annual, 2),
        })
    return ok(result)


@bp.route("/api/reports/budget-periods")
@login_required
@tier_required("budget")
def api_budget_periods():
    """Return list of all budget periods for the period picker."""
    periods = get_budget_periods(db())
    return ok([dict(p) for p in periods])


@bp.route("/api/budget/periods", methods=["POST"])
@login_required
@tier_required("budget")
def api_budget_period_create():
    d = request.json or {}
    name = (d.get("name") or "").strip()
    if not name:
        return err("Name is required", 400)
    try:
        fy = int(d.get("fy_year") or 0)
    except (TypeError, ValueError):
        return err("fy_year must be an integer", 400)
    pid = create_budget_period(
        db(), name, fy,
        d.get("period_type", "Annual"),
        d.get("start_date") or f"{fy-1}-07-01",
        d.get("end_date")   or f"{fy}-06-30",
        created_by=session.get("username"))
    audit(db(), session.get("user_id"), session.get("username"),
          "CreateBudget", "budget_period", pid, name)
    return ok({"id": pid})


@bp.route("/api/budget/periods/<int:pid>", methods=["PUT"])
@login_required
@tier_required("budget")
def api_budget_period_update(pid):
    d = request.json or {}
    name = (d.get("name") or "").strip()
    if not name:
        return err("Name is required", 400)
    try:
        fy = int(d.get("fy_year") or 0)
    except (TypeError, ValueError):
        return err("fy_year must be an integer", 400)
    conn = get_connection(db())
    conn.execute("""UPDATE budget_periods SET name=?,fy_year=?,period_type=?,
        start_date=?,end_date=? WHERE id=?""",
        (name, fy, d.get("period_type","Annual"),
         d.get("start_date") or f"{fy-1}-07-01",
         d.get("end_date")   or f"{fy}-06-30",
         pid))
    conn.commit()
    conn.close()
    return ok()


@bp.route("/api/budget/periods/<int:pid>", methods=["DELETE"])
@login_required
@tier_required("budget")
def api_budget_period_delete(pid):
    delete_budget_period(db(), pid)
    return ok()


@bp.route("/api/budget/periods/<int:pid>/lines", methods=["GET"])
@login_required
@tier_required("budget")
def api_budget_lines_get(pid):
    lines = get_budget_lines(db(), pid)
    # Convert integer month keys to strings for JSON safety
    for line in lines:
        line["months"] = {str(k): v for k, v in line["months"].items()}
    return ok(lines)


@bp.route("/api/budget/periods/<int:pid>/lines", methods=["POST"])
@login_required
@tier_required("budget")
def api_budget_lines_save(pid):
    d = request.json or {}
    lines = d.get("lines", [])
    save_budget_lines(db(), pid, lines)
    audit(db(), session.get("user_id"), session.get("username"),
          "SaveBudget", "budget_period", pid, f"{len(lines)} lines")
    return ok()


@bp.route("/api/budget/periods/<int:pid>/template")
@login_required
@tier_required("budget")
def api_budget_template(pid):
    csv_data = generate_budget_csv_template(db(), pid)
    period = get_budget_period(db(), pid)
    fname = f"budget_template_{period['name'] if period else pid}.csv"
    from flask import Response
    return Response(csv_data, mimetype="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{fname}"'})


@bp.route("/api/budget/periods/<int:pid>/import", methods=["POST"])
@login_required
@tier_required("budget")
def api_budget_import(pid):
    if "file" not in request.files:
        return err("No file uploaded", 400)
    f = request.files["file"]
    try:
        content = f.read().decode("utf-8-sig")
    except UnicodeDecodeError:
        return err("File encoding error — save as UTF-8 CSV", 400)
    n, errors = import_budget_csv(db(), pid, content)
    if errors:
        return err("; ".join(errors[:5]) + (f" (+{len(errors)-5} more)" if len(errors) > 5 else ""), 400)
    audit(db(), session.get("user_id"), session.get("username"),
          "ImportBudget", "budget_period", pid, f"imported {n} lines")
    return ok({"imported": n})


@bp.route("/api/reports/bas")
@login_required
def api_bas():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to", str(date.today()))
    basis     = request.args.get("basis", "accrual")
    try:
        data = bas_report(db(), date_from, date_to, basis=basis)
        return ok(data)
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/aged")
@login_required
def api_aged():
    as_of       = request.args.get("as_of", str(date.today()))
    report_type = request.args.get("type", "receivables")
    try:
        if report_type == "payables":
            data = aged_payables(db(), as_of)
        else:
            data = aged_receivables(db(), as_of)
        # aged_receivables/payables returns a dict: {as_at, totals, rows}
        # rows items are dicts already; just ensure they're serialisable
        result = dict(data)
        result["rows"] = [dict(r) for r in result.get("rows", [])]
        result["type"] = report_type
        return ok(result)
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/cash-flow")
@login_required
def api_cash_flow():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to", str(date.today()))
    try:
        data = cash_flow_statement(db(), date_from, date_to)
        return ok(data)
    except Exception as e:
        return err(str(e))

# ── Reports PDF downloads ──────────────────────────────────────────────────────

@bp.route("/api/reports/profit-loss/pdf")
@login_required
def api_pl_pdf():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    basis     = request.args.get("basis", "accrual")
    theme     = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix="_pl.pdf")
        render_pl_pdf(db(), date_from, date_to, out_path=out,
                      basis=basis, theme=theme, watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db()))
        return send_file(out, as_attachment=True,
                         download_name=f"profit_loss_{date_from}_{date_to}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/balance-sheet/pdf")
@login_required
def api_bs_pdf():
    as_of = request.args.get("as_of", str(date.today()))
    theme = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix="_bs.pdf")
        render_bs_pdf(db(), as_at_date=as_of, out_path=out,
                      theme=theme, watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db()))
        return send_file(out, as_attachment=True,
                         download_name=f"balance_sheet_{as_of}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/trial-balance/pdf")
@login_required
def api_tb_pdf():
    theme = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix="_tb.pdf")
        render_tb_pdf(db(), out_path=out, theme=theme, watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db()))
        return send_file(out, as_attachment=True,
                         download_name=f"trial_balance_{date.today()}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/bas/pdf")
@login_required
def api_bas_pdf():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    basis     = request.args.get("basis", "accrual")
    form      = request.args.get("form", "bas")
    theme     = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix=f"_{form}.pdf")
        if form == "ias":
            render_ias_pdf(db(), date_from, date_to, out_path=out,
                           theme=theme, watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db()))
        else:
            render_bas_pdf(db(), date_from, date_to, out_path=out,
                           basis=basis, theme=theme, watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db()))
        return send_file(out, as_attachment=True,
                         download_name=f"{form}_{date_from}_{date_to}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/aged/pdf")
@login_required
def api_aged_pdf():
    as_of       = request.args.get("as_of", str(date.today()))
    report_type = request.args.get("type", "receivables")
    theme       = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix=f"_aged_{report_type}.pdf")
        render_aged_pdf(db(), as_of, report_type=report_type,
                        out_path=out, theme=theme, watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db()))
        return send_file(out, as_attachment=True,
                         download_name=f"aged_{report_type}_{as_of}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/cash-flow/pdf")
@login_required
def api_cash_flow_pdf():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    theme     = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix="_cashflow.pdf")
        render_cash_flow_pdf(db(), date_from, date_to, out_path=out,
                             theme=theme, watermark=_get_pdf_watermark(), footer=_get_combined_pdf_footer(db()))
        return send_file(out, as_attachment=True,
                         download_name=f"cash_flow_{date_from}_{date_to}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

# ── Reports CSV exports ────────────────────────────────────────────────────────

@bp.route("/api/reports/profit-loss/csv")
@login_required
def api_pl_csv():
    import csv, io
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    basis     = request.args.get("basis", "accrual")
    try:
        d = profit_and_loss(db(), date_from, date_to, basis=basis)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Section", "Code", "Account", "Amount"])
        for r in d.get("income", []):
            w.writerow(["Income", r.get("code",""), r.get("name",""), r.get("amount",0)])
        w.writerow(["Income", "", "TOTAL INCOME", d.get("total_income", 0)])
        w.writerow([])
        for r in d.get("cost_of_sales", []):
            w.writerow(["Cost of Sales", r.get("code",""), r.get("name",""), r.get("amount",0)])
        if d.get("cost_of_sales"):
            w.writerow(["Cost of Sales", "", "TOTAL COST OF SALES",
                        sum(r.get("amount",0) for r in d.get("cost_of_sales",[]))])
            w.writerow([])
        for r in d.get("expense", []):
            w.writerow(["Expense", r.get("code",""), r.get("name",""), r.get("amount",0)])
        w.writerow(["Expense", "", "TOTAL EXPENSES", d.get("total_expense", 0)])
        w.writerow([])
        w.writerow(["", "", "NET PROFIT / (LOSS)", d.get("net_profit", 0)])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"profit_loss_{date_from}_{date_to}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/balance-sheet/csv")
@login_required
def api_bs_csv():
    import csv, io
    as_of = request.args.get("as_of", str(date.today()))
    try:
        d = balance_sheet(db(), as_of)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Section", "Code", "Account", "Balance"])
        for section in ("assets", "liabilities", "equity"):
            for r in d.get(section, []):
                if abs(r.get("balance", 0)) >= 0.005:
                    w.writerow([section.title(), r.get("code",""), r.get("name",""), r.get("balance",0)])
            w.writerow([section.title(), "", "TOTAL " + section.upper(),
                        d.get("total_" + section, 0)])
            w.writerow([])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"balance_sheet_{as_of}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/trial-balance/csv")
@login_required
def api_tb_csv():
    as_of    = request.args.get("as_of", str(date.today()))
    software = request.args.get("software", "").strip()  # myob_tax | handisoft
    try:
        rows = trial_balance(db(), as_at_date=as_of)

        # Load external code mappings if a software target is requested
        ext_codes = {}
        if software:
            conn = get_connection(db())
            mrows = conn.execute(
                "SELECT account_id, external_code FROM coa_mappings WHERE software=?",
                (software,)).fetchall()
            conn.close()
            ext_codes = {r["account_id"]: r["external_code"] for r in mrows}

        buf = io.StringIO()
        w   = csv.writer(buf)
        header = ["Code", "Account", "Type", "Debit", "Credit"]
        if software:
            header.insert(0, "External Code")
        w.writerow(header)
        tot_dr = tot_cr = 0.0
        for r in rows:
            bal = float(r.get("balance") or 0)
            if abs(bal) < 0.005:
                continue
            is_dr_normal = r.get("account_type") in ("Asset", "Expense")
            dr = bal if (is_dr_normal and bal >= 0) or (not is_dr_normal and bal < 0) else 0
            cr = bal if (not is_dr_normal and bal >= 0) or (is_dr_normal and bal < 0) else 0
            if dr < 0: dr = -dr
            if cr < 0: cr = -cr
            tot_dr += dr; tot_cr += cr
            row_data = [r.get("code",""), r.get("name",""),
                        r.get("account_type",""),
                        f"{dr:.2f}" if dr else "", f"{cr:.2f}" if cr else ""]
            if software:
                row_data.insert(0, ext_codes.get(r.get("account_id", 0), ""))
            w.writerow(row_data)
        totals_row = ["", "TOTALS", "", f"{tot_dr:.2f}", f"{tot_cr:.2f}"]
        if software:
            totals_row.insert(0, "")
        w.writerow(totals_row)
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"trial_balance_{as_of}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/bas/csv")
@login_required
def api_bas_csv():
    import csv, io
    from core.ledger import ias_report
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    basis     = request.args.get("basis", "accrual")
    form      = request.args.get("form",  "bas")
    try:
        d = ias_report(db(), date_from, date_to) if form == "ias" \
            else bas_report(db(), date_from, date_to, basis=basis)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Label", "Description", "Amount"])
        for key, val in d.items():
            if key not in ("period_from", "period_to", "pay_runs") \
                    and isinstance(val, (int, float)):
                w.writerow([key, key.replace("_", " ").title(), val])
        w.writerow(["period_from", "Period From", d.get("period_from", "")])
        w.writerow(["period_to",   "Period To",   d.get("period_to",   "")])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"{form}_{date_from}_{date_to}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/aged/csv")
@login_required
def api_aged_csv():
    import csv, io
    as_of       = request.args.get("as_of", str(date.today()))
    report_type = request.args.get("type", "receivables")
    try:
        data   = aged_payables(db(), as_of) if report_type == "payables" \
                 else aged_receivables(db(), as_of)
        rows   = [dict(r) for r in data.get("rows", [])]
        totals = data.get("totals", {})
        contact_col = "Supplier" if report_type == "payables" else "Customer"
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow([contact_col, "Current", "1-30 Days", "31-60 Days",
                    "61-90 Days", "90+ Days", "Total"])
        for r in rows:
            w.writerow([r.get("contact_name",""),
                        r.get("current",0), r.get("b0",0), r.get("b1",0),
                        r.get("b2",0), r.get("b3",0), r.get("total",0)])
        w.writerow(["TOTAL",
                    totals.get("current",0), totals.get("b0",0), totals.get("b1",0),
                    totals.get("b2",0), totals.get("b3",0), totals.get("total",0)])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"aged_{report_type}_{as_of}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))

@bp.route("/api/reports/cash-flow/csv")
@login_required
def api_cash_flow_csv():
    import csv, io
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    try:
        d = cash_flow_statement(db(), date_from, date_to)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Section", "Description", "Amount"])
        for section_key, section_label in [
            ("operating", "Operating Activities"),
            ("investing", "Investing Activities"),
            ("financing", "Financing Activities"),
        ]:
            sec = d.get(section_key, {})
            for item in sec.get("items", []):
                w.writerow([section_label,
                             item.get("label", item.get("description","")),
                             item.get("amount", 0)])
            w.writerow([section_label, f"Net Cash from {section_label}",
                        sec.get("subtotal", 0)])
            w.writerow([])
        w.writerow(["Summary", "Opening Cash Balance", d.get("opening_cash", 0)])
        w.writerow(["Summary", "Net Change",           d.get("net_change",   0)])
        w.writerow(["Summary", "Closing Cash Balance", d.get("closing_cash", 0)])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"cash_flow_{date_from}_{date_to}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))


@bp.route("/api/reports/general-ledger")
@login_required
def api_general_ledger():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to", str(date.today()))
    try:
        return ok(get_general_ledger(db(), date_from, date_to))
    except Exception as e:
        return err(str(e))


@bp.route("/api/reports/general-ledger/csv")
@login_required
def api_general_ledger_csv():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to", str(date.today()))
    try:
        data = get_general_ledger(db(), date_from, date_to)
        buf  = io.StringIO()
        w    = csv.writer(buf)
        w.writerow(["Code", "Account", "Date", "Reference", "Description",
                    "Debit", "Credit", "Balance"])
        for sec in data["sections"]:
            a    = sec["account"]
            code = a["code"]
            name = a["name"]
            ob   = sec["opening_balance"]
            w.writerow([code, name, "", "", "Opening Balance", "", "", f"{ob:.2f}"])
            for l in sec["lines"]:
                w.writerow([
                    code, name,
                    l["date"], l["reference"], l["description"],
                    f"{l['debit']:.2f}"  if l["debit"]  else "",
                    f"{l['credit']:.2f}" if l["credit"] else "",
                    f"{l['balance']:.2f}",
                ])
            w.writerow([code, name, "", "", "Closing Balance", "", "",
                        f"{sec['closing_balance']:.2f}"])
            w.writerow([])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"general_ledger_{date_from}_{date_to}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))


@bp.route("/api/reports/eoy-package")
@login_required
def api_eoy_package():
    import zipfile
    from core.fixed_assets import asset_register_report
    fy_year = request.args.get("fy", "")
    date_from = request.args.get("from", "")
    date_to   = request.args.get("to",   "")
    if not date_from or not date_to:
        return err("from and to dates are required", 400)
    try:
        # ── Trial Balance CSV ────────────────────────────────────────────────
        tb_rows = trial_balance(db(), as_at_date=date_to)
        tb_buf  = io.StringIO()
        tb_w    = csv.writer(tb_buf)
        tb_w.writerow(["Code", "Account", "Type", "Debit", "Credit"])
        tot_dr = tot_cr = 0.0
        for r in tb_rows:
            bal = float(r.get("balance") or 0)
            if abs(bal) < 0.005:
                continue
            is_dr = r.get("account_type") in ("Asset", "Expense")
            dr = (bal if (is_dr and bal >= 0) or (not is_dr and bal < 0) else 0)
            cr = (bal if (not is_dr and bal >= 0) or (is_dr and bal < 0) else 0)
            if dr < 0: dr = -dr
            if cr < 0: cr = -cr
            tot_dr += dr; tot_cr += cr
            tb_w.writerow([r.get("code",""), r.get("name",""),
                           r.get("account_type",""),
                           f"{dr:.2f}" if dr else "", f"{cr:.2f}" if cr else ""])
        tb_w.writerow(["", "TOTALS", "", f"{tot_dr:.2f}", f"{tot_cr:.2f}"])
        tb_bytes = tb_buf.getvalue().encode("utf-8-sig")

        # ── General Ledger CSV ───────────────────────────────────────────────
        gl_data = get_general_ledger(db(), date_from, date_to)
        gl_buf  = io.StringIO()
        gl_w    = csv.writer(gl_buf)
        gl_w.writerow(["Code", "Account", "Date", "Reference", "Description",
                       "Debit", "Credit", "Balance"])
        for sec in gl_data["sections"]:
            a = sec["account"]
            gl_w.writerow([a["code"], a["name"], "", "", "Opening Balance",
                           "", "", f"{sec['opening_balance']:.2f}"])
            for l in sec["lines"]:
                gl_w.writerow([
                    a["code"], a["name"],
                    l["date"], l["reference"], l["description"],
                    f"{l['debit']:.2f}"  if l["debit"]  else "",
                    f"{l['credit']:.2f}" if l["credit"] else "",
                    f"{l['balance']:.2f}",
                ])
            gl_w.writerow([a["code"], a["name"], "", "", "Closing Balance",
                           "", "", f"{sec['closing_balance']:.2f}"])
            gl_w.writerow([])
        gl_bytes = gl_buf.getvalue().encode("utf-8-sig")

        # ── Fixed Asset Schedule CSV ─────────────────────────────────────────
        fa_rows = asset_register_report(db())
        fa_buf  = io.StringIO()
        fa_w    = csv.writer(fa_buf)
        fa_w.writerow(["Asset No", "Description", "Category", "Acquired",
                       "Cost (ex GST)", "Residual Value", "Method", "Life (yrs)",
                       "Accum Depr", "Net WDV", "Next FY Depr", "Status"])
        for a in fa_rows:
            cost  = a.get("cost_excl_gst") or a.get("cost_price") or 0
            fa_w.writerow([
                a.get("asset_number") or f"#{a['id']}",
                a.get("description", ""),
                a.get("category") or "",
                a.get("acquisition_date", ""),
                f"{float(cost):.2f}",
                f"{float(a.get('residual_value') or 0):.2f}",
                a.get("depn_method", ""),
                a.get("effective_life_years") or "",
                f"{float(a.get('accum_depn', 0)):.2f}",
                f"{float(a.get('current_wdv', 0)):.2f}",
                f"{float(a.get('next_depn', 0)):.2f}",
                a.get("status", ""),
            ])
        fa_bytes = fa_buf.getvalue().encode("utf-8-sig")

        # ── Bundle into ZIP ──────────────────────────────────────────────────
        label   = fy_year or f"{date_from[:4]}-{date_to[:4]}"
        zip_buf = io.BytesIO()
        with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(f"trial_balance_{date_to}.csv",       tb_bytes)
            zf.writestr(f"general_ledger_{date_from}_{date_to}.csv", gl_bytes)
            zf.writestr(f"fixed_asset_schedule_{date_to}.csv", fa_bytes)
        zip_buf.seek(0)
        return send_file(zip_buf, mimetype="application/zip",
                         as_attachment=True,
                         download_name=f"accountant_package_{label}.zip")
    except Exception as e:
        return err(str(e))


@bp.route("/api/inventory/livestock-categories")
@login_required
def api_livestock_categories():
    return ok(get_livestock_category_list())


@bp.route("/api/reports/livestock-trading")
@login_required
def api_livestock_trading():
    date_from = request.args.get("from", "")
    date_to   = request.args.get("to",   "")
    if not date_from or not date_to:
        return err("from and to date parameters are required")
    try:
        return ok(get_livestock_trading_statement(db(), date_from, date_to))
    except Exception as e:
        return err(str(e))


@bp.route("/api/reports/livestock-trading/csv")
@login_required
def api_livestock_trading_csv():
    date_from = request.args.get("from", "")
    date_to   = request.args.get("to",   "")
    if not date_from or not date_to:
        return err("from and to date parameters are required")
    try:
        d     = get_livestock_trading_statement(db(), date_from, date_to)
        items = d.get("items", [])
        t     = d.get("totals", {})
        buf   = io.StringIO()
        w     = csv.writer(buf)

        w.writerow(["Per-Item Summary"])
        w.writerow(["Code", "Item", "Opening Qty", "Opening $",
                    "Closing Qty", "Closing $", "Sales Revenue"])
        for it in items:
            w.writerow([it.get("code",""), it.get("name",""),
                        f"{float(it.get('opening_qty',0)):.2f}",
                        f"{float(it.get('opening_value',0)):.2f}",
                        f"{float(it.get('closing_qty',0)):.2f}",
                        f"{float(it.get('closing_value',0)):.2f}",
                        f"{float(it.get('sales_revenue',0)):.2f}"])
        w.writerow([])
        w.writerow(["Trading Account Summary"])
        w.writerow(["Description", "Amount"])
        for label, key in [
            ("Opening Stock",       "opening_stock"),
            ("Add: Purchases",      "purchases"),
            ("Add: Natural Increase","natural_increase"),
            ("Less: Deaths",        "deaths"),
            ("Less: Private Use",   "private_use"),
            ("Less: Closing Stock", "closing_stock"),
            ("Cost of Livestock Sold","cogs"),
            ("Livestock Sales (Revenue)","sales_revenue"),
            ("Gross Livestock Income","gross_income"),
        ]:
            w.writerow([label, f"{float(t.get(key,0)):.2f}"])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"livestock_trading_{date_from}_{date_to}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))


@bp.route("/api/reports/budget-vs-actual/csv")
@login_required
@tier_required("budget")
def api_budget_vs_actual_csv():
    periods = get_budget_periods(db())
    if not periods:
        return err("No budget periods found", 404)
    pid       = int(request.args.get("period_id") or periods[0]["id"])
    date_from = request.args.get("from",  "").strip() or None
    date_to   = request.args.get("to",    "").strip() or None
    try:
        rows, period = build_actual_vs_budget_report(db(), pid, date_from, date_to)
        buf = io.StringIO()
        w   = csv.writer(buf)
        period_name = period["name"] if period else str(pid)
        w.writerow([f"Budget vs Actual — {period_name}"])
        if date_from or date_to:
            w.writerow([f"Period: {date_from or ''} to {date_to or ''}"])
        w.writerow([])
        w.writerow(["Code", "Account", "Type",
                    "Budget (Total)", "Actual (Total)", "Variance", "Variance %"])
        for r in rows:
            var_pct = r.get("total_variance_pct", 0)
            w.writerow([
                r.get("code",""), r.get("name",""), r.get("account_type",""),
                f"{r.get('total_budget',0):.2f}",
                f"{r.get('total_actual',0):.2f}",
                f"{r.get('total_variance',0):.2f}",
                f"{var_pct:.1f}%",
            ])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"budget_vs_actual_{period_name.replace(' ','_')}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))


@bp.route("/api/reports/budget-vs-actual/pdf")
@login_required
@tier_required("budget")
def api_budget_vs_actual_pdf():
    periods = get_budget_periods(db())
    if not periods:
        return err("No budget periods found", 404)
    pid       = int(request.args.get("period_id") or periods[0]["id"])
    date_from = request.args.get("from",  "").strip() or None
    date_to   = request.args.get("to",    "").strip() or None
    theme     = request.args.get("theme", session.get("theme", "ocean"))
    try:
        rows, period = build_actual_vs_budget_report(db(), pid, date_from, date_to)
        data = {"rows": rows, "period": dict(period) if period else {},
                "date_from": date_from, "date_to": date_to}
        path = render_budget_pdf(data, db_path=db(), theme=theme,
                                  watermark=_get_pdf_watermark(),
                                  footer=_get_combined_pdf_footer(db()))
        period_name = (period["name"] if period else str(pid)).replace(" ", "_")
        return send_file(path, as_attachment=False,
                         download_name=f"budget_vs_actual_{period_name}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))


@bp.route("/api/reports/account-ledger/csv")
@login_required
def api_account_ledger_csv():
    account_id = request.args.get("account_id", type=int)
    if not account_id:
        return err("account_id required", 400)
    date_from = request.args.get("from")
    date_to   = request.args.get("to") or request.args.get("as_of")
    try:
        data = get_account_ledger(db(), account_id, date_from=date_from, date_to=date_to)
        if data is None:
            return err("Account not found", 404)
        acct  = data.get("account", {})
        lines = data.get("lines", [])
        ob    = float(data.get("opening_balance", 0))

        buf = io.StringIO()
        w   = csv.writer(buf)
        w.writerow([f"{acct.get('code','')} — {acct.get('name','')}"])
        w.writerow(["Date", "Reference", "Description", "Debit", "Credit", "Balance"])
        w.writerow(["", "", "Opening Balance", "", "", f"{ob:.2f}"])

        is_dr_normal = acct.get("account_type") in ("Asset", "Expense")
        run_bal = ob
        for l in lines:
            dr = float(l.get("debit") or 0)
            cr = float(l.get("credit") or 0)
            if is_dr_normal:
                run_bal += dr - cr
            else:
                run_bal += cr - dr
            w.writerow([
                l.get("entry_date",""),
                l.get("reference",""),
                l.get("line_desc") or l.get("je_desc",""),
                f"{dr:.2f}" if dr else "",
                f"{cr:.2f}" if cr else "",
                f"{run_bal:.2f}",
            ])
        w.writerow(["", "", "Closing Balance", "", "", f"{run_bal:.2f}"])
        buf.seek(0)
        fname = f"account_ledger_{acct.get('code','').replace('-','')}"
        if date_from: fname += f"_{date_from}"
        if date_to:   fname += f"_{date_to}"
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"{fname}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))


# ── COA Mappings ───────────────────────────────────────────────────────────────

@bp.route("/api/reports/coa-mappings")
@login_required
def api_coa_mappings_get():
    software = request.args.get("software", "").strip()
    conn = get_connection(db())
    if software:
        rows = conn.execute(
            "SELECT account_id, software, external_code FROM coa_mappings WHERE software=?",
            (software,)).fetchall()
    else:
        rows = conn.execute(
            "SELECT account_id, software, external_code FROM coa_mappings").fetchall()
    conn.close()
    return ok([dict(r) for r in rows])


@bp.route("/api/reports/coa-mappings", methods=["POST"])
@login_required
def api_coa_mappings_save():
    d = request.json or {}
    software = (d.get("software") or "").strip()
    mappings = d.get("mappings", [])  # [{account_id, external_code}, ...]
    if not software:
        return err("software is required", 400)
    conn = get_connection(db())
    for m in mappings:
        aid   = m.get("account_id")
        code  = (m.get("external_code") or "").strip()
        if not aid:
            continue
        if code:
            conn.execute("""INSERT INTO coa_mappings (account_id, software, external_code)
                            VALUES (?,?,?)
                            ON CONFLICT(account_id, software)
                            DO UPDATE SET external_code=excluded.external_code""",
                         (aid, software, code))
        else:
            conn.execute("DELETE FROM coa_mappings WHERE account_id=? AND software=?",
                         (aid, software))
    conn.commit()
    conn.close()
    return ok()


# ── Jobs Report ────────────────────────────────────────────────────────────────
@bp.route("/api/reports/jobs")
@login_required
def api_jobs_report():
    try:
        data = get_jobs_report(
            db(),
            contact_id = request.args.get("contact_id", type=int),
            date_from  = request.args.get("from"),
            date_to    = request.args.get("to"),
            owner      = request.args.get("owner") or None,
            stage      = request.args.get("stage") or None,
        )
        return ok(data)
    except Exception as e:
        return err(str(e))


@bp.route("/api/reports/jobs/csv")
@login_required
def api_jobs_report_csv():
    try:
        data = get_jobs_report(
            db(),
            contact_id = request.args.get("contact_id", type=int),
            date_from  = request.args.get("from"),
            date_to    = request.args.get("to"),
            owner      = request.args.get("owner") or None,
            stage      = request.args.get("stage") or None,
        )
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Job #", "Client", "Name", "Stage", "Owner",
                    "Start Date", "End Date", "Job Value",
                    "Invoiced (ex-GST)", "Costs (ex-GST)", "Margin"])
        for r in data["rows"]:
            invoiced = r.get("total_invoiced") or 0
            costs    = r.get("total_costs") or 0
            w.writerow([
                r.get("job_number",""),
                r.get("contact_name",""),
                r.get("name",""),
                r.get("stage",""),
                r.get("owner",""),
                r.get("start_date",""),
                r.get("end_date",""),
                r.get("value") or "",
                invoiced,
                costs,
                invoiced - costs,
            ])
        s = data["summary"]
        w.writerow([])
        w.writerow(["TOTAL", "", "", "", "", "", "",
                    s["total_value"], s["total_invoiced"],
                    s["total_costs"], s["total_margin"]])
        buf.seek(0)
        fname = f"jobs_report_{date.today()}.csv"
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True, download_name=fname, mimetype="text/csv",
        )
    except Exception as e:
        return err(str(e))


@bp.route("/api/reports/jobs/pdf")
@login_required
def api_jobs_report_pdf():
    try:
        data = get_jobs_report(
            db(),
            contact_id = request.args.get("contact_id", type=int),
            date_from  = request.args.get("from"),
            date_to    = request.args.get("to"),
            owner      = request.args.get("owner") or None,
            stage      = request.args.get("stage") or None,
        )
        import tempfile
        out = tempfile.mktemp(suffix="_jobs_report.pdf")
        render_jobs_pdf(
            data,
            date_from  = request.args.get("from"),
            date_to    = request.args.get("to"),
            db_path    = db(),
            theme      = request.args.get("theme"),
            out_path   = out,
            watermark  = _get_pdf_watermark(),
            footer     = _get_combined_pdf_footer(db()),
        )
        return send_file(out, as_attachment=True,
                         download_name=f"jobs_report_{date.today()}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))
