# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from functools import wraps
from flask import Blueprint, request

from web.shared import db, ok, err, login_required, current_user
from core.auth import get_users, get_user, create_user, update_user
from core.budget import get_audit_log, audit

bp = Blueprint('users', __name__)


def _admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if current_user().get("role") != "Admin":
            return err("Admin role required", 403)
        return f(*args, **kwargs)
    return decorated


@bp.route("/api/users")
@login_required
@_admin_required
def api_users_list():
    active_only = request.args.get("active_only", "1") != "0"
    return ok(get_users(db(), active_only=active_only))


@bp.route("/api/users/<int:uid>")
@login_required
@_admin_required
def api_users_get(uid):
    user = get_user(db(), uid)
    if not user:
        return err("User not found", 404)
    user.pop("password_hash", None)
    return ok(user)


@bp.route("/api/users", methods=["POST"])
@login_required
@_admin_required
def api_users_create():
    data = request.get_json() or {}
    username     = (data.get("username") or "").strip()
    display_name = (data.get("display_name") or "").strip()
    password     = data.get("password") or ""
    role         = data.get("role", "Staff")
    if not username:
        return err("Username is required")
    if not display_name:
        return err("Display name is required")
    if not password:
        return err("Password is required")
    if role not in ("Admin", "Accountant", "Trades", "Retail", "ReadOnly"):
        return err("Invalid role")
    try:
        uid = create_user(db(), username, display_name, password, role=role)
    except ValueError as e:
        return err(str(e))
    audit(db(), current_user().get("id"), current_user().get("username", "?"),
          "create_user", "user", uid, f"Created user '{username}' role={role}")
    return ok({"id": uid})


@bp.route("/api/users/<int:uid>", methods=["PUT"])
@login_required
@_admin_required
def api_users_update(uid):
    data = request.get_json() or {}
    display_name = data.get("display_name")
    role         = data.get("role")
    is_active    = data.get("is_active")
    if role is not None and role not in ("Admin", "Accountant", "Trades", "Retail", "ReadOnly", "Staff"):
        return err("Invalid role")
    if display_name is not None:
        display_name = display_name.strip()
        if not display_name:
            return err("Display name cannot be empty")
    update_user(db(), uid,
                display_name=display_name,
                role=role,
                is_active=is_active)
    audit(db(), current_user().get("id"), current_user().get("username", "?"),
          "update_user", "user", uid,
          f"display_name={display_name!r} role={role!r} is_active={is_active!r}")
    return ok()


@bp.route("/api/users/<int:uid>/set-password", methods=["POST"])
@login_required
@_admin_required
def api_users_set_password(uid):
    data = request.get_json() or {}
    password = data.get("password") or ""
    if len(password) < 6:
        return err("Password must be at least 6 characters")
    update_user(db(), uid, new_password=password)
    audit(db(), current_user().get("id"), current_user().get("username", "?"),
          "set_password", "user", uid, "Password changed by admin")
    return ok()


@bp.route("/api/users/<int:uid>/pos-pin", methods=["POST"])
@login_required
@_admin_required
def api_users_set_pos_pin(uid):
    from core.auth import set_pos_pin
    data = request.get_json() or {}
    pin = (data.get("pin") or "").strip()
    try:
        set_pos_pin(db(), uid, pin)
    except ValueError as e:
        return err(str(e))
    audit(db(), current_user().get("id"), current_user().get("username", "?"),
          "set_pos_pin", "user", uid, "POS PIN set")
    return ok()


@bp.route("/api/users/<int:uid>/pos-pin", methods=["DELETE"])
@login_required
@_admin_required
def api_users_clear_pos_pin(uid):
    from core.auth import clear_pos_pin
    clear_pos_pin(db(), uid)
    audit(db(), current_user().get("id"), current_user().get("username", "?"),
          "clear_pos_pin", "user", uid, "POS PIN cleared")
    return ok()


@bp.route("/api/users/audit-log")
@login_required
@_admin_required
def api_users_audit_log():
    return ok(get_audit_log(db()))
