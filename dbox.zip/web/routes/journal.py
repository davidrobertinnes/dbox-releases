from flask import Blueprint, request

from web.shared import db, ok, err, login_required, current_user
from core.ledger import (
    post_journal, get_journal_entries_full, get_journal_entry,
    update_journal, void_journal, reverse_journal,
)
from core.budget import audit
from core.database import get_connection


def _check_lock(db_path, entry_date: str):
    """Raise ValueError if entry_date falls within a locked period."""
    conn = get_connection(db_path)
    row  = conn.execute("SELECT lock_date FROM company LIMIT 1").fetchone()
    conn.close()
    lock = (row["lock_date"] if row else None) or ""
    if lock and entry_date <= lock:
        raise ValueError(f"Period is locked through {lock} — post a correcting journal dated after that date")

bp = Blueprint('journal', __name__)


@bp.route("/api/journal")
@login_required
def api_journal():
    search    = request.args.get("search")
    etype     = request.args.get("type")
    date_from = request.args.get("from")
    date_to   = request.args.get("to")
    limit     = max(1, min(1000, int(request.args.get("limit", 200) or 200)))
    rows = get_journal_entries_full(
        db(),
        entry_type=etype if etype and etype != "All" else None,
        search=search or None,
        date_from=date_from or None,
        date_to=date_to or None,
        limit=limit,
    )
    return ok([dict(r) for r in rows])


@bp.route("/api/journal/<int:jid>")
@login_required
def api_journal_entry(jid):
    entry, lines = get_journal_entry(db(), jid)
    if not entry:
        return err("Not found", 404)
    return ok({"entry": dict(entry), "lines": [dict(l) for l in lines]})


@bp.route("/api/journal", methods=["POST"])
@login_required
def api_journal_post():
    data = request.get_json() or {}
    try:
        _check_lock(db(), data.get("entry_date", ""))
        jid = post_journal(
            db(),
            data["entry_date"],
            data["description"],
            data.get("reference", ""),
            data.get("lines", []),
        )
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "NewJournal", "journal_entry", jid, data["description"])
        return ok({"id": jid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/journal/<int:jid>", methods=["PUT"])
@login_required
def api_journal_update(jid):
    data = request.get_json() or {}
    try:
        update_journal(db(), jid, data["entry_date"], data.get("reference", ""),
                       data["description"], data.get("lines", []))
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/journal/<int:jid>/void", methods=["POST"])
@login_required
def api_journal_void(jid):
    try:
        rev = void_journal(db(), jid)
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "VoidJournal", "journal_entry", jid, f"reversal={rev}")
        return ok({"reversal_id": rev})
    except Exception as e:
        return err(str(e))


@bp.route("/api/journal/<int:jid>/reverse", methods=["POST"])
@login_required
def api_journal_reverse(jid):
    data = request.get_json() or {}
    try:
        rev = reverse_journal(db(), jid, data.get("reverse_date"))
        return ok({"reversal_id": rev})
    except Exception as e:
        return err(str(e))
