# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from flask import Blueprint, request
from web.shared import db, ok, err, login_required
from core.tax_estimate import get_tax_estimate, get_tax_settings, save_tax_settings

bp = Blueprint('tax_estimate', __name__)


@bp.route('/api/tax-estimate')
@login_required
def api_tax_estimate():
    try:
        return ok(get_tax_estimate(db()))
    except Exception as e:
        return err(str(e))


@bp.route('/api/tax-estimate/settings')
@login_required
def api_tax_estimate_settings_get():
    try:
        return ok(get_tax_settings(db()))
    except Exception as e:
        return err(str(e))


@bp.route('/api/tax-estimate/settings', methods=['POST'])
@login_required
def api_tax_estimate_settings_save():
    data       = request.get_json() or {}
    account_id = data.get('account_id')
    if account_id is not None and account_id != '':
        try:
            account_id = int(account_id)
        except (TypeError, ValueError):
            return err('Invalid account ID')
    else:
        account_id = None
    save_tax_settings(db(), {
        'tfr':        bool(data.get('tfr', True)),
        'help_debt':  bool(data.get('help_debt', False)),
        'account_id': account_id,
    })
    return ok()
