import uuid as _uuid
from flask import Blueprint, request
from web.shared import db, ok, err, login_required, tier_required

bp = Blueprint('pos', __name__)


# ── Item catalogue ────────────────────────────────────────────────────────────

@bp.route("/api/pos/items")
@login_required
@tier_required("pos")
def api_pos_items():
    from core.pos import get_pos_items
    search = request.args.get("q") or None
    return ok(get_pos_items(db(), search=search))


# ── Sales ─────────────────────────────────────────────────────────────────────

@bp.route("/api/pos/sale", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_sale():
    from core.pos import create_pos_sale
    data = request.get_json() or {}
    try:
        result = create_pos_sale(
            db(),
            lines=data.get("lines", []),
            tender=data.get("tender", "cash"),
            tendered_amount=data.get("tendered"),
            terminal_tx_id=data.get("terminal_tx_id"),
            terminal_provider=data.get("terminal_provider"),
            note=data.get("note", ""),
        )
        return ok(result)
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/sales")
@login_required
@tier_required("pos")
def api_pos_sales():
    from core.pos import get_pos_sales
    limit = int(request.args.get("limit", 50))
    return ok(get_pos_sales(db(), limit=limit))


# ── Terminal payments ─────────────────────────────────────────────────────────

@bp.route("/api/pos/terminal/charge", methods=["POST"])
@login_required
@tier_required("pos")
def api_pos_terminal_charge():
    from core.pos import charge_terminal
    data = request.get_json() or {}
    amount_cents = int(round(float(data.get("amount", 0)) * 100))
    reference    = data.get("reference", "POS")
    idempotency  = str(_uuid.uuid4())
    try:
        result = charge_terminal(db(), amount_cents, reference, idempotency)
        return ok(result)
    except Exception as e:
        return err(str(e))


@bp.route("/api/pos/terminal/charge/<checkout_id>")
@login_required
@tier_required("pos")
def api_pos_terminal_status(checkout_id):
    from core.pos import get_terminal_status
    provider = request.args.get("provider", "")
    try:
        return ok(get_terminal_status(db(), provider, checkout_id))
    except Exception as e:
        return err(str(e))


# ── Settings ──────────────────────────────────────────────────────────────────

@bp.route("/api/pos/settings")
@login_required
def api_pos_settings_get():
    from core.pos_settings import get_pos_settings
    s = get_pos_settings(db())
    # Don't send the raw API key — send a flag so the UI can show "configured"
    s["api_key_configured"] = bool(s.pop("api_key", ""))
    return ok(s)


@bp.route("/api/pos/settings", methods=["POST"])
@login_required
def api_pos_settings_save():
    from core.pos_settings import get_pos_settings, save_pos_settings
    data = request.get_json() or {}
    # If browser sends blank api_key, preserve the stored one
    if not data.get("api_key"):
        existing = get_pos_settings(db())
        data["api_key"] = existing.get("api_key", "")
    save_pos_settings(db(), data)
    return ok()
