# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import os
import json
import time as _time
import threading as _threading
from flask import Blueprint, request, session, send_file, Response

from web.shared import db, ok, err, login_required, _app_state, _app_state_lock
from core.database import get_connection
from core.ledger import eofy_status, perform_eofy_rollover

bp = Blueprint('company', __name__)

# ── Heartbeat / inactivity lock ───────────────────────────────────────────────
_last_heartbeat: float = _time.time()
_HEARTBEAT_TIMEOUT = 600  # 10 minutes
_shutdown_timer: "_threading.Timer | None" = None


def _do_lock():
    with _app_state_lock:
        _app_state["locked"] = True
    print("\n  dbox: inactivity timeout — session locked. Server still running.")


def _reset_shutdown_timer():
    global _shutdown_timer
    if _shutdown_timer is not None:
        _shutdown_timer.cancel()
    _shutdown_timer = _threading.Timer(_HEARTBEAT_TIMEOUT, _do_lock)
    _shutdown_timer.daemon = True
    _shutdown_timer.start()


def clear_lock():
    """Called by auth on successful login to clear inactivity lock."""
    with _app_state_lock:
        _app_state["locked"] = False
    _reset_shutdown_timer()


# ── Company logo helpers ───────────────────────────────────────────────────────

def _ensure_logo_columns(conn):
    for col, typ in (("logo_blob", "BLOB"), ("logo_mime", "TEXT")):
        try:
            conn.execute(f"ALTER TABLE company ADD COLUMN {col} {typ}")
        except Exception:
            pass


# ── Routes ────────────────────────────────────────────────────────────────────

@bp.route("/api/company")
@login_required
def api_company():
    conn = get_connection(db())
    try:
        row = conn.execute(
            "SELECT id,name,abn,acn,address,city,state,postcode,phone,email,website,"
            "gst_registered,fy_start_month,logo_path,logo_blob,default_payment_instructions,"
            "inv_prefix,inv_next,quote_prefix,quote_next,po_prefix,po_next,"
            "pdf_branding,wizard_completed,created_at FROM company WHERE id=1"
        ).fetchone()
    finally:
        conn.close()
    if not row:
        return ok({"name": "dbox", "has_logo": False, "is_new": True})
    d = {k: row[k] for k in row.keys() if k != "logo_blob"}
    d["has_logo"] = bool(row["logo_blob"]) or bool(
        d.get("logo_path") and os.path.exists(d.get("logo_path") or ""))
    if not d.get("wizard_completed"):
        d["is_new"] = True
    return ok(d)


@bp.route("/api/company", methods=["PUT"])
@login_required
def api_company_save():
    data = request.get_json() or {}
    name = (data.get("name") or "").strip()
    if not name:
        return err("Company name is required")
    conn = get_connection(db())
    try:
        existing = conn.execute("SELECT id FROM company WHERE id=1").fetchone()
        fields = ("name", "abn", "acn", "address", "city", "state", "postcode",
                  "phone", "email", "website", "gst_registered",
                  "fy_start_month", "default_payment_instructions", "pdf_branding")
        vals = tuple(
            int(data.get(f, 1)) if f in ("gst_registered", "pdf_branding")
            else int(data.get(f, 7)) if f == "fy_start_month"
            else data.get(f, "")
            for f in fields
        )
        if existing:
            set_clause = ", ".join(f"{f}=?" for f in fields)
            conn.execute(f"UPDATE company SET {set_clause}, wizard_completed=1 WHERE id=1", vals)
        else:
            col_list = ", ".join(("id",) + fields + ("wizard_completed",))
            placeholders = ", ".join("?" for _ in range(len(fields) + 2))
            conn.execute(f"INSERT INTO company ({col_list}) VALUES ({placeholders})",
                         (1,) + vals + (1,))
        conn.commit()
    finally:
        conn.close()
    return ok()


@bp.route("/api/company/doc-numbers", methods=["PUT"])
@login_required
def api_company_doc_numbers():
    data = request.get_json() or {}
    conn = get_connection(db())
    try:
        conn.execute("""UPDATE company SET
            inv_prefix=?, inv_next=?, quote_prefix=?, quote_next=?, po_prefix=?, po_next=?
            WHERE id=1""",
            (data.get("inv_prefix", "INV-") or "INV-",
             max(1, int(data.get("inv_next") or 1)),
             data.get("quote_prefix", "QTE-") or "QTE-",
             max(1, int(data.get("quote_next") or 1)),
             data.get("po_prefix", "PO-") or "PO-",
             max(1, int(data.get("po_next") or 1001))))
        conn.commit()
    finally:
        conn.close()
    return ok()


@bp.route("/api/company/logo")
@login_required
def api_company_logo_get():
    conn = get_connection(db())
    _ensure_logo_columns(conn)
    row = conn.execute("SELECT logo_blob, logo_mime, logo_path FROM company WHERE id=1").fetchone()
    conn.close()
    if not row:
        return err("No logo", 404)
    if row["logo_blob"]:
        mime = row["logo_mime"] or "image/png"
        return Response(bytes(row["logo_blob"]), mimetype=mime,
                        headers={"Cache-Control": "no-store"})
    if row["logo_path"] and os.path.exists(row["logo_path"]):
        return send_file(row["logo_path"])
    return err("No logo", 404)


@bp.route("/api/company/logo", methods=["POST"])
@login_required
def api_company_logo_upload():
    if "logo" not in request.files:
        return err("No file provided")
    f = request.files["logo"]
    if not f.filename:
        return err("No file selected")
    ext = os.path.splitext(f.filename)[1].lower()
    mime_map = {".png": "image/png", ".jpg": "image/jpeg",
                ".jpeg": "image/jpeg", ".gif": "image/gif"}
    if ext not in mime_map:
        return err("Unsupported format — use PNG, JPG, or GIF")
    data = f.read()
    mime = mime_map[ext]
    conn = get_connection(db())
    try:
        _ensure_logo_columns(conn)
        conn.execute(
            "UPDATE company SET logo_blob=?, logo_mime=? WHERE id=1",
            (data, mime))
        conn.commit()
    finally:
        conn.close()
    return ok()


@bp.route("/api/company/logo", methods=["DELETE"])
@login_required
def api_company_logo_delete():
    conn = get_connection(db())
    try:
        _ensure_logo_columns(conn)
        conn.execute("UPDATE company SET logo_blob=NULL, logo_mime=NULL WHERE id=1")
        conn.commit()
    finally:
        conn.close()
    return ok()


@bp.route("/api/theme", methods=["GET"])
@login_required
def api_theme_get():
    if not db():
        return ok({"name": "Ocean Light"})
    theme_path = db() + ".dbox.theme"
    try:
        with open(theme_path) as f:
            data = json.load(f)
        return ok({"name": data.get("name", "Ocean Light")})
    except Exception:
        return ok({"name": "Ocean Light"})


@bp.route("/api/theme", methods=["POST"])
@login_required
def api_theme_set():
    data = request.get_json() or {}
    name = data.get("name", "Ocean Light")
    if not db():
        return ok()
    theme_path = db() + ".dbox.theme"
    try:
        existing = {}
        try:
            with open(theme_path) as f:
                existing = json.load(f)
        except Exception:
            pass
        existing["name"] = name
        with open(theme_path, "w") as f:
            json.dump(existing, f, indent=2)
    except Exception as e:
        return err(str(e))
    return ok()


@bp.route("/api/navigate", methods=["POST"])
@login_required
def api_navigate():
    data = request.get_json() or {}
    module = data.get("module", "")
    return ok({"module": module})


@bp.route("/api/company/rollover-status")
@login_required
def api_rollover_status():
    try:
        return ok(eofy_status(db()))
    except Exception as e:
        return err(str(e))


@bp.route("/api/company/rollover", methods=["POST"])
@login_required
def api_rollover():
    data    = request.get_json() or {}
    fy_year = data.get("fy_year")
    if not fy_year:
        return err("fy_year is required")
    try:
        result = perform_eofy_rollover(db(), int(fy_year))
        return ok(result)
    except Exception as e:
        return err(str(e))


@bp.route("/api/heartbeat", methods=["POST"])
def api_heartbeat():
    global _last_heartbeat
    with _app_state_lock:
        locked = _app_state["locked"]
    if locked:
        session.clear()
        return ok({"alive": False, "reason": "timeout"})
    _last_heartbeat = _time.time()
    _reset_shutdown_timer()
    return ok({"alive": True})
