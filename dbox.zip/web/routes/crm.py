import os
from flask import Blueprint, request, jsonify, send_file

from web.shared import db, ok, err, login_required, tier_required, dict_rows, current_user
from core.crm import (
    get_crm_dashboard, get_pipeline_summary, PIPELINE_STAGES,
    COMM_TYPES, TASK_TYPES, PRIORITY, QUOTE_STATUS,
    get_opportunities, get_opportunity, save_opportunity, delete_opportunity,
    next_opp_number, next_quote_number,
    get_communications, save_communication, delete_communication,
    get_tasks, save_task, complete_task, delete_task,
    get_quotes, get_quote, save_quote, accept_quote,
    convert_quote_to_invoice, delete_quote,
    get_progress_claims, save_progress_claim, claim_to_invoice, delete_progress_claim,
    log_email_activity,
)
from core.purchase_orders import create_po_from_crm_quote
from core.budget import audit
from core.ledger import get_contacts, get_invoices, get_bills
from core.licence import get_licence_status, watermark_text

bp = Blueprint('crm', __name__)


def _get_pdf_watermark() -> str | None:
    """
    Return a watermark string for PDFs if the licence is invalid/missing/lapsed,
    or None if fully licenced. Mirrors get_watermark() from ui/shared.py.
    The app_dir search matches app.py: one level up from server.py (web/).
    """
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
        return watermark_text(status)
    except Exception:
        return "Unregistered"


# ── CRM ────────────────────────────────────────────────────────────────────────

@bp.route("/api/crm/meta")
@login_required
def api_crm_meta():
    """Return pipeline stages, comm types, task types, priorities, quote statuses."""
    return ok({
        "pipeline_stages": PIPELINE_STAGES,
        "comm_types":      COMM_TYPES,
        "task_types":      TASK_TYPES,
        "priority":        PRIORITY,
        "quote_status":    QUOTE_STATUS,
    })


@bp.route("/api/crm/opportunities")
@login_required
def api_crm_opps():
    stage      = request.args.get("stage")
    search     = request.args.get("search")
    contact_id = request.args.get("contact_id", type=int)
    rows = get_opportunities(db(), stage=stage or None, search=search or None,
                             contact_id=contact_id or None)
    return ok(rows)


@bp.route("/api/crm/opportunities/<int:oid>")
@login_required
def api_crm_opp(oid):
    opp = get_opportunity(db(), oid)
    if not opp:
        return err("Not found", 404)
    comms  = get_communications(db(), opp_id=oid)
    tasks  = get_tasks(db(), opp_id=oid, open_only=False)
    quotes = get_quotes(db(), opp_id=oid)
    claims = get_progress_claims(db(), opp_id=oid)
    return ok({"opp": opp, "comms": comms, "tasks": tasks,
               "quotes": quotes, "claims": claims})


@bp.route("/api/crm/opportunities", methods=["POST"])
@login_required
def api_crm_opp_save():
    data = request.get_json() or {}
    try:
        if not data.get("opp_number"):
            data["opp_number"] = next_opp_number(db())
        data["created_by"] = current_user().get("id")
        oid = save_opportunity(db(), data)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "SaveOpportunity", "crm_opportunity", oid, data.get("title",""))
        return ok({"id": oid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/opportunities/<int:oid>", methods=["PUT"])
@login_required
def api_crm_opp_update(oid):
    data = request.get_json() or {}
    data["id"] = oid
    try:
        save_opportunity(db(), data)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "UpdateOpportunity", "crm_opportunity", oid, data.get("title",""))
        return ok({"id": oid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/opportunities/<int:oid>", methods=["DELETE"])
@login_required
def api_crm_opp_delete(oid):
    try:
        delete_opportunity(db(), oid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/next-opp-number")
@login_required
def api_crm_next_opp_number():
    return ok(next_opp_number(db()))


# ── CRM Communications ─────────────────────────────────────────────────────────

@bp.route("/api/crm/communications", methods=["POST"])
@login_required
def api_crm_comm_save():
    data = request.get_json() or {}
    data["logged_by"] = current_user().get("id")
    try:
        cid = save_communication(db(), data)
        return ok({"id": cid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/communications/<int:cid>", methods=["DELETE"])
@login_required
def api_crm_comm_delete(cid):
    try:
        delete_communication(db(), cid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── CRM Tasks ─────────────────────────────────────────────────────────────────

@bp.route("/api/crm/tasks", methods=["POST"])
@login_required
def api_crm_task_save():
    data = request.get_json() or {}
    try:
        tid = save_task(db(), data)
        return ok({"id": tid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/tasks/<int:tid>/complete", methods=["POST"])
@login_required
def api_crm_task_complete(tid):
    try:
        complete_task(db(), tid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/tasks/<int:tid>", methods=["DELETE"])
@login_required
def api_crm_task_delete(tid):
    try:
        delete_task(db(), tid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── Standalone Quotes list ────────────────────────────────────────────────────

@bp.route("/api/quotes")
@login_required
def api_quotes_all():
    """Return all quotes regardless of opportunity, enriched with contact/opp names."""
    quotes = get_quotes(db())          # opp_id=None → returns all
    contacts = {c["id"]: c["name"] for c in get_contacts(db())}
    result = []
    for q in quotes:
        q = dict(q)
        q["contact_name"] = contacts.get(q.get("contact_id"), "—")
        result.append(q)
    return ok(result)


@bp.route("/api/crm/quotes/<int:qid>/pdf")
@login_required
def api_crm_quote_pdf(qid):
    """Download a quote as a PDF."""
    try:
        from core.quote_pdf import generate_quote_pdf
        import tempfile, os
        from flask import send_file
        watermark = _get_pdf_watermark()
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
            tmp_path = tmp.name
        generate_quote_pdf(db(), qid, output_path=tmp_path, watermark=watermark)
        q, _ = get_quote(db(), qid)
        fname = f"Quote-{q['quote_number']}.pdf" if q else "quote.pdf"
        response = send_file(tmp_path, mimetype="application/pdf",
                             as_attachment=True, download_name=fname)
        @response.call_on_close
        def _cleanup():
            try: os.unlink(tmp_path)
            except: pass
        return response
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/quotes/<int:qid>/email", methods=["POST"])
@login_required
def api_crm_quote_email(qid):
    """Email a quote PDF to the contact."""
    from core.email_invoice import send_pdf_email
    import tempfile
    data = request.get_json() or {}
    to_email = (data.get("to") or "").strip()
    if not to_email:
        return err("Recipient email is required", 400)
    q, _ = get_quote(db(), qid)
    if not q:
        return err("Quote not found", 404)
    from core.quote_pdf import generate_quote_pdf
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
            tmp_path = tmp.name
        generate_quote_pdf(db(), qid, output_path=tmp_path,
                           watermark=_get_pdf_watermark())
        subject = data.get("subject") or f"Quote {q.get('quote_number','')} from {q.get('contact_name','')}"
        body    = data.get("body") or f"Please find attached quote {q.get('quote_number','')}.\n\nThank you."
        ok_flag, msg = send_pdf_email(db(), tmp_path, to_email, subject, body)
        if not ok_flag:
            return err(msg)
        log_email_activity(db(), q.get("contact_id"), subject, body)
        return ok()
    except Exception as e:
        return err(str(e))
    finally:
        if tmp_path:
            try: os.unlink(tmp_path)
            except Exception: pass


# ── CRM Quotes ────────────────────────────────────────────────────────────────

@bp.route("/api/crm/quotes/<int:qid>")
@login_required
def api_crm_quote(qid):
    q, lines = get_quote(db(), qid)
    if not q:
        return err("Not found", 404)
    return ok({"quote": q, "lines": lines})


@bp.route("/api/crm/quotes", methods=["POST"])
@login_required
def api_crm_quote_save():
    body = request.get_json() or {}
    qdata = body.get("quote", {})
    lines = body.get("lines", [])
    if not qdata.get("quote_number"):
        qdata["quote_number"] = next_quote_number(db())
    qdata["created_by"] = current_user().get("id")
    try:
        qid = save_quote(db(), qdata, lines)
        return ok({"id": qid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/quotes/<int:qid>", methods=["PUT"])
@login_required
def api_crm_quote_update(qid):
    body = request.get_json() or {}
    qdata = body.get("quote", {})
    lines = body.get("lines", [])
    qdata["id"] = qid
    try:
        save_quote(db(), qdata, lines)
        return ok({"id": qid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/quotes/<int:qid>/accept", methods=["POST"])
@login_required
def api_crm_quote_accept(qid):
    try:
        opp_id = accept_quote(db(), qid, current_user().get("username",""))
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "AcceptQuote", "crm_quote", qid, "")
        return ok({"opp_id": opp_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/quotes/<int:qid>/convert", methods=["POST"])
@login_required
def api_crm_quote_convert(qid):
    """Convert accepted quote to a draft invoice. Returns invoice_id."""
    try:
        inv_id = convert_quote_to_invoice(db(), qid, current_user().get("id"))
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "ConvertQuoteToInvoice", "crm_quote", qid, f"inv={inv_id}")
        return ok({"invoice_id": inv_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/quotes/<int:qid>", methods=["DELETE"])
@login_required
def api_crm_quote_delete(qid):
    try:
        delete_quote(db(), qid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── CRM Progress Claims ───────────────────────────────────────────────────────

@bp.route("/api/crm/claims", methods=["POST"])
@login_required
def api_crm_claim_save():
    data = request.get_json() or {}
    data["created_by"] = current_user().get("id")
    try:
        cid = save_progress_claim(db(), data)
        return ok({"id": cid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/claims/<int:cid>/convert", methods=["POST"])
@login_required
def api_crm_claim_convert(cid):
    try:
        inv_id = claim_to_invoice(db(), cid, current_user().get("id"))
        return ok({"invoice_id": inv_id})
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/claims/<int:cid>", methods=["DELETE"])
@login_required
def api_crm_claim_delete(cid):
    try:
        delete_progress_claim(db(), cid)
        return ok()
    except Exception as e:
        return err(str(e))


@bp.route("/api/crm/opportunities/<int:oid>/transactions")
@login_required
def api_crm_opp_transactions(oid):
    """Return invoices and bills linked to this opportunity via opp_id FK."""
    opp = get_opportunity(db(), oid)
    if not opp:
        return err("Not found", 404)

    invoices = get_invoices(db(), opp_id=oid)
    bills    = get_bills(db(),    opp_id=oid)

    rows = []
    for inv in invoices:
        rows.append({
            "type":        "Invoice",
            "id":          inv["id"],
            "number":      inv.get("invoice_number") or "",
            "date":        inv.get("invoice_date")   or "",
            "due_date":    inv.get("due_date")        or "",
            "status":      inv.get("status")          or "",
            "total":       float(inv.get("total")     or 0),
            "balance_due": round(float(inv.get("total") or 0)
                                 - float(inv.get("amount_paid") or 0), 2),
            "contact_name": inv.get("contact_name")  or "",
        })
    for bill in bills:
        rows.append({
            "type":        "Bill",
            "id":          bill["id"],
            "number":      bill.get("bill_number")  or "",
            "date":        bill.get("bill_date")    or "",
            "due_date":    bill.get("due_date")      or "",
            "status":      bill.get("status")        or "",
            "total":       float(bill.get("total")  or 0),
            "balance_due": round(float(bill.get("total") or 0)
                                 - float(bill.get("amount_paid") or 0), 2),
            "contact_name": bill.get("contact_name") or "",
        })

    rows.sort(key=lambda r: (r["date"] or ""), reverse=True)
    return ok(rows)
