# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import os
import json as _json
import datetime as _dt
import urllib.request as _urllib_req
from flask import (Blueprint, request, session, redirect, url_for,
                   render_template)

from web.shared import (db, ok, err, login_required, current_user,
                        _load_prefs, _save_prefs, TIER_CAPS, TIER_LABELS,
                        _get_tier, _get_licence_status, _get_update_info)
from web.routes.company import clear_lock
from core.auth import authenticate_user, set_own_password, ROLE_MODULES
from core.budget import audit
from core.database import get_connection
from core.licence import (status_banner, watermark_text, has_feature,
                           log_licence_event, ACTION_EULA_ACCEPT,
                           _parse_licence_text, verify_licence)

bp = Blueprint('auth', __name__)

CURRENT_EULA_VERSION = "6.0"
_LICENSER_URL = "https://license.dogboxsoftware.com.au"


# ── EULA helpers ──────────────────────────────────────────────────────────────

def _load_eula_text() -> str:
    # auth.py lives in web/routes/ — EULA.txt is at repo root (two levels up)
    this_dir = os.path.dirname(os.path.abspath(__file__))
    for path in [
        os.path.normpath(os.path.join(this_dir, "..", "..", "EULA.txt")),
        os.path.join(this_dir, "..", "EULA.txt"),
    ]:
        if os.path.isfile(path):
            with open(path, encoding="utf-8", errors="replace") as f:
                return f.read()
    return (
        "DOGBOX ACCOUNTING — END USER LICENCE AGREEMENT\n\n"
        "EULA.txt could not be found in the application directory.\n\n"
        "Please contact david.robert.innes@gmail.com to obtain a copy "
        "of the full licence agreement before using this software."
    )


def _eula_accepted() -> bool:
    return _load_prefs().get("eula_version") == CURRENT_EULA_VERSION


def _eula_acceptance_date() -> str:
    return _load_prefs().get("eula_date", "")


def _record_eula_acceptance():
    data = _load_prefs()
    data["eula_version"] = CURRENT_EULA_VERSION
    data["eula_date"]    = _dt.date.today().isoformat()
    _save_prefs(data)


# ── Registration helpers ──────────────────────────────────────────────────────

def _registration_done() -> bool:
    prefs = _load_prefs()
    if prefs.get("registered"):
        return True
    # Existing .lic file = issued via portal, already in the system — skip self-registration
    app_dir  = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    lic_path = os.path.join(app_dir, "dbox.lic")
    if os.path.isfile(lic_path):
        prefs["registered"] = True
        _save_prefs(prefs)
        return True
    return False


def _save_lic_file(lic_content: str):
    app_dir  = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    lic_path = os.path.join(app_dir, "dbox.lic")
    try:
        with open(lic_path, "w", encoding="utf-8") as fh:
            fh.write(lic_content)
    except Exception:
        pass


def _call_register_api(name: str, email: str) -> "str | None":
    try:
        payload = _json.dumps({"name": name, "email": email}).encode()
        req = _urllib_req.Request(
            f"{_LICENSER_URL}/api/register-free",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with _urllib_req.urlopen(req, timeout=10) as r:
            body = _json.loads(r.read())
        if body.get("ok"):
            return body.get("lic_content")
    except Exception:
        pass
    return None


def _record_registration(name: str, email: str, lic_content: "str | None" = None,
                          pending: bool = False):
    data = _load_prefs()
    data["registered"]  = True
    data["reg_name"]    = name
    data["reg_email"]   = email
    data["reg_pending"] = pending
    _save_prefs(data)
    if lic_content:
        _save_lic_file(lic_content)


def _retry_pending_registration():
    prefs = _load_prefs()
    if not prefs.get("reg_pending"):
        return
    name  = prefs.get("reg_name", "")
    email = prefs.get("reg_email", "")
    if not name or not email:
        return
    lic_content = _call_register_api(name, email)
    if lic_content:
        _record_registration(name, email, lic_content, pending=False)


# ── Brute-force protection ────────────────────────────────────────────────────

import threading as _threading
_login_attempts: dict = {}
_login_attempts_lock = _threading.Lock()
_MAX_ATTEMPTS  = 10
_LOCKOUT_SECS  = 300  # 5 minutes


def _check_rate_limit(ip: str) -> bool:
    import time
    now = time.time()
    with _login_attempts_lock:
        attempts = [t for t in _login_attempts.get(ip, []) if now - t < _LOCKOUT_SECS]
        _login_attempts[ip] = attempts
        return len(attempts) < _MAX_ATTEMPTS


def _record_attempt(ip: str):
    import time
    with _login_attempts_lock:
        _login_attempts.setdefault(ip, []).append(time.time())


def _clear_attempts(ip: str):
    with _login_attempts_lock:
        _login_attempts.pop(ip, None)


# ── Pages ─────────────────────────────────────────────────────────────────────

@bp.route("/")
def index():
    from flask import current_app
    if current_app.config.get('DEMO_MODE'):
        return redirect(url_for(".dashboard"))
    if not _eula_accepted():
        return redirect(url_for(".eula_page"))
    _retry_pending_registration()
    if not session.get("user"):
        return redirect(url_for(".login_page"))
    return redirect(url_for(".dashboard"))


@bp.route("/login", methods=["GET"])
def login_page():
    from flask import current_app
    if current_app.config.get('DEMO_MODE'):
        return redirect(url_for(".dashboard"))
    if not _eula_accepted():
        return redirect(url_for(".eula_page"))
    return render_template("login.html")


@bp.route("/eula", methods=["GET"])
def eula_page():
    from flask import current_app
    if current_app.config.get('DEMO_MODE'):
        return redirect(url_for(".dashboard"))
    if _eula_accepted():
        return redirect(url_for("."))
    return render_template("eula.html", eula_text=_load_eula_text(),
                           eula_version=CURRENT_EULA_VERSION)


@bp.route("/register", methods=["GET"])
def register_page():
    from flask import current_app
    if current_app.config.get('DEMO_MODE'):
        return redirect(url_for(".dashboard"))
    if not _eula_accepted():
        return redirect(url_for(".eula_page"))
    if _registration_done():
        return redirect(url_for(".login_page"))
    return render_template("register.html")


@bp.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html")


@bp.route("/<path:path>")
@login_required
def spa(path):
    if path.startswith("api/"):
        from flask import abort
        abort(404)
    return render_template("app.html", page=path.split("/")[0])


# ── EULA API ──────────────────────────────────────────────────────────────────

@bp.route("/api/eula/accept", methods=["POST"])
def api_eula_accept():
    _record_eula_acceptance()
    try:
        if db():
            log_licence_event(db(), ACTION_EULA_ACCEPT,
                              eula_version=CURRENT_EULA_VERSION)
    except Exception:
        pass
    return ok()


@bp.route("/api/register", methods=["POST"])
def api_register():
    data  = request.get_json() or {}
    name  = str(data.get("name", "")).strip()
    email = str(data.get("email", "")).strip()
    if not name or not email:
        return err("Name and email are required")
    lic_content = _call_register_api(name, email)
    _record_registration(name, email, lic_content, pending=(lic_content is None))
    return ok({"pending": lic_content is None})


@bp.route("/api/eula", methods=["GET"])
@login_required
def api_eula_status():
    return ok({
        "version":       CURRENT_EULA_VERSION,
        "accepted":      _eula_accepted(),
        "accepted_date": _eula_acceptance_date(),
        "text":          _load_eula_text(),
    })


# ── Licence API ───────────────────────────────────────────────────────────────

@bp.route("/api/licence", methods=["GET"])
@login_required
def api_licence_status():
    return ok(_get_licence_status())


@bp.route("/api/licence/upload", methods=["POST"])
@login_required
def api_licence_upload():
    f = request.files.get("licence")
    if not f:
        return err("No file provided")
    text = f.read().decode("utf-8", errors="replace")
    fields = _parse_licence_text(text)
    if not fields:
        return err("File could not be parsed — is this a valid dbox.lic?")
    if not verify_licence(fields):
        return err("Licence signature is invalid or the file has been modified")
    # auth.py is in web/routes/ — app root is three levels up
    app_dir  = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    lic_path = os.path.join(app_dir, "dbox.lic")
    with open(lic_path, "w", encoding="utf-8") as fh:
        fh.write(text)
    return ok(_get_licence_status())


# ── Auth API ──────────────────────────────────────────────────────────────────

@bp.route("/api/login", methods=["POST"])
def api_login():
    ip = request.remote_addr or "unknown"
    if not _check_rate_limit(ip):
        return err("Too many login attempts. Please wait 5 minutes.", 429)
    data = request.get_json() or {}
    user = authenticate_user(db(), data.get("username", ""), data.get("password", ""))
    if not user:
        _record_attempt(ip)
        return err("Invalid username or password", 401)
    _clear_attempts(ip)
    clear_lock()
    session.permanent = True
    tier = _get_tier(db())
    role = user["role"]
    role_mods = ROLE_MODULES.get(role)
    session["user"] = {
        "id":           user["id"],
        "username":     user["username"],
        "display_name": user["display_name"],
        "role":         role,
        "tier":         tier,
        "tier_label":   TIER_LABELS.get(tier, tier.title()),
        "tier_caps":    sorted(TIER_CAPS[tier]),
        "role_modules": sorted(role_mods) if role_mods is not None else None,
    }
    return ok({
        "display_name":          user["display_name"],
        "role":                  role,
        "tier":                  tier,
        "tier_label":            TIER_LABELS.get(tier, tier.title()),
        "role_modules":          sorted(role_mods) if role_mods is not None else None,
        "force_password_change": bool(user.get("force_password_change", 0)),
    })


@bp.route("/api/logout", methods=["POST"])
def api_logout():
    session.clear()
    return ok()


@bp.route("/api/me/set-password", methods=["POST"])
@login_required
def api_me_set_password():
    data     = request.get_json() or {}
    password = (data.get("password") or "").strip()
    if len(password) < 8:
        return err("Password must be at least 8 characters", 400)
    uid = session["user"]["id"]
    set_own_password(db(), uid, password)
    audit(db(), uid, session["user"]["username"], "change_own_password")
    return ok()


@bp.route("/api/me")
@login_required
def api_me():
    user = dict(current_user())
    try:
        lic    = _get_licence_status()
        banner = status_banner(lic)
        user["licence_status"]       = lic.get("status")
        user["licence_issued_to"]    = lic.get("issued_to")
        user["licence_banner"]       = {"message": banner[0], "severity": banner[1], "register_cta": banner[2]} if banner else None
        user["licence_watermark"]    = watermark_text(lic)
        user["payroll_enabled"]      = has_feature(lic, "payroll")
        user["registered"]           = _registration_done()
        # pos_enabled derived from pack caps, not a separate feature flag
        user["pos_enabled"]          = "pos" in set(user.get("tier_caps") or [])
        user["pack"]                 = user.get("tier", "core")
        user["is_pro"]               = user.get("tier") == "paid"
        user["maintenance_active"]   = lic.get("maintenance_active", True)
        try:
            _vpath = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
                os.path.abspath(__file__)))), "version.txt")
            APP_VERSION = open(_vpath).read().strip()
        except Exception:
            APP_VERSION = ""
        upd = _get_update_info(APP_VERSION)
        user["update_info"] = upd if upd and upd.get("ok") else None
    except Exception:
        user["licence_banner"]    = None
        user["licence_watermark"] = "Unregistered"
        user["payroll_enabled"]   = False
        user["pos_enabled"]       = False
    try:
        conn = get_connection(db())
        row  = conn.execute("SELECT gst_registered FROM company WHERE id=1").fetchone()
        conn.close()
        user["gst_registered"] = int(row["gst_registered"]) if row else 1
    except Exception:
        user["gst_registered"] = 1
    try:
        conn2 = get_connection(db())
        rows2 = conn2.execute(
            "SELECT tile_key FROM role_tile_defaults WHERE role=? AND enabled=0",
            (user.get("role", ""),)
        ).fetchall()
        conn2.close()
        user["tile_overrides"] = [r["tile_key"] for r in rows2]
    except Exception:
        user["tile_overrides"] = []
    return ok(user)
