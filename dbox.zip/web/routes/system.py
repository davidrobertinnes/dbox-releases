# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import os
import sys
import json
import shutil
import zipfile
import tempfile
import time as _time
import threading as _threading
import urllib.request
import urllib.error
from flask import Blueprint, request

from core.licence import VALIDATION_URL
from core.paths import user_data_dir, user_data_path, is_store_install
from core import usage as _usage
from web.shared import db, ok, err, login_required, main_computer_only, _get_licence_status

bp = Blueprint('system', __name__)

# Set by dbox.py after the browser process is launched.
# The shutdown route must close it directly — os._exit() bypasses atexit.
_browser_proc = None

_INSTALL_DIR = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
# Per-user folder; older versions kept dbox.conf in the install folder
_CONF_PATH = user_data_path('dbox.conf', os.path.join(_INSTALL_DIR, 'dbox.conf'))


def _load_conf() -> dict:
    try:
        with open(_CONF_PATH) as f:
            return json.load(f)
    except Exception:
        return {}


def _save_conf(conf: dict) -> None:
    with open(_CONF_PATH, 'w') as f:
        json.dump(conf, f, indent=2)


def _kill_browser():
    if not _browser_proc or _browser_proc.poll() is not None:
        return
    try:
        if sys.platform == "win32":
            import subprocess as _sp
            _sp.call(['taskkill', '/F', '/T', '/PID', str(_browser_proc.pid)],
                     stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)
        else:
            _browser_proc.terminate()
    except Exception:
        pass


_VERSION_FILE  = os.path.join(os.path.dirname(__file__), '..', '..', 'version.txt')
APP_VERSION    = open(_VERSION_FILE).read().strip() if os.path.exists(_VERSION_FILE) else 'dev'
_UPDATE_URL    = 'https://raw.githubusercontent.com/davidrobertinnes/dbox-releases/main/version.json'
# Bug reports go to the licence server, which files the GitHub issue — no
# credential ships in the app (it's a public zip).
_BUG_REPORT_URL = VALIDATION_URL.rstrip('/') + '/api/bug-report'
_update_cache: dict = {}
_update_prog:  dict = {'state': 'idle', 'pct': 0, 'error': None}


# Pre-update copies of overwritten files, kept in the per-user folder.
# Older versions kept them in <install>/backups — cleared on the next update.
_BACKUP_ROOT = os.path.join(user_data_dir(), 'update-backups')


def _remove_legacy_backups(install_dir):
    # Only the updater's own pre-* copies; the folder goes only if that empties it
    legacy = os.path.join(install_dir, 'backups')
    if not os.path.isdir(legacy):
        return
    for e in os.listdir(legacy):
        if e.startswith('pre-'):
            shutil.rmtree(os.path.join(legacy, e), ignore_errors=True)
    try:
        os.rmdir(legacy)
    except OSError:
        pass


def _prune_backups(install_dir, keep=2):
    _remove_legacy_backups(install_dir)
    backup_root = _BACKUP_ROOT
    if not os.path.isdir(backup_root):
        return
    entries = sorted(
        [e for e in os.listdir(backup_root) if e.startswith('pre-')],
        reverse=True,
    )
    for old in entries[keep:]:
        shutil.rmtree(os.path.join(backup_root, old), ignore_errors=True)


def _do_update(url):
    install_dir = os.path.normpath(
        os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')
    )
    SKIP = {'backups', '.git', '__pycache__', 'scratch'}
    backup_dir = None
    try:
        with tempfile.TemporaryDirectory() as tmp:
            zip_path = os.path.join(tmp, 'update.zip')

            def _progress(count, block, total):
                if total > 0:
                    _update_prog['pct'] = min(int(count * block * 100 / total), 90)

            urllib.request.urlretrieve(url, zip_path, _progress)
            _update_prog.update({'state': 'applying', 'pct': 91})

            extract_dir = os.path.join(tmp, 'x')
            with zipfile.ZipFile(zip_path) as zf:
                names = zf.namelist()
                tops = {n.split('/')[0] for n in names}
                prefix = (tops.pop() + '/') if len(tops) == 1 else ''
                for m in zf.infolist():
                    rel = m.filename[len(prefix):] if prefix else m.filename
                    if not rel or any(part in SKIP for part in rel.split('/')):
                        continue
                    m.filename = rel
                    zf.extract(m, extract_dir)

            # Back up only the files about to be overwritten, before touching anything.
            backup_dir = os.path.join(_BACKUP_ROOT, f'pre-{int(_time.time())}')
            os.makedirs(backup_dir, exist_ok=True)
            _update_prog.update({'state': 'applying', 'pct': 93})
            for root, dirs, files in os.walk(extract_dir):
                dirs[:] = [d for d in dirs if d not in SKIP]
                rel_root = os.path.relpath(root, extract_dir)
                for f in files:
                    if f.endswith('.dbox') or f.lower() in {'desktop.ini', 'thumbs.db'}:
                        continue
                    existing = os.path.join(install_dir, rel_root, f)
                    if os.path.exists(existing):
                        bak = os.path.join(backup_dir, rel_root, f)
                        os.makedirs(os.path.dirname(bak), exist_ok=True)
                        shutil.copy2(existing, bak)

            # Apply update
            _update_prog.update({'state': 'applying', 'pct': 96})
            for root, dirs, files in os.walk(extract_dir):
                dirs[:] = [d for d in dirs if d not in SKIP]
                rel_root = os.path.relpath(root, extract_dir)
                for f in files:
                    if f.endswith('.dbox') or f.lower() in {'desktop.ini', 'thumbs.db'}:
                        continue
                    src = os.path.join(root, f)
                    dst = os.path.join(install_dir, rel_root, f)
                    os.makedirs(os.path.dirname(dst), exist_ok=True)
                    shutil.copy2(src, dst)

        _prune_backups(install_dir)
        _update_prog.update({'state': 'done', 'pct': 100})

    except Exception as e:
        # Best-effort restore from backup before reporting failure
        if backup_dir and os.path.exists(backup_dir):
            try:
                for root, dirs, files in os.walk(backup_dir):
                    rel_root = os.path.relpath(root, backup_dir)
                    for f in files:
                        src = os.path.join(root, f)
                        dst = os.path.join(install_dir, rel_root, f)
                        os.makedirs(os.path.dirname(dst), exist_ok=True)
                        shutil.copy2(src, dst)
            except Exception:
                pass
        _update_prog.update({'state': 'error', 'error': str(e)})


@bp.route('/api/system/version')
@login_required
def api_system_version():
    _usage.ping('dbox', APP_VERSION, user_data_dir(), store=is_store_install(),
                licence_fn=lambda: _usage.licence_kind(_get_licence_status()))
    if is_store_install():
        # The Microsoft Store updates the app; don't check or offer updates
        return ok({
            'current':            APP_VERSION,
            'latest':             APP_VERSION,
            'update_available':   False,
            'notes':              '',
            'download_url':       '',
            'maintenance_active': True,
            'entitled_to_update': False,
            'store_install':      True,
        })
    now = _time.time()
    if not _update_cache or now - _update_cache.get('checked_at', 0) > 86400:
        try:
            with urllib.request.urlopen(_UPDATE_URL, timeout=5) as r:
                data = json.loads(r.read())
            _update_cache.update({**data, 'checked_at': now})
        except Exception:
            _update_cache['checked_at'] = now
    latest  = _update_cache.get('version')
    current = tuple(int(x) for x in APP_VERSION.split('.') if x.isdigit())
    newest  = tuple(int(x) for x in latest.split('.') if x.isdigit()) if latest else ()
    update_available = newest > current
    lic = _get_licence_status()
    maintenance_active   = lic.get('maintenance_active', True)
    # Updates aren't gated: a lapsed subscription locks Pro features instead
    entitled_to_update   = update_available
    return ok({
        'current':            APP_VERSION,
        'latest':             latest,
        'update_available':   update_available,
        'notes':              _update_cache.get('notes', ''),
        'download_url':       _update_cache.get('url', ''),
        'maintenance_active': maintenance_active,
        'entitled_to_update': entitled_to_update,
        'store_install':      False,
    })


@bp.route('/api/system/apply-update', methods=['POST'])
@login_required
@main_computer_only
def api_system_apply_update():
    if is_store_install():
        # Package files are read-only and the Store handles updates
        return err('Updates are installed by the Microsoft Store.')
    url = (request.json or {}).get('url', '')
    if not url:
        return err('No download URL')
    _update_prog.update({'state': 'downloading', 'pct': 0, 'error': None})
    _threading.Thread(target=_do_update, args=(url,), daemon=True).start()
    return ok({'started': True})


@bp.route('/api/system/update-progress')
@login_required
def api_system_update_progress():
    return ok(_update_prog)


@bp.route('/api/system/server-config')
@login_required
def api_server_config_get():
    from flask import current_app
    lan_active = current_app.config.get('LAN_MODE', False)
    conf = _load_conf()
    from core.ports import load_port
    result = {
        'lan':      lan_active,
        'lan_conf': conf.get('lan', False),
        'port':     current_app.config.get('PORT') or request.host.rpartition(':')[2],
        'port_saved':   load_port(_CONF_PATH),
        'port_default': 5000,
    }
    if lan_active:
        try:
            import socket
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            result['lan_ip'] = s.getsockname()[0]
            s.close()
        except Exception:
            result['lan_ip'] = None
    return ok(result)


@bp.route('/api/system/server-config', methods=['POST'])
@login_required
@main_computer_only
def api_server_config_set():
    data = request.json or {}
    if 'lan' in data:
        new_lan = bool(data['lan'])
        if new_lan:
            try:
                from core.licence import get_licence_status, has_feature
                app_dir = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', '..'))
                lic = get_licence_status(app_dir)
                if not has_feature(lic, 'lan'):
                    return err('LAN mode is not available on this licence. Contact support to enable multi-user access.')
            except Exception as e:
                return err(f'Could not verify licence: {e}')
        conf = _load_conf()
        conf['lan'] = new_lan
        _save_conf(conf)
    if 'port' in data:
        from core.ports import save_port
        raw = str(data.get('port') or '').strip()
        try:
            save_port(_CONF_PATH, int(raw) if raw else None)
        except ValueError as e:
            return err(str(e) if 'port' in str(e) else 'Enter a whole number from 1024 to 65535')
        except OSError as e:
            return err(f"Couldn't save the setting: {e}")
    return ok()


@bp.route('/api/system/shutdown', methods=['POST'])
@login_required
@main_computer_only
def api_system_shutdown():
    def _exit():
        import time; time.sleep(0.4)
        _kill_browser()
        os._exit(0)
    _threading.Thread(target=_exit, daemon=True).start()
    return ok({'stopped': True})


@bp.route('/api/system/restart', methods=['POST'])
@login_required
@main_computer_only
def api_system_restart():
    from flask import current_app
    port = current_app.config.get('PORT')   # restart on the same port: the window reloads from it
    # Hand the session key to the new server so whoever is signed in stays signed in
    # (the window reloads to the dashboard instead of the login screen).
    session_key = current_app.secret_key
    session_key = session_key.hex() if isinstance(session_key, bytes) else ''
    # The open file: app.config has it however it was opened. web.server.DB_PATH
    # is only set when dbox.py was given the file, not when it was opened from the
    # startup page (the usual way), so the restart came back with no file open.
    import web.server as _wsrv
    db_path = current_app.config.get('DB_PATH') or getattr(_wsrv, 'DB_PATH', None)

    def _do_restart():
        import time, subprocess as _sp
        time.sleep(0.4)
        # Don't kill the browser — the JS poller in _shutdownDogbox will reload
        # the existing window once the new server is up (avoids Chrome profile-lock
        # issues that caused the new browser instance to crash on restart).
        script = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'dbox.py')
        )
        cmd = [sys.executable, script]
        db_path_passed = bool(db_path)
        if db_path_passed:
            cmd.append(db_path)
        if port:
            cmd += ['--port', str(port)]
        env = {**os.environ, 'DBOX_RESTART_DELAY': '2', 'PYTHONUTF8': '1'}
        if session_key and db_path_passed:
            env['DBOX_SESSION_KEY'] = session_key
        cwd = os.path.dirname(script)
        # Beside dbox_error.log (per-user folder) — the install folder may be read-only
        from core.logger import get_log_path
        _main_log = get_log_path()
        log_path = os.path.join(os.path.dirname(_main_log) if _main_log else cwd,
                                'restart.log')
        try:
            with open(log_path, 'w') as _log:
                _log.write(f'cmd: {cmd}\ncwd: {cwd}\n')
                _log.flush()
                kwargs = dict(env=env, cwd=cwd, stdout=_log, stderr=_log)
                if sys.platform == 'win32':
                    kwargs['creationflags'] = _sp.CREATE_NO_WINDOW | _sp.CREATE_NEW_PROCESS_GROUP
                else:
                    kwargs['start_new_session'] = True
                _sp.Popen(cmd, **kwargs)
        except Exception as _e:
            with open(log_path, 'a') as _log:
                _log.write(f'Popen failed: {_e}\n')
        time.sleep(0.2)
        os._exit(0)
    _threading.Thread(target=_do_restart, daemon=True).start()
    return ok({'restarting': True})


@bp.route('/api/system/bug-report', methods=['POST'])
@login_required
def api_system_bug_report():
    import platform
    data = request.json or {}
    description = (data.get('description') or '').strip()
    if not description:
        return err('Description is required')

    from core.logger import get_log_tail
    payload = json.dumps({
        'description': description,
        'version': APP_VERSION,
        'os': f"{platform.system()} {platform.release()} ({platform.machine()})",
        'log_tail': get_log_tail(30),
    }).encode()
    req = urllib.request.Request(
        _BUG_REPORT_URL,
        data=payload,
        headers={'Content-Type': 'application/json', 'User-Agent': f'dbox/{APP_VERSION}'},
        method='POST',
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            resp = json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            resp = json.loads(e.read())
        except Exception:
            resp = {'error': f'HTTP {e.code}'}
    except Exception:
        return err("Couldn't reach Dogbox to send the report. Check your internet "
                   "connection, or email dogboxsoftware@gmail.com.")
    if not resp.get('ok'):
        return err(resp.get('error') or 'Could not submit report')
    return ok({'number': resp.get('number')})


@bp.route('/api/alive')
def api_alive():
    # 'app' lets a new launch tell this server from another program on the port (core/ports.py)
    return ok({'alive': True, 'app': 'dogbox-accounting'})


@bp.route('/api/system/close-beacon', methods=['POST'])
def api_close_beacon():
    remote = request.remote_addr or ''
    if remote not in ('127.0.0.1', '::1'):
        return ('', 403)
    def _exit():
        import time; time.sleep(1.5)
        # If the browser process is still alive, this was a reload (e.g. Ctrl+Shift+R)
        # not a genuine close — don't exit.
        if _browser_proc and _browser_proc.poll() is None:
            return
        os._exit(0)
    _threading.Thread(target=_exit, daemon=True).start()
    return ('', 204)
