# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import os
import sys
import json
import shutil
import zipfile
import tempfile
import time as _time
import threading as _threading
import urllib.request
from flask import Blueprint, request

from web.shared import db, ok, err, login_required, _get_licence_status

bp = Blueprint('system', __name__)

# Set by web_server.py after the browser process is launched.
# The shutdown route must close it directly — os._exit() bypasses atexit.
_browser_proc = None

_CONF_PATH = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', '..', 'dbox.conf'))


def _load_conf() -> dict:
    try:
        with open(_CONF_PATH) as f:
            return json.load(f)
    except Exception:
        return {}


def _save_conf(conf: dict) -> None:
    with open(_CONF_PATH, 'w') as f:
        json.dump(conf, f, indent=2)


def _kill_browser():
    if not _browser_proc or _browser_proc.poll() is not None:
        return
    try:
        if sys.platform == "win32":
            import subprocess as _sp
            _sp.call(['taskkill', '/F', '/T', '/PID', str(_browser_proc.pid)],
                     stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)
        else:
            _browser_proc.terminate()
    except Exception:
        pass


_VERSION_FILE = os.path.join(os.path.dirname(__file__), '..', '..', 'version.txt')
APP_VERSION   = open(_VERSION_FILE).read().strip() if os.path.exists(_VERSION_FILE) else 'dev'
_UPDATE_URL   = 'https://raw.githubusercontent.com/davidrobertinnes/dbox-releases/main/version.json'
_update_cache: dict = {}
_update_prog:  dict = {'state': 'idle', 'pct': 0, 'error': None}


def _do_update(url):
    install_dir = os.path.normpath(
        os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')
    )
    SKIP = {'backups', '.git', '__pycache__'}
    try:
        with tempfile.TemporaryDirectory() as tmp:
            zip_path = os.path.join(tmp, 'update.zip')

            def _progress(count, block, total):
                if total > 0:
                    _update_prog['pct'] = min(int(count * block * 100 / total), 95)

            urllib.request.urlretrieve(url, zip_path, _progress)
            _update_prog.update({'state': 'applying', 'pct': 96})

            extract_dir = os.path.join(tmp, 'x')
            with zipfile.ZipFile(zip_path) as zf:
                names = zf.namelist()
                tops = {n.split('/')[0] for n in names}
                prefix = (tops.pop() + '/') if len(tops) == 1 else ''
                for m in zf.infolist():
                    rel = m.filename[len(prefix):] if prefix else m.filename
                    if not rel or any(part in SKIP for part in rel.split('/')):
                        continue
                    m.filename = rel
                    zf.extract(m, extract_dir)

            for root, dirs, files in os.walk(extract_dir):
                dirs[:] = [d for d in dirs if d not in SKIP]
                rel_root = os.path.relpath(root, extract_dir)
                for f in files:
                    if f.endswith('.dbox') or f.lower() in {'desktop.ini', 'thumbs.db'}:
                        continue
                    src = os.path.join(root, f)
                    dst = os.path.join(install_dir, rel_root, f)
                    os.makedirs(os.path.dirname(dst), exist_ok=True)
                    shutil.copy2(src, dst)

        _update_prog.update({'state': 'done', 'pct': 100})
    except Exception as e:
        _update_prog.update({'state': 'error', 'error': str(e)})


@bp.route('/api/system/version')
@login_required
def api_system_version():
    now = _time.time()
    if not _update_cache or now - _update_cache.get('checked_at', 0) > 86400:
        try:
            with urllib.request.urlopen(_UPDATE_URL, timeout=5) as r:
                data = json.loads(r.read())
            _update_cache.update({**data, 'checked_at': now})
        except Exception:
            _update_cache['checked_at'] = now
    latest  = _update_cache.get('version')
    current = tuple(int(x) for x in APP_VERSION.split('.') if x.isdigit())
    newest  = tuple(int(x) for x in latest.split('.') if x.isdigit()) if latest else ()
    update_available = newest > current
    lic = _get_licence_status()
    maintenance_active   = lic.get('maintenance_active', True)
    entitled_to_update   = update_available and maintenance_active
    return ok({
        'current':            APP_VERSION,
        'latest':             latest,
        'update_available':   update_available,
        'notes':              _update_cache.get('notes', ''),
        'download_url':       _update_cache.get('url', ''),
        'maintenance_active': maintenance_active,
        'entitled_to_update': entitled_to_update,
    })


@bp.route('/api/system/apply-update', methods=['POST'])
@login_required
def api_system_apply_update():
    url = (request.json or {}).get('url', '')
    if not url:
        return err('No download URL')
    _update_prog.update({'state': 'downloading', 'pct': 0, 'error': None})
    _threading.Thread(target=_do_update, args=(url,), daemon=True).start()
    return ok({'started': True})


@bp.route('/api/system/update-progress')
@login_required
def api_system_update_progress():
    return ok(_update_prog)


@bp.route('/api/system/server-config')
@login_required
def api_server_config_get():
    from flask import current_app
    lan_active = current_app.config.get('LAN_MODE', False)
    conf = _load_conf()
    result = {
        'lan':      lan_active,
        'lan_conf': conf.get('lan', False),
    }
    if lan_active:
        try:
            import socket
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            result['lan_ip'] = s.getsockname()[0]
            s.close()
        except Exception:
            result['lan_ip'] = None
    return ok(result)


@bp.route('/api/system/server-config', methods=['POST'])
@login_required
def api_server_config_set():
    data = request.json or {}
    if 'lan' in data:
        new_lan = bool(data['lan'])
        if new_lan:
            try:
                from core.licence import get_licence_status, has_feature
                app_dir = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', '..'))
                lic = get_licence_status(app_dir)
                if not has_feature(lic, 'lan'):
                    return err('LAN mode is not available on this licence. Contact support to enable multi-user access.')
            except Exception as e:
                return err(f'Could not verify licence: {e}')
        conf = _load_conf()
        conf['lan'] = new_lan
        _save_conf(conf)
    return ok()


@bp.route('/api/system/shutdown', methods=['POST'])
@login_required
def api_system_shutdown():
    def _exit():
        import time; time.sleep(0.4)
        _kill_browser()
        os._exit(0)
    _threading.Thread(target=_exit, daemon=True).start()
    return ok({'stopped': True})


@bp.route('/api/system/restart', methods=['POST'])
@login_required
def api_system_restart():
    def _do_restart():
        import time, subprocess as _sp
        time.sleep(0.4)
        # Don't kill the browser — the JS poller in _shutdownDogbox will reload
        # the existing window once the new server is up (avoids Chrome profile-lock
        # issues that caused the new browser instance to crash on restart).
        script = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'web_server.py')
        )
        cmd = [sys.executable, script]
        try:
            import web.server as _wsrv
            db_path = getattr(_wsrv, 'DB_PATH', None)
            if db_path:
                cmd.append(db_path)
        except Exception:
            pass
        env = {**os.environ, 'DBOX_RESTART_DELAY': '2', 'PYTHONUTF8': '1'}
        cwd = os.path.dirname(script)
        log_path = os.path.join(cwd, 'restart.log')
        try:
            with open(log_path, 'w') as _log:
                _log.write(f'cmd: {cmd}\ncwd: {cwd}\n')
                _log.flush()
                kwargs = dict(env=env, cwd=cwd, stdout=_log, stderr=_log)
                if sys.platform == 'win32':
                    kwargs['creationflags'] = _sp.CREATE_NO_WINDOW | _sp.CREATE_NEW_PROCESS_GROUP
                else:
                    kwargs['start_new_session'] = True
                _sp.Popen(cmd, **kwargs)
        except Exception as _e:
            with open(log_path, 'a') as _log:
                _log.write(f'Popen failed: {_e}\n')
        time.sleep(0.2)
        os._exit(0)
    _threading.Thread(target=_do_restart, daemon=True).start()
    return ok({'restarting': True})


@bp.route('/api/alive')
def api_alive():
    return ok({'alive': True})


@bp.route('/api/system/close-beacon', methods=['POST'])
def api_close_beacon():
    remote = request.remote_addr or ''
    if remote not in ('127.0.0.1', '::1'):
        return ('', 403)
    def _exit():
        import time; time.sleep(1.5)
        # If the browser process is still alive, this was a reload (e.g. Ctrl+Shift+R)
        # not a genuine close — don't exit.
        if _browser_proc and _browser_proc.poll() is None:
            return
        os._exit(0)
    _threading.Thread(target=_exit, daemon=True).start()
    return ('', 204)
