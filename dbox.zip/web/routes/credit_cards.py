# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

from flask import Blueprint, request

from web.shared import db, ok, err, login_required
from core.ledger import (
    get_credit_card_accounts, record_credit_card_charge,
    record_credit_card_payment, get_credit_card_transactions,
    get_credit_card_balance, void_cc_charge,
)

bp = Blueprint('credit_cards', __name__)


@bp.route("/api/credit-cards")
@login_required
def api_credit_cards():
    cards = get_credit_card_accounts(db())
    result = []
    for c in cards:
        d = dict(c)
        d["balance"] = round(get_credit_card_balance(db(), c["id"]), 2)
        result.append(d)
    return ok(result)


@bp.route("/api/credit-cards/<int:cid>/transactions")
@login_required
def api_cc_transactions(cid):
    txns = get_credit_card_transactions(db(), cid,
        date_from=request.args.get("from"),
        date_to=request.args.get("to"))
    return ok([dict(t) for t in txns])


@bp.route("/api/credit-cards/charge", methods=["POST"])
@login_required
def api_cc_charge():
    d = request.get_json() or {}
    try:
        jid = record_credit_card_charge(
            db(), d["card_id"], d["date"], d["description"],
            float(d["amount"]), d["expense_account_id"],
            reference=d.get("reference", ""),
            tax_code=d.get("tax_code"),
            gst_amount=float(d.get("gst_amount", 0)),
            contact_id=d.get("contact_id") or None,
        )
        return ok({"journal_id": jid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/credit-cards/payment", methods=["POST"])
@login_required
def api_cc_payment():
    d = request.get_json() or {}
    try:
        jid = record_credit_card_payment(
            db(), d["card_id"], d["date"],
            float(d["amount"]), d["bank_account_id"],
            reference=d.get("reference", ""),
            description=d.get("description", "Credit Card Payment"),
        )
        return ok({"journal_id": jid})
    except Exception as e:
        return err(str(e))


@bp.route("/api/credit-cards/void/<int:journal_id>", methods=["POST"])
@login_required
def api_cc_void(journal_id):
    try:
        void_cc_charge(db(), journal_id)
        return ok()
    except Exception as e:
        return err(str(e))
