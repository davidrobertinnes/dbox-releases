import csv
import io
import datetime as _dt
from flask import Blueprint, request

from web.shared import db, ok, err, login_required
from core.ledger import (
    post_journal, save_invoice, save_bill, import_transactions,
)
from core.database import get_connection

bp = Blueprint('settings', __name__)


# ── Email / SMTP ───────────────────────────────────────────────────────────────

@bp.route("/api/settings/email", methods=["GET"])
@login_required
def api_email_settings_get():
    from core.email_invoice import get_email_settings
    return ok(get_email_settings(db()))


@bp.route("/api/settings/email", methods=["POST"])
@login_required
def api_email_settings_save():
    from core.email_invoice import save_email_settings
    data = request.get_json() or {}
    save_email_settings(db(), data)
    return ok()


@bp.route("/api/settings/email/test", methods=["POST"])
@login_required
def api_email_test():
    import smtplib, ssl
    data = request.get_json() or {}
    host = data.get("smtp_host", "").strip()
    port = int(data.get("smtp_port") or 587)
    user = data.get("smtp_user", "").strip()
    pwd  = data.get("smtp_password", "")
    tls  = int(data.get("use_tls", 1))
    if not host or not user or not pwd:
        return err("Fill in host, username, and password first")
    try:
        ctx = ssl.create_default_context()
        if port == 465:
            with smtplib.SMTP_SSL(host, port, context=ctx) as s:
                s.login(user, pwd)
        else:
            with smtplib.SMTP(host, port, timeout=10) as s:
                if tls:
                    s.starttls(context=ctx)
                s.login(user, pwd)
        return ok()
    except smtplib.SMTPAuthenticationError:
        return err("Authentication failed. For Gmail use an App Password, not your regular password.")
    except Exception as e:
        return err(str(e))


# ── Discount Limits ────────────────────────────────────────────────────────────

@bp.route("/api/settings/discount-limits", methods=["GET"])
@login_required
def api_discount_limits_get():
    from core.discounts import get_discount_limits
    return ok(get_discount_limits(db()))


@bp.route("/api/settings/discount-limits", methods=["POST"])
@login_required
def api_discount_limits_save():
    from core.discounts import save_discount_limits
    data = request.get_json() or {}
    for role, val in data.items():
        try:
            v = float(val)
            if v < 0 or v > 100:
                return err(f"{role}: percentage must be 0–100")
        except (TypeError, ValueError):
            return err(f"{role}: must be a number")
    save_discount_limits(db(), {k: float(v) for k, v in data.items()})
    return ok()


# ── Opening Balance Wizard ─────────────────────────────────────────────────────

@bp.route("/api/opening-balances/status")
@login_required
def api_ob_status():
    conn = get_connection(db())
    n = conn.execute(
        "SELECT COUNT(*) as n FROM journal_entries "
        "WHERE reference LIKE 'OB-%' OR description='Opening balances'"
    ).fetchone()["n"]
    conn.close()
    return ok({"already_posted": n > 0, "count": n})


@bp.route("/api/opening-balances", methods=["POST"])
@login_required
def api_ob_post():
    data     = request.get_json() or {}
    date_str = (data.get("date") or "").strip()
    entries  = data.get("entries") or []
    try:
        _dt.date.fromisoformat(date_str)
    except ValueError:
        return err("Invalid date — use YYYY-MM-DD")

    DEBIT_TYPES = {"Asset", "Bank", "Expense", "Accounts Receivable",
                   "Cost of Sales", "Credit Card"}
    conn  = get_connection(db())
    lines = []
    total_dr = total_cr = 0.0
    for e in entries:
        try:
            amt = float(e.get("amount") or 0)
        except (TypeError, ValueError):
            continue
        if amt < 0.005:
            continue
        acc = conn.execute(
            "SELECT id, name, account_type FROM accounts WHERE id=?",
            (e.get("account_id"),)).fetchone()
        if not acc:
            continue
        if acc["account_type"] in DEBIT_TYPES:
            lines.append({"account_id": acc["id"], "debit": amt, "credit": 0.0,
                          "description": acc["name"]})
            total_dr += amt
        else:
            lines.append({"account_id": acc["id"], "debit": 0.0, "credit": amt,
                          "description": acc["name"]})
            total_cr += amt

    diff = round(total_dr - total_cr, 2)
    if abs(diff) > 0.01:
        re_acc = conn.execute(
            "SELECT id FROM accounts WHERE code LIKE '3-%' "
            "AND name LIKE '%Retained%' LIMIT 1").fetchone()
        if re_acc:
            if diff > 0:
                lines.append({"account_id": re_acc["id"], "debit": 0.0, "credit": diff,
                              "description": "Retained Earnings (auto-balance)"})
            else:
                lines.append({"account_id": re_acc["id"], "debit": abs(diff), "credit": 0.0,
                              "description": "Retained Earnings (auto-balance)"})
    conn.close()

    if not lines:
        return err("No valid entries — enter at least one non-zero balance")
    try:
        post_journal(db(), date_str, "Opening balances", f"OB-{date_str}", lines)
        conn2 = get_connection(db())
        for e in entries:
            try:
                conn2.execute("UPDATE accounts SET opening_balance=0 WHERE id=?",
                              (e["account_id"],))
            except Exception:
                pass
        conn2.commit(); conn2.close()
        return ok({"posted": len(lines)})
    except Exception as exc:
        return err(str(exc))


# ── Import report CSV (parse only) ────────────────────────────────────────────

@bp.route("/api/import/parse-report-csv", methods=["POST"])
@login_required
def api_import_parse_report_csv():
    if "file" not in request.files:
        return err("No file uploaded")
    f = request.files["file"]
    if not f.filename:
        return err("No file selected")
    import tempfile, os as _os
    tmp = tempfile.NamedTemporaryFile(suffix=".csv", delete=False)
    try:
        f.save(tmp.name); tmp.close()
        from core.importer import parse_report_csv
        result = parse_report_csv(tmp.name)
        return ok(result)
    except Exception as exc:
        return err(str(exc))
    finally:
        try: _os.unlink(tmp.name)
        except Exception: pass


# ── Transaction Import Wizard ─────────────────────────────────────────────────

@bp.route("/api/txn-import/parse", methods=["POST"])
@login_required
def api_txn_import_parse():
    if "file" not in request.files:
        return err("No file uploaded")
    f = request.files["file"]
    if not f.filename:
        return err("No file selected")
    try:
        content = f.read().decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(content))
        accounts = {}
        counterparties = {}
        type_counts = {}
        dates = []
        for row in reader:
            txn_type = (row.get("Transaction type") or "").strip()
            acct_id  = (row.get("Account ID") or "").strip()
            acct_nm  = (row.get("Account name") or "").strip()
            acct_tp  = (row.get("Account type") or "").strip()
            cp_id    = (row.get("Counterparty ID") or "").strip()
            cp_nm    = (row.get("Counterparty legal name") or "").strip()
            date_str = (row.get("Date") or "").strip()
            if txn_type:
                type_counts[txn_type] = type_counts.get(txn_type, 0) + 1
            if acct_id and acct_nm:
                if acct_id not in accounts:
                    accounts[acct_id] = {"ext_id": acct_id, "ext_name": acct_nm,
                                         "ext_type": acct_tp, "count": 0}
                accounts[acct_id]["count"] += 1
            if cp_id and cp_nm:
                if cp_id not in counterparties:
                    counterparties[cp_id] = {"ext_id": cp_id, "ext_name": cp_nm, "count": 0}
                counterparties[cp_id]["count"] += 1
            if date_str:
                dates.append(date_str)
        summary = dict(type_counts)
        if dates:
            summary["date_from"] = min(dates)
            summary["date_to"]   = max(dates)
        return ok({
            "accounts":       sorted(accounts.values(),       key=lambda x: x["ext_name"]),
            "counterparties": sorted(counterparties.values(), key=lambda x: x["ext_name"]),
            "summary":        summary,
        })
    except Exception as exc:
        return err(str(exc))


@bp.route("/api/txn-import/confirm", methods=["POST"])
@login_required
def api_txn_import_confirm():
    import json as _json
    if "file" not in request.files:
        return err("No file uploaded")
    f = request.files["file"]
    try:
        config = _json.loads(request.form.get("config", "{}"))
    except Exception:
        return err("Invalid config JSON")

    account_map = {str(k): int(v) for k, v in config.get("account_map", {}).items() if v}
    balancing   = {k: int(v) for k, v in config.get("balancing", {}).items() if v}
    contact_map = {}
    for k, v in config.get("contact_map", {}).items():
        try:
            iv = int(v)
            contact_map[str(k)] = iv if iv > 0 else None
        except Exception:
            contact_map[str(k)] = None
    date_from = config.get("date_from", "")
    date_to   = config.get("date_to", "")

    try:
        content = f.read().decode("utf-8-sig")
        reader  = csv.DictReader(io.StringIO(content))
        rows = []
        for row in reader:
            date_str = (row.get("Date") or "").strip()
            if not date_str:
                continue
            if date_from and date_str < date_from:
                continue
            if date_to and date_str > date_to:
                continue
            try:
                amount = float(row.get("Amount") or 0)
            except (ValueError, TypeError):
                amount = 0.0
            try:
                gst = float(row.get("Tax amount") or 0)
            except (ValueError, TypeError):
                gst = 0.0
            rows.append({
                "txn_number":      (row.get("Transaction number") or "").strip(),
                "txn_type":        (row.get("Transaction type") or "").strip(),
                "date":            date_str,
                "ext_account_id":  (row.get("Account ID") or "").strip(),
                "amount":          amount,
                "gst_amount":      gst,
                "ext_contact_id":  (row.get("Counterparty ID") or "").strip(),
                "counterparty_name": (row.get("Counterparty legal name") or "").strip(),
                "line_comment":    (row.get("Line comment") or "").strip(),
                "doc_number":      (row.get("Document number") or "").strip(),
                "tax_code":        (row.get("Tax code") or "").strip(),
            })
        result = import_transactions(db(), rows, account_map, balancing, contact_map)
        return ok(result)
    except Exception as exc:
        return err(str(exc))


# ── AR/AP Reconciliation Wizard ────────────────────────────────────────────────

@bp.route("/api/arap-balances")
@login_required
def api_arap_balances():
    conn = get_connection(db())
    ar_gl = conn.execute("""
        SELECT COALESCE(SUM(jl.debit-jl.credit),0) as b
        FROM journal_lines jl JOIN accounts a ON a.id=jl.account_id
        WHERE a.code='1-1200'""").fetchone()["b"]
    ar_ob = conn.execute("""
        SELECT COALESCE(SUM(total-amount_paid),0) as b
        FROM invoices WHERE invoice_number LIKE 'OB-AR-%'
        AND status NOT IN ('Paid','Void')""").fetchone()["b"]
    ap_gl = conn.execute("""
        SELECT COALESCE(SUM(jl.credit-jl.debit),0) as b
        FROM journal_lines jl JOIN accounts a ON a.id=jl.account_id
        WHERE a.code='2-1100'""").fetchone()["b"]
    ap_ob = conn.execute("""
        SELECT COALESCE(SUM(total-amount_paid),0) as b
        FROM bills WHERE bill_number LIKE 'OB-AP-%'
        AND status NOT IN ('Paid','Void')""").fetchone()["b"]
    ob = conn.execute(
        "SELECT entry_date FROM journal_entries "
        "WHERE reference LIKE 'OB-%' ORDER BY id LIMIT 1").fetchone()
    conn.close()
    return ok({
        "ar": {"gl":         round(ar_gl - ar_ob, 2),
               "reconciled": round(ar_ob, 2),
               "remaining":  max(0.0, round(ar_gl - 2*ar_ob, 2))},
        "ap": {"gl":         round(ap_gl - ap_ob, 2),
               "reconciled": round(ap_ob, 2),
               "remaining":  max(0.0, round(ap_gl - 2*ap_ob, 2))},
        "ob_date": ob["entry_date"] if ob else "",
    })


@bp.route("/api/arap-reconcile", methods=["POST"])
@login_required
def api_arap_reconcile():
    data     = request.get_json() or {}
    date_str = (data.get("date") or "").strip()
    ar_rows  = data.get("ar_rows") or []
    ap_rows  = data.get("ap_rows") or []
    try:
        _dt.date.fromisoformat(date_str)
    except ValueError:
        return err("Invalid date — use YYYY-MM-DD")

    conn     = get_connection(db())
    inc_acc  = conn.execute(
        "SELECT id FROM accounts WHERE code='4-1200'").fetchone()
    exp_acc  = conn.execute(
        "SELECT id FROM accounts WHERE account_type='Expense' "
        "AND code NOT LIKE '5-9%' ORDER BY code LIMIT 1").fetchone()
    ar_exist = conn.execute(
        "SELECT COUNT(*) as n FROM invoices "
        "WHERE invoice_number LIKE 'OB-AR-%'").fetchone()["n"]
    ap_exist = conn.execute(
        "SELECT COUNT(*) as n FROM bills "
        "WHERE bill_number LIKE 'OB-AP-%'").fetchone()["n"]
    conn.close()

    if not inc_acc or not exp_acc:
        return err("Required GL accounts (Sales, Expense) not found")

    def _contact(name, ctype):
        c = get_connection(db())
        row = c.execute("SELECT id FROM contacts WHERE name=? LIMIT 1",
                        (name,)).fetchone()
        if row: c.close(); return row["id"]
        c.execute("INSERT INTO contacts (name,contact_type,is_active) VALUES (?,?,1)",
                  (name, ctype))
        c.commit()
        cid = c.execute("SELECT id FROM contacts WHERE name=? "
                        "ORDER BY id DESC LIMIT 1", (name,)).fetchone()["id"]
        c.close(); return cid

    errors = []; ar_total = ap_total = 0.0
    for i, row in enumerate(ar_rows, ar_exist + 1):
        try:
            amt  = float(row.get("amount") or 0)
            name = (row.get("name") or "Opening Balance Entries").strip() \
                   or "Opening Balance Entries"
            if amt < 0.001: continue
            cid = _contact(name, "Customer")
            save_invoice(db(),
                {"id": None, "contact_id": cid,
                 "invoice_number": f"OB-AR-{i:03d}",
                 "invoice_date": date_str, "due_date": date_str, "status": "Approved"},
                [{"description": f"Opening accounts receivable — {name}",
                  "quantity": 1, "unit_price": amt, "tax_code": "N-T",
                  "account_id": inc_acc["id"]}],
                skip_gl=True)
            ar_total += amt
        except Exception as exc:
            errors.append(f"AR {row.get('name', '?')}: {exc}")

    for i, row in enumerate(ap_rows, ap_exist + 1):
        try:
            amt  = float(row.get("amount") or 0)
            name = (row.get("name") or "Opening Balance Entries").strip() \
                   or "Opening Balance Entries"
            if amt < 0.001: continue
            cid = _contact(name, "Supplier")
            save_bill(db(),
                {"id": None, "contact_id": cid,
                 "bill_number": f"OB-AP-{i:03d}",
                 "bill_date": date_str, "due_date": date_str, "status": "Approved"},
                [{"description": f"Opening accounts payable — {name}",
                  "quantity": 1, "unit_price": amt, "tax_code": "N-T",
                  "account_id": exp_acc["id"]}],
                skip_gl=True)
            ap_total += amt
        except Exception as exc:
            errors.append(f"AP {row.get('name', '?')}: {exc}")

    return ok({"ar_total": ar_total, "ap_total": ap_total, "errors": errors})


# ── Migration Import Wizard ───────────────────────────────────────────────────

@bp.route("/api/migration/parse", methods=["POST"])
@login_required
def api_migration_parse():
    if "file" not in request.files:
        return err("No file uploaded")
    f = request.files["file"]
    if not f.filename:
        return err("No file selected")
    import tempfile, os as _os
    ext = _os.path.splitext(f.filename)[1].lower() or ".csv"
    tmp = tempfile.NamedTemporaryFile(suffix=ext, delete=False)
    try:
        f.save(tmp.name); tmp.close()
        from core.importer import detect_and_parse, map_to_dbox_account
        from core.ledger import get_accounts
        fmt, data = detect_and_parse(tmp.name)
        dbox_accts = get_accounts(db())
        id_by_code = {a["code"]: a["id"] for a in dbox_accts if a.get("code")}
        accounts_out = []
        for acc in data.get("accounts", []):
            sug = map_to_dbox_account(acc.get("name", ""), acc.get("type", ""))
            match_id = id_by_code.get(sug.get("code")) if sug.get("code") else None
            accounts_out.append({
                "key":  acc.get("code") or acc.get("name", ""),
                "code": acc.get("code", ""),
                "name": acc.get("name", ""),
                "type": acc.get("type", ""),
                "suggestion": {
                    "id":         match_id,
                    "code":       sug["code"],
                    "name":       sug["name"],
                    "confidence": sug["confidence"],
                } if sug.get("confidence") != "none" else None,
            })
        return ok({
            "format":   fmt,
            "counts": {
                "accounts":  len(data.get("accounts", [])),
                "contacts":  len(data.get("contacts", [])),
                "invoices":  len(data.get("invoices", [])),
                "bills":     len(data.get("bills",    [])),
                "journals":  len(data.get("journals", [])),
            },
            "accounts": accounts_out,
            "warnings": data.get("warnings", []),
        })
    except Exception as exc:
        return err(str(exc))
    finally:
        try: _os.unlink(tmp.name)
        except Exception: pass


@bp.route("/api/migration/import", methods=["POST"])
@login_required
def api_migration_import():
    import tempfile, os as _os, json as _json
    if "file" not in request.files:
        return err("No file uploaded")
    f = request.files["file"]
    try:
        config = _json.loads(request.form.get("config", "{}"))
    except Exception:
        return err("Invalid config JSON")
    account_map_raw = config.get("account_map", {})
    ext = _os.path.splitext(f.filename)[1].lower() or ".csv"
    tmp = tempfile.NamedTemporaryFile(suffix=ext, delete=False)
    try:
        f.save(tmp.name); tmp.close()
        from core.importer import detect_and_parse, import_to_dbox
        from core.ledger import get_accounts
        _, data = detect_and_parse(tmp.name)
        if account_map_raw:
            dbox_accts = get_accounts(db())
            id_to_name = {a["id"]: a["name"] for a in dbox_accts}
            name_remap = {}
            skip_keys  = set()
            for ext_key, dbox_id in account_map_raw.items():
                if dbox_id:
                    dbox_name = id_to_name.get(int(dbox_id))
                    if dbox_name:
                        name_remap[ext_key.lower()] = dbox_name
                        skip_keys.add(ext_key.lower())
            if skip_keys:
                data["accounts"] = [
                    a for a in data.get("accounts", [])
                    if (a.get("code") or a.get("name", "")).lower() not in skip_keys
                ]
            for jnl in data.get("journals", []):
                for ln in jnl.get("lines", []):
                    aname = (ln.get("account_name") or "").lower()
                    if aname in name_remap:
                        ln["account_name"] = name_remap[aname]
        result = import_to_dbox(
            db(), data,
            import_accounts=bool(config.get("import_accounts", True)),
            import_contacts=bool(config.get("import_contacts", True)),
            import_invoices=bool(config.get("import_invoices", True)),
            import_bills   =bool(config.get("import_bills",    True)),
            import_journals=bool(config.get("import_journals", True)),
        )
        return ok(result)
    except Exception as exc:
        return err(str(exc))
    finally:
        try: _os.unlink(tmp.name)
        except Exception: pass
