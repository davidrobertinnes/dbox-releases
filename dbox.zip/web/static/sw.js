// Static files are fetched network-first, so updates reach tablets without bumping
// this. Bumping CACHE_NAME still clears old caches (v2 and earlier were cache-first
// and could keep serving an old tablet.js after an update).
const CACHE_NAME = 'dbox-tablet-v3';

// Only cache truly static assets — never auth-gated HTML pages
const SHELL = [
  '/static/tablet.css',
  '/static/dbox.css',
  '/static/js/tablet.js',
  '/manifest.json',
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(SHELL))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // Never intercept API calls — always hit the network
  if (url.pathname.startsWith('/api/')) return;

  // For navigation requests (HTML pages), network first, fall back to cache
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request).catch(() => caches.match('/static/tablet.css')
        .then(() => caches.match(event.request))
      )
    );
    return;
  }

  // Static files: network first (the tablet needs the server anyway, and this way an
  // update to Dogbox reaches the tablet), the cached copy only if the network fails
  event.respondWith(
    fetch(event.request).then(response => {
      if (response.ok) {
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
      }
      return response;
    }).catch(() => caches.match(event.request))
  );
});
