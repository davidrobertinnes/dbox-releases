// ═══════════════════════════════════════════════════════════════════════════
// RECURRING PAGE
// ═══════════════════════════════════════════════════════════════════════════
let _recAll=[], _recFilter='All', _recSearch='', _recSort={col:'next_due',dir:1}, _recSelected=null;
let _recEditId=null;
let _recLines=[], _recAccts=[];
const REC_TYPES=['All','Journal','Invoice','Bill'];
// badge-muted → badge-draft (badge-muted is not defined in dbox.css)
const REC_TYPE_BADGE={'Journal':'badge-draft','Invoice':'badge-pending','Bill':'badge-partial'};
const REC_FREQS=['Weekly','Fortnightly','Monthly','Quarterly','Annual'];

async function pageRecurring() {
  try {
    _recAll = await apiFetch('/api/recurring') || [];
    renderRecurringPage();
  } catch(e) {
    document.getElementById('module-content').innerHTML=`<div class="state-error">Failed to load recurring templates: ${esc(e.message)}</div>`;
  }
}

function _recFiltered() {
  const q=_recSearch.toLowerCase();
  return _recAll.filter(t=>{
    if(_recFilter!=='All'&&t.template_type!==_recFilter) return false;
    if(q&&![t.name,t.description,t.contact_name,t.frequency].some(v=>(v||'').toLowerCase().includes(q))) return false;
    return true;
  }).sort((a,b)=>{
    const col=_recSort.col, av=a[col]??'', bv=b[col]??'';
    return String(av).localeCompare(String(bv))*_recSort.dir;
  });
}

function renderRecurringPage(restoreFocus) {
  const rows=_recFiltered();
  const today=isoToday();
  const overdue=_recAll.filter(t=>t.is_active&&t.next_due<=today).length;
  const counts={All:_recAll.length};
  REC_TYPES.slice(1).forEach(t=>{ counts[t]=_recAll.filter(r=>r.template_type===t).length; });

  const mc=document.getElementById('module-content');
  mc.innerHTML=`
    ${overdue?`<div class="rec-overdue-banner">
      <span class="rec-overdue-msg">⚠ ${overdue} template${overdue!==1?'s':''} due or overdue</span>
      <button class="btn btn-primary" onclick="recRunDue()">Run All Due</button>
    </div>`:''}
    <div class="inv-toolbar">
      <input class="inv-search" id="rec-q" placeholder="Search name, contact, frequency\u2026" value="${esc(_recSearch)}">
      <div class="inv-filter-group">
        ${REC_TYPES.map(t=>`<button class="filter-btn${_recFilter===t?' active':''}" onclick="recSetFilter('${t}')">
          ${t}${counts[t]?` <span class="filter-count">(${counts[t]})</span>`:''}</button>`).join('')}
      </div>
      <button class="btn btn-primary" onclick="recNew()">+ New Template</button>
    </div>
    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        ${recTh('name','Name')}
        ${recTh('template_type','Type')}
        ${recTh('frequency','Frequency')}
        ${recTh('contact_name','Contact')}
        ${recTh('next_due','Next Due')}
        ${recTh('run_count','Runs','r')}
        <th class="th-c">Active</th>
      </tr></thead><tbody>
        ${rows.length ? rows.map(recRow).join('') : `<tr class="tbl-empty-row"><td colspan="7">No templates found</td></tr>`}
      </tbody></table>
    </div></div>
    <div class="mt-8"><span class="count-pill">${rows.length} of ${_recAll.length} template${_recAll.length!==1?'s':''}</span></div>`;

  const q=document.getElementById('rec-q');
  if(q){
    q.addEventListener('input',e=>{_recSearch=e.target.value;renderRecurringPage(true);});
    if(restoreFocus){q.focus();q.setSelectionRange(q.value.length,q.value.length);}
  }
}

// recTh — single class= attribute merging sort class and th-r to avoid double class= bug
function recTh(col,label,align) {
  const sortCls=_recSort.col===col?(_recSort.dir>0?'sort-asc':'sort-desc'):'';
  const alignCls=align==='r'?'th-r':'';
  const cls=[sortCls,alignCls].filter(Boolean).join(' ');
  return `<th${cls?` class="${cls}"`:''} onclick="recSortBy('${col}')">${label}</th>`;
}

function recRow(t) {
  const today=isoToday();
  const isOverdue=t.is_active&&t.next_due<=today;
  const sel=_recSelected===t.id;
  return `<tr class="inv-row${sel?' rec-row-selected':''}${isOverdue?' is-overdue':''}" onclick="recOpen(${t.id})">
    <td><span class="inv-contact">${esc(t.name)}</span></td>
    <td><span class="badge ${REC_TYPE_BADGE[t.template_type]||'badge-draft'}">${esc(t.template_type)}</span></td>
    <td><span class="rec-freq-cell">${esc(t.frequency)}</span></td>
    <td><span class="rec-contact-cell">${esc(t.contact_name||'—')}</span></td>
    <td><span class="inv-mono${isOverdue?' rec-due-overdue':''}">${fmtDate(t.next_due)}${isOverdue?' ⚠':''}</span></td>
    <td class="td-r-mono">${t.run_count||0}</td>
    <td class="td-c-mono">${t.is_active?'<span class="col-green">✓</span>':'<span class="col-ink3">—</span>'}</td>
  </tr>`;
}

function recSortBy(col){_recSort={col,dir:_recSort.col===col?_recSort.dir*-1:1};renderRecurringPage();}
function recSetFilter(f){_recFilter=f;renderRecurringPage();}

async function recOpen(id) {
  _recSelected=id;
  renderRecurringPage();
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent='Template';
  document.getElementById('det-body').innerHTML='<div class="state-loading">Loading\u2026</div>';
  document.getElementById('det-foot').innerHTML='';
  try {
    const t=await apiFetch(`/api/recurring/${id}`);
    const runs=await apiFetch(`/api/recurring/${id}/runs`);
    renderRecDetail(t, runs||[]);
  } catch(e) {
    document.getElementById('det-body').innerHTML=`<div class="state-error">${esc(e.message)}</div>`;
  }
}

function renderRecDetail(t, runs) {
  document.getElementById('det-title').textContent=t.name;
  const today=isoToday();
  const isOverdue=t.is_active&&t.next_due<=today;
  const isJournal=t.template_type==='Journal';

  // Parse lines_json (may be already parsed from API or still a string)
  let lines=t.lines_json;
  if(typeof lines==='string'){try{lines=JSON.parse(lines);}catch{lines=null;}}
  const hasLines=Array.isArray(lines)&&lines.length>0;

  // Build lines display section
  let linesHtml='';
  if(hasLines) {
    if(isJournal) {
      const dr=lines.reduce((s,l)=>s+(parseFloat(l.debit)||0),0);
      const cr=lines.reduce((s,l)=>s+(parseFloat(l.credit)||0),0);
      linesHtml=`<div class="rec-lines-detail">
        <div class="det-section-title">Journal Lines</div>
        <table class="rec-lines-tbl"><thead><tr>
          <th>Account</th><th class="th-r">Debit</th><th class="th-r">Credit</th><th>Memo</th>
        </tr></thead><tbody>
          ${lines.map(l=>`<tr>
            <td>${esc(l.account_name||(l.account_id?'#'+l.account_id:'—'))}</td>
            <td class="td-r-mono">${parseFloat(l.debit)?fmt(parseFloat(l.debit)):'—'}</td>
            <td class="td-r-mono">${parseFloat(l.credit)?fmt(parseFloat(l.credit)):'—'}</td>
            <td class="col-ink2">${esc(l.description||'')}</td>
          </tr>`).join('')}
        </tbody><tfoot><tr>
          <td style="text-align:right;font-weight:600;color:var(--ink2)">Totals</td>
          <td class="td-r-mono rec-line-total">${fmt(dr)}</td>
          <td class="td-r-mono rec-line-total">${fmt(cr)}</td>
          <td></td>
        </tr></tfoot></table>
      </div>`;
    } else {
      const total=lines.reduce((s,l)=>s+(parseFloat(l.quantity||1)*parseFloat(l.unit_price||0)),0);
      linesHtml=`<div class="rec-lines-detail">
        <div class="det-section-title">Line Items</div>
        <table class="rec-lines-tbl"><thead><tr>
          <th>Description</th><th class="th-r">Qty</th><th class="th-r">Unit Price</th>
          <th>Tax</th><th>Account</th><th class="th-r">Amount</th>
        </tr></thead><tbody>
          ${lines.map(l=>`<tr>
            <td>${esc(l.description||'')}</td>
            <td class="td-r-mono">${l.quantity!=null?l.quantity:1}</td>
            <td class="td-r-mono">${fmt(parseFloat(l.unit_price)||0)}</td>
            <td class="td-c-mono">${esc(l.tax_code||'')}</td>
            <td class="col-ink2">${esc(l.account_name||'')}</td>
            <td class="td-r-mono">${fmt(parseFloat(l.quantity||1)*parseFloat(l.unit_price||0))}</td>
          </tr>`).join('')}
        </tbody><tfoot><tr>
          <td colspan="5" style="text-align:right;font-weight:600;color:var(--ink2)">Total</td>
          <td class="td-r-mono rec-line-total">${fmt(total)}</td>
        </tr></tfoot></table>
      </div>`;
    }
  }

  // Amount shown in summary (from lines if present, else raw field)
  const displayAmt=hasLines
    ? (isJournal
        ? lines.reduce((s,l)=>s+(parseFloat(l.debit)||0),0)
        : lines.reduce((s,l)=>s+(parseFloat(l.quantity||1)*parseFloat(l.unit_price||0)),0))
    : t.amount;

  const runsHtml=runs.length?`
    <div class="rec-runs-section">
      <div class="det-section-title">Recent Runs</div>
      <table class="rec-runs-tbl">
        <thead><tr>
          <th>Date</th>
          <th>Type</th>
          <th class="th-r">Status</th>
        </tr></thead><tbody>
        ${runs.slice(0,8).map(r=>`<tr>
          <td class="td-ref">${fmtDate(r.run_date)}</td>
          <td class="col-ink2">${esc(r.generated_type||'—')}</td>
          <td class="td-r-mono">
            <span class="badge ${r.status==='OK'?'badge-paid':'badge-overdue'}">${esc(r.status)}</span>
          </td>
        </tr>`).join('')}
        </tbody>
      </table>
    </div>` : `<div class="rec-no-runs">No runs yet.</div>`;

  document.getElementById('det-body').innerHTML=`
    <div class="det-badge-row">
      <span class="badge ${REC_TYPE_BADGE[t.template_type]||'badge-draft'}">${esc(t.template_type)}</span>
      <span class="badge badge-draft">${esc(t.frequency)}</span>
      ${t.is_active?'<span class="badge badge-paid">Active</span>':'<span class="badge badge-draft">Paused</span>'}
    </div>
    <div class="det-meta">
      <div>
        <div class="det-lbl">Next Due</div>
        <div class="det-val mono${isOverdue?' rec-due-overdue':''}">${fmtDate(t.next_due)}${isOverdue?' ⚠ Overdue':''}</div>
      </div>
      <div>
        <div class="det-lbl">End Date</div>
        <div class="det-val mono">${t.end_date?fmtDate(t.end_date):'No end'}</div>
      </div>
      <div>
        <div class="det-lbl">Contact</div>
        <div class="det-val">${esc(t.contact_name||'—')}</div>
      </div>
      <div>
        <div class="det-lbl">${hasLines?(isJournal?'Total Dr/Cr':'Total (excl. GST)'):'Amount'}</div>
        <div class="det-val mono">${displayAmt!=null?fmt(displayAmt):'—'}</div>
      </div>
      ${t.description?`<div class="rec-det-span2">
        <div class="det-lbl">Description</div>
        <div class="det-val">${esc(t.description)}</div>
      </div>`:''}
      <div>
        <div class="det-lbl">Runs</div>
        <div class="det-val mono">${t.run_count||0}</div>
      </div>
      <div>
        <div class="det-lbl">Last Generated</div>
        <div class="det-val mono">${t.last_generated?fmtDate(t.last_generated):'Never'}</div>
      </div>
    </div>
    ${linesHtml}
    ${runsHtml}`;

  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" onclick="recEdit(${t.id})">✏ Edit</button>
    <button class="btn btn-outline" onclick="recRunOne(${t.id})">${isOverdue?'▶ Run Now':'▶ Run'}</button>
    <button class="btn btn-outline" onclick="recToggleActive(${t.id},${t.is_active})">${t.is_active?'⏸ Pause':'▶ Resume'}</button>
    <button class="btn btn-danger" onclick="recDelete(${t.id})">Delete</button>`;
}

// ── New / Edit form ──────────────────────────────────────────────────────────

// ── Line-item helpers ────────────────────────────────────────────────────────

function _recDefaultLine(type) {
  if(type==='Journal') return {account_id:null, debit:0, credit:0, description:''};
  return {description:'', quantity:1, unit_price:0, tax_code:'GST', account_id:null};
}

function _recAcctOptsFor(selectedId) {
  return _recAccts.map(a=>
    `<option value="${a.id}"${a.id===selectedId?' selected':''}>${esc((a.code?a.code+' ':'')+a.name)}</option>`
  ).join('');
}

function recAddLine() {
  const type=document.getElementById('rf-type')?.value||'Invoice';
  _recLines.push(_recDefaultLine(type));
  _recRenderLineRows(type);
}

function recRemoveLine(i) {
  _recLines.splice(i,1);
  const type=document.getElementById('rf-type')?.value||'Invoice';
  _recRenderLineRows(type);
}

function recUpdateTotals() {
  const dr=_recLines.reduce((s,ln)=>s+(parseFloat(ln.debit)||0),0);
  const cr=_recLines.reduce((s,ln)=>s+(parseFloat(ln.credit)||0),0);
  const dtEl=document.getElementById('rf-debit-total');
  const ctEl=document.getElementById('rf-credit-total');
  if(dtEl) dtEl.textContent=fmt(dr);
  if(ctEl) ctEl.textContent=fmt(cr);
  const wEl=document.getElementById('rf-balance-warn');
  if(wEl) wEl.textContent=Math.abs(dr-cr)>0.005?`Out of balance by ${fmt(Math.abs(dr-cr))}`:'';
}

function _recRenderLinesSection(type) {
  const section=document.getElementById('rf-lines-section');
  if(!section) return;
  if(type==='Journal') {
    section.innerHTML=`
      <div class="lbl-line" style="margin-top:12px;margin-bottom:4px">
        <label class="edt-lbl">Journal Lines</label>
        <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();recAddLine()">+ Add Line</a>
      </div>
      <div class="tbl-overflow-x">
        <table class="rec-lines-tbl"><thead><tr>
          <th style="min-width:160px">Account</th>
          <th class="th-r" style="width:110px">Debit ($)</th>
          <th class="th-r" style="width:110px">Credit ($)</th>
          <th>Memo</th><th style="width:28px"></th>
        </tr></thead>
        <tbody id="rf-lines-body"></tbody>
        <tfoot><tr>
          <td style="text-align:right;font-weight:600;padding:4px 8px;color:var(--ink2)">Totals</td>
          <td id="rf-debit-total" class="td-r-mono rec-line-total">0.00</td>
          <td id="rf-credit-total" class="td-r-mono rec-line-total">0.00</td>
          <td colspan="2"><span id="rf-balance-warn" class="rec-balance-warn"></span></td>
        </tr></tfoot></table>
      </div>`;
  } else {
    section.innerHTML=`
      <div class="lbl-line" style="margin-top:12px;margin-bottom:4px">
        <label class="edt-lbl">Line Items</label>
        <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();recAddLine()">+ Add Line</a>
      </div>
      <div class="tbl-overflow-x">
        <table class="rec-lines-tbl"><thead><tr>
          <th>Description</th>
          <th class="th-r" style="width:60px">Qty</th>
          <th class="th-r" style="width:110px">Unit Price ($)</th>
          <th style="width:60px">Tax</th>
          <th style="min-width:150px">Account</th>
          <th style="width:28px"></th>
        </tr></thead>
        <tbody id="rf-lines-body"></tbody></table>
      </div>`;
  }
  _recRenderLineRows(type);
}

function _recRenderLineRows(type) {
  const tbody=document.getElementById('rf-lines-body');
  if(!tbody) return;
  if(type==='Journal') {
    tbody.innerHTML=_recLines.map((ln,i)=>`<tr>
      <td><select class="edt-sel" style="width:100%" onchange="_recLines[${i}].account_id=this.value?parseInt(this.value):null">
        <option value="">— Select —</option>${_recAcctOptsFor(ln.account_id)}
      </select></td>
      <td><input class="edt-inp" style="text-align:right" type="number" step="0.01" min="0"
        value="${ln.debit||''}" placeholder="0.00"
        oninput="_recLines[${i}].debit=parseFloat(this.value)||0;recUpdateTotals()"></td>
      <td><input class="edt-inp" style="text-align:right" type="number" step="0.01" min="0"
        value="${ln.credit||''}" placeholder="0.00"
        oninput="_recLines[${i}].credit=parseFloat(this.value)||0;recUpdateTotals()"></td>
      <td><input class="edt-inp" value="${esc(ln.description||'')}"
        oninput="_recLines[${i}].description=this.value"></td>
      <td>${_recLines.length>1?`<button class="rec-line-del" onclick="recRemoveLine(${i})" title="Remove">✕</button>`:''}</td>
    </tr>`).join('');
    recUpdateTotals();
  } else {
    tbody.innerHTML=_recLines.map((ln,i)=>`<tr>
      <td><input class="edt-inp" value="${esc(ln.description||'')}" placeholder="Item description"
        oninput="_recLines[${i}].description=this.value"></td>
      <td><input class="edt-inp" style="text-align:right" type="number" step="0.01" min="0"
        value="${ln.quantity!=null?ln.quantity:1}"
        oninput="_recLines[${i}].quantity=parseFloat(this.value)||1"></td>
      <td><input class="edt-inp" style="text-align:right" type="number" step="0.01"
        value="${ln.unit_price||''}" placeholder="0.00"
        oninput="_recLines[${i}].unit_price=parseFloat(this.value)||0"></td>
      <td><select class="edt-sel" onchange="_recLines[${i}].tax_code=this.value">
        ${['GST','FRE','INP','N-T','CAP'].map(tc=>`<option${(ln.tax_code||'GST')===tc?' selected':''}>${tc}</option>`).join('')}
      </select></td>
      <td><select class="edt-sel" style="width:100%" onchange="_recLines[${i}].account_id=this.value?parseInt(this.value):null">
        <option value="">— None —</option>${_recAcctOptsFor(ln.account_id)}
      </select></td>
      <td>${_recLines.length>1?`<button class="rec-line-del" onclick="recRemoveLine(${i})" title="Remove">✕</button>`:''}</td>
    </tr>`).join('');
  }
}

function recNew() {
  _recEditId=null;
  _showRecForm(null);
}

async function _recNewContact() {
  const c = await quickNewContact('Both');
  if (!c) return;
  const sel = document.getElementById('rf-contact');
  if (sel) sel.appendChild(new Option(c.name, c.id, true, true));
}

async function recEdit(id) {
  _recEditId=id;
  try {
    const t=await apiFetch(`/api/recurring/${id}`);
    _showRecForm(t);
  } catch(e){ toast(e.message, 'error'); }
}

async function _showRecForm(t) {
  const isNew=!t;
  const [contacts,accounts]=await Promise.all([
    apiFetch('/api/contacts'),
    apiFetch('/api/accounts'),
  ]);
  const allContacts=contacts||[];
  _recAccts=accounts||[];

  const v=(f,fb='')=>esc(t?String(t[f]??fb):fb);
  const selOpts=(f,opts,fb='')=>opts.map(o=>`<option${(t?t[f]:fb)===o?' selected':''}>${o}</option>`).join('');
  const conOpts=allContacts.map(c=>`<option value="${c.id}"${t?.contact_id===c.id?' selected':''}>${esc(c.name)}</option>`).join('');

  // Initialise _recLines from template data (lines_json, single-line fallback, or default)
  const type=t?.template_type||'Invoice';
  let rawLines=t?.lines_json;
  if(typeof rawLines==='string'){try{rawLines=JSON.parse(rawLines);}catch{rawLines=null;}}
  if(Array.isArray(rawLines)&&rawLines.length) {
    _recLines=rawLines.map(ln=>({...ln}));
  } else if(t) {
    // Existing single-line template — seed one line from legacy fields
    if(type==='Journal') {
      _recLines=[{account_id:t.account_id||null, debit:t.amount||0, credit:0, description:t.description||''}];
    } else {
      _recLines=[{description:t.description||'', quantity:1, unit_price:t.amount||0, tax_code:t.tax_code||'GST', account_id:t.account_id||null}];
    }
  } else {
    _recLines=[_recDefaultLine(type)];
  }

  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent=isNew?'New Template':`Edit — ${t.name}`;
  document.getElementById('det-body').innerHTML=`<div class="edt-body-pad">
    <div class="edt-grid">
      <div class="edt-field edt-span"><label class="edt-lbl">Template Name *</label>
        <input class="edt-inp" id="rf-name" value="${v('name')}"></div>
      <div class="edt-field"><label class="edt-lbl">Type *</label>
        <select class="edt-sel" id="rf-type" onchange="recTypeChange()">
          ${selOpts('template_type',['Journal','Invoice','Bill'],'Invoice')}
        </select></div>
      <div class="edt-field"><label class="edt-lbl">Frequency *</label>
        <select class="edt-sel" id="rf-freq">
          ${selOpts('frequency',REC_FREQS,'Monthly')}
        </select></div>
      <div class="edt-field"><label class="edt-lbl">Next Due Date *</label>
        <input class="edt-inp" id="rf-due" type="date" value="${t?.next_due||isoToday()}"></div>
      <div class="edt-field"><label class="edt-lbl">End Date (optional)</label>
        <input class="edt-inp" id="rf-end" type="date" value="${t?.end_date||''}"></div>
      <div class="edt-field"><label class="edt-lbl">Active</label>
        <select class="edt-sel" id="rf-active">
          <option value="1"${(t?.is_active!==0)?' selected':''}>Yes</option>
          <option value="0"${t?.is_active===0?' selected':''}>No (Paused)</option>
        </select></div>
    </div>

    <div id="rf-contact-row" class="rec-form-section">
      <div class="edt-grid">
        <div class="edt-field edt-span">
          <div class="lbl-line">
            <label class="edt-lbl" id="rf-contact-lbl">Contact</label>
            <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();_recNewContact()">+ New</a>
          </div>
          <select class="edt-sel" id="rf-contact">
            <option value="">— None —</option>${conOpts}
          </select></div>
      </div>
    </div>

    <div class="rec-form-section">
      <div class="edt-grid">
        <div class="edt-field edt-span"><label class="edt-lbl">Description / Notes</label>
          <input class="edt-inp" id="rf-desc" value="${v('description')}"></div>
        <div class="edt-field"><label class="edt-lbl">Reference</label>
          <input class="edt-inp" id="rf-ref" value="${v('reference')}"></div>
      </div>
    </div>

    <div id="rf-lines-section"></div>
  </div>`;

  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="rec-save-btn" onclick="saveRec()">Save</button>
    <button class="btn btn-outline" onclick="${_recEditId?`recOpen(${_recEditId})`:'detClose()'}">Cancel</button>`;

  recTypeChange();
  setTimeout(()=>document.getElementById('rf-name')?.focus(),50);
}

function recTypeChange() {
  const type=document.getElementById('rf-type')?.value||'Invoice';
  const contactLbl=document.getElementById('rf-contact-lbl');
  if(contactLbl) {
    contactLbl.textContent=type==='Invoice'?'Customer *':type==='Bill'?'Supplier *':'Contact (optional)';
  }
  // Reset lines only when switching between Journal and Invoice/Bill families
  if(document.getElementById('rf-lines-body')) {
    const wasJournal=_recLines.length>0&&'debit' in _recLines[0];
    if(wasJournal!==(type==='Journal')) _recLines=[_recDefaultLine(type)];
  }
  _recRenderLinesSection(type);
}

async function saveRec() {
  const name=(document.getElementById('rf-name')?.value||'').trim();
  const type=document.getElementById('rf-type')?.value;
  const due=document.getElementById('rf-due')?.value;
  if(!name||!type||!due){toast('Name, type and next due date are required','err');return;}

  // Validate lines
  if(type==='Journal') {
    if(_recLines.length<2){toast('Journal needs at least 2 lines','err');return;}
    if(_recLines.some(l=>!l.account_id)){toast('All journal lines need an account','err');return;}
    const dr=_recLines.reduce((s,l)=>s+(parseFloat(l.debit)||0),0);
    const cr=_recLines.reduce((s,l)=>s+(parseFloat(l.credit)||0),0);
    if(Math.abs(dr-cr)>0.005){toast(`Journal is out of balance \u2014 Dr ${fmt(dr)} \u2260 Cr ${fmt(cr)}`,'err');return;}
  } else {
    if(!_recLines.some(l=>parseFloat(l.unit_price)>0)){toast('Add at least one line item with a price','err');return;}
  }

  // Calculate total for record
  const totalAmount=type==='Journal'
    ? _recLines.reduce((s,l)=>s+(parseFloat(l.debit)||0),0)
    : _recLines.reduce((s,l)=>s+(parseFloat(l.quantity||1)*parseFloat(l.unit_price||0)),0);

  const btn=document.getElementById('rec-save-btn');
  btn.disabled=true; btn.textContent='Saving\u2026';

  const contactId=parseInt(document.getElementById('rf-contact')?.value||0)||null;
  const payload={
    name, template_type:type,
    frequency: document.getElementById('rf-freq').value,
    next_due: due,
    end_date: document.getElementById('rf-end')?.value||null,
    is_active: parseInt(document.getElementById('rf-active').value),
    contact_id: contactId,
    description: document.getElementById('rf-desc')?.value.trim()||'',
    reference: document.getElementById('rf-ref')?.value.trim()||'',
    amount: totalAmount||null,
    tax_code: _recLines[0]?.tax_code||'GST',
    account_id: _recLines[0]?.account_id||null,
    lines_json: _recLines,
  };

  try {
    let savedId=_recEditId;
    if(_recEditId) {
      const r=await fetch(`/api/recurring/${_recEditId}`,{method:'PUT',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
    } else {
      const r=await fetch('/api/recurring',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
      savedId=j.data?.id;
    }
    toast(_recEditId?'Template updated':'Template created');
    _recAll=await apiFetch('/api/recurring')||[];
    if(savedId){ _recSelected=savedId; await recOpen(savedId); }
    else { detClose(); renderRecurringPage(); }
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent='Save';
  }
}

async function recRunDue() {
  if(!await confirmDlg('Run all due and overdue templates now? This will create draft invoices, bills, or journal entries.')) return;
  try {
    const r=await fetch('/api/recurring/process',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({})});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Process failed');
    const results=j.data||[];
    const ok=results.filter(x=>x.status==='OK').length;
    const errs=results.filter(x=>x.status==='Error').length;
    toast(ok?`Processed ${ok} template${ok!==1?'s':''}${errs?`, ${errs} error(s)`:''}`:errs?`${errs} error(s) — check templates`:'Nothing due', errs>0);
    _recAll=await apiFetch('/api/recurring')||[];
    renderRecurringPage();
    if(_recSelected) await recOpen(_recSelected);
  } catch(e){ toast(e.message, 'error'); }
}

async function recRunOne(id) {
  try {
    const r=await fetch('/api/recurring/process',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify({as_of:isoToday()})});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Process failed');
    // Find result for this template
    const result=(j.data||[]).find(x=>x.template===_recAll.find(t=>t.id===id)?.name);
    if(result?.status==='Error') throw new Error(result.error);
    toast(result?`Ran: created ${result.type} #${result.id}`:'Processed');
    _recAll=await apiFetch('/api/recurring')||[];
    await recOpen(id);
  } catch(e){ toast(e.message, 'error'); }
}

async function recToggleActive(id, currentlyActive) {
  try {
    const t=await apiFetch(`/api/recurring/${id}`);
    t.is_active=currentlyActive?0:1;
    const r=await fetch(`/api/recurring/${id}`,{method:'PUT',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(t)});
    const j=await r.json(); if(!j.ok) throw new Error(j.error);
    toast(currentlyActive?'Template paused':'Template resumed');
    _recAll=await apiFetch('/api/recurring')||[];
    renderRecurringPage();
    await recOpen(id);
  } catch(e){ toast(e.message, 'error'); }
}

async function recDelete(id) {
  if(!await confirmDlg('Delete this template? This cannot be undone. Past runs are not affected.')) return;
  try {
    const r=await fetch(`/api/recurring/${id}`,{method:'DELETE',credentials:'include'});
    const j=await r.json(); if(!j.ok) throw new Error(j.error);
    toast('Template deleted');
    detClose();
    _recAll=await apiFetch('/api/recurring')||[];
    renderRecurringPage();
  } catch(e){ toast(e.message, 'error'); }
}
