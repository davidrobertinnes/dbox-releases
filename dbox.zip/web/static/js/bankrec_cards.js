// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// web/static/js/bankrec_cards.js — Bank Rec, Xero-style
//
// One card per bank statement line still to deal with: the statement line on
// the left, and on the right either a Match (to something already in dbox)
// or Create (record it now). OK does it. Reuses bankrec.js for CSV import,
// rules, reports and the split dialog (shared _brAccId/_brAccounts).

// ── State ─────────────────────────────────────────────────────────────────────
let _brcAccId    = null;
let _brcAccts    = [];      // reconcilable accounts (picker)
let _brcView     = null;    // /reconcile-view payload
let _brcTab      = 'reconcile';
let _brcAllAccs  = [];      // chart of accounts (create form)
let _brcContacts = [];
let _brcOpenInv  = [];
let _brcOpenBill = [];
let _brcLedger   = [];      // unmatched ledger lines (Find & match)
let _brcCards    = {};      // per statement line UI state
let _brcBusy     = new Set();
let _brcGstReg   = true;
let _brcTxnRows  = [];      // Account transactions tab

const _BRC_TAX = [['GST', 'GST 10%'], ['FRE', 'GST free'], ['INP', 'Input taxed'], ['N-T', 'No GST']];

// ── Entry point ───────────────────────────────────────────────────────────────
async function pageBankReconcile() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = `
    <div id="brc-root">
      <div class="inv-toolbar">
        <select id="brc-acc" class="inv-search br-acc-sel" onchange="_brcOnAcc()"></select>
        <button class="btn btn-purple" onclick="_brcImport()">⬆ Import statement</button>
        <button class="btn btn-outline" onclick="_brcRules()">📋 Rules</button>
        <button class="btn btn-outline" onclick="_brcReport()">📄 Report</button>
        <button class="btn btn-outline" onclick="_brcPastRecs()">📑 Past recs</button>
        <span class="brc-spacer"></span>
        <button class="btn btn-outline btn-sm" onclick="pageBankRec()" title="The previous bank rec screen — use it to finalise a period">Classic view</button>
      </div>
      <div class="brc-head" id="brc-head"></div>
      <div class="brc-tabs" id="brc-tabs"></div>
      <div id="brc-body"><div class="state-loading">Loading…</div></div>
    </div>`;
  _brcCards = {};
  try {
    const [accts, me] = await Promise.all([
      apiFetch('/api/bankrec/accounts'),
      apiFetch('/api/me').catch(() => null),
    ]);
    _brcAccts = accts || [];
    _brcGstReg = me ? me.gst_registered !== 0 : true;
  } catch (e) {
    document.getElementById('brc-body').innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`;
    return;
  }
  const sel = document.getElementById('brc-acc');
  if (!_brcAccts.length) {
    document.getElementById('brc-body').innerHTML = `<div class="state-empty">
      <div class="state-empty-title">No bank accounts</div>
      <div class="state-empty-sub">Mark an account as a bank or credit card account in Accounts first.</div></div>`;
    return;
  }
  sel.innerHTML = _brcAccts.map(a => `<option value="${a.id}">${esc(a.code)}  ${esc(a.name)}</option>`).join('');
  const saved = parseInt(localStorage.getItem('brc_acc') || '');
  _brcAccId = _brcAccts.some(a => a.id === saved) ? saved : _brcAccts[0].id;
  sel.value = _brcAccId;
  _brcSyncClassic();
  await _brcLoadLookups();
  await _brcReload();
}

// Share the selected account with bankrec.js so its dialogs work here
function _brcSyncClassic() {
  _brAccounts = _brcAccts;
  _brAccId    = _brcAccId;
}

function _brcOnAcc() {
  _brcAccId = parseInt(document.getElementById('brc-acc').value);
  localStorage.setItem('brc_acc', _brcAccId);
  _brcSyncClassic();
  _brcCards = {};
  _brcReload();
}

async function _brcLoadLookups() {
  const [accs, contacts, invs, bills] = await Promise.all([
    apiFetch('/api/accounts'), apiFetch('/api/contacts'),
    apiFetch('/api/invoices'), apiFetch('/api/bills'),
  ]);
  _brcAllAccs  = (accs || []).filter(a => a.is_active !== 0);
  _brcContacts = (contacts || []).filter(c => c.is_active !== 0)
                   .sort((a, b) => (a.name || '').localeCompare(b.name || ''));
  _brcOpenInv  = (invs || [])
    .filter(i => ['Sent', 'Partial', 'Approved', 'Overdue'].includes(i.status))
    .map(i => ({ ...i, _owing: _brcRound(parseFloat(i.total || 0) - parseFloat(i.amount_paid || 0)) }))
    .filter(i => i._owing > 0.005);
  _brcOpenBill = (bills || [])
    .filter(b => ['Approved', 'Partial', 'Overdue'].includes(b.status))
    .map(b => ({ ...b, _owing: _brcRound(parseFloat(b.total || 0) - parseFloat(b.amount_paid || 0)) }))
    .filter(b => b._owing > 0.005);
}

// Called after any change (also by bankrec.js after import/rules via _brLoad)
async function _brcReload() {
  if (!_brcAccId) return;
  try {
    const [view, ledger] = await Promise.all([
      apiFetch(`/api/bankrec/${_brcAccId}/reconcile-view`),
      apiFetch(`/api/bankrec/${_brcAccId}/unmatched-ledger`),
    ]);
    _brcView = view;
    _brcLedger = ledger || [];
  } catch (e) {
    document.getElementById('brc-body').innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`;
    return;
  }
  // Drop state for lines that are gone; keep what the user has typed
  const ids = new Set(_brcView.lines.map(l => l.id));
  for (const k of Object.keys(_brcCards)) if (!ids.has(+k)) delete _brcCards[k];
  _brcRenderHead();
  _brcRenderTabs();
  if (_brcTab === 'reconcile') _brcRenderCards();
  else await _brcLoadTxns();
}

// ── Header + tabs ─────────────────────────────────────────────────────────────
function _brcRenderHead() {
  const v = _brcView;
  const liab = v.is_liability;
  const stmt = v.statement_balance;
  const stmtHtml = stmt == null
    ? `<div class="brc-bal-val brc-muted">—</div><div class="brc-bal-sub">No balance column in the imported statement</div>`
    : `<div class="brc-bal-val">${_brcMoney(stmt)}</div><div class="brc-bal-sub">Last statement line, ${_brcDate(v.statement_date)}</div>`;
  const autoN = v.lines.filter(l => l.auto).length;
  const ruleN = v.lines.filter(l => l.rule && l.rule.account_id && !l.suggestions.length).length;
  document.getElementById('brc-head').innerHTML = `
    <div class="brc-bal">
      <div class="brc-bal-lbl">Statement balance${liab ? ' (owed)' : ''}</div>${stmtHtml}
    </div>
    <div class="brc-bal">
      <div class="brc-bal-lbl">Balance in dbox${liab ? ' (owed)' : ''}</div>
      <div class="brc-bal-val">${_brcMoney(v.dbox_balance)}</div>
      <div class="brc-bal-sub">Everything recorded to this account</div>
    </div>
    <div class="brc-bal">
      <div class="brc-bal-lbl">To reconcile</div>
      <div class="brc-bal-val">${v.lines.length}</div>
      <div class="brc-bal-sub">statement line${v.lines.length === 1 ? '' : 's'}</div>
    </div>
    <div class="brc-bal">
      <div class="brc-bal-lbl">Reconciled to</div>
      <div class="brc-bal-val">${v.last_rec_date ? _brcDate(v.last_rec_date) : '—'}</div>
      <div class="brc-bal-sub">${v.last_rec_date ? 'Last finished statement' : 'Not reconciled yet'}</div>
    </div>
    <div class="brc-bulk">
      ${autoN ? `<button class="btn btn-success btn-sm" onclick="_brcAcceptAuto()" title="Only clear-cut matches">✓ Accept ${autoN} suggested match${autoN === 1 ? '' : 'es'}</button>` : ''}
      ${ruleN ? `<button class="btn btn-outline btn-sm" onclick="_brcApplyRules(${ruleN})" title="Record every line a bank rule covers. Lines that might match something already in dbox are left for you.">⚙ Apply rules (${ruleN})</button>` : ''}
      <button class="btn btn-primary btn-sm" onclick="_brcFinishOpen()">Reconcile…</button>
    </div>`;
}

function _brcRenderTabs() {
  const n = _brcView ? _brcView.lines.length : 0;
  document.getElementById('brc-tabs').innerHTML = `
    <button class="brc-tab${_brcTab === 'reconcile' ? ' active' : ''}" onclick="_brcSetTab('reconcile')">Reconcile${n ? ` <span class="brc-count">${n}</span>` : ''}</button>
    <button class="brc-tab${_brcTab === 'transactions' ? ' active' : ''}" onclick="_brcSetTab('transactions')">Account transactions</button>`;
}

async function _brcSetTab(t) {
  _brcTab = t;
  _brcRenderTabs();
  if (t === 'reconcile') _brcRenderCards();
  else await _brcLoadTxns();
}

// ── Cards ─────────────────────────────────────────────────────────────────────
function _brcRenderCards() {
  const body = document.getElementById('brc-body');
  const lines = _brcView.lines;
  if (!lines.length) {
    body.innerHTML = `<div class="state-empty">
      <svg class="state-empty-icon" aria-hidden="true"><use href="#ic-landmark"/></svg>
      <div class="state-empty-title">All caught up</div>
      <div class="state-empty-sub">Every imported statement line is dealt with. Import the next statement to keep going.</div>
      <button class="btn btn-purple btn-sm" onclick="_brcImport()">⬆ Import statement</button></div>`;
    return;
  }
  body.innerHTML = `<div class="brc-cols"><div>Bank statement</div><div></div><div>Match or create in dbox</div></div>` +
    lines.map(l => `<div class="brc-card" id="brc-card-${l.id}">${_brcCardInner(l)}</div>`).join('');
  lines.forEach(l => _brcRefreshOk(l.id));
}

function _brcLine(id) { return _brcView.lines.find(l => l.id === id); }

function _brcIsIn(l) { return _brcView.is_liability ? l.amount < 0 : l.amount > 0; }

function _brcState(l) {
  if (_brcCards[l.id]) return _brcCards[l.id];
  const isIn = _brcIsIn(l);
  const amt = Math.abs(l.amount);
  const docs = isIn ? _brcOpenInv : _brcOpenBill;
  const exactDoc = docs.find(d => Math.abs(d._owing - amt) < 0.005);
  const st = {
    pane: l.suggestions.length ? 'match' : 'create',
    pick: l.suggestions.length ? l.suggestions[0].journal_line_ids : [],
    sel: new Set(), q: '',
    mode: (!l.rule && exactDoc) ? (isIn ? 'invoice' : 'bill') : 'account',
    doc: exactDoc ? exactDoc.id : '',
    contact: l.rule?.contact_id || '',
    account: l.rule?.account_id || '',
    tax: '', desc: _brcText(l),
    remember: false, pattern: _brcPattern(_brcText(l)),
    split: null,            // [{account, tax, desc, amount}] when split into lines
    xfer: '', xdesc: '',    // transfer: the other bank/card account
    touched: false,
  };
  st.tax = _brcDefaultTax(st.account);
  _brcCards[l.id] = st;
  return st;
}

function _brcCardInner(l) {
  const st = _brcState(l);
  const isIn = _brcIsIn(l);
  const amt = Math.abs(l.amount);
  const liab = _brcView.is_liability;
  const outLbl = liab ? 'Charge' : 'Spent', inLbl = liab ? 'Payment' : 'Received';
  return `
    <div class="brc-stmt">
      <div class="brc-stmt-top">
        <span class="brc-date">${_brcDate(l.transaction_date)}</span>
        ${l.auto ? '<span class="brc-pill brc-pill-auto">Clear match</span>' : ''}
        ${l.rule && st.pane === 'create' ? `<span class="brc-pill">Rule: ${esc(l.rule.name)}</span>` : ''}
      </div>
      <div class="brc-desc">${esc(_brcText(l) || '(no description)')}</div>
      ${l.description && l.reference && l.reference.trim() !== l.description.trim() ? `<div class="brc-ref">${esc(l.reference)}</div>` : ''}
      <div class="brc-amts">
        <div class="${isIn ? 'brc-dim' : ''}"><span>${outLbl}</span><b>${isIn ? '' : _brcMoney(amt)}</b></div>
        <div class="${isIn ? '' : 'brc-dim'}"><span>${inLbl}</span><b class="brc-in">${isIn ? _brcMoney(amt) : ''}</b></div>
      </div>
      <div class="brc-stmt-actions">
        <button class="brc-link" onclick="_brcStartSplit(${l.id})" title="Split across several accounts">Split…</button>
        <button class="brc-link brc-link-danger" onclick="_brcReject(${l.id})" title="Remove a line that was imported twice">Reject duplicate</button>
      </div>
    </div>
    <div class="brc-mid"><button class="btn btn-success brc-ok" id="brc-ok-${l.id}" onclick="_brcOk(${l.id})" disabled>OK</button></div>
    <div class="brc-side">
      <div class="brc-panetabs">
        <button class="${st.pane === 'match' || st.pane === 'find' ? 'active' : ''}" onclick="_brcPane(${l.id},'match')">Match${l.suggestions.length ? '' : ' <span class="brc-muted">(none found)</span>'}</button>
        <button class="${st.pane === 'create' ? 'active' : ''}" onclick="_brcPane(${l.id},'create')">Create</button>
      </div>
      <div class="brc-pane" id="brc-pane-${l.id}">${_brcPaneHtml(l)}</div>
    </div>`;
}

function _brcRerender(id) {
  const l = _brcLine(id), el = document.getElementById(`brc-card-${id}`);
  if (!l || !el) return;
  el.innerHTML = _brcCardInner(l);
  _brcRefreshOk(id);
}

function _brcPane(id, pane) {
  const st = _brcCards[id];
  st.pane = (pane === 'match' && !_brcLine(id).suggestions.length) ? 'find' : pane;
  st.touched = true;
  _brcRerender(id);
}

function _brcPaneHtml(l) {
  const st = _brcCards[l.id];
  if (st.pane === 'match') return _brcMatchHtml(l, st);
  if (st.pane === 'find')  return _brcFindHtml(l, st);
  return _brcCreateHtml(l, st);
}

// ── Match pane ────────────────────────────────────────────────────────────────
function _brcLedgerRow(x) {
  return `<span class="brc-lr-date">${_brcDate(x.date)}</span>
    <span class="brc-lr-desc">${esc(x.description || x.reference || '')}${x.description && x.reference && x.reference.trim() !== x.description.trim() ? ` <span class="brc-muted">${esc(x.reference)}</span>` : ''}</span>
    <span class="brc-lr-amt">${_brcMoney(Math.abs(x.amount))}</span>`;
}

function _brcMatchHtml(l, st) {
  const sug = l.suggestions;
  const chosen = sug.find(s => _brcSameIds(s.journal_line_ids, st.pick)) || sug[0];
  const others = sug.filter(s => s !== chosen);
  return `
    <div class="brc-match">
      ${chosen.kind === 'combined' ? `<div class="brc-note">${chosen.lines.length} transactions in dbox add up to this amount (e.g. receipts banked together):</div>` : ''}
      ${chosen.lines.map(x => `<div class="brc-lr">${_brcLedgerRow(x)}</div>`).join('')}
    </div>
    ${others.length ? `<div class="brc-note">Other possible matches:</div>` + others.map((s, i) => `
      <button class="brc-alt" onclick="_brcPick(${l.id}, ${sug.indexOf(s)})">
        ${s.lines.map(x => `<div class="brc-lr">${_brcLedgerRow(x)}</div>`).join('')}
      </button>`).join('') : ''}
    <button class="brc-link" onclick="_brcPane(${l.id},'find')">Find &amp; match something else…</button>`;
}

function _brcPick(id, idx) {
  const l = _brcLine(id), st = _brcCards[id];
  st.pick = l.suggestions[idx].journal_line_ids;
  st.touched = true;
  _brcRerender(id);
}

function _brcFindHtml(l, st) {
  return `
    <div class="brc-find">
      <input class="form-input brc-find-q" placeholder="Search description, reference or amount…"
             value="${esc(st.q)}" oninput="_brcFindQ(${l.id}, this.value)">
      <div class="brc-find-list" id="brc-find-${l.id}">${_brcFindRows(l, st)}</div>
      <div class="brc-find-foot" id="brc-findfoot-${l.id}">${_brcFindFoot(l, st)}</div>
      ${l.suggestions.length ? `<button class="brc-link" onclick="_brcPane(${l.id},'match')">← Back to suggested match</button>` : ''}
    </div>`;
}

function _brcFindRows(l, st) {
  const isIn = _brcIsIn(l);
  const target = Math.abs(l.amount);
  const q = st.q.trim().toLowerCase();
  const takenElsewhere = new Set();   // lines picked on other cards' find panes
  for (const [k, s] of Object.entries(_brcCards)) if (+k !== l.id && s.pane === 'find') s.sel.forEach(i => takenElsewhere.add(i));
  let rows = _brcLedger.filter(x => ((x.amount > 0) === (l.amount > 0)) && !takenElsewhere.has(x.id));
  if (q) rows = rows.filter(x => [x.description, x.reference, x.contact_name, Math.abs(x.amount).toFixed(2), _brcDate(x.date)]
                  .join(' ').toLowerCase().includes(q));
  const days = x => Math.abs((new Date(x.date) - new Date(l.transaction_date)) / 86400000);
  rows.sort((a, b) => (st.sel.has(b.id) - st.sel.has(a.id))
                   || (Math.abs(Math.abs(a.amount) - target) - Math.abs(Math.abs(b.amount) - target))
                   || (days(a) - days(b)));
  rows = rows.slice(0, 60);
  if (!rows.length) return `<div class="brc-note">Nothing in dbox ${isIn ? 'received' : 'spent'} on this account is waiting to be matched${q ? ' for that search' : ''}. Use Create instead.</div>`;
  return rows.map(x => `
    <label class="brc-lr brc-lr-pick${st.sel.has(x.id) ? ' sel' : ''}">
      <input type="checkbox" ${st.sel.has(x.id) ? 'checked' : ''} onchange="_brcFindToggle(${l.id}, ${x.id}, this.checked)">
      ${_brcLedgerRow(x)}
    </label>`).join('');
}

function _brcFindTotal(st) {
  let t = 0;
  st.sel.forEach(i => { const x = _brcLedger.find(y => y.id === i); if (x) t += x.amount; });
  return _brcRound(t);
}

function _brcFindFoot(l, st) {
  const tot = _brcFindTotal(st);
  const diff = _brcRound(l.amount - tot);
  if (!st.sel.size) return `<span class="brc-muted">Tick the transactions that make up this statement line.</span>`;
  return `Selected ${_brcMoney(Math.abs(tot))} of ${_brcMoney(Math.abs(l.amount))} ·
    ${Math.abs(diff) < 0.005 ? '<b class="brc-ok-txt">Matches ✓</b>' : `<b class="brc-bad-txt">${_brcMoney(Math.abs(diff))} ${Math.abs(tot) > Math.abs(l.amount) ? 'too much' : 'still to find'}</b>`}`;
}

function _brcFindQ(id, q) {
  const l = _brcLine(id), st = _brcCards[id];
  st.q = q;
  document.getElementById(`brc-find-${id}`).innerHTML = _brcFindRows(l, st);
}

function _brcFindToggle(id, lineId, on) {
  const l = _brcLine(id), st = _brcCards[id];
  on ? st.sel.add(lineId) : st.sel.delete(lineId);
  st.touched = true;
  document.getElementById(`brc-findfoot-${id}`).innerHTML = _brcFindFoot(l, st);
  _brcRefreshOk(id);
}

// ── Create pane ───────────────────────────────────────────────────────────────
function _brcCreateHtml(l, st) {
  const isIn = _brcIsIn(l);
  const docLbl = isIn ? 'Invoice payment' : 'Bill payment';
  const docMode = isIn ? 'invoice' : 'bill';
  const seg = `
    <div class="brc-seg">
      <button class="${st.mode === 'account' ? 'active' : ''}" onclick="_brcMode(${l.id},'account')">${isIn ? 'Money in' : 'Money out'} to an account</button>
      <button class="${st.mode === docMode ? 'active' : ''}" onclick="_brcMode(${l.id},'${docMode}')">${docLbl}</button>
      ${_brcAccts.length > 1 ? `<button class="${st.mode === 'xfer' ? 'active' : ''}" onclick="_brcMode(${l.id},'xfer')">Transfer</button>` : ''}
    </div>`;
  if (st.mode === 'xfer') return seg + _brcXferHtml(l, st, isIn);
  if (st.mode !== 'account') return seg + _brcDocHtml(l, st, isIn);
  if (st.split) return seg + _brcSplitHtml(l, st);

  const contactOpts = `<option value="">— optional —</option>` +
    _brcContacts.map(c => `<option value="${c.id}" ${String(c.id) === String(st.contact) ? 'selected' : ''}>${esc(c.name)}</option>`).join('');
  const groups = ['Income', 'Expense', 'Asset', 'Liability', 'Equity'];
  const accOpts = `<option value="">— choose an account —</option>` + groups.map(g => {
    const accs = _brcAllAccs.filter(a => a.account_type === g && a.id !== _brcAccId);
    return accs.length ? `<optgroup label="${g}">` + accs.map(a =>
      `<option value="${a.id}" ${String(a.id) === String(st.account) ? 'selected' : ''}>${esc(a.code)}  ${esc(a.name)}${a.is_bank || a.is_credit_card ? '  (transfer)' : ''}</option>`).join('') + `</optgroup>` : '';
  }).join('');
  const taxOpts = _BRC_TAX.map(([c, n]) => `<option value="${c}" ${c === st.tax ? 'selected' : ''}>${n}</option>`).join('');
  return seg + `
    <div class="brc-form">
      <label>Who</label>
      <select class="form-input" onchange="_brcSet(${l.id},'contact',this.value)">${contactOpts}</select>
      <label>Account</label>
      <select class="form-input" onchange="_brcSet(${l.id},'account',this.value)">${accOpts}</select>
      <label>GST</label>
      <select class="form-input" id="brc-tax-${l.id}" onchange="_brcSet(${l.id},'tax',this.value)">${taxOpts}</select>
      <label>Description</label>
      <input class="form-input" value="${esc(st.desc)}" oninput="_brcSet(${l.id},'desc',this.value)">
    </div>
    <button class="brc-link" onclick="_brcStartSplit(${l.id})">Split into several lines…</button>
    <label class="brc-remember">
      <input type="checkbox" ${st.remember ? 'checked' : ''} onchange="_brcSet(${l.id},'remember',this.checked)">
      Remember: use this account and contact for statement lines containing
      <input class="form-input brc-pattern" value="${esc(st.pattern)}" oninput="_brcSet(${l.id},'pattern',this.value)">
    </label>`;
}

function _brcAccOpts(sel) {
  const groups = ['Income', 'Expense', 'Asset', 'Liability', 'Equity'];
  return `<option value="">— account —</option>` + groups.map(g => {
    const accs = _brcAllAccs.filter(a => a.account_type === g && a.id !== _brcAccId);
    return accs.length ? `<optgroup label="${g}">` + accs.map(a =>
      `<option value="${a.id}" ${String(a.id) === String(sel) ? 'selected' : ''}>${esc(a.code)}  ${esc(a.name)}</option>`).join('') + `</optgroup>` : '';
  }).join('');
}

// ── Split on the card ─────────────────────────────────────────────────────────
function _brcStartSplit(id) {
  const l = _brcLine(id), st = _brcCards[id] || _brcState(l);
  st.pane = 'create';
  st.mode = 'account';
  if (!st.split) {
    st.split = [
      { account: st.account, tax: st.account ? st.tax : _brcDefaultTax(''), desc: st.desc, amount: Math.abs(l.amount).toFixed(2) },
      { account: '', tax: _brcDefaultTax(''), desc: st.desc, amount: '' },
    ];
  }
  st.touched = true;
  _brcRerender(id);
}

function _brcSplitHtml(l, st) {
  const contactOpts = `<option value="">— optional —</option>` +
    _brcContacts.map(c => `<option value="${c.id}" ${String(c.id) === String(st.contact) ? 'selected' : ''}>${esc(c.name)}</option>`).join('');
  const rows = st.split.map((r, i) => `
    <div class="brc-split-row">
      <select class="form-input" onchange="_brcSplitSet(${l.id},${i},'account',this.value)">${_brcAccOpts(r.account)}</select>
      <select class="form-input" onchange="_brcSplitSet(${l.id},${i},'tax',this.value)">${_BRC_TAX.map(([c, n]) => `<option value="${c}" ${c === r.tax ? 'selected' : ''}>${n}</option>`).join('')}</select>
      <input class="form-input" placeholder="Description" value="${esc(r.desc)}" oninput="_brcSplitSet(${l.id},${i},'desc',this.value)">
      <input class="form-input brc-split-amt" inputmode="decimal" placeholder="0.00" value="${esc(r.amount)}" oninput="_brcSplitSet(${l.id},${i},'amount',this.value)">
      <button class="brc-split-x" title="Remove line" onclick="_brcSplitRemove(${l.id},${i})" ${st.split.length < 2 ? 'disabled' : ''}>✕</button>
    </div>`).join('');
  return `
    <div class="brc-form brc-form-1"><label>Who</label>
      <select class="form-input" onchange="_brcSet(${l.id},'contact',this.value)">${contactOpts}</select></div>
    <div class="brc-split-head"><span>Account</span><span>GST</span><span>Description</span><span class="brc-r">Amount</span><span></span></div>
    ${rows}
    <div class="brc-split-foot">
      <button class="brc-link" onclick="_brcSplitAdd(${l.id})">+ Add line</button>
      <span id="brc-split-left-${l.id}">${_brcSplitLeft(l, st)}</span>
    </div>
    <div class="brc-split-links">
      <button class="brc-link" onclick="_brcSplitCancel(${l.id})">Back to one line</button>
      <button class="brc-link" onclick="_brcSplit(${l.id})" title="Mix invoices, bills and accounts in one split">Including invoices or bills? Full split dialog…</button>
    </div>`;
}

function _brcSplitTotal(st) {
  return _brcRound(st.split.reduce((t, r) => t + (parseFloat(r.amount) || 0), 0));
}

function _brcSplitLeft(l, st) {
  const left = _brcRound(Math.abs(l.amount) - _brcSplitTotal(st));
  if (Math.abs(left) < 0.005) return `<b class="brc-ok-txt">Fully allocated ✓</b>`;
  return left > 0 ? `<b class="brc-bad-txt">${_brcMoney(left)} left to allocate</b>`
                  : `<b class="brc-bad-txt">${_brcMoney(-left)} too much</b>`;
}

function _brcSplitSet(id, i, key, val) {
  const l = _brcLine(id), st = _brcCards[id];
  st.split[i][key] = val;
  st.touched = true;
  if (key === 'account') {
    st.split[i].tax = _brcDefaultTax(val);
    _brcRerender(id);
    return;
  }
  if (key === 'amount') document.getElementById(`brc-split-left-${id}`).innerHTML = _brcSplitLeft(l, st);
  _brcRefreshOk(id);
}

function _brcSplitAdd(id) {
  const l = _brcLine(id), st = _brcCards[id];
  const left = _brcRound(Math.abs(l.amount) - _brcSplitTotal(st));
  st.split.push({ account: '', tax: _brcDefaultTax(''), desc: st.desc, amount: left > 0 ? left.toFixed(2) : '' });
  _brcRerender(id);
}

function _brcSplitRemove(id, i) {
  const st = _brcCards[id];
  if (st.split.length < 2) return;
  st.split.splice(i, 1);
  _brcRerender(id);
}

function _brcSplitCancel(id) {
  const st = _brcCards[id];
  const first = st.split && st.split[0];
  if (first && first.account) { st.account = first.account; st.tax = first.tax; }
  st.split = null;
  _brcRerender(id);
}

function _brcSplitValid(l, st) {
  return st.split.length > 0
    && st.split.every(r => r.account && (parseFloat(r.amount) || 0) > 0)
    && Math.abs(_brcSplitTotal(st) - Math.abs(l.amount)) < 0.005;
}

// ── Transfer ──────────────────────────────────────────────────────────────────
function _brcXferHtml(l, st, isIn) {
  const others = _brcAccts.filter(a => a.id !== _brcAccId);
  const opts = `<option value="">— choose an account —</option>` + others.map(a =>
    `<option value="${a.id}" ${String(a.id) === String(st.xfer) ? 'selected' : ''}>${esc(a.code)}  ${esc(a.name)}</option>`).join('');
  return `
    <div class="brc-form">
      <label>${isIn ? 'From' : 'To'}</label>
      <select class="form-input" onchange="_brcXferSet(${l.id},this.value)">${opts}</select>
      <label>Description</label>
      <input class="form-input" id="brc-xdesc-${l.id}" value="${esc(st.xdesc)}" oninput="_brcSet(${l.id},'xdesc',this.value)">
    </div>
    <div class="brc-note">Money moving between your own accounts. No GST. When you reconcile the other account, its statement line will be matched to this transfer.</div>`;
}

function _brcXferSet(id, val) {
  const l = _brcLine(id), st = _brcCards[id];
  st.xfer = val;
  st.touched = true;
  const a = _brcAccts.find(x => String(x.id) === String(val));
  if (a && (!st.xdesc || /^Transfer (to|from) /.test(st.xdesc))) {
    st.xdesc = `Transfer ${_brcIsIn(l) ? 'from' : 'to'} ${a.name}`;
    const el = document.getElementById(`brc-xdesc-${id}`);
    if (el) el.value = st.xdesc;
  }
  _brcRefreshOk(id);
}

function _brcDocHtml(l, st, isIn) {
  const amt = Math.abs(l.amount);
  const docs = (isIn ? _brcOpenInv : _brcOpenBill).slice()
    .sort((a, b) => Math.abs(a._owing - amt) - Math.abs(b._owing - amt));
  if (!docs.length) return `<div class="brc-note">No unpaid ${isIn ? 'invoices' : 'bills'}. Use “${isIn ? 'Money in' : 'Money out'} to an account” instead.</div>`;
  const num = d => isIn ? d.invoice_number : (d.bill_number || d.supplier_ref || `Bill ${d.id}`);
  const opts = `<option value="">— choose ${isIn ? 'an invoice' : 'a bill'} —</option>` + docs.map(d =>
    `<option value="${d.id}" ${String(d.id) === String(st.doc) ? 'selected' : ''}>${esc(num(d) || '')} · ${esc(d.contact_name || '')} · owing ${_brcMoney(d._owing)}${Math.abs(d._owing - amt) < 0.005 ? '  ✓ same amount' : ''}</option>`).join('');
  const d = docs.find(x => String(x.id) === String(st.doc));
  let note = '';
  if (d) {
    if (amt > d._owing + 0.005) note = `<div class="brc-note brc-bad-txt">The statement line is more than this ${isIn ? 'invoice' : 'bill'} owes (${_brcMoney(d._owing)}). Use Split… to pay several, or choose another.</div>`;
    else if (amt < d._owing - 0.005) note = `<div class="brc-note">Part payment: ${_brcMoney(d._owing - amt)} will still be owing.</div>`;
  }
  return `<div class="brc-form brc-form-1">
      <label>${isIn ? 'Invoice' : 'Bill'}</label>
      <select class="form-input" onchange="_brcSet(${l.id},'doc',this.value)">${opts}</select>
    </div>${note}`;
}

function _brcMode(id, mode) {
  const st = _brcCards[id];
  st.mode = mode;
  st.touched = true;
  _brcRerender(id);
}

function _brcSet(id, key, val) {
  const st = _brcCards[id];
  st[key] = val;
  st.touched = true;
  if (key === 'account') {
    st.tax = _brcDefaultTax(val);
    const t = document.getElementById(`brc-tax-${id}`);
    if (t) t.value = st.tax;
  }
  if (key === 'doc') { _brcRerender(id); return; }
  _brcRefreshOk(id);
}

// ── OK ────────────────────────────────────────────────────────────────────────
function _brcValid(l) {
  const st = _brcCards[l.id];
  if (!st) return false;
  if (st.pane === 'match') return st.pick.length > 0;
  if (st.pane === 'find')  return st.sel.size > 0 && Math.abs(_brcFindTotal(st) - l.amount) < 0.005;
  if (st.mode === 'xfer') return !!st.xfer;
  if (st.mode === 'account' && st.split) return _brcSplitValid(l, st);
  if (st.mode === 'account') return !!st.account && (!st.remember || st.pattern.trim().length >= 3);
  const docs = st.mode === 'invoice' ? _brcOpenInv : _brcOpenBill;
  const d = docs.find(x => String(x.id) === String(st.doc));
  return !!d && Math.abs(l.amount) <= d._owing + 0.005;
}

function _brcRefreshOk(id) {
  const l = _brcLine(id), b = document.getElementById(`brc-ok-${id}`);
  if (b && l) b.disabled = _brcBusy.has(id) || !_brcValid(l);
}

async function _brcPost(url, body) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const d = await r.json();
  if (!d.ok) throw new Error(d.error || 'Failed');
  return d.data;
}

async function _brcOk(id) {
  const l = _brcLine(id), st = _brcCards[id];
  if (!l || !st || _brcBusy.has(id) || !_brcValid(l)) return;
  _brcBusy.add(id);
  _brcRefreshOk(id);
  let paidDoc = false;
  try {
    if (st.pane === 'match' || st.pane === 'find') {
      await _brcPost('/api/bankrec/match', { bank_txn_id: id, journal_line_ids: st.pane === 'find' ? [...st.sel] : st.pick });
    } else if (st.mode === 'xfer') {
      await _brcPost('/api/bankrec/allocate', { bank_txn_id: id, mode: 'account', alloc_data: {
        account_id: parseInt(st.xfer), tax_code: 'N-T', description: st.xdesc.trim() || _brcText(l), contact_id: null } });
    } else if (st.mode === 'account' && st.split && st.split.length > 1) {
      const contact = st.contact ? parseInt(st.contact) : null;
      await _brcPost('/api/bankrec/allocate-multi', { bank_txn_id: id, lines: st.split.map(r => ({
        mode: 'account', amount: _brcRound(parseFloat(r.amount)), account_id: parseInt(r.account),
        tax_code: r.tax, description: r.desc.trim() || _brcText(l), contact_id: contact })) });
    } else if (st.mode === 'account' && st.split) {
      const r = st.split[0];
      await _brcPost('/api/bankrec/allocate', { bank_txn_id: id, mode: 'account', alloc_data: {
        account_id: parseInt(r.account), tax_code: r.tax, description: r.desc.trim() || _brcText(l),
        contact_id: st.contact ? parseInt(st.contact) : null } });
    } else if (st.mode === 'account') {
      await _brcPost('/api/bankrec/allocate', { bank_txn_id: id, mode: 'account', alloc_data: {
        account_id: parseInt(st.account), tax_code: st.tax, description: st.desc.trim() || _brcText(l),
        contact_id: st.contact ? parseInt(st.contact) : null } });
      if (st.remember) await _brcSaveRule(l, st);
    } else {
      const docs = st.mode === 'invoice' ? _brcOpenInv : _brcOpenBill;
      const d = docs.find(x => String(x.id) === String(st.doc));
      await _brcPost('/api/bankrec/allocate', { bank_txn_id: id, mode: st.mode, alloc_data: {
        [st.mode === 'invoice' ? 'invoice_id' : 'bill_id']: d.id, amount: Math.abs(l.amount),
        contact_id: d.contact_id || null } });
      paidDoc = true;
    }
  } catch (e) {
    _brcBusy.delete(id);
    _brcRefreshOk(id);
    toast(e.message, 'err');
    return;
  }
  _brcBusy.delete(id);
  const card = document.getElementById(`brc-card-${id}`);
  if (card) card.classList.add('brc-done');
  delete _brcCards[id];
  if (paidDoc || st.remember) await _brcLoadLookups();
  setTimeout(_brcReload, card ? 220 : 0);
}

async function _brcSaveRule(l, st) {
  const debit = parseFloat(l.debit || 0) > 0;
  try {
    await _brcPost('/api/bankrec/rules', {
      rule_name: st.pattern.trim(), match_field: (l.description || '').trim() ? 'description' : 'reference',
      match_type: 'contains',
      match_value: st.pattern.trim(), direction: debit ? 'debit' : 'credit',
      account_id: parseInt(st.account), contact_id: st.contact ? parseInt(st.contact) : null,
      is_active: 1, priority: 0 });
    toast(`Rule saved: “${st.pattern.trim()}”`);
  } catch (e) {
    toast('Saved the transaction, but the rule failed: ' + e.message, 'err');
  }
}

async function _brcAcceptAuto() {
  const autos = _brcView.lines.filter(l => l.auto && l.suggestions.length);
  if (!autos.length) return;
  let done = 0, failed = 0;
  for (const l of autos) {
    try {
      await _brcPost('/api/bankrec/match', { bank_txn_id: l.id, journal_line_ids: l.suggestions[0].journal_line_ids });
      done++;
    } catch { failed++; }
  }
  toast(`Matched ${done} statement line${done === 1 ? '' : 's'}${failed ? ` · ${failed} couldn't be matched` : ''}`, failed ? 'err' : undefined);
  await _brcReload();
}

async function _brcApplyRules(n) {
  let d;
  try { d = await _brcPost(`/api/bankrec/${_brcAccId}/apply-rules`, {}); }
  catch (e) { toast(e.message, 'err'); return; }
  let msg = `Rules recorded ${d.applied} statement line${d.applied === 1 ? '' : 's'}`;
  if (d.skipped_match) msg += ` · ${d.skipped_match} left for you (might match something already in dbox)`;
  if (d.errors && d.errors.length) msg += ` · ${d.errors.length} failed`;
  toast(msg, d.errors && d.errors.length ? 'err' : undefined);
  _brcCards = {};
  await _brcReload();
}

// ── Reconcile (finish a statement) ────────────────────────────────────────────
let _brcFin = null;    // { preview }

function _brcFinishOpen() {
  document.getElementById('brc-fin-bd')?.remove();
  _brcFin = null;
  const v = _brcView;
  const liab = v.is_liability;
  const lastStmt = v.statement_date || new Date().toISOString().slice(0, 10);
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.id = 'brc-fin-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box brc-fin">
    <div class="modal-hdr">Reconcile ${esc(v.account.code)} ${esc(v.account.name)}</div>
    <div class="modal-body">
      <p class="brc-note">Enter the date and closing balance from your bank statement. dbox checks that everything up to that date adds up, then marks it reconciled.</p>
      <div class="brc-form">
        <label for="brc-fin-date">Reconcile date</label>
        <input type="date" class="form-input" id="brc-fin-date" value="${lastStmt}" onchange="_brcFinishPreview()">
        <label for="brc-fin-close">Statement balance${liab ? ' (owed)' : ''}</label>
        <input class="form-input" id="brc-fin-close" inputmode="decimal" placeholder="0.00" oninput="_brcFinishCalc()">
        <label for="brc-fin-open">Opening balance</label>
        <input class="form-input" id="brc-fin-open" inputmode="decimal" oninput="_brcFinishCalc()">
      </div>
      <div id="brc-fin-sum" class="brc-fin-sum"><div class="state-loading">Checking…</div></div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-outline" onclick="document.getElementById('brc-fin-bd').remove()">Cancel</button>
      <button class="btn btn-success" id="brc-fin-go" onclick="_brcFinishGo()" disabled>Reconcile</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  _brcFinishPreview(true);
}

async function _brcFinishPreview(first) {
  const date = document.getElementById('brc-fin-date').value;
  if (!date) return;
  let p;
  try { p = await apiFetch(`/api/bankrec/${_brcAccId}/finish-preview?date=${encodeURIComponent(date)}`); }
  catch (e) { document.getElementById('brc-fin-sum').innerHTML = `<div class="state-error">${esc(e.message)}</div>`; return; }
  _brcFin = { preview: p, adjOn: _brcFin?.adjOn || false, adjAcc: _brcFin?.adjAcc || '' };
  const open = document.getElementById('brc-fin-open');
  open.value = p.opening.toFixed(2);
  open.readOnly = p.opening_locked;
  open.title = p.opening_locked ? `Closing balance of the reconciliation to ${_brcDate(p.last_rec_date)}` : 'First reconciliation: the balance at the start of the first statement';
  const close = document.getElementById('brc-fin-close');
  if (p.statement_balance != null && (first || !close.dataset.typed)) close.value = p.statement_balance.toFixed(2);
  close.oninput = () => { close.dataset.typed = '1'; _brcFinishCalc(); };
  _brcFinishCalc();
}

function _brcFinishCalc() {
  const p = _brcFin && _brcFin.preview;
  if (!p) return;
  const close = parseFloat(document.getElementById('brc-fin-close').value);
  const open = p.opening_locked ? p.opening : parseFloat(document.getElementById('brc-fin-open').value || 0);
  const expected = _brcRound(open + p.movement);
  const problems = [];
  if (p.last_rec_date && p.as_at <= p.last_rec_date)
    problems.push(`Already reconciled to ${_brcDate(p.last_rec_date)}. Choose a later date.`);
  if (p.outstanding)
    problems.push(`${p.outstanding} statement line${p.outstanding === 1 ? '' : 's'} up to this date still need${p.outstanding === 1 ? 's' : ''} matching or creating.`);
  let diffHtml = '';
  let balanced = false;
  let diff = 0;
  if (!isNaN(close)) {
    diff = _brcRound(close - expected);
    balanced = Math.abs(diff) < 0.005;
    diffHtml = balanced
      ? `<div class="brc-fin-row brc-fin-total"><span>Difference</span><b class="brc-ok-txt">$0.00 ✓</b></div>`
      : `<div class="brc-fin-row brc-fin-total"><span>Difference</span><b class="brc-bad-txt">${_brcMoney(diff)}</b></div>
         <div class="brc-note">Usually a statement line that hasn't been imported, or a wrong opening or statement balance.</div>`;
  }
  const canAdjust = !isNaN(close) && !balanced && !p.outstanding && !(p.last_rec_date && p.as_at <= p.last_rec_date);
  const adjusting = canAdjust && _brcFin.adjOn && _brcFin.adjAcc;
  if (!p.line_count && !problems.length && !adjusting)
    problems.push('Nothing new to reconcile up to this date.');
  if (canAdjust) {
    const accs = _brcAllAccs.filter(a => ['Expense', 'Income', 'Equity'].includes(a.account_type) && a.id !== _brcAccId);
    if (!_brcFin.adjAcc) {
      const guess = accs.find(a => /bank (fee|charge)|suspense/i.test(a.name));
      if (guess) _brcFin.adjAcc = String(guess.id);
    }
    diffHtml += `<div class="brc-fin-adj">
      <label><input type="checkbox" ${_brcFin.adjOn ? 'checked' : ''} onchange="_brcFin.adjOn=this.checked; _brcFinishCalc()">
        Record the ${_brcMoney(Math.abs(diff))} difference as an adjustment to</label>
      <select class="form-input" onchange="_brcFin.adjAcc=this.value; _brcFinishCalc()">
        <option value="">— choose an account —</option>
        ${accs.map(a => `<option value="${a.id}" ${String(a.id) === String(_brcFin.adjAcc) ? 'selected' : ''}>${esc(a.code)}  ${esc(a.name)}</option>`).join('')}
      </select>
      <div class="brc-note">Only when you're sure the statement is right, e.g. a small bank fee you won't record separately. A journal is posted on the reconcile date.</div>
    </div>`;
  }
  document.getElementById('brc-fin-sum').innerHTML = `
    <div class="brc-fin-row"><span>Opening balance</span><b>${_brcMoney(open)}</b></div>
    <div class="brc-fin-row"><span>+ ${p.line_count} statement line${p.line_count === 1 ? '' : 's'} dealt with up to ${_brcDate(p.as_at)}</span><b>${_brcMoney(p.movement)}</b></div>
    <div class="brc-fin-row brc-fin-total"><span>Should be on the statement</span><b>${_brcMoney(expected)}</b></div>
    ${diffHtml}
    ${problems.map(m => `<div class="brc-note brc-bad-txt">${esc(m)}</div>`).join('')}`;
  _brcFin.adjusting = adjusting;
  _brcFin.adjDiff = diff;
  document.getElementById('brc-fin-go').disabled = !(balanced || adjusting) || problems.length > 0;
}

async function _brcFinishGo() {
  const btn = document.getElementById('brc-fin-go');
  btn.disabled = true;
  const p = _brcFin.preview;
  let d;
  try {
    d = await _brcPost(`/api/bankrec/${_brcAccId}/finish`, {
      date: document.getElementById('brc-fin-date').value,
      closing: parseFloat(document.getElementById('brc-fin-close').value),
      opening: p.opening_locked ? null : parseFloat(document.getElementById('brc-fin-open').value || 0),
      adjust_account_id: _brcFin.adjusting ? parseInt(_brcFin.adjAcc) : null,
    });
  } catch (e) { toast(e.message, 'err'); _brcFinishCalc(); return; }
  const box = document.querySelector('#brc-fin-bd .modal-box');
  box.querySelector('.modal-body').innerHTML = `
    <div class="brc-fin-done">✓ Reconciled to ${_brcDate(p.as_at)}</div>
    <p class="brc-note">${p.line_count} statement line${p.line_count === 1 ? '' : 's'} and their transactions in dbox are now reconciled${_brcFin.adjusting ? `, plus an adjustment of ${_brcMoney(Math.abs(_brcFin.adjDiff))} to ${esc((_brcAllAccs.find(a => String(a.id) === String(_brcFin.adjAcc)) || {}).name || 'the chosen account')}` : ''}. The statement balance carries forward as the next opening balance.</p>`;
  box.querySelector('.modal-foot').innerHTML = `
    <button class="btn btn-outline" onclick="_brcSyncClassic(); _brShowPeriodReport(${d.id})">View report</button>
    <button class="btn btn-primary" onclick="document.getElementById('brc-fin-bd').remove()">Done</button>`;
  _brcReload();
}

async function _brcReject(id) {
  const l = _brcLine(id);
  if (!confirm(`Reject this statement line as a duplicate?\n\n${_brcDate(l.transaction_date)}  ${_brcText(l)}  ${_brcMoney(Math.abs(l.amount))}\n\nUse this only for a line that was imported twice. Nothing is recorded in dbox.`)) return;
  try {
    await _brcPost('/api/bankrec/reject', { items: [{ source: 'csv', id }] });
  } catch (e) { toast(e.message, 'err'); return; }
  delete _brcCards[id];
  _brcReload();
}

// Split / more options: the classic allocation dialog
function _brcSplit(id) {
  const l = _brcLine(id);
  const txn = { ...l, _source: 'csv', _iid: `csv:${id}` };
  _brcSyncClassic();
  _brTxns = [txn];
  _brShowAllocModal(txn, () => { delete _brcCards[id]; _brcReload(); });
}

// ── Toolbar actions (bankrec.js dialogs) ──────────────────────────────────────
function _brcImport()   { _brcSyncClassic(); _brShowImportCsv(); }
function _brcRules()    { _brcSyncClassic(); _brShowRules(); }
function _brcReport()   { _brcSyncClassic(); _brShowReport(); }
function _brcPastRecs() { _brcSyncClassic(); _brShowPastRecs(); }

// ── Account transactions tab ──────────────────────────────────────────────────
async function _brcLoadTxns() {
  const body = document.getElementById('brc-body');
  try {
    _brcTxnRows = await apiFetch(`/api/bankrec/${_brcAccId}/account-transactions`);
  } catch (e) {
    body.innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`;
    return;
  }
  body.innerHTML = `
    <div class="inv-toolbar">
      <input class="inv-search" id="brc-txn-q" placeholder="Search description, reference or amount…" oninput="_brcRenderTxns()">
      <select class="inv-search" id="brc-txn-st" onchange="_brcRenderTxns()" style="max-width:220px">
        <option value="">All</option>
        <option value="open">Not yet reconciled</option>
        <option value="reconciled">Reconciled</option>
      </select>
    </div>
    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        <th>Date</th><th>Description</th><th>Reference</th>
        <th class="th-r">${_brcView.is_liability ? 'Charge' : 'Spent'}</th>
        <th class="th-r">${_brcView.is_liability ? 'Payment' : 'Received'}</th>
        <th class="th-c">Status</th><th></th>
      </tr></thead><tbody id="brc-txn-body"></tbody></table>
    </div></div>
    <div class="mt-8"><span class="count-pill" id="brc-txn-count"></span></div>`;
  _brcRenderTxns();
}

function _brcRenderTxns() {
  const q = (document.getElementById('brc-txn-q')?.value || '').trim().toLowerCase();
  const f = document.getElementById('brc-txn-st')?.value || '';
  const liab = _brcView.is_liability;
  const label = {
    reconciled:   ['Reconciled', 'brc-st-rec'],
    statement:    ['From statement', 'brc-st-ok'],
    matched:      ['Matched', 'brc-st-ok'],
    unreconciled: ['Not on a statement yet', 'brc-st-open'],
    rejected:     ['Rejected', 'brc-st-rej'],
  };
  let rows = _brcTxnRows.filter(r => r.status !== 'rejected' || f === '');
  if (f === 'open') rows = rows.filter(r => r.status !== 'reconciled' && r.status !== 'rejected');
  if (f === 'reconciled') rows = rows.filter(r => r.status === 'reconciled');
  if (q) rows = rows.filter(r => [r.description, r.reference, Math.abs(r.amount).toFixed(2), _brcDate(r.date)]
                     .join(' ').toLowerCase().includes(q));
  const tb = document.getElementById('brc-txn-body');
  tb.innerHTML = rows.length ? rows.map((r, i) => {
    const isIn = liab ? r.amount < 0 : r.amount > 0;
    const [lbl, cls] = label[r.status] || [r.status, ''];
    return `<tr class="inv-row${i % 2 ? ' row-alt' : ''}">
      <td class="brc-nowrap"><span class="inv-mono">${_brcDate(r.date)}</span></td>
      <td>${esc(r.description || '')}</td>
      <td><span class="inv-mono">${esc(r.reference || '')}</span></td>
      <td class="inv-amt">${isIn ? '' : _brcMoney(Math.abs(r.amount))}</td>
      <td class="inv-amt">${isIn ? _brcMoney(Math.abs(r.amount)) : ''}</td>
      <td class="col-c"><span class="brc-st ${cls}">${lbl}</span></td>
      <td class="col-c">${r.status === 'statement' || r.status === 'matched'
        ? `<button class="brc-link" onclick="_brcUndo('${r.status}', ${r.status === 'statement' ? r.from_statement : r.matched_to})" title="Put the statement line back on the Reconcile tab">Remove &amp; redo</button>` : ''}</td>
    </tr>`;
  }).join('') : `<tr><td colspan="7" style="padding:0"><div class="state-empty"><div class="state-empty-title">No transactions</div></div></td></tr>`;
  document.getElementById('brc-txn-count').textContent = `${rows.length} of ${_brcTxnRows.length} transactions`;
}

// Undo an OK'd statement line that isn't in a finished reconciliation yet
async function _brcUndo(kind, bankTxnId) {
  const msg = kind === 'matched'
    ? `Remove this match?\n\nThe statement line goes back to the Reconcile tab. The transaction in dbox is left as it is.`
    : `Remove this transaction?\n\nWhat was recorded from the statement line is reversed (including any invoice or bill payment), and the line goes back to the Reconcile tab to redo.`;
  if (!confirm(msg)) return;
  try {
    await _brcPost(kind === 'matched' ? '/api/bankrec/unmatch' : '/api/bankrec/deallocate', { bank_txn_id: bankTxnId });
  } catch (e) { toast(e.message, 'err'); return; }
  toast('Statement line is back on the Reconcile tab');
  await _brcLoadLookups();
  await _brcReload();
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function _brcRound(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }

function _brcMoney(n) {
  const v = parseFloat(n || 0);
  return (v < 0 ? '−$' : '$') + Math.abs(v).toLocaleString('en-AU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function _brcDate(iso) {
  if (!iso) return '';
  const d = new Date(iso + 'T00:00:00');
  return isNaN(d) ? iso : d.toLocaleDateString('en-AU', { day: 'numeric', month: 'short', year: 'numeric' });
}

// Statement text: some banks leave description empty and put it all in reference
function _brcText(l) { return (l.description || '').trim() || (l.reference || '').trim(); }

function _brcSameIds(a, b) {
  return a.length === b.length && a.every(x => b.includes(x));
}

function _brcDefaultTax(accId) {
  if (!_brcGstReg) return 'N-T';
  const a = _brcAllAccs.find(x => String(x.id) === String(accId));
  if (!a) return 'GST';
  if (!['Income', 'Expense'].includes(a.account_type)) return 'N-T';
  return _BRC_TAX.some(([c]) => c === a.tax_code) ? a.tax_code : 'GST';
}

// A starting pattern for "Remember": the first meaningful words of the
// statement description, without card numbers, dates and amounts.
function _brcPattern(desc) {
  const skip = /^(eftpos|visa|purchase|pos|card|debit|credit|tfr|transfer|from|to|direct|osko|payment|ref|value|date)$/i;
  const words = (desc || '').split(/\s+/)
    .map(w => w.replace(/[^A-Za-z&'.-]/g, ''))
    .filter(w => w.length >= 3 && !skip.test(w));
  return words.slice(0, 2).join(' ').toLowerCase();
}
