// Expense Claims module — prefix _exp
// Routes: GET/POST /api/expense-claims, GET/PUT/DELETE /api/expense-claims/<id>
//         POST /api/expense-claims/<id>/post, POST /api/expense-claims/<id>/void

let _expAll    = [];
let _expFilter = 'All';
let _expSearch = '';
let _expDetId  = null;
let _expAccts  = null;   // expense accounts cache

const EXP_STATS  = ['All', 'Draft', 'Posted'];
const EXP_BADGE  = { Draft: 'badge-draft', Posted: 'badge-paid' };
const EXP_CATS   = ['Motor Vehicle','Mileage','Travel & Accommodation',
                     'Meals & Entertainment','Office Supplies','Phone & Internet',
                     'Professional Development','Tools & Equipment','Subscriptions','Other'];

// ─── Page entry ───────────────────────────────────────────────────────────────

async function pageExpenseClaims() {
  try {
    _expAll = await apiFetch('/api/expense-claims') || [];
  } catch(e) {
    document.getElementById('module-content').innerHTML =
      `<div class="state-error">${esc(e.message)}</div>`; return;
  }
  _expRender();
}

function _expRender() {
  const q = _expSearch.toLowerCase();
  const rows = _expAll.filter(c => {
    if (_expFilter !== 'All' && c.status !== _expFilter) return false;
    if (q && !(`${c.description} ${c.category}`.toLowerCase().includes(q))) return false;
    return true;
  });

  const counts = {};
  EXP_STATS.forEach(s => counts[s] = s === 'All' ? _expAll.length : _expAll.filter(c => c.status === s).length);

  document.getElementById('module-content').innerHTML = `
    <div class="inv-toolbar">
      <input class="inv-search" id="exp-q" placeholder="Search description, category…" value="${esc(_expSearch)}"
             oninput="_expSearch=this.value;_expRender()">
      <div class="inv-filter-group">
        ${EXP_STATS.map(s => `<button class="filter-btn${_expFilter===s?' active':''}" onclick="_expSetFilter('${s}')">
          ${s}${counts[s]?` <span class="filter-count">(${counts[s]})</span>`:''}</button>`).join('')}
      </div>
      <button class="btn btn-primary" onclick="_expNew()">+ New Claim</button>
    </div>
    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        <th>Date</th><th>Description</th><th>Category</th>
        <th class="th-r">Ex GST</th><th class="th-r">GST</th><th class="th-r">Total</th>
        <th>Status</th>
      </tr></thead><tbody>
        ${rows.length ? rows.map(_expRow).join('') :
          `<tr class="tbl-empty-row"><td colspan="7">No expense claims match your filter</td></tr>`}
      </tbody></table>
    </div></div>
    <div class="count-pill">${rows.length} of ${_expAll.length}</div>`;
}

function _expRow(c) {
  return `<tr class="inv-row" onclick="_expOpen(${c.id})">
    <td class="td-mono">${fmtDate(c.claim_date)}</td>
    <td>${esc(c.description)}</td>
    <td><span class="col-ink2">${esc(c.category||'')}</span></td>
    <td class="td-r-mono">${fmt(c.amount_ex_gst)}</td>
    <td class="td-r-mono">${c.gst_amount ? fmt(c.gst_amount) : '<span class="col-ink3">—</span>'}</td>
    <td class="td-r-mono-bold">${fmt(c.total)}</td>
    <td><span class="badge ${EXP_BADGE[c.status]||'badge-draft'}">${c.status}</span></td>
  </tr>`;
}

function _expSetFilter(f) { _expFilter = f; _expRender(); }

// ─── Detail panel ─────────────────────────────────────────────────────────────

async function _expOpen(id) {
  _expDetId = id;
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = 'Expense Claim';
  document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading…</div>';
  document.getElementById('det-foot').innerHTML = '';
  try {
    const c = await apiFetch(`/api/expense-claims/${id}`);
    _expRenderDetail(c);
  } catch(e) {
    document.getElementById('det-body').innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
  }
}

function _expRenderDetail(c) {
  document.getElementById('det-title').textContent = `Expense — ${fmtDate(c.claim_date)}`;
  const isDraft  = c.status === 'Draft';
  const isPosted = c.status === 'Posted';

  document.getElementById('det-body').innerHTML = `
    <div class="det-meta">
      <div><div class="det-lbl">Date</div><div class="det-val mono">${fmtDate(c.claim_date)}</div></div>
      <div><div class="det-lbl">Status</div><div class="det-val"><span class="badge ${EXP_BADGE[c.status]||'badge-draft'}">${c.status}</span></div></div>
      <div><div class="det-lbl">Category</div><div class="det-val">${esc(c.category||'—')}</div></div>
      ${c.is_mileage ? `<div><div class="det-lbl">Distance</div><div class="det-val mono">${(c.km||0)} km @ $${(c.km_rate||0).toFixed(4)}/km</div></div>` : ''}
      <div><div class="det-lbl">Account</div><div class="det-val">${c.account_code ? `${esc(c.account_code)} ${esc(c.account_name)}` : '<span class="col-ink3">Not set</span>'}</div></div>
    </div>
    <div class="det-pane active">
      <div class="edt-section" style="padding:0">
        <div style="font-size:.97rem;padding:4px 0 10px">${esc(c.description)}</div>
        ${c.notes ? `<div class="col-ink2" style="font-size:.85rem">${esc(c.notes)}</div>` : ''}
        <div class="det-totals" style="margin-top:16px">
          <div class="det-tot-row"><span>Amount ex GST</span><span>${fmt(c.amount_ex_gst)}</span></div>
          ${c.gst_amount ? `<div class="det-tot-row"><span>GST (${c.tax_code})</span><span>${fmt(c.gst_amount)}</span></div>` : ''}
          <div class="det-tot-row grand"><span>Total</span><span>${fmt(c.total)}</span></div>
        </div>
        ${isPosted ? `<div style="margin-top:14px;font-size:.8rem;color:var(--ink3)">Journal EXP-${String(c.id).padStart(4,'0')} posted to GL.</div>` : ''}
      </div>
    </div>
    <div class="edt-divider"></div>
    <div class="edt-section">
      <div class="edt-lbl" style="margin-bottom:8px">📎 Attachments</div>
      <div id="exp-att-pane"></div>
    </div>`;

  setTimeout(() => _attLoad('exp-att-pane', 'expense_claim', c.id), 0);

  const foot = document.getElementById('det-foot');
  foot.innerHTML = '';
  const mk = (label, cls, fn) => {
    const b = document.createElement('button');
    b.className = `btn ${cls}`; b.textContent = label; b.onclick = fn;
    foot.appendChild(b);
  };
  if (isDraft) {
    mk('Edit', 'btn-primary', () => _expEdit(c.id));
    mk('Post to GL', 'btn-outline', () => _expPost(c.id));
    mk('Delete', 'btn-outline btn-danger-outline', () => _expDelete(c.id));
  }
  if (isPosted) {
    mk('Void', 'btn-outline', () => _expVoid(c.id));
  }
}

// ─── New / Edit form ──────────────────────────────────────────────────────────

async function _expNew() {
  await _expOpenForm(null);
}

async function _expEdit(id) {
  try {
    const c = await apiFetch(`/api/expense-claims/${id}`);
    await _expOpenForm(c);
  } catch(e) { toast(e.message, 'err'); }
}

async function _expOpenForm(c) {
  // Load expense accounts if not cached
  if (!_expAccts) {
    try {
      const all = await apiFetch('/api/accounts');
      _expAccts = (all || []).filter(a => a.account_type === 'Expense');
    } catch(e) { toast('Could not load accounts: ' + e.message, 'err'); return; }
  }

  const isNew    = !c;
  const today    = isoToday();
  const isMileage = c ? !!c.is_mileage : false;
  const cat      = c?.category || 'Other';

  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = isNew ? 'New Expense Claim' : 'Edit Expense Claim';

  const accOpts = (_expAccts || []).map(a =>
    `<option value="${a.id}" ${a.id === c?.account_id ? 'selected' : ''}>${esc((a.code ? a.code+' ' : '') + a.name)}</option>`
  ).join('');
  const catOpts = EXP_CATS.map(cat2 =>
    `<option ${cat2 === cat ? 'selected' : ''}>${cat2}</option>`
  ).join('');

  document.getElementById('det-body').innerHTML = `
    <div class="edt-section">
      <div class="edt-row">
        <div class="edt-field">
          <label class="edt-lbl">Date *</label>
          <input class="edt-inp" type="date" id="exp-date" value="${c?.claim_date || today}">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Category</label>
          <select class="edt-sel" id="exp-cat" onchange="_expCatChange()">${catOpts}</select>
        </div>
      </div>
      <div class="edt-row">
        <div class="edt-field full">
          <label class="edt-lbl">Description *</label>
          <input class="edt-inp" id="exp-desc" value="${esc(c?.description || '')}">
        </div>
      </div>
    </div>
    <div class="edt-divider"></div>
    <div class="edt-section" id="exp-amount-section">
      <div class="edt-row" id="exp-mileage-row" style="${isMileage ? '' : 'display:none'}">
        <div class="edt-field">
          <label class="edt-lbl">Kilometres</label>
          <input class="edt-inp" type="number" step="0.1" id="exp-km" value="${c?.km || ''}"
                 oninput="_expCalcMileage()">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Rate ($/km)</label>
          <input class="edt-inp" type="number" step="0.0001" id="exp-rate" value="${c?.km_rate || 0.88}"
                 oninput="_expCalcMileage()">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Amount</label>
          <input class="edt-inp" id="exp-mileage-amt" readonly style="background:var(--surface2)"
                 value="${c?.is_mileage ? fmt(c.total) : ''}">
        </div>
      </div>
      <div class="edt-row" id="exp-regular-row" style="${isMileage ? 'display:none' : ''}">
        <div class="edt-field">
          <label class="edt-lbl">Amount ex GST *</label>
          <input class="edt-inp" type="number" step="0.01" id="exp-amount" value="${c?.amount_ex_gst || ''}">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Tax</label>
          <select class="edt-sel" id="exp-tax">
            <option ${(c?.tax_code||'GST')==='GST'?'selected':''}>GST</option>
            <option ${c?.tax_code==='FRE'?'selected':''}>FRE</option>
          </select>
        </div>
      </div>
    </div>
    <div class="edt-divider"></div>
    <div class="edt-section">
      <div class="edt-row">
        <div class="edt-field full">
          <label class="edt-lbl">Expense Account *</label>
          <select class="edt-sel" id="exp-account">
            <option value="">— Select account —</option>${accOpts}
          </select>
        </div>
      </div>
      <div class="edt-row">
        <div class="edt-field full">
          <label class="edt-lbl">Notes (optional)</label>
          <textarea class="edt-ta" id="exp-notes">${esc(c?.notes || '')}</textarea>
        </div>
      </div>
    </div>`;

  document.getElementById('det-foot').innerHTML = '';
  const foot = document.getElementById('det-foot');
  const mk = (label, cls, fn) => {
    const b = document.createElement('button');
    b.className = `btn ${cls}`; b.textContent = label; b.onclick = fn;
    foot.appendChild(b);
  };
  mk('Save', 'btn-primary', () => _expSave(c?.id || null));
  mk('Cancel', 'btn-outline', () => {
    if (c?.id) _expOpen(c.id); else detClose();
  });

  // Trigger category-based visibility on load
  _expCatChange();
  setTimeout(() => document.getElementById('exp-desc')?.focus(), 50);
}

function _expCatChange() {
  const cat = document.getElementById('exp-cat')?.value;
  const isMil = cat === 'Mileage';
  const milRow = document.getElementById('exp-mileage-row');
  const regRow = document.getElementById('exp-regular-row');
  if (milRow) milRow.style.display = isMil ? '' : 'none';
  if (regRow) regRow.style.display = isMil ? 'none' : '';
  if (isMil) _expCalcMileage();
}

function _expCalcMileage() {
  const km   = parseFloat(document.getElementById('exp-km')?.value || 0) || 0;
  const rate = parseFloat(document.getElementById('exp-rate')?.value || 0.88) || 0.88;
  const amt  = Math.round(km * rate * 100) / 100;
  const el   = document.getElementById('exp-mileage-amt');
  if (el) el.value = fmt(amt);
}

async function _expSave(existingId) {
  const desc    = document.getElementById('exp-desc')?.value.trim();
  const cat     = document.getElementById('exp-cat')?.value || 'Other';
  const isMil   = cat === 'Mileage';
  const date    = document.getElementById('exp-date')?.value;
  const accId   = parseInt(document.getElementById('exp-account')?.value || 0) || null;

  if (!desc)  { toast('Description is required', 'err'); return; }
  if (!date)  { toast('Date is required', 'err'); return; }

  const payload = {
    claim_date:    date,
    description:   desc,
    category:      cat,
    is_mileage:    isMil ? 1 : 0,
    account_id:    accId,
    notes:         document.getElementById('exp-notes')?.value.trim() || '',
  };

  if (isMil) {
    payload.km      = parseFloat(document.getElementById('exp-km')?.value || 0) || 0;
    payload.km_rate = parseFloat(document.getElementById('exp-rate')?.value || 0.88) || 0.88;
  } else {
    payload.amount_ex_gst = parseFloat(document.getElementById('exp-amount')?.value || 0) || 0;
    payload.tax_code      = document.getElementById('exp-tax')?.value || 'GST';
  }

  try {
    if (existingId) {
      const r = await fetch(`/api/expense-claims/${existingId}`, {
        method: 'PUT', credentials: 'include',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload),
      });
      const j = await r.json(); if (!j.ok) throw new Error(j.error || 'Failed');
      toast('Claim saved');
    } else {
      const r = await fetch('/api/expense-claims', {
        method: 'POST', credentials: 'include',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload),
      });
      const j = await r.json(); if (!j.ok) throw new Error(j.error || 'Failed');
      existingId = j.data.id;
      toast('Claim created');
    }
    _expAll = await apiFetch('/api/expense-claims') || [];
    _expRender();
    _expOpen(existingId);
  } catch(e) { toast(e.message, 'err'); }
}

// ─── Post / Void / Delete ─────────────────────────────────────────────────────

async function _expPost(id) {
  const c = _expAll.find(x => x.id === id);
  if (!await confirmDlg(`Post this expense claim to the GL?\n\nThis will create a journal entry and cannot be easily undone.`)) return;
  try {
    const r = await fetch(`/api/expense-claims/${id}/post`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: '{}',
    });
    const j = await r.json(); if (!j.ok) throw new Error(j.error || 'Failed');
    toast('Claim posted to GL');
    _expAll = await apiFetch('/api/expense-claims') || [];
    _expRender();
    _expOpen(id);
  } catch(e) { toast(e.message, 'err'); }
}

async function _expVoid(id) {
  if (!await confirmDlg('Void this expense claim? The GL journal will be reversed and the claim returned to Draft.')) return;
  try {
    const r = await fetch(`/api/expense-claims/${id}/void`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: '{}',
    });
    const j = await r.json(); if (!j.ok) throw new Error(j.error || 'Failed');
    toast('Claim voided');
    _expAll = await apiFetch('/api/expense-claims') || [];
    _expRender();
    _expOpen(id);
  } catch(e) { toast(e.message, 'err'); }
}

async function _expDelete(id) {
  if (!await confirmDlg('Delete this claim? This cannot be undone.')) return;
  try {
    const r = await fetch(`/api/expense-claims/${id}`, {
      method: 'DELETE', credentials: 'include',
    });
    const j = await r.json(); if (!j.ok) throw new Error(j.error || 'Failed');
    toast('Claim deleted');
    _expAll = await apiFetch('/api/expense-claims') || [];
    detClose();
    _expRender();
  } catch(e) { toast(e.message, 'err'); }
}
