// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// web/static/js/bankrec.js — Bank Reconciliation module

// ── Module state ──────────────────────────────────────────────────────────────
let _brAccounts   = [];          // all reconcilable accounts
let _brAccId      = null;        // selected account id
let _brTxns       = [];          // full loaded transaction list
let _brFiltered   = [];          // after filter
let _brSortCol    = 'date';
let _brSortAsc    = true;
let _brShowRec    = false;
let _brShowRej    = false;
let _brOpening    = 0;
let _brSelected   = new Set();   // selected _iid strings
let _brAccOpts    = [];          // for allocation modal
let _brInvoices   = [];
let _brBills      = [];
let _brRules      = [];
let _brRuleEditId = null;
let _brCsvHeaders = [];
let _brCsvRows    = [];
let _brColMap     = {};          // field → col index
let _brSplitLines = [];          // accumulated lines in the categorise modal
let _brLastDiff   = 0;           // last computed diff (stmt − expected); used by finalise
let _brLastGlClose = 0;          // last computed GL closing; used by adjustment dialog
let _brPendingAdj = null;        // state for in-progress adjustment dialog

// ── Entry point ───────────────────────────────────────────────────────────────
async function pageBankRec() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = `
    <!-- Row 1: account picker + action buttons -->
    <div class="inv-toolbar">
      <select id="br-acc-sel" class="inv-search br-acc-sel"
              onchange="_brOnAccChange()"></select>
      <button class="btn btn-outline" onclick="_brLoad()">↺ Reload</button>
      <button class="btn btn-purple"  onclick="_brShowImportCsv()">⬆ Import CSV</button>
      <button class="btn btn-outline" onclick="_brShowRules()">📋 Rules</button>
      <button class="btn btn-outline" onclick="_brShowReport()">📄 Report</button>
      <button class="btn btn-outline" onclick="_brShowDateReportPrompt()">📅 Date Report</button>
      <button class="btn btn-outline" onclick="_brShowPastRecs()">📑 Past Recs</button>
    </div>

    <!-- Row 2: filter bar -->
    <div class="br-filter-row">
      <label>From</label>
      <input type="date" id="br-from" onchange="_brApplyFilter()">
      <label>To</label>
      <input type="date" id="br-to" onchange="_brApplyFilter()">
      <label>Search</label>
      <input type="text" id="br-search" class="br-search" placeholder="description, ref, amount…"
             oninput="_brApplyFilter()">
      <button class="btn btn-primary btn-sm" onclick="_brApplyFilter()">Filter</button>
      <button class="btn btn-outline btn-sm" onclick="_brClearFilter()">Clear</button>
      <label class="br-show-rec-lbl">
        <input type="checkbox" id="br-show-rec" onchange="_brToggleShowRec()"> Show reconciled
      </label>
      <label class="br-show-rec-lbl">
        <input type="checkbox" id="br-show-rej" onchange="_brToggleShowRej()"> Show rejected
      </label>
    </div>

    <!-- Row 3: reconciliation controls -->
    <div class="br-rec-bar">
      <span class="br-rec-lbl">Rec Date</span>
      <input type="date" id="br-rec-date">
      <span class="br-rec-lbl" id="br-lbl-opening">Opening</span>
      <input type="text" id="br-opening-val" class="br-opening-input" placeholder="0.00"
             oninput="_brUpdateDiff()" readonly>
      <span class="br-rec-lbl">Last Rec</span>
      <span id="br-last-rec-date" class="br-last-rec-date">—</span>
      <span class="br-rec-lbl" id="br-lbl-closing">Closing</span>
      <input type="text" id="br-closing" placeholder="0.00" oninput="_brUpdateDiff()">
      <span id="br-cc-status" class="br-cc-status" style="display:none"></span>
      <span class="br-rec-lbl">Difference</span>
      <span id="br-diff" class="br-diff-val">—</span>
      <button class="btn btn-success btn-sm" onclick="_brFinalise()">✓ Finalise</button>
    </div>

    <!-- Row 4: multi-select action toolbar -->
    <div class="br-action-bar">
      <div class="br-action-group">
        <button class="btn btn-danger  btn-sm" onclick="_brRejectSelected()">⊘ Reject Dup</button>
        <button class="btn btn-outline btn-sm" onclick="_brUnrejectSelected()">↩ Unreject</button>
      </div>
      <div class="br-action-group">
        <button class="btn btn-primary btn-sm" onclick="_brCategoriseSelected()">$ Categorise</button>
        <button class="btn btn-purple  btn-sm" onclick="_brSuggestMatches()">🔍 Suggest Matches</button>
        <button class="btn btn-success btn-sm" onclick="_brAutoRules()">⚙ Auto-Rules</button>
      </div>
      <div class="br-action-group">
        <button class="btn btn-outline btn-sm" onclick="_brSelectAll()">Select All</button>
        <button class="btn btn-outline btn-sm" onclick="_brSelectNone()">Select None</button>
        <span class="br-sel-count" id="br-sel-count"></span>
      </div>
    </div>

    <!-- Status bar -->
    <div class="br-status-bar">
      <span id="br-status-txt">Select an account to begin.</span>
      <span class="br-status-hint">Click to select · Double-click to allocate/toggle</span>
    </div>

    <!-- Transaction table -->
    <div class="inv-list-panel">
      <div class="tbl-overflow-x">
        <table class="inv-list-table" id="br-tbl">
          <thead><tr>
            <th class="br-th-chk">
              <input type="checkbox" id="br-chk-all" onchange="_brToggleAll(this)">
            </th>
            <th id="br-th-date"        onclick="_brSort('date')">Date</th>
            <th id="br-th-description" onclick="_brSort('description')">Description</th>
            <th id="br-th-reference"   onclick="_brSort('reference')">Reference</th>
            <th id="br-th-debit"       onclick="_brSort('debit')"   class="th-r">Debit</th>
            <th id="br-th-credit"      onclick="_brSort('credit')"  class="th-r">Credit</th>
            <th id="br-th-balance"     onclick="_brSort('balance')" class="th-r">Balance</th>
            <th id="br-th-source"      onclick="_brSort('source')"  class="th-c">Source</th>
            <th id="br-th-status"      onclick="_brSort('status')"  class="th-c">Status</th>
          </tr></thead>
          <tbody id="br-tbody"></tbody>
        </table>
      </div>
    </div>
    <div class="mt-8"><span class="count-pill" id="br-count-pill"></span></div>`;

  // Reset filter flags to match the freshly-built unchecked checkboxes
  _brShowRec = false;
  _brShowRej = false;

  // Set today's date in rec date field
  const today = new Date();
  const dd = String(today.getDate()).padStart(2,'0');
  const mm = String(today.getMonth()+1).padStart(2,'0');
  const yyyy = today.getFullYear();
  document.getElementById('br-rec-date').value = `${yyyy}-${mm}-${dd}`;

  await _brLoadAccounts();
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function _brIsLiability() {
  const a = _brAccounts.find(x => x.id === _brAccId);
  return a ? a.account_type === 'Liability' : false;
}

// ── Account loading ───────────────────────────────────────────────────────────
async function _brLoadAccounts() {
  _brAccounts = await apiFetch('/api/bankrec/accounts');
  const sel = document.getElementById('br-acc-sel');
  if (!sel) return;
  sel.innerHTML = _brAccounts.map(a =>
    `<option value="${a.id}">${a.code}  ${a.name}</option>`
  ).join('');
  if (_brAccounts.length) {
    _brAccId = _brAccounts[0].id;
    await _brLoad();
  }
}

function _brOnAccChange() {
  const sel = document.getElementById('br-acc-sel');
  if (!sel) return;
  _brAccId = parseInt(sel.value);
  _brLoad();
}

async function _brLoad() {
  if (!_brAccId) return;
  _brSelected.clear();
  document.getElementById('br-sel-count').textContent = '';

  const isLiab = _brIsLiability();
  const openLbl   = document.getElementById('br-lbl-opening');
  const closeLbl  = document.getElementById('br-lbl-closing');
  const closingEl = document.getElementById('br-closing');
  if (openLbl)  openLbl.textContent  = isLiab ? 'Opening (owed)' : 'Opening';
  if (closeLbl) closeLbl.textContent = isLiab ? 'Closing (owed)' : 'Closing';
  if (closingEl) closingEl.placeholder = isLiab ? '0.00  (enter as positive if owing)' : '0.00';

  try {
    const lastRec = await apiFetch(`/api/bankrec/${_brAccId}/last-reconciliation`);
    const openEl = document.getElementById('br-opening-val');
    if (openEl) {
      if (lastRec) {
        _brOpening = parseFloat(lastRec.closing_balance || 0);
        openEl.value = _brOpening.toFixed(2);
        openEl.readOnly = true;
        openEl.title = 'Locked — equals previous reconciliation closing balance';
        const lastRecLbl = document.getElementById('br-last-rec-date');
        if (lastRecLbl) lastRecLbl.textContent = _isoToAu(lastRec.reconcile_date);
      } else {
        _brOpening = 0;
        openEl.value = '';
        openEl.readOnly = false;
        openEl.title = 'No prior reconciliation — enter opening balance';
        const lastRecLbl = document.getElementById('br-last-rec-date');
        if (lastRecLbl) lastRecLbl.textContent = '—';
      }
    }

    _brTxns = await apiFetch(`/api/bankrec/${_brAccId}/transactions`);
  } catch(e) {
    _brToast('Load error: ' + e.message, true);
    return;
  }
  _brApplyFilter();
  _brUpdateDiff();
}

// ── Filtering ─────────────────────────────────────────────────────────────────
function _brApplyFilter() {
  const fromEl   = document.getElementById('br-from');
  const toEl     = document.getElementById('br-to');
  const searchEl = document.getElementById('br-search');
  const showRecCb = document.getElementById('br-show-rec');
  const showRejCb = document.getElementById('br-show-rej');

  // Always sync from DOM to avoid stale state after page rebuilds or reloads
  if (showRecCb) _brShowRec = showRecCb.checked;
  if (showRejCb) _brShowRej = showRejCb.checked;

  const fromVal  = fromEl  ? _auDateToIso(fromEl.value.trim())  : '';
  const toVal    = toEl    ? _auDateToIso(toEl.value.trim())    : '';
  const search   = searchEl ? searchEl.value.trim().toLowerCase() : '';

  _brFiltered = _brTxns.filter(t => {
    if (t.is_rejected && !_brShowRej) return false;
    if (!_brShowRec && t.is_reconciled) return false;
    const d = t.transaction_date || '';
    if (fromVal && d < fromVal) return false;
    if (toVal   && d > toVal)   return false;
    if (search) {
      const hay = [t.description||'', t.reference||'',
                   t.debit||'', t.credit||''].join(' ').toLowerCase();
      if (!hay.includes(search)) return false;
    }
    return true;
  });

  _brRenderTable();
  _brUpdateStatus();
}

function _brClearFilter() {
  const ids = ['br-from','br-to','br-search'];
  ids.forEach(id => { const el = document.getElementById(id); if (el) el.value=''; });
  _brApplyFilter();
}

function _brToggleShowRec() {
  const cb = document.getElementById('br-show-rec');
  _brShowRec = cb ? cb.checked : false;
  _brApplyFilter();
}

function _brToggleShowRej() {
  const cb = document.getElementById('br-show-rej');
  _brShowRej = cb ? cb.checked : false;
  _brApplyFilter();
}

// ── Sort ──────────────────────────────────────────────────────────────────────
function _brSort(col) {
  if (_brSortCol === col) {
    _brSortAsc = !_brSortAsc;
  } else {
    _brSortCol = col;
    _brSortAsc = true;
  }
  // Update sort indicators on th elements (inv-list-table style)
  const colThIds = {
    date:'br-th-date', description:'br-th-description', reference:'br-th-reference',
    debit:'br-th-debit', credit:'br-th-credit', balance:'br-th-balance',
    source:'br-th-source', status:'br-th-status'
  };
  Object.values(colThIds).forEach(id => {
    const th = document.getElementById(id);
    if (th) th.classList.remove('sort-asc','sort-desc');
  });
  const activeTh = document.getElementById(colThIds[col]);
  if (activeTh) activeTh.classList.add(_brSortAsc ? 'sort-asc' : 'sort-desc');
  _brRenderTable();
}

function _brSortedTxns() {
  const keyFns = {
    date:        t => t.transaction_date || '',
    description: t => (t.description||'').toLowerCase(),
    reference:   t => (t.reference||'').toLowerCase(),
    debit:       t => parseFloat(t.debit || 0),
    credit:      t => parseFloat(t.credit || 0),
    balance:     t => parseFloat(t.balance || 0),
    source:      t => t._source || '',
    status:      t => t.is_reconciled ? 1 : 0,
  };
  const fn = keyFns[_brSortCol] || (t => t.transaction_date);
  return [..._brFiltered].sort((a, b) => {
    const ka = fn(a), kb = fn(b);
    if (ka < kb) return _brSortAsc ? -1 : 1;
    if (ka > kb) return _brSortAsc ?  1 : -1;
    return 0;
  });
}

// ── Render table ──────────────────────────────────────────────────────────────
function _brRenderTable() {
  const tbody = document.getElementById('br-tbody');
  if (!tbody) return;
  const txns    = _brSortedTxns();
  const isLiab  = _brIsLiability();
  const thDebit  = document.getElementById('br-th-debit');
  const thCredit = document.getElementById('br-th-credit');
  if (thDebit)  thDebit.textContent  = isLiab ? 'Payments' : 'Debit';
  if (thCredit) thCredit.textContent = isLiab ? 'Charges'  : 'Credit';

  if (txns.length === 0) {
    tbody.innerHTML = _brTxns.length === 0
      ? `<tr><td colspan="9" style="padding:0"><div class="state-empty">
          <svg class="state-empty-icon" aria-hidden="true"><use href="#ic-landmark"/></svg>
          <div class="state-empty-title">No transactions loaded</div>
          <div class="state-empty-sub">Select a bank account and import a CSV statement to begin reconciling.</div>
        </div></td></tr>`
      : `<tr><td colspan="9" style="padding:0"><div class="state-empty">
          <svg class="state-empty-icon" aria-hidden="true"><use href="#ic-landmark"/></svg>
          <div class="state-empty-title">No transactions match your filter</div>
          <div class="state-empty-sub">Try adjusting the date range or search term.</div>
          <button class="btn btn-outline btn-sm" onclick="_brClearFilter()">Clear filters</button>
        </div></td></tr>`;
    return;
  }
  tbody.innerHTML = txns.map((t, i) => {
    const iid    = t._iid;
    const sel    = _brSelected.has(iid);
    // For bank (asset) CSV: bank credit = money in = GL debit → flip columns for display.
    // For CC (liability) CSV: stored credit = charge = GL credit → no flip needed.
    const rawD = parseFloat(t.debit || 0), rawC = parseFloat(t.credit || 0);
    const shouldFlip = t._source === 'csv' && !isLiab;
    const debit  = shouldFlip ? rawC : rawD;
    const credit = shouldFlip ? rawD : rawC;
    const bal    = t.balance != null ? parseFloat(t.balance) : null;

    let rowCls = '';
    if (t.is_rejected)    rowCls = 'br-row-rejected';
    else if (t.is_reconciled) rowCls = 'br-row-rec';
    else if (t._duplicate)    rowCls = 'br-row-dup';
    else if (i % 2)           rowCls = 'row-alt';

    const badge = _brStatusBadge(t);
    const srcCls = t._source === 'csv' ? 'br-src-csv' : 'br-src-journal';
    const srcLbl = t._source === 'csv' ? 'CSV' : 'JNL';

    return `<tr class="inv-row ${rowCls}${sel ? ' br-selected' : ''}" data-iid="${iid}"
              onclick="_brRowClick(event,'${iid}')"
              ondblclick="_brRowDblClick('${iid}')">
      <td class="br-td-chk" onclick="event.stopPropagation()">
        <input type="checkbox" ${sel?'checked':''} onchange="_brToggleRow(event,'${iid}')">
      </td>
      <td><span class="inv-mono">${_isoToAu(t.transaction_date||'')}</span></td>
      <td>${esc(t.description||'')}</td>
      <td><span class="inv-mono">${esc(t.reference||'')}</span></td>
      <td class="inv-amt">${debit  ? _fmtAmt(debit)  : '—'}</td>
      <td class="inv-amt">${credit ? _fmtAmt(credit) : '—'}</td>
      <td class="inv-amt">${bal != null ? _fmtAmt(bal) : ''}</td>
      <td class="col-c"><span class="${srcCls}">${srcLbl}</span></td>
      <td class="col-c">${badge}</td>
    </tr>`;
  }).join('');
}

function _brStatusBadge(t) {
  if (t.is_rejected) return `<span class="br-badge br-badge-rej">Rejected</span>`;
  if (t.is_reconciled && t._source === 'journal')
    return `<span class="br-badge br-badge-rec">✓ Rec'd</span>`;
  if (t.is_reconciled) {
    const lbl = {account:'GL Acct',invoice:'Invoice',bill:'Bill',contact:'Contact',split:'Split'}[t.alloc_mode] || "Rec'd";
    return `<span class="br-badge br-badge-rec">✓ ${lbl}</span>`;
  }
  if (t._source === 'csv' && t.journal_id) {
    const lbl = {account:'GL Acct',invoice:'Invoice',bill:'Bill',contact:'Contact',split:'Split'}[t.alloc_mode] || 'Done';
    return `<span class="br-badge br-badge-alloc">📋 ${lbl}</span>`;
  }
  if (t._duplicate) return `<span class="br-badge br-badge-dup">⚠ Dup?</span>`;
  return '';
}

// ── Selection ─────────────────────────────────────────────────────────────────
function _brRowClick(e, iid) {
  if (e.ctrlKey || e.metaKey) {
    _brSelected.has(iid) ? _brSelected.delete(iid) : _brSelected.add(iid);
  } else {
    _brSelected.clear();
    _brSelected.add(iid);
  }
  _brRenderTable();
  _brUpdateSelCount();
}

function _brToggleRow(e, iid) {
  e.target.checked ? _brSelected.add(iid) : _brSelected.delete(iid);
  _brRenderTable();
  _brUpdateSelCount();
}

function _brSelectAll() {
  _brFiltered.forEach(t => _brSelected.add(t._iid));
  _brRenderTable();
  _brUpdateSelCount();
}

function _brSelectNone() {
  _brSelected.clear();
  _brRenderTable();
  _brUpdateSelCount();
}

function _brToggleAll(chk) {
  chk.checked ? _brSelectAll() : _brSelectNone();
}

function _brUpdateSelCount() {
  const el = document.getElementById('br-sel-count');
  if (el) el.textContent = _brSelected.size ? `${_brSelected.size} selected` : '';
  _brUpdateDiff();
}

function _brParseIids() {
  return [..._brSelected].map(iid => {
    const [src, rid] = iid.split(':');
    return { source: src, id: parseInt(rid), iid };
  });
}

// ── Double-click ──────────────────────────────────────────────────────────────
async function _brRowDblClick(iid) {
  const [src, ridStr] = iid.split(':');
  const rid = parseInt(ridStr);
  if (src === 'journal') {
    // Toggle reconciled
    const txn = _brTxns.find(t => t._iid === iid);
    if (!txn) return;
    const reconcile = !txn.is_reconciled;
    await fetch('/api/bankrec/reconcile', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ items:[{source:'journal', id: rid}], reconcile, rec_date: document.getElementById('br-rec-date')?.value || null })
    });
    _brLoad();
  } else {
    // Open allocation dialog
    const txn = _brTxns.find(t => t._iid === iid);
    if (!txn) return;
    _brShowAllocModal(txn);
  }
}

// ── Multi-select actions ──────────────────────────────────────────────────────
async function _brRejectSelected() {
  const items = _brParseIids();
  if (!items.length) { _brToast('Select rows first.'); return; }
  if (!confirm(`Mark ${items.length} transaction(s) as rejected duplicates?\n\nRejected rows are hidden from the reconciliation list. They are NOT deleted from the ledger.`)) return;
  const r = await fetch('/api/bankrec/reject', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ items: items.map(i=>({source:i.source,id:i.id})) })
  });
  const d = await r.json();
  if (!d.ok) { _brToast('Error: ' + d.error, true); return; }
  await _brLoad();
}

async function _brUnrejectSelected() {
  const items = _brParseIids();
  if (!items.length) { _brToast('Select rows first.'); return; }
  const r = await fetch('/api/bankrec/unreject', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ items: items.map(i=>({source:i.source,id:i.id})) })
  });
  const d = await r.json();
  if (!d.ok) { _brToast('Error: ' + d.error, true); return; }
  await _brLoad();
}

async function _brCategoriseSelected() {
  const csvItems = _brParseIids().filter(i => i.source === 'csv');
  if (!csvItems.length) {
    _brToast('Select one or more imported (CSV) rows to categorise. Journal rows are already posted to the ledger.');
    return;
  }
  const txns = csvItems.map(i => _brTxns.find(t => t._iid === i.iid)).filter(Boolean);
  const unalloc = txns.filter(t => !t.journal_id);
  const alloc   = txns.filter(t =>  t.journal_id);

  if (!unalloc.length && alloc.length) {
    if (!confirm(`All ${alloc.length} selected row(s) are already categorised.\n\nOpen for editing?`)) return;
    _brAllocQueue(alloc, 0);
    return;
  }
  _brAllocQueue(unalloc, 0, alloc.length);
}

function _brAllocQueue(queue, idx, skipped = 0) {
  if (idx >= queue.length) {
    const msg = `Categorisation complete.\n\n${idx} transaction(s) categorised.`
      + (skipped ? `\n${skipped} already-categorised row(s) were skipped.` : '');
    _brToast(msg);
    _brLoad();
    return;
  }
  _brShowAllocModal(queue[idx], () => _brAllocQueue(queue, idx + 1, skipped));
}

async function _brAutoRules() {
  const candidates = _brTxns.filter(t =>
    t._source === 'csv' && !t.is_reconciled && !t.is_rejected && !t.alloc_mode);
  if (!candidates.length) { _brToast('No unallocated transactions to categorise.'); return; }
  const r = await fetch('/api/bankrec/apply-rules', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ transactions: candidates })
  });
  const d = await r.json();
  if (!d.ok) { _brToast('Error: ' + d.error, true); return; }
  const {applied, errors} = d.data;
  let msg = `Applied ${applied} rule match${applied !== 1 ? 'es':''}`;
  if (errors && errors.length) msg += `\n${errors.length} error(s)`;
  if (!applied) msg = 'No rules matched any transactions.\nUse Rules to create categorisation rules.';
  _brToast(msg);
  await _brLoad();
}

// ── Suggest Matches ───────────────────────────────────────────────────────────
async function _brSuggestMatches() {
  const candidates = _brTxns.filter(t =>
    t._source === 'csv' && !t.is_reconciled && !t.is_rejected && !t.alloc_mode);
  if (!candidates.length) { _brToast('No unallocated CSV transactions to match.'); return; }

  // Load open invoices + bills
  const [rawInv, rawBil] = await Promise.all([
    apiFetch('/api/invoices'),
    apiFetch('/api/bills'),
  ]);
  const openInv = rawInv
    .filter(i => ['Sent','Partial'].includes(i.status))
    .map(i => ({...i, _balance: parseFloat(i.total||0) - parseFloat(i.amount_paid||0),
                _type:'invoice', _date: i.invoice_date||'',
                _ref: ((i.invoice_number||'')+' '+(i.contact_name||'')).toLowerCase()}))
    .filter(i => i._balance > 0.005);
  const openBil = rawBil
    .filter(b => ['Approved','Partial'].includes(b.status))
    .map(b => ({...b, _balance: parseFloat(b.total||0) - parseFloat(b.amount_paid||0),
                _type:'bill', _date: b.bill_date||b.due_date||'',
                _ref: ((b.bill_number||'')+' '+(b.contact_name||'')).toLowerCase()}))
    .filter(b => b._balance > 0.005);

  function daysDiff(d1, d2) {
    try {
      return Math.abs((new Date(d1) - new Date(d2)) / 86400000);
    } catch { return 999; }
  }

  function score(txn, rec) {
    const amount = parseFloat(txn.credit || txn.debit || 0);
    if (Math.abs(rec._balance - amount) > 0.02) return 0;
    const days = daysDiff(txn.transaction_date||'', rec._date);
    if (days > 30) return 0;
    let s = 60;
    if (days === 0)       s += 30;
    else if (days <= 3)   s += 20;
    else if (days <= 7)   s += 10;
    else if (days <= 14)  s += 5;
    const narr = (txn.description||'').toLowerCase();
    const words = rec._ref.split(' ').filter(w => w.length > 2);
    const matched = words.filter(w => narr.includes(w)).length;
    if (matched) s += Math.min(10, matched * 4);
    return Math.min(s, 100);
  }

  const CONF_AUTO = 85;
  const CONF_SHOW = 50;
  let autoMatched = 0;
  const ambiguous = [];

  for (const txn of candidates) {
    const credit = parseFloat(txn.credit||0);
    const debit  = parseFloat(txn.debit||0);
    const pool   = credit > 0 ? openInv : openBil;
    const mode   = credit > 0 ? 'invoice' : 'bill';

    const scored = pool
      .map(rec => ({ s: score(txn, rec), rec, mode }))
      .filter(x => x.s >= CONF_SHOW)
      .sort((a, b) => b.s - a.s);

    if (!scored.length) continue;

    if (scored[0].s >= CONF_AUTO && (scored.length === 1 || scored[0].s - scored[1].s >= 20)) {
      const {rec, mode: m} = scored[0];
      try {
        await fetch('/api/bankrec/allocate', {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify({
            bank_txn_id: txn.id, mode: m,
            alloc_data: {
              [m === 'invoice' ? 'invoice_id' : 'bill_id']: rec.id,
              amount: credit || debit,
              contact_id: rec.contact_id || null,
            }
          })
        });
        autoMatched++;
      } catch { /* skip */ }
    } else {
      ambiguous.push({ txn, scored });
    }
  }

  await _brLoad();

  if (ambiguous.length) {
    _brShowMatchDialog(ambiguous, 0, autoMatched);
  } else {
    const parts = [];
    if (autoMatched) parts.push(`✓ Auto-matched: ${autoMatched} transaction(s)`);
    if (!parts.length) parts.push('No confident matches found.');
    _brToast(parts.join('\n'));
  }
}

function _brShowMatchDialog(queue, idx, autoMatched) {
  if (idx >= queue.length) {
    _brToast(`Auto-matched: ${autoMatched} | Reviewed: ${idx}`);
    _brLoad();
    return;
  }
  const {txn, scored} = queue[idx];
  const credit  = parseFloat(txn.credit||0);
  const debit   = parseFloat(txn.debit||0);
  const amount  = credit || debit;
  const isLiabM = _brIsLiability();
  const dir     = isLiabM
    ? (credit ? 'Charge (card expense)' : 'Payment to card')
    : (credit ? 'Credit (money in)'     : 'Debit (money out)');

  const candidateRows = scored.map((c, i) => {
    const rec = c.rec;
    const num = rec.invoice_number || rec.bill_number || `#${rec.id}`;
    const scoreCls = c.s >= 85 ? 'br-match-score-high' : 'br-match-score-mid';
    return `<div class="br-match-cand-row${i===0?' selected':''}" data-idx="${i}"
                 onclick="_brMatchSelectRow(this)">
      <span class="${scoreCls}">${c.s}%</span>
      <span class="br-match-mode-lbl">${c.mode.charAt(0).toUpperCase()+c.mode.slice(1)}</span>
      <span class="br-alloc-open-num">${esc(num)}</span>
      <span class="br-alloc-open-name">${esc(rec.contact_name||'—')}</span>
      <span class="br-alloc-open-bal">$${amount.toFixed(2)}</span>
      <span class="br-alloc-open-due">${_isoToAu(rec._date||'')}</span>
    </div>`;
  }).join('');

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box modal-700 modal-tall">
    <div class="modal-hdr">
      <span>Review Ambiguous Matches — ${idx+1} of ${queue.length}</span>
    </div>
    <div class="modal-body modal-body-scroll">
      <p class="br-match-progress">Auto-matched: ${autoMatched} | Remaining: ${queue.length - idx}</p>
      <div class="br-match-txn-card">
        <div class="br-alloc-txn-amt">${dir} — ${_fmtAmt(amount)}</div>
        <div class="br-alloc-txn-meta">${_isoToAu(txn.transaction_date||'')} · ${esc(txn.description||'—')}</div>
      </div>
      <p class="br-match-hint">Select the correct match:</p>
      <div class="br-match-cand-list">${candidateRows}</div>
    </div>
    <div class="modal-foot modal-foot-sb">
      <button class="btn btn-danger btn-sm" onclick="_brMatchClose('${bd.id}')">✗ Done / Close</button>
      <div class="br-match-btns">
        <button class="btn btn-sm" onclick="_brMatchSkip()">⟶ Skip</button>
        <button class="btn btn-success btn-sm" onclick="_brMatchAllocate()">✓ Allocate Selected</button>
      </div>
    </div>
    </div>`;

  const mid = 'br-match-bd-' + Date.now();
  bd.id = mid;
  document.body.appendChild(bd);

  // Stash context for handlers
  bd._queue      = queue;
  bd._idx        = idx;
  bd._autoMatched= autoMatched;
}

function _brMatchSelectRow(el) {
  el.closest('.br-match-cand-list').querySelectorAll('.br-match-cand-row')
    .forEach(r => r.classList.remove('selected'));
  el.classList.add('selected');
}

async function _brMatchAllocate() {
  const bd = document.querySelector('.modal-bd[id^="br-match-bd-"]');
  if (!bd) return;
  const selRow = bd.querySelector('.br-match-cand-row.selected');
  if (!selRow) { _brToast('Select a match first.'); return; }
  const {txn, scored} = bd._queue[bd._idx];
  const cidx = parseInt(selRow.dataset.idx);
  const {rec, mode} = scored[cidx];
  const credit = parseFloat(txn.credit||0);
  const debit  = parseFloat(txn.debit||0);

  const r = await fetch('/api/bankrec/allocate', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({
      bank_txn_id: txn.id, mode,
      alloc_data: {
        [mode === 'invoice' ? 'invoice_id' : 'bill_id']: rec.id,
        amount: credit || debit,
        contact_id: rec.contact_id || null,
      }
    })
  });
  const d = await r.json();
  if (!d.ok) { _brToast('Error: ' + d.error, true); return; }

  const nextAuto = bd._autoMatched + 1;
  bd.remove();
  _brLoad();
  _brShowMatchDialog(bd._queue, bd._idx + 1, nextAuto);
}

function _brMatchSkip() {
  const bd = document.querySelector('.modal-bd[id^="br-match-bd-"]');
  if (!bd) return;
  const next = bd._idx + 1;
  const auto = bd._autoMatched;
  const queue = bd._queue;
  bd.remove();
  _brShowMatchDialog(queue, next, auto);
}

function _brMatchClose(id) {
  const bd = document.getElementById(id);
  if (bd) bd.remove();
  _brLoad();
}

async function _brNewContact() {
  const c = await quickNewContact('Both');
  if (!c) return;
  const sel = document.getElementById('br-gl-contact');
  if (sel) sel.appendChild(new Option(c.name, c.id, true, true));
}

// ── Allocation modal (supports single and split/multi-line) ───────────────────
async function _brShowAllocModal(txn, onDone) {
  _brSplitLines = [];

  const [accs, invs, bills, contacts] = await Promise.all([
    apiFetch('/api/accounts'),
    apiFetch('/api/invoices'),
    apiFetch('/api/bills'),
    apiFetch('/api/contacts'),
  ]);

  const debit    = parseFloat(txn.debit  || 0);
  const credit   = parseFloat(txn.credit || 0);
  const amount   = credit || debit;
  const isCredit = credit > 0;
  const isLiab   = _brIsLiability();
  // CC: a GL credit = charge (money out); a GL debit = payment to card.
  // For tab defaults: CC charges default to Bill; CC payments default to GL Account.
  // Bank: credit = money in → Invoice; debit = money out → Bill.
  const defaultInvTab = isLiab ? false : isCredit;
  const txnDirLabel   = isLiab
    ? (isCredit ? 'Charge (card expense)' : 'Payment to card')
    : (isCredit ? 'Credit (money in)'     : 'Debit (money out)');

  const openInv = invs.filter(i => ['Sent','Partial','Approved','Overdue'].includes(i.status) &&
    (parseFloat(i.total||0) - parseFloat(i.amount_paid||0)) > 0.005);
  const openBil = bills.filter(b => ['Approved','Partial','Overdue'].includes(b.status) &&
    (parseFloat(b.total||0) - parseFloat(b.amount_paid||0)) > 0.005);

  const taxCodes = ['N-T','GST','FRE','INP'];
  const accOpts  = accs.map(a => `<option value="${a.id}">${a.code}  ${a.name}</option>`).join('');
  const contOpts = `<option value="">— none —</option>` +
    contacts.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('');

  const invRows = openInv.map(i => {
    const bal = parseFloat(i.total||0) - parseFloat(i.amount_paid||0);
    return `<div class="br-alloc-open-row" data-id="${i.id}" data-contact="${i.contact_id||''}"
                 data-balance="${bal.toFixed(2)}" onclick="_brAllocPickInv(this)">
      <span class="br-alloc-open-num">${esc(i.invoice_number||'#'+i.id)}</span>
      <span class="br-alloc-open-name">${esc(i.contact_name||'—')}</span>
      <span class="br-alloc-open-bal">${_fmtAmt(bal)}</span>
      <span class="br-alloc-open-due">${_isoToAu(i.due_date||'')}</span>
    </div>`;
  }).join('') || '<div class="br-match-no-txns">No open invoices</div>';

  const bilRows = openBil.map(b => {
    const bal = parseFloat(b.total||0) - parseFloat(b.amount_paid||0);
    return `<div class="br-alloc-open-row" data-id="${b.id}" data-contact="${b.contact_id||''}"
                 data-balance="${bal.toFixed(2)}" onclick="_brAllocPickBil(this)">
      <span class="br-alloc-open-num">${esc(b.bill_number||'#'+b.id)}</span>
      <span class="br-alloc-open-name">${esc(b.contact_name||'—')}</span>
      <span class="br-alloc-open-bal">${_fmtAmt(bal)}</span>
      <span class="br-alloc-open-due">${_isoToAu(b.due_date||'')}</span>
    </div>`;
  }).join('') || '<div class="br-match-no-txns">No open bills</div>';

  const isAlloc  = !!txn.journal_id;
  const deallocBtn = isAlloc
    ? `<span class="br-dealloc-btn" onclick="_brDeallocate(${txn.id})">Remove categorisation</span>` : '';

  document.getElementById('br-alloc-bd')?.remove();

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.id = 'br-alloc-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box modal-md modal-tall">
    <div class="modal-hdr">
      <span>Categorise Transaction</span>
      <span class="br-rcpt-ref">${_isoToAu(txn.transaction_date||'')} · ${esc(txn.description||'')}</span>
      ${deallocBtn}
    </div>
    <div class="modal-body br-rcpt-body">
      <div class="br-alloc-txn-card">
        <div class="br-alloc-txn-amt">${txnDirLabel} — ${_fmtAmt(amount)}</div>
        <div class="br-alloc-txn-meta">${esc(txn.reference||'—')}</div>
      </div>

      <!-- Accumulated split lines -->
      <div class="br-split-section">
        <div class="br-split-hdr">
          <span>Lines</span>
          <span id="br-split-remaining" class="br-split-remaining br-split-bad">Remaining: ${_fmtAmt(amount)}</span>
        </div>
        <div id="br-split-lines" class="br-split-lines">
          <div class="br-split-empty">Add lines below to categorise this transaction.</div>
        </div>
      </div>

      <!-- Add-line area -->
      <div class="br-split-add">
        <div class="br-alloc-tabs">
          <div class="br-alloc-tab${defaultInvTab?' active':''}" id="br-tab-inv" onclick="_brAllocTab('inv')">Invoice</div>
          <div class="br-alloc-tab${!defaultInvTab?' active':''}" id="br-tab-bil" onclick="_brAllocTab('bil')">Bill</div>
          <div class="br-alloc-tab" id="br-tab-acc" onclick="_brAllocTab('acc')">GL Account</div>
        </div>
        <div class="br-alloc-panel${defaultInvTab?' active':''}" id="br-panel-inv">
          <div class="br-alloc-open-list">${invRows}</div>
          <input type="hidden" id="br-inv-id">
        </div>
        <div class="br-alloc-panel${!defaultInvTab?' active':''}" id="br-panel-bil">
          <div class="br-alloc-open-list">${bilRows}</div>
          <input type="hidden" id="br-bil-id">
        </div>
        <div class="br-alloc-panel" id="br-panel-acc">
          <div class="br-alloc-field">
            <label>Preset</label>
            <div style="display:flex;gap:5px;align-items:center">
              <select id="br-gl-preset" style="flex:1" onchange="_brApplyAllocPreset(this.value)">
                ${_brAllocPresetOpts()}
              </select>
              <button class="btn btn-sm btn-outline" onclick="_brSaveAllocPreset()" title="Save current fields as a preset">Save</button>
              <button class="btn btn-sm" id="br-gl-preset-del"
                      onclick="_brDeleteAllocPreset()" title="Delete preset"
                      style="color:var(--red);display:none">✕</button>
            </div>
          </div>
          <div class="br-alloc-field"><label>Account *</label>
            <select id="br-gl-acc">${accOpts}</select></div>
          <div class="br-alloc-field"><label>Tax Code</label>
            <select id="br-gl-tax">${taxCodes.map(c=>`<option ${c==='N-T'?'selected':''}>${c}</option>`).join('')}</select></div>
          <div class="br-alloc-field">
            <div class="lbl-line"><label>Contact (optional)</label>
              <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();_brNewContact()">+ New</a>
            </div>
            <select id="br-gl-contact">${contOpts}</select></div>
          <div class="br-alloc-field"><label>Description</label>
            <input type="text" id="br-gl-desc" value="${esc(txn.description||'')}"></div>
        </div>
        <div class="br-split-amt-row">
          <label>Amount</label>
          <input type="number" id="br-alloc-amt" min="0.01" step="0.01" value="${amount.toFixed(2)}">
          <button class="btn btn-primary btn-sm" onclick="_brSplitAddLine(${txn.id})">+ Add</button>
        </div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-sm btn-success" id="br-split-save"
              data-txn-id="${txn.id}"
              onclick="_brAllocSave(${txn.id})" disabled>✓ Categorise</button>
    </div>
    </div>`;

  document.body.appendChild(bd);
  bd._onDone = onDone;
}

function _brAllocTab(tab) {
  ['inv','bil','acc'].forEach(t => {
    document.getElementById(`br-tab-${t}`)?.classList.toggle('active', t === tab);
    document.getElementById(`br-panel-${t}`)?.classList.toggle('active', t === tab);
  });
  if (tab === 'acc') {
    const txnId = parseInt(document.getElementById('br-split-save')?.dataset.txnId);
    const txn = _brTxns.find(t => t._source === 'csv' && t.id === txnId);
    if (txn) {
      const total = parseFloat(txn.credit||0) || parseFloat(txn.debit||0);
      const allocated = _brSplitLines.reduce((s, l) => s + l.amount, 0);
      const remaining = Math.round((total - allocated) * 100) / 100;
      const amtEl = document.getElementById('br-alloc-amt');
      if (amtEl) amtEl.value = remaining.toFixed(2);
    }
  }
}

function _brAllocPickInv(el) {
  el.closest('.br-alloc-open-list').querySelectorAll('.br-alloc-open-row')
    .forEach(r => r.classList.remove('selected'));
  el.classList.add('selected');
  document.getElementById('br-inv-id').value = el.dataset.id;
  _brAutoFillAmt(parseFloat(el.dataset.balance || 0));
}

function _brAllocPickBil(el) {
  el.closest('.br-alloc-open-list').querySelectorAll('.br-alloc-open-row')
    .forEach(r => r.classList.remove('selected'));
  el.classList.add('selected');
  document.getElementById('br-bil-id').value = el.dataset.id;
  _brAutoFillAmt(parseFloat(el.dataset.balance || 0));
}

function _brAutoFillAmt(itemBalance) {
  const txnId = parseInt(document.getElementById('br-split-save')?.dataset.txnId);
  const txn = _brTxns.find(t => t._source === 'csv' && t.id === txnId);
  if (!txn) return;
  const total = parseFloat(txn.credit||0) || parseFloat(txn.debit||0);
  const allocated = _brSplitLines.reduce((s, l) => s + l.amount, 0);
  const remaining = Math.round((total - allocated) * 100) / 100;
  const amtEl = document.getElementById('br-alloc-amt');
  if (amtEl) amtEl.value = Math.min(itemBalance, remaining).toFixed(2);
}

function _brRenderSplitLines(txn) {
  const total     = parseFloat(txn.credit||0) || parseFloat(txn.debit||0);
  const allocated = _brSplitLines.reduce((s, l) => s + l.amount, 0);
  const remaining = Math.round((total - allocated) * 100) / 100;
  const balanced  = Math.abs(remaining) < 0.005;

  const linesEl = document.getElementById('br-split-lines');
  if (linesEl) {
    linesEl.innerHTML = _brSplitLines.length
      ? _brSplitLines.map((l, i) => `
          <div class="br-split-line">
            <button class="br-split-remove" onclick="_brSplitRemove(${i})" title="Remove">&times;</button>
            <span class="br-split-mode">${esc(l.modeLabel)}</span>
            <span class="br-split-label">${esc(l.label)}</span>
            <span class="br-split-amt">${_fmtAmt(l.amount)}</span>
          </div>`).join('')
      : '<div class="br-split-empty">Add lines below to categorise this transaction.</div>';
  }

  const remEl = document.getElementById('br-split-remaining');
  if (remEl) {
    remEl.textContent = balanced ? 'Fully allocated ✓' : `Remaining: ${_fmtAmt(remaining)}`;
    remEl.className   = 'br-split-remaining ' + (balanced ? 'br-split-ok' : 'br-split-bad');
  }

  const saveBtn = document.getElementById('br-split-save');
  if (saveBtn) {
    saveBtn.disabled    = !_brSplitLines.length || !balanced;
    const n             = _brSplitLines.length;
    saveBtn.textContent = n > 1 ? `✓ Save (${n} lines)` : '✓ Categorise';
  }

  const amtEl = document.getElementById('br-alloc-amt');
  if (amtEl && remaining > 0.005) amtEl.value = remaining.toFixed(2);
}

function _brSplitRemove(idx) {
  _brSplitLines.splice(idx, 1);
  const txnId = parseInt(document.getElementById('br-split-save')?.dataset.txnId);
  const txn   = _brTxns.find(t => t._source === 'csv' && t.id === txnId);
  if (txn) _brRenderSplitLines(txn);
}

function _brSplitAddLine(bankTxnId) {
  const txn = _brTxns.find(t => t._source === 'csv' && t.id === bankTxnId);
  if (!txn) return;
  const total     = parseFloat(txn.credit||0) || parseFloat(txn.debit||0);
  const allocated = _brSplitLines.reduce((s, l) => s + l.amount, 0);
  const remaining = Math.round((total - allocated) * 100) / 100;

  const amtEl = document.getElementById('br-alloc-amt');
  const amount = Math.round(parseFloat(amtEl?.value || 0) * 100) / 100;
  if (!amount || amount <= 0) { _brToast('Enter a valid amount.', true); return; }
  if (amount > remaining + 0.005) {
    _brToast(`Amount exceeds remaining balance (${_fmtAmt(remaining)}).`, true); return;
  }

  const activeTab = document.querySelector('.br-alloc-tab.active')?.id?.replace('br-tab-','');
  let line;

  if (activeTab === 'inv') {
    const invId = parseInt(document.getElementById('br-inv-id')?.value);
    if (!invId) { _brToast('Select an invoice first.'); return; }
    const row  = document.querySelector('#br-panel-inv .br-alloc-open-row.selected');
    const num  = row?.querySelector('.br-alloc-open-num')?.textContent || `#${invId}`;
    const name = row?.querySelector('.br-alloc-open-name')?.textContent || '';
    line = { mode:'invoice', invoice_id:invId, amount,
             contact_id: row ? parseInt(row.dataset.contact)||null : null,
             label:`${num} · ${name}`, modeLabel:'Invoice' };
    document.querySelectorAll('#br-panel-inv .br-alloc-open-row').forEach(r => r.classList.remove('selected'));
    document.getElementById('br-inv-id').value = '';

  } else if (activeTab === 'bil') {
    const bilId = parseInt(document.getElementById('br-bil-id')?.value);
    if (!bilId) { _brToast('Select a bill first.'); return; }
    const row  = document.querySelector('#br-panel-bil .br-alloc-open-row.selected');
    const num  = row?.querySelector('.br-alloc-open-num')?.textContent || `#${bilId}`;
    const name = row?.querySelector('.br-alloc-open-name')?.textContent || '';
    line = { mode:'bill', bill_id:bilId, amount,
             contact_id: row ? parseInt(row.dataset.contact)||null : null,
             label:`${num} · ${name}`, modeLabel:'Bill' };
    document.querySelectorAll('#br-panel-bil .br-alloc-open-row').forEach(r => r.classList.remove('selected'));
    document.getElementById('br-bil-id').value = '';

  } else {
    const accEl  = document.getElementById('br-gl-acc');
    const accId  = parseInt(accEl?.value);
    if (!accId) { _brToast('Select a GL account.'); return; }
    if (accId === _brAccId) { _brToast('Cannot allocate to the account being reconciled.', true); return; }
    const accText   = accEl?.options[accEl.selectedIndex]?.text || '';
    const taxCode   = document.getElementById('br-gl-tax')?.value || 'N-T';
    const desc      = document.getElementById('br-gl-desc')?.value || '';
    const contactId = parseInt(document.getElementById('br-gl-contact')?.value)||null;
    line = { mode:'account', account_id:accId, tax_code:taxCode,
             contact_id:contactId, description:desc, amount,
             label:accText, modeLabel:'GL Acct' };
  }

  _brSplitLines.push(line);
  _brRenderSplitLines(txn);
}

async function _brAllocSave(bankTxnId) {
  if (!_brSplitLines.length) { _brToast('Add at least one line.', true); return; }
  const txn   = _brTxns.find(t => t._source === 'csv' && t.id === bankTxnId);
  const total = parseFloat(txn?.credit||0) || parseFloat(txn?.debit||0);
  const allocated = _brSplitLines.reduce((s, l) => s + l.amount, 0);
  if (Math.abs(total - allocated) > 0.02) {
    _brToast('Lines must sum to the transaction total.', true); return;
  }

  let r;
  if (_brSplitLines.length === 1) {
    const line     = _brSplitLines[0];
    const allocData = { ...line };
    delete allocData.modeLabel; delete allocData.label; delete allocData.mode;
    r = await fetch('/api/bankrec/allocate', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ bank_txn_id: bankTxnId, mode: line.mode, alloc_data: allocData })
    });
  } else {
    r = await fetch('/api/bankrec/allocate-multi', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ bank_txn_id: bankTxnId, lines: _brSplitLines })
    });
  }
  const d = await r.json();
  if (!d.ok) { _brToast('Error: ' + d.error, true); return; }

  const bd   = document.getElementById('br-alloc-bd');
  const onDone = bd?._onDone;
  bd?.remove();
  await _brLoad();
  if (onDone) onDone();
}

async function _brDeallocate(bankTxnId) {
  if (!confirm('Remove categorisation from this transaction?\n\nThe journal entry will be reversed.')) return;
  const r = await fetch('/api/bankrec/deallocate', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ bank_txn_id: bankTxnId })
  });
  const d = await r.json();
  if (!d.ok) { _brToast('Error: ' + d.error, true); return; }
  document.getElementById('br-alloc-bd')?.remove();
  await _brLoad();
}

// ── Finalise ──────────────────────────────────────────────────────────────────
async function _brFinalise() {
  if (!_brAccId) { _brToast('Select an account first.'); return; }
  const recDateRaw = document.getElementById('br-rec-date')?.value?.trim();
  const closingRaw = document.getElementById('br-closing')?.value?.trim();
  const openingRaw = document.getElementById('br-opening-val')?.value?.trim();
  if (!recDateRaw) { _brToast('Enter a reconciliation date.'); return; }
  const closing = parseFloat(closingRaw);
  if (isNaN(closing)) { _brToast('Enter a valid closing balance.'); return; }
  const opening = parseFloat(openingRaw || 0);
  if (isNaN(opening)) { _brToast('Enter a valid opening balance.'); return; }
  _brOpening = opening;
  const recDate = _auDateToIso(recDateRaw) || recDateRaw;

  const unallocN = _brTxns.filter(t =>
    t._source === 'csv' && !t.journal_id && !t.is_reconciled && !t.is_rejected
  ).length;
  if (unallocN > 0) {
    alert(
      `⚠ ${unallocN} unallocated CSV transaction${unallocN !== 1 ? 's' : ''} must be processed before finalising.\n\n` +
      `For each one, either:\n` +
      `  • Double-click → allocate to an account, invoice, or bill\n` +
      `  • Select → ✓ Reconcile  (if a matching journal entry exists)\n` +
      `  • Select → ⊘ Reject Dup  (if it is a known duplicate)\n\n` +
      `Tip: use "📋 Rules" to auto-categorise similar transactions.`
    );
    return;
  }

  // Only the currently-selected unreconciled transactions will be marked reconciled
  const selectedIids = [..._brSelected];
  const willRecN = selectedIids.filter(iid => {
    const t = _brTxns.find(tx => tx._iid === iid);
    return t && !t.is_reconciled && !t.is_rejected;
  }).length;

  if (Math.abs(_brLastDiff) >= 0.005) {
    _brShowAdjustmentDialog(recDate, closing, opening, selectedIids, willRecN);
    return;
  }

  if (!confirm(
    `Finalise reconciliation?\n\n` +
    `Date: ${_isoToAu(recDate)}\n` +
    `Opening Balance: ${_fmtAmt(_brOpening)}\n` +
    `Closing Balance: ${_fmtAmt(closing)}\n` +
    `Transactions to reconcile: ${willRecN}\n\n` +
    `Only selected transactions will be marked as reconciled.\n` +
    `The closing balance becomes the opening balance for the next period.`
  )) return;

  const r = await fetch(`/api/bankrec/${_brAccId}/complete`, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ reconcile_date: recDate, closing_balance: closing, opening_balance: _brOpening, selected_iids: selectedIids })
  });
  const d = await r.json();
  if (!d.ok) { _brToast('Error: ' + d.error, true); return; }
  const recId = d.data?.id;
  _brToast(`Reconciliation finalised — ${willRecN} transaction${willRecN !== 1 ? 's' : ''} reconciled.\nOpening balance: ${_fmtAmt(closing)}`);
  // Update opening balance immediately to the closing of the just-completed period
  const openEl = document.getElementById('br-opening-val');
  if (openEl) {
    _brOpening = closing;
    openEl.value = closing.toFixed(2);
    openEl.readOnly = true;
    openEl.title = 'Locked — equals previous reconciliation closing balance';
  }
  // Clear closing field and reset date so the next period starts clean
  const closingEl = document.getElementById('br-closing');
  if (closingEl) closingEl.value = '';
  const recDateEl = document.getElementById('br-rec-date');
  if (recDateEl) {
    const td = new Date();
    recDateEl.value = `${td.getFullYear()}-${String(td.getMonth()+1).padStart(2,'0')}-${String(td.getDate()).padStart(2,'0')}`;
  }
  await _brLoad();
  if (recId && confirm('View the period reconciliation report?')) {
    await _brShowPeriodReport(recId);
  }
}

// ── Reconciliation adjustment dialog ─────────────────────────────────────────
async function _brShowAdjustmentDialog(recDate, closing, opening, selectedIids, willRecN) {
  const diff    = _brLastDiff;
  const glClose = _brLastGlClose;
  let accounts = [];
  try { accounts = await apiFetch('/api/accounts'); } catch(e) {
    _brToast('Error loading accounts: ' + e.message, true); return;
  }
  const nonBank = accounts.filter(a => !a.is_bank);
  const suspense = nonBank.find(a => a.code === '9-9000');
  _brPendingAdj = { recDate, closing, opening, selectedIids, willRecN, diff, glClose };

  const opts = nonBank.map(a =>
    `<option value="${a.id}" ${suspense && a.id === suspense.id ? 'selected' : ''}>${esc(a.code)} — ${esc(a.name)}</option>`
  ).join('');

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box" style="max-width:500px">
      <div class="modal-hdr">Reconciliation Out of Balance</div>
      <div class="modal-body">
        <table class="br-adj-tbl">
          <tr><td>GL Closing Balance</td><td class="td-r">${_fmtAmt(glClose)}</td></tr>
          <tr><td>Statement Closing</td><td class="td-r">${_fmtAmt(closing)}</td></tr>
          <tr class="br-adj-gap"><td><strong>Difference</strong></td><td class="td-r"><strong>${_fmtAmt(Math.abs(diff))}</strong></td></tr>
        </table>
        <p class="br-adj-hint">An adjustment journal will be created to bring the GL into balance with the statement. Choose the offset account for the adjustment entry.</p>
        <div class="edt-field">
          <label class="edt-lbl">Offset Account</label>
          <input type="text" id="br-adj-search" class="edt-inp" placeholder="Search…"
                 oninput="_brAdjFilter()" style="margin-bottom:4px">
          <select id="br-adj-account" class="edt-sel" size="6" style="height:130px;width:100%">${opts}</select>
        </div>
        <div class="edt-field" style="margin-top:8px">
          <label class="edt-lbl">Description</label>
          <input type="text" id="br-adj-desc" class="edt-inp" value="Reconciliation adjustment">
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary" onclick="_brSubmitAdjustment()">Create Adjustment &amp; Finalise</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
  window._brAdjAllAccounts = nonBank;
}

function _brAdjFilter() {
  const q   = (document.getElementById('br-adj-search')?.value || '').toLowerCase();
  const sel = document.getElementById('br-adj-account');
  if (!sel || !window._brAdjAllAccounts) return;
  const cur = sel.value;
  sel.innerHTML = window._brAdjAllAccounts
    .filter(a => !q || a.code.toLowerCase().includes(q) || a.name.toLowerCase().includes(q))
    .map(a => `<option value="${a.id}" ${String(a.id)===cur?'selected':''}>${esc(a.code)} — ${esc(a.name)}</option>`)
    .join('');
}

async function _brSubmitAdjustment() {
  if (!_brPendingAdj) return;
  const adjAccountId = parseInt(document.getElementById('br-adj-account')?.value);
  const adjDesc = document.getElementById('br-adj-desc')?.value?.trim() || 'Reconciliation adjustment';
  if (!adjAccountId) { _brToast('Select an offset account', true); return; }

  const { recDate, closing, opening, selectedIids, willRecN, diff, glClose } = _brPendingAdj;
  document.querySelector('.modal-bd')?.remove();

  const r = await fetch(`/api/bankrec/${_brAccId}/finalise-with-adjustment`, {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({
      reconcile_date: recDate, closing_balance: closing,
      opening_balance: opening, gl_closing: glClose,
      adj_account_id: adjAccountId, adj_description: adjDesc,
      selected_iids: selectedIids
    })
  });
  const d = await r.json();
  if (!d.ok) { _brToast('Error: ' + d.error, true); return; }
  const recId = d.data?.id;
  _brToast(`Reconciliation finalised with adjustment — ${willRecN} transaction${willRecN!==1?'s':''} reconciled.`);
  const openEl = document.getElementById('br-opening-val');
  if (openEl) { _brOpening = closing; openEl.value = closing.toFixed(2); openEl.readOnly = true; }
  const closingEl = document.getElementById('br-closing');
  if (closingEl) closingEl.value = '';
  const td = new Date();
  const recDateEl = document.getElementById('br-rec-date');
  if (recDateEl) recDateEl.value = `${td.getFullYear()}-${String(td.getMonth()+1).padStart(2,'0')}-${String(td.getDate()).padStart(2,'0')}`;
  _brSelected.clear();
  document.getElementById('br-sel-count').textContent = '';
  await _brLoad();
  if (recId && confirm('View the period reconciliation report?')) await _brShowPeriodReport(recId);
}

async function _brCorrectRec(recId, currentClosing) {
  const input = prompt(
    `Correct closing balance\n\nCurrent: ${_fmtAmt(currentClosing)}\n\nEnter corrected closing balance:`,
    currentClosing.toFixed(2));
  if (input === null) return;
  const newClosing = parseFloat(input);
  if (isNaN(newClosing)) { _brToast('Invalid amount', true); return; }
  if (Math.abs(newClosing - currentClosing) < 0.005) { _brToast('No change made'); return; }

  const r = await fetch(`/api/bankrec/${_brAccId}/reconciliations/${recId}/correct`, {
    method: 'PATCH',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({closing_balance: newClosing})
  });
  const d = await r.json();
  if (!d.ok) { _brToast('Error: ' + d.error, true); return; }
  const msg = d.data?.next_updated
    ? `Closing balance corrected to ${_fmtAmt(newClosing)}. Next reconciliation opening updated.`
    : `Closing balance corrected to ${_fmtAmt(newClosing)}.`;
  const warn = (d.data?.downstream_count || 0) > 0
    ? ` Note: ${d.data.downstream_count} further reconciliation(s) downstream may also need correction.`
    : '';
  _brToast(msg + warn);
  detClose();
  await _brLoad();
}

// ── Difference ────────────────────────────────────────────────────────────────
function _brUpdateDiff() {
  const el = document.getElementById('br-diff');
  if (!el) return;
  const closingRaw = document.getElementById('br-closing')?.value?.trim();
  const closing = parseFloat(closingRaw);
  const ccStatus = document.getElementById('br-cc-status');
  const isLiabDiff = _brIsLiability();
  if (ccStatus) {
    if (isLiabDiff && !isNaN(closing)) {
      ccStatus.style.display = '';
      if (closing > 0) { ccStatus.textContent = 'Owing'; ccStatus.className = 'br-cc-status br-cc-owing'; }
      else if (closing < 0) { ccStatus.textContent = 'In credit'; ccStatus.className = 'br-cc-status br-cc-credit'; }
      else { ccStatus.textContent = 'Nil balance'; ccStatus.className = 'br-cc-status'; }
    } else {
      ccStatus.style.display = 'none';
    }
  }
  if (isNaN(closing)) { el.textContent = '—'; el.className = ''; return; }

  const openingRaw = document.getElementById('br-opening-val')?.value?.trim();
  const opening = parseFloat(openingRaw || 0);
  _brOpening = isNaN(opening) ? 0 : opening;

  // Sum only the currently SELECTED transactions (live preview).
  // Nothing selected → diff = closing − opening (the unexplained gap).
  // Something selected → diff shows whether that selection closes the gap.
  // Assets  (bank): GL debit = balance up; bank-statement credit = money in.
  // Liabs (CC/loan): stored credit = charge = increases balance (same formula for journal + CSV).
  const isLiab = _brIsLiability();
  const movement = [..._brSelected].reduce((sum, iid) => {
    const t = (_brTxns || []).find(tx => tx._iid === iid);
    if (!t || t.is_rejected) return sum;
    const d = parseFloat(t.debit || 0), c = parseFloat(t.credit || 0);
    if (isLiab) return sum + (c - d);
    return sum + (t._source === 'journal' ? d - c : c - d);
  }, 0);
  const expected = _brOpening + movement;
  const diff = closing - expected;
  _brLastDiff    = diff;
  _brLastGlClose = expected;
  const balanced = Math.abs(diff) < 0.005;
  el.textContent = `${_fmtAmt(diff)} ${balanced ? '✓' : '✗'}`;
  el.className = balanced ? 'br-diff-ok' : 'br-diff-bad';
}

// ── Status bar ─────────────────────────────────────────────────────────────────
function _brUpdateStatus() {
  const el = document.getElementById('br-status-txt');
  if (!el) return;
  const all   = _brTxns.length;
  const rec   = _brTxns.filter(t => t.is_reconciled && !t.is_rejected).length;
  const unrec = _brTxns.filter(t => !t.is_reconciled && !t.is_rejected).length;
  const dups  = _brTxns.filter(t => t._duplicate && !t.is_rejected).length;
  const rej   = _brTxns.filter(t => t.is_rejected).length;
  const shown = _brFiltered.length;
  let parts = [`${all} total`, `${unrec} unreconciled`, `${rec} reconciled`];
  if (dups) parts.push(`⚠ ${dups} possible duplicates`);
  if (rej)  parts.push(`${rej} rejected`);
  parts.push(`${shown} shown`);
  if (rec > 0 && !_brShowRec) parts.push(`(${rec} reconciled hidden — tick "Show reconciled" to view)`);
  if (rej > 0 && !_brShowRej) parts.push(`(${rej} rejected hidden — tick "Show rejected" to view)`);
  el.textContent = parts.join('  ·  ');
  const pill = document.getElementById('br-count-pill');
  if (pill) pill.textContent = `${_brFiltered.length} of ${_brTxns.length} transaction${_brTxns.length!==1?'s':''}`;
}

// ── CSV Import ────────────────────────────────────────────────────────────────
function _brShowImportCsv() {
  if (!_brAccId) { _brToast('Select an account first.'); return; }
  _brCsvHeaders  = [];
  _brCsvRows     = [];
  _brColMap      = {};
  _brCsvStep     = 1;
  _brHasHeaders  = false;
  _brCsvRawLines = [];
  _brCsvParsedRows = [];

  const FIELDS = [
    ['date',        'Date *'],
    ['description', 'Description'],
    ['reference',   'Reference'],
    ['debit',       'Debit (out)'],
    ['credit',      'Credit (in)'],
    ['amount',      'Amount (±)'],
    ['balance',     'Balance'],
  ];

  const fieldRows = FIELDS.map(([f, lbl]) => `
    <label class="br-csv-col-map">${lbl}</label>
    <select id="br-csv-map-${f}" onchange="_brCsvMap()">
      <option value="">— skip —</option>
    </select>`).join('');

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.id = 'br-import-modal';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box modal-760 modal-tall">
    <div class="modal-hdr"><span>Import Bank CSV</span></div>
    <div class="modal-body modal-body-scroll">
      <!-- Step 1: file upload -->
      <div class="br-csv-step active" id="br-csv-step1">
        <div class="br-csv-upload-area" id="br-csv-drop"
             ondragover="event.preventDefault()" ondrop="_brCsvDrop(event)"
             onclick="document.getElementById('br-csv-file-inp').click()">
          <div class="br-import-icon">📂</div>
          <div>Drag & drop a CSV file here, or click to browse</div>
          <div class="br-import-hint">Supports most bank CSV formats</div>
        </div>
        <input type="file" id="br-csv-file-inp" accept=".csv" style="display:none"
               onchange="_brCsvFileSelected(this)">
        <div class="br-csv-row">
          <label class="br-csv-lbl">Data starts row:</label>
          <input type="number" id="br-csv-start-row" value="1" min="1" max="50"
                 class="br-csv-inp" onchange="_brCsvReparse()">
          <span class="br-csv-hint">(skip preamble rows)</span>
          <label class="br-csv-lbl" style="margin-left:12px">
            <input type="checkbox" id="br-csv-has-headers" onchange="_brCsvReparse()">
            First row is headers
          </label>
        </div>
        <div class="br-csv-raw" id="br-csv-raw">Load a CSV file to see preview.</div>
        <div class="br-csv-status" id="br-csv-status"></div>
      </div>
      <!-- Step 2: mapping -->
      <div class="br-csv-step" id="br-csv-step2">
        <div class="br-csv-row" style="margin-bottom:14px">
          <label class="br-csv-lbl">Bank format:</label>
          <select class="br-csv-sel" id="br-csv-bank-preset" onchange="_brApplyPreset(this.value)">
            <option value="">— auto detect —</option>
            ${Object.entries(_BR_BANK_PRESETS).map(([k,p]) => `<option value="${k}">${p.label}</option>`).join('')}
          </select>
          <button class="btn btn-sm" onclick="_brSaveCustomPreset()" title="Save current mapping as a preset">💾 Save preset</button>
          <button class="btn btn-sm btn-danger" id="br-csv-preset-del" style="display:none"
                  onclick="_brDeleteCustomPreset(document.getElementById('br-csv-bank-preset').value)"
                  title="Delete this saved preset">✕ Delete</button>
        </div>
        <p class="br-csv-hdr">Map CSV columns to fields:</p>
        <div class="br-csv-col-map">${fieldRows}</div>
        <div class="br-csv-row">
          <label class="br-csv-lbl">Date Format:</label>
          <select id="br-csv-datefmt" class="br-csv-sel">
            <option>%d/%m/%Y</option><option>%Y-%m-%d</option><option>%m/%d/%Y</option>
            <option>%d-%m-%Y</option><option>%d %b %Y</option><option>%d/%m/%y</option>
          </select>
          <label class="br-csv-lbl">Amount +ve =</label>
          <select id="br-csv-sign" class="br-csv-sel">
            <option value="credit">Credit (money in)</option>
            <option value="debit">Debit (money out)</option>
          </select>
        </div>
        <button class="btn btn-sm btn-primary" onclick="_brCsvPreview()">👁 Preview</button>
      </div>
      <!-- Step 3: preview -->
      <div class="br-csv-step" id="br-csv-step3">
        <div class="br-csv-status" id="br-csv-prev-status"></div>
        <div class="br-csv-preview-tbl tbl-scroll" id="br-csv-prev-tbl"></div>
      </div>
    </div>
    <div class="modal-foot modal-foot-sb">
      <button class="btn btn-sm" onclick="document.querySelector('.modal-bd').remove()">Cancel</button>
      <div class="br-match-btns">
        <button class="btn btn-sm" id="br-csv-btn-back" style="display:none" onclick="_brCsvBack()">← Back</button>
        <button class="btn btn-sm btn-primary" id="br-csv-btn-next" onclick="_brCsvNext()">Next →</button>
        <button class="btn btn-sm btn-success" id="br-csv-btn-import" style="display:none" onclick="_brCsvImport()">⬆ Import</button>
      </div>
    </div>
    </div>`;
  document.body.appendChild(bd);
  // Populate custom presets (built-ins already rendered in template above)
  _brRebuildPresetDropdown();
}

let _brCsvStep = 1;
let _brCsvRawLines = [];
let _brCsvParsedRows = [];
let _brHasHeaders = false;

const _BR_BANK_PRESETS = {
  'cba':       { label: 'CommBank (NetBank)', hasHeaders: false, dateFmt: '%d/%m/%Y', signMode: 'credit', cols: { date: 0, amount: 1, description: 2 } },
  'anz':       { label: 'ANZ',                hasHeaders: true,  dateFmt: '%d/%m/%Y', signMode: 'credit', cols: {} },
  'nab':       { label: 'NAB',                hasHeaders: true,  dateFmt: '%d/%m/%Y', signMode: 'credit', cols: {} },
  'westpac':   { label: 'Westpac',            hasHeaders: true,  dateFmt: '%d/%m/%Y', signMode: 'credit', cols: {} },
  'ing':       { label: 'ING',                hasHeaders: true,  dateFmt: '%d/%m/%Y', signMode: 'credit', cols: {} },
  'bendigo':   { label: 'Bendigo Bank',       hasHeaders: true,  dateFmt: '%d/%m/%Y', signMode: 'credit', cols: {} },
  'macquarie': { label: 'Macquarie Bank',     hasHeaders: true,  dateFmt: '%d/%m/%Y', signMode: 'credit', cols: {} },
  'suncorp':   { label: 'Suncorp',            hasHeaders: true,  dateFmt: '%d/%m/%Y', signMode: 'credit', cols: {} },
};

function _brCsvDrop(e) {
  e.preventDefault();
  const file = e.dataTransfer.files[0];
  if (file) _brCsvReadFile(file);
}

function _brCsvFileSelected(inp) {
  if (inp.files[0]) _brCsvReadFile(inp.files[0]);
}

function _brCsvReadFile(file) {
  const reader = new FileReader();
  reader.onload = e => {
    const text = e.target.result;
    _brCsvRawLines = text.replace(/\r\n/g,'\n').replace(/\r/g,'\n').split('\n');
    const rawEl = document.getElementById('br-csv-raw');
    const startRow = parseInt(document.getElementById('br-csv-start-row')?.value||'1');
    if (rawEl) {
      rawEl.textContent = _brCsvRawLines.slice(0, 30).map((l,i) =>
        `${String(i+1).padStart(3)} ${i+1===startRow?'►':'  '} ${l}`
      ).join('\n') + (_brCsvRawLines.length > 30 ? `\n  ... (${_brCsvRawLines.length-30} more rows)` : '');
    }
    // Auto-detect if first data row looks like a header (all text, no dates/numbers)
    const firstDataLine = _brCsvRawLines.slice(startRow - 1).find(l => l.trim());
    if (firstDataLine) {
      const firstRow = _brCsvParseLine(firstDataLine);
      const dateRe = /^\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}$|^\d{4}-\d{2}-\d{2}$/;
      const numRe  = /^-?[\d,]+\.?\d*$/;
      const looksLikeHeaders = firstRow.length > 0 && firstRow.some(v => v.trim().length > 0)
        && firstRow.every(v => { const s = v.trim().replace(/[$,]/g,''); return !dateRe.test(s) && !numRe.test(s); });
      const hdrChk = document.getElementById('br-csv-has-headers');
      if (hdrChk) { hdrChk.checked = looksLikeHeaders; _brHasHeaders = looksLikeHeaders; }
    }
    _brCsvParseHeaders();
    // Auto-apply last used preset (overrides generic auto-map)
    const lastPreset = localStorage.getItem('dbox-br-last-preset');
    if (lastPreset) {
      const presetSel = document.getElementById('br-csv-bank-preset');
      if (presetSel) presetSel.value = lastPreset;
      _brApplyPreset(lastPreset);
    }
    const statusEl = document.getElementById('br-csv-status');
    if (statusEl) statusEl.textContent = `${file.name} — ${_brCsvRawLines.length} lines`;
  };
  reader.readAsText(file, 'UTF-8');
}

function _brCsvParseHeaders() {
  const startRow = parseInt(document.getElementById('br-csv-start-row')?.value||'1');
  _brHasHeaders = document.getElementById('br-csv-has-headers')?.checked ?? false;
  const allParsed = _brCsvRawLines.slice(startRow - 1).filter(l => l.trim()).map(l => _brCsvParseLine(l));
  if (!allParsed.length) return;
  const ncols = Math.max(...allParsed.slice(0, 5).map(r => r.length));

  let headerNames = null;
  if (_brHasHeaders && allParsed.length > 0) {
    headerNames = allParsed[0].map((h, i) => h.trim() || `Col ${i+1}`);
    _brCsvRows = allParsed.slice(1);
  } else {
    _brCsvRows = allParsed;
  }

  const samples = Array.from({length: ncols}, (_, c) => {
    for (const row of _brCsvRows.slice(0, 3)) if (row[c]?.trim()) return row[c].trim().slice(0, 20);
    return '';
  });
  _brCsvHeaders = Array.from({length: ncols}, (_, c) =>
    headerNames ? (headerNames[c] || `Col ${c+1}`) :
    (samples[c] ? `Col ${c+1}  —  ${samples[c]}` : `Col ${c+1}`));

  const opts = ['<option value="">— skip —</option>',
    ..._brCsvHeaders.map((h, i) => `<option value="${i}">${esc(h)}</option>`)].join('');
  ['date','description','reference','debit','credit','amount','balance'].forEach(f => {
    const sel = document.getElementById(`br-csv-map-${f}`);
    if (sel) sel.innerHTML = opts;
  });
  _brCsvAutoMap(headerNames || samples, ncols, !!headerNames);
}

function _brCsvAutoMap(namesOrSamples, ncols, isHeaderNames = false) {
  const setVal = (f, c) => {
    if (c < 0 || c === undefined) return;
    const sel = document.getElementById(`br-csv-map-${f}`);
    if (sel) sel.value = String(c);
  };

  if (isHeaderNames) {
    // Match by header name
    const lower = namesOrSamples.map((n, i) => ({ i, n: (n||'').toLowerCase() }));
    const find = (...terms) => { const m = lower.find(x => terms.some(t => x.n.includes(t))); return m ? m.i : -1; };
    setVal('date',        find('date'));
    setVal('description', find('description', 'narration', 'details', 'merchant', 'memo', 'particulars', 'transaction'));
    setVal('reference',   find('reference', 'ref', 'cheque', 'check'));
    const debitIdx  = find('debit', 'withdrawal', 'debit amount');
    const creditIdx = find('credit', 'deposit', 'credit amount');
    setVal('debit',  debitIdx);
    setVal('credit', creditIdx);
    // Only map amount if there are no separate debit/credit columns
    if (debitIdx < 0 && creditIdx < 0) setVal('amount', find('amount', 'amt'));
    setVal('balance', find('balance', 'bal', 'closing'));
    return;
  }

  // Content sniffing fallback
  const dateRe = /^\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}$|^\d{4}-\d{2}-\d{2}$/;
  const numRe  = /^-?[\d,]+\.?\d*$/;
  const dateCols = [], numCols = [], textCols = [];
  for (let c = 0; c < ncols; c++) {
    const s = (namesOrSamples[c] || '').replace(/[$,]/g,'').trim();
    if (dateRe.test(s)) dateCols.push(c);
    else if (numRe.test(s) && s.length > 0) numCols.push(c);
    else if (s.length > 0) textCols.push(c);
  }
  if (dateCols.length)     setVal('date',        dateCols[0]);
  if (textCols.length)     setVal('description', textCols[0]);
  if (textCols.length > 1) setVal('reference',   textCols[1]);
  if (numCols.length === 1)     setVal('amount', numCols[0]);
  else if (numCols.length >= 2) { setVal('debit', numCols[0]); setVal('credit', numCols[1]); }
  if (numCols.length >= 3) setVal('balance', numCols[numCols.length - 1]);
}

function _brCsvReparse() {
  if (_brCsvRawLines.length) _brCsvParseHeaders();
}

function _brCsvMap() { /* live mapping — no-op, used on next */ }

function _brCsvParseLine(line) {
  // Handle quoted CSV
  const result = [];
  let cur = '', inQ = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') { inQ = !inQ; continue; }
    if (ch === ',' && !inQ) { result.push(cur.trim()); cur = ''; continue; }
    cur += ch;
  }
  result.push(cur.trim());
  return result;
}

function _brAutoDetectDateFmt(dcol) {
  const FORMATS = ['%d/%m/%Y', '%Y-%m-%d', '%d-%m-%Y', '%d/%m/%y', '%d %b %Y', '%m/%d/%Y'];
  const samples = _brCsvRows.slice(0, 10).map(r => (r[dcol] || '').trim()).filter(Boolean);
  if (!samples.length) return null;
  for (const fmt of FORMATS) {
    if (samples.filter(s => _brCsvParseDate(s, fmt) !== null).length / samples.length >= 0.8) return fmt;
  }
  return null;
}

// ── Categorise presets (GL Account panel) ────────────────────────────────────
const _BR_ALLOC_PRESETS_KEY = 'dbox-br-alloc-presets';

function _brLoadAllocPresets() {
  try { return JSON.parse(localStorage.getItem(_BR_ALLOC_PRESETS_KEY) || '{}'); }
  catch { return {}; }
}

function _brAllocPresetOpts() {
  const entries = Object.entries(_brLoadAllocPresets());
  if (!entries.length) return '<option value="">— no presets saved —</option>';
  return '<option value="">— load preset —</option>' +
    entries.map(([k, p]) => `<option value="${k}">${esc(p.label)}</option>`).join('');
}

function _brApplyAllocPreset(key) {
  const del = document.getElementById('br-gl-preset-del');
  if (del) del.style.display = key ? '' : 'none';
  if (!key) return;
  const p = _brLoadAllocPresets()[key];
  if (!p) return;
  const accSel = document.getElementById('br-gl-acc');
  if (accSel && p.account_id) accSel.value = String(p.account_id);
  const taxSel = document.getElementById('br-gl-tax');
  if (taxSel && p.tax_code) taxSel.value = p.tax_code;
  const contSel = document.getElementById('br-gl-contact');
  if (contSel) contSel.value = p.contact_id ? String(p.contact_id) : '';
  if (p.description) {
    const descInp = document.getElementById('br-gl-desc');
    if (descInp) descInp.value = p.description;
  }
}

function _brSaveAllocPreset() {
  const accSel = document.getElementById('br-gl-acc');
  if (!parseInt(accSel?.value || 0)) { _brToast('Select an account before saving a preset', true); return; }
  const name = prompt('Preset name (e.g. "Phone - Telstra"):');
  if (!name?.trim()) return;
  const key = 'alloc_' + name.trim().toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '');
  const all = _brLoadAllocPresets();
  all[key] = {
    label:      name.trim(),
    account_id: parseInt(accSel.value) || null,
    tax_code:   document.getElementById('br-gl-tax')?.value || 'N-T',
    contact_id: parseInt(document.getElementById('br-gl-contact')?.value || 0) || null,
    description: document.getElementById('br-gl-desc')?.value.trim() || '',
  };
  localStorage.setItem(_BR_ALLOC_PRESETS_KEY, JSON.stringify(all));
  const sel = document.getElementById('br-gl-preset');
  if (sel) { sel.innerHTML = _brAllocPresetOpts(); sel.value = key; }
  const del = document.getElementById('br-gl-preset-del');
  if (del) del.style.display = '';
  _brToast(`Preset "${name.trim()}" saved`);
}

function _brDeleteAllocPreset() {
  const sel = document.getElementById('br-gl-preset');
  const key = sel?.value;
  if (!key) return;
  const all = _brLoadAllocPresets();
  const label = all[key]?.label || key;
  if (!confirm(`Delete preset "${label}"?`)) return;
  delete all[key];
  localStorage.setItem(_BR_ALLOC_PRESETS_KEY, JSON.stringify(all));
  if (sel) { sel.innerHTML = _brAllocPresetOpts(); sel.value = ''; }
  const del = document.getElementById('br-gl-preset-del');
  if (del) del.style.display = 'none';
  _brToast(`Preset "${label}" deleted`);
}

// ── CSV import presets ────────────────────────────────────────────────────────
const _BR_CUSTOM_PRESETS_KEY = 'dbox-br-custom-presets';

function _brLoadCustomPresets() {
  try { return JSON.parse(localStorage.getItem(_BR_CUSTOM_PRESETS_KEY) || '{}'); }
  catch { return {}; }
}

function _brRebuildPresetDropdown(selectKey) {
  const sel = document.getElementById('br-csv-bank-preset');
  if (!sel) return;
  const custom = _brLoadCustomPresets();
  const customEntries = Object.entries(custom);
  sel.innerHTML = [
    '<option value="">— auto detect —</option>',
    ...Object.entries(_BR_BANK_PRESETS).map(([k, p]) => `<option value="${k}">${esc(p.label)}</option>`),
    ...(customEntries.length ? ['<option disabled>──── My presets ────</option>'] : []),
    ...customEntries.map(([k, p]) => `<option value="${k}">${esc(p.label)}</option>`),
  ].join('');
  if (selectKey !== undefined) sel.value = selectKey;
  _brUpdatePresetDeleteBtn(sel.value);
}

function _brUpdatePresetDeleteBtn(key) {
  const btn = document.getElementById('br-csv-preset-del');
  if (btn) btn.style.display = (key || '').startsWith('custom_') ? '' : 'none';
}

function _brSaveCustomPreset() {
  const name = prompt('Preset name (e.g. "Bankwest", "Bank of Queensland"):');
  if (!name?.trim()) return;
  const key = 'custom_' + name.trim().toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '');
  const colOf = f => { const s = document.getElementById(`br-csv-map-${f}`)?.value; return (s !== '' && s !== undefined) ? parseInt(s) : undefined; };
  const cols = {};
  ['date','description','reference','debit','credit','amount','balance'].forEach(f => {
    const v = colOf(f); if (v !== undefined && !isNaN(v)) cols[f] = v;
  });
  const preset = {
    label:      name.trim(),
    hasHeaders: document.getElementById('br-csv-has-headers')?.checked ?? false,
    dateFmt:    document.getElementById('br-csv-datefmt')?.value || '%d/%m/%Y',
    signMode:   document.getElementById('br-csv-sign')?.value || 'credit',
    cols,
  };
  const all = _brLoadCustomPresets();
  all[key] = preset;
  localStorage.setItem(_BR_CUSTOM_PRESETS_KEY, JSON.stringify(all));
  _brRebuildPresetDropdown(key);
  _brToast(`Preset "${name.trim()}" saved.`);
}

function _brDeleteCustomPreset(key) {
  if (!(key || '').startsWith('custom_')) return;
  const all = _brLoadCustomPresets();
  const label = all[key]?.label || key;
  if (!confirm(`Delete preset "${label}"?`)) return;
  delete all[key];
  localStorage.setItem(_BR_CUSTOM_PRESETS_KEY, JSON.stringify(all));
  _brRebuildPresetDropdown('');
  _brToast(`Preset "${label}" deleted.`);
}

function _brApplyPreset(key) {
  if (!key) {
    _brUpdatePresetDeleteBtn('');
    if (_brCsvRawLines.length) _brCsvParseHeaders();
    return;
  }
  const preset = _BR_BANK_PRESETS[key] || _brLoadCustomPresets()[key];
  if (!preset) {
    // Stale key — drop it so auto-detect takes over next time
    localStorage.removeItem('dbox-br-last-preset');
    if (_brCsvRawLines.length) _brCsvParseHeaders();
    return;
  }
  localStorage.setItem('dbox-br-last-preset', key);
  const hdrChk = document.getElementById('br-csv-has-headers');
  if (hdrChk) { hdrChk.checked = preset.hasHeaders; _brHasHeaders = preset.hasHeaders; }
  const dateFmtSel = document.getElementById('br-csv-datefmt');
  if (dateFmtSel) dateFmtSel.value = preset.dateFmt;
  const signSel = document.getElementById('br-csv-sign');
  if (signSel) signSel.value = preset.signMode;
  if (_brCsvRawLines.length) _brCsvParseHeaders();
  // Apply explicit column indices (used for headerless formats like CBA)
  if (preset.cols) {
    Object.entries(preset.cols).forEach(([f, c]) => {
      const sel = document.getElementById(`br-csv-map-${f}`);
      if (sel && sel.options.length > c + 1) sel.value = String(c);
    });
  }
  _brUpdatePresetDeleteBtn(key);
}

function _brCsvPreview() {
  let dateFmt    = document.getElementById('br-csv-datefmt')?.value || '%d/%m/%Y';
  const signMode = document.getElementById('br-csv-sign')?.value || 'credit';
  const colOf    = f => { const s = document.getElementById(`br-csv-map-${f}`)?.value; return s !== '' ? parseInt(s) : -1; };

  const dcol   = colOf('date');

  // Auto-detect date format from the mapped column's data
  if (dcol >= 0) {
    const detected = _brAutoDetectDateFmt(dcol);
    if (detected) {
      const sel = document.getElementById('br-csv-datefmt');
      if (sel) sel.value = detected;
      dateFmt = detected;
    }
  }

  const descol = colOf('description');
  const refcol = colOf('reference');
  const debcol = colOf('debit');
  const crecol = colOf('credit');
  const amtcol = colOf('amount');
  const balcol = colOf('balance');

  if (dcol < 0) { _brToast('Map the Date column first.'); return false; }

  _brCsvParsedRows = _brCsvRows.map(row => {
    const raw = v => (v >= 0 && row[v] !== undefined) ? row[v].trim() : '';
    const dateStr = raw(dcol);
    const isoDate = _brCsvParseDate(dateStr, dateFmt);
    const descVal = raw(descol);
    const refVal  = raw(refcol);
    let debit = 0, credit = 0;
    if (amtcol >= 0) {
      const amt = parseFloat(raw(amtcol).replace(/[,$]/g,'')) || 0;
      if (signMode === 'credit') { if (amt > 0) credit = amt; else debit = Math.abs(amt); }
      else                       { if (amt > 0) debit  = amt; else credit = Math.abs(amt); }
    } else {
      debit  = parseFloat(raw(debcol).replace(/[,$]/g,'')) || 0;
      credit = parseFloat(raw(crecol).replace(/[,$]/g,'')) || 0;
    }
    const bal = balcol >= 0 ? parseFloat(raw(balcol).replace(/[,$]/g,'')) || 0 : 0;
    return { date: isoDate, description: descVal, reference: refVal,
             debit, credit, balance: bal, _raw: dateStr };
  }).filter(r => r.date);

  const prevEl = document.getElementById('br-csv-prev-tbl');
  if (prevEl) {
    prevEl.innerHTML = `<table class="tbl">
      <thead><tr><th>Date</th><th>Description</th><th>Reference</th>
        <th class="th-r">Debit</th><th class="th-r">Credit</th><th class="th-r">Balance</th></tr></thead>
      <tbody>${_brCsvParsedRows.slice(0,50).map((r,i) =>
        `<tr class="${i%2?'row-alt':''}">
          <td>${_isoToAu(r.date)}</td><td>${esc(r.description)}</td>
          <td>${esc(r.reference)}</td>
          <td class="td-r-mono">${r.debit  ? _fmtAmt(r.debit)  : ''}</td>
          <td class="td-r-mono">${r.credit ? _fmtAmt(r.credit) : ''}</td>
          <td class="td-r-mono">${r.balance ? _fmtAmt(r.balance) : ''}</td>
        </tr>`).join('')}
      </tbody></table>`;
  }
  const statusEl = document.getElementById('br-csv-prev-status');
  if (statusEl) statusEl.textContent = `${_brCsvParsedRows.length} rows parsed (${_brCsvRows.length - _brCsvParsedRows.length} skipped — invalid date)`;
  return true;
}

function _brCsvParseDate(s, fmt) {
  s = s.replace(/^"|"$/g,'').trim();
  const fmtParts = fmt.split(/[\/\-\s]/);
  const sParts   = s.split(/[\/\-\s]/);
  if (fmtParts.length !== sParts.length) return null;
  let y,m,d;
  fmtParts.forEach((p,i) => {
    if (p==='%Y') y = sParts[i].padStart(4,'20');
    else if (p==='%y') y = '20'+sParts[i];
    else if (p==='%m') {
      // Handle both numeric months and abbreviated month names (e.g. "APR" in CBA exports)
      const months = {jan:'01',feb:'02',mar:'03',apr:'04',may:'05',jun:'06',
                      jul:'07',aug:'08',sep:'09',oct:'10',nov:'11',dec:'12'};
      m = months[sParts[i].toLowerCase().slice(0,3)] || sParts[i].padStart(2,'0');
    }
    else if (p==='%d') d = sParts[i].padStart(2,'0');
    else if (p==='%b') {
      const months = {jan:'01',feb:'02',mar:'03',apr:'04',may:'05',jun:'06',
                      jul:'07',aug:'08',sep:'09',oct:'10',nov:'11',dec:'12'};
      m = months[sParts[i].toLowerCase().slice(0,3)] || '01';
    }
  });
  if (!y||!m||!d) return null;
  return `${y}-${m}-${d}`;
}

function _brCsvNext() {
  if (_brCsvStep === 1) {
    if (!_brCsvRows.length) { _brToast('Load a CSV file first.'); return; }
    _brCsvStep = 2;
    document.getElementById('br-csv-step1').classList.remove('active');
    document.getElementById('br-csv-step2').classList.add('active');
    document.getElementById('br-csv-btn-back').style.display = '';
    document.getElementById('br-csv-btn-next').textContent = 'Preview →';
    // Re-apply column mapping now that step 2 elements are visible — select.value
    // assignments inside display:none don't reliably stick in all browsers.
    const presetSel = document.getElementById('br-csv-bank-preset');
    if (presetSel?.value) _brApplyPreset(presetSel.value);
    else _brCsvParseHeaders();
  } else if (_brCsvStep === 2) {
    if (!_brCsvPreview()) return;
    _brCsvStep = 3;
    document.getElementById('br-csv-step2').classList.remove('active');
    document.getElementById('br-csv-step3').classList.add('active');
    document.getElementById('br-csv-btn-next').style.display = 'none';
    const importBtn = document.getElementById('br-csv-btn-import');
    importBtn.style.display = '';
    importBtn.textContent = `⬆ Import ${_brCsvParsedRows.length} rows`;
  }
}

function _brCsvBack() {
  if (_brCsvStep === 2) {
    _brCsvStep = 1;
    document.getElementById('br-csv-step2').classList.remove('active');
    document.getElementById('br-csv-step1').classList.add('active');
    document.getElementById('br-csv-btn-back').style.display = 'none';
    document.getElementById('br-csv-btn-next').textContent = 'Next →';
  } else if (_brCsvStep === 3) {
    _brCsvStep = 2;
    document.getElementById('br-csv-step3').classList.remove('active');
    document.getElementById('br-csv-step2').classList.add('active');
    document.getElementById('br-csv-btn-next').style.display = '';
    const importBtn = document.getElementById('br-csv-btn-import');
    importBtn.style.display = 'none';
    importBtn.textContent = '⬆ Import';
  }
}

async function _brCsvImport() {
  if (!_brCsvParsedRows.length) { _brToast('Nothing to import — preview first.'); return; }
  const importBtn = document.getElementById('br-csv-btn-import');
  if (importBtn) { importBtn.disabled = true; importBtn.textContent = 'Importing…'; }
  const rows = _brCsvParsedRows.map(r => ({
    date: r.date, description: r.description, reference: r.reference,
    debit: r.debit, credit: r.credit, balance: r.balance,
  }));
  try {
    const res = await fetch(`/api/bankrec/${_brAccId}/import-csv`, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ rows })
    });
    const d = await res.json();
    if (!d.ok) {
      _brToast('Import failed: ' + d.error, true);
      if (importBtn) { importBtn.disabled = false; importBtn.textContent = `⬆ Import ${_brCsvParsedRows.length} rows`; }
      return;
    }
    document.getElementById('br-import-modal')?.remove();
    const inserted = d.data?.inserted ?? 0;
    _brToast(`Import complete — ${inserted} new row(s) added (duplicates skipped).`);
    await _brLoad();
  } catch (e) {
    _brToast('Import failed: ' + e.message, true);
    if (importBtn) { importBtn.disabled = false; importBtn.textContent = `⬆ Import ${_brCsvParsedRows.length} rows`; }
  }
}

// ── Bank Rules modal ──────────────────────────────────────────────────────────
async function _brShowRules() {
  _brRules = await apiFetch('/api/bankrec/rules');
  const accs = await apiFetch('/api/accounts');

  const rows = _brRules.map((r, i) => `
    <tr class="${i%2?'row-alt':''} br-rule-row" data-id="${r.id}" onclick="_brRuleSelect(${r.id})">
      <td>${r.priority||0}</td>
      <td>${esc(r.rule_name||'')}</td>
      <td>${r.match_field||'description'}</td>
      <td>${r.match_type||'contains'}</td>
      <td>${esc(r.match_value||'')}</td>
      <td>${r.direction||'both'}</td>
      <td>${r.account_code ? `${r.account_code} ${r.account_name||''}` : '—'}</td>
      <td>${r.contact_name||'—'}</td>
      <td><span class="${r.is_active ? 'br-rule-active' : 'br-rule-inactive'}">${r.is_active ? '✓ Active' : 'Inactive'}</span></td>
    </tr>`).join('');

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box modal-900 modal-tall">
    <div class="modal-hdr">
      <span>Bank Categorisation Rules</span>
    </div>
    <div class="modal-body modal-body-scroll">
      <p class="br-rules-hint">Rules are applied in priority order (highest first). First matching rule wins per transaction.</p>
      <div class="br-rules-btns">
        <button class="btn btn-sm btn-success" onclick="_brRuleNew()">+ New Rule</button>
        <button class="btn btn-sm btn-primary" id="br-rule-edit-btn" style="display:none" onclick="_brRuleEdit()">✎ Edit</button>
        <button class="btn btn-sm btn-danger"  id="br-rule-del-btn"  style="display:none" onclick="_brRuleDelete()">✗ Delete</button>
      </div>
      <div class="tbl-scroll">
        <table class="tbl br-rules-tbl" id="br-rules-tbl">
          <thead><tr>
            <th>Priority</th><th>Rule Name</th><th>Field</th><th>Type</th>
            <th>Pattern</th><th>Direction</th><th>Account</th><th>Contact</th><th>Status</th>
          </tr></thead>
          <tbody>${rows || '<tr><td colspan="9" class="br-rules-empty">No rules yet. Create one to start auto-categorising transactions.</td></tr>'}</tbody>
        </table>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-sm" onclick="document.querySelector('.modal-bd').remove()">Close</button>
    </div>
    </div>`;
  document.body.appendChild(bd);
  bd._accs = accs;
}

let _brRuleSelId = null;

function _brRuleSelect(id) {
  _brRuleSelId = id;
  document.querySelectorAll('#br-rules-tbl tbody tr').forEach(r => {
    r.classList.toggle('selected', parseInt(r.dataset.id) === id);
  });
  document.getElementById('br-rule-edit-btn').style.display = '';
  document.getElementById('br-rule-del-btn').style.display  = '';
}

function _brRuleNew() {
  _brRuleEditId = null;
  _brRuleEditForm(null);
}

function _brRuleEdit() {
  if (!_brRuleSelId) return;
  const rule = _brRules.find(r => r.id === _brRuleSelId);
  _brRuleEditId = _brRuleSelId;
  _brRuleEditForm(rule);
}

async function _brRuleDelete() {
  if (!_brRuleSelId) return;
  if (!confirm('Delete this rule? This cannot be undone.')) return;
  const r = await fetch(`/api/bankrec/rules/${_brRuleSelId}`, { method:'DELETE' });
  const d = await r.json();
  if (!d.ok) { _brToast('Error: ' + d.error, true); return; }
  document.querySelector('.modal-bd')?.remove();
  await _brShowRules();
}

function _brRuleEditForm(rule) {
  const bd = document.querySelector('.modal-bd');
  const accs = bd?._accs || [];
  const accOpts = '<option value="">— none —</option>' +
    accs.map(a => `<option value="${a.id}" ${rule?.account_id==a.id?'selected':''}>${a.code}  ${a.name}</option>`).join('');

  const formBd = document.createElement('div');
  formBd.className = 'modal-bd';
  formBd.style.display = 'flex';
  formBd.style.zIndex = '10001';
  formBd.innerHTML = `
    <div class="modal-box modal-520">
    <div class="modal-hdr"><span>${rule ? 'Edit Rule' : 'New Rule'}</span></div>
    <div class="modal-body">
      <div class="br-alloc-field"><label>Rule Name *</label>
        <input type="text" id="brf-name" value="${esc(rule?.rule_name||'')}"></div>
      <div class="br-alloc-field"><label>Match Field</label>
        <select id="brf-field">
          ${['description','reference'].map(f=>`<option ${rule?.match_field===f?'selected':''}>${f}</option>`).join('')}
        </select></div>
      <div class="br-alloc-field"><label>Match Type</label>
        <select id="brf-type">
          ${['contains','startswith','exact'].map(t=>`<option ${rule?.match_type===t?'selected':''}>${t}</option>`).join('')}
        </select></div>
      <div class="br-alloc-field"><label>Pattern *</label>
        <input type="text" id="brf-value" value="${esc(rule?.match_value||'')}"></div>
      <div class="br-alloc-field"><label>Direction</label>
        <select id="brf-dir">
          ${['both','credit','debit'].map(d=>`<option ${rule?.direction===d?'selected':''}>${d}</option>`).join('')}
        </select></div>
      <div class="br-alloc-field"><label>Account</label>
        <select id="brf-acc">${accOpts}</select></div>
      <div class="br-alloc-field"><label>Priority (higher = first)</label>
        <input type="number" id="brf-priority" value="${rule?.priority||0}" min="0"></div>
      <div class="br-alloc-field"><label>
        <input type="checkbox" id="brf-active" ${rule?.is_active!==0?'checked':''}> Active
      </label></div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-sm btn-success" onclick="_brRuleSave()">✓ Save Rule</button>
    </div>
    </div>`;
  document.body.appendChild(formBd);
}

async function _brRuleSave() {
  const name   = document.getElementById('brf-name')?.value.trim();
  const val    = document.getElementById('brf-value')?.value.trim();
  if (!name) { _brToast('Rule name is required.'); return; }
  if (!val)  { _brToast('Pattern is required.'); return; }

  const data = {
    id:           _brRuleEditId || undefined,
    rule_name:    name,
    match_field:  document.getElementById('brf-field')?.value,
    match_type:   document.getElementById('brf-type')?.value,
    match_value:  val,
    direction:    document.getElementById('brf-dir')?.value,
    account_id:   parseInt(document.getElementById('brf-acc')?.value)||null,
    contact_id:   null,
    priority:     parseInt(document.getElementById('brf-priority')?.value)||0,
    is_active:    document.getElementById('brf-active')?.checked ? 1 : 0,
  };

  let res;
  if (_brRuleEditId) {
    res = await fetch(`/api/bankrec/rules/${_brRuleEditId}`, {
      method:'PUT', headers:{'Content-Type':'application/json'},
      body: JSON.stringify(data)
    });
  } else {
    res = await fetch('/api/bankrec/rules', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify(data)
    });
  }
  const d = await res.json();
  if (!d.ok) { _brToast('Error: ' + d.error, true); return; }

  // Close both modals and reopen rules list
  document.querySelectorAll('.modal-bd').forEach(el => el.remove());
  await _brShowRules();
}

// ── Reconciliation Report ────────────────────────────────────────────────────
async function _brShowReport() {
  if (!_brAccId) { _brToast('Select an account first.'); return; }
  let data;
  try {
    data = await apiFetch(`/api/bankrec/${_brAccId}/rec-report`);
  } catch(e) {
    _brToast('Error loading report: ' + e.message, true);
    return;
  }

  const acc     = data.account;
  const lastRec = data.last_rec;
  const lastRecDate = lastRec ? _isoToAu(lastRec.reconcile_date) : '—';

  function fmtMoney(v) {
    const n = parseFloat(v || 0);
    if (Math.abs(n) < 0.005) return '';
    return '$' + n.toLocaleString('en-AU', {minimumFractionDigits:2, maximumFractionDigits:2});
  }

  // GL items: asset convention — debit=in, credit=out
  function buildGLRows(items) {
    if (!items.length) return `<tr><td colspan="5" class="br-rpt-empty">No unreconciled GL items</td></tr>`;
    return items.map(t => `<tr>
      <td class="br-rpt-date">${_isoToAu(t.date)}</td>
      <td class="br-rpt-desc">${esc(t.description)}</td>
      <td class="br-rpt-ref">${esc(t.reference||'')}</td>
      <td class="br-rpt-in">${fmtMoney(t.debit)}</td>
      <td class="br-rpt-out">${fmtMoney(t.credit)}</td>
    </tr>`).join('');
  }

  // Bank items: statement convention — credit=in, debit=out
  function buildBankRows(items) {
    if (!items.length) return `<tr><td colspan="5" class="br-rpt-empty">No unreconciled bank items</td></tr>`;
    return items.map(t => `<tr>
      <td class="br-rpt-date">${_isoToAu(t.date)}</td>
      <td class="br-rpt-desc">${esc(t.description)}</td>
      <td class="br-rpt-ref">${esc(t.reference||'')}</td>
      <td class="br-rpt-in">${fmtMoney(t.credit)}</td>
      <td class="br-rpt-out">${fmtMoney(t.debit)}</td>
    </tr>`).join('');
  }

  const diff     = data.difference;
  const balanced = Math.abs(diff) < 0.005;
  const diffCls  = balanced ? 'br-rpt-bal-ok' : 'br-rpt-bal-bad';
  const diffTxt  = balanced ? `${_fmtAmt(0)} ✓` : `${_fmtAmt(Math.abs(diff))} ✗`;

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box br-rpt-box">
      <div class="modal-hdr">
        <span>Bank Reconciliation Report</span>
        <div style="display:flex;gap:8px;margin-left:auto">
          <button class="btn btn-outline btn-sm" onclick="window.print()">🖨 Print</button>
          <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">✕ Close</button>
        </div>
      </div>
      <div class="modal-body br-rpt-body" id="br-rpt-content">

        <div class="br-rpt-header">
          <div class="br-rpt-title">${esc(acc.code)} — ${esc(acc.name)}</div>
          <div class="br-rpt-subtitle">As at ${_isoToAu(data.as_at)}</div>
        </div>

        <!-- Section A: GL -->
        <div class="br-rpt-section">
          <div class="br-rpt-sec-hdr">A — Balance per General Ledger</div>
          <table class="br-rpt-tbl">
            <thead><tr>
              <th class="br-rpt-date">Date</th>
              <th class="br-rpt-desc">Description</th>
              <th class="br-rpt-ref">Reference</th>
              <th class="br-rpt-in">Money In</th>
              <th class="br-rpt-out">Money Out</th>
            </tr></thead>
            <tbody>
              <tr class="br-rpt-opening">
                <td class="br-rpt-date">${lastRecDate}</td>
                <td class="br-rpt-desc" colspan="2">Last reconciliation balance</td>
                <td class="br-rpt-in">${_fmtAmt(data.last_rec_balance)}</td>
                <td class="br-rpt-out"></td>
              </tr>
              ${buildGLRows(data.unreconciled_gl)}
            </tbody>
          </table>
          <div class="br-rpt-total-row">
            <span>GL Balance per books &nbsp;<span class="br-rpt-count">${data.unreconciled_gl.length} unreconciled item${data.unreconciled_gl.length!==1?'s':''}</span></span>
            <span class="br-rpt-total-amt">${_fmtAmt(data.gl_balance)}</span>
          </div>
        </div>

        <!-- Section B: Bank Statement -->
        <div class="br-rpt-section">
          <div class="br-rpt-sec-hdr">B — Balance per Bank Statement</div>
          <table class="br-rpt-tbl">
            <thead><tr>
              <th class="br-rpt-date">Date</th>
              <th class="br-rpt-desc">Description</th>
              <th class="br-rpt-ref">Reference</th>
              <th class="br-rpt-in">Money In</th>
              <th class="br-rpt-out">Money Out</th>
            </tr></thead>
            <tbody>
              <tr class="br-rpt-opening">
                <td class="br-rpt-date">${lastRecDate}</td>
                <td class="br-rpt-desc" colspan="2">Last reconciliation balance</td>
                <td class="br-rpt-in">${_fmtAmt(data.last_rec_balance)}</td>
                <td class="br-rpt-out"></td>
              </tr>
              ${buildBankRows(data.unreconciled_bank)}
            </tbody>
          </table>
          <div class="br-rpt-total-row">
            <span>Bank Statement Balance &nbsp;<span class="br-rpt-count">${data.unreconciled_bank.length} unreconciled item${data.unreconciled_bank.length!==1?'s':''}</span></span>
            <span class="br-rpt-total-amt">${_fmtAmt(data.bank_balance)}</span>
          </div>
        </div>

        <!-- Difference -->
        <div class="br-rpt-diff-row ${diffCls}">
          <span>Difference (A − B)</span>
          <span class="br-rpt-diff-amt">${diffTxt}</span>
        </div>

      </div>
    </div>`;

  document.body.appendChild(bd);
}

// ── Date Range Report ─────────────────────────────────────────────────────────
function _brShowDateReportPrompt() {
  if (!_brAccId) { _brToast('Select an account first.'); return; }

  // Default: 1st – last of previous month
  const now  = new Date();
  const pf   = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const pl   = new Date(now.getFullYear(), now.getMonth(), 0);
  const pad  = n => String(n).padStart(2, '0');
  const fromDef = `${pf.getFullYear()}-${pad(pf.getMonth()+1)}-01`;
  const toDef   = `${pl.getFullYear()}-${pad(pl.getMonth()+1)}-${pad(pl.getDate())}`;

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'br-dr-prompt';
  bd.innerHTML = `<div class="modal-box" style="max-width:320px">
    <div class="modal-hdr"><span>Date Range Report</span></div>
    <div class="modal-body" style="display:flex;flex-direction:column;gap:14px">
      <div class="br-alloc-field">
        <label>From</label>
        <input type="date" id="br-dr-from" value="${fromDef}" style="width:100%">
      </div>
      <div class="br-alloc-field">
        <label>To</label>
        <input type="date" id="br-dr-to" value="${toDef}" style="width:100%">
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-outline" onclick="document.getElementById('br-dr-prompt').remove()">Cancel</button>
      <button class="btn btn-primary" onclick="_brRunDateReport()">Generate</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

async function _brRunDateReport() {
  const from = document.getElementById('br-dr-from')?.value;
  const to   = document.getElementById('br-dr-to')?.value;
  if (!from || !to) { _brToast('Select both dates.', true); return; }
  if (from > to)   { _brToast('From date must be before To date.', true); return; }
  document.getElementById('br-dr-prompt')?.remove();
  await _brShowDateReport(from, to);
}

async function _brShowDateReport(from, to) {
  if (!_brAccId) { _brToast('Select an account first.'); return; }
  let data;
  try {
    data = await apiFetch(`/api/bankrec/${_brAccId}/date-report?from=${from}&to=${to}`);
  } catch(e) {
    _brToast('Error loading report: ' + e.message, true); return;
  }

  const acc = data.account;

  function fmtMoney(v) {
    const n = parseFloat(v || 0);
    if (Math.abs(n) < 0.005) return '';
    return '$' + n.toLocaleString('en-AU', {minimumFractionDigits:2, maximumFractionDigits:2});
  }
  function buildRows(items, bankConvention) {
    return items.map(t => `<tr>
      <td class="br-rpt-date">${_isoToAu(t.date)}</td>
      <td class="br-rpt-desc">${esc(t.description)}</td>
      <td class="br-rpt-ref">${esc(t.reference||'')}</td>
      <td class="br-rpt-in">${bankConvention ? fmtMoney(t.credit) : fmtMoney(t.debit)}</td>
      <td class="br-rpt-out">${bankConvention ? fmtMoney(t.debit) : fmtMoney(t.credit)}</td>
    </tr>`).join('');
  }
  function tblWrap(rows, emptyMsg) {
    return `<table class="br-rpt-tbl">
      <thead><tr>
        <th class="br-rpt-date">Date</th><th class="br-rpt-desc">Description</th>
        <th class="br-rpt-ref">Reference</th><th class="br-rpt-in">Money In</th>
        <th class="br-rpt-out">Money Out</th>
      </tr></thead>
      <tbody>${rows || `<tr><td colspan="5" class="br-rpt-empty">${emptyMsg}</td></tr>`}</tbody>
    </table>`;
  }

  const diff     = data.difference;
  const balanced = Math.abs(diff) < 0.005;
  const diffCls  = balanced ? 'br-rpt-bal-ok' : 'br-rpt-bal-bad';
  const diffTxt  = balanced ? `${_fmtAmt(0)} ✓` : `${_fmtAmt(Math.abs(diff))} ✗`;

  const bankLabel = data.bank_authoritative
    ? 'Closing balance per bank statement'
    : 'Estimated closing balance';
  const bankNote = data.bank_authoritative ? '' : (data.last_rec
    ? `⚠ Estimated — based on reconciliation of ${_isoToAu(data.last_rec.reconcile_date)} plus imported bank transactions to ${_isoToAu(to)}. May not reflect actual bank balance.`
    : `⚠ No reconciliation on record — bank balance derived from imported transactions only. May not reflect actual bank balance.`);

  const hasOutGL   = data.outstanding_gl.length > 0;
  const hasOutBank = data.outstanding_bank.length > 0;
  const hasOut     = hasOutGL || hasOutBank;

  const outGLNet   = data.outstanding_gl_net;
  const outBankNet = data.outstanding_bank_net;

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box br-rpt-box">
      <div class="modal-hdr">
        <span>Bank Reconciliation — Date Range Report</span>
        <div style="display:flex;gap:8px;margin-left:auto">
          <button class="btn btn-outline btn-sm" onclick="window.print()">🖨 Print</button>
          <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">✕ Close</button>
        </div>
      </div>
      <div class="modal-body br-rpt-body" id="br-rpt-content">
        <div class="br-rpt-header">
          <div class="br-rpt-title">${esc(acc.code)} — ${esc(acc.name)}</div>
          <div class="br-rpt-subtitle">${_isoToAu(from)} – ${_isoToAu(to)}</div>
        </div>

        <!-- Section A: GL transactions in period -->
        <div class="br-rpt-section">
          <div class="br-rpt-sec-hdr">A — General Ledger Transactions</div>
          <table class="br-rpt-tbl">
            <thead><tr>
              <th class="br-rpt-date">Date</th><th class="br-rpt-desc">Description</th>
              <th class="br-rpt-ref">Reference</th>
              <th class="br-rpt-in">Money In</th><th class="br-rpt-out">Money Out</th>
            </tr></thead>
            <tbody>
              <tr class="br-rpt-opening">
                <td class="br-rpt-date">${_isoToAu(from)}</td>
                <td class="br-rpt-desc" colspan="2">Opening balance</td>
                <td class="br-rpt-in">${_fmtAmt(data.gl_opening)}</td>
                <td></td>
              </tr>
              ${data.gl_items.length
                ? buildRows(data.gl_items, false)
                : `<tr><td colspan="5" class="br-rpt-empty">No GL transactions in this period</td></tr>`}
            </tbody>
          </table>
          <div class="br-rpt-total-row">
            <span>GL Closing Balance &nbsp;<span class="br-rpt-count">${data.gl_items.length} transaction${data.gl_items.length!==1?'s':''}</span></span>
            <span class="br-rpt-total-amt">${_fmtAmt(data.gl_closing)}</span>
          </div>
        </div>

        <!-- Section B: Outstanding items -->
        <div class="br-rpt-section">
          <div class="br-rpt-sec-hdr">B — Outstanding Items at ${_isoToAu(to)}</div>
          ${hasOut ? `
            ${hasOutGL ? `
              <div style="font-size:0.82rem;color:var(--ink2);margin-bottom:4px">
                In general ledger, not yet cleared on bank statement (${data.outstanding_gl.length})
              </div>
              ${tblWrap(buildRows(data.outstanding_gl, false), '')}
              <div class="br-rpt-total-row" style="margin-bottom:12px">
                <span>Net outstanding GL</span>
                <span class="br-rpt-total-amt">${_fmtAmt(outGLNet)}</span>
              </div>` : ''}
            ${hasOutBank ? `
              <div style="font-size:0.82rem;color:var(--ink2);margin-bottom:4px;margin-top:${hasOutGL?'4px':'0'}">
                Imported from bank, not yet posted to GL (${data.outstanding_bank.length})
              </div>
              ${tblWrap(buildRows(data.outstanding_bank, true), '')}
              <div class="br-rpt-total-row" style="margin-bottom:12px">
                <span>Net outstanding bank imports</span>
                <span class="br-rpt-total-amt">${_fmtAmt(outBankNet)}</span>
              </div>` : ''}
          ` : `<div class="br-rpt-empty" style="padding:16px 0">No outstanding items at ${_isoToAu(to)}</div>`}
          <div class="br-rpt-total-row" style="font-weight:700;border-top:2px solid var(--border);padding-top:8px">
            <span>Adjusted GL Balance</span>
            <span class="br-rpt-total-amt">${_fmtAmt(data.adjusted_gl)}</span>
          </div>
        </div>

        <!-- Section C: Confirmed bank balance -->
        <div class="br-rpt-section">
          <div class="br-rpt-sec-hdr">C — Bank Balance</div>
          <div class="br-rpt-total-row">
            <span>${esc(bankLabel)}</span>
            <span class="br-rpt-total-amt">${_fmtAmt(data.bank_balance)}</span>
          </div>
          ${bankNote ? `<div style="font-size:0.82rem;color:var(--amber);padding:8px 0 0">${esc(bankNote)}</div>` : ''}
        </div>

        <!-- Difference -->
        <div class="br-rpt-diff-row ${diffCls}">
          <span>Difference (Adjusted GL − Bank)</span>
          <span class="br-rpt-diff-amt">${diffTxt}</span>
        </div>
      </div>
    </div>`;
  document.body.appendChild(bd);
}

// ── Past Reconciliations ──────────────────────────────────────────────────────
async function _brShowPastRecs() {
  if (!_brAccId) { _brToast('Select an account first.'); return; }

  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = 'Past Reconciliations';
  document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading…</div>';
  document.getElementById('det-foot').innerHTML = '';

  let recs, dups;
  try {
    [recs, dups] = await Promise.all([
      apiFetch(`/api/bankrec/${_brAccId}/reconciliations`),
      apiFetch(`/api/bankrec/${_brAccId}/duplicate-allocations`),
    ]);
  } catch(e) {
    document.getElementById('det-body').innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
    return;
  }

  const dupBanner = dups.length > 0
    ? `<div class="br-orphan-banner">
        <span>${dups.length} duplicate bank allocation entr${dups.length===1?'y':'ies'} found — posted twice to this account, inflating the GL balance.
        Each will be reversed (a correcting journal is created; original entries are unchanged).</span>
        <button class="btn btn-sm btn-primary" onclick="_brVoidDups(${JSON.stringify(dups.map(d=>d.id))})">Reverse All</button>
       </div>`
    : '';

  const rows = recs.length
    ? recs.map(r => `<tr>
        <td>${_isoToAu(r.reconcile_date)}</td>
        <td class="td-r">${_fmtAmt(r.opening_balance)}</td>
        <td class="td-r">${_fmtAmt(r.closing_balance)}</td>
        <td><span class="badge badge-paid">${esc(r.status)}</span></td>
        <td style="display:flex;gap:4px">
          <button class="btn btn-outline btn-sm"
              onclick="detClose();_brShowPeriodReport(${r.id})">View</button>
          <button class="btn btn-outline btn-sm"
              onclick="_brCorrectRec(${r.id},${parseFloat(r.closing_balance||0)})">Correct</button>
        </td>
      </tr>`).join('')
    : `<tr><td colspan="5" class="det-empty">No reconciliations yet</td></tr>`;

  document.getElementById('det-body').innerHTML = `
    ${dupBanner}
    <table class="inv-list-table" style="width:100%">
      <thead><tr>
        <th>Date</th><th class="th-r">Opening</th>
        <th class="th-r">Closing</th><th>Status</th><th></th>
      </tr></thead>
      <tbody>${rows}</tbody>
    </table>`;

  document.getElementById('det-foot').innerHTML =
    `<button class="btn btn-outline" onclick="detClose()">Close</button>`;
}

async function _brVoidDups(journalIds) {
  if (!journalIds.length) return;
  const n = journalIds.length;
  if (!confirm(`Reverse ${n} duplicate allocation entr${n===1?'y':'ies'}?\n\nThis posts a correcting journal for each. The original entries are not deleted.`)) return;
  try {
    const r = await fetch(`/api/bankrec/${_brAccId}/void-duplicate-allocations`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ journal_ids: journalIds }),
    });
    const d = await r.json();
    if (!d.ok) throw new Error(d.error || 'Failed');
    _brToast(`${d.data.voided} duplicate entr${d.data.voided===1?'y':'ies'} reversed — GL balance corrected.`);
    await _brShowPastRecs();
    await _brLoad();
  } catch(e) {
    _brToast('Error: ' + e.message, true);
  }
}


async function _brShowPeriodReport(recId) {
  if (!_brAccId) { _brToast('Select an account first.'); return; }
  let data;
  try {
    data = await apiFetch(`/api/bankrec/${_brAccId}/reconciliations/${recId}/report`);
  } catch(e) {
    _brToast('Error loading report: ' + e.message, true); return;
  }

  const acc  = data.account;
  const rec  = data.reconciliation;
  const prev = data.prev_reconciliation;
  const prevDate   = prev ? _isoToAu(prev.reconcile_date) : '—';
  const opening    = parseFloat(rec.opening_balance || 0);
  const closingExp = parseFloat(rec.closing_balance || 0);

  function fmtMoney(v) {
    const n = parseFloat(v || 0);
    if (Math.abs(n) < 0.005) return '';
    return '$' + n.toLocaleString('en-AU', {minimumFractionDigits:2, maximumFractionDigits:2});
  }
  function buildGLRows(items) {
    if (!items.length) return `<tr><td colspan="5" class="br-rpt-empty">No GL items reconciled this period</td></tr>`;
    return items.map(t => `<tr>
      <td class="br-rpt-date">${_isoToAu(t.date)}</td>
      <td class="br-rpt-desc">${esc(t.description)}</td>
      <td class="br-rpt-ref">${esc(t.reference||'')}</td>
      <td class="br-rpt-in">${fmtMoney(t.debit)}</td>
      <td class="br-rpt-out">${fmtMoney(t.credit)}</td>
    </tr>`).join('');
  }
  function buildBankRows(items) {
    if (!items.length) return `<tr><td colspan="5" class="br-rpt-empty">No bank items reconciled this period</td></tr>`;
    return items.map(t => `<tr>
      <td class="br-rpt-date">${_isoToAu(t.date)}</td>
      <td class="br-rpt-desc">${esc(t.description)}</td>
      <td class="br-rpt-ref">${esc(t.reference||'')}</td>
      <td class="br-rpt-in">${fmtMoney(t.credit)}</td>
      <td class="br-rpt-out">${fmtMoney(t.debit)}</td>
    </tr>`).join('');
  }

  const isLiabRpt = acc.account_type === 'Liability';
  const glNet  = data.reconciled_gl.reduce((s,t) => {
    const d = parseFloat(t.debit||0), c = parseFloat(t.credit||0);
    return s + (isLiabRpt ? c - d : d - c);
  }, 0);
  const glClose = Math.round((opening + glNet) * 100) / 100;
  // diff: GL computed closing vs user-confirmed bank statement closing
  const diff    = Math.round((glClose - closingExp) * 100) / 100;
  const balanced = Math.abs(diff) < 0.005;
  const diffCls  = balanced ? 'br-rpt-bal-ok' : 'br-rpt-bal-bad';
  const diffTxt  = balanced ? `${_fmtAmt(0)} ✓` : `${_fmtAmt(Math.abs(diff))} ✗`;

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box br-rpt-box">
      <div class="modal-hdr">
        <span>Period Reconciliation Report</span>
        <div style="display:flex;gap:8px;margin-left:auto">
          <button class="btn btn-outline btn-sm" onclick="window.print()">🖨 Print</button>
          <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">✕ Close</button>
        </div>
      </div>
      <div class="modal-body br-rpt-body" id="br-rpt-content">
        <div class="br-rpt-header">
          <div class="br-rpt-title">${esc(acc.code)} — ${esc(acc.name)}</div>
          <div class="br-rpt-subtitle">Reconciled ${_isoToAu(rec.reconcile_date)}
            &nbsp;·&nbsp; Period: ${prevDate} → ${_isoToAu(rec.reconcile_date)}</div>
        </div>

        <!-- Section A: GL -->
        <div class="br-rpt-section">
          <div class="br-rpt-sec-hdr">A — General Ledger</div>
          <table class="br-rpt-tbl">
            <thead><tr>
              <th class="br-rpt-date">Date</th>
              <th class="br-rpt-desc">Description</th>
              <th class="br-rpt-ref">Reference</th>
              <th class="br-rpt-in">Money In</th>
              <th class="br-rpt-out">Money Out</th>
            </tr></thead>
            <tbody>
              <tr class="br-rpt-opening">
                <td class="br-rpt-date">${prevDate}</td>
                <td class="br-rpt-desc" colspan="2">Opening balance</td>
                <td class="br-rpt-in">${_fmtAmt(opening)}</td>
                <td class="br-rpt-out"></td>
              </tr>
              ${buildGLRows(data.reconciled_gl)}
            </tbody>
          </table>
          <div class="br-rpt-total-row">
            <span>GL Closing Balance &nbsp;<span class="br-rpt-count">${data.reconciled_gl.length} item${data.reconciled_gl.length!==1?'s':''}</span></span>
            <span class="br-rpt-total-amt">${_fmtAmt(glClose)}</span>
          </div>
        </div>

        <!-- Section B: Bank Statement -->
        <div class="br-rpt-section">
          <div class="br-rpt-sec-hdr">B — Bank Statement</div>
          <div class="br-rpt-total-row" style="margin-bottom:12px">
            <span>Closing balance per bank statement</span>
            <span class="br-rpt-total-amt">${_fmtAmt(closingExp)}</span>
          </div>
          ${data.reconciled_bank.length ? `
          <div style="font-size:0.82rem;color:var(--ink2);margin-bottom:6px">
            Matched bank transactions (${data.reconciled_bank.length})
          </div>
          <table class="br-rpt-tbl">
            <thead><tr>
              <th class="br-rpt-date">Date</th>
              <th class="br-rpt-desc">Description</th>
              <th class="br-rpt-ref">Reference</th>
              <th class="br-rpt-in">Money In</th>
              <th class="br-rpt-out">Money Out</th>
            </tr></thead>
            <tbody>${buildBankRows(data.reconciled_bank)}</tbody>
          </table>` : ''}
        </div>

        <!-- Difference -->
        <div class="br-rpt-diff-row ${diffCls}">
          <span>Difference (A − B)</span>
          <span class="br-rpt-diff-amt">${diffTxt}</span>
        </div>
      </div>
    </div>`;
  document.body.appendChild(bd);
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function _fmtAmt(n) {
  return '$' + parseFloat(n||0).toLocaleString('en-AU', {minimumFractionDigits:2, maximumFractionDigits:2});
}

function _isoToAu(s) {
  if (!s) return '';
  const [y,m,d] = s.split('-');
  return d && m && y ? `${d}/${m}/${y}` : s;
}

function _auDateToIso(s) {
  if (!s) return '';
  const parts = s.split('/');
  if (parts.length === 3) {
    const [d,m,y] = parts;
    const yr = y.length === 2 ? '20'+y : y;
    return `${yr}-${m.padStart(2,'0')}-${d.padStart(2,'0')}`;
  }
  return s; // already ISO or unrecognised
}


function _brToast(msg, isErr=false) {
  toast(msg, isErr ? 'err' : 'ok');
}
