// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ══════════════════════════════════════════════════════════════════════════════
//  FIXED ASSETS — Web UI module
//  Namespace: _fa*
//  Entry:     pageFixedAssets()
//
//  Features:
//    • Asset register list with status filter pills + search
//    • Slide-over: asset detail + depreciation schedule tab
//    • New / Edit asset form (slide-over)
//    • Dispose asset dialog (modal)
//    • Post FY Depreciation dialog (modal)
//    • Asset Register PDF download
//    • ATO effective life lookup
//    • Category auto-fills GL accounts + method + life
// ══════════════════════════════════════════════════════════════════════════════

"use strict";

// ── Module state ─────────────────────────────────────────────────────────────
let _faAll        = [];   // full asset list from server
let _faFilter     = "All"; // active status filter
let _faSearch     = "";
let _faSortCol    = "acquisition_date";
let _faSortAsc    = false;
let _faAccounts   = [];   // all GL accounts

// ── Constants ─────────────────────────────────────────────────────────────────
const _FA_METHODS = [
    "Prime Cost",
    "Diminishing Value",
    "Instant Write-Off",
    "Low-Value Pool",
    "Small Business Pool",
];

const _FA_STATUSES = ["All", "Active", "Fully Depreciated", "Disposed"];

// ── Entry point ───────────────────────────────────────────────────────────────
async function pageFixedAssets() {
    document.getElementById("module-content").innerHTML = `
        <div class="inv-toolbar">
            <input class="inv-search" id="fa-search" placeholder="Search assets…" oninput="_faOnSearch(this.value)">
            <div class="inv-filter-group" id="fa-filter-pills"></div>
            <button class="btn btn-primary btn-sm" onclick="_faNewAsset()">+ Add Asset</button>
            <button class="btn btn-outline btn-sm" onclick="_faPostFYDialog()">📅 Post FY Depreciation</button>
            <button class="btn btn-outline btn-sm" onclick="_faDownloadPDF()">📄 Register PDF</button>
            <button class="btn btn-outline btn-sm" onclick="window.open('/api/fixed-assets/schedule-csv','_blank')">⬇ Export CSV</button>
        </div>

        <div class="inv-list-panel">
            <div class="tbl-overflow-x">
                <table class="inv-list-table" id="fa-table">
                    <thead>
                        <tr>
                            <th id="fa-th-num"   onclick="_faSort('asset_number')">Asset No</th>
                            <th id="fa-th-desc"  onclick="_faSort('description')">Description</th>
                            <th id="fa-th-cat"   onclick="_faSort('category')">Category</th>
                            <th id="fa-th-acq"   onclick="_faSort('acquisition_date')" class="sort-desc">Acquired</th>
                            <th id="fa-th-cost"  onclick="_faSort('cost_excl_gst')" class="th-r">Cost (ex GST)</th>
                            <th id="fa-th-meth"  onclick="_faSort('depn_method')">Method</th>
                            <th id="fa-th-life"  onclick="_faSort('effective_life_years')" class="th-r">Life</th>
                            <th id="fa-th-accum" onclick="_faSort('accum_depn')" class="th-r">Accum Depr</th>
                            <th id="fa-th-wdv"   onclick="_faSort('current_wdv')" class="th-r">WDV</th>
                            <th id="fa-th-stat"  onclick="_faSort('status')">Status</th>
                        </tr>
                    </thead>
                    <tbody id="fa-tbody"></tbody>
                </table>
            </div>
        </div>

        <div class="mt-8 fa-footer-row" id="fa-footer-row">
            <span class="count-pill" id="fa-count"></span>
            <span class="col-ink3 fa-summary" id="fa-summary"></span>
        </div>

        <!-- Slide-over -->
        <div class="det-overlay" id="fa-overlay" onclick="faDetClose()"></div>
        <div class="det-panel" id="fa-panel">
            <div class="det-hdr">
                <span class="det-title" id="fa-panel-title">Asset Detail</span>
                <button class="det-close" onclick="faDetClose()">✕</button>
            </div>
            <div class="det-body" id="fa-body"></div>
            <div class="det-foot" id="fa-foot"></div>
        </div>
    `;

    _faBuildFilterPills();
    await _faLoadAccounts();
    await _faLoad();
}

// ── Filter pills ──────────────────────────────────────────────────────────────
function _faBuildFilterPills() {
    const c = document.getElementById("fa-filter-pills");
    c.innerHTML = _FA_STATUSES.map(s => `
        <button class="filter-btn${s === _faFilter ? " active" : ""}"
                onclick="_faSetFilter('${s}')">${s}</button>
    `).join("");
}

function _faSetFilter(s) {
    _faFilter = s;
    _faBuildFilterPills();
    _faRender();
}

function _faOnSearch(v) {
    _faSearch = v.trim().toLowerCase();
    _faRender();
}

// ── Data ──────────────────────────────────────────────────────────────────────
async function _faLoad() {
    document.getElementById("fa-tbody").innerHTML =
        `<tr><td colspan="10" class="state-loading">Loading…</td></tr>`;
    try {
        _faAll = await apiFetch("/api/fixed-assets");
        _faRender();
    } catch (e) {
        document.getElementById("fa-tbody").innerHTML =
            `<tr><td colspan="10" class="state-error">Failed to load: ${e.message}</td></tr>`;
    }
}

async function _faLoadAccounts() {
    try {
        _faAccounts = await apiFetch("/api/accounts");
    } catch (_) {
        _faAccounts = [];
    }
}

// ── Render list ───────────────────────────────────────────────────────────────
function _faRender() {
    let rows = _faAll.slice();

    // Status filter
    if (_faFilter !== "All") {
        rows = rows.filter(a => a.status === _faFilter);
    }

    // Search
    if (_faSearch) {
        rows = rows.filter(a =>
            (a.description   || "").toLowerCase().includes(_faSearch) ||
            (a.asset_number  || "").toLowerCase().includes(_faSearch) ||
            (a.category      || "").toLowerCase().includes(_faSearch)
        );
    }

    // Sort
    rows.sort((a, b) => {
        let va = a[_faSortCol] ?? "";
        let vb = b[_faSortCol] ?? "";
        if (typeof va === "number" && typeof vb === "number") {
            return _faSortAsc ? va - vb : vb - va;
        }
        va = String(va); vb = String(vb);
        return _faSortAsc ? va.localeCompare(vb) : vb.localeCompare(va);
    });

    const tbody = document.getElementById("fa-tbody");
    if (!rows.length) {
        tbody.innerHTML = `<tr><td colspan="10" class="det-empty">No assets found.</td></tr>`;
    } else {
        tbody.innerHTML = rows.map((a, i) => {
            const cost  = a.cost_excl_gst ?? a.cost_price ?? 0;
            const accum = a.accum_depn ?? 0;
            const wdv   = a.current_wdv ?? (cost - accum);
            const life  = a.effective_life_years ? `${a.effective_life_years} yrs` : "—";
            const badge = _faBadge(a.status);
            const rowCls = a.status === "Disposed" ? " col-ink3"
                         : a.status === "Fully Depreciated" ? " col-amber" : "";
            return `<tr class="inv-row" onclick="_faOpenDetail(${a.id})">
                <td><span class="inv-mono">${_h(a.asset_number || `#${a.id}`)}</span></td>
                <td><span class="inv-contact${rowCls}">${_h(a.description)}</span></td>
                <td><span class="td-sm col-ink3">${_h(a.category_label || a.category || "—")}</span></td>
                <td><span class="inv-mono">${fmtDate(a.acquisition_date)}</span></td>
                <td class="inv-amt">${_fmtAmt(cost)}</td>
                <td><span class="td-sm">${_h(a.depn_method || "—")}</span></td>
                <td class="td-r-mono">${life}</td>
                <td class="inv-amt">${_fmtAmt(accum)}</td>
                <td class="inv-amt">${_fmtAmt(wdv)}</td>
                <td>${badge}</td>
            </tr>`;
        }).join("");
    }

    // Footer
    const n     = rows.length;
    const total = rows.reduce((s, a) => s + (a.cost_excl_gst ?? a.cost_price ?? 0), 0);
    const accum = rows.reduce((s, a) => s + (a.accum_depn ?? 0), 0);
    const wdv   = rows.reduce((s, a) => s + (a.current_wdv ?? 0), 0);
    document.getElementById("fa-count").textContent = `${n} asset${n !== 1 ? "s" : ""}`;
    document.getElementById("fa-summary").textContent =
        `Cost ${_fmtAmt(total)}  ·  Accum ${_fmtAmt(accum)}  ·  Net WDV ${_fmtAmt(wdv)}`;
}

// ── Sort ──────────────────────────────────────────────────────────────────────
function _faSort(col) {
    if (_faSortCol === col) {
        _faSortAsc = !_faSortAsc;
    } else {
        _faSortCol = col;
        _faSortAsc = false;
    }
    // Update header classes
    document.querySelectorAll("#fa-table th").forEach(th => {
        th.classList.remove("sort-asc", "sort-desc");
    });
    const thMap = {
        asset_number: "fa-th-num", description: "fa-th-desc",
        category: "fa-th-cat", acquisition_date: "fa-th-acq",
        cost_excl_gst: "fa-th-cost", depn_method: "fa-th-meth",
        effective_life_years: "fa-th-life", accum_depn: "fa-th-accum",
        current_wdv: "fa-th-wdv", status: "fa-th-stat",
    };
    if (thMap[col]) {
        document.getElementById(thMap[col])?.classList.add(_faSortAsc ? "sort-asc" : "sort-desc");
    }
    _faRender();
}

// ── Slide-over: detail ────────────────────────────────────────────────────────
async function _faOpenDetail(id) {
    document.getElementById("fa-overlay").classList.add("open");
    document.getElementById("fa-panel").classList.add("open");
    document.getElementById("fa-body").innerHTML = `<div class="state-loading">Loading…</div>`;
    document.getElementById("fa-foot").innerHTML = "";

    try {
        const [asset, schedule] = await Promise.all([
            apiFetch(`/api/fixed-assets/${id}`),
            apiFetch(`/api/fixed-assets/${id}/schedule`),
        ]);

        document.getElementById("fa-panel-title").textContent =
            asset.description || `Asset #${id}`;

        _faRenderDetail(asset, schedule);
    } catch (e) {
        document.getElementById("fa-body").innerHTML =
            `<div class="state-error">Failed to load: ${e.message}</div>`;
    }
}

function _faRenderDetail(a, schedule) {
    const cost  = a.cost_excl_gst ?? a.cost_price ?? 0;
    const accum = schedule.filter(r => r.posted).reduce((s, r) => s + (r.depn_amount ?? 0), 0);
    const wdv   = cost - accum;
    // Enrich so _faDisposeDialog has correct WDV even though api_fa_get omits these
    a.accum_depn  = accum;
    a.current_wdv = wdv;

    const body = document.getElementById("fa-body");
    body.innerHTML = `
        <!-- Summary cards -->
        <div class="fa-stat-grid">
            ${_faCard("Cost (ex GST)", _fmtAmt(cost), "col-ink")}
            ${_faCard("Accum Depr", _fmtAmt(accum), "col-amber")}
            ${_faCard("Net WDV", _fmtAmt(wdv), wdv > 0 ? "col-green" : "col-ink3")}
        </div>

        <!-- Tabs -->
        <div class="det-tabs">
            <div class="det-tab active" id="fa-tab-detail" onclick="_faTab('detail')">Details</div>
            <div class="det-tab"        id="fa-tab-sched"  onclick="_faTab('sched')">Depreciation Schedule</div>
        </div>

        <!-- Detail pane -->
        <div class="det-pane active" id="fa-pane-detail">
            <div class="det-meta">
                <div><div class="det-lbl">Asset No.</div><div class="det-val mono">${_h(a.asset_number || `#${a.id}`)}</div></div>
                <div><div class="det-lbl">Status</div><div class="det-val">${_faBadge(a.status)}</div></div>
                <div><div class="det-lbl">Category</div><div class="det-val">${_h(a.category_label || a.category || "—")}</div></div>
                <div><div class="det-lbl">Acquired</div><div class="det-val mono">${fmtDate(a.acquisition_date)}</div></div>
                <div><div class="det-lbl">Cost incl GST</div><div class="det-val mono">${_fmtAmt(a.cost_price ?? 0)}</div></div>
                <div><div class="det-lbl">Residual Value</div><div class="det-val mono">${_fmtAmt(a.residual_value ?? 0)}</div></div>
                <div><div class="det-lbl">Depn Method</div><div class="det-val">${_h(a.depn_method || "—")}</div></div>
                <div><div class="det-lbl">Effective Life</div><div class="det-val mono">${a.effective_life_years ? `${a.effective_life_years} yrs` : "—"}</div></div>
                <div><div class="det-lbl">Asset Account</div><div class="det-val mono col-ink3">${_h(a.asset_account_code ? `${a.asset_account_code} – ${a.asset_account_name}` : "—")}</div></div>
                <div><div class="det-lbl">Accum Depr A/c</div><div class="det-val mono col-ink3">${_h(a.accum_depn_account_code ? `${a.accum_depn_account_code} – ${a.accum_depn_account_name}` : "—")}</div></div>
                <div><div class="det-lbl">Depn Expense A/c</div><div class="det-val mono col-ink3">${_h(a.depn_expense_account_code ? `${a.depn_expense_account_code} – ${a.depn_expense_account_name}` : "—")}</div></div>
                ${a.source_type ? `<div><div class="det-lbl">Source</div><div class="det-val col-ink3">${_h(a.source_type)} ${_h(a.source_ref || "")}${a.source_supplier ? ` — ${_h(a.source_supplier)}` : ""}</div></div>` : ""}
                ${a.disposal_date ? `<div><div class="det-lbl">Disposed</div><div class="det-val col-red">${fmtDate(a.disposal_date)} — Proceeds ${_fmtAmt(a.disposal_proceeds ?? 0)}</div></div>` : ""}
            </div>
            ${a.notes ? `<div class="det-section-title">Notes</div><div class="det-note">${_h(a.notes)}</div>` : ""}
        </div>

        <!-- Schedule pane -->
        <div class="det-pane" id="fa-pane-sched">
            <div class="fa-sched-mb">
                <button class="btn btn-outline btn-sm" onclick="_faRegenerateSchedule(${a.id})">🔄 Regenerate Schedule</button>
            </div>
            ${_faRenderScheduleTable(schedule)}
        </div>
    `;

    // Footer buttons
    const foot = document.getElementById("fa-foot");
    foot.innerHTML = "";

    if (a.status !== "Disposed") {
        const btnEdit = document.createElement("button");
        btnEdit.className = "btn btn-primary btn-sm";
        btnEdit.textContent = "✎ Edit";
        btnEdit.onclick = () => _faEditAsset(a.id);
        foot.appendChild(btnEdit);

        const btnDispose = document.createElement("button");
        btnDispose.className = "btn btn-orange btn-sm";
        btnDispose.textContent = "Dispose…";
        btnDispose.onclick = () => _faDisposeDialog(a);
        foot.appendChild(btnDispose);
    }

    if (a.status === "Active") {
        const btnPost = document.createElement("button");
        btnPost.className = "btn btn-outline btn-sm";
        btnPost.textContent = "📅 Post Depreciation…";
        btnPost.onclick = () => _faPostFYDialog(a.id);
        foot.appendChild(btnPost);
    }

    if (!a.disposal_date) {
        const btnDel = document.createElement("button");
        btnDel.className = "btn btn-danger btn-sm";
        btnDel.textContent = "Delete";
        btnDel.onclick = () => _faDeleteAsset(a.id, a.description);
        foot.appendChild(btnDel);
    }
}

function _faCard(label, value, colorCls) {
    return `<div class="fa-stat-card">
        <div class="det-lbl">${label}</div>
        <div class="fa-stat-val ${colorCls}">${value}</div>
    </div>`;
}

function _faRenderScheduleTable(schedule) {
    if (!schedule.length) return `<div class="det-empty">No depreciation schedule generated yet.</div>`;
    return `
        <table class="inv-list-table fa-sched-tbl">
            <thead><tr>
                <th>FY Year</th>
                <th class="th-r">Opening WDV</th>
                <th class="th-r">Depreciation</th>
                <th class="th-r">Closing WDV</th>
                <th>Posted</th>
                <th>Notes</th>
            </tr></thead>
            <tbody>
                ${schedule.map(r => `
                    <tr class="inv-row">
                        <td class="inv-mono">FY${r.fy_year - 1}/${String(r.fy_year).slice(-2)}</td>
                        <td class="inv-amt">${_fmtAmt(r.opening_wdv)}</td>
                        <td class="inv-amt">${_fmtAmt(r.depn_amount)}</td>
                        <td class="inv-amt">${_fmtAmt(r.closing_wdv)}</td>
                        <td>${r.posted
                            ? `<span class="badge badge-paid">✓ Posted</span>`
                            : `<span class="badge badge-draft">Unposted</span>`}</td>
                        <td class="td-sm col-ink3">${_h(r.notes || "")}</td>
                    </tr>`).join("")}
            </tbody>
        </table>`;
}

async function _faRegenerateSchedule(id) {
    if (!confirm("Regenerate the depreciation schedule?\n\nPosted entries will be kept. Unposted rows will be recalculated.")) return;
    try {
        const r = await fetch(`/api/fixed-assets/${id}/regenerate-schedule`, { method: "POST" });
        const d = await r.json();
        if (!d.ok) { toast(d.error || "Regenerate failed", 'err'); return; }
        toast("Schedule regenerated");
        // Reload the detail panel
        _faOpenDetail(id);
    } catch (e) {
        toast("Regenerate failed: " + e.message, 'err');
    }
}

function _faTab(tab) {
    document.querySelectorAll("#fa-body .det-tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll("#fa-body .det-pane").forEach(p => p.classList.remove("active"));
    document.getElementById(`fa-tab-${tab}`)?.classList.add("active");
    document.getElementById(`fa-pane-${tab}`)?.classList.add("active");
}

function faDetClose() {
    document.getElementById("fa-overlay")?.classList.remove("open");
    document.getElementById("fa-panel")?.classList.remove("open");
}

// ── New / Edit asset form ─────────────────────────────────────────────────────
function _faNewAsset() { _faOpenForm(null); }
function _faEditAsset(id) {
    const a = _faAll.find(x => x.id === id);
    _faOpenForm(a);
}

function _faOpenForm(asset) {
    faDetClose();
    const isNew = !asset;
    const title = isNew ? "Add Fixed Asset" : `Edit — ${asset.description}`;

    document.getElementById("fa-panel-title").textContent = title;
    document.getElementById("fa-overlay").classList.add("open");
    document.getElementById("fa-panel").classList.add("open");

    // Build account option lists
    const assetAccs  = _faAccounts.filter(a => a.account_subtype === "Fixed Asset" && !a.name.includes("Accum"));
    const accumAccs  = _faAccounts.filter(a =>
        a.account_subtype === "Accumulated Depreciation" ||
        (a.account_subtype === "Fixed Asset" && a.name.includes("Accum")));
    const depnAccs   = _faAccounts.filter(a => a.account_type   === "Expense" && a.name.toLowerCase().includes("depreciation"));
    const allExpense = _faAccounts.filter(a => a.account_type   === "Expense");

    function accOpts(list, selectedId) {
        const pool = list.length ? list : allExpense;
        return pool.map(a =>
            `<option value="${a.id}"${a.id === selectedId ? " selected" : ""}>${a.code} – ${_h(a.name)}</option>`
        ).join("");
    }

    document.getElementById("fa-body").innerHTML = `
        <div class="edt-section">
            <div class="edt-row">
                <div class="edt-field">
                    <label class="edt-lbl">Asset No.</label>
                    <input class="edt-inp" id="fa-f-num" type="text"
                           value="${_h(asset?.asset_number || "")}" placeholder="Auto-assigned">
                </div>
                <div class="edt-field">
                    <label class="edt-lbl">Asset Class *</label>
                    <select class="edt-sel" id="fa-f-cat" onchange="_faOnCategoryChange()">
                        <option value="">— Select category —</option>
                        ${_faAssetClassOptions(asset?.category)}
                    </select>
                </div>
            </div>
            <div class="edt-row">
                <div class="edt-field full">
                    <label class="edt-lbl">Description *</label>
                    <input class="edt-inp" id="fa-f-desc" type="text"
                           value="${_h(asset?.description || "")}"
                           oninput="_faCheckAtoLife()"
                           placeholder="e.g. Dell laptop, Toyota Hilux">
                </div>
            </div>
            <div class="edt-row">
                <div class="edt-field">
                    <label class="edt-lbl">Acquired *</label>
                    <input class="edt-inp" id="fa-f-acq" type="date"
                           value="${asset?.acquisition_date || ""}"
                           oninput="_faCheckIawoHint()">
                </div>
                <div class="edt-field">
                    <label class="edt-lbl">Cost incl GST ($)</label>
                    <input class="edt-inp" id="fa-f-costinc" type="number" step="0.01" min="0"
                           value="${asset?.cost_price || ""}"
                           oninput="_faCalcExclGst();_faCheckIawoHint()">
                </div>
            </div>
            <div class="edt-row">
                <div class="edt-field">
                    <label class="edt-lbl">Cost excl GST ($) *</label>
                    <input class="edt-inp" id="fa-f-cost" type="number" step="0.01" min="0"
                           value="${asset?.cost_excl_gst || asset?.cost_price || ""}"
                           oninput="_faCheckIawoHint()">
                </div>
                <div class="edt-field">
                    <label class="edt-lbl">Residual Value ($)</label>
                    <input class="edt-inp" id="fa-f-resid" type="number" step="0.01" min="0"
                           value="${asset?.residual_value || 0}">
                </div>
            </div>

            <div class="edt-divider"></div>
            <div class="det-section-title">Depreciation Settings</div>

            <div class="edt-row">
                <div class="edt-field">
                    <label class="edt-lbl">Method *</label>
                    <select class="edt-sel" id="fa-f-meth" onchange="_faCheckIawoHint()">
                        ${_FA_METHODS.map(m =>
                            `<option${m === (asset?.depn_method || "Diminishing Value") ? " selected" : ""}>${_h(m)}</option>`
                        ).join("")}
                    </select>
                </div>
                <div class="edt-field">
                    <label class="edt-lbl">Effective Life (years)</label>
                    <input class="edt-inp" id="fa-f-life" type="number" step="0.5" min="0"
                           value="${asset?.effective_life_years || ""}">
                </div>
            </div>
            <div id="fa-ato-hint" class="col-amber fa-ato-hint"></div>
            <button class="btn btn-outline btn-sm fa-ato-btn" type="button" onclick="_faAtoLookup()">
                🔍 Lookup ATO Effective Life
            </button>
            <div id="fa-ato-result" class="col-ink3 fa-ato-result"></div>

            <div class="edt-divider"></div>
            <div class="det-section-title">GL Accounts</div>

            <div class="edt-row">
                <div class="edt-field full">
                    <label class="edt-lbl">Asset at Cost Account</label>
                    <select class="edt-sel" id="fa-f-acc-asset">
                        <option value="">— Select —</option>
                        ${accOpts(assetAccs, asset?.asset_account_id)}
                    </select>
                </div>
            </div>
            <div class="edt-row">
                <div class="edt-field full">
                    <label class="edt-lbl">Accumulated Depreciation Account</label>
                    <select class="edt-sel" id="fa-f-acc-accum">
                        <option value="">— Select —</option>
                        ${accOpts(accumAccs, asset?.accum_depn_account_id)}
                    </select>
                </div>
            </div>
            <div class="edt-row">
                <div class="edt-field full">
                    <label class="edt-lbl">Depreciation Expense Account</label>
                    <select class="edt-sel" id="fa-f-acc-depn">
                        <option value="">— Select —</option>
                        ${accOpts(depnAccs.length ? depnAccs : allExpense, asset?.depn_expense_account_id)}
                    </select>
                </div>
            </div>

            <div class="edt-divider"></div>
            <div class="det-section-title col-ink3">Source Transaction (optional)</div>
            <div class="edt-row">
                <div class="edt-field">
                    <label class="edt-lbl">Source Type</label>
                    <select class="edt-sel" id="fa-f-srctype" onchange="_faSourceTypeChange()">
                        ${["", "bill", "receipt", "journal", "other"].map(t =>
                            `<option${t === (asset?.source_type || "") ? " selected" : ""}>${t}</option>`
                        ).join("")}
                    </select>
                </div>
                <div class="edt-field">
                    <label class="edt-lbl">Reference No.</label>
                    <input class="edt-inp" id="fa-f-srcref" type="text" value="${_h(asset?.source_ref || "")}">
                </div>
            </div>
            <div id="fa-no-src-hint" class="col-amber fa-no-src-hint"></div>
            <div class="edt-row">
                <div class="edt-field full">
                    <label class="edt-lbl">Supplier</label>
                    <input class="edt-inp" id="fa-f-srcsup" type="text" value="${_h(asset?.source_supplier || "")}">
                </div>
            </div>

            <div class="edt-divider"></div>
            <div class="edt-row">
                <div class="edt-field full">
                    <label class="edt-lbl">Notes</label>
                    <textarea class="edt-ta" id="fa-f-notes" rows="3">${_h(asset?.notes || "")}</textarea>
                </div>
            </div>
        </div>
    `;

    const foot = document.getElementById("fa-foot");
    foot.innerHTML = "";

    const btnSave = document.createElement("button");
    btnSave.className = "btn btn-primary btn-sm";
    btnSave.textContent = isNew ? "Create Asset" : "Save Changes";
    btnSave.onclick = () => _faSaveAsset(asset?.id || null);
    foot.appendChild(btnSave);

    const btnCancel = document.createElement("button");
    btnCancel.className = "btn btn-outline btn-sm";
    btnCancel.textContent = "Cancel";
    btnCancel.onclick = faDetClose;
    foot.appendChild(btnCancel);

    // Auto-check IAWO hint and source-type hint on open
    _faCheckIawoHint();
    _faSourceTypeChange();
}

function _faSourceTypeChange() {
    const srcType = document.getElementById("fa-f-srctype")?.value || "";
    const hint    = document.getElementById("fa-no-src-hint");
    if (!hint) return;
    hint.textContent = srcType
        ? ""
        : "⚠ No source transaction — cost excl GST will be saved as $0. Depreciation will not be posted to the GL.";
}

function _faAssetClassOptions(selected) {
    // These labels must match what the server returns from ASSET_CLASS_LABELS
    const classes = [
        "Land", "Buildings", "Leasehold Improvements", "Plant & Equipment",
        "Motor Vehicles", "Fixtures & Fittings", "Computer Equipment",
        "Office Equipment", "Low-Value Pool", "Intangible Assets", "Right-of-Use Assets",
    ];
    return classes.map(c =>
        `<option value="${_h(c)}"${c === selected ? " selected" : ""}>${_h(c)}</option>`
    ).join("");
}

async function _faOnCategoryChange() {
    const cat = document.getElementById("fa-f-cat")?.value;
    if (!cat) return;
    try {
        const d = await apiFetch(`/api/fixed-assets/class-defaults?category=${encodeURIComponent(cat)}`);

        // Set method + life
        if (d.default_method) {
            const meth = document.getElementById("fa-f-meth");
            for (let i = 0; i < meth.options.length; i++) {
                if (meth.options[i].value === d.default_method) {
                    meth.selectedIndex = i; break;
                }
            }
        }
        if (d.default_life) {
            const lifeEl = document.getElementById("fa-f-life");
            if (!lifeEl.value) lifeEl.value = d.default_life;
        }

        // Set GL accounts if they exist in the selects
        const _setAcc = (elId, accId) => {
            if (!accId) return;
            const sel = document.getElementById(elId);
            for (let i = 0; i < sel.options.length; i++) {
                if (parseInt(sel.options[i].value) === accId) {
                    sel.selectedIndex = i; return;
                }
            }
        };
        _setAcc("fa-f-acc-asset", d.asset_account_id);
        _setAcc("fa-f-acc-accum", d.accum_depn_account_id);
        _setAcc("fa-f-acc-depn",  d.depn_expense_account_id);

        // Notes hint
        if (d.notes_hint) {
            document.getElementById("fa-ato-result").textContent = `ℹ ${d.notes_hint}`;
        }
    } catch (_) {}
    _faCheckIawoHint();
}

function _faCalcExclGst() {
    const inc = parseFloat(document.getElementById("fa-f-costinc")?.value || 0);
    if (inc > 0) {
        const excl = document.getElementById("fa-f-cost");
        if (!excl.value) excl.value = (inc / 1.1).toFixed(2);
    }
}

function _faCheckAtoLife() {
    _faCheckIawoHint();
}

// IAWO thresholds — mirrors core/fixed_assets.py IAWO_THRESHOLDS
const _FA_IAWO_THRESHOLDS = [
    { from: "2020-10-06", to: "2023-06-30", limit: null,   sbeOnly: false },
    { from: "2020-03-12", to: "2020-10-05", limit: 150000, sbeOnly: false },
    { from: "2019-04-02", to: "2020-03-11", limit: 30000,  sbeOnly: false },
    { from: "2018-01-29", to: "2019-04-01", limit: 25000,  sbeOnly: true  },
    { from: "2015-05-12", to: "2018-01-28", limit: 20000,  sbeOnly: true  },
    { from: "2023-07-01", to: "2099-12-31", limit: 20000,  sbeOnly: true  },
];

function _faIawoLimit(acqDate) {
    for (const t of _FA_IAWO_THRESHOLDS) {
        if (acqDate >= t.from && acqDate <= t.to) {
            return t.limit === null ? Infinity : t.limit;
        }
    }
    return null;
}

function _faCheckIawoHint() {
    const el = document.getElementById("fa-ato-hint");
    if (!el) return;
    const meth = document.getElementById("fa-f-meth")?.value || "";
    if (!meth.toLowerCase().includes("instant") && !meth.toLowerCase().includes("write")) {
        el.textContent = "";
        el.className = "col-amber";
        return;
    }
    const acq  = document.getElementById("fa-f-acq")?.value || "";
    if (!acq) {
        el.textContent = "Enter acquisition date to check IAWO eligibility.";
        el.className = "col-ink3";
        return;
    }
    const cost  = parseFloat(document.getElementById("fa-f-cost")?.value ||
                             document.getElementById("fa-f-costinc")?.value || 0);
    const limit = _faIawoLimit(acq);
    if (limit === null) {
        el.textContent = "⚠ Instant Asset Write-Off not available for this acquisition date.";
        el.className = "col-red";
    } else if (limit === Infinity) {
        el.textContent = "✓ Temporary Full Expensing applies — 100% write-off in year of acquisition.";
        el.className = "col-green";
    } else if (cost > limit) {
        el.textContent = `⚠ Cost $${cost.toLocaleString("en-AU", {minimumFractionDigits:2})} exceeds IAWO limit $${limit.toLocaleString("en-AU")} — use standard depreciation.`;
        el.className = "col-red";
    } else {
        el.textContent = `✓ IAWO eligible — cost $${cost.toLocaleString("en-AU", {minimumFractionDigits:2})} ≤ $${limit.toLocaleString("en-AU")} threshold.`;
        el.className = "col-green";
    }
}

async function _faAtoLookup() {
    const desc = document.getElementById("fa-f-desc")?.value?.trim();
    if (!desc) { toast("Enter a description first", 'err'); return; }
    try {
        const r = await apiFetch(`/api/fixed-assets/ato-lookup?description=${encodeURIComponent(desc)}`);
        const el = document.getElementById("fa-ato-result");
        if (r.life) {
            el.textContent = `ATO effective life for "${desc}": ${r.life} years`;
            el.classList.add("col-green");
            const lifeEl = document.getElementById("fa-f-life");
            if (!lifeEl.value) lifeEl.value = r.life;
        } else {
            el.textContent = "No ATO effective life found for that description.";
            el.classList.remove("col-green");
        }
    } catch (e) {
        toast("ATO lookup failed: " + e.message, 'err');
    }
}

async function _faSaveAsset(id) {
    const g = id => document.getElementById(id);

    const acqIso = g("fa-f-acq")?.value?.trim();
    if (!acqIso) { toast("Acquisition date is required", 'err'); return; }

    const desc = g("fa-f-desc")?.value?.trim();
    if (!desc) { toast("Description is required", 'err'); return; }

    const sourceType = g("fa-f-srctype")?.value || null;
    // No source transaction → zero out depreciable cost; cost_price kept for reference
    const hasSource  = !!sourceType;
    let costExcl = parseFloat(g("fa-f-cost")?.value || 0);
    if (!hasSource) costExcl = 0;

    const payload = {
        id,
        asset_number:            g("fa-f-num")?.value?.trim() || null,
        description:             desc,
        category:                g("fa-f-cat")?.value || null,
        acquisition_date:        acqIso,
        cost_price:              parseFloat(g("fa-f-costinc")?.value || 0) || null,
        cost_excl_gst:           costExcl,
        residual_value:          parseFloat(g("fa-f-resid")?.value || 0),
        depn_method:             g("fa-f-meth")?.value || "Prime Cost",
        effective_life_years:    parseFloat(g("fa-f-life")?.value || 0) || null,
        asset_account_id:        parseInt(g("fa-f-acc-asset")?.value) || null,
        accum_depn_account_id:   parseInt(g("fa-f-acc-accum")?.value) || null,
        depn_expense_account_id: parseInt(g("fa-f-acc-depn")?.value)  || null,
        source_type:             sourceType,
        source_ref:              g("fa-f-srcref")?.value?.trim() || null,
        source_supplier:         g("fa-f-srcsup")?.value?.trim() || null,
        notes:                   g("fa-f-notes")?.value?.trim() || null,
    };

    try {
        const method = id ? "PUT" : "POST";
        const url    = id ? `/api/fixed-assets/${id}` : "/api/fixed-assets";
        const r = await fetch(url, {
            method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });
        const d = await r.json();
        if (!d.ok) { toast(d.error || "Save failed", 'err'); return; }

        faDetClose();
        if (!hasSource) {
            toast("Asset saved — no source transaction, depreciable cost set to $0");
        } else {
            toast(id ? "Asset updated" : "Asset created");
        }
        await _faLoad();

        // Open detail for new asset
        const newId = d.data?.id;
        if (!id && newId) {
            setTimeout(() => _faOpenDetail(newId), 150);
        }
    } catch (e) {
        toast("Save failed: " + e.message, 'err');
    }
}

// ── Delete ────────────────────────────────────────────────────────────────────
async function _faDeleteAsset(id, desc) {
    const bd = document.createElement("div");
    bd.className = "modal-bd";
    bd.style.display = "flex";
    bd.innerHTML = `
        <div class="modal-box modal-xs-tight">
            <div class="modal-hdr"><span>Delete Asset</span></div>
            <div class="modal-body">
                <p>Delete <strong>${_h(desc)}</strong>?</p>
                <p class="col-ink3 fa-del-hint">Assets with posted depreciation journals cannot be deleted — dispose of them instead.</p>
            </div>
            <div class="modal-foot">
                <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
                <button class="btn btn-danger btn-sm" id="fa-del-btn">Delete</button>
            </div>
        </div>`;
    document.body.appendChild(bd);
    bd.querySelector("#fa-del-btn").onclick = async () => {
        try {
            const r = await fetch(`/api/fixed-assets/${id}`, { method: "DELETE" });
            const d = await r.json();
            if (!d.ok) { toast(d.error || "Delete failed", 'err'); bd.remove(); return; }
            bd.remove();
            faDetClose();
            toast("Asset deleted");
            await _faLoad();
        } catch (e) {
            toast("Delete failed: " + e.message, 'err');
            bd.remove();
        }
    };
}

// ── Dispose dialog ────────────────────────────────────────────────────────────
function _faDispGlPreview(wdv) {
    const el = document.getElementById("fa-disp-gl");
    if (!el) return;
    const proceeds = parseFloat(document.getElementById("fa-disp-proc")?.value || 0);
    const gl = proceeds - wdv;
    if (gl > 0.005) {
        el.textContent = `Gain on disposal: ${_fmtAmt(gl)}`;
        el.style.color = "var(--green)";
    } else if (gl < -0.005) {
        el.textContent = `Loss on disposal: ${_fmtAmt(Math.abs(gl))}`;
        el.style.color = "var(--red)";
    } else {
        el.textContent = "No gain or loss on disposal.";
        el.style.color = "var(--ink3)";
    }
}

function _faDisposeDialog(asset) {
    // cost_excl_gst is 0 for assets with no source transaction (set on save)
    const cost  = asset.cost_excl_gst ?? 0;
    const accum = asset.accum_depn ?? 0;
    const wdv   = cost - accum;
    const noGl  = cost === 0;

    const warning = noGl
        ? `<div class="alert-warn">
               ⚠ No source transaction — this asset has no depreciable cost. Disposal will update the register status only. No GL journal will be posted.
           </div>`
        : "";

    const bd = document.createElement("div");
    bd.className = "modal-bd";
    bd.style.display = "flex";
    bd.innerHTML = `
        <div class="modal-box modal-sm">
            <div class="modal-hdr"><span>Dispose Asset — ${_h(asset.description)}</span></div>
            <div class="modal-body">
                ${warning}
                <div class="fa-disp-wdv">
                    <div class="fa-disp-wdv-row"><span class="col-ink3">Cost (excl GST)</span><span class="inv-mono">${_fmtAmt(cost)}</span></div>
                    <div class="fa-disp-wdv-row"><span class="col-ink3">Accum Depreciation</span><span class="inv-mono">${_fmtAmt(accum)}</span></div>
                    <div class="fa-disp-wdv-total"><span>Written-Down Value</span><span class="inv-mono">${_fmtAmt(wdv)}</span></div>
                </div>
                <div class="form-grid form-grid-1 fa-disp-form-gap">
                    <div class="edt-field">
                        <label class="edt-lbl">Disposal Date *</label>
                        <input class="edt-inp" id="fa-disp-date" type="date"
                               value="${isoToday()}">
                    </div>
                    <div class="edt-field">
                        <label class="edt-lbl">Proceeds ($)</label>
                        <input class="edt-inp" id="fa-disp-proc" type="number" step="0.01" min="0" value="0"
                               oninput="_faDispGlPreview(${wdv})">
                    </div>
                    <div class="edt-field">
                        <label class="edt-lbl">Disposal Method</label>
                        <select class="edt-sel" id="fa-disp-meth">
                            ${["Sale", "Scrapped", "Trade-In", "Donated"].map(m =>
                                `<option>${m}</option>`
                            ).join("")}
                        </select>
                    </div>
                    <div class="edt-field">
                        <label class="edt-lbl">Notes</label>
                        <textarea class="edt-ta" id="fa-disp-notes" rows="2"></textarea>
                    </div>
                </div>
                ${noGl ? "" : `<div id="fa-disp-gl" class="fa-disp-gl"></div>`}
            </div>
            <div class="modal-foot">
                <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
                <button class="btn btn-orange btn-sm" id="fa-disp-save">Record Disposal</button>
            </div>
        </div>`;
    document.body.appendChild(bd);
    if (!noGl) _faDispGlPreview(wdv);

    bd.querySelector("#fa-disp-save").onclick = async () => {
        const dateIso = document.getElementById("fa-disp-date").value;
        if (!dateIso) { toast("Disposal date is required", 'err'); return; }

        const payload = {
            disposal_date:    dateIso,
            proceeds:         parseFloat(document.getElementById("fa-disp-proc").value || 0),
            method:           document.getElementById("fa-disp-meth").value,
            notes:            document.getElementById("fa-disp-notes").value.trim(),
        };

        try {
            const r = await fetch(`/api/fixed-assets/${asset.id}/dispose`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload),
            });
            const d = await r.json();
            if (!d.ok) { toast(d.error || "Disposal failed", 'err'); return; }
            bd.remove();
            faDetClose();
            toast(d.data?.journal_id
                ? "Asset disposed — journal posted"
                : "Asset disposed — register updated (no GL journal)");
            await _faLoad();
        } catch (e) {
            toast("Disposal failed: " + e.message, 'err');
        }
    };
}

// ── Post FY Depreciation dialog ───────────────────────────────────────────────
async function _faPostFYDialog(singleAssetId) {
    const now   = new Date();
    const curFY = now.getMonth() >= 6 ? now.getFullYear() + 1 : now.getFullYear();
    const fyOpts = [curFY, curFY - 1, curFY - 2].map(fy =>
        `<option value="${fy}">FY${fy-1}/${String(fy).slice(-2)}</option>`
    ).join("");

    const bd = document.createElement("div");
    bd.className = "modal-bd";
    bd.style.display = "flex";
    bd.innerHTML = `
        <div class="modal-box modal-580 modal-tall">
            <div class="modal-hdr">
                <span>${singleAssetId ? "Post Depreciation — Single Asset" : "Post FY Depreciation — All Assets"}</span>
            </div>
            <div class="modal-body modal-body-scroll">
                <div class="fa-pfy-picker">
                    <div class="edt-field fa-pfy-field">
                        <label class="edt-lbl">Financial Year *</label>
                        <select class="edt-sel" id="fa-pfy-year" onchange="_faPostFYPreview(${singleAssetId || "null"})">${fyOpts}</select>
                    </div>
                    <button class="btn btn-outline btn-sm fa-pfy-btn" onclick="_faPostFYPreview(${singleAssetId || "null"})">Preview</button>
                </div>
                <div id="fa-pfy-preview"></div>
                <div id="fa-pfy-results"></div>
            </div>
            <div class="modal-foot">
                <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Close</button>
                <button class="btn btn-success btn-sm" id="fa-pfy-go" disabled>✅ Post Depreciation</button>
            </div>
        </div>`;
    document.body.appendChild(bd);

    // Auto-preview on open
    await _faPostFYPreview(singleAssetId || null);

    bd.querySelector("#fa-pfy-go").onclick = async () => {
        const fyYear = parseInt(document.getElementById("fa-pfy-year").value);
        const resDiv = document.getElementById("fa-pfy-results");
        resDiv.innerHTML = `<div class="state-loading">Posting…</div>`;
        document.getElementById("fa-pfy-go").disabled = true;

        try {
            const url = singleAssetId
                ? `/api/fixed-assets/${singleAssetId}/post-depreciation`
                : "/api/fixed-assets/post-all-depreciation";

            const r = await fetch(url, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ fy_year: fyYear }),
            });
            const d = await r.json();
            if (!d.ok) { resDiv.innerHTML = `<div class="state-error">${d.error}</div>`; return; }

            const results = d.results || (d.journal_id
                ? [{ description: "Asset", depn_amount: d.depn_amount, journal_id: d.journal_id, error: null }]
                : []);
            const posted = results.filter(r => !r.error);
            const errors = results.filter(r =>  r.error);

            document.getElementById("fa-pfy-preview").innerHTML = "";
            resDiv.innerHTML = `
                <p class="col-green fw-600">✓ Posted ${posted.length} journal${posted.length !== 1 ? "s" : ""}</p>
                ${posted.map(r => `
                    <div class="fa-pfy-row">
                        <span class="col-ink2">${_h(r.description)}</span>
                        <span class="inv-amt">${_fmtAmt(r.depn_amount)}</span>
                    </div>`).join("")}
                ${errors.length ? `
                    <p class="col-red fw-600 fa-pfy-err-hdr">⚠ ${errors.length} error${errors.length !== 1 ? "s" : ""}</p>
                    ${errors.map(r => `<div class="col-red fa-pfy-err">${_h(r.description)}: ${_h(r.error)}</div>`).join("")}
                ` : ""}`;

            _faLoad();
        } catch (e) {
            resDiv.innerHTML = `<div class="state-error">Failed: ${e.message}</div>`;
        }
    };
}

async function _faPostFYPreview(singleAssetId) {
    const prevDiv = document.getElementById("fa-pfy-preview");
    if (!prevDiv) return;
    const fyYear = parseInt(document.getElementById("fa-pfy-year")?.value || 0);
    if (!fyYear) return;

    prevDiv.innerHTML = `<div class="state-loading">Loading preview…</div>`;
    document.getElementById("fa-pfy-results").innerHTML = "";

    try {
        const url = singleAssetId
            ? `/api/fixed-assets/post-fy-preview?fy_year=${fyYear}&asset_id=${singleAssetId}`
            : `/api/fixed-assets/post-fy-preview?fy_year=${fyYear}`;
        const rows = await apiFetch(url);

        if (!rows.length) {
            prevDiv.innerHTML = `<div class="det-empty">No assets with an unposted schedule row for this FY.</div>`;
            document.getElementById("fa-pfy-go").disabled = true;
            return;
        }

        const canPost = rows.filter(r => r.ready).length;
        const total   = rows.filter(r => r.ready).reduce((s, r) => s + (r.depn_amount || 0), 0);

        prevDiv.innerHTML = `
            <table class="inv-list-table fa-preview-tbl">
                <thead><tr>
                    <th>Asset No</th><th>Description</th>
                    <th class="th-r">Depreciation</th><th>Status</th>
                </tr></thead>
                <tbody>
                    ${rows.map(r => {
                        const cls = r.already_posted ? "col-ink3"
                                  : !r.ready        ? "col-red" : "";
                        return `<tr class="inv-row ${cls}">
                            <td class="inv-mono">${_h(r.asset_number || `#${r.asset_id}`)}</td>
                            <td>${_h(r.description)}</td>
                            <td class="inv-amt">${_fmtAmt(r.depn_amount)}</td>
                            <td><span class="td-sm">${_h(r.status)}</span></td>
                        </tr>`;
                    }).join("")}
                </tbody>
            </table>
            <div class="fa-pfy-caption">
                ${canPost} asset${canPost !== 1 ? "s" : ""} ready to post
                · Total depreciation: ${_fmtAmt(total)}
            </div>`;

        document.getElementById("fa-pfy-go").disabled = (canPost === 0);
    } catch (e) {
        prevDiv.innerHTML = `<div class="state-error">Preview failed: ${e.message}</div>`;
    }
}

// ── PDF download ──────────────────────────────────────────────────────────────
function _faDownloadPDF() {
    const th = encodeURIComponent(typeof currentTheme !== 'undefined' ? currentTheme : '');
    window.open(`/api/fixed-assets/register-pdf?theme=${th}`, "_blank");
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function _faBadge(status) {
    const map = {
        "Active":             "badge-paid",
        "Fully Depreciated":  "badge-pending",
        "Disposed":           "badge-overdue",
    };
    return `<span class="badge ${map[status] || "badge-draft"}">${_h(status)}</span>`;
}

function _fmtAmt(v) {
    const n = parseFloat(v) || 0;
    return "$" + n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function _h(s) {
    return String(s ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}
