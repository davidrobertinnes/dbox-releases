// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ═══════════════════════════════════════════════════════════════════════════
// CONTACTS PAGE
// ═══════════════════════════════════════════════════════════════════════════
let _conAll=[],_conFilter='All',_conSearch='',_conSort={col:'name',dir:1},_conSelected=null;
const CON_TYPES=['All','Customer','Supplier','Both','Employee'];

async function pageContacts() {
  try {
    _conAll = await apiFetch('/api/contacts') || [];
    renderContactsPage();
  } catch(e) {
    document.getElementById('module-content').innerHTML=`<div class="state-error">Failed to load contacts: ${esc(e.message)}</div>`;
  }
}

function _conFiltered() {
  const q=_conSearch.toLowerCase();
  return _conAll.filter(c=>{
    if(_conFilter==='Employee'&&!c.has_employee) return false;
    else if(_conFilter!=='All'&&_conFilter!=='Employee'&&c.contact_type!==_conFilter) return false;
    if(q&&![c.name,c.email,c.phone,c.abn,c.contact_person].some(v=>(v||'').toLowerCase().includes(q))) return false;
    return true;
  }).sort((a,b)=>{
    const col=_conSort.col, av=a[col]??'', bv=b[col]??'';
    return(typeof av==='number'?(av-bv):String(av).localeCompare(String(bv)))*_conSort.dir;
  });
}

function renderContactsPage(restoreFocus) {
  const rows=_conFiltered();
  const counts={All:_conAll.length};
  CON_TYPES.slice(1).forEach(t=>{ counts[t]=_conAll.filter(c=>t==='Employee'?c.has_employee:c.contact_type===t).length; });
  const mc=document.getElementById('module-content');
  mc.innerHTML=`
    <div class="inv-toolbar">
      <input class="inv-search" id="con-q" placeholder="Search name, email, phone, ABN\u2026" value="${esc(_conSearch)}">
      <div class="inv-filter-group">
        ${CON_TYPES.map(t=>`<button class="filter-btn${_conFilter===t?' active':''}" onclick="conSetFilter('${t}')">
          ${t}${counts[t]?` <span class="filter-count">(${counts[t]})</span>`:''}</button>`).join('')}
      </div>
      <button class="btn btn-outline" onclick="conFindDuplicates()">⇄ Find Duplicates</button>
      <button class="btn btn-outline" onclick="conBulkStatements()">📧 Bulk Statements</button>
      <button class="btn btn-primary" onclick="conNew()">+ New Contact</button>
    </div>
    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        ${conTh('name','Name')}${conTh('contact_type','Type')}
        ${conTh('email','Email')}${conTh('phone','Phone')}
        ${conTh('abn','ABN')}${conTh('payment_terms','Terms','r')}
      </tr></thead><tbody>
        ${rows.length ? rows.map(conRow).join('') : `<tr><td colspan="6" class="tbl-empty-row">No contacts match your filter</td></tr>`}
      </tbody></table>
    </div></div>
    <div class="list-count-row"><span class="count-pill">${rows.length} of ${_conAll.length} contact${_conAll.length!==1?'s':''}</span></div>`;
  const q=document.getElementById('con-q');
  if(q){
    q.addEventListener('input',e=>{_conSearch=e.target.value;renderContactsPage(true);});
    if(restoreFocus){q.focus();q.setSelectionRange(q.value.length,q.value.length);}
  }
}

// FIX 3: merge sort class and alignment class into a single class attribute
function conTh(col,label,align) {
  const sortCls=_conSort.col===col?(_conSort.dir>0?'sort-asc':'sort-desc'):'';
  const cls=[sortCls,align==='r'?'th-r':''].filter(Boolean).join(' ');
  return `<th${cls?` class="${cls}"`:''} onclick="conSortBy('${col}')">${label}</th>`;
}

// FIX 1: badge-green → badge-paid (defined in dbox.css; badge-green is not)
const CON_TYPE_BADGE={'Customer':'badge-pending','Supplier':'badge-partial','Both':'badge-partial','Employee':'badge-paid'};

function conRow(c) {
  const sel=_conSelected===c.id;
  // FIX 1: badge-green → badge-paid
  const empBadge=c.has_employee?'<span class="badge badge-paid badge-sm-inline">Employee</span>':'';
  const approvedBadge=c.approved_account?'<span class="badge badge-pending badge-sm-inline">Approved</span>':'';
  return `<tr class="inv-row${sel?' acct-row-selected':''}" onclick="conOpen(${c.id})">
    <td><span class="inv-contact">${esc(c.name)}</span>${!c.is_active?'<span class="badge badge-draft badge-sm-inline">Inactive</span>':''}${empBadge}${approvedBadge}</td>
    <td><span class="badge ${CON_TYPE_BADGE[c.contact_type]||'badge-draft'}">${esc(c.contact_type||'—')}</span></td>
    <td><span class="inv-mono td-sm">${esc(c.email||'—')}</span></td>
    <td><span class="inv-mono td-sm">${esc(c.phone||'—')}</span></td>
    <td><span class="inv-mono">${esc(c.abn||'—')}</span></td>
    <td class="td-r-mono">${c.payment_terms?c.payment_terms+' days':'—'}</td>
  </tr>`;
}

function conSortBy(col){_conSort={col,dir:_conSort.col===col?_conSort.dir*-1:1};renderContactsPage();}
function conSetFilter(f){_conFilter=f;renderContactsPage();}

async function conOpen(id) {
  _conSelected=id;
  _conDetailTab='details';
  renderContactsPage();
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent='Contact';
  document.getElementById('det-body').innerHTML='<div class="state-loading">Loading\u2026</div>';
  document.getElementById('det-foot').innerHTML='';
  try {
    const c=await apiFetch(`/api/contacts/${id}`);
    renderConDetail(c);
  } catch(e) {
    document.getElementById('det-body').innerHTML=`<div class="state-error">${esc(e.message)}</div>`;
  }
}

let _conDetailTab='details', _conDetailContact=null;

function _conDetailsHtml(c) {
  const addr=[c.address,c.city,c.state,c.postcode].filter(Boolean).join(', ');
  return `
    <div class="con-badge-row">
      <span class="badge ${CON_TYPE_BADGE[c.contact_type]||'badge-draft'}">${esc(c.contact_type||'Contact')}</span>
      ${c.has_employee?'<span class="badge badge-paid">Employee</span>':''}
      ${c.approved_account?'<span class="badge badge-pending">Approved Account</span>':''}
      ${!c.is_active?'<span class="badge badge-draft">Inactive</span>':''}
    </div>
    <div class="det-meta">
      <div><div class="det-lbl">Email</div>
        <div class="det-val">${c.email?`<a href="mailto:${esc(c.email)}" class="lnk-accent">${esc(c.email)}</a>`:'—'}</div></div>
      <div><div class="det-lbl">Phone</div><div class="det-val">${esc(c.phone||'—')}</div></div>
      <div><div class="det-lbl">ABN</div><div class="det-val mono">${esc(c.abn||'—')}</div></div>
      <div><div class="det-lbl">Contact Person</div><div class="det-val">${esc(c.contact_person||'—')}</div></div>
      ${addr?`<div class="con-addr-row"><div class="det-lbl">Address</div><div class="det-val">${esc(addr)}</div></div>`:''}
      <div><div class="det-lbl">Payment Terms</div><div class="det-val">${c.payment_terms?c.payment_terms+' days':'—'}</div></div>
      <div><div class="det-lbl">Default Tax</div><div class="det-val mono">${esc(c.default_tax_code||'—')}</div></div>
      ${c.approved_account?`<div><div class="det-lbl">Approved By</div><div class="det-val">${esc(c.approved_by_name||'—')}</div></div>`:''}
    </div>
    ${c.notes?`<div class="con-notes-box">${esc(c.notes)}</div>`:''}
    ${(c.bsb||c.account_number)?`
    <div class="con-bank-section">
      <div class="con-bank-lbl">Bank Details</div>
      <div class="det-meta">
        <div><div class="det-lbl">BSB</div><div class="det-val mono">${esc(c.bsb||'—')}</div></div>
        <div><div class="det-lbl">Account No.</div><div class="det-val mono">${esc(c.account_number||'—')}</div></div>
        ${c.bank_account_name?`<div class="con-addr-row"><div class="det-lbl">Account Name</div><div class="det-val">${esc(c.bank_account_name)}</div></div>`:''}
      </div>
    </div>`:''}`;
}

function renderConDetail(c) {
  _conDetailContact = c;
  document.getElementById('det-title').textContent = c.name;
  _renderConTabs();
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" onclick="conEdit(${c.id})">✏ Edit</button>
    <button class="btn btn-outline" onclick="conStatement(${c.id})">📄 Statement</button>
    <button class="btn btn-outline" onclick="conMerge(${c.id})">⇄ Merge</button>
    <button class="btn btn-outline" onclick="conNew()">+ New Contact</button>
    <button class="btn btn-outline" onclick="detClose()">Close</button>`;
}

function _renderConTabs() {
  const c = _conDetailContact;
  const body = document.getElementById('det-body');
  body.innerHTML = `
    <div class="det-tabs" id="con-tabs">
      <div class="det-tab${_conDetailTab==='details'?' active':''}" onclick="conTab('details')">Details</div>
      <div class="det-tab${_conDetailTab==='tasks'?' active':''}" id="con-tasks-tab-hdr">Tasks</div>
    </div>
    <div id="con-tab-content"></div>`;
  document.getElementById('con-tasks-tab-hdr').onclick = () => conTab('tasks');
  if (_conDetailTab === 'details') {
    document.getElementById('con-tab-content').innerHTML = _conDetailsHtml(c);
  } else {
    _loadWorkTasks(c.id);
  }
}

async function conTab(tab) {
  _conDetailTab = tab;
  document.querySelectorAll('#con-tabs .det-tab').forEach(el => {
    el.classList.toggle('active', el.textContent.startsWith(tab === 'details' ? 'Details' : 'Tasks'));
  });
  const el = document.getElementById('con-tab-content');
  if (tab === 'details') {
    el.innerHTML = _conDetailsHtml(_conDetailContact);
  } else {
    await _loadWorkTasks(_conDetailContact.id);
  }
}

// ── Work Tasks tab (Maintenance Log) ─────────────────────────────────────────

let _wtasks = [], _wtEditId = null, _wtEditBd = null, _wtJobs = [];
let _conCrmTasks = [];
let _wtLogFilter = 'All', _wtLogFrom = '', _wtLogTo = '';

const _WT_FREQUENCIES = ['Weekly','Fortnightly','Monthly','Quarterly','Annual'];

function _wtAdvanceDate(iso, frequency) {
  if (!iso) return '';
  const d = new Date(iso + 'T00:00:00');
  switch ((frequency || '').toLowerCase()) {
    case 'weekly':      d.setDate(d.getDate() + 7); break;
    case 'fortnightly': d.setDate(d.getDate() + 14); break;
    case 'monthly':     d.setMonth(d.getMonth() + 1); break;
    case 'quarterly':   d.setMonth(d.getMonth() + 3); break;
    case 'annual':      d.setFullYear(d.getFullYear() + 1); break;
  }
  return d.toISOString().slice(0, 10);
}

function _wtFreqOptions(selected) {
  return _WT_FREQUENCIES.map(f =>
    `<option value="${f}"${f === selected ? ' selected' : ''}>${f}</option>`
  ).join('');
}

function _wtScheduleNextModal(task, cid) {
  const base = task.due_date || isoToday();
  const suggested = _wtAdvanceDate(base, task.recur_frequency);
  const bd = createModal({
    width: '420px',
    html: `<div class="modal-hdr">Schedule next task</div>
      <div class="modal-body">
        <p style="margin:0 0 14px">Schedule the next occurrence of <strong>${esc(task.title)}</strong>?</p>
        <div class="modal-field"><label class="modal-lbl">Frequency</label>
          <select class="modal-inp" id="wt-next-freq">
            <option value="">— none —</option>
            ${_wtFreqOptions(task.recur_frequency)}
          </select>
        </div>
        <div class="modal-field"><label class="modal-lbl">Due date</label>
          <input class="modal-inp" type="date" id="wt-next-due" value="${suggested}">
        </div>
      </div>
      <div class="modal-acts">
        <button class="btn btn-outline btn-sm" id="wt-next-skip">Skip</button>
        <button class="btn btn-primary btn-sm" id="wt-next-sched">Schedule →</button>
      </div>`
  });
  bd.querySelector('#wt-next-freq').onchange = function() {
    bd.querySelector('#wt-next-due').value = _wtAdvanceDate(base, this.value);
  };
  bd.querySelector('#wt-next-skip').onclick = () => { bd.remove(); _loadWorkTasks(cid); };
  bd.querySelector('#wt-next-sched').onclick = async () => {
    const freq = bd.querySelector('#wt-next-freq').value;
    const due  = bd.querySelector('#wt-next-due').value;
    try {
      const r = await fetch('/api/work-tasks', {
        method: 'POST', credentials: 'include',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          contact_id:      task.contact_id,
          job_id:          task.job_id || null,
          opp_id:          task.opp_id || null,
          title:           task.title,
          is_recurring:    1,
          recur_frequency: freq || null,
          due_date:        due || null,
        })
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Failed');
      toast('Next task scheduled');
    } catch(e) { toast(e.message, 'err'); }
    bd.remove();
    _loadWorkTasks(cid);
  };
}

async function _loadWorkTasks(cid) {
  const el = document.getElementById('con-tab-content');
  el.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    [_wtasks, _conCrmTasks] = await Promise.all([
      apiFetch(`/api/contacts/${cid}/work-tasks`).then(r => r || []),
      apiFetch(`/api/contacts/${cid}/crm-tasks`).then(r => r || []),
    ]);
    _wtJobs = await apiFetch('/api/jobs').then(r => r || []);
    _wtJobs = _wtJobs.filter(j => !j.contact_id || j.contact_id === cid);
    _renderTaskLog(cid);
    _updateTasksTabLabel();
  } catch(e) {
    el.innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
  }
}

function _updateTasksTabLabel() {
  const openWork = _wtasks.filter(t => !t.is_done).length;
  const openCrm  = _conCrmTasks.filter(t => !t.is_done).length;
  const open = openWork + openCrm;
  const hdr = document.getElementById('con-tasks-tab-hdr');
  if (hdr) hdr.textContent = `Tasks${open ? ` (${open} open)` : ''}`;
}

function _renderTaskLog(cid) {
  const el = document.getElementById('con-tab-content');
  const today = isoToday();

  let tasks = [..._wtasks];
  if (_wtLogFilter === 'Open')           tasks = tasks.filter(t => !t.is_done);
  else if (_wtLogFilter === 'Completed') tasks = tasks.filter(t =>  t.is_done && !t.invoice_id);
  else if (_wtLogFilter === 'Invoiced')  tasks = tasks.filter(t => !!t.invoice_id);
  if (_wtLogFrom) tasks = tasks.filter(t => (t.created_at||'').slice(0,10) >= _wtLogFrom);
  if (_wtLogTo)   tasks = tasks.filter(t => (t.created_at||'').slice(0,10) <= _wtLogTo);
  tasks.sort((a, b) => (b.created_at||'') > (a.created_at||'') ? 1 : -1);

  const openCrm = _conCrmTasks.filter(t => !t.is_done);
  const uninvoiced = _wtasks.filter(t => t.is_done && !t.invoice_id);

  const bdgCls = s => s === 'Open' ? 'badge-pending' : s === 'Invoiced' ? 'badge-paid' : 'badge-partial';

  const trows = tasks.map(t => {
    const status = !t.is_done ? 'Open' : t.invoice_id ? 'Invoiced' : 'Completed';
    const jobLabel = t.job_name ? (t.job_number ? t.job_number + ' — ' + t.job_name : t.job_name) : null;
    const dueDisplay = t.due_date && !t.is_done
      ? `<span class="${t.due_date < today ? 'wt-overdue' : 'wt-due'}">Due ${fmtDate(t.due_date)}</span>` : '';
    return `<tr>
      <td>${esc(t.title)}${t.is_recurring ? `<span class="wt-recur-badge">↻ ${esc(t.recur_frequency || 'Recurring')}</span>` : ''}${dueDisplay}</td>
      <td>${jobLabel ? `<span class="wt-link-badge">${esc(jobLabel)}</span>` : '<span class="txt-ink3">—</span>'}</td>
      <td class="td-sm">${t.created_at ? fmtDate(t.created_at.slice(0,10)) : '—'}</td>
      <td class="td-sm">${t.done_at ? fmtDate(t.done_at.slice(0,10)) : '—'}</td>
      <td class="log-notes-cell">${t.description ? esc(t.description) : '<span class="txt-ink3">—</span>'}</td>
      <td><span class="badge ${bdgCls(status)} badge-sm-inline">${status}</span></td>
      <td class="td-actions">
        ${status !== 'Invoiced' ? `
          <input type="checkbox" class="wt-chk" ${t.is_done?'checked':''} title="${t.is_done?'Mark open':'Mark complete'}"
            onchange="_wtToggle(${t.id},${cid},this.checked)">
          <button class="btn-icon" title="Edit" onclick="_wtEdit(${t.id})">✏</button>
          <button class="btn-icon btn-icon-red" title="Delete" onclick="_wtDelete(${t.id},${cid})">✕</button>
        ` : '<span class="wt-invoiced-icon" title="Invoiced">✓</span>'}
      </td>
    </tr>`;
  }).join('');

  el.innerHTML = `
    <div class="wt-wrap">
      ${openCrm.length ? `
        <div class="wt-section-hdr">Linked tasks</div>
        ${openCrm.map(t => {
          const overdue = t.due_date && t.due_date < today;
          return `<div class="wt-row">
            <div class="wt-body">
              <div class="wt-title">${esc(t.title)}</div>
              <div class="wt-meta">
                ${esc(t.task_type||'')}${t.due_date?` — Due: ${fmtDate(t.due_date)}${overdue?' ⚠':''}`:'' }
                ${t.job_id?`&nbsp;·&nbsp; <span class="wt-link-badge">Job: ${esc(t.job_name||t.job_number||'#'+t.job_id)}</span>`:''}
              </div>
            </div>
          </div>`;
        }).join('')}
      ` : ''}

      <div class="log-toolbar">
        <div class="inv-filter-group">
          ${['All','Open','Completed','Invoiced'].map(s =>
            `<button class="filter-btn${_wtLogFilter===s?' active':''}" onclick="_wtLogSetFilter('${s}',${cid})">${s}</button>`
          ).join('')}
        </div>
        <div class="log-date-range">
          <input type="date" class="edt-inp log-date-inp" value="${_wtLogFrom}"
            onchange="_wtLogSetFrom(this.value,${cid})">
          <span class="log-date-sep">–</span>
          <input type="date" class="edt-inp log-date-inp" value="${_wtLogTo}"
            onchange="_wtLogSetTo(this.value,${cid})">
          ${(_wtLogFrom||_wtLogTo)?`<button class="btn-link" onclick="_wtLogClearDates(${cid})">Clear</button>`:''}
        </div>
        <button class="btn btn-outline btn-sm" onclick="_wtPrintLog(${cid})">🖨 Print</button>
      </div>

      <div class="tbl-overflow-x">
        <table class="inv-list-table">
          <thead><tr>
            <th>Task</th><th>Job</th><th>Entered</th><th>Completed</th><th>Notes</th><th>Status</th><th></th>
          </tr></thead>
          <tbody>
            ${tasks.length ? trows : '<tr><td colspan="7" class="tbl-empty-row">No tasks match the current filter</td></tr>'}
          </tbody>
        </table>
      </div>
      <div class="log-count-row">
        <span class="count-pill">${tasks.length} of ${_wtasks.length} task${_wtasks.length!==1?'s':''}</span>
        ${uninvoiced.length ? `
          <button class="btn btn-primary btn-sm" onclick="_wtInvoice(${cid},[${uninvoiced.map(t=>t.id)}])">
            Invoice ${uninvoiced.length} completed task${uninvoiced.length!==1?'s':''}
          </button>
        ` : ''}
      </div>

      <div class="wt-section-hdr log-add-hdr">Add Task</div>
      <div class="wt-add-form" id="wt-add-form">
        <div class="wt-form-row">
          <input class="edt-inp wt-inp-title" id="wt-new-title" placeholder="Task title *">
          <input class="edt-inp wt-inp-qty" id="wt-new-qty" type="number" step="0.01" value="1" placeholder="Qty">
          <input class="edt-inp wt-inp-price" id="wt-new-price" type="number" step="0.01" value="0" placeholder="Unit $">
        </div>
        <div class="wt-form-row">
          <input class="edt-inp wt-inp-desc" id="wt-new-desc" placeholder="Notes (optional)">
          <button class="btn btn-primary btn-sm" id="wt-add-btn" onclick="_wtAdd(${cid})">Add Task</button>
        </div>
        <div class="wt-form-row">
          <label class="wt-lbl">Date entered</label>
          <input class="edt-inp" id="wt-new-date" type="date" value="${today}">
          <label class="wt-lbl" style="margin-left:14px">Due date</label>
          <input class="edt-inp" id="wt-new-due" type="date">
        </div>
        <div class="wt-form-row" style="align-items:center;gap:10px">
          <label class="chk-label" style="display:flex;align-items:center;gap:6px;cursor:pointer">
            <input type="checkbox" id="wt-new-recurring" onchange="document.getElementById('wt-new-freq-wrap').style.display=this.checked?'flex':'none'">
            Recurring task
          </label>
          <div id="wt-new-freq-wrap" style="display:none;align-items:center;gap:6px">
            <label class="wt-lbl" style="margin:0">Frequency</label>
            <select class="edt-sel" id="wt-new-freq">
              <option value="">— none —</option>
              ${_WT_FREQUENCIES.map(f=>`<option>${f}</option>`).join('')}
            </select>
          </div>
        </div>
        <div class="wt-form-row">
          <select class="edt-sel wt-sel-link" id="wt-new-job">
            <option value="">No job</option>
            ${_wtJobs.map(j=>`<option value="${j.id}">${esc(j.job_number+' — '+j.name)}</option>`).join('')}
          </select>
        </div>
      </div>
    </div>`;
}

function _wtLogSetFilter(s, cid) { _wtLogFilter = s; _renderTaskLog(cid); }
function _wtLogSetFrom(v, cid)   { _wtLogFrom = v;   _renderTaskLog(cid); }
function _wtLogSetTo(v, cid)     { _wtLogTo = v;     _renderTaskLog(cid); }
function _wtLogClearDates(cid)   { _wtLogFrom = ''; _wtLogTo = ''; _renderTaskLog(cid); }

function _wtPrintLog(cid) {
  let tasks = [..._wtasks];
  if (_wtLogFilter === 'Open')           tasks = tasks.filter(t => !t.is_done);
  else if (_wtLogFilter === 'Completed') tasks = tasks.filter(t =>  t.is_done && !t.invoice_id);
  else if (_wtLogFilter === 'Invoiced')  tasks = tasks.filter(t => !!t.invoice_id);
  if (_wtLogFrom) tasks = tasks.filter(t => (t.created_at||'').slice(0,10) >= _wtLogFrom);
  if (_wtLogTo)   tasks = tasks.filter(t => (t.created_at||'').slice(0,10) <= _wtLogTo);
  tasks.sort((a, b) => (b.created_at||'') > (a.created_at||'') ? 1 : -1);

  const contactName = _conDetailContact?.name || '';
  const filterLabel = [
    _wtLogFilter !== 'All' ? _wtLogFilter : '',
    _wtLogFrom ? `From ${fmtDate(_wtLogFrom)}` : '',
    _wtLogTo   ? `To ${fmtDate(_wtLogTo)}`     : '',
  ].filter(Boolean).join('  ·  ') || 'All tasks';

  const rows = tasks.map(t => {
    const status = !t.is_done ? 'Open' : t.invoice_id ? 'Invoiced' : 'Completed';
    const jobLabel = t.job_name ? (t.job_number ? t.job_number + ' — ' + t.job_name : t.job_name) : '—';
    const esc2 = s => s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    return `<tr>
      <td>${esc2(t.title)}</td>
      <td>${esc2(jobLabel)}</td>
      <td>${t.created_at ? fmtDate(t.created_at.slice(0,10)) : '—'}</td>
      <td>${t.done_at ? fmtDate(t.done_at.slice(0,10)) : '—'}</td>
      <td>${t.description ? esc2(t.description) : '—'}</td>
      <td>${status}</td>
    </tr>`;
  }).join('');

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
    <title>Maintenance Log — ${contactName}</title>
    <style>
      body { font-family: Arial, sans-serif; font-size: 11pt; color: #111; margin: 20mm 18mm; }
      h2 { font-size: 14pt; margin: 0 0 2px; }
      .sub { font-size: 10pt; color: #555; margin-bottom: 14px; }
      table { width: 100%; border-collapse: collapse; }
      th { background: #f0f0f0; text-align: left; padding: 5px 7px;
           font-size: 10pt; border-bottom: 2px solid #ccc; }
      td { padding: 5px 7px; font-size: 10pt; border-bottom: 1px solid #e0e0e0;
           vertical-align: top; }
      tr:last-child td { border-bottom: none; }
    </style>
  </head><body>
    <h2>Maintenance Log — ${contactName}</h2>
    <div class="sub">${filterLabel} &nbsp;·&nbsp; Printed ${fmtDate(isoToday())}</div>
    <table>
      <thead><tr>
        <th>Task</th><th>Job</th><th>Entered</th><th>Completed</th><th>Notes</th><th>Status</th>
      </tr></thead>
      <tbody>${rows || '<tr><td colspan="6">No tasks</td></tr>'}</tbody>
    </table>
  </body></html>`;

  const w = window.open('', '_blank');
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(() => w.print(), 300);
}

async function _wtToggle(tid, cid, checked) {
  try {
    const r = await fetch(`/api/work-tasks/${tid}/complete`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({is_done: checked})
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed');
    if (checked && j.data?.recurring) {
      _wtScheduleNextModal(j.data.recurring, cid);
    } else {
      await _loadWorkTasks(cid);
    }
  } catch(e) {
    toast(e.message, 'err');
    await _loadWorkTasks(cid);
  }
}

async function _wtAdd(cid) {
  const title = (document.getElementById('wt-new-title')?.value || '').trim();
  if (!title) { toast('Task title is required', 'err'); return; }
  const qty   = parseFloat(document.getElementById('wt-new-qty')?.value  || '1') || 1;
  const price = parseFloat(document.getElementById('wt-new-price')?.value || '0') || 0;
  const desc  = (document.getElementById('wt-new-desc')?.value || '').trim();
  const btn   = document.getElementById('wt-add-btn');
  btn.disabled = true; btn.textContent = 'Adding…';
  try {
    const jobId      = parseInt(document.getElementById('wt-new-job')?.value) || null;
    const addedDate  = document.getElementById('wt-new-date')?.value || null;
    const dueDate    = document.getElementById('wt-new-due')?.value || null;
    const isRecurring = document.getElementById('wt-new-recurring')?.checked ? 1 : 0;
    const recurFreq  = document.getElementById('wt-new-freq')?.value || null;
    const r = await fetch('/api/work-tasks', {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({contact_id: cid, title, description: desc, qty, unit_price: price,
                            job_id: jobId, created_at: addedDate,
                            due_date: dueDate, is_recurring: isRecurring, recur_frequency: recurFreq})
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    toast('Task added');
    await _loadWorkTasks(cid);
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = 'Add Task';
  }
}

function _wtEdit(tid) {
  const t = _wtasks.find(x => x.id === tid);
  if (!t) return;
  _wtEditId = tid;
  const jobOpts = `<option value="">No job</option>${_wtJobs.map(j=>`<option value="${j.id}"${t.job_id===j.id?' selected':''}>${esc(j.job_number+' — '+j.name)}</option>`).join('')}`;
  const bd = document.createElement('div');
  _wtEditBd = bd;
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:min(520px,96vw)">
    <div class="modal-title">Edit Task</div>
    <div class="modal-field"><label class="modal-lbl">Title *</label>
      <input class="modal-inp" id="wte-title" value="${esc(t.title)}"></div>
    <div class="modal-field"><label class="modal-lbl">Description</label>
      <input class="modal-inp" id="wte-desc" value="${esc(t.description||'')}"></div>
    <div class="modal-field" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="modal-lbl">Qty</label>
        <input class="modal-inp" id="wte-qty" type="number" step="0.01" value="${t.qty}"></div>
      <div><label class="modal-lbl">Unit Price ($)</label>
        <input class="modal-inp" id="wte-price" type="number" step="0.01" value="${t.unit_price}"></div>
    </div>
    <div class="modal-field"><label class="modal-lbl">Job</label>
      <select class="modal-inp" id="wte-job">${jobOpts}</select></div>
    <div class="modal-field" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="modal-lbl">Date Added</label>
        <input class="modal-inp" id="wte-added" type="date" value="${t.created_at ? t.created_at.split(' ')[0] : ''}"></div>
      <div><label class="modal-lbl">Due Date</label>
        <input class="modal-inp" id="wte-due" type="date" value="${t.due_date || ''}"></div>
    </div>
    <div class="modal-field" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="modal-lbl">Date Completed</label>
        <input class="modal-inp" id="wte-done" type="date" value="${t.done_at ? t.done_at.split(' ')[0] : ''}"></div>
    </div>
    <div class="modal-field" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
      <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
        <input type="checkbox" id="wte-recurring"${t.is_recurring ? ' checked' : ''}
          onchange="document.getElementById('wte-freq-wrap').style.display=this.checked?'flex':'none'">
        Recurring task
      </label>
      <div id="wte-freq-wrap" style="display:${t.is_recurring ? 'flex' : 'none'};align-items:center;gap:6px">
        <label class="modal-lbl" style="margin:0">Frequency</label>
        <select class="modal-inp" id="wte-freq" style="margin:0">
          <option value="">— none —</option>
          ${_wtFreqOptions(t.recur_frequency)}
        </select>
      </div>
    </div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary btn-sm" id="wte-save-btn" onclick="_wtSaveEdit(${t.contact_id})">Save</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  setTimeout(() => document.getElementById('wte-title')?.focus(), 50);
}

async function _wtSaveEdit(cid) {
  const title = (document.getElementById('wte-title')?.value || '').trim();
  if (!title) { toast('Title is required', 'err'); return; }
  const btn = document.getElementById('wte-save-btn');
  btn.disabled = true; btn.textContent = 'Saving…';
  try {
    const r = await fetch(`/api/work-tasks/${_wtEditId}`, {
      method: 'PUT', credentials: 'include',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({
        title,
        description:     (document.getElementById('wte-desc')?.value || '').trim(),
        qty:             parseFloat(document.getElementById('wte-qty')?.value   || '1') || 1,
        unit_price:      parseFloat(document.getElementById('wte-price')?.value || '0') || 0,
        job_id:          parseInt(document.getElementById('wte-job')?.value)   || null,
        created_at:      document.getElementById('wte-added')?.value || null,
        done_at:         document.getElementById('wte-done')?.value  || null,
        due_date:        document.getElementById('wte-due')?.value   || null,
        is_recurring:    document.getElementById('wte-recurring')?.checked ? 1 : 0,
        recur_frequency: document.getElementById('wte-freq')?.value  || null,
      })
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    _wtEditBd?.remove(); _wtEditBd = null;
    toast('Task updated');
    await _loadWorkTasks(cid);
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = 'Save';
  }
}

async function _wtDelete(tid, cid) {
  if (!confirm('Delete this task?')) return;
  try {
    const r = await fetch(`/api/work-tasks/${tid}`, {method:'DELETE', credentials:'include'});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Delete failed');
    toast('Task deleted');
    await _loadWorkTasks(cid);
  } catch(e) {
    toast(e.message, 'err');
  }
}

async function _wtInvoice(cid, taskIds) {
  if (!taskIds.length) { toast('No completed tasks to invoice', 'err'); return; }
  if (!confirm(`Create a draft invoice from ${taskIds.length} completed task${taskIds.length!==1?'s':''}?`)) return;
  try {
    const r = await fetch(`/api/contacts/${cid}/work-tasks/invoice`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({task_ids: taskIds})
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Invoice creation failed');
    toast('Draft invoice created');
    await _loadWorkTasks(cid);
    navigate('invoices');
    setTimeout(() => invOpen(j.data.id), 300);
  } catch(e) {
    toast(e.message, 'err');
  }
}



function conNew() {
  _conEditId=null;
  _showConModal(null);
}

function conEdit(id) {
  _conEditId=id;
  apiFetch(`/api/contacts/${id}`).then(c=>_showConModal(c)).catch(e=>toast(e.message,true));
}

let _conEditId=null;
async function _showConModal(c) {
  let emps=[];
  try { emps=await apiFetch('/api/payroll/employees')||[]; } catch(_){}
  const isNew=!c;
  const v=(f,fb='')=>esc(c?c[f]??fb:fb);
  const sel=(f,opts,fb='')=>opts.map(o=>`<option${(c?c[f]:fb)===o?' selected':''}>${o}</option>`).join('');
  const activeRow=!isNew?`
      <div class="edt-field edt-span form-field-check">
        <input type="checkbox" id="cf-active"${c.is_active?' checked':''}>
        <label class="form-lbl" for="cf-active">Active</label>
      </div>`:'';
  const approvedChecked=c&&c.approved_account;
  const empOpts=emps.map(e=>`<option value="${e.id}"${(c&&c.approved_by_employee_id==e.id)?' selected':''}>${esc((e.first_name||'')+' '+(e.last_name||''))}</option>`).join('');
  showConModal(isNew?'New Contact':`Edit — ${c.name}`, `
    <div class="edt-grid">
      <div class="edt-field edt-span"><label class="edt-lbl">Name *</label><input class="edt-inp" id="cf-name" value="${v('name')}"></div>
      <div class="edt-field"><label class="edt-lbl">Type *</label>
        <select class="edt-sel" id="cf-type">${sel('contact_type',['Customer','Supplier','Both','Employee'],'Customer')}</select></div>
      <div class="edt-field"><label class="edt-lbl">ABN</label><input class="edt-inp" id="cf-abn" value="${v('abn')}"></div>
      <div class="edt-field"><label class="edt-lbl">Contact Person</label><input class="edt-inp" id="cf-person" value="${v('contact_person')}"></div>
      <div class="edt-field"><label class="edt-lbl">Email</label><input class="edt-inp" id="cf-email" type="email" value="${v('email')}"></div>
      <div class="edt-field"><label class="edt-lbl">Phone</label><input class="edt-inp" id="cf-phone" value="${v('phone')}"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Address</label><input class="edt-inp" id="cf-address" value="${v('address')}"></div>
      <div class="edt-field"><label class="edt-lbl">City</label><input class="edt-inp" id="cf-city" value="${v('city')}"></div>
      <div class="edt-field"><label class="edt-lbl">State</label><input class="edt-inp" id="cf-state" value="${v('state')}"></div>
      <div class="edt-field"><label class="edt-lbl">Postcode</label><input class="edt-inp" id="cf-postcode" value="${v('postcode')}"></div>
      <div class="edt-field"><label class="edt-lbl">Payment Terms (days)</label><input class="edt-inp" id="cf-terms" type="number" value="${v('payment_terms','30')}"></div>
      <div class="edt-field"><label class="edt-lbl">Default Tax Code</label>
        <select class="edt-sel" id="cf-tax">${sel('default_tax_code',['GST','FRE','INP','N-T','CAP'],'GST')}</select></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Notes</label><textarea class="edt-inp edt-ta-resize" id="cf-notes" rows="2">${c?esc(c.notes||''):''}</textarea></div>
      ${activeRow}
      <div class="edt-field edt-span form-field-check">
        <input type="checkbox" id="cf-approved-acct"${approvedChecked?' checked':''} onchange="conToggleApproved(this)">
        <label class="form-lbl" for="cf-approved-acct">Approved Account <span class="con-field-hint">(allows on-account sales in POS)</span></label>
      </div>
      <div class="edt-field edt-span" id="cf-approved-by-row" style="display:${approvedChecked?'':'none'}">
        <label class="edt-lbl">Approved By <span class="con-field-hint">(optional)</span></label>
        <select class="edt-sel" id="cf-approved-by">
          <option value="">— not specified —</option>
          ${empOpts}
        </select>
      </div>
      <div class="edt-field edt-span con-edit-section-hdr">
        <span class="con-bank-lbl">Bank Details (ABA payments)</span></div>
      <div class="edt-field"><label class="edt-lbl">BSB</label><input class="edt-inp" id="cf-bsb" value="${v('bsb')}"></div>
      <div class="edt-field"><label class="edt-lbl">Account Number</label><input class="edt-inp" id="cf-accnum" value="${v('account_number')}"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Account Name</label><input class="edt-inp" id="cf-accname" value="${v('bank_account_name')}"></div>
    </div>
  `);
}

function conToggleApproved(cb) {
  document.getElementById('cf-approved-by-row').style.display=cb.checked?'':'none';
}

// Lightweight modal for contacts (reuses det-panel as edit surface)
function showConModal(title, html) {
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent=title;
  document.getElementById('det-body').innerHTML=`<div class="edt-body-pad">${html}</div>`;
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="con-save-btn" onclick="saveContact()">Save</button>
    <button class="btn btn-outline" onclick="${_conEditId?`conOpen(${_conEditId})`:'detClose()'}">Cancel</button>`;
  setTimeout(()=>{ const f=document.getElementById('cf-name'); if(f) f.focus(); }, 50);
}

async function saveContact() {
  const name=(document.getElementById('cf-name')?.value||'').trim();
  if(!name){toast('Name is required',true);return;}
  const btn=document.getElementById('con-save-btn');
  btn.disabled=true; btn.textContent='Saving\u2026';
  // FIX 4: read Active checkbox; default to 1 for new contacts
  const activeEl=document.getElementById('cf-active');
  const payload={
    name, contact_type:document.getElementById('cf-type').value,
    abn:document.getElementById('cf-abn').value.trim(),
    contact_person:document.getElementById('cf-person').value.trim(),
    email:document.getElementById('cf-email').value.trim(),
    phone:document.getElementById('cf-phone').value.trim(),
    address:document.getElementById('cf-address').value.trim(),
    city:document.getElementById('cf-city').value.trim(),
    state:document.getElementById('cf-state').value.trim(),
    postcode:document.getElementById('cf-postcode').value.trim(),
    payment_terms:parseInt(document.getElementById('cf-terms').value||30),
    default_tax_code:document.getElementById('cf-tax').value,
    notes:document.getElementById('cf-notes').value.trim(),
    bsb:document.getElementById('cf-bsb').value.trim(),
    account_number:document.getElementById('cf-accnum').value.trim(),
    bank_account_name:document.getElementById('cf-accname').value.trim(),
    is_active:activeEl?(activeEl.checked?1:0):1,
    approved_account:document.getElementById('cf-approved-acct')?.checked?1:0,
    approved_by_employee_id:(()=>{const cb=document.getElementById('cf-approved-acct');const sel=document.getElementById('cf-approved-by');return(cb?.checked&&sel?.value)?parseInt(sel.value):null;})(),
  };
  try {
    let savedId=_conEditId;
    if(_conEditId) {
      const r=await fetch(`/api/contacts/${_conEditId}`,{method:'PUT',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
    } else {
      const r=await fetch('/api/contacts',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
      savedId=j.data?.id;
    }
    // Invalidate cached contact lists used by other modules
    _contacts=[];_editContacts=null;_billEditContacts=null;
    toast('Contact saved');
    _conAll=await apiFetch('/api/contacts')||[];
    if(savedId) { _conSelected=savedId; await conOpen(savedId); }
    else { detClose(); renderContactsPage(); }
  } catch(e){
    toast(e.message,true);
    btn.disabled=false; btn.textContent='Save';
  }
}

// FIX 5: Statement of Account — date-range modal → streams PDF from server
async function conStatement(id) {
  const today=isoToday();
  const n=new Date(); const firstOfMonth=`${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,'0')}-01`;
  const bd=document.createElement('div');
  bd.className='modal-bd';
  bd.style.display='flex';
  bd.innerHTML=`
    <div class="modal-box" style="width:min(440px,94vw)">
      <div class="modal-title">Statement of Account</div>
      <div class="modal-field">
        <label class="modal-lbl">Date From</label>
        <input class="modal-inp" type="date" id="stmt-from" value="${firstOfMonth}">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Date To</label>
        <input class="modal-inp" type="date" id="stmt-to" value="${today}">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Email To (optional)</label>
        <input class="modal-inp" type="email" id="stmt-email" placeholder="contact@example.com">
      </div>
      <div class="modal-acts">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-outline btn-sm" id="stmt-go-btn" onclick="_conStmtGenerate(${id})">📄 Download PDF</button>
        <button class="btn btn-primary btn-sm" id="stmt-eml-btn" onclick="_conStmtEmail(${id})">📧 Email</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
  try {
    const c=await apiFetch(`/api/contacts/${id}`);
    if(c?.email) document.getElementById('stmt-email').value=c.email;
  } catch(e){}
}

async function _conStmtGenerate(id) {
  const dateFrom=document.getElementById('stmt-from').value;
  const dateTo=document.getElementById('stmt-to').value;
  if(!dateFrom||!dateTo){toast('Both dates are required','err');return;}
  if(dateFrom>dateTo){toast('Date From must be before Date To','err');return;}
  const btn=document.getElementById('stmt-go-btn');
  btn.disabled=true; btn.textContent='Generating\u2026';
  try {
    const url=`/api/contacts/${id}/statement?date_from=${dateFrom}&date_to=${dateTo}`;
    const r=await fetch(url,{credentials:'include'});
    if(!r.ok){let msg='Failed';try{const j=await r.json();msg=j.error||msg;}catch(_){}throw new Error(msg);}
    const blob=await r.blob();
    const a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download=`statement_${id}_${dateFrom}_${dateTo}.pdf`;
    a.click();
    document.getElementById('stmt-go-btn')?.closest('.modal-bd')?.remove();
    toast('Statement downloaded');
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent='📄 Download PDF';
  }
}

async function _conStmtEmail(id) {
  const dateFrom=document.getElementById('stmt-from')?.value;
  const dateTo=document.getElementById('stmt-to')?.value;
  const toEmail=(document.getElementById('stmt-email')?.value||'').trim();
  if(!dateFrom||!dateTo){toast('Both dates are required','err');return;}
  if(dateFrom>dateTo){toast('Date From must be before Date To','err');return;}
  if(!toEmail){toast('Email address is required','err');return;}
  const btn=document.getElementById('stmt-eml-btn');
  btn.disabled=true; btn.textContent='Sending…';
  try {
    const r=await fetch(`/api/contacts/${id}/statement/email`,{method:'POST',credentials:'include',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({to:toEmail,date_from:dateFrom,date_to:dateTo})});
    const j=await r.json();
    if(!j.ok) throw new Error(j.error||'Send failed');
    btn.closest('.modal-bd')?.remove();
    toast('Statement emailed');
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent='📧 Email';
  }
}

// ── Contact Merge ─────────────────────────────────────────────────────────────

let _conMergeKeepId = null, _conMergeDropId = null;

async function conMerge(keepId) {
  _conMergeKeepId = keepId;
  _conMergeDropId = null;
  const keep = _conAll.find(c => c.id === keepId);
  const others = _conAll.filter(c => c.id !== keepId && !c.is_system);
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.id = 'con-merge-bd';
  bd.innerHTML = `
    <div class="modal-box" style="display:flex;flex-direction:column;max-height:90vh;width:min(540px,96vw)">
      <div class="modal-hdr">
        <div class="modal-title" style="margin-bottom:0">Merge Contact</div>
        <button class="btn-icon" onclick="document.getElementById('con-merge-bd')?.remove()">✕</button>
      </div>
      <div class="modal-body" style="overflow-y:auto;flex:1;padding:16px 20px">
        <div class="con-merge-keep-row">
          <div class="con-merge-label">Keeping</div>
          <div class="con-merge-name">${esc(keep?.name || '')}</div>
          <div class="con-merge-hint">All records from the duplicate will be reassigned to this contact.</div>
        </div>
        <div class="con-merge-search-row">
          <label class="modal-lbl">Select duplicate to remove</label>
          <input class="modal-inp" id="con-merge-q" placeholder="Search by name, email or phone…" oninput="_conMergeFilter()">
        </div>
        <div id="con-merge-list" class="con-merge-list">
          ${_conMergeRows(others, '')}
        </div>
        <div id="con-merge-confirm" class="con-merge-confirm" style="display:none">
          <div class="con-merge-warn">⚠ This will permanently delete <strong id="con-merge-drop-name"></strong> and reassign all their invoices, bills, jobs, and other records to <strong>${esc(keep?.name || '')}</strong>. This cannot be undone.</div>
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="document.getElementById('con-merge-bd')?.remove()">Cancel</button>
        <button class="btn btn-danger btn-sm" id="con-merge-go-btn" disabled onclick="_conMergeConfirm(${keepId})">Merge & Delete Duplicate</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
  setTimeout(() => document.getElementById('con-merge-q')?.focus(), 50);
}

function _conMergeRows(contacts, q) {
  const filtered = q
    ? contacts.filter(c => [c.name, c.email, c.phone].some(v => (v||'').toLowerCase().includes(q.toLowerCase())))
    : contacts;
  if (!filtered.length) return `<div class="con-merge-empty">No contacts match</div>`;
  return filtered.map(c => `
    <div class="con-merge-row${_conMergeDropId===c.id?' selected':''}" data-cid="${c.id}" onclick="_conMergeSelect(${c.id})">
      <div class="con-merge-row-name">${esc(c.name)}</div>
      <div class="con-merge-row-meta">
        <span class="badge ${CON_TYPE_BADGE[c.contact_type]||'badge-draft'} badge-sm-inline">${esc(c.contact_type||'')}</span>
        ${c.email ? `<span class="td-sm">${esc(c.email)}</span>` : ''}
        ${c.phone ? `<span class="td-sm">${esc(c.phone)}</span>` : ''}
      </div>
    </div>`).join('');
}

function _conMergeFilter() {
  const q = (document.getElementById('con-merge-q')?.value || '').trim();
  const others = _conAll.filter(c => c.id !== _conMergeKeepId && !c.is_system);
  document.getElementById('con-merge-list').innerHTML = _conMergeRows(others, q);
}

function _conMergeSelect(dropId) {
  _conMergeDropId = dropId;
  const drop = _conAll.find(c => c.id === dropId);
  document.querySelectorAll('#con-merge-list .con-merge-row').forEach(el => {
    el.classList.toggle('selected', parseInt(el.dataset.cid) === dropId);
  });
  const confirmEl = document.getElementById('con-merge-confirm');
  const nameEl    = document.getElementById('con-merge-drop-name');
  if (confirmEl && nameEl) {
    nameEl.textContent = drop?.name || '';
    confirmEl.style.display = 'block';
  }
  const goBtn = document.getElementById('con-merge-go-btn');
  if (goBtn) goBtn.disabled = false;
}

async function _conMergeConfirm(keepId) {
  if (!_conMergeDropId) return;
  const drop = _conAll.find(c => c.id === _conMergeDropId);
  const keep = _conAll.find(c => c.id === keepId);
  if (!confirm(`Merge "${drop?.name}" into "${keep?.name}" and permanently delete "${drop?.name}"?\n\nThis cannot be undone.`)) return;
  const btn = document.getElementById('con-merge-go-btn');
  btn.disabled = true; btn.textContent = 'Merging…';
  try {
    const r = await fetch(`/api/contacts/${keepId}/merge`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({merge_with: _conMergeDropId})
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Merge failed');
    document.getElementById('con-merge-bd')?.remove();
    toast(`Merged — "${drop?.name}" deleted`);
    _conAll = await apiFetch('/api/contacts') || [];
    _contacts = []; _editContacts = null; _billEditContacts = null;
    renderContactsPage();
    await conOpen(keepId);
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = 'Merge & Delete Duplicate';
  }
}

// ── Bulk Statements ───────────────────────────────────────────────────────────

async function conBulkStatements() {
  const today = isoToday();
  const n = new Date();
  const yearStart = `${n.getFullYear()}-01-01`;

  const targets = _conAll.filter(c =>
    c.is_active !== 0 &&
    ['Customer','Both'].includes(c.contact_type) &&
    c.email
  );

  if (!targets.length) {
    toast('No active customers with email addresses found', 'err');
    return;
  }

  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:min(560px,96vw);display:flex;flex-direction:column;max-height:90vh">
    <div class="modal-title">📧 Bulk Statements</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:0 0 8px">
      <div class="modal-field" style="margin:0">
        <label class="modal-lbl">Date From</label>
        <input class="modal-inp" type="date" id="bstmt-from" value="${yearStart}">
      </div>
      <div class="modal-field" style="margin:0">
        <label class="modal-lbl">Date To</label>
        <input class="modal-inp" type="date" id="bstmt-to" value="${today}">
      </div>
    </div>
    <div class="bulk-sel-hdr">
      <span id="bstmt-count">${targets.length} of ${targets.length} selected</span>
      <span>
        <button class="btn-link" onclick="_bstmtToggleAll(true)">Select all</button>
        &nbsp;·&nbsp;
        <button class="btn-link" onclick="_bstmtToggleAll(false)">Deselect all</button>
      </span>
    </div>
    <div style="overflow-y:auto;flex:1;max-height:260px;border:1px solid var(--border);border-radius:6px">
      ${targets.map(c => `
        <label class="bulk-row">
          <input type="checkbox" class="bstmt-chk" data-cid="${c.id}" data-email="${esc(c.email)}" data-name="${esc(c.name)}" checked>
          <span class="bulk-row-name">${esc(c.name)}</span>
          <span class="bulk-row-email">${esc(c.email)}</span>
        </label>`).join('')}
    </div>
    <div id="bstmt-progress" style="display:none;padding:8px 0;font-size:13px;color:var(--ink3)"></div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" id="bstmt-cancel" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary btn-sm" id="bstmt-send-btn" onclick="_bstmtSend()">📧 Send Statements</button>
    </div>
  </div>`;
  document.body.appendChild(bd);

  bd.addEventListener('change', () => {
    const sel = bd.querySelectorAll('.bstmt-chk:checked').length;
    const el = document.getElementById('bstmt-count');
    if (el) el.textContent = `${sel} of ${targets.length} selected`;
  });
}

function _bstmtToggleAll(state) {
  document.querySelectorAll('.bstmt-chk').forEach(cb => { cb.checked = state; });
  const total = document.querySelectorAll('.bstmt-chk').length;
  const el = document.getElementById('bstmt-count');
  if (el) el.textContent = `${state ? total : 0} of ${total} selected`;
}

async function _bstmtSend() {
  const dateFrom = (document.getElementById('bstmt-from')?.value || '').trim();
  const dateTo   = (document.getElementById('bstmt-to')?.value || '').trim();
  if (!dateFrom || !dateTo) { toast('Both dates are required', 'err'); return; }
  if (dateFrom > dateTo)   { toast('Date From must be before Date To', 'err'); return; }

  const checked = [...document.querySelectorAll('.bstmt-chk:checked')].map(cb => ({
    id:    parseInt(cb.dataset.cid),
    email: cb.dataset.email,
    name:  cb.dataset.name,
  }));
  if (!checked.length) { toast('No contacts selected', 'err'); return; }

  const btn      = document.getElementById('bstmt-send-btn');
  const cancelBtn= document.getElementById('bstmt-cancel');
  const progress = document.getElementById('bstmt-progress');
  btn.disabled = cancelBtn.disabled = true;
  progress.style.display = 'block';

  let sent = 0, failed = 0, errors = [];
  for (let i = 0; i < checked.length; i++) {
    const {id, email, name} = checked[i];
    progress.textContent = `Sending ${i + 1} of ${checked.length}: ${name}…`;
    try {
      const r = await fetch(`/api/contacts/${id}/statement/email`, {
        method: 'POST', credentials: 'include',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({to: email, date_from: dateFrom, date_to: dateTo}),
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Send failed');
      sent++;
    } catch(e) {
      failed++;
      errors.push(`${name}: ${e.message}`);
    }
  }

  if (!failed) {
    btn.closest('.modal-bd').remove();
    toast(`${sent} statement${sent !== 1 ? 's' : ''} sent`);
  } else {
    progress.innerHTML = `<strong>${sent} sent, ${failed} failed:</strong><br>${errors.map(e => esc(e)).join('<br>')}`;
    btn.textContent = 'Close';
    btn.disabled = false;
    btn.onclick = () => btn.closest('.modal-bd').remove();
    cancelBtn.style.display = 'none';
  }
}

// ── Duplicate Detection ───────────────────────────────────────────────────────

function _conNormName(name) {
  const noise = /\b(pty|ltd|limited|the|and|co|company|group|services|trading|australia|au)\b/g;
  return (name || '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(noise, '').replace(/\s+/g, ' ').trim();
}

function _conNameSimilar(a, b) {
  const wa = _conNormName(a).split(' ').filter(Boolean);
  const wb = _conNormName(b).split(' ').filter(Boolean);
  if (wa.length < 2 || wb.length < 2) {
    // Short names: require exact normalised match
    return _conNormName(a) === _conNormName(b) && _conNormName(a).length > 2;
  }
  const sa = new Set(wa), sb = new Set(wb);
  let overlap = 0;
  sa.forEach(w => { if (sb.has(w)) overlap++; });
  const score = overlap / Math.max(sa.size, sb.size);
  return score >= 0.6;
}

function _conFindDupPairs(contacts) {
  const pairs = [];
  const seen = new Set();
  const active = contacts.filter(c => !c.is_system);

  for (let i = 0; i < active.length; i++) {
    for (let j = i + 1; j < active.length; j++) {
      const a = active[i], b = active[j];
      const key = `${Math.min(a.id,b.id)}-${Math.max(a.id,b.id)}`;
      if (seen.has(key)) continue;

      const reasons = [];
      if (a.abn && b.abn && a.abn.replace(/\s/g,'') === b.abn.replace(/\s/g,''))
        reasons.push('Same ABN');
      if (a.email && b.email && a.email.toLowerCase() === b.email.toLowerCase())
        reasons.push('Same email');
      const aPhone = (a.phone||'').replace(/\D/g,'');
      const bPhone = (b.phone||'').replace(/\D/g,'');
      if (aPhone.length >= 8 && aPhone === bPhone)
        reasons.push('Same phone');
      if (_conNameSimilar(a.name, b.name))
        reasons.push('Similar name');

      if (reasons.length) {
        seen.add(key);
        pairs.push({a, b, reasons});
      }
    }
  }
  return pairs;
}

function conFindDuplicates() {
  const pairs = _conFindDupPairs(_conAll);
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.id = 'con-dup-bd';

  const rows = pairs.length ? pairs.map((p, idx) => `
    <div class="con-dup-pair" id="con-dup-pair-${idx}">
      <div class="con-dup-reasons">${p.reasons.map(r=>`<span class="con-dup-reason">${r}</span>`).join('')}</div>
      <div class="con-dup-names">
        <div class="con-dup-card">
          <div class="con-dup-card-name">${esc(p.a.name)}</div>
          <div class="con-dup-card-meta">
            <span class="badge ${CON_TYPE_BADGE[p.a.contact_type]||'badge-draft'} badge-sm-inline">${esc(p.a.contact_type||'')}</span>
            ${p.a.email?`<span class="td-sm">${esc(p.a.email)}</span>`:''}
            ${p.a.phone?`<span class="td-sm">${esc(p.a.phone)}</span>`:''}
            ${p.a.abn?`<span class="td-sm">ABN ${esc(p.a.abn)}</span>`:''}
            ${!p.a.is_active?'<span class="badge badge-draft badge-sm-inline">Inactive</span>':''}
          </div>
        </div>
        <div class="con-dup-arrow">→</div>
        <div class="con-dup-card">
          <div class="con-dup-card-name">${esc(p.b.name)}</div>
          <div class="con-dup-card-meta">
            <span class="badge ${CON_TYPE_BADGE[p.b.contact_type]||'badge-draft'} badge-sm-inline">${esc(p.b.contact_type||'')}</span>
            ${p.b.email?`<span class="td-sm">${esc(p.b.email)}</span>`:''}
            ${p.b.phone?`<span class="td-sm">${esc(p.b.phone)}</span>`:''}
            ${p.b.abn?`<span class="td-sm">ABN ${esc(p.b.abn)}</span>`:''}
            ${!p.b.is_active?'<span class="badge badge-draft badge-sm-inline">Inactive</span>':''}
          </div>
        </div>
      </div>
      <div class="con-dup-actions">
        <button class="btn btn-sm btn-outline" onclick="_conDupMerge(${p.a.id},${p.b.id},'con-dup-bd')">
          Keep "${esc(p.a.name)}" →
        </button>
        <button class="btn btn-sm btn-outline" onclick="_conDupMerge(${p.b.id},${p.a.id},'con-dup-bd')">
          Keep "${esc(p.b.name)}" →
        </button>
        <button class="btn btn-sm btn-ghost" onclick="this.closest('.con-dup-pair').remove();_conDupCheckEmpty()">
          Not a duplicate
        </button>
      </div>
    </div>`).join('') :
    `<div class="con-dup-empty">No duplicate contacts detected.</div>`;

  bd.innerHTML = `
    <div class="modal-box" style="display:flex;flex-direction:column;max-height:90vh;width:min(640px,96vw)">
      <div class="modal-hdr">
        <div class="modal-title" style="margin-bottom:0">Find Duplicate Contacts</div>
        <button class="btn-icon" onclick="document.getElementById('con-dup-bd')?.remove()">✕</button>
      </div>
      <div class="modal-body" style="overflow-y:auto;flex:1;padding:16px 20px" id="con-dup-body">
        ${pairs.length
          ? `<p class="con-dup-summary">${pairs.length} potential duplicate pair${pairs.length!==1?'s':''} found. Review each pair and choose which record to keep, or dismiss if they are not duplicates.</p>`
          : ''}
        <div id="con-dup-list">${rows}</div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="document.getElementById('con-dup-bd')?.remove()">Close</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
}

function _conDupCheckEmpty() {
  const list = document.getElementById('con-dup-list');
  if (list && !list.querySelector('.con-dup-pair')) {
    list.innerHTML = '<div class="con-dup-empty">All pairs reviewed.</div>';
  }
}

async function _conDupMerge(keepId, dropId, parentBdId) {
  const drop = _conAll.find(c => c.id === dropId);
  const keep = _conAll.find(c => c.id === keepId);
  if (!confirm(`Merge "${drop?.name}" into "${keep?.name}" and permanently delete "${drop?.name}"?\n\nThis cannot be undone.`)) return;
  try {
    const r = await fetch(`/api/contacts/${keepId}/merge`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({merge_with: dropId})
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Merge failed');
    toast(`Merged — "${drop?.name}" deleted`);
    _conAll = await apiFetch('/api/contacts') || [];
    _contacts = []; _editContacts = null; _billEditContacts = null;
    renderContactsPage();
    document.getElementById(parentBdId)?.remove();
    // Re-run detection and re-open if any pairs remain
    const remaining = _conFindDupPairs(_conAll);
    if (remaining.length) conFindDuplicates();
  } catch(e) {
    toast(e.message, 'err');
  }
}
