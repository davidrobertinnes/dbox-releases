// ═══════════════════════════════════════════════════════════════════════════
// CONTACTS PAGE
// ═══════════════════════════════════════════════════════════════════════════
let _conAll=[],_conFilter='All',_conSearch='',_conSort={col:'name',dir:1},_conSelected=null;
const CON_TYPES=['All','Customer','Supplier','Both','Employee'];

async function pageContacts() {
  try {
    _conAll = await apiFetch('/api/contacts') || [];
    renderContactsPage();
  } catch(e) {
    document.getElementById('module-content').innerHTML=`<div class="state-error">Failed to load contacts: ${esc(e.message)}</div>`;
  }
}

function _conFiltered() {
  const q=_conSearch.toLowerCase();
  return _conAll.filter(c=>{
    if(_conFilter==='Employee'&&!c.has_employee) return false;
    else if(_conFilter!=='All'&&_conFilter!=='Employee'&&c.contact_type!==_conFilter) return false;
    if(q&&![c.name,c.email,c.phone,c.abn,c.contact_person].some(v=>(v||'').toLowerCase().includes(q))) return false;
    return true;
  }).sort((a,b)=>{
    const col=_conSort.col, av=a[col]??'', bv=b[col]??'';
    return(typeof av==='number'?(av-bv):String(av).localeCompare(String(bv)))*_conSort.dir;
  });
}

function renderContactsPage(restoreFocus) {
  const rows=_conFiltered();
  const counts={All:_conAll.length};
  CON_TYPES.slice(1).forEach(t=>{ counts[t]=_conAll.filter(c=>t==='Employee'?c.has_employee:c.contact_type===t).length; });
  const mc=document.getElementById('module-content');
  mc.innerHTML=`
    <div class="inv-toolbar">
      <input class="inv-search" id="con-q" placeholder="Search name, email, phone, ABN\u2026" value="${esc(_conSearch)}">
      <div class="inv-filter-group">
        ${CON_TYPES.map(t=>`<button class="filter-btn${_conFilter===t?' active':''}" onclick="conSetFilter('${t}')">
          ${t}${counts[t]?` <span class="filter-count">(${counts[t]})</span>`:''}</button>`).join('')}
      </div>
      <button class="btn btn-primary" onclick="conNew()">+ New Contact</button>
    </div>
    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        ${conTh('name','Name')}${conTh('contact_type','Type')}
        ${conTh('email','Email')}${conTh('phone','Phone')}
        ${conTh('abn','ABN')}${conTh('payment_terms','Terms','r')}
      </tr></thead><tbody>
        ${rows.length ? rows.map(conRow).join('') : `<tr><td colspan="6" class="tbl-empty-row">No contacts match your filter</td></tr>`}
      </tbody></table>
    </div></div>
    <div class="list-count-row"><span class="count-pill">${rows.length} of ${_conAll.length} contact${_conAll.length!==1?'s':''}</span></div>`;
  const q=document.getElementById('con-q');
  if(q){
    q.addEventListener('input',e=>{_conSearch=e.target.value;renderContactsPage(true);});
    if(restoreFocus){q.focus();q.setSelectionRange(q.value.length,q.value.length);}
  }
}

// FIX 3: merge sort class and alignment class into a single class attribute
function conTh(col,label,align) {
  const sortCls=_conSort.col===col?(_conSort.dir>0?'sort-asc':'sort-desc'):'';
  const cls=[sortCls,align==='r'?'th-r':''].filter(Boolean).join(' ');
  return `<th${cls?` class="${cls}"`:''} onclick="conSortBy('${col}')">${label}</th>`;
}

// FIX 1: badge-green → badge-paid (defined in dbox.css; badge-green is not)
const CON_TYPE_BADGE={'Customer':'badge-pending','Supplier':'badge-partial','Both':'badge-partial','Employee':'badge-paid'};

function conRow(c) {
  const sel=_conSelected===c.id;
  // FIX 1: badge-green → badge-paid
  const empBadge=c.has_employee?'<span class="badge badge-paid badge-sm-inline">Employee</span>':'';
  return `<tr class="inv-row${sel?' acct-row-selected':''}" onclick="conOpen(${c.id})">
    <td><span class="inv-contact">${esc(c.name)}</span>${!c.is_active?'<span class="badge badge-draft badge-sm-inline">Inactive</span>':''}${empBadge}</td>
    <td><span class="badge ${CON_TYPE_BADGE[c.contact_type]||'badge-draft'}">${esc(c.contact_type||'—')}</span></td>
    <td><span class="inv-mono td-sm">${esc(c.email||'—')}</span></td>
    <td><span class="inv-mono td-sm">${esc(c.phone||'—')}</span></td>
    <td><span class="inv-mono">${esc(c.abn||'—')}</span></td>
    <td class="td-r-mono">${c.payment_terms?c.payment_terms+' days':'—'}</td>
  </tr>`;
}

function conSortBy(col){_conSort={col,dir:_conSort.col===col?_conSort.dir*-1:1};renderContactsPage();}
function conSetFilter(f){_conFilter=f;renderContactsPage();}

async function conOpen(id) {
  _conSelected=id;
  renderContactsPage();
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent='Contact';
  document.getElementById('det-body').innerHTML='<div class="state-loading">Loading\u2026</div>';
  document.getElementById('det-foot').innerHTML='';
  try {
    const c=await apiFetch(`/api/contacts/${id}`);
    renderConDetail(c);
  } catch(e) {
    document.getElementById('det-body').innerHTML=`<div class="state-error">${esc(e.message)}</div>`;
  }
}

// FIX 2: replace inv-detail-grid/row/lbl with det-meta/det-lbl/det-val (defined in dbox.css)
// FIX 1: badge-green → badge-paid in detail badge row
function renderConDetail(c) {
  document.getElementById('det-title').textContent=c.name;
  const addr=[c.address,c.city,c.state,c.postcode].filter(Boolean).join(', ');
  document.getElementById('det-body').innerHTML=`
    <div class="con-badge-row">
      <span class="badge ${CON_TYPE_BADGE[c.contact_type]||'badge-draft'}">${esc(c.contact_type||'Contact')}</span>
      ${c.has_employee?'<span class="badge badge-paid">Employee</span>':''}
      ${!c.is_active?'<span class="badge badge-draft">Inactive</span>':''}
    </div>
    <div class="det-meta">
      <div>
        <div class="det-lbl">Email</div>
        <div class="det-val">${c.email?`<a href="mailto:${esc(c.email)}" class="lnk-accent">${esc(c.email)}</a>`:'—'}</div>
      </div>
      <div>
        <div class="det-lbl">Phone</div>
        <div class="det-val">${esc(c.phone||'—')}</div>
      </div>
      <div>
        <div class="det-lbl">ABN</div>
        <div class="det-val mono">${esc(c.abn||'—')}</div>
      </div>
      <div>
        <div class="det-lbl">Contact Person</div>
        <div class="det-val">${esc(c.contact_person||'—')}</div>
      </div>
      ${addr?`<div class="con-addr-row">
        <div class="det-lbl">Address</div>
        <div class="det-val">${esc(addr)}</div>
      </div>`:''}
      <div>
        <div class="det-lbl">Payment Terms</div>
        <div class="det-val">${c.payment_terms?c.payment_terms+' days':'—'}</div>
      </div>
      <div>
        <div class="det-lbl">Default Tax</div>
        <div class="det-val mono">${esc(c.default_tax_code||'—')}</div>
      </div>
    </div>
    ${c.notes?`<div class="con-notes-box">${esc(c.notes)}</div>`:''}
    ${(c.bsb||c.account_number)?`
    <div class="con-bank-section">
      <div class="con-bank-lbl">Bank Details</div>
      <div class="det-meta">
        <div>
          <div class="det-lbl">BSB</div>
          <div class="det-val mono">${esc(c.bsb||'—')}</div>
        </div>
        <div>
          <div class="det-lbl">Account No.</div>
          <div class="det-val mono">${esc(c.account_number||'—')}</div>
        </div>
        ${c.bank_account_name?`<div class="con-addr-row">
          <div class="det-lbl">Account Name</div>
          <div class="det-val">${esc(c.bank_account_name)}</div>
        </div>`:''}
      </div>
    </div>`:''}`;
  // FIX 5: Statement of Account button added to detail footer
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" onclick="conEdit(${c.id})">✏ Edit</button>
    <button class="btn btn-outline" onclick="conStatement(${c.id})">📄 Statement</button>
    <button class="btn btn-outline" onclick="conNew()">+ New Contact</button>
    <button class="btn btn-outline" onclick="detClose()">Close</button>`;
}

function conNew() {
  _conEditId=null;
  _showConModal(null);
}

function conEdit(id) {
  _conEditId=id;
  apiFetch(`/api/contacts/${id}`).then(c=>_showConModal(c)).catch(e=>toast(e.message,true));
}

let _conEditId=null;
function _showConModal(c) {
  const isNew=!c;
  const v=(f,fb='')=>esc(c?c[f]??fb:fb);
  const sel=(f,opts,fb='')=>opts.map(o=>`<option${(c?c[f]:fb)===o?' selected':''}>${o}</option>`).join('');
  // FIX 4: Active checkbox added; shown only when editing an existing contact
  const activeRow=!isNew?`
      <div class="edt-field edt-span form-field-check">
        <input type="checkbox" id="cf-active"\${c.is_active?' checked':''}>
        <label class="form-lbl" for="cf-active">Active</label>
      </div>`:'';
  showConModal(isNew?'New Contact':`Edit — ${c.name}`, `
    <div class="edt-grid">
      <div class="edt-field edt-span"><label class="edt-lbl">Name *</label><input class="edt-inp" id="cf-name" value="${v('name')}"></div>
      <div class="edt-field"><label class="edt-lbl">Type *</label>
        <select class="edt-sel" id="cf-type">${sel('contact_type',['Customer','Supplier','Both','Employee'],'Customer')}</select></div>
      <div class="edt-field"><label class="edt-lbl">ABN</label><input class="edt-inp" id="cf-abn" value="${v('abn')}"></div>
      <div class="edt-field"><label class="edt-lbl">Contact Person</label><input class="edt-inp" id="cf-person" value="${v('contact_person')}"></div>
      <div class="edt-field"><label class="edt-lbl">Email</label><input class="edt-inp" id="cf-email" type="email" value="${v('email')}"></div>
      <div class="edt-field"><label class="edt-lbl">Phone</label><input class="edt-inp" id="cf-phone" value="${v('phone')}"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Address</label><input class="edt-inp" id="cf-address" value="${v('address')}"></div>
      <div class="edt-field"><label class="edt-lbl">City</label><input class="edt-inp" id="cf-city" value="${v('city')}"></div>
      <div class="edt-field"><label class="edt-lbl">State</label><input class="edt-inp" id="cf-state" value="${v('state')}"></div>
      <div class="edt-field"><label class="edt-lbl">Postcode</label><input class="edt-inp" id="cf-postcode" value="${v('postcode')}"></div>
      <div class="edt-field"><label class="edt-lbl">Payment Terms (days)</label><input class="edt-inp" id="cf-terms" type="number" value="${v('payment_terms','30')}"></div>
      <div class="edt-field"><label class="edt-lbl">Default Tax Code</label>
        <select class="edt-sel" id="cf-tax">${sel('default_tax_code',['GST','FRE','INP','N-T','CAP'],'GST')}</select></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Notes</label><textarea class="edt-inp edt-ta-resize" id="cf-notes" rows="2">${c?esc(c.notes||''):''}</textarea></div>
      ${activeRow}
      <div class="edt-field edt-span con-edit-section-hdr">
        <span class="con-bank-lbl">Bank Details (ABA payments)</span></div>
      <div class="edt-field"><label class="edt-lbl">BSB</label><input class="edt-inp" id="cf-bsb" value="${v('bsb')}"></div>
      <div class="edt-field"><label class="edt-lbl">Account Number</label><input class="edt-inp" id="cf-accnum" value="${v('account_number')}"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Account Name</label><input class="edt-inp" id="cf-accname" value="${v('bank_account_name')}"></div>
    </div>
  `);
}

// Lightweight modal for contacts (reuses det-panel as edit surface)
function showConModal(title, html) {
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent=title;
  document.getElementById('det-body').innerHTML=`<div class="edt-body-pad">${html}</div>`;
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="con-save-btn" onclick="saveContact()">Save</button>
    <button class="btn btn-outline" onclick="${_conEditId?`conOpen(${_conEditId})`:'detClose()'}">Cancel</button>`;
  setTimeout(()=>{ const f=document.getElementById('cf-name'); if(f) f.focus(); }, 50);
}

async function saveContact() {
  const name=(document.getElementById('cf-name')?.value||'').trim();
  if(!name){toast('Name is required',true);return;}
  const btn=document.getElementById('con-save-btn');
  btn.disabled=true; btn.textContent='Saving\u2026';
  // FIX 4: read Active checkbox; default to 1 for new contacts
  const activeEl=document.getElementById('cf-active');
  const payload={
    name, contact_type:document.getElementById('cf-type').value,
    abn:document.getElementById('cf-abn').value.trim(),
    contact_person:document.getElementById('cf-person').value.trim(),
    email:document.getElementById('cf-email').value.trim(),
    phone:document.getElementById('cf-phone').value.trim(),
    address:document.getElementById('cf-address').value.trim(),
    city:document.getElementById('cf-city').value.trim(),
    state:document.getElementById('cf-state').value.trim(),
    postcode:document.getElementById('cf-postcode').value.trim(),
    payment_terms:parseInt(document.getElementById('cf-terms').value||30),
    default_tax_code:document.getElementById('cf-tax').value,
    notes:document.getElementById('cf-notes').value.trim(),
    bsb:document.getElementById('cf-bsb').value.trim(),
    account_number:document.getElementById('cf-accnum').value.trim(),
    bank_account_name:document.getElementById('cf-accname').value.trim(),
    is_active:activeEl?( activeEl.checked?1:0):1,
  };
  try {
    let savedId=_conEditId;
    if(_conEditId) {
      const r=await fetch(`/api/contacts/${_conEditId}`,{method:'PUT',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
    } else {
      const r=await fetch('/api/contacts',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
      savedId=j.data?.id;
    }
    // Invalidate cached contact lists used by other modules
    _contacts=[];_editContacts=null;_billEditContacts=null;
    toast('Contact saved');
    _conAll=await apiFetch('/api/contacts')||[];
    if(savedId) { _conSelected=savedId; await conOpen(savedId); }
    else { detClose(); renderContactsPage(); }
  } catch(e){
    toast(e.message,true);
    btn.disabled=false; btn.textContent='Save';
  }
}

// FIX 5: Statement of Account — date-range modal → streams PDF from server
async function conStatement(id) {
  const today=isoToday();
  const n=new Date(); const firstOfMonth=`${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,'0')}-01`;
  const bd=document.createElement('div');
  bd.className='modal-bd';
  bd.style.display='flex';
  bd.innerHTML=`
    <div class="modal-box" style="width:min(440px,94vw)">
      <div class="modal-title">Statement of Account</div>
      <div class="modal-field">
        <label class="modal-lbl">Date From</label>
        <input class="modal-inp" type="date" id="stmt-from" value="${firstOfMonth}">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Date To</label>
        <input class="modal-inp" type="date" id="stmt-to" value="${today}">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Email To (optional)</label>
        <input class="modal-inp" type="email" id="stmt-email" placeholder="contact@example.com">
      </div>
      <div class="modal-acts">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-outline btn-sm" id="stmt-go-btn" onclick="_conStmtGenerate(${id})">📄 Download PDF</button>
        <button class="btn btn-primary btn-sm" id="stmt-eml-btn" onclick="_conStmtEmail(${id})">📧 Email</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
  try {
    const c=await apiFetch(`/api/contacts/${id}`);
    if(c?.email) document.getElementById('stmt-email').value=c.email;
  } catch(e){}
}

async function _conStmtGenerate(id) {
  const dateFrom=document.getElementById('stmt-from').value;
  const dateTo=document.getElementById('stmt-to').value;
  if(!dateFrom||!dateTo){toast('Both dates are required','err');return;}
  if(dateFrom>dateTo){toast('Date From must be before Date To','err');return;}
  const btn=document.getElementById('stmt-go-btn');
  btn.disabled=true; btn.textContent='Generating\u2026';
  try {
    const url=`/api/contacts/${id}/statement?date_from=${dateFrom}&date_to=${dateTo}`;
    const r=await fetch(url,{credentials:'include'});
    if(!r.ok){let msg='Failed';try{const j=await r.json();msg=j.error||msg;}catch(_){}throw new Error(msg);}
    const blob=await r.blob();
    const a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download=`statement_${id}_${dateFrom}_${dateTo}.pdf`;
    a.click();
    document.getElementById('stmt-go-btn')?.closest('.modal-bd')?.remove();
    toast('Statement downloaded');
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent='📄 Download PDF';
  }
}

async function _conStmtEmail(id) {
  const dateFrom=document.getElementById('stmt-from')?.value;
  const dateTo=document.getElementById('stmt-to')?.value;
  const toEmail=(document.getElementById('stmt-email')?.value||'').trim();
  if(!dateFrom||!dateTo){toast('Both dates are required','err');return;}
  if(dateFrom>dateTo){toast('Date From must be before Date To','err');return;}
  if(!toEmail){toast('Email address is required','err');return;}
  const btn=document.getElementById('stmt-eml-btn');
  btn.disabled=true; btn.textContent='Sending…';
  try {
    const r=await fetch(`/api/contacts/${id}/statement/email`,{method:'POST',credentials:'include',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({to:toEmail,date_from:dateFrom,date_to:dateTo})});
    const j=await r.json();
    if(!j.ok) throw new Error(j.error||'Send failed');
    btn.closest('.modal-bd')?.remove();
    toast('Statement emailed');
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent='📧 Email';
  }
}
