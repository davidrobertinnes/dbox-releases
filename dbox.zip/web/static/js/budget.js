// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ── Budget Module ─────────────────────────────────────────────────────────────
// Budget management: period CRUD, month-by-month line editor, Quick Wizard,
// CSV download/upload, and Actual vs Budget comparison report.

let _budgetPeriods    = [];
let _budgetPeriodId   = null;
let _budgetData       = null;   // {rows, period, date_from, date_to} for the report view
let _budgetView       = 'list'; // 'list' | 'editor' | 'report'
let _budgetReportMode = 'totals'; // 'totals' | 'monthly'
let _budgetPreset     = 'full';   // 'full' | 'month' | 'last_month' | 'ytd' | 'custom'
let _budgetDateFrom   = '';
let _budgetDateTo     = '';

const _MONTH_ABBR = ['','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
// Calendar month labels (1=Jan…12=Dec) — data is stored as calendar months
const FY_MONTHS = [7,8,9,10,11,12,1,2,3,4,5,6]; // display order: Jul first

// ── Page entry ────────────────────────────────────────────────────────────────
async function pageBudget() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading\u2026</div>';
  try {
    _budgetPeriods = await apiFetch('/api/reports/budget-periods') || [];
  } catch(e) {
    mod.innerHTML = `<div class="state-error">Failed to load budget: ${esc(e.message)}</div>`;
    return;
  }
  _budgetPeriodId = _budgetPeriods.length ? _budgetPeriods[0].id : null;
  _renderBudgetList();
}

// ── Period list (main view) ───────────────────────────────────────────────────
function _renderBudgetList() {
  _budgetView = 'list';
  const mod = document.getElementById('module-content');

  mod.innerHTML = `
  <div class="inv-toolbar">
    <span style="font-weight:600;font-size:14px">Budgets</span>
    <div style="margin-left:auto;display:flex;gap:6px">
      <button class="btn btn-purple btn-sm" onclick="_budgetWizard()">🧙 Quick Wizard</button>
      <button class="btn btn-primary btn-sm" onclick="_budgetNewPeriod()">+ New Budget</button>
    </div>
  </div>

  <div class="inv-list-panel">
    <div class="tbl-overflow-x">
      <table class="inv-list-table">
        <thead><tr>
          <th>Name</th>
          <th>FY Year</th>
          <th>Type</th>
          <th>Start</th>
          <th>End</th>
          <th style="width:190px"></th>
        </tr></thead>
        <tbody id="budget-period-tbody"></tbody>
      </table>
    </div>
  </div>
  <div class="mt-8">
    <span class="count-pill" id="budget-period-count"></span>
  </div>`;

  _renderBudgetPeriodRows();
}

function _renderBudgetPeriodRows() {
  const tbody = document.getElementById('budget-period-tbody');
  const pill  = document.getElementById('budget-period-count');
  if (!tbody) return;
  if (!_budgetPeriods.length) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--ink3)">
      No budgets yet. Click <strong>+ New Budget</strong> or use the <strong>🧙 Quick Wizard</strong>.
    </td></tr>`;
    if (pill) pill.textContent = '0 budgets';
    return;
  }
  tbody.innerHTML = _budgetPeriods.map(p => `
    <tr class="inv-row">
      <td><span class="inv-contact">${esc(p.name)}</span></td>
      <td><span class="inv-mono">${esc(p.fy_year)}</span></td>
      <td>${esc(p.period_type||'Annual')}</td>
      <td><span class="inv-mono">${fmtDate(p.start_date)}</span></td>
      <td><span class="inv-mono">${fmtDate(p.end_date)}</span></td>
      <td style="white-space:nowrap">
        <button class="btn btn-outline btn-sm" onclick="_budgetEditLines(${p.id})">✏ Edit / Import</button>
        <button class="btn btn-primary btn-sm" onclick="rptGoBudget(${p.id})">📊 Report</button>
        <button class="btn btn-outline btn-sm" onclick="_budgetDownloadTemplate(${p.id})">⬇ CSV</button>
        <button class="btn btn-danger btn-sm" onclick="_budgetDeletePeriod(${p.id},'${esc(p.name)}')">🗑</button>
      </td>
    </tr>`).join('');
  if (pill) pill.textContent = `${_budgetPeriods.length} budget${_budgetPeriods.length !== 1 ? 's' : ''}`;
}

// ── Period create / edit ──────────────────────────────────────────────────────
function _budgetNewPeriod() { _budgetPeriodForm(null); }

function _budgetPeriodForm(period) {
  const isEdit = !!period;
  const today = new Date();
  const fy = today.getMonth() >= 6 ? today.getFullYear() + 1 : today.getFullYear();
  const defName  = period ? period.name : `FY${fy} Budget`;
  const defFy    = period ? period.fy_year : fy;
  const defType  = period ? (period.period_type||'Annual') : 'Annual';
  const defStart = period ? (period.start_date||'') : `${fy-1}-07-01`;
  const defEnd   = period ? (period.end_date||'')   : `${fy}-06-30`;

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'budget-period-modal';
  bd.innerHTML = `
    <div class="modal-box" style="width:min(440px,96vw)">
      <div class="modal-hdr"><span>${isEdit ? 'Edit Budget Period' : 'New Budget Period'}</span></div>
      <div class="modal-body">
        <div class="form-grid form-grid-1">
          <div class="form-field">
            <label class="form-lbl">Name *</label>
            <input class="form-input" id="bp-name" value="${esc(defName)}">
          </div>
          <div class="form-field">
            <label class="form-lbl">FY Year *</label>
            <input class="form-input" id="bp-fy" type="number" value="${defFy}" min="2000" max="2100">
          </div>
          <div class="form-field">
            <label class="form-lbl">Type</label>
            <select class="form-input" id="bp-type">
              ${['Annual','Quarterly','Monthly'].map(t=>
                `<option${t===defType?' selected':''}>${t}</option>`).join('')}
            </select>
          </div>
          <div class="form-field">
            <label class="form-lbl">Start Date *</label>
            <input class="form-input" id="bp-start" type="date" value="${defStart}">
          </div>
          <div class="form-field">
            <label class="form-lbl">End Date *</label>
            <input class="form-input" id="bp-end" type="date" value="${defEnd}">
          </div>
        </div>
        <div id="bp-err" style="color:var(--red);font-size:12px;margin-top:8px"></div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="document.getElementById('budget-period-modal').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" id="bp-save-btn" onclick="_budgetSavePeriod(${period ? period.id : 'null'})">Save</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
  document.getElementById('bp-name').focus();
}

async function _budgetSavePeriod(pid) {
  const btn = document.getElementById('bp-save-btn');
  const errEl = document.getElementById('bp-err');
  const name  = document.getElementById('bp-name').value.trim();
  const fy    = parseInt(document.getElementById('bp-fy').value);
  const type  = document.getElementById('bp-type').value;
  const start = document.getElementById('bp-start').value;
  const end   = document.getElementById('bp-end').value;
  errEl.textContent = '';
  if (!name) { errEl.textContent = 'Name is required.'; return; }
  if (!fy)   { errEl.textContent = 'FY Year is required.'; return; }
  if (!start || !end) { errEl.textContent = 'Start and end dates are required.'; return; }
  btn.disabled = true; btn.textContent = 'Saving\u2026';
  try {
    const url    = pid ? `/api/budget/periods/${pid}` : '/api/budget/periods';
    const method = pid ? 'PUT' : 'POST';
    const r = await fetch(url, {
      method, credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({name, fy_year: fy, period_type: type, start_date: start, end_date: end})
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    document.getElementById('budget-period-modal').remove();
    _budgetPeriods = await apiFetch('/api/reports/budget-periods') || [];
    toast('Budget period saved');
    _renderBudgetPeriodRows();
  } catch(e) {
    errEl.textContent = e.message;
    btn.disabled = false; btn.textContent = 'Save';
  }
}

async function _budgetDeletePeriod(pid, name) {
  if (!await confirmDlg(`Delete budget "${name}" and all its lines? This cannot be undone.`)) return;
  try {
    const r = await fetch(`/api/budget/periods/${pid}`, {method:'DELETE', credentials:'include'});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Delete failed');
    toast('Budget deleted');
    _budgetPeriods = await apiFetch('/api/reports/budget-periods') || [];
    _renderBudgetPeriodRows();
  } catch(e) { toast(e.message, 'error'); }
}

// ── Budget lines editor ───────────────────────────────────────────────────────
async function _budgetEditLines(pid) {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading lines\u2026</div>';
  _budgetView = 'editor';
  try {
    const [periods, rawLines, allAccounts] = await Promise.all([
      apiFetch('/api/reports/budget-periods'),
      apiFetch(`/api/budget/periods/${pid}/lines`),
      apiFetch('/api/accounts')
    ]);
    const period = (periods || []).find(p => p.id === pid);
    const accounts = (allAccounts || [])
      .filter(a => ['Revenue','Income','Cost of Sales','Expense'].includes(a.account_type))
      .sort((a,b) => a.code.localeCompare(b.code));

    // Build month map: account_id -> month_num -> amount
    const lineMap = {};
    for (const l of rawLines) {
      // Normalise string month keys from JSON back to integers
      const norm = {};
      Object.entries(l.months || {}).forEach(([k,v]) => { norm[parseInt(k)] = v; });
      lineMap[l.account_id] = norm;
    }

    _renderLinesEditor(pid, period, accounts, lineMap);
  } catch(e) {
    mod.innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`;
  }
}

function _renderLinesEditor(pid, period, accounts, lineMap) {
  const mod = document.getElementById('module-content');
  const periodLabel = period ? `${period.name} (FY${period.fy_year})` : `Period #${pid}`;

  const groupOrder = ['Revenue','Income','Cost of Sales','Expense'];
  const groups = {};
  accounts.forEach(a => {
    const t = a.account_type;
    if (!groups[t]) groups[t] = [];
    groups[t].push(a);
  });
  const orderedGroups = [
    ...groupOrder.filter(g => groups[g]),
    ...Object.keys(groups).filter(g => !groupOrder.includes(g))
  ];

  let tableRows = '';
  orderedGroups.forEach(type => {
    tableRows += `<tr style="background:var(--row-alt)">
      <td colspan="15" style="font-weight:700;font-size:10px;text-transform:uppercase;
        letter-spacing:.08em;color:var(--ink3);padding:7px 10px">${esc(type)}</td>
    </tr>`;
    groups[type].forEach(acc => {
      const months = lineMap[acc.id] || {};
      const monthCells = FY_MONTHS.map(m => {
        const v = parseFloat(months[m] || 0);
        return `<td style="padding:2px 1px"><input class="bline-inp" data-aid="${acc.id}" data-m="${m}"
          value="${v > 0 ? v.toFixed(0) : ''}" placeholder="—"
          oninput="_budgetLineUpdate(this)"></td>`;
      }).join('');
      tableRows += `<tr class="inv-row" id="brow-${acc.id}">
        <td><span class="inv-mono" style="font-size:10px">${esc(acc.code)}</span></td>
        <td style="min-width:160px">${esc(acc.name)}</td>
        ${monthCells}
        <td class="inv-amt" id="bannual-${acc.id}" style="color:var(--ink3);font-size:11px">—</td>
      </tr>`;
    });
  });

  mod.innerHTML = `
  <div class="inv-toolbar" style="flex-wrap:wrap;gap:8px">
    <button class="btn btn-outline btn-sm" onclick="_renderBudgetList()">← Back</button>
    <span style="font-weight:600">${esc(periodLabel)}</span>
    <div style="margin-left:auto;display:flex;gap:6px;flex-wrap:wrap">
      <label class="btn btn-purple btn-sm" style="cursor:pointer">
        ⬆ Upload CSV
        <input type="file" accept=".csv" style="display:none" onchange="_budgetUploadCsv(event,${pid})">
      </label>
      <button class="btn btn-outline btn-sm" onclick="_budgetDownloadTemplate(${pid})">⬇ Template</button>
      <button class="btn btn-primary btn-sm" id="blines-save-btn" onclick="_budgetSaveLines(${pid})">Save All</button>
    </div>
  </div>

  <div style="font-size:11px;color:var(--ink3);margin-bottom:8px;padding:0 2px">
    Enter monthly amounts. Leave blank for $0. Annual total updates as you type.
  </div>

  <div class="inv-list-panel" style="overflow:auto">
    <table class="inv-list-table" style="min-width:1240px;font-size:12px">
      <thead><tr>
        <th style="width:58px">Code</th>
        <th>Account</th>
        ${FY_MONTHS.map(m => `<th style="text-align:right;min-width:68px">${_MONTH_ABBR[m]}</th>`).join('')}
        <th style="text-align:right;min-width:80px">Annual</th>
      </tr></thead>
      <tbody>${tableRows}</tbody>
    </table>
  </div>
  <div class="mt-8" id="blines-total-bar" style="font-size:12px;color:var(--ink3)"></div>`;

  // Seed CSS for bline inputs — lightweight inline style
  if (!document.getElementById('bline-style')) {
    const s = document.createElement('style');
    s.id = 'bline-style';
    s.textContent = `.bline-inp{width:62px;text-align:right;border:1px solid var(--border);
      border-radius:4px;padding:3px 5px;font-size:11px;font-family:'DM Mono',monospace;
      background:var(--entry-bg);color:var(--ink);outline:none}
      .bline-inp:focus{border-color:var(--accent)}
      .bline-inp::placeholder{color:var(--ink3)}`;
    document.head.appendChild(s);
  }

  accounts.forEach(acc => _budgetRecalcAnnual(acc.id));
  _budgetUpdateTotalBar();
}

function _budgetLineUpdate(inp) {
  _budgetRecalcAnnual(inp.dataset.aid);
  _budgetUpdateTotalBar();
}

function _budgetRecalcAnnual(aid) {
  const inputs = document.querySelectorAll(`.bline-inp[data-aid="${aid}"]`);
  let total = 0;
  inputs.forEach(i => { const v = parseFloat(i.value); if (!isNaN(v)) total += v; });
  const el = document.getElementById(`bannual-${aid}`);
  if (el) el.textContent = total > 0 ? fmt(total) : '—';
}

function _budgetUpdateTotalBar() {
  const bar = document.getElementById('blines-total-bar');
  if (!bar) return;
  let grand = 0;
  document.querySelectorAll('.bline-inp').forEach(i => { grand += parseFloat(i.value) || 0; });
  bar.textContent = grand > 0 ? `Total budgeted: ${fmt(grand)}` : '';
}

async function _budgetSaveLines(pid) {
  const btn = document.getElementById('blines-save-btn');
  btn.disabled = true; btn.textContent = 'Saving\u2026';
  const lines = [];
  document.querySelectorAll('.bline-inp').forEach(inp => {
    lines.push({
      account_id: parseInt(inp.dataset.aid),
      month: parseInt(inp.dataset.m),
      amount: parseFloat(inp.value) || 0
    });
  });
  try {
    const r = await fetch(`/api/budget/periods/${pid}/lines`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({lines})
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    toast('Budget lines saved');
  } catch(e) { toast(e.message, 'error'); }
  btn.disabled = false; btn.textContent = 'Save All';
}

// ── CSV download / upload ─────────────────────────────────────────────────────
function _budgetDownloadTemplate(pid) {
  window.location.href = `/api/budget/periods/${pid}/template`;
}

async function _budgetUploadCsv(event, pid) {
  const file = event.target.files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append('file', file);
  try {
    const r = await fetch(`/api/budget/periods/${pid}/import`, {
      method: 'POST', credentials: 'include', body: fd
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Import failed');
    toast(`Imported ${j.data?.imported || 0} account lines — reloading\u2026`);
    await _budgetEditLines(pid);
  } catch(e) { toast(e.message, 'err'); }
  event.target.value = '';
}

// ── Quick Wizard ──────────────────────────────────────────────────────────────
let _wizStep = 0;
let _wizData = {};
let _wizAmounts = {};
let _wizAccounts = [];
let _wizUplift = 0;

async function _budgetWizard() {
  _wizStep = 0;
  _wizData = {};
  _wizAmounts = {};
  _wizAccounts = [];
  _wizUplift = 0;

  try {
    _wizAccounts = (await apiFetch('/api/accounts') || []).filter(a =>
      ['Revenue','Income','Cost of Sales','Expense'].includes(a.account_type));
  } catch(e) { toast('Could not load accounts', 'error'); return; }

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'wizard-modal';
  bd.innerHTML = `
    <div class="modal-box" style="width:min(600px,96vw);max-height:90vh;display:flex;flex-direction:column">
      <div class="modal-hdr"><span id="wiz-title">Quick Budget Wizard — Step 1 of 3</span></div>
      <div class="modal-body" id="wiz-body" style="overflow-y:auto;flex:1"></div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" id="wiz-back-btn" onclick="_wizBack()" style="display:none">← Back</button>
        <button class="btn btn-outline btn-sm" onclick="document.getElementById('wizard-modal').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" id="wiz-next-btn" onclick="_wizNext()">Next →</button>
        <button class="btn btn-success btn-sm" id="wiz-finish-btn" onclick="_wizFinish()" style="display:none">✓ Create Budget</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
  _wizRenderStep(0);
}

function _wizRenderStep(step) {
  _wizStep = step;
  document.getElementById('wiz-title').textContent = `Quick Budget Wizard — Step ${step+1} of 3`;
  document.getElementById('wiz-back-btn').style.display   = step > 0 ? '' : 'none';
  document.getElementById('wiz-next-btn').style.display   = step < 2 ? '' : 'none';
  document.getElementById('wiz-finish-btn').style.display = step === 2 ? '' : 'none';
  const body = document.getElementById('wiz-body');
  if (step === 0) _wizStep1(body);
  if (step === 1) _wizStep2(body);
  if (step === 2) _wizStep3(body);
}

function _wizStep1(body) {
  const today = new Date();
  const fy = today.getMonth() >= 6 ? today.getFullYear() + 1 : today.getFullYear();
  const d = _wizData;
  body.innerHTML = `
    <div style="font-weight:600;margin-bottom:4px">Name your budget and set the period.</div>
    <div style="font-size:12px;color:var(--ink3);margin-bottom:16px">
      Annual amounts you enter will be spread evenly across 12 months.
      Fine-tune month by month afterwards in the Lines Editor.
    </div>
    <div class="form-grid form-grid-1">
      <div class="form-field">
        <label class="form-lbl">Budget Name *</label>
        <input class="form-input" id="wiz-name" value="${esc(d.name || `FY${fy} Budget`)}">
      </div>
      <div class="form-field">
        <label class="form-lbl">Financial Year *</label>
        <input class="form-input" id="wiz-fy" type="number" value="${d.fy_year || fy}">
      </div>
      <div class="form-field">
        <label class="form-lbl">Start Date *</label>
        <input class="form-input" id="wiz-start" type="date" value="${d.start_date || `${fy-1}-07-01`}">
      </div>
      <div class="form-field">
        <label class="form-lbl">End Date *</label>
        <input class="form-input" id="wiz-end" type="date" value="${d.end_date || `${fy}-06-30`}">
      </div>
    </div>
    <div style="font-size:11px;color:var(--ink3);margin-top:8px">
      Tip: Australian FY — e.g. FY2026 = 2025-07-01 to 2026-06-30
    </div>`;
}

function _wizValidateStep1() {
  const name  = (document.getElementById('wiz-name')?.value || '').trim();
  const fy    = parseInt(document.getElementById('wiz-fy')?.value);
  const start = document.getElementById('wiz-start')?.value;
  const end   = document.getElementById('wiz-end')?.value;
  if (!name)  { toast('Budget name is required', 'error'); return false; }
  if (!fy)    { toast('Financial year is required', 'error'); return false; }
  if (!start) { toast('Start date is required', 'error'); return false; }
  if (!end)   { toast('End date is required', 'error'); return false; }
  _wizData = {name, fy_year: fy, start_date: start, end_date: end};
  return true;
}

function _wizPriorYearDates() {
  const shiftYear = iso => iso.replace(/^(\d{4})/, y => String(parseInt(y) - 1));
  return { from: shiftYear(_wizData.start_date), to: shiftYear(_wizData.end_date) };
}

function _wizStep2(body) {
  const incAccs = _wizAccounts.filter(a => ['Revenue','Income'].includes(a.account_type));
  const expAccs = _wizAccounts.filter(a => ['Cost of Sales','Expense'].includes(a.account_type));
  const {from, to} = _wizPriorYearDates();

  function section(accs, colorVar, label) {
    if (!accs.length) return `<div style="color:var(--ink3);font-size:12px;padding:8px 10px">No ${label} accounts found.</div>`;
    return `<div style="background:${colorVar};color:#fff;font-weight:700;font-size:10px;
      text-transform:uppercase;letter-spacing:.05em;padding:6px 10px">${label}</div>` +
      accs.map(a => `
        <div style="display:flex;align-items:center;gap:8px;padding:5px 10px;
          background:var(--surface);border-bottom:1px solid var(--border)">
          <span style="font-size:10px;color:var(--ink3);min-width:48px;
            font-family:'DM Mono',monospace">${esc(a.code)}</span>
          <span style="flex:1;font-size:12px">${esc(a.name)}</span>
          <input class="form-input wiz-amt" data-aid="${a.id}"
            style="width:120px;text-align:right"
            value="${_wizAmounts[a.id]||''}" placeholder="Annual $"
            oninput="_wizUpdateTotals()">
        </div>`).join('');
  }

  body.innerHTML = `
    <div style="background:var(--row-alt);border:1px solid var(--border);border-radius:6px;
      padding:10px 14px;margin-bottom:12px;display:flex;align-items:center;gap:10px;flex-wrap:wrap">
      <span style="font-size:12px;font-weight:600">Load prior year actuals</span>
      <span style="font-size:11px;color:var(--ink3)">${fmtDate(from)} – ${fmtDate(to)}</span>
      <span style="margin-left:auto;display:flex;align-items:center;gap:6px">
        <span style="font-size:12px;color:var(--ink2)">Vary by</span>
        <input id="wiz-uplift" type="number" class="form-input" style="width:64px;text-align:right"
          value="${_wizUplift || ''}" placeholder="0" step="any">
        <span style="font-size:12px;color:var(--ink2)">%</span>
        <button class="btn btn-sm btn-primary" onclick="_wizLoadActuals()">Load Actuals</button>
      </span>
    </div>
    <div style="font-size:12px;color:var(--ink3);padding-bottom:10px">
      Enter expected <strong>annual totals</strong> for each account. Leave blank to exclude.
    </div>
    <div style="background:var(--row-alt);border-radius:6px;padding:8px 12px;
      font-size:12px;margin-bottom:12px" id="wiz-totals-bar">
      Revenue: $0 &nbsp;·&nbsp; Expenses: $0 &nbsp;·&nbsp; Net: $0
    </div>
    ${section(incAccs, 'var(--green)', '💰 Revenue / Income')}
    ${section(expAccs, 'var(--amber)', '💸 Cost of Sales / Expenses')}`;
}

async function _wizLoadActuals() {
  const upliftInput = document.getElementById('wiz-uplift');
  _wizUplift = parseFloat(upliftInput?.value || '0') || 0;
  const {from, to} = _wizPriorYearDates();
  let rows;
  try {
    rows = await apiFetch(`/api/budget/prior-year-actuals?from=${from}&to=${to}`);
  } catch(e) {
    toast('Failed to load actuals: ' + e.message, 'err');
    return;
  }
  if (!rows || !rows.length) {
    toast('No actuals found for ' + fmtDate(from) + ' – ' + fmtDate(to), 'err');
    return;
  }
  const factor = 1 + _wizUplift / 100;
  let loaded = 0;
  rows.forEach(r => {
    if (_wizAccounts.find(a => a.id === r.id)) {
      _wizAmounts[r.id] = String(Math.round(r.annual * factor * 100) / 100);
      loaded++;
    }
  });
  const body = document.getElementById('wiz-body');
  _wizStep2(body);
  _wizUpdateTotals();
  toast(`Loaded ${loaded} account${loaded !== 1 ? 's' : ''} from prior year actuals` +
    (_wizUplift ? ` (${_wizUplift > 0 ? '+' : ''}${_wizUplift}%)` : ''));
}

function _wizUpdateTotals() {
  let inc = 0, exp = 0;
  document.querySelectorAll('.wiz-amt').forEach(inp => {
    _wizAmounts[inp.dataset.aid] = inp.value;
    const v = parseFloat(inp.value) || 0;
    const isInc = _wizAccounts.find(a =>
      String(a.id) === inp.dataset.aid && ['Revenue','Income'].includes(a.account_type));
    if (isInc) inc += v; else exp += v;
  });
  const bar = document.getElementById('wiz-totals-bar');
  if (bar) {
    const net = inc - exp;
    bar.innerHTML = `Revenue: <strong>${fmt(inc)}</strong> &nbsp;·&nbsp; ` +
      `Expenses: <strong>${fmt(exp)}</strong> &nbsp;·&nbsp; ` +
      `Net: <strong style="color:${net>=0?'var(--green)':'var(--red)'}">${fmt(net)}</strong>`;
  }
}

function _wizStep3(body) {
  document.querySelectorAll('.wiz-amt').forEach(inp => { _wizAmounts[inp.dataset.aid] = inp.value; });

  const incEntries = _wizAccounts
    .filter(a => ['Revenue','Income'].includes(a.account_type) && parseFloat(_wizAmounts[a.id]) > 0)
    .map(a => ({acc: a, annual: parseFloat(_wizAmounts[a.id])}));
  const expEntries = _wizAccounts
    .filter(a => ['Cost of Sales','Expense'].includes(a.account_type) && parseFloat(_wizAmounts[a.id]) > 0)
    .map(a => ({acc: a, annual: parseFloat(_wizAmounts[a.id])}));
  const totalInc = incEntries.reduce((s,e) => s+e.annual, 0);
  const totalExp = expEntries.reduce((s,e) => s+e.annual, 0);
  const net = totalInc - totalExp;

  function rows(entries) {
    return entries.map(e => `
      <div style="display:flex;padding:4px 8px">
        <span style="flex:1;font-size:12px">${esc(e.acc.name)}</span>
        <span style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3)">
          ${fmt(e.annual)}/yr &nbsp;(${fmt(e.annual/12)}/mo)
        </span>
      </div>`).join('');
  }

  body.innerHTML = `
    <div style="font-weight:600;margin-bottom:10px">
      ${esc(_wizData.name)} &nbsp;·&nbsp;
      <span style="color:var(--ink3);font-weight:400;font-size:12px">
        ${fmtDate(_wizData.start_date)} – ${fmtDate(_wizData.end_date)}
      </span>
    </div>
    ${incEntries.length ? `
      <div style="background:var(--green);color:#fff;font-size:10px;font-weight:700;
        text-transform:uppercase;padding:5px 8px">Revenue</div>
      ${rows(incEntries)}` : ''}
    ${expEntries.length ? `
      <div style="background:var(--amber);color:#fff;font-size:10px;font-weight:700;
        text-transform:uppercase;padding:5px 8px;margin-top:8px">Expenses</div>
      ${rows(expEntries)}` : ''}
    <div style="border-top:2px solid var(--border);margin-top:12px;padding-top:8px">
      ${[['Total Revenue', totalInc, false],['Total Expenses', totalExp, false],
         ['Net Profit / (Loss)', net, true]].map(([l,v,bold]) => `
        <div style="display:flex;padding:3px 8px">
          <span style="flex:1;font-weight:${bold?700:400};font-size:12px">${l}</span>
          <span style="font-family:'DM Mono',monospace;font-weight:${bold?700:400};
            font-size:12px;color:${bold?(net>=0?'var(--green)':'var(--red)'):'inherit'}">${fmt(v)}</span>
        </div>`).join('')}
    </div>
    ${!incEntries.length && !expEntries.length ? `
      <div style="color:var(--ink3);font-size:12px;padding:8px">
        No amounts entered — go back to Step 2.</div>` : ''}
    <div style="font-size:11px;color:var(--ink3);margin-top:10px">
      Annual amounts will be split evenly across the period months.
    </div>`;
}

function _wizBack() { _wizRenderStep(_wizStep - 1); }
function _wizNext() {
  if (_wizStep === 0 && !_wizValidateStep1()) return;
  if (_wizStep === 1) {
    document.querySelectorAll('.wiz-amt').forEach(inp => { _wizAmounts[inp.dataset.aid] = inp.value; });
  }
  _wizRenderStep(_wizStep + 1);
}

async function _wizFinish() {
  const entries = _wizAccounts
    .filter(a => parseFloat(_wizAmounts[a.id]) > 0)
    .map(a => ({acc: a, annual: parseFloat(_wizAmounts[a.id])}));

  if (!entries.length) { toast('Enter at least one amount', 'error'); return; }

  const finBtn = document.getElementById('wiz-finish-btn');
  finBtn.disabled = true; finBtn.textContent = 'Creating\u2026';

  try {
    // 1 — create period
    const pr = await fetch('/api/budget/periods', {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        name: _wizData.name, fy_year: _wizData.fy_year,
        period_type: 'Annual',
        start_date: _wizData.start_date, end_date: _wizData.end_date
      })
    });
    const pj = await pr.json();
    if (!pj.ok) throw new Error(pj.error || 'Period create failed');
    const newPid = pj.data.id;

    // 2 — calculate months in period
    const startD = new Date(_wizData.start_date);
    const endD   = new Date(_wizData.end_date);
    const months = [];
    let cur = new Date(startD.getFullYear(), startD.getMonth(), 1);
    while (cur <= endD && months.length < 12) {
      months.push(cur.getMonth() + 1);
      cur = new Date(cur.getFullYear(), cur.getMonth() + 1, 1);
    }
    const nMonths = months.length || 12;

    // 3 — build lines
    const lines = [];
    entries.forEach(({acc, annual}) => {
      const monthly = Math.round((annual / nMonths) * 100) / 100;
      months.forEach(m => lines.push({account_id: acc.id, month: m, amount: monthly}));
    });

    // 4 — save lines
    const lr = await fetch(`/api/budget/periods/${newPid}/lines`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({lines})
    });
    const lj = await lr.json();
    if (!lj.ok) throw new Error(lj.error || 'Lines save failed');

    document.getElementById('wizard-modal').remove();
    toast(`Budget "${_wizData.name}" created with ${entries.length} accounts`);
    _budgetPeriods = await apiFetch('/api/reports/budget-periods') || [];
    _renderBudgetList();
  } catch(e) {
    toast(e.message, 'error');
    finBtn.disabled = false; finBtn.textContent = '✓ Create Budget';
  }
}

// ── Report view ───────────────────────────────────────────────────────────────
async function _budgetReport(pid) {
  _budgetView     = 'report';
  _budgetPeriodId = pid;
  _budgetPreset   = 'full';
  _budgetDateFrom = '';
  _budgetDateTo   = '';
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading report\u2026</div>';
  try {
    _budgetData = await apiFetch(`/api/reports/budget-vs-actual?period_id=${pid}`);
  } catch(e) {
    mod.innerHTML = `<div class="state-error">Failed: ${esc(e.message)}</div>`;
    return;
  }
  _renderReportPage();
}

async function _budgetFetchActuals() {
  const wrap = document.getElementById('budget-report-wrap');
  if (wrap) wrap.innerHTML = '<div class="state-loading" style="padding:32px">Loading\u2026</div>';
  let url = `/api/reports/budget-vs-actual?period_id=${_budgetPeriodId}`;
  if (_budgetDateFrom) url += `&from=${_budgetDateFrom}`;
  if (_budgetDateTo)   url += `&to=${_budgetDateTo}`;
  try {
    _budgetData = await apiFetch(url);
    _renderReportTable();
    _updateBudgetDateBar();
  } catch(e) {
    if (wrap) wrap.innerHTML = `<div class="state-error">Failed: ${esc(e.message)}</div>`;
  }
}

function _renderReportPage() {
  const mod = document.getElementById('module-content');
  const period = _budgetData?.period;

  const periodOpts = _budgetPeriods.map(p =>
    `<option value="${p.id}"${p.id===_budgetPeriodId?' selected':''}>${esc(p.name)} (FY${p.fy_year})</option>`
  ).join('');

  const presets = ['full','month','last_month','ytd','custom'];
  const presetLabels = {full:'Full Period', month:'This Month', last_month:'Last Month', ytd:'YTD', custom:'Custom'};

  mod.innerHTML = `
  <div class="inv-toolbar" style="align-items:center;flex-wrap:wrap;gap:8px">
    <button class="btn btn-outline btn-sm" onclick="_renderBudgetList()">← Back</button>
    <div style="display:flex;align-items:center;gap:8px">
      <label style="font-size:12px;color:var(--ink3);white-space:nowrap">Period</label>
      ${_budgetPeriods.length > 1
        ? `<select class="edt-sel" style="width:220px" onchange="_budgetReport(parseInt(this.value))">${periodOpts}</select>`
        : `<span style="font-weight:600">${period ? `${esc(period.name)} (FY${period.fy_year})` : '—'}</span>`}
    </div>
    <div style="margin-left:auto;display:flex;gap:6px">
      <button class="bv-btn filter-btn${_budgetReportMode==='totals'?' active':''}"
        data-view="totals" onclick="_setReportMode('totals')">Annual Totals</button>
      <button class="bv-btn filter-btn${_budgetReportMode==='monthly'?' active':''}"
        data-view="monthly" onclick="_setReportMode('monthly')">Monthly</button>
    </div>
  </div>
  <div style="display:flex;align-items:center;gap:6px;padding:6px 0 4px;flex-wrap:wrap">
    <span style="font-size:12px;color:var(--ink3);white-space:nowrap">Actuals:</span>
    ${presets.map(p => `<button class="bv-preset filter-btn${_budgetPreset===p?' active':''}"
      data-preset="${p}" onclick="_setBudgetPreset('${p}')">${presetLabels[p]}</button>`).join('')}
    <span id="bv-custom-inputs" style="display:${_budgetPreset==='custom'?'flex':'none'};align-items:center;gap:4px">
      <input type="date" id="bv-from" class="set-inp" style="max-width:140px" value="${_budgetDateFrom}">
      <span style="color:var(--ink3)">–</span>
      <input type="date" id="bv-to"   class="set-inp" style="max-width:140px" value="${_budgetDateTo}">
      <button class="btn btn-sm btn-primary" onclick="_applyCustomBudgetDates()">Apply</button>
    </span>
    <span id="bv-date-label" style="font-size:11px;color:var(--ink3)"></span>
  </div>
  <div id="budget-report-wrap"></div>`;

  _renderReportTable();
  _updateBudgetDateBar();
}

function _setReportMode(v) {
  _budgetReportMode = v;
  document.querySelectorAll('.bv-btn').forEach(b =>
    b.classList.toggle('active', b.dataset.view === v));
  _renderReportTable();
}

function _budgetPresetDates(preset) {
  const period = _budgetData?.period;
  const today  = new Date();
  const iso = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const y = today.getFullYear(), m = today.getMonth();
  if (preset === 'full')       return {from: period?.start_date || '', to: period?.end_date || ''};
  if (preset === 'month')      return {from: iso(new Date(y, m, 1)),       to: iso(today)};
  if (preset === 'last_month') return {from: iso(new Date(y, m - 1, 1)),   to: iso(new Date(y, m, 0))};
  if (preset === 'ytd')        return {from: period?.start_date || '',      to: iso(today)};
  return null; // custom
}

function _setBudgetPreset(preset) {
  _budgetPreset = preset;
  document.querySelectorAll('.bv-preset').forEach(b =>
    b.classList.toggle('active', b.dataset.preset === preset));
  const customEl = document.getElementById('bv-custom-inputs');
  if (customEl) customEl.style.display = preset === 'custom' ? 'flex' : 'none';
  if (preset === 'custom') return; // wait for Apply
  const dates = _budgetPresetDates(preset);
  _budgetDateFrom = dates.from;
  _budgetDateTo   = dates.to;
  _budgetFetchActuals();
}

function _applyCustomBudgetDates() {
  const from = (document.getElementById('bv-from') || {}).value || '';
  const to   = (document.getElementById('bv-to')   || {}).value || '';
  if (!from || !to) { toast('Select both a start and end date', 'err'); return; }
  if (from > to)    { toast('Start date must be before end date', 'err'); return; }
  _budgetDateFrom = from;
  _budgetDateTo   = to;
  _budgetFetchActuals();
}

function _updateBudgetDateBar() {
  const lbl = document.getElementById('bv-date-label');
  if (!lbl) return;
  if (_budgetPreset === 'full' || (!_budgetDateFrom && !_budgetDateTo)) {
    lbl.textContent = '';
    return;
  }
  const fmt = s => s ? fmtDate(s) : '?';
  lbl.textContent = `(${fmt(_budgetDateFrom)} – ${fmt(_budgetDateTo)})`;
}

function _renderReportTable() {
  const wrap = document.getElementById('budget-report-wrap');
  if (!wrap) return;

  // Normalise: JSON gives string keys on integer-keyed dicts
  const rows = (_budgetData?.rows || []).map(r => ({
    ...r,
    months: Object.fromEntries(
      Object.entries(r.months || {}).map(([k,v]) => [parseInt(k), v])
    )
  }));
  const period = _budgetData?.period || null;

  if (!rows.length) {
    wrap.innerHTML = `
    <div style="text-align:center;padding:48px 0;color:var(--ink3)">
      <div style="font-size:32px;margin-bottom:12px">🎯</div>
      <div style="font-weight:600;margin-bottom:6px">No budget data</div>
      <div style="font-size:12px">Set up budget lines for this period to see the comparison.</div>
      ${period ? `<div style="margin-top:16px">
        <button class="btn btn-primary btn-sm" onclick="_budgetEditLines(${period.id})">✏ Edit Lines</button>
      </div>` : ''}
    </div>`;
    return;
  }

  const groups = {};
  rows.forEach(r => {
    const t = r.account_type;
    if (!groups[t]) groups[t] = [];
    groups[t].push(r);
  });
  const groupOrder = ['Revenue','Income','Cost of Sales','Expense'];
  const orderedGroups = [
    ...groupOrder.filter(g => groups[g]),
    ...Object.keys(groups).filter(g => !groupOrder.includes(g))
  ];

  wrap.innerHTML = _budgetReportMode === 'monthly'
    ? _renderMonthlyTable(orderedGroups, groups)
    : _renderTotalsTable(orderedGroups, groups);
}

// ── Totals view ───────────────────────────────────────────────────────────────
function _renderTotalsTable(orderedGroups, groups) {
  const isRevenue = t => ['Revenue','Income'].includes(t);

  let html = `<div class="inv-list-panel" style="overflow-x:auto">
  <table class="inv-list-table">
    <thead><tr>
      <th style="width:70px">Code</th>
      <th>Account</th>
      <th style="text-align:right">Budget</th>
      <th style="text-align:right">Actual</th>
      <th style="text-align:right">Variance</th>
      <th style="text-align:right;width:70px">Var %</th>
      <th style="width:90px">Progress</th>
    </tr></thead>
    <tbody>`;

  let totalRevBud = 0, totalRevAct = 0;
  let totalExpBud = 0, totalExpAct = 0;

  orderedGroups.forEach(type => {
    const typeRows = groups[type];
    let typeBud = 0, typeAct = 0;

    html += `<tr style="background:var(--row-alt)">
      <td colspan="7" style="font-weight:700;font-size:10px;text-transform:uppercase;
        letter-spacing:.08em;color:var(--ink3);padding:7px 10px">${esc(type)}</td>
    </tr>`;

    typeRows.forEach(r => {
      const bud = r.total_budget || 0;
      const act = r.total_actual || 0;
      const vr  = r.total_variance || 0;
      const pct = r.total_variance_pct || 0;
      typeBud += bud; typeAct += act;
      const fav = isRevenue(type) ? vr >= 0 : vr <= 0;
      const barPct = bud !== 0 ? Math.min(100, Math.round(Math.abs(act/bud)*100)) : 0;

      html += `<tr class="inv-row">
        <td><span class="inv-mono" style="font-size:10px">${esc(r.code)}</span></td>
        <td>${esc(r.name)}</td>
        <td class="inv-amt">${fmt(bud)}</td>
        <td class="inv-amt">${fmt(act)}</td>
        <td class="inv-amt" style="color:${fav?'var(--green)':'var(--red)'}">
          ${vr >= 0 ? '+' : ''}${fmt(vr)}</td>
        <td style="text-align:right;font-size:11px;color:${fav?'var(--green)':'var(--red)'}">
          ${pct >= 0?'+':''}${pct.toFixed(1)}%</td>
        <td>
          <div style="height:5px;background:var(--border);border-radius:3px;overflow:hidden">
            <div style="height:100%;width:${barPct}%;background:${
              barPct>=100?(isRevenue(type)?'var(--green)':'var(--red)')
              :(barPct>=75?'var(--amber)':'var(--accent)')};border-radius:3px"></div>
          </div>
          <div style="font-size:10px;color:var(--ink3);margin-top:1px;
            font-family:'DM Mono',monospace">${barPct}%</div>
        </td>
      </tr>`;
    });

    const typeVar = typeAct - typeBud;
    const typeFav = isRevenue(type) ? typeVar >= 0 : typeVar <= 0;
    html += `<tr style="font-weight:700;border-top:1.5px solid var(--border2)">
      <td></td>
      <td style="color:var(--ink2)">Total ${esc(type)}</td>
      <td class="inv-amt">${fmt(typeBud)}</td>
      <td class="inv-amt">${fmt(typeAct)}</td>
      <td class="inv-amt" style="color:${typeFav?'var(--green)':'var(--red)'}">
        ${typeVar>=0?'+':''}${fmt(typeVar)}</td>
      <td colspan="2"></td>
    </tr>
    <tr><td colspan="7" style="height:6px"></td></tr>`;

    if (isRevenue(type)) { totalRevBud += typeBud; totalRevAct += typeAct; }
    else                 { totalExpBud += typeBud; totalExpAct += typeAct; }
  });

  const npBud = totalRevBud - totalExpBud;
  const npAct = totalRevAct - totalExpAct;
  const npVar = npAct - npBud;
  const npPct = npBud !== 0 ? (npVar / Math.abs(npBud)) * 100 : 0;
  const npFav = npAct >= npBud;
  html += `<tr style="font-weight:700;font-size:13px;border-top:2.5px solid var(--border2);
      background:var(--row-alt)">
    <td></td>
    <td>Net Profit</td>
    <td class="inv-amt">${fmt(npBud)}</td>
    <td class="inv-amt">${fmt(npAct)}</td>
    <td class="inv-amt" style="color:${npFav?'var(--green)':'var(--red)'}">
      ${npVar>=0?'+':''}${fmt(npVar)}</td>
    <td style="text-align:right;font-size:11px;color:${npFav?'var(--green)':'var(--red)'}">
      ${npPct>=0?'+':''}${npPct.toFixed(1)}%</td>
    <td></td>
  </tr>`;

  html += `</tbody></table></div>`;
  return html;
}

// ── Monthly view ──────────────────────────────────────────────────────────────
function _renderMonthlyTable(orderedGroups, groups) {
  const months = FY_MONTHS; // Jul … Jun display order
  const isRevenue = t => ['Revenue','Income'].includes(t);

  let html = `<div class="inv-list-panel" style="overflow-x:auto">
  <table class="inv-list-table" style="min-width:1100px;font-size:11px">
    <thead>
      <tr>
        <th style="min-width:180px">Account</th>
        ${months.map(m => `<th style="text-align:right;min-width:78px">${_MONTH_ABBR[m]}</th>`).join('')}
        <th style="text-align:right;min-width:88px">Total</th>
      </tr>
    </thead>
    <tbody>`;

  const mRevBud = {}, mRevAct = {}, mExpBud = {}, mExpAct = {};
  months.forEach(m => { mRevBud[m]=0; mRevAct[m]=0; mExpBud[m]=0; mExpAct[m]=0; });
  let totalRevBud = 0, totalRevAct = 0;
  let totalExpBud = 0, totalExpAct = 0;

  orderedGroups.forEach(type => {
    const typeRows = groups[type];
    html += `<tr style="background:var(--row-alt)">
      <td colspan="${months.length+2}" style="font-weight:700;font-size:10px;
        text-transform:uppercase;letter-spacing:.08em;color:var(--ink3);
        padding:7px 10px">${esc(type)}</td>
    </tr>`;

    typeRows.forEach(r => {
      // Budget row
      html += `<tr class="inv-row inv-row-pair" style="border-bottom:none">
        <td rowspan="2" style="vertical-align:top;border-bottom:none">
          <span class="inv-mono" style="font-size:10px">${esc(r.code)}</span>
          <div style="font-size:11px">${esc(r.name)}</div>
        </td>
        ${months.map(m => {
          const bud = r.months?.[m]?.budget || 0;
          return `<td style="text-align:right;color:var(--ink3)">${bud ? fmt(bud) : '—'}</td>`;
        }).join('')}
        <td style="text-align:right;color:var(--ink3);font-weight:600">${fmt(r.total_budget)}</td>
      </tr>`;
      // Actual row
      html += `<tr class="inv-row inv-row-pair">
        ${months.map(m => {
          const bud = r.months?.[m]?.budget || 0;
          const act = r.months?.[m]?.actual || 0;
          const vr  = act - bud;
          const fav = isRevenue(type) ? vr >= 0 : vr <= 0;
          return `<td style="text-align:right;font-weight:${act?'600':'400'};
            color:${act?(fav?'var(--green)':'var(--red)'):'var(--ink3)'}">
            ${act ? fmt(act) : '—'}</td>`;
        }).join('')}
        <td style="text-align:right;font-weight:700;
          color:${isRevenue(type)
            ?(r.total_actual>=r.total_budget?'var(--green)':'var(--red)')
            :(r.total_actual<=r.total_budget?'var(--green)':'var(--red)')
          }">${fmt(r.total_actual)}</td>
      </tr>`;
    });

    const typeBud = typeRows.reduce((s,r) => s+(r.total_budget||0), 0);
    const typeAct = typeRows.reduce((s,r) => s+(r.total_actual||0), 0);
    html += `<tr style="font-weight:700;border-top:2px solid var(--border)">
      <td>Total ${esc(type)}</td>
      ${months.map(m => {
        const mBud = typeRows.reduce((s,r) => s+(r.months?.[m]?.budget||0), 0);
        const mAct = typeRows.reduce((s,r) => s+(r.months?.[m]?.actual||0), 0);
        const fav  = isRevenue(type) ? mAct >= mBud : mAct <= mBud;
        if (isRevenue(type)) { mRevBud[m] += mBud; mRevAct[m] += mAct; }
        else                 { mExpBud[m] += mBud; mExpAct[m] += mAct; }
        return `<td style="text-align:right;color:${fav?'var(--green)':'var(--red)'}">
          ${mAct ? fmt(mAct) : '—'}</td>`;
      }).join('')}
      <td style="text-align:right;color:${isRevenue(type)
        ?(typeAct>=typeBud?'var(--green)':'var(--red)')
        :(typeAct<=typeBud?'var(--green)':'var(--red)')}">${fmt(typeAct)}</td>
    </tr>
    <tr><td colspan="${months.length+2}" style="height:6px"></td></tr>`;

    if (isRevenue(type)) { totalRevBud += typeBud; totalRevAct += typeAct; }
    else                 { totalExpBud += typeBud; totalExpAct += typeAct; }
  });

  const npTotalBud = totalRevBud - totalExpBud;
  const npTotalAct = totalRevAct - totalExpAct;
  html += `<tr style="font-weight:700;font-size:12px;border-top:2.5px solid var(--border2);
      background:var(--row-alt)">
    <td>Net Profit</td>
    ${months.map(m => {
      const npBud = mRevBud[m] - mExpBud[m];
      const npAct = mRevAct[m] - mExpAct[m];
      const fav   = npAct >= npBud;
      return `<td style="text-align:right;color:${fav?'var(--green)':'var(--red)'}">
        ${(npAct||npBud) ? fmt(npAct) : '—'}</td>`;
    }).join('')}
    <td style="text-align:right;color:${npTotalAct>=npTotalBud?'var(--green)':'var(--red)'}">${fmt(npTotalAct)}</td>
  </tr>`;

  html += `</tbody></table></div>
  <div class="mt-8" style="font-size:11px;color:var(--ink3)">
    Top row = budget &middot; bottom row = actual &middot;
    <span style="color:var(--green)">green</span> = favourable &middot;
    <span style="color:var(--red)">red</span> = unfavourable
  </div>`;

  return html;
}
