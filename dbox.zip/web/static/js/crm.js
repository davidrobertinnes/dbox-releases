// ═══════════════════════════════════════════════════════════════════════════
// CRM PAGE
// ═══════════════════════════════════════════════════════════════════════════
let _crmAll=[], _crmFilter='All', _crmSearch='', _crmSort={col:'id',dir:-1}, _crmSelected=null;
let _crmMeta={pipeline_stages:[],comm_types:[],task_types:[],priority:[],quote_status:[]};
let _crmOppId=null, _crmOppContactId=null; // currently open opportunity in detail panel
let _crmActiveTab='comms'; // comms | tasks | quotes | claims
let _crmContacts=[], _crmQuoteLines=[], _crmJobs=[];

const CRM_STAGE_CLASS = {
  'Lead':'crm-stage-lead','Qualified':'crm-stage-qualified','Quoted':'crm-stage-quoted',
  'Accepted':'crm-stage-accepted','In Progress':'crm-stage-inprogress','On Hold':'crm-stage-onhold',
  'Complete':'crm-stage-complete','Invoiced':'crm-stage-invoiced','Won':'crm-stage-won','Lost':'crm-stage-lost'
};
const CRM_STAGE_ACTIVE = ['Lead','Qualified','Quoted','Accepted','In Progress','On Hold','Complete'];

function crmStageBadge(s){
  return `<span class="crm-stage-badge ${CRM_STAGE_CLASS[s]||'crm-stage-lead'}">${esc(s||'—')}</span>`;
}
function quoteStageBadge(s){
  const cls={Draft:'qs-draft',Sent:'qs-sent',Accepted:'qs-accepted',Declined:'qs-declined',
             Superseded:'qs-superseded',Invoiced:'qs-invoiced'}[s]||'qs-draft';
  return `<span class="quote-status-badge ${cls}">${esc(s||'—')}</span>`;
}
function priClass(p){ return {Urgent:'pri-urgent',High:'pri-high',Normal:'pri-normal',Low:'pri-low'}[p]||'pri-normal'; }

async function pageCrm() {
  try {
    [_crmMeta, _crmAll, _crmContacts, _crmJobs] = await Promise.all([
      apiFetch('/api/crm/meta'),
      apiFetch('/api/crm/opportunities'),
      apiFetch('/api/contacts'),
      apiFetch('/api/jobs'),
    ]);
    _crmJobs = _crmJobs || [];
    renderCrmPage();
  } catch(e) {
    document.getElementById('module-content').innerHTML=`<div class="state-error">Failed to load CRM: ${esc(e.message)}</div>`;
  }
}

function _crmFiltered() {
  const q=_crmSearch.toLowerCase();
  return _crmAll.filter(o=>{
    if(_crmFilter!=='All'&&o.stage!==_crmFilter) return false;
    if(q&&![o.title,o.contact_name,o.opp_number,o.owner].some(v=>(v||'').toLowerCase().includes(q))) return false;
    return true;
  }).sort((a,b)=>{
    const col=_crmSort.col;
    const av=a[col]??'', bv=b[col]??'';
    if(col==='value'||col==='probability') return (parseFloat(av||0)-parseFloat(bv||0))*_crmSort.dir;
    return String(av).localeCompare(String(bv))*_crmSort.dir;
  });
}

function renderCrmPage(restoreFocus) {
  const rows=_crmFiltered();
  const stages=['All',..._crmMeta.pipeline_stages];
  const counts={All:_crmAll.length};
  _crmMeta.pipeline_stages.forEach(s=>{ counts[s]=_crmAll.filter(o=>o.stage===s).length; });

  // KPI totals
  const active=_crmAll.filter(o=>CRM_STAGE_ACTIVE.includes(o.stage));
  const totalValue=active.reduce((s,o)=>s+(o.value||0),0);
  const weightedValue=active.reduce((s,o)=>s+(o.value||0)*(o.probability||0)/100,0);
  const openTasks=_crmAll.reduce((s,o)=>s+(o.open_tasks||0),0);
  const wonCount=_crmAll.filter(o=>o.stage==='Won').length;

  const mc=document.getElementById('module-content');
  mc.innerHTML=`
    <div class="crm-kpi-row">
      <div class="kpi-card"><div class="kpi-accent-bar kpi-accent-bar-accent"></div>
        <div class="kpi-label">Active Pipeline</div>
        <div class="kpi-value col-accent">${fmt(totalValue)}</div>
        <div class="kpi-sub">${active.length} opportunit${active.length!==1?'ies':'y'}</div></div>
      <div class="kpi-card"><div class="kpi-accent-bar kpi-accent-bar-green"></div>
        <div class="kpi-label">Weighted Value</div>
        <div class="kpi-value col-green">${fmt(weightedValue)}</div>
        <div class="kpi-sub">probability-adjusted</div></div>
      <div class="kpi-card"><div class="kpi-accent-bar kpi-accent-bar-amber"></div>
        <div class="kpi-label">Open Tasks</div>
        <div class="kpi-value col-amber">${openTasks}</div>
        <div class="kpi-sub">across all opportunities</div></div>
      <div class="kpi-card"><div class="kpi-accent-bar kpi-accent-bar-green"></div>
        <div class="kpi-label">Won</div>
        <div class="kpi-value col-green">${wonCount}</div>
        <div class="kpi-sub">all time</div></div>
    </div>
    <div class="inv-toolbar">
      <input class="inv-search" id="crm-q" placeholder="Search title, contact, ref…" value="${esc(_crmSearch)}">
      <div class="inv-filter-group inv-filter-group-wrap">
        ${stages.map(s=>`<button class="filter-btn${_crmFilter===s?' active':''}" onclick="crmSetFilter('${s.replace(/'/g,"\\'")}')">
          ${esc(s)}${counts[s]?` <span class="filter-count">(${counts[s]})</span>`:''}</button>`).join('')}
      </div>
      <button class="btn btn-primary" onclick="crmNew()">+ New Opportunity</button>
    </div>
    <div class="inv-list-panel">
      <div class="tbl-overflow-x">
      <table class="inv-list-table" id="crm-table">
        <thead><tr>
          <th onclick="crmSortBy('opp_number')" class="${_crmSort.col==='opp_number'?'sort-'+(_crmSort.dir>0?'asc':'desc'):''}">Ref</th>
          <th onclick="crmSortBy('title')" class="${_crmSort.col==='title'?'sort-'+(_crmSort.dir>0?'asc':'desc'):''}">Title</th>
          <th onclick="crmSortBy('contact_name')" class="${_crmSort.col==='contact_name'?'sort-'+(_crmSort.dir>0?'asc':'desc'):''}">Contact</th>
          <th onclick="crmSortBy('stage')" class="${_crmSort.col==='stage'?'sort-'+(_crmSort.dir>0?'asc':'desc'):''}">Stage</th>
          <th onclick="crmSortBy('value')" class="${_crmSort.col==='value'?'sort-'+(_crmSort.dir>0?'asc':'desc'):''}">Value</th>
          <th onclick="crmSortBy('probability')" class="${_crmSort.col==='probability'?'sort-'+(_crmSort.dir>0?'asc':'desc'):''}">Prob %</th>
          <th onclick="crmSortBy('target_close')" class="${_crmSort.col==='target_close'?'sort-'+(_crmSort.dir>0?'asc':'desc'):''}">Target Close</th>
          <th>Comms</th><th>Tasks</th>
          <th onclick="crmSortBy('owner')" class="${_crmSort.col==='owner'?'sort-'+(_crmSort.dir>0?'asc':'desc'):''}">Owner</th>
        </tr></thead>
        <tbody>
          ${rows.length?rows.map(o=>crmRow(o)).join(''):'<tr class="crm-empty-row"><td colspan="10">No opportunities found</td></tr>'}
        </tbody>
      </table>
      </div>
    </div>`;

  const q=document.getElementById('crm-q');
  if(q){
    q.addEventListener('input',e=>{ _crmSearch=e.target.value; renderCrmPage(true); });
    if(restoreFocus){q.focus();q.setSelectionRange(q.value.length,q.value.length);}
  }
}

function crmRow(o) {
  const sel=_crmSelected===o.id;
  const isLost=o.stage==='Lost';
  return `<tr class="inv-row${sel?' is-selected':''}${isLost?' is-void':''}" onclick="crmOpen(${o.id})">
    <td><span class="inv-mono">${esc(o.opp_number||'—')}</span></td>
    <td><span class="inv-contact">${esc(o.title||'—')}</span></td>
    <td>${esc(o.contact_name||'—')}</td>
    <td>${crmStageBadge(o.stage)}</td>
    <td><span class="inv-amt">${o.value!=null?fmt(o.value):'—'}</span></td>
    <td>
      <span class="inv-mono">${o.probability!=null?o.probability+'%':'—'}</span>
      <div class="crm-prob-bar"><div class="crm-prob-fill" style="width:${o.probability||0}%"></div></div>
    </td>
    <td><span class="inv-mono">${fmtDate(o.target_close)}</span></td>
    <td><span class="inv-mono crm-count-muted">${o.comm_count||0}</span></td>
    <td><span class="inv-mono ${o.open_tasks>0?'crm-count-amber':'crm-count-muted'}">${o.open_tasks||0}</span></td>
    <td>${esc(o.owner||'—')}</td>
  </tr>`;
}

function crmSetFilter(f){ _crmFilter=f; renderCrmPage(); }
function crmSortBy(col){ _crmSort={col,dir:_crmSort.col===col?_crmSort.dir*-1:1}; renderCrmPage(); }

// ── Opportunity detail slide-over ─────────────────────────────────────────────

async function crmOpen(oid) {
  _crmSelected=oid;
  renderCrmPage();
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent='Opportunity';
  document.getElementById('det-body').innerHTML='<div class="state-loading">Loading…</div>';
  document.getElementById('det-foot').innerHTML='';
  try {
    const data=await apiFetch(`/api/crm/opportunities/${oid}`);
    _crmOppId=oid;
    renderCrmDetail(data);
  } catch(e) {
    document.getElementById('det-body').innerHTML=`<div class="state-error">${esc(e.message)}</div>`;
  }
}

function renderCrmDetail(data) {
  const o=data.opp;
  _crmOppId=o.id; _crmOppContactId=o.contact_id||null;
  document.getElementById('det-title').textContent=`${esc(o.opp_number)} — ${esc(o.title)}`;

  const tabDef=[
    {id:'comms', label:`Comms (${data.comms.length})`},
    {id:'tasks', label:`Tasks (${data.tasks.filter(t=>!t.is_done).length} open)`},
    {id:'quotes',label:`Quotes (${data.quotes.length})`},
    {id:'claims',label:`Claims (${data.claims.length})`},
    {id:'txns',  label:'🧾 Transactions'},
  ];

  document.getElementById('det-body').innerHTML=`
    <div class="det-badge-row">
      ${crmStageBadge(o.stage)}
      ${o.source?`<span class="badge badge-muted">${esc(o.source)}</span>`:''}
    </div>
    <div class="det-meta">
      <div><div class="det-lbl">Contact</div><div class="det-val">${esc(o.contact_name||'—')}</div></div>
      <div><div class="det-lbl">Value</div><div class="det-val">${o.value!=null?fmt(o.value):'—'}</div></div>
      <div><div class="det-lbl">Probability</div><div class="det-val">${o.probability!=null?o.probability+'%':'—'}</div></div>
      <div><div class="det-lbl">Owner</div><div class="det-val">${esc(o.owner||'—')}</div></div>
      <div><div class="det-lbl">Target Close</div><div class="det-val mono">${fmtDate(o.target_close)}</div></div>
      <div><div class="det-lbl">Start Date</div><div class="det-val mono">${fmtDate(o.start_date)}</div></div>
      ${o.description?`<div class="det-span2"><div class="det-lbl">Description</div><div class="det-val det-val-sm">${esc(o.description)}</div></div>`:''}
      ${o.notes?`<div class="det-span2"><div class="det-lbl">Notes</div><div class="det-note">${esc(o.notes)}</div></div>`:''}
    </div>
    <div class="det-tabs" id="crm-tabs">
      ${tabDef.map(t=>`<div class="det-tab${_crmActiveTab===t.id?' active':''}" onclick="crmTab('${t.id}',${o.id})">${t.label}</div>`).join('')}
    </div>
    <div class="opp-tab-content" id="crm-tab-content"></div>`;

  // Surface the most important quote action at the footer level
  const acceptedQuote = data.quotes.find(q=>q.status==='Accepted'&&!q.invoice_id);
  const hasDraftQuote = data.quotes.some(q=>q.status==='Draft'||q.status==='Sent');

  document.getElementById('det-foot').innerHTML=`
    ${acceptedQuote
      ? `<button class="btn btn-primary" onclick="crmConvertQuote(${acceptedQuote.id})">→ Convert to Invoice</button>`
      : hasDraftQuote
        ? `<button class="btn btn-green"   onclick="crmTab('quotes',${o.id})">✓ Accept Quote</button>`
        : `<button class="btn btn-outline" onclick="crmNewQuote(${o.id},${o.contact_id||'null'})">+ New Quote</button>`
    }
    <button class="btn btn-outline" onclick="crmQuickStage(${o.id},'${esc(o.stage)}')">Stage &#8594;</button>
    <button class="btn btn-outline" onclick="crmEdit(${o.id})">&#9999; Edit</button>
    <button class="btn btn-danger"  onclick="crmDelete(${o.id})">Delete</button>
    <button class="btn btn-outline" onclick="detClose()">Close</button>`;

  crmTab(_crmActiveTab, o.id, data);
}

async function crmTab(tab, oid, preloaded) {
  _crmActiveTab=tab;
  document.querySelectorAll('#crm-tabs .det-tab').forEach(el=>{
    const starts={'comms':'Comms','tasks':'Tasks','quotes':'Quotes','claims':'Claims','txns':'🧾'}
    el.classList.toggle('active', el.textContent.startsWith(starts[tab]||''));
  });
  const el=document.getElementById('crm-tab-content');
  if(!el) return;
  el.innerHTML='<div class="state-loading">Loading…</div>';
  try {
    const data=preloaded||(await apiFetch(`/api/crm/opportunities/${oid}`));
    if(tab==='comms')        renderCrmComms(data.comms,  oid);
    else if(tab==='tasks')   renderCrmTasks(data.tasks,  oid);
    else if(tab==='quotes')  renderCrmQuotes(data.quotes, oid, data.opp);
    else if(tab==='claims')  renderCrmClaims(data.claims, oid, data.opp);
    else if(tab==='txns')    renderCrmTxns(oid);
  } catch(e){ el.innerHTML=`<div class="state-error">${esc(e.message)}</div>`; }
}

// ── Comms tab ─────────────────────────────────────────────────────────────────

function renderCrmComms(comms, oid) {
  const el=document.getElementById('crm-tab-content');
  const rows=comms.map(c=>`
    <div class="comm-row">
      <div class="comm-meta">
        <span class="comm-type-badge">${esc(c.comm_type)}</span>
        <span class="comm-date">${fmtDate(c.comm_date)}</span>
        ${c.subject?`<span class="comm-subj-inline">${esc(c.subject)}</span>`:''}
        <button onclick="crmDelComm(${c.id},${oid})" class="btn-icon-del" title="Delete">✕</button>
      </div>
      ${c.body?`<div class="comm-body">${esc(c.body)}</div>`:''}
      ${c.outcome?`<div class="comm-outcome">→ ${esc(c.outcome)}</div>`:''}
      ${c.next_action?`<div class="comm-next">Next: ${esc(c.next_action)}${c.next_action_date?' — '+fmtDate(c.next_action_date):''}</div>`:''}
    </div>`).join('');

  el.innerHTML=`
    <div class="tab-add-row">
      <button class="btn btn-outline btn-sm-outline" onclick="crmLogComm(${oid})">+ Log Communication</button>
    </div>
    ${rows||'<div class="det-empty">No communications logged yet.</div>'}`;
}

async function crmLogComm(oid) {
  const types=_crmMeta.comm_types||['Call','Email','Meeting','Note'];
  const todayVal=isoToday();
  document.getElementById('det-body').innerHTML=`
    <h3 class="form-section-hdr">Log Communication</h3>
    <div class="edt-grid">
      <div class="edt-field"><label class="edt-lbl">Type *</label>
        <select class="edt-sel" id="cf-type">${types.map(t=>`<option>${t}</option>`).join('')}</select></div>
      <div class="edt-field"><label class="edt-lbl">Date *</label>
        <input class="edt-inp" id="cf-date" type="date" value="${todayVal}"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Subject</label>
        <input class="edt-inp" id="cf-subj" placeholder="Brief subject"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Notes / Body</label>
        <textarea class="edt-ta edt-ta-tall" id="cf-body" placeholder="Call notes, email summary, meeting minutes…"></textarea></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Outcome</label>
        <input class="edt-inp" id="cf-outcome" placeholder="Result of this interaction"></div>
      <div class="edt-field"><label class="edt-lbl">Next Action</label>
        <input class="edt-inp" id="cf-next" placeholder="What to do next"></div>
      <div class="edt-field"><label class="edt-lbl">Next Action Date</label>
        <input class="edt-inp" id="cf-nextdate" type="date"></div>
    </div>`;
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="cf-save-btn" onclick="saveComm(${oid})">Save</button>
    <button class="btn btn-outline" onclick="crmTab('comms',${oid})">Cancel</button>`;
  document.getElementById('cf-subj').focus();
}

async function saveComm(oid) {
  const date=document.getElementById('cf-date')?.value;
  if(!date){toast('Date is required','err');return;}
  const btn=document.getElementById('cf-save-btn');
  btn.disabled=true; btn.textContent='Saving…';
  try {
    await fetch('/api/crm/communications',{method:'POST',headers:{'Content-Type':'application/json'},
      credentials:'include',body:JSON.stringify({
        opp_id:oid,
        comm_date:date,
        comm_type:document.getElementById('cf-type')?.value||'Note',
        subject:document.getElementById('cf-subj')?.value.trim()||'',
        body:document.getElementById('cf-body')?.value.trim()||'',
        outcome:document.getElementById('cf-outcome')?.value.trim()||'',
        next_action:document.getElementById('cf-next')?.value.trim()||'',
        next_action_date:document.getElementById('cf-nextdate')?.value||null,
      })}).then(r=>r.json()).then(j=>{if(!j.ok)throw new Error(j.error||'Save failed');});
    toast('Communication logged');
    _crmAll=await apiFetch('/api/crm/opportunities')||_crmAll;
    renderCrmPage();
    await crmTab('comms',oid);
  } catch(e){toast(e.message,'err');btn.disabled=false;btn.textContent='Save';}
}

async function crmDelComm(cid,oid) {
  if(!await confirmDlg('Delete this communication log entry?')) return;
  try {
    const r=await fetch(`/api/crm/communications/${cid}`,{method:'DELETE',credentials:'include'});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Delete failed');
    toast('Deleted');
    await crmTab('comms',oid);
  } catch(e){toast(e.message,'err');}
}

// ── Tasks tab ─────────────────────────────────────────────────────────────────

function renderCrmTasks(tasks, oid) {
  const el=document.getElementById('crm-tab-content');
  const open=tasks.filter(t=>!t.is_done);
  const done=tasks.filter(t=>t.is_done);
  const today=isoToday();

  const taskRow=t=>{
    const overdue=!t.is_done&&t.due_date&&t.due_date<today;
    const addedDate = t.created_at ? fmtDate(t.created_at.split(' ')[0]) : '';
    const doneDate  = t.done_at    ? fmtDate(t.done_at.split(' ')[0])    : '';
    return `<div class="task-detail-row${t.is_done?' is-void':''}">
      <span class="task-pri-badge ${priClass(t.priority)}">${esc(t.priority)}</span>
      <div class="task-row-body">
        <div class="${t.is_done?'task-title-done':'task-title'}">${esc(t.title)}</div>
        <div class="${overdue?'task-meta-overdue':'task-meta'}">
          ${esc(t.task_type)}${t.due_date?' — Due: '+fmtDate(t.due_date)+(overdue?' ⚠':''):''}
          ${t.assigned_to?' — '+esc(t.assigned_to):''}
          ${t.job_id?' — <span class="wt-link-badge">Job: '+esc(t.job_name||t.job_number||'#'+t.job_id)+'</span>':''}
        </div>
        <div class="task-dates">Added: ${addedDate}${doneDate?' &nbsp;·&nbsp; Completed: '+doneDate:''}</div>
      </div>
      ${!t.is_done?`<button class="btn btn-green btn-sm-action" onclick="crmCompleteTask(${t.id},${oid})">Done</button>`:''}
      <button onclick="crmDelTask(${t.id},${oid})" class="btn-icon-del-r" title="Delete">✕</button>
    </div>`;
  };

  el.innerHTML=`
    <div class="tab-add-row">
      <button class="btn btn-outline btn-sm-outline" onclick="crmAddTask(${oid})">+ Add Task</button>
    </div>
    ${open.length?open.map(taskRow).join(''):'<div class="det-empty tab-add-row">No open tasks.</div>'}
    ${done.length?`<div class="tasks-done-hdr">Completed (${done.length})</div>${done.map(taskRow).join('')}`:''}`;
}

async function crmAddTask(oid) {
  const types=_crmMeta.task_types||['Follow Up','Send Quote','Schedule Meeting','Other'];
  const priorities=_crmMeta.priority||['Low','Normal','High','Urgent'];
  const todayVal=isoToday();
  const opp=(_crmAll||[]).find(o=>o.id===oid);
  const oppContactId=opp?.contact_id||null;
  const eligibleJobs=(_crmJobs||[]).filter(j=>!j.contact_id||!oppContactId||j.contact_id===oppContactId);
  const jobOpts=`<option value="">No job</option>${eligibleJobs.map(j=>`<option value="${j.id}">${esc(j.job_number+' — '+j.name)}</option>`).join('')}`;
  document.getElementById('det-body').innerHTML=`
    <h3 class="form-section-hdr">Add Task</h3>
    <div class="edt-grid">
      <div class="edt-field edt-span"><label class="edt-lbl">Title *</label>
        <input class="edt-inp" id="tf-title" placeholder="Task description"></div>
      <div class="edt-field"><label class="edt-lbl">Type</label>
        <select class="edt-sel" id="tf-type">${types.map(t=>`<option>${t}</option>`).join('')}</select></div>
      <div class="edt-field"><label class="edt-lbl">Priority</label>
        <select class="edt-sel" id="tf-pri">${priorities.map(p=>`<option${p==='Normal'?' selected':''}>${p}</option>`).join('')}</select></div>
      <div class="edt-field"><label class="edt-lbl">Due Date</label>
        <input class="edt-inp" id="tf-due" type="date" value="${todayVal}"></div>
      <div class="edt-field"><label class="edt-lbl">Assigned To</label>
        <input class="edt-inp" id="tf-assigned" placeholder="Name or leave blank"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Job</label>
        <select class="edt-sel" id="tf-job">${jobOpts}</select></div>
    </div>`;
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="tf-save-btn" onclick="saveTask(${oid})">Save Task</button>
    <button class="btn btn-outline" onclick="crmTab('tasks',${oid})">Cancel</button>`;
  document.getElementById('tf-title').focus();
}

async function saveTask(oid) {
  const title=(document.getElementById('tf-title')?.value||'').trim();
  if(!title){toast('Title is required','err');return;}
  const btn=document.getElementById('tf-save-btn');
  btn.disabled=true; btn.textContent='Saving…';
  try {
    await fetch('/api/crm/tasks',{method:'POST',headers:{'Content-Type':'application/json'},
      credentials:'include',body:JSON.stringify({
        opp_id:oid, title,
        task_type:document.getElementById('tf-type')?.value||'Follow Up',
        priority:document.getElementById('tf-pri')?.value||'Normal',
        due_date:document.getElementById('tf-due')?.value||null,
        assigned_to:document.getElementById('tf-assigned')?.value.trim()||null,
        job_id:parseInt(document.getElementById('tf-job')?.value)||null,
      })}).then(r=>r.json()).then(j=>{if(!j.ok)throw new Error(j.error||'Save failed');});
    toast('Task added');
    _crmAll=await apiFetch('/api/crm/opportunities')||_crmAll;
    renderCrmPage();
    await crmTab('tasks',oid);
  } catch(e){toast(e.message,'err');btn.disabled=false;btn.textContent='Save Task';}
}

async function crmCompleteTask(tid,oid) {
  try {
    const r=await fetch(`/api/crm/tasks/${tid}/complete`,{method:'POST',credentials:'include'});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Failed');
    toast('Task marked done');
    _crmAll=await apiFetch('/api/crm/opportunities')||_crmAll;
    renderCrmPage();
    await crmTab('tasks',oid);
  } catch(e){toast(e.message,'err');}
}

async function crmDelTask(tid,oid) {
  if(!await confirmDlg('Delete this task?')) return;
  try {
    const r=await fetch(`/api/crm/tasks/${tid}`,{method:'DELETE',credentials:'include'});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Delete failed');
    toast('Deleted');
    await crmTab('tasks',oid);
  } catch(e){toast(e.message,'err');}
}

// ── Quotes tab ────────────────────────────────────────────────────────────────

function renderCrmQuotes(quotes, oid, opp) {
  const el=document.getElementById('crm-tab-content');
  const rows=quotes.map(q=>{
    const canAccept   = q.status==='Draft'||q.status==='Sent';
    const canConvert  = q.status==='Accepted'&&!q.invoice_id;
    const canCreatePO = q.status==='Accepted'&&!q.po_id;
    const actions = [
      canAccept   ? `<button class="btn btn-green btn-sm-green" onclick="event.stopPropagation();crmAcceptQuote(${q.id},${oid})">✓ Accept</button>` : '',
      canConvert  ? `<button class="btn btn-primary btn-sm-primary" onclick="event.stopPropagation();crmConvertQuote(${q.id})">→ Invoice</button>` : '',
      canCreatePO ? `<button class="btn btn-secondary btn-sm" onclick="event.stopPropagation();crmCreatePO(${q.id},${oid})">🏭 Create PO</button>` : '',
      q.invoice_id ? `<span class="quote-invoiced-lbl">✓ Invoiced</span>` : '',
      q.po_id      ? `<span class="quote-invoiced-lbl col-green">✓ PO</span>` : '',
      `<button class="btn btn-ghost btn-sm-outline" onclick="crmOpenQuote(${q.id},${oid})">View →</button>`,
    ].filter(Boolean).join('');
    return `
    <div class="quote-row">
      <div class="quote-row-body">
        <div class="quote-row-hdr">
          ${quoteStageBadge(q.status)}
          <span class="quote-row-num">${esc(q.quote_number)}</span>
          <span class="inv-amt quote-row-amt">${fmt(q.total)}</span>
        </div>
        <div class="quote-row-meta">${fmtDate(q.quote_date)}${q.expiry_date?' · Expires '+fmtDate(q.expiry_date):''}</div>
      </div>
      <div class="quote-row-actions">${actions}</div>
    </div>`;
  }).join('');

  el.innerHTML=`
    <div class="tab-add-row">
      <button class="btn btn-outline btn-sm-outline" onclick="crmNewQuote(${oid},${opp.contact_id||'null'})">+ New Quote</button>
    </div>
    ${rows||'<div class="det-empty">No quotes yet — click + New Quote to get started.</div>'}`;
}

async function crmOpenQuote(qid, oid) {
  document.getElementById('det-body').innerHTML='<div class="state-loading">Loading…</div>';
  document.getElementById('det-foot').innerHTML='';
  try {
    const data=await apiFetch(`/api/crm/quotes/${qid}`);
    renderQuoteDetail(data, oid);
  } catch(e){document.getElementById('det-body').innerHTML=`<div class="state-error">${esc(e.message)}</div>`;}
}

function renderQuoteDetail(data, oid) {
  const q=data.quote, lines=data.lines||[];
  document.getElementById('det-title').textContent=`Quote ${esc(q.quote_number)}`;
  const linesHtml=`
    <table class="det-lines">
      <thead><tr><th>Description</th><th class="th-r">Qty</th><th class="th-r">Price</th><th>Tax</th><th class="th-r">Total</th></tr></thead>
      <tbody>${lines.map(l=>`<tr>
        <td>${esc(l.description)}</td>
        <td class="td-r-mono">${l.quantity}</td>
        <td class="td-r-mono">${fmt(l.unit_price)}</td>
        <td><span class="inv-mono">${esc(l.tax_code)}</span></td>
        <td class="td-r-mono">${fmt(l.line_total)}</td>
      </tr>`).join('')}</tbody>
    </table>
    <div class="det-totals">
      <div class="det-tot-row"><span>Subtotal</span><span>${fmt(q.subtotal)}</span></div>
      <div class="det-tot-row"><span>GST</span><span>${fmt(q.gst_total)}</span></div>
      <div class="det-tot-row grand"><span>Total</span><span>${fmt(q.total)}</span></div>
    </div>`;

  document.getElementById('det-body').innerHTML=`
    <div class="det-badge-row">
      ${quoteStageBadge(q.status)}
    </div>
    <div class="det-meta">
      <div><div class="det-lbl">Quote Date</div><div class="det-val mono">${fmtDate(q.quote_date)}</div></div>
      <div><div class="det-lbl">Expiry</div><div class="det-val mono">${fmtDate(q.expiry_date)}</div></div>
      <div><div class="det-lbl">Contact</div><div class="det-val">${esc(q.contact_name||'—')}</div></div>
      <div><div class="det-lbl">Status</div><div class="det-val">${esc(q.status)}</div></div>
      ${q.accepted_date?`<div><div class="det-lbl">Accepted</div><div class="det-val mono">${fmtDate(q.accepted_date)}</div></div>`:''}
      ${q.invoice_id?`<div><div class="det-lbl">Invoice</div><div class="det-val"><a href="#" onclick="invOpen(${q.invoice_id});return false" class="det-inv-link">#${q.invoice_id}</a></div></div>`:''}
      ${q.po_id?`<div><div class="det-lbl">Purchase Order</div><div class="det-val col-green">PO #${q.po_id}</div></div>`:''}
    </div>
    ${q.intro_text?`<div class="det-section-block"><div class="det-lbl det-lbl-gap">Intro</div><div class="det-note">${esc(q.intro_text)}</div></div>`:''}
    ${linesHtml}
    ${q.terms_text?`<div class="det-section-top"><div class="det-lbl det-lbl-gap">Terms</div><div class="det-note">${esc(q.terms_text)}</div></div>`:''}
    ${q.internal_notes?`<div class="det-section-top"><div class="det-lbl det-lbl-gap">Internal Notes</div><div class="det-note">${esc(q.internal_notes)}</div></div>`:''}`;

  const canAccept   = q.status==='Draft'||q.status==='Sent';
  const canConvert  = q.status==='Accepted'&&!q.invoice_id;
  const canCreatePO = q.status==='Accepted'&&!q.po_id;
  document.getElementById('det-foot').innerHTML=`
    ${canAccept?`<button class="btn btn-green" onclick="crmAcceptQuote(${q.id},${oid})">✓ Accept</button>`:''}
    ${canConvert?`<button class="btn btn-primary" onclick="crmConvertQuote(${q.id})">→ Create Invoice</button>`:''}
    ${canCreatePO?`<button class="btn btn-secondary" onclick="crmCreatePO(${q.id},${oid})">🏭 Create PO</button>`:''}
    <button class="btn btn-outline" onclick="crmEditQuote(${q.id},${oid})">✏ Edit</button>
    <button class="btn btn-outline" onclick="window.open('/api/crm/quotes/${q.id}/pdf')">⬇ PDF</button>
    ${q.status!=='Accepted'&&q.status!=='Invoiced'?`<button class="btn btn-danger" onclick="crmDelQuote(${q.id},${oid})">Delete</button>`:''}
    <button class="btn btn-outline" onclick="crmTab('quotes',${oid})">← Back</button>`;
}

async function crmAcceptQuote(qid, oid) {
  if(!await confirmDlg('Accept this quote? Other draft quotes on this opportunity will be superseded.')) return;
  try {
    const r=await fetch(`/api/crm/quotes/${qid}/accept`,{method:'POST',credentials:'include'});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Failed');
    toast('Quote accepted — opportunity moved to Accepted');
    _crmAll=await apiFetch('/api/crm/opportunities')||_crmAll;
    renderCrmPage();
    await crmOpenQuote(qid, oid);
  } catch(e){toast(e.message,'err');}
}

async function crmConvertQuote(qid) {
  if(!await confirmDlg('Convert this quote to a draft invoice?')) return;
  try {
    const r=await fetch(`/api/crm/quotes/${qid}/convert`,{method:'POST',credentials:'include'});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Failed');
    toast('Invoice created — opening invoices…');
    detClose();
    _crmAll=await apiFetch('/api/crm/opportunities')||_crmAll;
    setTimeout(()=>{ navigate('invoices'); setTimeout(()=>invOpen(j.data.invoice_id),400); },400);
  } catch(e){toast(e.message,'err');}
}

async function crmCreatePO(qid, oid) {
  let suppliers = [];
  try {
    const contacts = await apiFetch('/api/contacts');
    suppliers = (contacts||[]).filter(c=>['Supplier','Both'].includes(c.contact_type));
  } catch(e) { toast(e.message,'err'); return; }

  const today = isoToday();
  const supOpts = suppliers.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join('');

  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box" style="width:min(420px,95vw)">
      <div class="modal-hdr"><span>Create PO from Quote</span>
        <button class="det-close" onclick="this.closest('.modal-bd').remove()">✕</button>
      </div>
      <div class="modal-body" style="padding:16px 20px">
        <p style="margin:0 0 12px;font-size:13px;color:var(--ink2)">Creates a supplier PO using the lines from this quote.</p>
        <label class="edt-lbl">Supplier *</label>
        <select id="crm-po-supp" class="edt-field edt-field-mb">
          <option value="">— Select supplier —</option>${supOpts}
        </select>
        <label class="edt-lbl">PO Date</label>
        <input id="crm-po-date" type="date" class="edt-field edt-field-mb" value="${today}">
        <label class="edt-lbl">Expected Date</label>
        <input id="crm-po-exp" type="date" class="edt-field edt-field-mb" value="">
      </div>
      <div class="modal-foot">
        <button class="btn btn-secondary" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary" id="crm-po-create-btn" onclick="_crmDoCreatePO(${qid},${oid})">Create PO</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
}

async function _crmDoCreatePO(qid, oid) {
  const suppEl = document.getElementById('crm-po-supp');
  if (!suppEl?.value) { alert('Select a supplier.'); return; }
  const btn = document.getElementById('crm-po-create-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Creating…'; }
  try {
    const r = await fetch(`/api/crm/quotes/${qid}/create-po`, {
      method:'POST', credentials:'include',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        supplier_id:   parseInt(suppEl.value),
        po_date:       document.getElementById('crm-po-date')?.value || null,
        expected_date: document.getElementById('crm-po-exp')?.value  || null,
      })
    });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || 'Failed');
    document.querySelector('.modal-bd')?.remove();
    toast(`Purchase Order created (PO #${j.po_id}) — find it in Purchase Orders.`);
    _crmAll = await apiFetch('/api/crm/opportunities') || _crmAll;
    renderCrmPage();
    await crmOpenQuote(qid, oid);
  } catch(e) {
    if (btn) { btn.disabled = false; btn.textContent = 'Create PO'; }
    toast(e.message, 'err');
  }
}

async function crmDelQuote(qid, oid) {
  if(!await confirmDlg('Delete this quote?')) return;
  try {
    const r=await fetch(`/api/crm/quotes/${qid}`,{method:'DELETE',credentials:'include'});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Delete failed');
    toast('Deleted');
    await crmTab('quotes',oid);
  } catch(e){toast(e.message,'err');}
}

// ── Quote editor (new + edit) ─────────────────────────────────────────────────

async function _ensureCrmEditAccts() {
  if (!window._crmEditAccts) {
    try {
      const accts = await apiFetch('/api/accounts');
      window._crmEditAccts = (accts||[]).filter(a => ['Revenue','Income','Other Income'].includes(a.account_type));
      if (!window._crmEditAccts.length) window._crmEditAccts = (accts||[]).filter(a => a.account_type);
    } catch(_) { window._crmEditAccts = []; }
  }
}

async function crmNewQuote(oid, contactId) {
  _crmQuoteLines=[{description:'',quantity:1,unit_price:0,tax_code:'GST',account_id:null,item_id:null,line_type:'item'}];
  await _ensureCrmEditAccts();
  const todayVal=isoToday();
  const expiry=isoAddDays(30);
  _showQuoteForm({opp_id:oid,contact_id:contactId,quote_date:todayVal,expiry_date:expiry,status:'Draft'},oid,false);
}

async function crmEditQuote(qid, oid) {
  try {
    const [data] = await Promise.all([apiFetch(`/api/crm/quotes/${qid}`), _ensureCrmEditAccts()]);
    const defLine={description:'',quantity:1,unit_price:0,tax_code:'GST',account_id:null,item_id:null,line_type:'item'};
    _crmQuoteLines=data.lines.length?data.lines.map(l=>({...defLine,...l})):[defLine];
    _showQuoteForm(data.quote, oid, true);
  } catch(e){toast(e.message,'err');}
}

function _showQuoteForm(q, oid, isEdit) {
  const statuses=_crmMeta.quote_status||['Draft','Sent'];
  const conOpts=(_crmContacts||[]).map(c=>`<option value="${c.id}"${c.id===q.contact_id?' selected':''}>${esc(c.name)}</option>`).join('');

  document.getElementById('det-title').textContent=isEdit?`Edit Quote ${q.quote_number||''}` : 'New Quote';
  document.getElementById('det-body').innerHTML=`
    <div class="edt-grid edt-grid-mb">
      <div class="edt-field"><label class="edt-lbl">Quote Date *</label>
        <input class="edt-inp" id="qf-date" type="date" value="${q.quote_date||''}"></div>
      <div class="edt-field"><label class="edt-lbl">Expiry Date</label>
        <input class="edt-inp" id="qf-expiry" type="date" value="${q.expiry_date||''}"></div>
      <div class="edt-field"><label class="edt-lbl">Contact</label>
        <select class="edt-sel" id="qf-contact"><option value="">— Select —</option>${conOpts}</select></div>
      <div class="edt-field"><label class="edt-lbl">Status</label>
        <select class="edt-sel" id="qf-status">${statuses.map(s=>`<option${s===q.status?' selected':''}>${s}</option>`).join('')}</select></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Intro Text</label>
        <textarea class="edt-ta" id="qf-intro" placeholder="Optional intro paragraph on the quote…">${esc(q.intro_text||'')}</textarea></div>
    </div>
    <div class="edt-section-lbl">Line Items</div>
    <div class="edt-lines-hdr"><span></span><span>Description</span><span>Qty</span><span>Unit Price</span><span>Tax</span><span>GST</span><span>Total</span><span></span></div>
    <div id="qf-lines"></div>
    <button class="btn btn-outline edt-add-btn" onclick="qfAddLine()">+ Add Line</button>
    <div class="edt-totals-preview" id="qf-totals"></div>
    <div class="edt-divider"></div>
    <div class="edt-grid">
      <div class="edt-field edt-span"><label class="edt-lbl">Terms</label>
        <textarea class="edt-ta" id="qf-terms" placeholder="Payment terms, conditions…">${esc(q.terms_text||'')}</textarea></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Internal Notes</label>
        <textarea class="edt-ta" id="qf-notes" placeholder="Internal notes (not shown on quote)">${esc(q.internal_notes||'')}</textarea></div>
    </div>`;

  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="qf-save-btn" onclick="saveQuote(${q.id||'null'},${oid},${q.opp_id||oid})">${isEdit?'Save Changes':'Create Quote'}</button>
    <button class="btn btn-outline" onclick="${isEdit?`crmOpenQuote(${q.id},${oid})`:`crmTab('quotes',${oid})`}">Cancel</button>`;

  qfRenderLines();
}

function qfAddLine() {
  _crmQuoteLines.push({description:'',quantity:1,unit_price:0,tax_code:'GST',account_id:null,item_id:null,line_type:'item'});
  qfRenderLines();
}

function qfRemoveLine(i) {
  _crmQuoteLines.splice(i,1);
  if(!_crmQuoteLines.length) _crmQuoteLines=[{description:'',quantity:1,unit_price:0,tax_code:'GST',account_id:null,item_id:null,line_type:'item'}];
  qfRenderLines();
}

function qfToggleLineType(i) {
  const l=_crmQuoteLines[i];
  l.line_type=(l.line_type==='comment')?'item':'comment';
  if(l.line_type==='comment'){l.quantity=0;l.unit_price=0;l.account_id=null;l.item_id=null;}
  else{l.quantity=1;l.unit_price=0;}
  qfRenderLines();
  qfCalc();
  if(l.line_type==='comment'){setTimeout(()=>{const ta=document.getElementById(`qf-desc-${i}`);if(ta){ta.focus();}},0);}
  else{_wireQfLineTypeahead(i);}
}

function qfRenderLines() {
  const el=document.getElementById('qf-lines');
  if(!el) return;
  const accts = window._crmEditAccts || [];
  el.innerHTML=_crmQuoteLines.map((l,i)=>{
    const isComment = l.line_type === 'comment';
    const toggleBtn = `<button class="edt-type-btn${isComment?' is-comment':''}" title="${isComment?'Switch to item line':'Switch to comment line'}" onclick="qfToggleLineType(${i})">${isComment?'T':'≡'}</button>`;
    if (isComment) {
      return `
    <div class="edt-line-wrap" id="qf-line-${i}">
      <div class="edt-line-row edt-comment-row">
        ${toggleBtn}
        <textarea class="edt-inp edt-comment-ta" id="qf-desc-${i}"
          placeholder="Comment or heading…"
          oninput="_crmQuoteLines[${i}].description=this.value">${esc(l.description||'')}</textarea>
        <button class="edt-rm-btn" onclick="qfRemoveLine(${i})">✕</button>
      </div>
    </div>`;
    }
    const ex=parseFloat(l.quantity||1)*parseFloat(l.unit_price||0);
    const rate=(l.tax_code==='GST')?0.1:0;
    const g=Math.round(ex*rate*100)/100;
    const tot=Math.round((ex+g)*100)/100;
    const acctOpts=accts.map(a=>`<option value="${a.id}"${a.id===l.account_id?' selected':''}>${esc((a.code?a.code+' ':'')+a.name)}</option>`).join('');
    return `
    <div class="edt-line-wrap" id="qf-line-${i}">
      <div class="edt-line-row">
        ${toggleBtn}
        <input class="edt-inp" type="text" id="qf-desc-${i}" value="${esc(l.description||'')}"
          placeholder="Description or search catalogue…"
          oninput="_crmQuoteLines[${i}].description=this.value">
        <input class="edt-inp" type="number" id="qf-qty-${i}" step="0.01" min="0" value="${l.quantity||1}"
          oninput="_crmQuoteLines[${i}].quantity=parseFloat(this.value)||0;qfLineCalc(${i})">
        <input class="edt-inp" type="number" id="qf-price-${i}" step="0.01" min="0" value="${l.unit_price||0}"
          oninput="_crmQuoteLines[${i}].unit_price=parseFloat(this.value)||0;qfLineCalc(${i})">
        <select class="edt-sel" onchange="_crmQuoteLines[${i}].tax_code=this.value;qfLineCalc(${i})">
          ${['GST','FRE','N-T'].map(tc=>`<option${(l.tax_code||'GST')===tc?' selected':''}>${tc}</option>`).join('')}
        </select>
        <span class="edt-calc" id="qf-gst-${i}">${fmt(g)}</span>
        <span class="edt-calc edt-calc-total" id="qf-tot-${i}">${fmt(tot)}</span>
        <button class="edt-rm-btn" onclick="qfRemoveLine(${i})">✕</button>
      </div>
      <div class="edt-line-acct">
        <span class="edt-acct-lbl">Account</span>
        <select class="edt-sel edt-acct-sel" id="qf-acct-${i}" onchange="_crmQuoteLines[${i}].account_id=this.value?+this.value:null">
          <option value="">— default (Sales) —</option>${acctOpts}
        </select>
      </div>
    </div>`;
  }).join('');
  // Wire catalogue typeahead on item lines
  _crmQuoteLines.forEach((l,i) => { if(l.line_type!=='comment') _wireQfLineTypeahead(i); });
  qfCalc();
}

function _wireQfLineTypeahead(i) {
  const inp=document.getElementById(`qf-desc-${i}`);
  if(!inp||inp.dataset.taWired) return;
  inp.dataset.taWired='1';
  _attachTypeahead(inp, item => {
    _crmQuoteLines[i].description = item.description||item.name;
    _crmQuoteLines[i].unit_price  = parseFloat(item.unit_price)||0;
    _crmQuoteLines[i].tax_code    = item.tax_code||'GST';
    _crmQuoteLines[i].account_id  = item.account_id||null;
    _crmQuoteLines[i].item_id     = item.id;
    // Push values to DOM inputs
    const priceInp=document.getElementById(`qf-price-${i}`);
    if(priceInp) priceInp.value=(parseFloat(item.unit_price)||0).toFixed(2);
    const taxSel=document.querySelector(`#qf-line-${i} select`);
    if(taxSel) taxSel.value=item.tax_code||'GST';
    const acctSel=document.getElementById(`qf-acct-${i}`);
    if(acctSel&&item.account_id) acctSel.value=item.account_id;
    qfLineCalc(i);
  });
}

function qfLineCalc(i) {
  const l=_crmQuoteLines[i];
  if(l.line_type==='comment'){qfCalc();return;}
  const ex=parseFloat(l.quantity||0)*parseFloat(l.unit_price||0);
  const rate=(l.tax_code==='GST')?0.1:0;
  const g=Math.round(ex*rate*100)/100;
  const tot=Math.round((ex+g)*100)/100;
  const gEl=document.getElementById(`qf-gst-${i}`);
  const tEl=document.getElementById(`qf-tot-${i}`);
  if(gEl) gEl.textContent=fmt(g);
  if(tEl) tEl.textContent=fmt(tot);
  qfCalc();
}

function qfCalc() {
  let sub=0,gst=0;
  _crmQuoteLines.forEach(l=>{
    if(l.line_type==='comment') return;
    const ex=parseFloat(l.quantity||0)*parseFloat(l.unit_price||0);
    const g=l.tax_code==='GST'?Math.round(ex*0.1*100)/100:0;
    sub+=ex; gst+=g;
  });
  sub=Math.round(sub*100)/100;
  gst=Math.round(gst*100)/100;
  const tot=document.getElementById('qf-totals');
  if(tot) tot.innerHTML=`
    <span>Subtotal <b>${fmt(sub)}</b></span>
    <span>GST <b>${fmt(gst)}</b></span>
    <span class="grand">Total <b>${fmt(Math.round((sub+gst)*100)/100)}</b></span>`;
}

async function saveQuote(qid, oid, oppId) {
  const date=document.getElementById('qf-date')?.value;
  if(!date){toast('Quote date is required','err');return;}
  const lines=_crmQuoteLines.filter(l=>l.description.trim());
  if(!lines.length){toast('Add at least one line item','err');return;}
  const btn=document.getElementById('qf-save-btn');
  btn.disabled=true; btn.textContent='Saving…';
  const contactId=parseInt(document.getElementById('qf-contact')?.value||0)||null;
  const body={
    quote:{
      id:qid||undefined, opp_id:oppId,
      contact_id:contactId,
      quote_date:date,
      expiry_date:document.getElementById('qf-expiry')?.value||null,
      status:document.getElementById('qf-status')?.value||'Draft',
      intro_text:document.getElementById('qf-intro')?.value.trim()||null,
      terms_text:document.getElementById('qf-terms')?.value.trim()||null,
      internal_notes:document.getElementById('qf-notes')?.value.trim()||null,
    },
    lines:lines.map(l=>({
      description:l.description,
      quantity:   l.line_type==='comment'?0:l.quantity,
      unit_price: l.line_type==='comment'?0:l.unit_price,
      tax_code:   l.tax_code||'GST',
      account_id: l.account_id||null,
      item_id:    l.item_id||null,
      line_type:  l.line_type||'item',
    })),
  };
  try {
    const method=qid?'PUT':'POST';
    const url=qid?`/api/crm/quotes/${qid}`:'/api/crm/quotes';
    const r=await fetch(url,{method,headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(body)});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
    toast(qid?'Quote updated':'Quote created');
    _crmAll=await apiFetch('/api/crm/opportunities')||_crmAll;
    renderCrmPage();
    const newQid=qid||j.data.id;
    await crmOpenQuote(newQid, oid);
  } catch(e){toast(e.message,'err');btn.disabled=false;btn.textContent=qid?'Save Changes':'Create Quote';}
}

// ── Claims tab ────────────────────────────────────────────────────────────────

function renderCrmClaims(claims, oid, opp) {
  const el=document.getElementById('crm-tab-content');
  const rows=claims.map(c=>{
    const statCls={'Draft':'claim-status-draft','Claimed':'claim-status-claimed','Invoiced':'claim-status-invoiced','Paid':'claim-status-paid'}[c.status]||'claim-status-draft';
    return `<div class="task-detail-row">
      <div class="claim-row-body">
        <div class="claim-num">${esc(c.claim_number)}</div>
        <div class="claim-meta">${fmtDate(c.claim_date)} · ${esc(c.description||'—')}</div>
      </div>
      <span class="claim-status ${statCls}">${esc(c.status)}</span>
      <span class="inv-amt">${fmt(c.amount_inc_gst)}</span>
      ${!c.invoice_id&&c.status!=='Invoiced'?`<button class="btn btn-outline btn-sm-outline" onclick="crmConvertClaim(${c.id},${oid})">→ Invoice</button>`:''}
      <button onclick="crmDelClaim(${c.id},${oid})" class="btn-icon-del-r" title="Delete">✕</button>
    </div>`;
  }).join('');

  el.innerHTML=`
    <div class="tab-add-row">
      <button class="btn btn-outline btn-sm-outline" onclick="crmNewClaim(${oid},${opp.contact_id||'null'})">+ New Claim</button>
    </div>
    ${rows||'<div class="det-empty">No progress claims yet.</div>'}`;
}

// ── Transactions tab ──────────────────────────────────────────────────────────

async function renderCrmTxns(oid) {
  const el=document.getElementById('crm-tab-content');
  const cid=_crmOppContactId;
  const newBtns=`<div class="txn-new-row">
    <button class="btn btn-outline btn-sm" onclick="invNew({contact_id:${cid||'null'},opp_id:${oid}})">+ New Invoice</button>
    <button class="btn btn-outline btn-sm" onclick="billNew({contact_id:${cid||'null'},opp_id:${oid}})">+ New Bill</button>
  </div>`;
  try {
    const rows=await apiFetch(`/api/crm/opportunities/${oid}/transactions`);
    if(!rows||!rows.length){
      el.innerHTML=`${newBtns}<div class="det-empty">No invoices or bills linked to this opportunity.</div>`;
      return;
    }
    const tbody=rows.map(r=>{
      const isVoid=(r.status||'').toLowerCase().includes('void');
      const isPaid=['paid','approved'].includes((r.status||'').toLowerCase());
      const statusCls=isVoid?'txn-status txn-status-void':isPaid?'txn-status txn-status-paid':r.type==='Bill'?'txn-status txn-status-amber':'txn-status txn-status-accent';
      const openFn=r.type==='Invoice'?`invOpen(${r.id})`:`billOpen(${r.id})`;
      return `<tr class="${isVoid?'txn-void':''}">
        <td><span class="${r.type==='Invoice'?'txn-type-inv':'txn-type-bill'}">${esc(r.type)}</span></td>
        <td><a href="#" onclick="${openFn};return false" class="txn-num-link">${esc(r.number||'—')}</a></td>
        <td class="txn-td-mono">${fmtDate(r.date)}</td>
        <td class="txn-td-mono">${fmtDate(r.due_date)}</td>
        <td><span class="${statusCls}">${esc(r.status)}</span></td>
        <td class="txn-td-r">${fmt(r.total)}</td>
        <td class="txn-td-r ${r.balance_due>0.005?'txn-bal-due':'txn-bal-paid'}">${fmt(r.balance_due)}</td>
      </tr>`;
    }).join('');
    el.innerHTML=`<div class="txn-wrap">${newBtns}
      <table class="txn-table">
        <thead><tr class="txn-thead-row">
          <th class="txn-th">Type</th>
          <th class="txn-th">Number</th>
          <th class="txn-th">Date</th>
          <th class="txn-th">Due</th>
          <th class="txn-th">Status</th>
          <th class="txn-th-r">Total</th>
          <th class="txn-th-r">Balance Due</th>
        </tr></thead>
        <tbody>${tbody}</tbody>
      </table></div>`;
  } catch(e){ el.innerHTML=`<div class="state-error">${esc(e.message)}</div>`; }
}

async function crmNewClaim(oid, contactId) {
  const todayVal=isoToday();
  document.getElementById('det-body').innerHTML=`
    <h3 class="form-section-hdr">New Progress Claim</h3>
    <div class="edt-grid">
      <div class="edt-field"><label class="edt-lbl">Claim Date *</label>
        <input class="edt-inp" id="clm-date" type="date" value="${todayVal}"></div>
      <div class="edt-field"><label class="edt-lbl">Amount ex-GST *</label>
        <input class="edt-inp" id="clm-amount" type="number" step="0.01" min="0" placeholder="0.00"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Description</label>
        <input class="edt-inp" id="clm-desc" placeholder="Work completed this claim period"></div>
      <div class="edt-field"><label class="edt-lbl">Cumulative % Claimed</label>
        <input class="edt-inp" id="clm-pct" type="number" step="1" min="0" max="100" placeholder="0"></div>
    </div>`;
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="clm-save-btn" onclick="saveClaim(${oid},${contactId||'null'})">Create Claim</button>
    <button class="btn btn-outline" onclick="crmTab('claims',${oid})">Cancel</button>`;
  document.getElementById('clm-amount').focus();
}

async function saveClaim(oid, contactId) {
  const date=document.getElementById('clm-date')?.value;
  const amount=parseFloat(document.getElementById('clm-amount')?.value||0);
  if(!date||!amount){toast('Date and amount are required','err');return;}
  const btn=document.getElementById('clm-save-btn');
  btn.disabled=true; btn.textContent='Saving…';
  try {
    await fetch('/api/crm/claims',{method:'POST',headers:{'Content-Type':'application/json'},
      credentials:'include',body:JSON.stringify({
        opp_id:oid, contact_id:contactId||null,
        claim_date:date, amount_ex_gst:amount,
        description:document.getElementById('clm-desc')?.value.trim()||'',
        cumulative_pct:parseFloat(document.getElementById('clm-pct')?.value||0),
        tax_code:'GST',
      })}).then(r=>r.json()).then(j=>{if(!j.ok)throw new Error(j.error||'Save failed');});
    toast('Claim created');
    await crmTab('claims',oid);
  } catch(e){toast(e.message,'err');btn.disabled=false;btn.textContent='Create Claim';}
}

async function crmConvertClaim(cid, oid) {
  if(!await confirmDlg('Convert this progress claim to a draft invoice?')) return;
  try {
    const r=await fetch(`/api/crm/claims/${cid}/convert`,{method:'POST',credentials:'include'});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Failed');
    toast('Invoice created');
    _crmAll=await apiFetch('/api/crm/opportunities')||_crmAll;
    renderCrmPage();
    await crmTab('claims',oid);
  } catch(e){toast(e.message,'err');}
}

async function crmDelClaim(cid, oid) {
  if(!await confirmDlg('Delete this progress claim?')) return;
  try {
    const r=await fetch(`/api/crm/claims/${cid}`,{method:'DELETE',credentials:'include'});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Delete failed');
    toast('Deleted');
    await crmTab('claims',oid);
  } catch(e){toast(e.message,'err');}
}

// ── New / Edit Opportunity form ───────────────────────────────────────────────

async function crmNew() {
  _crmOppId=null;
  _showOppForm(null);
}

async function crmEdit(oid) {
  try {
    const data=await apiFetch(`/api/crm/opportunities/${oid}`);
    _showOppForm(data.opp);
  } catch(e){toast(e.message,'err');}
}

function _showOppForm(o) {
  const isNew=!o;
  const stages=_crmMeta.pipeline_stages||[];
  const sources=['Referral','Website','Cold Call','Social Media','Exhibition','Repeat Client','Partner','Other'];
  const conOpts=(_crmContacts||[]).map(c=>`<option value="${c.id}"${o?.contact_id===c.id?' selected':''}>${esc(c.name)}</option>`).join('');
  const stageOpts=stages.map(s=>`<option${(o?.stage||'Lead')===s?' selected':''}>${s}</option>`).join('');
  const srcOpts=sources.map(s=>`<option${o?.source===s?' selected':''}>${s}</option>`).join('');

  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent=isNew?'New Opportunity':'Edit Opportunity';
  document.getElementById('det-body').innerHTML=`
    <div class="edt-grid">
      <div class="edt-field edt-span"><label class="edt-lbl">Title *</label>
        <input class="edt-inp" id="of-title" value="${esc(o?.title||'')}" placeholder="Deal or project name"></div>
      <div class="edt-field"><label class="edt-lbl">Contact</label>
        <select class="edt-sel" id="of-contact"><option value="">— None —</option>${conOpts}</select></div>
      <div class="edt-field"><label class="edt-lbl">Stage</label>
        <select class="edt-sel" id="of-stage">${stageOpts}</select></div>
      <div class="edt-field"><label class="edt-lbl">Est. Value ($)</label>
        <input class="edt-inp" id="of-value" type="number" step="0.01" min="0" value="${o?.value||''}"></div>
      <div class="edt-field"><label class="edt-lbl">Probability (%)</label>
        <input class="edt-inp" id="of-prob" type="number" step="1" min="0" max="100" value="${o?.probability??50}"></div>
      <div class="edt-field"><label class="edt-lbl">Source</label>
        <select class="edt-sel" id="of-source"><option value="">— None —</option>${srcOpts}</select></div>
      <div class="edt-field"><label class="edt-lbl">Owner</label>
        <input class="edt-inp" id="of-owner" list="of-owner-list"
               value="${esc(o?.owner||'')}" placeholder="Type or select…" autocomplete="off">
        <datalist id="of-owner-list">
          ${(_crmContacts||[]).map(c=>`<option value="${esc(c.name)}">`).join('')}
        </datalist></div>
      <div class="edt-field"><label class="edt-lbl">Start Date</label>
        <input class="edt-inp" id="of-start" type="date" value="${o?.start_date||''}"></div>
      <div class="edt-field"><label class="edt-lbl">Target Close</label>
        <input class="edt-inp" id="of-close" type="date" value="${o?.target_close||''}"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Description</label>
        <textarea class="edt-ta" id="of-desc">${esc(o?.description||'')}</textarea></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Notes</label>
        <textarea class="edt-ta" id="of-notes">${esc(o?.notes||'')}</textarea></div>
    </div>`;

  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="of-save-btn" onclick="saveOpp(${o?.id||'null'})">${isNew?'Create':'Save Changes'}</button>
    <button class="btn btn-outline" onclick="${o?.id?`crmOpen(${o.id})`:'detClose()'}">${isNew?'Cancel':'Cancel'}</button>`;
  document.getElementById('of-title').focus();
}

async function saveOpp(oid) {
  const title=(document.getElementById('of-title')?.value||'').trim();
  if(!title){toast('Title is required','err');return;}
  const btn=document.getElementById('of-save-btn');
  btn.disabled=true; btn.textContent='Saving…';
  const data={
    id:oid||undefined,
    title,
    contact_id:parseInt(document.getElementById('of-contact')?.value||0)||null,
    stage:document.getElementById('of-stage')?.value||'Lead',
    value:parseFloat(document.getElementById('of-value')?.value||0)||null,
    probability:parseInt(document.getElementById('of-prob')?.value||50),
    source:document.getElementById('of-source')?.value||null,
    owner:document.getElementById('of-owner')?.value.trim()||null,
    start_date:document.getElementById('of-start')?.value||null,
    target_close:document.getElementById('of-close')?.value||null,
    description:document.getElementById('of-desc')?.value.trim()||null,
    notes:document.getElementById('of-notes')?.value.trim()||null,
  };
  try {
    const method=oid?'PUT':'POST';
    const url=oid?`/api/crm/opportunities/${oid}`:'/api/crm/opportunities';
    const r=await fetch(url,{method,headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(data)});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
    toast(oid?'Opportunity updated':'Opportunity created');
    _crmAll=await apiFetch('/api/crm/opportunities')||_crmAll;
    renderCrmPage();
    const newOid=oid||j.data.id;
    _crmActiveTab='comms';
    await crmOpen(newOid);
  } catch(e){toast(e.message,'err');btn.disabled=false;btn.textContent=oid?'Save Changes':'Create';}
}

async function crmDelete(oid) {
  if(!await confirmDlg('Delete this opportunity? All communications, tasks and quotes will also be deleted.')) return;
  try {
    const r=await fetch(`/api/crm/opportunities/${oid}`,{method:'DELETE',credentials:'include'});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Delete failed');
    toast('Opportunity deleted');
    detClose();
    _crmAll=await apiFetch('/api/crm/opportunities')||_crmAll;
    renderCrmPage();
  } catch(e){toast(e.message,'err');}
}


// ── Quick Stage ───────────────────────────────────────────────────────────────
// Desktop equivalent: OppDetailDialog "Stage →" button → small inline dialog.
// Web uses a modal rather than a Toplevel. Intentional divergence: slide-overs
// are reserved for edit forms per the design system; a single-field action fits
// a modal better on the web.

function crmQuickStage(oid, currentStage) {
  const stages = _crmMeta.pipeline_stages || [];
  const opts = stages.map(s =>
    `<option value="${esc(s)}"${s===currentStage?' selected':''}>${esc(s)}</option>`
  ).join('');

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box" style="width:min(340px,94vw)">
      <div class="modal-hdr"><span>Move Stage</span></div>
      <div class="modal-body">
        <div class="edt-field">
          <label class="edt-lbl">Stage</label>
          <select class="edt-sel" id="qs-stage">${opts}</select>
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" id="qs-apply">Apply</button>
      </div>
    </div>`;
  document.body.appendChild(bd);

  bd.querySelector('#qs-apply').onclick = async () => {
    const newStage = bd.querySelector('#qs-stage').value;
    bd.querySelector('#qs-apply').disabled = true;
    try {
      // Fetch current opp data to avoid clobbering other fields on PUT
      const data = await apiFetch(`/api/crm/opportunities/${oid}`);
      const opp = data.opp;
      const r = await fetch(`/api/crm/opportunities/${oid}`, {
        method: 'PUT',
        credentials: 'include',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({...opp, stage: newStage}),
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Save failed');
      toast('Stage updated');
      bd.remove();
      _crmAll = await apiFetch('/api/crm/opportunities') || _crmAll;
      renderCrmPage();
      await crmOpen(oid);
    } catch(e) {
      toast(e.message, 'err');
      bd.querySelector('#qs-apply').disabled = false;
    }
  };
}
