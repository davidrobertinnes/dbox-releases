// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ═══════════════════════════════════════════════════════════════════════════
// REPORTS MODULE
// ═══════════════════════════════════════════════════════════════════════════

// ── State ──────────────────────────────────────────────────────────────────
let _rptActiveType      = 'pl';   // pl | bs | tb | bas | aged | cashflow | livestock | budget
let _rptBasis           = 'accrual';
let _rptForm            = 'bas';  // bas | ias
let _rptAgedType        = 'receivables';
let _rptDateFrom        = '';
let _rptDateTo          = '';
let _rptLoading         = false;
let _rptCaps            = null;   // tier caps array — loaded once in pageReports()
let _rptBudgetPeriods   = null;   // loaded on demand when budget type selected
let _rptBudgetPeriodId  = null;
let _rptTbSoftware      = '';     // myob_tax | handisoft | ''

// ── FY helpers ─────────────────────────────────────────────────────────────
// Always use local-time getters — toISOString() returns UTC and returns the
// wrong date for users in timezones east of UTC (e.g. Australia UTC+10/+11).
function _isoLocal(d) {
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function _rptFyStart() {
  const n = new Date();
  const y = n.getMonth() >= 6 ? n.getFullYear() : n.getFullYear() - 1;
  return `${y}-07-01`;
}
function _rptToday() { return _isoLocal(new Date()); }
function _rptMonthStart() {
  const n = new Date(); return `${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,'0')}-01`;
}
function _rptMonthEnd() {
  const n = new Date();
  return _isoLocal(new Date(n.getFullYear(), n.getMonth()+1, 0));
}
function _rptQuarterStart() {
  const n = new Date(), m = n.getMonth();
  const qm = [m < 3 ? 0 : m < 6 ? 3 : m < 9 ? 6 : 9];
  return `${n.getFullYear()}-${String(qm[0]+1).padStart(2,'0')}-01`;
}
function _rptQuarterEnd() {
  const n = new Date(), m = n.getMonth();
  const eq = m < 3 ? 2 : m < 6 ? 5 : m < 9 ? 8 : 11;
  return _isoLocal(new Date(n.getFullYear(), eq+1, 0));
}
function _rptLastMonthStart() {
  const n = new Date();
  return _isoLocal(new Date(n.getFullYear(), n.getMonth()-1, 1));
}
function _rptLastMonthEnd() {
  const n = new Date();
  return _isoLocal(new Date(n.getFullYear(), n.getMonth(), 0));
}
function _rptLastQuarterStart() {
  const n = new Date(), m = n.getMonth();
  const qm = m < 3 ? 9 : m < 6 ? 0 : m < 9 ? 3 : 6;
  const yr = m < 3 ? n.getFullYear()-1 : n.getFullYear();
  return `${yr}-${String(qm+1).padStart(2,'0')}-01`;
}
function _rptLastQuarterEnd() {
  const n = new Date(), m = n.getMonth();
  const eq = m < 3 ? 11 : m < 6 ? 2 : m < 9 ? 5 : 8;
  const yr = m < 3 ? n.getFullYear()-1 : n.getFullYear();
  return _isoLocal(new Date(yr, eq+1, 0));
}
function _rptLastFyStart() {
  const n = new Date(), y = n.getMonth() >= 6 ? n.getFullYear()-1 : n.getFullYear()-2;
  return `${y}-07-01`;
}
function _rptLastFyEnd() {
  const n = new Date(), y = n.getMonth() >= 6 ? n.getFullYear()-1 : n.getFullYear()-2;
  return `${y+1}-06-30`;
}

// ── Entry point ────────────────────────────────────────────────────────────
async function pageReports() {
  if (!_rptDateFrom) { _rptDateFrom = _rptFyStart(); _rptDateTo = _rptToday(); }
  if (!_rptCaps) {
    try {
      const me = await apiFetch('/api/me');
      _rptCaps = me.tier_caps || [];
    } catch(e) {
      _rptCaps = [];
    }
  }
  // If current type requires a cap the user doesn't have, fall back to pl
  if (_rptActiveType === 'aged' && !_rptCaps.includes('aged')) {
    _rptActiveType = 'pl';
  }
  _renderReportsShell();
  _rptRunReport();
}

// ── Shell HTML ─────────────────────────────────────────────────────────────
function _renderReportsShell() {
  const mc = document.getElementById('module-content');
  mc.innerHTML = `
  <style>
    .rpt-layout { display:grid; grid-template-columns:224px minmax(0,1fr); gap:14px; align-items:start; }
    .rpt-sidebar { display:flex; flex-direction:column; gap:10px; position:sticky; top:0; z-index:10; }
    .rpt-card { background:var(--surface); border:1px solid var(--border); border-radius:10px; overflow:hidden; }
    #rpt-date-card { overflow:visible; }
    .rpt-card-hdr { font-family:'DM Mono',monospace; font-size:9px; font-weight:500; letter-spacing:1.3px;
      text-transform:uppercase; color:var(--ink3); padding:10px 14px 6px; }
    .rpt-type-btn { display:flex; align-items:center; gap:8px; padding:8px 14px; cursor:pointer;
      font-size:12.5px; color:var(--ink2); font-weight:500; transition:all 0.12s; border-left:3px solid transparent; }
    .rpt-type-btn:hover { background:var(--row-alt); color:var(--ink); }
    .rpt-type-btn.active { background:var(--accent-dim); color:var(--accent); font-weight:600;
      border-left-color:var(--accent); }
    .rpt-type-icon { width:18px; text-align:center; font-size:13px; flex-shrink:0; }
    .rpt-date-row { display:flex; flex-direction:column; gap:6px; padding:10px 14px; }
    .rpt-date-lbl { font-family:'DM Mono',monospace; font-size:9px; color:var(--ink3);
      text-transform:uppercase; letter-spacing:0.8px; margin-bottom:3px; }
    .rpt-date-inp { width:100%; padding:5px 8px; border:1.5px solid var(--border); border-radius:6px;
      font-family:'DM Mono',monospace; font-size:11px; background:var(--entry-bg); color:var(--ink);
      outline:none; transition:border-color 0.13s; }
    .rpt-date-inp:focus { border-color:var(--accent); }
    .rpt-presets { display:flex; flex-wrap:wrap; gap:4px; padding:0 14px 10px; }
    .rpt-preset { padding:3px 9px; font-family:'DM Mono',monospace; font-size:10px; border-radius:6px;
      border:1.5px solid var(--border); background:var(--entry-bg); color:var(--ink3); cursor:pointer;
      transition:all 0.12s; }
    .rpt-preset:hover { border-color:var(--accent); color:var(--accent); }
    .rpt-opt-row { padding:8px 14px; }
    .rpt-opt-lbl { font-family:'DM Mono',monospace; font-size:9px; color:var(--ink3);
      text-transform:uppercase; letter-spacing:0.8px; margin-bottom:5px; }
    .rpt-radio-grp { display:flex; flex-direction:column; gap:4px; }
    .rpt-radio { display:flex; align-items:center; gap:6px; font-size:12px; color:var(--ink2); cursor:pointer; }
    .rpt-radio input { accent-color:var(--accent); }
    .rpt-run-btn { margin:6px 14px 10px; padding:8px; border-radius:8px; border:none;
      background:var(--accent); color:#fff; font-family:'Instrument Sans',sans-serif;
      font-size:13px; font-weight:600; cursor:pointer; width:calc(100% - 28px);
      transition:opacity 0.13s; }
    .rpt-run-btn:hover { opacity:0.87; }
    .rpt-run-btn:disabled { opacity:0.55; cursor:not-allowed; }
    .rpt-main { min-height:300px; min-width:0; overflow-x:auto; }
    .rpt-toolbar { display:flex; align-items:center; justify-content:space-between; margin-bottom:12px; flex-wrap:wrap; gap:8px; }
    .rpt-toolbar-left { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
    .rpt-title-block { }
    .rpt-title { font-family:'Syne',sans-serif; font-size:16px; font-weight:700; color:var(--ink); }
    .rpt-subtitle { font-family:'DM Mono',monospace; font-size:10.5px; color:var(--ink3); margin-top:2px; }
    .rpt-preview { background:var(--surface); border:1px solid var(--border); border-radius:10px;
      overflow:hidden; box-shadow:var(--shadow); }
    .rpt-preview-hdr { padding:10px 16px; border-bottom:1px solid var(--border); background:var(--row-alt);
      display:flex; align-items:center; gap:8px; }
    .rpt-preview-title { font-family:'Syne',sans-serif; font-size:12px; font-weight:700; color:var(--ink); flex:1; }
    .rpt-preview-body { padding:16px; overflow-x:auto; }
    .rpt-section-hdr { font-family:'DM Mono',monospace; font-size:9px; font-weight:600; letter-spacing:1px;
      text-transform:uppercase; color:var(--accent); background:var(--accent-dim); padding:7px 12px;
      border-radius:5px; margin:14px 0 4px; }
    .rpt-table { width:100%; border-collapse:collapse; font-size:12.5px; }
    .rpt-table th { font-family:'DM Mono',monospace; font-size:9px; font-weight:500; letter-spacing:1px;
      text-transform:uppercase; color:var(--ink3); padding:7px 12px; border-bottom:1.5px solid var(--border);
      background:var(--row-alt); text-align:left; }
    .rpt-table th.r { text-align:right; }
    .rpt-table td { padding:8px 12px; border-bottom:1px solid var(--border); color:var(--ink2); }
    .rpt-table tr:last-child td { border-bottom:none; }
    .rpt-table td.r { text-align:right; font-family:'DM Mono',monospace; font-weight:600; }
    .rpt-table td.code { font-family:'DM Mono',monospace; font-size:11px; color:var(--ink3); }
    .rpt-table tr.subtotal td { background:var(--accent-dim); font-weight:700; color:var(--accent); border-top:1.5px solid var(--border2); }
    .rpt-table tr.grand td { background:var(--accent); color:#fff; font-size:13px; font-weight:700; }
    .rpt-table tr.grand td.r { font-family:'DM Mono',monospace; }
    .rpt-table tr.profit td { background:var(--green-dim); color:var(--green); font-weight:700; }
    .rpt-table tr.loss td { background:var(--red-dim); color:var(--red); font-weight:700; }
    .rpt-table tr.alt td { background:var(--row-alt); }
    .rpt-amt-pos { color:var(--green); }
    .rpt-amt-neg { color:var(--red); }
    .rpt-bas-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
    .rpt-bas-section { background:var(--entry-bg); border:1px solid var(--border); border-radius:8px; overflow:hidden; }
    .rpt-bas-sec-hdr { font-family:'DM Mono',monospace; font-size:9px; font-weight:600; letter-spacing:1px;
      text-transform:uppercase; color:#fff; background:var(--accent); padding:7px 12px; }
    .rpt-bas-row { display:flex; align-items:center; justify-content:space-between; padding:8px 12px;
      border-bottom:1px solid var(--border); font-size:12.5px; }
    .rpt-bas-row:last-child { border-bottom:none; }
    .rpt-bas-code { font-family:'DM Mono',monospace; font-size:11px; font-weight:700;
      color:#fff; background:var(--ink); padding:2px 7px; border-radius:4px; margin-right:8px; flex-shrink:0; }
    .rpt-bas-lbl { flex:1; color:var(--ink2); }
    .rpt-bas-val { font-family:'DM Mono',monospace; font-size:12px; font-weight:700; color:var(--ink); }
    .rpt-bas-net { grid-column:1/-1; background:var(--accent); border-radius:8px; padding:14px 16px;
      display:flex; align-items:center; justify-content:space-between; margin-top:4px; }
    .rpt-bas-net-lbl { font-size:14px; font-weight:700; color:#fff; }
    .rpt-bas-net-val { font-family:'Syne',sans-serif; font-size:22px; font-weight:800; color:#fff; }
    .rpt-bas-net-val.refund { color:#a8ffc4; }
    .rpt-aged-grid { display:grid; grid-template-columns:repeat(5,1fr); gap:6px; margin-bottom:16px; }
    .rpt-aged-kpi { background:var(--surface); border:1px solid var(--border); border-radius:8px;
      padding:10px 12px; text-align:center; }
    .rpt-aged-kpi-lbl { font-family:'DM Mono',monospace; font-size:9px; color:var(--ink3);
      text-transform:uppercase; letter-spacing:0.8px; margin-bottom:4px; }
    .rpt-aged-kpi-val { font-family:'Syne',sans-serif; font-size:16px; font-weight:700; }
    .rpt-empty { text-align:center; padding:48px 20px; color:var(--ink3);
      font-family:'DM Mono',monospace; font-size:12px; }
  </style>

  <div class="rpt-layout">
    <!-- Left sidebar -->
    <div class="rpt-sidebar">

      <!-- Report type selector -->
      <div class="rpt-card">
        <div class="rpt-card-hdr">Report Type</div>
        <div style="max-height:260px;overflow-y:auto">
        ${[
          ['pl',       '📊', 'Profit & Loss'],
          ['bs',       '📋', 'Balance Sheet'],
          ['tb',       '⚖️',  'Trial Balance'],
          ['bas',      '🧾', 'BAS / IAS'],
          ['aged',     '📅', 'Aged AR / AP'],
          ['cashflow',  '💧', 'Cash Flow'],
          ['livestock', '🐄', 'Livestock Trading'],
          ['gl',        '📒', 'General Ledger'],
          ['budget',    '📈', 'Budget vs Actual'],
        ].filter(([k]) => k !== 'aged' || (_rptCaps||[]).includes('aged'))
         .map(([k,ic,lbl]) => `
          <div class="rpt-type-btn${_rptActiveType===k?' active':''}" onclick="rptSetType('${k}')">
            <span class="rpt-type-icon">${ic}</span>${lbl}
          </div>`).join('')}
        </div>
      </div>

      <!-- Date range -->
      <div class="rpt-card" id="rpt-date-card">
        <div class="rpt-card-hdr">Date Range</div>
        <div class="rpt-date-row">
          <div>
            <div class="rpt-date-lbl">From</div>
            <input class="rpt-date-inp" type="date" id="rpt-from"
              value="${_rptDateFrom}" onchange="_rptDateFrom=this.value">
          </div>
          <div>
            <div class="rpt-date-lbl">To / As At</div>
            <input class="rpt-date-inp" type="date" id="rpt-to"
              value="${_rptDateTo}" onchange="_rptDateTo=this.value">
          </div>
        </div>
        <div class="rpt-presets">
          <div class="rpt-preset" onclick="rptPreset('month')">This Month</div>
          <div class="rpt-preset" onclick="rptPreset('quarter')">This Qtr</div>
          <div class="rpt-preset" onclick="rptPreset('ytd')">YTD</div>
          <div class="rpt-preset" onclick="rptPreset('lmonth')">Last Month</div>
          <div class="rpt-preset" onclick="rptPreset('lquarter')">Last Qtr</div>
          <div class="rpt-preset" onclick="rptPreset('lfy')">Last FY</div>
        </div>
      </div>

      <!-- Options card (contextual) -->
      <div class="rpt-card" id="rpt-opts-card"></div>

      <!-- Run / PDF / CSV buttons -->
      <div class="rpt-card" style="padding:6px 0 2px">
        <button class="rpt-run-btn" id="rpt-run-btn" onclick="_rptRunReport()">▶ Run Report</button>
        <button class="rpt-run-btn" id="rpt-pdf-btn"
          style="background:var(--green);margin-top:4px" onclick="rptDownloadPdf()">
          ⎙ Download PDF
        </button>
        <button class="rpt-run-btn" id="rpt-csv-btn"
          style="background:var(--accent2);margin-top:4px" onclick="rptDownloadCsv()">
          ⬇ Export CSV
        </button>
      </div>

      <!-- EOY Package -->
      <div class="rpt-card" style="padding:10px 14px 12px">
        <div class="rpt-card-hdr" style="padding:0 0 8px">Accountant Package</div>
        <div style="font-size:11px;color:var(--ink3);margin-bottom:10px;line-height:1.5">
          Bundle TB, GL &amp; asset schedule into one ZIP for your accountant.
        </div>
        <button class="rpt-run-btn" style="background:var(--accent)" onclick="_rptEoyWizard()">
          📦 Download EOY Package
        </button>
        <button class="rpt-run-btn" style="background:var(--surface);color:var(--ink2);border:1.5px solid var(--border);margin-top:6px"
            onclick="_rptCoaMapping()">
          🗺 COA Mapping
        </button>
      </div>

    </div>

    <!-- Main preview area -->
    <div class="rpt-main" id="rpt-main">
      <div class="state-loading">Select a report and click Run Report</div>
    </div>
  </div>`;

  _renderRptOpts();
}

// ── Options card (basis, form type, aged type) ─────────────────────────────
function _renderRptOpts() {
  const card = document.getElementById('rpt-opts-card');
  if (!card) return;

  if (_rptActiveType === 'pl' || _rptActiveType === 'bas') {
    card.innerHTML = `
      <div class="rpt-opt-row">
        <div class="rpt-opt-lbl">Accounting Basis</div>
        <div class="rpt-radio-grp">
          <label class="rpt-radio">
            <input type="radio" name="rpt-basis" value="accrual"
              ${_rptBasis==='accrual'?'checked':''} onchange="_rptBasis=this.value;_rptRunReport()">
            Accrual
          </label>
          <label class="rpt-radio">
            <input type="radio" name="rpt-basis" value="cash"
              ${_rptBasis==='cash'?'checked':''} onchange="_rptBasis=this.value;_rptRunReport()">
            Cash
          </label>
        </div>
      </div>`;
    if (_rptActiveType === 'bas') {
      card.innerHTML += `
        <div class="rpt-opt-row" style="border-top:1px solid var(--border)">
          <div class="rpt-opt-lbl">Form Type</div>
          <div class="rpt-radio-grp">
            <label class="rpt-radio">
              <input type="radio" name="rpt-form" value="bas"
                ${_rptForm==='bas'?'checked':''} onchange="_rptForm=this.value">
              BAS (GST + PAYG)
            </label>
            <label class="rpt-radio">
              <input type="radio" name="rpt-form" value="ias"
                ${_rptForm==='ias'?'checked':''} onchange="_rptForm=this.value">
              IAS (PAYG only)
            </label>
          </div>
        </div>`;
    }
    return;
  }

  if (_rptActiveType === 'aged') {
    card.innerHTML = `
      <div class="rpt-opt-row">
        <div class="rpt-opt-lbl">Report Type</div>
        <div class="rpt-radio-grp">
          <label class="rpt-radio">
            <input type="radio" name="rpt-aged" value="receivables"
              ${_rptAgedType==='receivables'?'checked':''} onchange="_rptAgedType=this.value">
            Aged Receivables
          </label>
          <label class="rpt-radio">
            <input type="radio" name="rpt-aged" value="payables"
              ${_rptAgedType==='payables'?'checked':''} onchange="_rptAgedType=this.value">
            Aged Payables
          </label>
        </div>
      </div>`;
    return;
  }

  if (_rptActiveType === 'tb') {
    card.innerHTML = `
      <div class="rpt-opt-row">
        <div class="rpt-opt-lbl">Accountant Software</div>
        <select class="rpt-date-inp" id="rpt-tb-software"
            onchange="_rptTbSoftware=this.value">
          <option value="">— None —</option>
          <option value="myob_tax"   ${_rptTbSoftware==='myob_tax'?'selected':''}>MYOB Tax</option>
          <option value="handisoft"  ${_rptTbSoftware==='handisoft'?'selected':''}>Handisoft</option>
        </select>
        <div style="font-size:10.5px;color:var(--ink3);margin-top:5px;line-height:1.5">
          Adds mapped codes to CSV export.
          <span style="color:var(--accent);cursor:pointer;text-decoration:underline"
            onclick="_rptCoaMapping()">Manage mapping →</span>
        </div>
      </div>`;
    return;
  }

  if (_rptActiveType === 'budget') {
    if (!_rptBudgetPeriods) {
      card.innerHTML = `<div style="padding:12px;font-size:12px;color:var(--ink3)">Loading periods…</div>`;
      _loadBudgetPeriods();
      return;
    }
    if (!_rptBudgetPeriods.length) {
      card.innerHTML = `<div style="padding:12px;font-size:12px;color:var(--ink3);line-height:1.5">
        No budget periods found.<br>Create one in the Budget module first.</div>`;
      return;
    }
    card.innerHTML = `
      <div class="rpt-opt-row">
        <div class="rpt-opt-lbl">Budget Period</div>
        <select class="rpt-date-inp" id="rpt-budget-period"
            onchange="_rptBudgetPeriodId=parseInt(this.value)">
          ${_rptBudgetPeriods.map(p =>
            `<option value="${p.id}" ${_rptBudgetPeriodId===p.id?'selected':''}>${esc(p.name)}</option>`
          ).join('')}
        </select>
      </div>`;
    return;
  }

  card.innerHTML = '';
}

// ── Type switcher ──────────────────────────────────────────────────────────
function rptSetType(key) {
  _rptActiveType = key;
  document.querySelectorAll('.rpt-type-btn').forEach(el =>
    el.classList.toggle('active', el.textContent.trim().length > 0 &&
      el.getAttribute('onclick') === `rptSetType('${key}')`));
  _renderRptOpts();
  if (key === 'budget' && !_rptBudgetPeriods) _loadBudgetPeriods();
}

async function _loadBudgetPeriods() {
  try {
    const periods = await apiFetch('/api/reports/budget-periods');
    _rptBudgetPeriods = periods;
    if (_rptBudgetPeriodId === null && periods.length) {
      _rptBudgetPeriodId = periods[0].id;
    }
    if (_rptActiveType === 'budget') _renderRptOpts();
  } catch(e) { _rptBudgetPeriods = []; }
}

// ── Preset dates ───────────────────────────────────────────────────────────
function rptPreset(p) {
  const map = {
    month:    [_rptMonthStart,    _rptMonthEnd],
    quarter:  [_rptQuarterStart,  _rptQuarterEnd],
    ytd:      [_rptFyStart,       _rptToday],
    lmonth:   [_rptLastMonthStart,_rptLastMonthEnd],
    lquarter: [_rptLastQuarterStart,_rptLastQuarterEnd],
    lfy:      [_rptLastFyStart,   _rptLastFyEnd],
  };
  const [sf,st] = map[p]||[];
  if (!sf) return;
  _rptDateFrom = sf(); _rptDateTo = st();
  const fi=document.getElementById('rpt-from'), ti=document.getElementById('rpt-to');
  if(fi) fi.value=_rptDateFrom; if(ti) ti.value=_rptDateTo;
}

// ── Run report ─────────────────────────────────────────────────────────────
async function _rptRunReport() {
  if (_rptLoading) return;
  _rptLoading = true;
  const btn = document.getElementById('rpt-run-btn');
  if (btn) { btn.disabled=true; btn.textContent='Loading…'; }
  const main = document.getElementById('rpt-main');
  if (main) main.innerHTML='<div class="state-loading">Generating report…</div>';

  try {
    const from = _rptDateFrom || _rptFyStart();
    const to   = _rptDateTo   || _rptToday();
    const type = _rptActiveType;

    if (type === 'pl') {
      const d = await apiFetch(`/api/reports/profit-loss?from=${from}&to=${to}&basis=${_rptBasis}`);
      _renderPL(d, from, to);
    } else if (type === 'bs') {
      const d = await apiFetch(`/api/reports/balance-sheet?as_of=${to}`);
      _renderBS(d, to);
    } else if (type === 'tb') {
      const d = await apiFetch(`/api/reports/trial-balance?as_of=${to}`);
      _renderTB(d, to);
    } else if (type === 'bas') {
      const d = await apiFetch(`/api/reports/bas?from=${from}&to=${to}&basis=${_rptBasis}`);
      _renderBAS(d, from, to);
    } else if (type === 'aged') {
      const d = await apiFetch(`/api/reports/aged?as_of=${to}&type=${_rptAgedType}`);
      _renderAged(d, to);
    } else if (type === 'cashflow') {
      const d = await apiFetch(`/api/reports/cash-flow?from=${from}&to=${to}`);
      _renderCashFlow(d, from, to);
    } else if (type === 'livestock') {
      const d = await apiFetch(`/api/reports/livestock-trading?from=${from}&to=${to}`);
      _renderLivestockTrading(d, from, to);
    } else if (type === 'gl') {
      const d = await apiFetch(`/api/reports/general-ledger?from=${from}&to=${to}`);
      _renderGL(d, from, to);
    } else if (type === 'budget') {
      if (!_rptBudgetPeriodId) {
        if (!_rptBudgetPeriods) await _loadBudgetPeriods();
        if (!_rptBudgetPeriodId) {
          document.getElementById('rpt-main').innerHTML =
            '<div class="rpt-empty">No budget periods found. Create one in the Budget module first.</div>';
          return;
        }
      }
      const params = new URLSearchParams({period_id: _rptBudgetPeriodId});
      if (_rptDateFrom) params.set('from', _rptDateFrom);
      if (_rptDateTo)   params.set('to',   _rptDateTo);
      const d = await apiFetch(`/api/reports/budget-vs-actual?${params}`);
      _renderBudget(d, _rptDateFrom, _rptDateTo);
    }
  } catch(e) {
    const main2 = document.getElementById('rpt-main');
    if (main2) main2.innerHTML=`<div class="state-error">Failed to load report: ${esc(e.message)}</div>`;
  } finally {
    _rptLoading = false;
    if (btn) { btn.disabled=false; btn.textContent='▶ Run Report'; }
  }
}

// ── PDF download ───────────────────────────────────────────────────────────
function rptDownloadPdf() {
  const from  = _rptDateFrom || _rptFyStart();
  const to    = _rptDateTo   || _rptToday();
  const type  = _rptActiveType;
  const th    = encodeURIComponent(currentTheme);
  let url = '';
  if (type === 'pl')       url = `/api/reports/profit-loss/pdf?from=${from}&to=${to}&basis=${_rptBasis}&theme=${th}`;
  else if (type === 'bs')  url = `/api/reports/balance-sheet/pdf?as_of=${to}&theme=${th}`;
  else if (type === 'tb')  url = `/api/reports/trial-balance/pdf?theme=${th}`;
  else if (type === 'bas') url = `/api/reports/bas/pdf?from=${from}&to=${to}&basis=${_rptBasis}&form=${_rptForm}&theme=${th}`;
  else if (type === 'aged')url = `/api/reports/aged/pdf?as_of=${to}&type=${_rptAgedType}&theme=${th}`;
  else if (type === 'cashflow')  url = `/api/reports/cash-flow/pdf?from=${from}&to=${to}&theme=${th}`;
  else if (type === 'gl')        { toast('General Ledger is CSV only — use Export CSV', 'err'); return; }
  else if (type === 'livestock') { toast('Livestock Trading is CSV only — use Export CSV', 'err'); return; }
  else if (type === 'budget')    { toast('Budget vs Actual is CSV only — use Export CSV', 'err'); return; }
  if (url) window.open(url, '_blank');
}

// ── CSV download ───────────────────────────────────────────────────────────
function rptDownloadCsv() {
  const from  = _rptDateFrom || _rptFyStart();
  const to    = _rptDateTo   || _rptToday();
  const type  = _rptActiveType;
  let url = '';
  if      (type === 'pl')       url = `/api/reports/profit-loss/csv?from=${from}&to=${to}&basis=${_rptBasis}`;
  else if (type === 'bs')       url = `/api/reports/balance-sheet/csv?as_of=${to}`;
  else if (type === 'tb') {
    url = `/api/reports/trial-balance/csv?as_of=${to}`;
    if (_rptTbSoftware) url += `&software=${_rptTbSoftware}`;
  }
  else if (type === 'bas')      url = `/api/reports/bas/csv?from=${from}&to=${to}&basis=${_rptBasis}&form=${_rptForm}`;
  else if (type === 'aged')     url = `/api/reports/aged/csv?as_of=${to}&type=${_rptAgedType}`;
  else if (type === 'cashflow') url = `/api/reports/cash-flow/csv?from=${from}&to=${to}`;
  else if (type === 'gl')       url = `/api/reports/general-ledger/csv?from=${from}&to=${to}`;
  else if (type === 'livestock') url = `/api/reports/livestock-trading/csv?from=${from}&to=${to}`;
  else if (type === 'budget') {
    if (!_rptBudgetPeriodId) { toast('Select a budget period first', 'err'); return; }
    url = `/api/reports/budget-vs-actual/csv?period_id=${_rptBudgetPeriodId}`;
    if (_rptDateFrom) url += `&from=${_rptDateFrom}`;
    if (_rptDateTo)   url += `&to=${_rptDateTo}`;
  }
  if (url) window.open(url, '_blank');
}

// ── Preview header helper ──────────────────────────────────────────────────
function _rptHeader(title, subtitle) {
  return `
    <div class="rpt-toolbar">
      <div class="rpt-title-block">
        <div class="rpt-title">${title}</div>
        <div class="rpt-subtitle">${subtitle}</div>
      </div>
      <button class="btn btn-outline" onclick="rptDownloadPdf()" style="gap:5px">
        ⎙ <span>PDF</span>
      </button>
    </div>`;
}

// ── Profit & Loss ──────────────────────────────────────────────────────────
function _renderPL(d, from, to) {
  const basisLbl = _rptBasis==='cash' ? 'Cash Basis' : 'Accrual Basis';
  let html = _rptHeader('Profit & Loss', `${fmtDate(from)} – ${fmtDate(to)} · ${basisLbl}`);

  function section(label, items, amtKey='amount') {
    if (!items || !items.length) return [0, ''];
    const rows = items.filter(r => Math.abs(parseFloat(r[amtKey])||0) >= 0.005);
    if (!rows.length) return [0, ''];
    const total = rows.reduce((s,r) => s + (parseFloat(r[amtKey])||0), 0);
    let h = `<div class="rpt-section-hdr">${label}</div>
      <div class="rpt-preview"><table class="rpt-table">
      <thead><tr><th>Code</th><th>Account</th><th class="r">Amount</th></tr></thead><tbody>`;
    rows.forEach((r,i) => {
      const a = parseFloat(r[amtKey])||0;
      const aid = r.account_id || '';
      const drillArgs = aid ? `onclick="_showAccountLedger(${aid},'${esc(r.name||'')}',null,'${_rptDateFrom}','${_rptDateTo}')"` : '';
      h += `<tr class="${i%2===1?'alt':''} ${aid?'rpt-dr-row':''}" ${drillArgs}>
        <td class="code">${esc(r.code||'')}</td>
        <td>${esc(r.name||'')}</td>
        <td class="r ${a<0?'rpt-amt-neg':'rpt-amt-pos'}">${fmt(a)}</td></tr>`;
    });
    h += `<tr class="subtotal"><td></td><td>Total ${label}</td><td class="r">${fmt(total)}</td></tr>
      </tbody></table></div>`;
    return [total, h];
  }

  const [totInc, incHtml] = section('Income', d.income);
  const [totCos, cosHtml] = section('Cost of Sales', d.cost_of_sales);
  const [totExp, expHtml] = section('Expenses', d.expense);
  const net = (d.net_profit != null) ? parseFloat(d.net_profit) : (totInc - totCos - totExp);
  const isProfit = net >= 0;

  html += incHtml + cosHtml;
  if (cosHtml) {
    const gross = totInc - totCos;
    html += `<div class="rpt-section-hdr">Gross Profit</div>
      <div class="rpt-preview"><table class="rpt-table"><tbody>
      <tr class="${gross>=0?'profit':'loss'}"><td></td><td>Gross Profit</td><td class="r">${fmt(gross)}</td></tr>
      </tbody></table></div>`;
  }
  html += expHtml;
  html += `<div style="margin-top:14px"><div class="rpt-preview"><table class="rpt-table"><tbody>
    <tr><td style="width:40%"></td><td>Total Income</td><td class="r">${fmt(totInc)}</td></tr>
    <tr class="alt"><td></td><td>Total Expenses</td><td class="r">${fmt(totExp)}</td></tr>
    <tr class="${isProfit?'profit':'loss'} grand">
      <td></td><td>${isProfit?'Net Profit':'Net Loss'}</td><td class="r">${fmt(net)}</td>
    </tr></tbody></table></div></div>`;

  document.getElementById('rpt-main').innerHTML = html;
}

// ── Balance Sheet ──────────────────────────────────────────────────────────
function _renderBS(d, asOf) {
  let html = _rptHeader('Balance Sheet', `As at ${fmtDate(asOf)}`);

  function bsSection(label, items) {
    if (!items || !items.length) return [0, ''];
    const rows = items.filter(r => Math.abs(parseFloat(r.balance)||0) >= 0.005);
    if (!rows.length) return [0, ''];
    const total = rows.reduce((s,r) => s + (parseFloat(r.balance)||0), 0);
    let h = `<div class="rpt-section-hdr">${label}</div>
      <div class="rpt-preview"><table class="rpt-table">
      <thead><tr><th>Code</th><th>Account</th><th class="r">Balance</th></tr></thead><tbody>`;
    rows.forEach((r,i) => {
      const a = parseFloat(r.balance)||0;
      const aid = r.account_id || '';
      const asOf = document.getElementById('rpt-to') ? document.getElementById('rpt-to').value : '';
      const drillArgs = aid ? `onclick="_showAccountLedger(${aid},'${esc(r.name||'')}','${asOf}')"` : '';
      h += `<tr class="${i%2===1?'alt':''} ${aid?'rpt-dr-row':''}" ${drillArgs}>
        <td class="code">${esc(r.code||'')}</td><td>${esc(r.name||'')}</td>
        <td class="r">${fmt(a)}</td></tr>`;
    });
    h += `<tr class="subtotal"><td></td><td>Total ${label}</td><td class="r">${fmt(total)}</td></tr>
      </tbody></table></div>`;
    return [total, h];
  }

  // balance_sheet() returns: {assets, liabilities, equity,
  //   total_assets, total_liabilities, total_equity}
  const [totA,  aHtml]  = bsSection('Assets',      d.assets);
  const [totL,  lHtml]  = bsSection('Liabilities', d.liabilities);
  const [totEq, eqHtml] = bsSection('Equity',      d.equity);

  const totAssets = d.total_assets      != null ? parseFloat(d.total_assets)      : totA;
  const totLiab   = d.total_liabilities != null ? parseFloat(d.total_liabilities) : totL;
  const totEquity = d.total_equity      != null ? parseFloat(d.total_equity)      : totEq;
  const netAssets = totAssets - totLiab;

  html += aHtml + lHtml + eqHtml;
  html += `<div style="margin-top:14px"><div class="rpt-preview"><table class="rpt-table"><tbody>
    <tr><td style="width:60%">Total Assets</td><td class="r">${fmt(totAssets)}</td></tr>
    <tr class="alt"><td>Total Liabilities</td><td class="r">${fmt(totLiab)}</td></tr>
    <tr class="alt"><td>Total Equity</td><td class="r">${fmt(totEquity)}</td></tr>
    <tr class="grand"><td>Net Assets</td><td class="r">${fmt(netAssets)}</td></tr>
    </tbody></table></div></div>`;

  document.getElementById('rpt-main').innerHTML = html;
}

// ── Trial Balance ──────────────────────────────────────────────────────────
function _renderTB(d, asOf) {
  let html = _rptHeader('Trial Balance', `As at ${fmtDate(asOf)}`);
  const rows = Array.isArray(d) ? d : (d.rows || d.accounts || []);
  if (!rows.length) {
    document.getElementById('rpt-main').innerHTML = html +
      '<div class="rpt-empty">No transactions found.</div>'; return;
  }
  let totDr = 0, totCr = 0;
  let tbody = '';
  rows.forEach((r,i) => {
    const bal = parseFloat(r.balance || 0);
    if (Math.abs(bal) < 0.005) return;
    const isDebitNormal = ['Asset','Expense'].includes(r.account_type);
    // Net: positive balance sits on the account's normal side; negative is contra
    let drAmt = 0, crAmt = 0;
    if (isDebitNormal) { if (bal >= 0) drAmt = bal; else crAmt = -bal; }
    else               { if (bal >= 0) crAmt = bal; else drAmt = -bal; }
    totDr += drAmt; totCr += crAmt;
    const aid = r.account_id || '';
    tbody += `<tr class="rpt-dr-row ${i%2===1?'alt':''}" data-account-id="${aid}"
        data-account-name="${esc(r.name||'')}" data-as-of="${asOf||''}"
        title="Click to view account ledger" onclick="_showAccountLedger(${aid},'${esc(r.name||'')}','${asOf||''}')">
      <td class="code">${esc(r.code||'')}</td>
      <td>${esc(r.name||'')}</td>
      <td style="font-size:11px;color:var(--ink3)">${esc(r.account_type||'')}</td>
      <td class="r">${drAmt ? fmt(drAmt) : '—'}</td>
      <td class="r">${crAmt ? fmt(crAmt) : '—'}</td>
    </tr>`;
  });
  html += `<div class="rpt-preview"><div style="overflow-x:auto"><table class="rpt-table">
    <thead><tr><th>Code</th><th>Account</th><th>Type</th><th class="r">Debit</th><th class="r">Credit</th></tr></thead>
    <tbody>${tbody}</tbody>
    <tfoot><tr class="grand">
      <td colspan="3">Totals</td>
      <td class="r">${fmt(totDr)}</td>
      <td class="r">${fmt(totCr)}</td>
    </tr></tfoot>
    </table></div></div>`;

  const balanced = Math.abs(totDr - totCr) < 0.01;
  html += `<div style="margin-top:8px;font-family:'DM Mono',monospace;font-size:11px;
    color:${balanced?'var(--green)':'var(--red)'};text-align:right">
    ${balanced ? '✓ Balanced' : '⚠ Out of balance by ' + fmt(Math.abs(totDr-totCr))}</div>`;

  document.getElementById('rpt-main').innerHTML = html;
}

// ── BAS / IAS ──────────────────────────────────────────────────────────────
function _renderBAS(d, from, to) {
  const formLbl = _rptForm === 'ias' ? 'IAS' : 'BAS';
  let html = _rptHeader(`${formLbl} Summary`, `${fmtDate(from)} – ${fmtDate(to)}`);

  // bas_report() keys: G1_total_sales, 1A_GST_on_sales, G11_total_purchases,
  //   1B_GST_on_purchases, GST_payable, period_from, period_to
  // ias_report() keys: W1_total_wages, W2_payg_withheld, W3_no_abn_withholding,
  //   W4_investment_withholding, W5_total_withheld, T1_tax_instalment, net_payable
  function basSection(title, fields) {
    if (!fields || !fields.length) return '';
    return `<div class="rpt-bas-section">
      <div class="rpt-bas-sec-hdr">${title}</div>
      ${fields.map(([code,lbl,val]) => `
        <div class="rpt-bas-row">
          <span class="rpt-bas-code">${code}</span>
          <span class="rpt-bas-lbl">${lbl}</span>
          <span class="rpt-bas-val">${val != null ? fmt(parseFloat(val)||0) : '—'}</span>
        </div>`).join('')}
    </div>`;
  }

  let sectionsHtml = '', netLabel = '', netVal = 0;

  if (_rptForm === 'ias') {
    // IAS layout
    const w1 = parseFloat(d.W1_total_wages||0);
    const w2 = parseFloat(d.W2_payg_withheld||0);
    const w3 = parseFloat(d.W3_no_abn_withholding||0);
    const w4 = parseFloat(d.W4_investment_withholding||0);
    const w5 = parseFloat(d.W5_total_withheld||0);
    const t1 = parseFloat(d.T1_tax_instalment||0);
    netVal   = parseFloat(d.net_payable||0);
    netLabel = netVal < 0 ? 'Estimated Refund' : 'Net PAYG Payable';
    sectionsHtml = basSection('PAYG Withholding', [
      ['W1', 'Total salary & wages paid',       w1],
      ['W2', 'PAYG withheld from wages',         w2],
      ['W3', 'Withheld — no ABN quoted',         w3],
      ['W4', 'Withheld from investments',        w4],
    ]) + basSection('Totals & Instalments', [
      ['W5', 'Total amount withheld',            w5],
      ['T1', 'Tax instalment',                   t1],
    ]);
  } else {
    // BAS layout
    const g1  = parseFloat(d.G1_total_sales||0);
    const a1  = parseFloat(d['1A_GST_on_sales']||0);
    const g11 = parseFloat(d.G11_total_purchases||0);
    const b1  = parseFloat(d['1B_GST_on_purchases']||0);
    netVal    = parseFloat(d.GST_payable||0);
    netLabel  = netVal < 0 ? 'GST Refund' : 'Net GST Payable';
    sectionsHtml = basSection('GST on Sales', [
      ['G1', 'Total sales (incl. GST)',          g1],
      ['1A', 'GST collected on sales',           a1],
    ]) + basSection('GST on Purchases', [
      ['G11','Total purchases (incl. GST)',       g11],
      ['1B', 'GST credits on purchases',         b1],
    ]);
  }

  html += `<div class="rpt-bas-grid">
    ${sectionsHtml}
    <div class="rpt-bas-net">
      <div>
        <div class="rpt-bas-net-lbl">${netLabel}</div>
        <div style="font-size:11px;color:rgba(255,255,255,0.7);margin-top:2px">
          ${d.period_from||from} – ${d.period_to||to}
        </div>
      </div>
      <div class="rpt-bas-net-val ${netVal<0?'refund':''}">${fmt(Math.abs(netVal))}</div>
    </div>
  </div>`;

  document.getElementById('rpt-main').innerHTML = html;
}

// ── Aged Receivables / Payables ────────────────────────────────────────────
function _renderAged(d, asOf) {
  const label = _rptAgedType==='payables' ? 'Aged Payables' : 'Aged Receivables';
  const displayDate = d.as_at || asOf;
  let html = _rptHeader(label, `As at ${fmtDate(displayDate)}`);

  // aged_receivables/payables returns:
  // { as_at, totals: {current, b0, b1, b2, b3, total}, rows: [{contact_name, current, b0, b1, b2, b3, total}] }
  const rows = d.rows || [];
  const tot  = d.totals || {};

  if (!rows.length) {
    document.getElementById('rpt-main').innerHTML = html +
      `<div class="rpt-empty">No outstanding ${_rptAgedType} found.</div>`;
    return;
  }

  // KPI strip using totals from the response
  html += `<div class="rpt-aged-grid">
    ${[
      ['Current',   tot.current||0, 'var(--green)'],
      ['1–30 Days', tot.b0||0,      'var(--amber)'],
      ['31–60 Days',tot.b1||0,      'var(--amber)'],
      ['61–90 Days',tot.b2||0,      'var(--red)'],
      ['90+ Days',  tot.b3||0,      'var(--red)'],
    ].map(([l,v,c])=>`
      <div class="rpt-aged-kpi">
        <div class="rpt-aged-kpi-lbl">${l}</div>
        <div class="rpt-aged-kpi-val" style="color:${c}">${fmt(parseFloat(v)||0)}</div>
      </div>`).join('')}
  </div>`;

  html += `<div class="rpt-preview"><div style="overflow-x:auto"><table class="rpt-table">
    <thead><tr>
      <th>${_rptAgedType==='payables'?'Supplier':'Customer'}</th>
      <th class="r">Current</th><th class="r">1–30</th><th class="r">31–60</th>
      <th class="r">61–90</th><th class="r">90+</th><th class="r">Total</th>
    </tr></thead><tbody>`;

  rows.forEach((r,i) => {
    const cur  = parseFloat(r.current||0);
    const b0   = parseFloat(r.b0||0);
    const b1   = parseFloat(r.b1||0);
    const b2   = parseFloat(r.b2||0);
    const b3   = parseFloat(r.b3||0);
    const tot2 = parseFloat(r.total||0);
    const isOverdue = b2 > 0 || b3 > 0;
    html += `<tr class="${i%2===1?'alt':''}">
      <td style="${isOverdue?'color:var(--red);font-weight:600':''}">${esc(r.contact_name||'')}</td>
      <td class="r ${cur>0?'rpt-amt-pos':''}">${cur?fmt(cur):'—'}</td>
      <td class="r ${b0>0?'rpt-amt-neg':''}">${b0?fmt(b0):'—'}</td>
      <td class="r ${b1>0?'rpt-amt-neg':''}">${b1?fmt(b1):'—'}</td>
      <td class="r ${b2>0?'rpt-amt-neg':''}">${b2?fmt(b2):'—'}</td>
      <td class="r ${b3>0?'rpt-amt-neg':''}">${b3?fmt(b3):'—'}</td>
      <td class="r" style="font-weight:700">${fmt(tot2)}</td>
    </tr>`;
  });

  html += `<tr class="grand"><td>Total</td>
    <td class="r">${fmt(parseFloat(tot.current||0))}</td>
    <td class="r">${fmt(parseFloat(tot.b0||0))}</td>
    <td class="r">${fmt(parseFloat(tot.b1||0))}</td>
    <td class="r">${fmt(parseFloat(tot.b2||0))}</td>
    <td class="r">${fmt(parseFloat(tot.b3||0))}</td>
    <td class="r">${fmt(parseFloat(tot.total||0))}</td>
  </tr></tbody></table></div></div>`;

  document.getElementById('rpt-main').innerHTML = html;
}

// ── Cash Flow ──────────────────────────────────────────────────────────────
function _renderCashFlow(d, from, to) {
  let html = _rptHeader('Cash Flow Statement', `${fmtDate(from)} – ${fmtDate(to)}`);

  // cash_flow_statement() returns:
  // { operating: {items:[{label,amount}], subtotal},
  //   investing: {items:[...], subtotal},
  //   financing: {items:[...], subtotal},
  //   net_change, opening_cash, closing_cash }

  const openBal  = parseFloat(d.opening_cash||0);
  const closeBal = parseFloat(d.closing_cash||0);
  const netChg   = parseFloat(d.net_change||0);

  // KPI banner
  const netColor = netChg >= 0 ? 'var(--green)' : 'var(--red)';
  html += `<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:16px">
    ${[
      ['Opening Cash',    openBal,  'var(--ink)'],
      ['Closing Cash',    closeBal, closeBal>=0?'var(--green)':'var(--red)'],
      ['Net Change',      netChg,   netColor],
      ['From Operations', parseFloat(d.operating&&d.operating.subtotal||0), 'var(--accent)'],
    ].map(([l,v,c])=>`
      <div style="background:var(--surface);border:1px solid var(--border);border-radius:8px;
        padding:10px 12px;text-align:center">
        <div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--ink3);
          text-transform:uppercase;letter-spacing:.8px;margin-bottom:4px">${l}</div>
        <div style="font-family:'Syne',sans-serif;font-size:16px;font-weight:700;color:${c}">${fmt(v)}</div>
      </div>`).join('')}
  </div>`;

  function cfSection(title, section) {
    if (!section) return '';
    const items    = section.items || [];
    const subtotal = parseFloat(section.subtotal||0);
    let h = `<div class="rpt-section-hdr">${title}</div>
      <div class="rpt-preview"><table class="rpt-table">
      <thead><tr><th>Description</th><th class="r">Amount</th></tr></thead><tbody>`;
    if (!items.length) {
      h += `<tr><td colspan="2" style="color:var(--ink3);font-style:italic;font-size:12px">
        No transactions</td></tr>`;
    } else {
      items.forEach((item,i) => {
        const a = parseFloat(item.amount||0);
        h += `<tr class="${i%2===1?'alt':''}">
          <td>${esc(item.label||item.description||'')}</td>
          <td class="r ${a<0?'rpt-amt-neg':'rpt-amt-pos'}">${fmt(a)}</td></tr>`;
      });
    }
    h += `<tr class="subtotal">
        <td>Net Cash from ${title}</td>
        <td class="r">${fmt(subtotal)}</td>
      </tr></tbody></table></div>`;
    return h;
  }

  html += cfSection('Operating Activities', d.operating);
  html += cfSection('Investing Activities', d.investing);
  html += cfSection('Financing Activities', d.financing);

  html += `<div style="margin-top:14px"><div class="rpt-preview"><table class="rpt-table"><tbody>
    <tr><td style="width:70%">Net Increase / (Decrease) in Cash</td>
      <td class="r ${netChg<0?'rpt-amt-neg':'rpt-amt-pos'}" style="font-weight:700">${fmt(netChg)}</td></tr>
    <tr class="alt"><td>Opening Cash Balance</td><td class="r">${fmt(openBal)}</td></tr>
    <tr class="grand"><td>Closing Cash Balance</td><td class="r">${fmt(closeBal)}</td></tr>
    </tbody></table></div></div>`;

  document.getElementById('rpt-main').innerHTML = html;
}

// ── Budget vs Actual ───────────────────────────────────────────────────────
function _renderBudget(d, from, to) {
  const rows   = d.rows || [];
  const period = d.period;
  const pName  = period ? period.name : 'Budget';
  let html = _rptHeader('Budget vs Actual', esc(pName));

  if (!rows.length) {
    document.getElementById('rpt-main').innerHTML = html +
      '<div class="rpt-empty">No accounts found in this budget period.</div>';
    return;
  }

  const sections = {};
  rows.forEach(r => {
    const t = r.account_type || 'Other';
    if (!sections[t]) sections[t] = [];
    sections[t].push(r);
  });

  Object.entries(sections).forEach(([stype, srows]) => {
    const totBud = srows.reduce((s,r) => s + (r.total_budget||0), 0);
    const totAct = srows.reduce((s,r) => s + (r.total_actual||0), 0);
    const totVar = totAct - totBud;
    html += `<div class="rpt-section-hdr">${esc(stype)}</div>
      <div class="rpt-preview"><div style="overflow-x:auto"><table class="rpt-table">
      <thead><tr>
        <th>Code</th><th>Account</th>
        <th class="r">Budget</th><th class="r">Actual</th>
        <th class="r">Variance</th><th class="r">Var %</th>
      </tr></thead><tbody>`;
    srows.forEach((r, i) => {
      const bud = parseFloat(r.total_budget||0);
      const act = parseFloat(r.total_actual||0);
      const vr  = parseFloat(r.total_variance||0);
      const vp  = parseFloat(r.total_variance_pct||0);
      html += `<tr class="${i%2===1?'alt':''}">
        <td class="code">${esc(r.code||'')}</td>
        <td>${esc(r.name||'')}</td>
        <td class="r">${fmt(bud)}</td>
        <td class="r">${fmt(act)}</td>
        <td class="r ${vr>=0?'rpt-amt-pos':'rpt-amt-neg'}">${fmt(vr)}</td>
        <td class="r" style="font-size:11px;color:var(--ink3)">${vp.toFixed(1)}%</td>
      </tr>`;
    });
    html += `<tr class="subtotal">
      <td></td><td>Totals — ${esc(stype)}</td>
      <td class="r">${fmt(totBud)}</td>
      <td class="r">${fmt(totAct)}</td>
      <td class="r ${totVar>=0?'rpt-amt-pos':'rpt-amt-neg'}">${fmt(totVar)}</td>
      <td></td>
    </tr></tbody></table></div></div>`;
  });

  document.getElementById('rpt-main').innerHTML = html;
}

// ── Account Ledger Drill-Down ───────────────────────────────────────────────
async function _showAccountLedger(accountId, accountName, asOf, dateFrom, dateTo) {
  if (!accountId) return;
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box rpt-ldgr-box">
    <div class="modal-hdr">
      <span>${esc(accountName)} — Ledger</span>
      <button class="modal-close" onclick="this.closest('.modal-bd').remove()">✕</button>
    </div>
    <div class="modal-body rpt-ldgr-body">
      <div style="color:var(--ink3);font-family:'DM Mono',monospace;font-size:12px;padding:20px;text-align:center">
        Loading…
      </div>
    </div>
  </div>`;
  bd.addEventListener('click', e => { if (e.target === bd) bd.remove(); });
  document.body.appendChild(bd);

  try {
    let url = `/api/reports/account-ledger?account_id=${accountId}`;
    if (asOf)     url += `&as_of=${asOf}`;
    if (dateFrom) url += `&from=${dateFrom}`;
    if (dateTo)   url += `&to=${dateTo}`;
    const data = await apiFetch(url);
    _renderAccountLedger(bd.querySelector('.rpt-ldgr-body'), data, dateFrom, dateTo);
  } catch(e) {
    bd.querySelector('.rpt-ldgr-body').innerHTML =
      `<div style="color:var(--red);padding:20px;font-size:12px">${esc(e.message||'Error')}</div>`;
  }
}

function _renderAccountLedger(container, data, dateFrom, dateTo) {
  const acct  = data.account || {};
  const lines = data.lines   || [];
  const ob    = parseFloat(data.opening_balance || 0);
  const isDebitNormal = ['Asset','Expense'].includes(acct.account_type);

  const periodLbl = dateFrom && dateTo
    ? `${fmtDate(dateFrom)} – ${fmtDate(dateTo)}`
    : dateTo ? `up to ${fmtDate(dateTo)}` : 'All transactions';

  let runBal = ob;
  let rows = '';

  rows += `<tr class="rpt-ldgr-ob">
    <td colspan="3" style="color:var(--ink3);font-size:11px">Opening Balance</td>
    <td class="r"></td><td class="r"></td>
    <td class="r rpt-ldgr-bal">${fmt(ob)}</td>
  </tr>`;

  if (!lines.length) {
    rows += `<tr><td colspan="6" style="color:var(--ink3);font-style:italic;text-align:center;padding:16px">
      No transactions in this period.</td></tr>`;
  } else {
    lines.forEach((l, i) => {
      const dr = parseFloat(l.debit  || 0);
      const cr = parseFloat(l.credit || 0);
      if (isDebitNormal) runBal += dr - cr;
      else               runBal += cr - dr;
      const desc = l.line_desc || l.je_desc || '';
      const ref  = l.reference || '';
      const jid  = l.journal_id || '';
      rows += `<tr class="rpt-dr-row ${i%2===1?'alt':''}" title="Click to view full journal entry"
          onclick="_showJournalEntry(${jid})">
        <td class="rpt-ldgr-date">${fmtDate(l.entry_date)}</td>
        <td class="rpt-ldgr-ref">${esc(ref)}</td>
        <td>${esc(desc)}</td>
        <td class="r rpt-ldgr-dr">${dr ? fmt(dr) : '—'}</td>
        <td class="r rpt-ldgr-cr">${cr ? fmt(cr) : '—'}</td>
        <td class="r rpt-ldgr-bal">${fmt(runBal)}</td>
      </tr>`;
    });
  }

  const totDr = lines.reduce((s,l) => s + parseFloat(l.debit||0),  0);
  const totCr = lines.reduce((s,l) => s + parseFloat(l.credit||0), 0);

  const csvParams = new URLSearchParams({account_id: acct.id || ''});
  if (dateFrom) csvParams.set('from', dateFrom);
  if (dateTo)   csvParams.set('to',   dateTo);

  container.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;padding:0 0 10px">
      <span style="font-family:'DM Mono',monospace;font-size:10px;color:var(--ink3)">${esc(acct.code||'')} · ${esc(acct.account_type||'')} · ${periodLbl}</span>
      <span style="display:flex;align-items:center;gap:10px">
        <a href="/api/reports/account-ledger/csv?${csvParams}" target="_blank"
           style="font-family:'DM Mono',monospace;font-size:10px;color:var(--accent);text-decoration:none">⬇ CSV</a>
        <span style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink2)">Closing: <strong>${fmt(runBal)}</strong></span>
      </span>
    </div>
    <div style="overflow-x:auto">
    <table class="rpt-table rpt-ldgr-tbl">
      <thead><tr>
        <th style="width:90px">Date</th>
        <th style="width:90px">Ref</th>
        <th>Description</th>
        <th class="r" style="width:100px">Debit</th>
        <th class="r" style="width:100px">Credit</th>
        <th class="r" style="width:110px">Balance</th>
      </tr></thead>
      <tbody>${rows}</tbody>
      <tfoot><tr class="grand">
        <td colspan="3">Totals</td>
        <td class="r">${fmt(totDr)}</td>
        <td class="r">${fmt(totCr)}</td>
        <td class="r">${fmt(runBal)}</td>
      </tr></tfoot>
    </table></div>`;
}

async function _showJournalEntry(jid) {
  if (!jid) return;
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box rpt-je-box">
    <div class="modal-hdr">
      <span>Journal Entry #${jid}</span>
      <button class="modal-close" onclick="this.closest('.modal-bd').remove()">✕</button>
    </div>
    <div class="modal-body rpt-je-body">
      <div style="color:var(--ink3);font-family:'DM Mono',monospace;font-size:12px;padding:20px;text-align:center">Loading…</div>
    </div>
  </div>`;
  bd.addEventListener('click', e => { if (e.target === bd) bd.remove(); });
  document.body.appendChild(bd);

  const body = bd.querySelector('.rpt-je-body');
  try {
    const [data, atts] = await Promise.all([
      apiFetch(`/api/journal/${jid}`),
      apiFetch(`/api/attachments/journal/${jid}`),
    ]);
    const e = data.entry || {};
    const lines = data.lines || [];

    const isManual = e.entry_type === 'Journal';
    const isVoided = (e.reference||'').startsWith('VOID-') || (e.description||'').startsWith('[VOIDED]');
    const canEdit  = isManual && !isVoided;

    // Action button: edit manual journal via existing jEdit dialog,
    // or navigate to the source module for system entries
    const _srcModule = {Invoice:'invoices',Receipt:'invoices',Bill:'bills',Payment:'bills',Payroll:'payroll'};
    let actionBtn = '';
    if (canEdit) {
      actionBtn = `<button class="rpt-je-act-btn" onclick="_jeGoEdit(${jid})">✏ Edit</button>`;
    } else {
      const mod = _srcModule[e.entry_type];
      const sid = e.source_id;
      if (mod) {
        const label = mod.charAt(0).toUpperCase() + mod.slice(1);
        actionBtn = `<button class="rpt-je-act-btn" onclick="_jeGoSource('${mod}',${sid||'null'})">→ Open in ${label}</button>`;
      }
    }

    const totDr = lines.reduce((s,l) => s + parseFloat(l.debit||0),  0);
    const totCr = lines.reduce((s,l) => s + parseFloat(l.credit||0), 0);
    const balanced = Math.abs(totDr - totCr) < 0.01;

    let lrows = '';
    lines.forEach((l, i) => {
      const dr = parseFloat(l.debit||0), cr = parseFloat(l.credit||0);
      lrows += `<tr class="${i%2===1?'alt':''}">
        <td class="code">${esc(l.code||'')}</td>
        <td>${esc(l.account_name||'')}</td>
        <td style="color:var(--ink3);font-size:11px">${esc(l.description||'')}</td>
        <td class="r rpt-ldgr-dr">${dr ? fmt(dr) : '—'}</td>
        <td class="r rpt-ldgr-cr">${cr ? fmt(cr) : '—'}</td>
      </tr>`;
    });

    body.innerHTML = `
      <div class="rpt-je-meta">
        <div><span class="rpt-je-lbl">Date</span><span>${fmtDate(e.entry_date)}</span></div>
        <div><span class="rpt-je-lbl">Reference</span><span>${esc(e.reference||'—')}</span></div>
        <div><span class="rpt-je-lbl">Type</span><span>${esc(e.entry_type||'')}</span></div>
        <div style="grid-column:1/-1"><span class="rpt-je-lbl">Description</span><span>${esc(e.description||'')}</span></div>
      </div>
      ${actionBtn ? `<div style="margin-top:10px;text-align:right">${actionBtn}</div>` : ''}
      <div style="overflow-x:auto;margin-top:12px">
      <table class="rpt-table">
        <thead><tr>
          <th style="width:70px">Code</th><th>Account</th><th>Description</th>
          <th class="r" style="width:110px">Debit</th>
          <th class="r" style="width:110px">Credit</th>
        </tr></thead>
        <tbody>${lrows}</tbody>
        <tfoot><tr class="grand">
          <td colspan="3">Totals</td>
          <td class="r">${fmt(totDr)}</td>
          <td class="r">${fmt(totCr)}</td>
        </tr></tfoot>
      </table></div>
      <div style="margin-top:8px;font-family:'DM Mono',monospace;font-size:11px;
        color:${balanced?'var(--green)':'var(--red)'};text-align:right">
        ${balanced ? '✓ Balanced' : '⚠ Out of balance by ' + fmt(Math.abs(totDr-totCr))}</div>
      <div id="rpt-je-atts-${jid}" style="margin-top:16px">
        ${_jeRenderAttachments(atts||[], jid)}
      </div>`;
  } catch(err) {
    body.innerHTML =
      `<div style="color:var(--red);padding:20px;font-size:12px">${esc(err.message||'Error')}</div>`;
  }
}

function _jeRenderAttachments(atts, jid) {
  const list = (atts||[]).map((a, i) => {
    const ext  = (a.filename||'').split('.').pop().toLowerCase();
    const icon = ['pdf'].includes(ext) ? '📄'
               : ['jpg','jpeg','png','gif','webp'].includes(ext) ? '🖼' : '📎';
    const kb   = a.file_size ? Math.ceil(a.file_size/1024) + ' KB' : '';
    return `<div class="rpt-je-att">
      <span class="rpt-je-att-icon">${icon}</span>
      <span class="rpt-je-att-name">
        <a href="/api/attachments/${a.id}/download" target="_blank">${esc(a.filename||'')}</a>
        ${a.description ? `<span style="color:var(--ink3);font-size:11px"> — ${esc(a.description)}</span>` : ''}
      </span>
      <span class="rpt-je-att-size">${kb}</span>
      <button class="rpt-je-att-del" onclick="_jeDeleteAttachment(${a.id},${jid})" title="Remove">✕</button>
    </div>`;
  }).join('');

  return `<div class="rpt-je-att-section">
    <div class="rpt-je-att-hdr">
      <span>Attachments${atts.length ? ` (${atts.length})` : ''}</span>
      <label class="rpt-je-att-add">
        + Add<input type="file" style="display:none" onchange="_jeUploadAttachment(this,${jid})">
      </label>
    </div>
    ${list || '<div style="color:var(--ink3);font-size:12px;font-style:italic;padding:8px 12px">No attachments</div>'}
  </div>`;
}

async function _jeUploadAttachment(input, jid) {
  const file = input.files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append('file', file);
  try {
    const r = await fetch(`/api/attachments/journal/${jid}`, {method:'POST', body:fd});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Upload failed');
    const atts = await apiFetch(`/api/attachments/journal/${jid}`);
    const el = document.getElementById(`rpt-je-atts-${jid}`);
    if (el) el.innerHTML = _jeRenderAttachments(atts||[], jid);
  } catch(e) { toast(e.message || 'Upload failed', 'err'); }
}

async function _jeDeleteAttachment(attId, jid) {
  if (!confirm('Remove this attachment?')) return;
  try {
    const r = await fetch(`/api/attachments/${attId}`, {method:'DELETE'});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Delete failed');
    const atts = await apiFetch(`/api/attachments/journal/${jid}`);
    const el = document.getElementById(`rpt-je-atts-${jid}`);
    if (el) el.innerHTML = _jeRenderAttachments(atts||[], jid);
  } catch(e) { toast(e.message || 'Delete failed', 'err'); }
}

function _jeGoEdit(jid) {
  document.querySelectorAll('.modal-bd').forEach(b => b.remove());
  navigate('journal');
  setTimeout(() => typeof jEdit === 'function' && jEdit(jid), 400);
}

function _jeGoSource(mod, sid) {
  document.querySelectorAll('.modal-bd').forEach(b => b.remove());
  navigate(mod);
  if (!sid) return;
  const fn = mod === 'invoices' ? invOpen : mod === 'bills' ? billOpen : null;
  if (fn) setTimeout(() => fn(sid), 500);
}

// ── Livestock Trading Statement ────────────────────────────────────────────
function _renderLivestockTrading(d, from, to) {
  const main = document.getElementById('rpt-main');
  if (!main) return;

  const t = d.totals || {};
  const items = d.items || [];

  function fmtAmt(v) {
    const n = parseFloat(v) || 0;
    return `<span class="${n < 0 ? 'rpt-amt-neg' : ''}">${fmt(n)}</span>`;
  }
  function row(label, value, cls='') {
    return `<tr class="${cls}"><td>${label}</td><td class="r">${fmtAmt(value)}</td></tr>`;
  }
  function spacer() {
    return `<tr><td colspan="2" style="padding:2px 0;border:none"></td></tr>`;
  }

  // Per-item opening stock table
  const itemRowsHtml = items.length ? items.map((it,i) =>
    `<tr class="${i%2===1?'alt':''}">
      <td class="code">${esc(it.code||'')}</td>
      <td>${esc(it.name)}</td>
      <td class="r">${parseFloat(it.opening_qty||0).toFixed(2)}</td>
      <td class="r">${fmtAmt(it.opening_value)}</td>
      <td class="r">${parseFloat(it.closing_qty||0).toFixed(2)}</td>
      <td class="r">${fmtAmt(it.closing_value)}</td>
      <td class="r">${fmtAmt(it.sales_revenue)}</td>
    </tr>`
  ).join('') : `<tr><td colspan="7" class="r" style="color:var(--ink3)">No livestock items found. Mark items as livestock in Inventory → Edit Settings.</td></tr>`;

  let html = _rptHeader('Livestock Trading Statement',
    `${fmtDate(from)} – ${fmtDate(to)}`);

  html += `
  <div class="rpt-preview">
    <div class="rpt-preview-hdr">
      <span class="rpt-preview-title">Livestock Trading Account</span>
      <span style="font-family:'DM Mono',monospace;font-size:10px;color:var(--ink3)">${fmtDate(from)} – ${fmtDate(to)}</span>
    </div>
    <div class="rpt-preview-body">

      <div class="rpt-section-hdr">Per-Item Summary</div>
      <div style="overflow-x:auto">
        <table class="rpt-table" style="min-width:540px">
          <thead><tr>
            <th>Code</th><th>Item</th>
            <th class="r">Opening Qty</th><th class="r">Opening $</th>
            <th class="r">Closing Qty</th><th class="r">Closing $</th>
            <th class="r">Sales Rev.</th>
          </tr></thead>
          <tbody>${itemRowsHtml}</tbody>
        </table>
      </div>

      <div class="rpt-section-hdr" style="margin-top:20px">Trading Account Summary</div>
      <table class="rpt-table" style="max-width:500px">
        <thead><tr><th>Description</th><th class="r">Amount</th></tr></thead>
        <tbody>
          ${row('Opening Stock',     t.opening_stock)}
          ${row('Add: Purchases',    t.purchases)}
          ${row('Add: Natural Increase', t.natural_increase)}
          ${spacer()}
          ${row('Less: Deaths',      -Math.abs(parseFloat(t.deaths)||0))}
          ${row('Less: Private Use', -Math.abs(parseFloat(t.private_use)||0))}
          ${row('Less: Closing Stock', -Math.abs(parseFloat(t.closing_stock)||0))}
          ${spacer()}
          ${row('Cost of Livestock Sold', t.cogs, 'subtotal')}
          ${spacer()}
          ${row('Livestock Sales (Revenue)', t.sales_revenue)}
          ${row('Gross Livestock Income', t.gross_income,
               parseFloat(t.gross_income||0) >= 0 ? 'profit' : 'loss')}
        </tbody>
      </table>

    </div>
  </div>`;

  main.innerHTML = html;
}

// ── EOY Package Wizard ─────────────────────────────────────────────────────
function _rptEoyWizard() {
  // Build FY options: current + last 2
  const today = new Date();
  const fyOptions = [];
  for (let i = 0; i < 3; i++) {
    const endYear  = today.getMonth() >= 6
      ? today.getFullYear() - i
      : today.getFullYear() - 1 - i;
    const startYear = endYear - 1;
    fyOptions.push({
      label: `FY ${startYear}–${String(endYear).slice(2)}`,
      from:  `${startYear}-07-01`,
      to:    `${endYear}-06-30`,
    });
  }

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="max-width:400px;width:100%">
    <div class="modal-hdr">
      <span>📦 EOY Accountant Package</span>
      <button class="modal-close" onclick="this.closest('.modal-bd').remove()">✕</button>
    </div>
    <div class="modal-body" style="padding:18px 20px">
      <div class="modal-field" style="margin-bottom:14px">
        <label class="modal-lbl">Financial Year</label>
        <select class="modal-sel" id="eoy-fy-sel">
          ${fyOptions.map((o,i) => `<option value="${i}">${o.label}</option>`).join('')}
        </select>
      </div>
      <div style="background:var(--row-alt);border-radius:7px;padding:12px 14px;font-size:12px;color:var(--ink2);line-height:1.7">
        <div>✓ Trial Balance CSV (as at FY end)</div>
        <div>✓ General Ledger CSV (full year transactions)</div>
        <div>✓ Fixed Asset Schedule CSV</div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary" onclick="_rptEoyDownload(${JSON.stringify(fyOptions)})">
        ⬇ Download ZIP
      </button>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

function _rptEoyDownload(fyOptions) {
  const sel = document.getElementById('eoy-fy-sel');
  const opt = fyOptions[parseInt(sel.value)];
  const url = `/api/reports/eoy-package?from=${opt.from}&to=${opt.to}&fy=${encodeURIComponent(opt.label.replace('FY ','FY'))}`;
  document.querySelector('.modal-bd')?.remove();
  window.open(url, '_blank');
}

// ── COA Mapping Modal ──────────────────────────────────────────────────────
async function _rptCoaMapping() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="max-width:640px;width:100%">
    <div class="modal-hdr">
      <span>🗺 Chart of Accounts Mapping</span>
      <button class="modal-close" onclick="this.closest('.modal-bd').remove()">✕</button>
    </div>
    <div class="modal-body" style="padding:16px 20px">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
        <label style="font-family:'DM Mono',monospace;font-size:10px;text-transform:uppercase;
          letter-spacing:.8px;color:var(--ink3)">Software</label>
        <select id="coa-software-sel" class="modal-sel" style="max-width:180px"
            onchange="_coaLoadMappings()">
          <option value="myob_tax">MYOB Tax</option>
          <option value="handisoft">Handisoft</option>
        </select>
        <span style="font-size:11px;color:var(--ink3);flex:1">
          Enter the account code used in your accountant's software.
        </span>
      </div>
      <div id="coa-table-wrap" style="max-height:400px;overflow-y:auto;border:1px solid var(--border);border-radius:8px">
        <div style="padding:20px;text-align:center;color:var(--ink3);font-family:'DM Mono',monospace;font-size:12px">Loading…</div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary" onclick="_coaSaveMappings()">Save Mapping</button>
    </div>
  </div>`;
  bd.addEventListener('click', e => { if (e.target === bd) bd.remove(); });
  document.body.appendChild(bd);
  await _coaLoadMappings();
}

async function _coaLoadMappings() {
  const software = document.getElementById('coa-software-sel')?.value || 'myob_tax';
  const wrap = document.getElementById('coa-table-wrap');
  if (!wrap) return;
  wrap.innerHTML = `<div style="padding:20px;text-align:center;color:var(--ink3);
    font-family:'DM Mono',monospace;font-size:12px">Loading…</div>`;
  try {
    const [accounts, mappings] = await Promise.all([
      apiFetch('/api/accounts'),
      apiFetch(`/api/reports/coa-mappings?software=${software}`),
    ]);
    const mapByAccount = {};
    (mappings || []).forEach(m => { mapByAccount[m.account_id] = m.external_code; });

    const activeAccounts = (accounts || []).filter(a => a.is_active !== 0);
    activeAccounts.sort((a,b) => (a.code||'').localeCompare(b.code||''));

    let rows = activeAccounts.map((a, i) => `
      <tr class="${i%2===1?'alt':''}">
        <td class="code" style="padding:6px 10px;font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3)">${esc(a.code||'')}</td>
        <td style="padding:6px 10px;font-size:12px">${esc(a.name||'')}</td>
        <td style="padding:6px 10px;font-size:11px;color:var(--ink3)">${esc(a.account_type||'')}</td>
        <td style="padding:4px 8px">
          <input type="text" class="coa-ext-code" data-account-id="${a.id}"
            value="${esc(mapByAccount[a.id]||'')}"
            placeholder="External code"
            style="width:100%;padding:4px 7px;border:1.5px solid var(--border);border-radius:5px;
              font-family:'DM Mono',monospace;font-size:11px;background:var(--entry-bg);
              color:var(--ink);outline:none">
        </td>
      </tr>`).join('');

    wrap.innerHTML = `<table class="rpt-table" style="width:100%">
      <thead><tr>
        <th style="padding:8px 10px">Code</th>
        <th style="padding:8px 10px">Account</th>
        <th style="padding:8px 10px">Type</th>
        <th style="padding:8px 10px">External Code</th>
      </tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
  } catch(e) {
    wrap.innerHTML = `<div style="padding:20px;color:var(--red);font-size:12px">${esc(e.message||'Error')}</div>`;
  }
}

async function _coaSaveMappings() {
  const software = document.getElementById('coa-software-sel')?.value;
  if (!software) return;
  const inputs = document.querySelectorAll('.coa-ext-code');
  const mappings = [];
  inputs.forEach(inp => {
    mappings.push({
      account_id:    parseInt(inp.dataset.accountId),
      external_code: inp.value.trim(),
    });
  });
  try {
    const r = await fetch('/api/reports/coa-mappings', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({software, mappings}),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    toast('COA mapping saved');
    document.querySelector('.modal-bd')?.remove();
  } catch(e) { toast(e.message || 'Save failed', 'err'); }
}

// ── General Ledger ─────────────────────────────────────────────────────────
function _renderGL(d, from, to) {
  const main = document.getElementById('rpt-main');
  if (!main) return;
  const sections = d.sections || [];
  let html = _rptHeader('General Ledger', `${fmtDate(from)} — ${fmtDate(to)}`);
  if (!sections.length) {
    main.innerHTML = html + '<div class="rpt-empty">No transactions found for this period.</div>';
    return;
  }

  sections.forEach(sec => {
    const a   = sec.account;
    const ob  = parseFloat(sec.opening_balance) || 0;
    const cb  = parseFloat(sec.closing_balance) || 0;
    const lines = sec.lines || [];

    html += `<div class="rpt-preview" style="margin-bottom:18px">
      <div class="rpt-section-hdr" style="display:flex;justify-content:space-between">
        <span>${esc(a.code)} — ${esc(a.name)}</span>
        <span style="font-weight:400;font-size:11px;color:var(--ink3)">${esc(a.account_type)}</span>
      </div>
      <table class="rpt-table">
        <thead><tr>
          <th style="width:90px">Date</th>
          <th style="width:110px">Reference</th>
          <th>Description</th>
          <th class="r" style="width:90px">Debit</th>
          <th class="r" style="width:90px">Credit</th>
          <th class="r" style="width:100px">Balance</th>
        </tr></thead>
        <tbody>
          <tr class="subtotal">
            <td colspan="5">Opening Balance</td>
            <td class="r">${fmt(ob)}</td>
          </tr>`;

    lines.forEach((l, i) => {
      html += `<tr class="${i%2===1?'alt':''}">
        <td style="font-family:'DM Mono',monospace;font-size:11px">${esc(l.date||'')}</td>
        <td style="font-family:'DM Mono',monospace;font-size:11px">${esc(l.reference||'')}</td>
        <td>${esc(l.description||'')}</td>
        <td class="r">${l.debit  ? fmt(l.debit)  : '—'}</td>
        <td class="r">${l.credit ? fmt(l.credit) : '—'}</td>
        <td class="r">${fmt(parseFloat(l.balance)||0)}</td>
      </tr>`;
    });

    html += `</tbody>
        <tfoot><tr class="grand">
          <td colspan="5">Closing Balance</td>
          <td class="r">${fmt(cb)}</td>
        </tr></tfoot>
      </table>
    </div>`;
  });

  main.innerHTML = html;
}

