// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

'use strict';
// ═══════════════════════════════════════════════════════════════════════════
// jobs.js — Jobs module (consolidates former jobs.js + crm.js)
//
// API convention:
//   GET  → apiFetch(url)          returns unwrapped data directly
//   POST/PUT/DELETE/PATCH → raw fetch() with body
//
// Shared helpers from dashboard.html:
//   apiFetch, confirmDlg, esc, fmt, fmtDate, isoToday, isoAddDays,
//   _attachTypeahead, toast, navigate
//   detClose() defined in invoices.js
// ═══════════════════════════════════════════════════════════════════════════

// ── Constants ────────────────────────────────────────────────────────────────
const PIPELINE_STAGES = [
  'Lead','Qualified','Quoted','Accepted','In Progress','On Hold',
  'Complete','Invoiced','Won','Lost',
];
const PIPELINE_ACTIVE = [
  'Lead','Qualified','Quoted','Accepted','In Progress','On Hold','Complete',
];
const JOB_SOURCES = [
  'Referral','Website','Cold Call','Social Media',
  'Exhibition','Repeat Client','Partner','Other',
];

const STAGE_CSS = {
  'Lead':        'crm-stage-lead',
  'Qualified':   'crm-stage-qualified',
  'Quoted':      'crm-stage-quoted',
  'Accepted':    'crm-stage-accepted',
  'In Progress': 'crm-stage-inprogress',
  'On Hold':     'crm-stage-onhold',
  'Complete':    'crm-stage-complete',
  'Invoiced':    'crm-stage-invoiced',
  'Won':         'crm-stage-won',
  'Lost':        'crm-stage-lost',
};

// ── Module state (all _job prefixed) ─────────────────────────────────────────
let _jobAll          = [];
let _jobMeta         = { pipeline_stages:[], comm_types:[], task_types:[], priority:[], quote_status:[] };
let _jobFilter       = 'All';   // stage pill
let _jobStatusFilter = '';      // status dropdown
let _jobSearch       = '';
let _jobSort         = { col: 'id', dir: -1 };
let _jobViewMode     = 'list';  // 'list' | 'board'
let _jobSelectedId   = null;
let _jobActiveTab    = 'overview';
let _jobContacts     = [];
let _jobQuoteLines   = [];
let _jobEditAccts    = null;
let _jobPurchLines   = [];
let _jobExpAccts     = null;
let _jobTimeEmployees= null;
let _jobDetail       = null;    // cached full detail object
let _jobTaskFilter   = 'All';  // 'All' | 'Open' | 'Completed'
let _jobTaskRecurring = false;
let _jobCrmTaskCache = [];
let _jobItems        = null;

async function _jobNewContact(selId, defaultType) {
  const c = await quickNewContact(defaultType);
  if (!c) return;
  if (_jobContacts) _jobContacts.push(c);
  const sel = document.getElementById(selId);
  if (sel) sel.appendChild(new Option(c.name, c.id, true, true));
}

// ── Badge helpers ─────────────────────────────────────────────────────────────
function _jobStageBadge(s) {
  const cls = STAGE_CSS[s] || 'crm-stage-lead';
  return `<span class="crm-stage-badge ${cls}">${esc(s||'—')}</span>`;
}

function _jobStatusBadge(status) {
  const map = {
    'Active':    'job-badge-active',
    'On Hold':   'job-badge-hold',
    'Completed': 'job-badge-completed',
    'Cancelled': 'job-badge-cancelled',
  };
  return `<span class="job-badge ${map[status]||''}">${esc(status||'—')}</span>`;
}

function _jobQuoteBadge(s) {
  const map = { Draft:'qs-draft', Sent:'qs-sent', Accepted:'qs-accepted',
                Declined:'qs-declined', Superseded:'qs-superseded', Invoiced:'qs-invoiced' };
  return `<span class="quote-status-badge ${map[s]||'qs-draft'}">${esc(s||'—')}</span>`;
}

function _jobPriClass(p) {
  return { Urgent:'pri-urgent', High:'pri-high', Normal:'pri-normal', Low:'pri-low' }[p] || 'pri-normal';
}

// ── Entry point ───────────────────────────────────────────────────────────────
window.pageJobs = async function () {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    [_jobMeta, _jobAll, _jobContacts] = await Promise.all([
      apiFetch('/api/crm/meta'),
      apiFetch('/api/jobs'),
      apiFetch('/api/contacts'),
    ]);
    _jobMeta     = _jobMeta     || { pipeline_stages:[], comm_types:[], task_types:[], priority:[], quote_status:[] };
    _jobAll      = _jobAll      || [];
    _jobContacts = _jobContacts || [];
    _jobFilter   = 'All';
    _jobStatusFilter = '';
    _jobSearch   = '';
    _jobSort     = { col: 'id', dir: -1 };
    _jobViewMode = 'list';
    _jobRenderPage(mod);
  } catch(e) {
    mod.innerHTML = `<div class="state-error">Failed to load jobs: ${esc(e.message)}</div>`;
  }
};

// ── Page scaffold ─────────────────────────────────────────────────────────────
function _jobRenderPage(container) {
  // KPI data
  // Open jobs only: finished ones (Complete/Invoiced/Won/Lost) aren't pipeline
  const active = _jobAll.filter(j => PIPELINE_ACTIVE.includes(j.stage) && j.stage !== 'Complete');
  const pipelineValue  = active.reduce((s,j) => s + (j.value||0), 0);
  const weightedValue  = active.reduce((s,j) => s + (j.value||0) * (j.probability||0) / 100, 0);
  const openTasks      = _jobAll.reduce((s,j) => s + (j.open_tasks||0), 0);
  const wonCount       = _jobAll.filter(j => ['Won','Complete','Invoiced'].includes(j.stage)).length;

  const stagePills = ['All', ...PIPELINE_STAGES].map(s => {
    const cnt = s === 'All' ? _jobAll.length : _jobAll.filter(j => j.stage === s).length;
    const active = _jobFilter === s ? ' active' : '';
    return `<button class="filter-btn${active}" onclick="_jobSetStage('${esc(s)}')">${esc(s)}${cnt ? ` <span class="filter-count">(${cnt})</span>` : ''}</button>`;
  }).join('');

  container.innerHTML = `
    <div class="crm-kpi-row">
      <div class="kpi-card"><div class="kpi-accent-bar kpi-accent-bar-accent"></div>
        <div class="kpi-label">Pipeline Value</div>
        <div class="kpi-value col-accent">${fmt(pipelineValue)}</div>
        <div class="kpi-sub">${active.length} active job${active.length !== 1 ? 's' : ''}</div></div>
      <div class="kpi-card"><div class="kpi-accent-bar kpi-accent-bar-green"></div>
        <div class="kpi-label">Weighted Value</div>
        <div class="kpi-value col-green">${fmt(weightedValue)}</div>
        <div class="kpi-sub">probability-adjusted</div></div>
      <div class="kpi-card"><div class="kpi-accent-bar kpi-accent-bar-amber"></div>
        <div class="kpi-label">Open Tasks</div>
        <div class="kpi-value col-amber">${openTasks}</div>
        <div class="kpi-sub">across all jobs</div></div>
      <div class="kpi-card"><div class="kpi-accent-bar kpi-accent-bar-green"></div>
        <div class="kpi-label">Won</div>
        <div class="kpi-value col-green">${wonCount}</div>
        <div class="kpi-sub">won, completed or invoiced</div></div>
    </div>

    <div class="inv-toolbar">
      <input class="inv-search" id="job-search-inp" placeholder="Search jobs…"
             oninput="_jobSearch=this.value;_jobRenderView()">
      <div class="inv-filter-group inv-filter-group-wrap" id="job-stage-pills">
        ${stagePills}
      </div>
      <div style="display:flex;gap:6px;align-items:center;margin-left:4px">
        <button class="btn btn-outline btn-sm${_jobViewMode==='list'?' is-active':''}"
                id="job-view-list" title="List view" onclick="_jobSetView('list')">≡ List</button>
        <button class="btn btn-outline btn-sm${_jobViewMode==='board'?' is-active':''}"
                id="job-view-board" title="Board view" onclick="_jobSetView('board')">⬛ Board</button>
      </div>
      <button class="btn btn-primary ml-auto" onclick="_jobNew()">+ New Job</button>
    </div>

    <div id="job-view-container"></div>
    <div class="count-pill" id="job-count"></div>`;

  _jobRenderView();
}

// ── Filter / sort helpers ─────────────────────────────────────────────────────
function _jobFiltered() {
  const q = (_jobSearch || '').toLowerCase();
  return _jobAll.filter(j => {
    if (_jobFilter !== 'All' && j.stage !== _jobFilter) return false;
    if (q && ![ j.job_number, j.name, j.contact_name, j.manager, j.owner, j.opp_number ]
               .some(v => (v||'').toLowerCase().includes(q))) return false;
    return true;
  }).sort((a, b) => {
    const { col, dir } = _jobSort;
    const av = a[col] ?? '', bv = b[col] ?? '';
    const cmp = (col === 'value' || col === 'budget_amount')
      ? (parseFloat(av||0) - parseFloat(bv||0))
      : String(av).localeCompare(String(bv));
    return cmp * dir;
  });
}

window._jobSetStage = function(stage) {
  _jobFilter = stage;
  // Update pills
  document.querySelectorAll('#job-stage-pills .filter-btn').forEach(b => {
    b.classList.toggle('active', b.textContent.trim().startsWith(stage));
  });
  _jobRenderView();
};

window._jobSetView = function(mode) {
  _jobViewMode = mode;
  document.getElementById('job-view-list')?.classList.toggle('is-active', mode === 'list');
  document.getElementById('job-view-board')?.classList.toggle('is-active', mode === 'board');
  _jobRenderView();
};

function _jobRenderView() {
  if (_jobViewMode === 'board') {
    _jobRenderBoard();
  } else {
    _jobRenderList();
  }
}

// ── List view ─────────────────────────────────────────────────────────────────
function _jobRenderList() {
  const rows = _jobFiltered();
  const cnt = document.getElementById('job-count');
  if (cnt) cnt.textContent = `${rows.length} of ${_jobAll.length} jobs`;

  const container = document.getElementById('job-view-container');
  if (!container) return;

  const thSort = (col, label) => {
    const active = _jobSort.col === col;
    const dir = active ? (_jobSort.dir > 0 ? 'sort-asc' : 'sort-desc') : '';
    return `<th class="${dir}" onclick="_jobSortBy('${col}')">${label}</th>`;
  };

  if (!rows.length) {
    container.innerHTML = `
      <div class="inv-list-panel">
        <div class="job-list-empty">
          <div class="job-list-empty-icon">🏗</div>
          No jobs found. <button class="btn btn-outline ml-8" onclick="_jobNew()">+ New Job</button>
        </div>
      </div>`;
    return;
  }

  container.innerHTML = `
    <div class="inv-list-panel">
      <div class="tbl-overflow-x">
        <table class="inv-list-table" id="job-list-table">
          <thead><tr>
            ${thSort('job_number','#')}
            ${thSort('name','Job Name')}
            ${thSort('contact_name','Contact')}
            ${thSort('stage','Stage')}
            ${thSort('value','Value')}
            ${thSort('owner','Owner')}
            ${thSort('target_close','Target Close')}
          </tr></thead>
          <tbody>
            ${rows.map(j => `
              <tr class="inv-row${_jobSelectedId === j.id ? ' is-selected' : ''}" onclick="_jobOpen(${j.id})">
                <td class="inv-mono">${esc(j.job_number||'')}</td>
                <td class="inv-contact">${esc(j.name||'')}</td>
                <td>${esc(j.contact_name||'—')}</td>
                <td>${_jobStageBadge(j.stage)}</td>
                <td class="inv-amt">${j.value != null ? fmt(j.value) : '—'}</td>
                <td>${esc(j.owner||'—')}</td>
                <td class="inv-mono">${fmtDate(j.target_close)||'—'}</td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>`;
}

window._jobSortBy = function(col) {
  _jobSort = { col, dir: _jobSort.col === col ? _jobSort.dir * -1 : 1 };
  _jobRenderView();
};

// ── Kanban board view ─────────────────────────────────────────────────────────
function _jobRenderBoard() {
  const rows = _jobFiltered();
  const cnt = document.getElementById('job-count');
  if (cnt) cnt.textContent = `${rows.length} of ${_jobAll.length} jobs`;

  const container = document.getElementById('job-view-container');
  if (!container) return;

  const cols = PIPELINE_STAGES.map(stage => {
    const stageJobs = rows.filter(j => j.stage === stage);
    const cards = stageJobs.map(j => `
      <div class="job-board-card" draggable="true"
           ondragstart="_jobDragStart(event,${j.id})"
           onclick="_jobOpen(${j.id})">
        <div class="job-board-card-num inv-mono">${esc(j.job_number||'')}</div>
        <div class="job-board-card-name">${esc(j.name||'')}</div>
        ${j.contact_name ? `<div class="job-board-card-contact">${esc(j.contact_name)}</div>` : ''}
        ${j.value != null ? `<div class="job-board-card-val">${fmt(j.value)}</div>` : ''}
      </div>`).join('');
    return `
      <div class="job-board-col"
           ondragover="event.preventDefault()"
           ondrop="_jobDrop(event,'${stage}')">
        <div class="job-board-col-hdr">
          <span>${_jobStageBadge(stage)}</span>
          <span class="job-board-col-count">${stageJobs.length}</span>
        </div>
        <div class="job-board-col-body">${cards||'<div class="job-board-empty">—</div>'}</div>
      </div>`;
  }).join('');

  container.innerHTML = `<div class="job-board">${cols}</div>`;
}

let _jobDragId = null;
window._jobDragStart = function(e, id) {
  _jobDragId = id;
  e.dataTransfer.effectAllowed = 'move';
};
window._jobDrop = async function(e, stage) {
  e.preventDefault();
  if (!_jobDragId) return;
  const id = _jobDragId;
  _jobDragId = null;
  try {
    const r = await fetch(`/api/jobs/${id}/stage`, {
      method: 'PATCH', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stage }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed');
    toast(`Moved to ${stage}`);
    _jobAll = await apiFetch('/api/jobs') || _jobAll;
    _jobRenderView();
    // If the moved job is open in the panel, refresh it
    if (_jobSelectedId === id) await _jobOpen(id);
  } catch(e) { toast(e.message, 'err'); }
};

// ═══════════════════════════════════════════════════════════════════════════
// DETAIL PANEL
// ═══════════════════════════════════════════════════════════════════════════

function _jobPanelOpen() {
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
}

window._jobOpen = async function(id) {
  _jobSelectedId = id;
  _jobPanelOpen();
  document.getElementById('det-title').textContent = 'Job';
  document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading…</div>';
  document.getElementById('det-foot').innerHTML = '';
  try {
    const [det, time] = await Promise.all([
      apiFetch(`/api/jobs/${id}`),
      apiFetch(`/api/jobs/${id}/time`),
    ]);
    _jobDetail = { ...det, time: time || [] };
    _jobRenderDetail();
  } catch(e) {
    document.getElementById('det-body').innerHTML =
      `<div class="state-error">Failed to load: ${esc(e.message)}</div>`;
  }
};

function _jobRenderDetail() {
  if (!_jobDetail) return;
  const { job, pl, transactions, comms, crm_tasks, work_tasks, quotes, claims, pos, bills, time, bom, visits } = _jobDetail;
  const txns      = transactions  || [];
  const allComms  = comms         || [];
  const crmTasks  = crm_tasks     || [];
  const wrkTasks  = work_tasks    || [];
  const allQuotes = quotes        || [];
  const allClaims = claims        || [];
  const allPos    = pos           || [];
  const allBills  = bills         || [];
  const timeEntries = time        || [];
  const allBom    = bom           || [];
  const allVisits = visits        || [];

  document.getElementById('det-title').textContent = `${job.job_number} — ${job.name}`;

  // Tab counts
  const openTaskCount = wrkTasks.filter(t=>!t.is_done).length + crmTasks.filter(t=>!t.is_done).length;
  const allTaskCount  = wrkTasks.length + crmTasks.length;
  const purchCount    = allPos.length + allBills.length;
  const bomPending    = allBom.filter(l => !l.is_customer_supplied && !l.po_id && !l.is_on_hand).length;

  const tabs = [
    { id:'overview',    label:'Overview' },
    { id:'comms',       label:`Comms${allComms.length ? ` (${allComms.length})` : ''}` },
    { id:'tasks',       label:`Tasks${allTaskCount ? ` (${openTaskCount} open)` : ''}` },
    { id:'visits',      label:`Visits${allVisits.length ? ` (${allVisits.length})` : ''}` },
    { id:'quotes',      label:`Quotes${allQuotes.length ? ` (${allQuotes.length})` : ''}` },
    { id:'claims',      label:`Claims${allClaims.length ? ` (${allClaims.length})` : ''}` },
    { id:'materials',   label:`Materials${allBom.length ? ` (${allBom.length}${bomPending ? ` — ${bomPending} pending` : ''})` : ''}` },
    { id:'purchasing',  label:`Purchasing${purchCount ? ` (${purchCount})` : ''}` },
    { id:'financials',  label:'Financials' },
    { id:'time',        label:'Time' },
  ];

  const tabBar = `
    <div class="det-tabs" id="job-tabs">
      ${tabs.map(t => `<div class="det-tab${_jobActiveTab===t.id?' active':''}"
         onclick="_jobTab('${t.id}')">${t.label}</div>`).join('')}
    </div>
    <div id="job-tab-content"></div>`;

  document.getElementById('det-body').innerHTML = tabBar;
  // The tabs bar sticks to the top of the panel; a tab's own sticky toolbar
  // (e.g. Tasks) sits just under it, so it needs the bar's real height.
  const _tabsEl = document.getElementById('job-tabs');
  if (_tabsEl) document.getElementById('det-body').style.setProperty('--job-tabs-h', _tabsEl.offsetHeight + 'px');

  // Footer
  const acceptedQuote = allQuotes.find(q => q.status === 'Accepted' && !q.invoice_id);
  const blk = _jobDetail.recharge_blocked || { bill: [], po: [] };
  const hasBillableExpenses = allBills.filter(b=>!['Void','Voided'].includes(b.status) && !blk.bill.includes(b.id)).length
                            + allPos.filter(p=>!['Cancelled','Billed'].includes(p.status) && !blk.po.includes(p.id)).length;
  document.getElementById('det-foot').innerHTML = `
    ${acceptedQuote
      ? `<button class="btn btn-primary" onclick="_jobConvertQuote(${acceptedQuote.id})">→ Convert to Invoice</button>`
      : ''}
    ${hasBillableExpenses
      ? `<button class="btn btn-primary" onclick="_jobInvoiceExpenses(${job.id})">→ Invoice Expenses</button>`
      : ''}
    <button class="btn btn-outline" onclick="_jobEditForm()">✏ Edit</button>
    <button class="btn btn-outline" onclick="_jobQuickStage(${job.id},'${esc(job.stage||'Lead')}')">Stage →</button>
    <button class="btn btn-outline" onclick="_jobCardPdf(${job.id})">Job Card</button>
    <span id="job-more-slot"></span>
    <button class="btn btn-outline ml-auto" onclick="detClose()">Close</button>`;
  document.getElementById('job-more-slot').replaceWith(moreMenuBtn([
    {label:'Worksheet', fn:()=>window.open(`/api/jobs/${job.id}/worksheet`,'_blank')},
    {label:'Copy Job', fn:_jobCopyDlg},
    {label:'New Job', fn:_jobNew},
    '-',
    {label:'Delete Job', fn:()=>_jobDelete(job.id), danger:true},
  ]));

  _jobTab(_jobActiveTab);
}

window._jobTab = function(tab) {
  _jobActiveTab = tab;
  document.querySelectorAll('#job-tabs .det-tab').forEach(el => {
    const tabStarts = { overview:'Overview', comms:'Comms', tasks:'Tasks', visits:'Visits',
                        quotes:'Quotes', claims:'Claims', materials:'Materials',
                        purchasing:'Purchasing', financials:'Financials', time:'Time' };
    el.classList.toggle('active', el.textContent.trim().startsWith(tabStarts[tab]||''));
  });
  const el = document.getElementById('job-tab-content');
  if (!el || !_jobDetail) return;

  const { job, pl, transactions, comms, crm_tasks, work_tasks, quotes, claims, pos, bills, time, bom, visits } = _jobDetail;
  const txns      = transactions  || [];
  const allComms  = comms         || [];
  const crmTasks  = crm_tasks     || [];
  const wrkTasks  = work_tasks    || [];
  const allQuotes = quotes        || [];
  const allClaims = claims        || [];
  const allPos    = pos           || [];
  const allBills  = bills         || [];
  const timeEntries = time        || [];
  const allBom    = bom           || [];
  const allVisits = visits        || [];

  if (tab === 'overview')      { el.innerHTML = _jobTabOverview(job, pl); }
  else if (tab === 'comms')    { _jobTabComms(el, allComms, job.id); }
  else if (tab === 'tasks')    { _jobTabTasks(el, wrkTasks, job.id); }
  else if (tab === 'visits')   { _jobTabVisits(el, allVisits, job); }
  else if (tab === 'quotes')   { _jobTabQuotes(el, allQuotes, job); }
  else if (tab === 'claims')   { _jobTabClaims(el, allClaims, wrkTasks, job, pl, txns); }
  else if (tab === 'materials'){ _jobTabMaterials(el, allBom, allPos, job); }
  else if (tab === 'purchasing'){ _jobTabPurchasing(el, allPos, allBills, job); }
  else if (tab === 'financials'){ _jobTabFinancials(el, pl, txns, job); }
  else if (tab === 'time')     { _jobTabTime(el, timeEntries, pl, job.id); }
};

// ── Overview tab ──────────────────────────────────────────────────────────────
// Top: who/where, the money (quoted, invoiced, costs, profit), the next visit, open tasks
// and quick actions. Below: the job's details as before.
function _jobOverviewSummary(job, pl) {
  const d = _jobDetail || {};
  const live = (d.quotes || []).filter(q => !['Declined', 'Superseded'].includes(q.status));
  const accepted = live.filter(q => q.status === 'Accepted');
  const quoted = (accepted.length ? accepted : live.slice(0, 1)).reduce((s, q) => s + (q.subtotal || 0), 0);
  const quotedSub = accepted.length ? 'accepted, ex GST' : live.length ? 'not yet accepted, ex GST' : 'no quote yet';
  const invoiced = pl?.revenue || 0, costs = pl?.total_costs || 0;
  const profit = pl?.gross_profit ?? (invoiced - costs);
  const toInvoice = accepted.length ? Math.max(0, quoted - invoiced) : 0;

  const today = isoToday();
  const key = v => (v.event_date || '') + ' ' + (v.start_time || '');
  const next = (d.visits || []).filter(v => (v.event_date || '') >= today).sort((a, b) => key(a).localeCompare(key(b)))[0];
  const tasks = [...(d.work_tasks || []), ...(d.crm_tasks || [])].filter(t => !t.is_done);

  const tel = job.contact_phone ? `<a class="lnk-accent" href="tel:${esc(job.contact_phone.replace(/\s/g, ''))}">${esc(job.contact_phone)}</a>` : '';
  const mail = job.contact_email ? `<a class="lnk-accent" href="mailto:${esc(job.contact_email)}">${esc(job.contact_email)}</a>` : '';
  const site = (job.site_address || '').trim();
  const map = site ? ` <a class="lnk-accent lnk-sm" href="#" data-site="${esc(site)}" onclick="event.preventDefault();window.open('https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(this.dataset.site),'_blank')">Map</a>` : '';
  const stat = (lbl, val, sub, cls = '') =>
    `<div class="job-ov-stat"><div class="det-lbl">${lbl}</div><div class="job-ov-val ${cls}">${val}</div>${sub ? `<div class="job-ov-sub">${sub}</div>` : ''}</div>`;

  return `
    <div class="job-ov">
      <div class="job-ov-who">
        <div><div class="det-lbl">Client</div>
          <div class="det-val">${esc(job.contact_name || '—')}</div>
          <div class="job-ov-sub">${[tel, mail].filter(Boolean).join(' · ')}</div></div>
        <div><div class="det-lbl">Site</div>
          <div class="det-val job-ov-site">${site ? esc(site) + map : '<span class="col-ink3">Same as client / not set</span>'}</div></div>
        <div><div class="det-lbl">Stage</div><div>${_jobStageBadge(job.stage)}</div></div>
      </div>
      <div class="job-ov-money">
        ${stat('Quoted', fmt(quoted), quotedSub)}
        ${stat('Invoiced', fmt(invoiced), toInvoice > 0.005 ? `${fmt(toInvoice)} still to invoice` : 'ex GST')}
        ${stat('Costs', fmt(costs), 'materials, labour, other')}
        ${stat('Profit', fmt(profit), invoiced ? `${(profit / invoiced * 100).toFixed(0)}% margin` : '', profit < 0 ? 'col-red' : 'col-green')}
      </div>
      <div class="job-ov-cols">
        <div class="job-ov-box">
          <div class="det-lbl">Next visit</div>
          ${next ? `<div class="det-val">${fmtDate(next.event_date)}${next.start_time ? ` · ${esc(next.start_time)}${next.end_time ? '–' + esc(next.end_time) : ''}` : ''}</div>
                   <div class="job-ov-sub">${esc(next.title || '')}</div>`
                 : `<div class="job-ov-sub">No visit booked</div>`}
        </div>
        <div class="job-ov-box">
          <div class="det-lbl">Open tasks (${tasks.length})</div>
          ${tasks.length ? tasks.slice(0, 3).map(t => `<div class="job-ov-sub">• ${esc(t.title || t.description || '')}</div>`).join('')
                          + (tasks.length > 3 ? `<div class="job-ov-sub"><a href="#" class="lnk-accent" onclick="event.preventDefault();_jobTab('tasks')">and ${tasks.length - 3} more</a></div>` : '')
                         : `<div class="job-ov-sub">None</div>`}
        </div>
      </div>
      <div class="job-ov-actions">
        <button class="btn btn-outline btn-sm" onclick="_jobVisitForm(${job.id},null)">+ Visit</button>
        <button class="btn btn-outline btn-sm" onclick="_jobNewQuote(${job.id},${job.contact_id || 'null'})">+ Quote</button>
        <button class="btn btn-outline btn-sm" onclick="invNew({contact_id:${job.contact_id || 'null'},job_id:${job.id}})">+ Invoice</button>
        <button class="btn btn-outline btn-sm" onclick="_jobAddTask(${job.id})">+ Task</button>
      </div>
    </div>`;
}

function _jobTabOverview(job, pl) {
  return _jobOverviewSummary(job, pl) + `
    <div class="det-lbl job-ov-details-hdr">Details</div>
    <div class="det-meta">
      <div><div class="det-lbl">Job Number</div>
        <div class="job-mono-bold">${esc(job.job_number||'')}</div></div>
      <div><div class="det-lbl">Status</div>
        <div>${_jobStatusBadge(job.status)}</div></div>
      <div><div class="det-lbl">Contact</div>
        <div class="det-val">${esc(job.contact_name||'—')}</div></div>
      <div><div class="det-lbl">Manager</div>
        <div class="det-val">${esc(job.manager||'—')}</div></div>
      <div><div class="det-lbl">Start Date</div>
        <div class="inv-mono">${fmtDate(job.start_date)||'—'}</div></div>
      <div><div class="det-lbl">End Date</div>
        <div class="inv-mono">${fmtDate(job.end_date)||'Ongoing'}</div></div>
      ${job.budget_amount ? `
      <div><div class="det-lbl">Budget</div>
        <div class="job-mono-bold">${fmt(job.budget_amount)}</div></div>` : ''}
      ${job.budget_notes ? `
      <div><div class="det-lbl">Budget Notes</div>
        <div class="job-txt-sm">${esc(job.budget_notes)}</div></div>` : ''}
      ${job.hourly_rate != null ? `
      <div><div class="det-lbl">Hourly Rate</div>
        <div class="job-mono-bold">${fmt(job.hourly_rate)}/hr</div></div>` : ''}
      <div><div class="det-lbl">Stage</div>
        <div>${_jobStageBadge(job.stage)}</div></div>
      ${job.source ? `
      <div><div class="det-lbl">Source</div>
        <div class="det-val">${esc(job.source)}</div></div>` : ''}
      ${job.value != null ? `
      <div><div class="det-lbl">Est. Value</div>
        <div class="job-mono-bold">${fmt(job.value)}</div></div>` : ''}
      ${job.probability != null ? `
      <div><div class="det-lbl">Probability</div>
        <div class="inv-mono">${job.probability}%</div></div>` : ''}
      ${job.owner ? `
      <div><div class="det-lbl">Owner</div>
        <div class="det-val">${esc(job.owner)}</div></div>` : ''}
      ${job.target_close ? `
      <div><div class="det-lbl">Target Close</div>
        <div class="inv-mono">${fmtDate(job.target_close)}</div></div>` : ''}
      ${job.opp_number ? `
      <div><div class="det-lbl">Opp Number</div>
        <div class="inv-mono">${esc(job.opp_number)}</div></div>` : ''}
      ${job.description ? `
      <div class="det-span2"><div class="det-lbl">Description</div>
        <div class="det-val det-val-sm">${esc(job.description)}</div></div>` : ''}
      ${job.notes ? `
      <div class="det-span2"><div class="det-lbl">Notes</div>
        <div class="det-note">${esc(job.notes)}</div></div>` : ''}
    </div>`;
}

// ── Comms tab ─────────────────────────────────────────────────────────────────
function _jobTabComms(el, comms, jobId) {
  const rows = comms.map(c => `
    <div class="comm-row">
      <div class="comm-meta">
        <span class="comm-type-badge">${esc(c.comm_type)}</span>
        <span class="comm-date">${fmtDate(c.comm_date)}</span>
        ${c.subject ? `<span class="comm-subj-inline">${esc(c.subject)}</span>` : ''}
        <button onclick="_jobDelComm(${c.id},${jobId})" class="btn-icon-del" title="Delete">✕</button>
      </div>
      ${c.body    ? `<div class="comm-body">${esc(c.body)}</div>` : ''}
      ${c.outcome ? `<div class="comm-outcome">→ ${esc(c.outcome)}</div>` : ''}
      ${c.next_action ? `<div class="comm-next">Next: ${esc(c.next_action)}${c.next_action_date?' — '+fmtDate(c.next_action_date):''}</div>` : ''}
    </div>`).join('');

  el.innerHTML = `
    <div class="tab-add-row job-sticky-toolbar">
      <button class="btn btn-outline btn-sm-outline" onclick="_jobLogComm(${jobId})">+ Log Communication</button>
    </div>
    ${rows || '<div class="det-empty">No communications logged yet.</div>'}`;
}

window._jobLogComm = function(jobId) {
  const types = _jobMeta.comm_types || ['Call','Email','Meeting','Note'];
  document.getElementById('det-body').innerHTML = `
    <div class="det-tabs" id="job-tabs" style="display:none"></div>
    <div id="job-tab-content">
    <h3 class="form-section-hdr">Log Communication</h3>
    <div class="edt-grid">
      <div class="edt-field"><label class="edt-lbl">Type *</label>
        <select class="edt-sel" id="cf-type">${types.map(t=>`<option>${t}</option>`).join('')}</select></div>
      <div class="edt-field"><label class="edt-lbl">Date *</label>
        <input class="edt-inp" id="cf-date" type="date" value="${isoToday()}"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Subject</label>
        <input class="edt-inp" id="cf-subj" placeholder="Brief subject"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Notes / Body</label>
        <textarea class="edt-ta edt-ta-tall" id="cf-body" placeholder="Call notes, email summary…"></textarea></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Outcome</label>
        <input class="edt-inp" id="cf-outcome" placeholder="Result of this interaction"></div>
      <div class="edt-field"><label class="edt-lbl">Next Action</label>
        <input class="edt-inp" id="cf-next" placeholder="What to do next"></div>
      <div class="edt-field"><label class="edt-lbl">Next Action Date</label>
        <input class="edt-inp" id="cf-nextdate" type="date"></div>
    </div></div>`;
  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-primary" id="cf-save-btn" onclick="_jobSaveComm(${jobId})">Save</button>
    <button class="btn btn-outline" onclick="_jobRenderDetail()">Cancel</button>`;
  document.getElementById('cf-subj')?.focus();
};

window._jobSaveComm = async function(jobId) {
  const date = document.getElementById('cf-date')?.value;
  if (!date) { toast('Date is required', 'err'); return; }
  const btn = document.getElementById('cf-save-btn');
  btn.disabled = true; btn.textContent = 'Saving…';
  try {
    const r = await fetch('/api/crm/communications', {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        job_id:           jobId,
        comm_date:        date,
        comm_type:        document.getElementById('cf-type')?.value || 'Note',
        subject:          document.getElementById('cf-subj')?.value.trim() || '',
        body:             document.getElementById('cf-body')?.value.trim() || '',
        outcome:          document.getElementById('cf-outcome')?.value.trim() || '',
        next_action:      document.getElementById('cf-next')?.value.trim() || '',
        next_action_date: document.getElementById('cf-nextdate')?.value || null,
      }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    toast('Communication logged');
    await _jobRefreshDetail(jobId, 'comms');
  } catch(e) { toast(e.message, 'err'); btn.disabled = false; btn.textContent = 'Save'; }
};

window._jobDelComm = async function(cid, jobId) {
  if (!await confirmDlg('Delete this communication log entry?')) return;
  try {
    const r = await fetch(`/api/crm/communications/${cid}`, { method:'DELETE', credentials:'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Delete failed');
    toast('Deleted');
    await _jobRefreshDetail(jobId, 'comms');
  } catch(e) { toast(e.message, 'err'); }
};

// ── Tasks tab ─────────────────────────────────────────────────────────────────
// Hourly tasks have no price of their own (billed via visit hours × the
// job's hourly rate). Fixed tasks can be part-billed on progress claims.
function _jobTaskBillBadge(t) {
  if (t.billing === 'hourly') return '<span class="task-billable-badge task-hourly-badge">Hourly</span>';
  if (t.qty_invoiced > 0 && !t.invoice_id)
    return `<span class="task-billable-badge">${+t.qty_invoiced} of ${+t.qty} billed</span>`;
  if (!t.is_done) return `<span class="task-billable-badge">${fmt(t.unit_price||0)} × ${t.qty||1}</span>`;
  return '';
}

// Unbilled amount on a fixed task (all of it, or what's left after part-claims)
function _jobTaskRemaining(t) {
  const contract = Math.round((t.qty||1) * (t.unit_price||0) * 100) / 100;
  return Math.round((contract - (t.amount_billed||0)) * 100) / 100;
}

window._jobTaskBillingToggle = function(prefix) {
  const hourly = document.getElementById(`${prefix}-billing`)?.value === 'hourly';
  const row = document.getElementById(`${prefix}-price-row`);
  if (row) row.style.display = hourly ? 'none' : 'grid';
};

function _jobTaskBillingField(prefix, t) {
  const locked = t && t.qty_invoiced > 0;
  const cur = t?.billing || 'fixed';
  return `<div class="modal-field"><label class="modal-lbl">Billing</label>
      <select class="modal-inp" id="${prefix}-billing" onchange="_jobTaskBillingToggle('${prefix}')"${locked ? ' disabled' : ''}>
        <option value="fixed"${cur==='fixed'?' selected':''}>Fixed price (qty × unit price)</option>
        <option value="hourly"${cur==='hourly'?' selected':''}>Hourly (time logged × job's hourly rate)</option>
      </select>
      ${locked ? `<div class="job-time-hint">${+t.qty_invoiced} of ${+t.qty} already billed — price and billing type are locked</div>` : ''}
    </div>`;
}

// "14 of 24 · 23 Sep, 26 Sep" — progress recorded on visits (core/visit_tasks.py)
function _jobTaskVisitLine(t) {
  const tv = (_jobDetail?.task_visits || {})[t.id];
  if (!tv || !tv.visits.length) return '';
  const days = tv.visits.map(v => {
    const d = new Date(v.event_date + 'T00:00:00');
    return d.toLocaleString('en-AU', { day: 'numeric', month: 'short' });
  }).join(', ');
  const prog = t.billing !== 'hourly' && (+t.qty) > 1 ? `${+tv.progress} of ${+t.qty} · ` : '';
  if (t.billing === 'hourly') {
    const ids = new Set(tv.visits.map(v => v.visit_id));
    const hrs = (_jobDetail?.visits || []).filter(v => ids.has(v.id)).reduce((s, v) => s + (+v.hours || 0), 0);
    if (hrs) return `<div class="task-dates jvt-task-visits">Time: ${Math.round(hrs * 100) / 100} hrs · ${days}</div>`;
  }
  return `<div class="task-dates jvt-task-visits">Visits: ${prog}${days}</div>`;
}

function _jobTaskRow(t, jobId) {
  const today = isoToday();
  const addedDate = t.created_at ? fmtDate(t.created_at.split(' ')[0]) : '';
  const doneDate  = t.done_at   ? fmtDate(t.done_at.split(' ')[0])    : '';
  const wtDue = t.due_date && !t.is_done
    ? `<span class="${t.due_date < today ? 'wt-overdue' : 'wt-due'}">Due ${fmtDate(t.due_date)}</span>` : '';
  return `
    <div class="task-detail-row${t.is_done?' is-void':''}">
      <div class="task-row-body">
        <div class="${t.is_done?'task-title-done':'task-title'}">${esc(t.title)}${t.is_recurring?`<span class="wt-recur-badge">↻ ${esc(t.recur_frequency||'Recurring')}</span>`:''}${wtDue}</div>
        ${t.description ? `<div class="task-meta">${esc(t.description)}</div>` : ''}
        <div class="task-dates">Added: ${addedDate}${doneDate?' &nbsp;·&nbsp; Completed: '+doneDate:''}</div>
        ${_jobTaskVisitLine(t)}
      </div>
      ${!t.invoice_id ? `<button class="btn btn-outline btn-sm-action" onclick="_jobEditWorkTask(${t.id},${jobId})">Edit</button>` : ''}
      ${t.billing === 'hourly' && !t.invoice_id ? `<button class="btn btn-outline btn-sm-action" title="Add a visit with the hours worked on this task" onclick="_jobVisitForm(${jobId},null,{taskId:${t.id},tab:'tasks'})">+ Log time</button>` : ''}
      ${_jobTaskBillBadge(t)}
      ${t.invoice_id ? `<button class="btn btn-outline btn-sm-outline" onclick="detClose();setTimeout(()=>{navigate('invoices');setTimeout(()=>invOpen(${t.invoice_id}),400)},200)">View Invoice</button>` : ''}
      ${!t.is_done ? `<button class="btn btn-green btn-sm-action" onclick="_jobCompleteTask(${t.id},${jobId},this)">Done</button>` : ''}
      <button onclick="_jobDelTask(${t.id},${jobId})" class="btn-icon-del-r" title="Delete">✕</button>
    </div>`;
}

function _jobRefreshTaskRows(jobId) {
  const container = document.getElementById('jt-task-rows');
  if (!container) return;
  let tasks = [...(_jobDetail?.work_tasks || [])];
  if (_jobTaskFilter === 'Open')      tasks = tasks.filter(t => !t.is_done);
  else if (_jobTaskFilter === 'Completed') tasks = tasks.filter(t =>  t.is_done);
  if (_jobTaskRecurring) tasks = tasks.filter(t => t.is_recurring);

  const openWork     = tasks.filter(t => !t.is_done);
  const doneWork     = tasks.filter(t =>  t.is_done && !t.invoice_id);
  const invoicedWork = tasks.filter(t =>  t.is_done && t.invoice_id);

  if (!tasks.length) {
    container.innerHTML = '<div class="det-empty tab-add-row">No tasks match the current filter.</div>';
    return;
  }
  container.innerHTML =
    (openWork.length ? openWork.map(t => _jobTaskRow(t, jobId)).join('') : (_jobTaskFilter === 'All' ? '<div class="det-empty tab-add-row">No open tasks.</div>' : '')) +
    (doneWork.length ? `<div class="tasks-done-hdr">Completed (${doneWork.length})</div>${doneWork.map(t => _jobTaskRow(t, jobId)).join('')}` : '') +
    (invoicedWork.length ? `<div class="tasks-done-hdr wt-section-invoiced">Invoiced (${invoicedWork.length})</div>${invoicedWork.map(t => _jobTaskRow(t, jobId)).join('')}` : '');
}

function _jobTaskSetFilter(s, jobId) {
  _jobTaskFilter = s;
  document.querySelectorAll('#jt-filter-group .filter-btn').forEach(b => b.classList.toggle('active', b.id === `jt-flt-${s}`));
  _jobRefreshTaskRows(jobId);
}

function _jobTaskToggleRecurring(jobId) {
  _jobTaskRecurring = !_jobTaskRecurring;
  const btn = document.getElementById('jt-flt-recurring');
  if (btn) btn.classList.toggle('active', _jobTaskRecurring);
  _jobRefreshTaskRows(jobId);
}

function _jobCrmTaskRow(t, jobId) {
  const today = isoToday();
  const due = t.due_date && !t.is_done
    ? `<span class="${t.due_date < today ? 'wt-overdue' : 'wt-due'}"> Due ${fmtDate(t.due_date)}</span>` : '';
  const badge = t.task_type ? `<span class="comm-type-badge">${esc(t.task_type)}</span> ` : '';
  return `<div class="task-detail-row${t.is_done?' is-void':''}">
    <div class="task-row-body">
      <div class="${t.is_done?'task-title-done':'task-title'}">${badge}${esc(t.title)}${due}</div>
      ${t.description ? `<div class="task-meta">${esc(t.description)}</div>` : ''}
    </div>
    ${!t.is_done ? `<button class="btn btn-green btn-sm-action" onclick="_jobCrmDone(${t.id},${jobId})">Done</button>` : ''}
    <button class="btn btn-outline btn-sm-action" onclick="_jobEditTask(${t.id},${jobId})">Edit</button>
    <button onclick="_jobDelCrmTask(${t.id},${jobId})" class="btn-icon-del-r" title="Delete">✕</button>
  </div>`;
}

function _jobTabTasks(el, wrkTasks, jobId) {
  const crmTasks   = _jobDetail?.crm_tasks || [];
  _jobCrmTaskCache = crmTasks;
  const hasContact = !!_jobDetail?.job?.contact_id;

  el.innerHTML = `
    <div class="tab-add-row job-sticky-toolbar" style="gap:8px;flex-wrap:wrap">
      <button class="btn btn-outline btn-sm-outline" onclick="_jobAddTask(${jobId})">+ Add Task</button>
      ${hasContact ? `<button class="btn btn-outline btn-sm-outline" onclick="_jobLinkOrphanTasks(${jobId})">↓ From contact</button>` : ''}
      <div class="inv-filter-group" id="jt-filter-group">
        ${['All','Open','Completed'].map(s =>
          `<button class="filter-btn${_jobTaskFilter===s?' active':''}" id="jt-flt-${s}" onclick="_jobTaskSetFilter('${s}',${jobId})">${s}</button>`
        ).join('')}
      </div>
      <button class="filter-btn${_jobTaskRecurring?' active':''}" id="jt-flt-recurring" onclick="_jobTaskToggleRecurring(${jobId})">Recurring</button>
    </div>
    <div id="jt-task-rows"></div>
    ${crmTasks.length ? `
    <div class="tasks-done-hdr" style="margin-top:12px">CRM Tasks (${crmTasks.length})</div>
    <div id="jt-crm-rows">${crmTasks.map(t => _jobCrmTaskRow(t, jobId)).join('')}</div>` : ''}`;
  _jobRefreshTaskRows(jobId);
}

function _jobTaskFormHtml(task, jobId) {
  const types      = _jobMeta.task_types  || ['Follow Up','Send Quote','Schedule Meeting','Other'];
  const priorities = _jobMeta.priority    || ['Low','Normal','High','Urgent'];
  const assigned   = task ? (task.assigned_to || '') : '';
  const typeOpts   = types.map(t=>`<option${task&&task.task_type===t?' selected':''}>${esc(t)}</option>`).join('');
  const priOpts    = priorities.map(p=>`<option${(task?task.priority||'Normal':'Normal')===p?' selected':''}>${esc(p)}</option>`).join('');
  const linkedCid  = task ? (task.contact_id || '') : '';
  const conOpts    = `<option value="">— None —</option>` +
    (_jobContacts||[]).map(c=>`<option value="${c.id}"${c.id==linkedCid?' selected':''}>${esc(c.name)}</option>`).join('');
  return `
    <div class="det-tabs" id="job-tabs" style="display:none"></div>
    <div id="job-tab-content">
    <h3 class="form-section-hdr">${task ? 'Edit Task' : 'Add Task'}</h3>
    <div class="edt-grid">
      <div class="edt-field edt-span"><label class="edt-lbl">Title *</label>
        <input class="edt-inp" id="tf-title" placeholder="Task description" value="${task ? esc(task.title) : ''}"></div>
      <div class="edt-field"><label class="edt-lbl">Type</label>
        <select class="edt-sel" id="tf-type">${typeOpts}</select></div>
      <div class="edt-field"><label class="edt-lbl">Priority</label>
        <select class="edt-sel" id="tf-pri">${priOpts}</select></div>
      <div class="edt-field"><label class="edt-lbl">Due Date</label>
        <input class="edt-inp" id="tf-due" type="date" value="${task ? (task.due_date || '') : isoToday()}"></div>
      <div class="edt-field"><label class="edt-lbl">Contact</label>
        <select class="edt-sel" id="tf-contact">${conOpts}</select></div>
    </div></div>`;
}

window._jobAddTask = async function(jobId) {
  if (!_jobItems) {
    try { _jobItems = await apiFetch('/api/items'); } catch(e) { _jobItems = []; }
  }
  const today = isoToday();
  const itemOpts = `<option value="">— manual entry —</option>` +
    _jobItems.map(i => `<option value="${i.id}" data-name="${esc(i.name)}" data-desc="${esc(i.description||'')}" data-price="${i.unit_price||0}">${esc((i.code ? i.code+' — ' : '') + i.name)}</option>`).join('');
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:min(520px,96vw)">
    <div class="modal-title">Add Task</div>
    <div class="modal-field"><label class="modal-lbl">From Catalog</label>
      <select class="modal-inp" id="jat-catalog" onchange="_jobPickCatalogItem(this)">${itemOpts}</select></div>
    <div class="modal-field"><label class="modal-lbl">Title *</label>
      <input class="modal-inp" id="jat-title" placeholder="Task title"></div>
    <div class="modal-field"><label class="modal-lbl">Description</label>
      <input class="modal-inp" id="jat-desc" placeholder="Notes (optional)"></div>
    ${_jobTaskBillingField('jat', null)}
    <div class="modal-field" id="jat-price-row" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="modal-lbl">Qty</label>
        <input class="modal-inp" id="jat-qty" type="number" step="0.01" value="1"></div>
      <div><label class="modal-lbl">Unit Price ($)</label>
        <input class="modal-inp" id="jat-price" type="number" step="0.01" value="0"></div>
    </div>
    <div class="modal-field" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="modal-lbl">Date Added</label>
        <input class="modal-inp" id="jat-added" type="date" value="${today}"></div>
      <div><label class="modal-lbl">Due Date</label>
        <input class="modal-inp" id="jat-due" type="date"></div>
    </div>
    <div class="modal-field" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
      <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
        <input type="checkbox" id="jat-recurring"
          onchange="document.getElementById('jat-freq-wrap').style.display=this.checked?'flex':'none'">
        Recurring task
      </label>
      <div id="jat-freq-wrap" style="display:none;align-items:center;gap:6px">
        <label class="modal-lbl" style="margin:0">Frequency</label>
        <select class="modal-inp" id="jat-freq" style="margin:0">
          <option value="">— none —</option>
          ${['Weekly','Fortnightly','Monthly','Quarterly','Annual'].map(f=>`<option>${f}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary btn-sm" id="jat-save-btn" onclick="_jobSaveNewWorkTask(${jobId})">Add Task</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  setTimeout(() => document.getElementById('jat-title')?.focus(), 50);
};

window._jobPickCatalogItem = function(sel) {
  const opt = sel.options[sel.selectedIndex];
  if (!opt || !opt.value) return;
  const titleEl = document.getElementById('jat-title');
  const descEl  = document.getElementById('jat-desc');
  const priceEl = document.getElementById('jat-price');
  if (titleEl) titleEl.value = opt.dataset.name || '';
  if (descEl)  descEl.value  = opt.dataset.desc  || '';
  if (priceEl) priceEl.value = opt.dataset.price  || '0';
};

window._jobSaveNewWorkTask = async function(jobId) {
  const title = (document.getElementById('jat-title')?.value || '').trim();
  if (!title) { toast('Title is required', 'err'); return; }
  const btn = document.getElementById('jat-save-btn');
  btn.disabled = true; btn.textContent = 'Saving…';
  try {
    const r = await fetch('/api/work-tasks', {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        title,
        description:     (document.getElementById('jat-desc')?.value  || '').trim(),
        billing:         document.getElementById('jat-billing')?.value || 'fixed',
        qty:             document.getElementById('jat-billing')?.value === 'hourly' ? 1
                           : parseFloat(document.getElementById('jat-qty')?.value   || '1') || 1,
        unit_price:      document.getElementById('jat-billing')?.value === 'hourly' ? 0
                           : parseFloat(document.getElementById('jat-price')?.value || '0') || 0,
        job_id:          jobId,
        contact_id:      _jobDetail?.job?.contact_id || null,
        created_at:      document.getElementById('jat-added')?.value || null,
        due_date:        document.getElementById('jat-due')?.value   || null,
        is_recurring:    document.getElementById('jat-recurring')?.checked ? 1 : 0,
        recur_frequency: document.getElementById('jat-freq')?.value  || null,
      }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    btn.closest('.modal-bd')?.remove();
    toast('Task added');
    await _jobRefreshDetail(jobId, 'tasks');
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = 'Add Task';
  }
};

window._jobEditTask = function(tid, jobId) {
  const task = _jobCrmTaskCache.find(t => t.id === tid);
  if (!task) { toast('Task not found', 'err'); return; }
  document.getElementById('det-body').innerHTML = _jobTaskFormHtml(task, jobId);
  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-primary" id="tf-save-btn" onclick="_jobSaveTask(${jobId},${tid})">Save Task</button>
    <button class="btn btn-outline" onclick="_jobRenderDetail()">Cancel</button>`;
  document.getElementById('tf-title')?.focus();
};

window._jobEditWorkTask = function(tid, jobId) {
  const t = (_jobDetail?.work_tasks || []).find(x => x.id === tid);
  if (!t) { toast('Task not found', 'err'); return; }
  const jobOpts = `<option value="">No job</option>${_jobAll.map(j=>`<option value="${j.id}"${t.job_id===j.id?' selected':''}>${esc(j.job_number+' — '+j.name)}</option>`).join('')}`;
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  const jFreqOpts = sel => ['Weekly','Fortnightly','Monthly','Quarterly','Annual'].map(f =>
    `<option value="${f}"${f === sel ? ' selected' : ''}>${f}</option>`).join('');
  bd.innerHTML = `<div class="modal-box" style="width:min(520px,96vw)">
    <div class="modal-title">Edit Task</div>
    <div class="modal-field"><label class="modal-lbl">Title *</label>
      <input class="modal-inp" id="jwt-title" value="${esc(t.title)}"></div>
    <div class="modal-field"><label class="modal-lbl">Description</label>
      <input class="modal-inp" id="jwt-desc" value="${esc(t.description||'')}"></div>
    ${_jobTaskBillingField('jwt', t)}
    <div class="modal-field" id="jwt-price-row" style="display:${t.billing==='hourly'?'none':'grid'};grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="modal-lbl">Qty</label>
        <input class="modal-inp" id="jwt-qty" type="number" step="0.01" value="${t.qty}"></div>
      <div><label class="modal-lbl">Unit Price ($)</label>
        <input class="modal-inp" id="jwt-price" type="number" step="0.01" value="${t.unit_price}"${t.qty_invoiced > 0 ? ' disabled' : ''}></div>
    </div>
    <div class="modal-field"><label class="modal-lbl">Job</label>
      <select class="modal-inp" id="jwt-job">${jobOpts}</select></div>
    <div class="modal-field" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="modal-lbl">Date Added</label>
        <input class="modal-inp" id="jwt-added" type="date" value="${t.created_at ? t.created_at.split(' ')[0] : ''}"></div>
      <div><label class="modal-lbl">Due Date</label>
        <input class="modal-inp" id="jwt-due" type="date" value="${t.due_date || ''}"></div>
    </div>
    <div class="modal-field" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="modal-lbl">Date Completed</label>
        <input class="modal-inp" id="jwt-done" type="date" value="${t.done_at ? t.done_at.split(' ')[0] : ''}"></div>
    </div>
    <div class="modal-field" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
      <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
        <input type="checkbox" id="jwt-recurring"${t.is_recurring ? ' checked' : ''}
          onchange="document.getElementById('jwt-freq-wrap').style.display=this.checked?'flex':'none'">
        Recurring task
      </label>
      <div id="jwt-freq-wrap" style="display:${t.is_recurring ? 'flex' : 'none'};align-items:center;gap:6px">
        <label class="modal-lbl" style="margin:0">Frequency</label>
        <select class="modal-inp" id="jwt-freq" style="margin:0">
          <option value="">— none —</option>
          ${jFreqOpts(t.recur_frequency)}
        </select>
      </div>
    </div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary btn-sm" id="jwt-save-btn" onclick="_jobSaveWorkTask(${tid},${jobId})">Save</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  setTimeout(() => document.getElementById('jwt-title')?.focus(), 50);
};

window._jobSaveWorkTask = async function(tid, jobId) {
  const title = (document.getElementById('jwt-title')?.value || '').trim();
  if (!title) { toast('Title is required', 'err'); return; }
  const btn = document.getElementById('jwt-save-btn');
  btn.disabled = true; btn.textContent = 'Saving…';
  try {
    const r = await fetch(`/api/work-tasks/${tid}`, {
      method: 'PUT', credentials: 'include',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({
        title,
        description:     (document.getElementById('jwt-desc')?.value || '').trim(),
        billing:         document.getElementById('jwt-billing')?.value || 'fixed',
        qty:             document.getElementById('jwt-billing')?.value === 'hourly' ? 1
                           : parseFloat(document.getElementById('jwt-qty')?.value   || '1') || 1,
        unit_price:      document.getElementById('jwt-billing')?.value === 'hourly' ? 0
                           : parseFloat(document.getElementById('jwt-price')?.value || '0') || 0,
        job_id:          parseInt(document.getElementById('jwt-job')?.value)   || null,
        created_at:      document.getElementById('jwt-added')?.value || null,
        done_at:         document.getElementById('jwt-done')?.value  || null,
        due_date:        document.getElementById('jwt-due')?.value   || null,
        is_recurring:    document.getElementById('jwt-recurring')?.checked ? 1 : 0,
        recur_frequency: document.getElementById('jwt-freq')?.value  || null,
      })
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    btn.closest('.modal-bd')?.remove();
    toast('Task updated');
    await _jobRefreshDetail(jobId, 'tasks');
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = 'Save';
  }
};

window._jobSaveTask = async function(jobId, taskId) {
  const title = (document.getElementById('tf-title')?.value || '').trim();
  if (!title) { toast('Title is required', 'err'); return; }
  const btn = document.getElementById('tf-save-btn');
  btn.disabled = true; btn.textContent = 'Saving…';
  try {
    const r = await fetch('/api/crm/tasks', {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id:          taskId || undefined,
        job_id:      jobId,
        title,
        task_type:   document.getElementById('tf-type')?.value    || 'Follow Up',
        priority:    document.getElementById('tf-pri')?.value     || 'Normal',
        due_date:    document.getElementById('tf-due')?.value     || null,
        contact_id:  parseInt(document.getElementById('tf-contact')?.value) || null,
      }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    toast(taskId ? 'Task updated' : 'Task added');
    await _jobRefreshDetail(jobId, 'tasks');
  } catch(e) { toast(e.message, 'err'); btn.disabled = false; btn.textContent = 'Save Task'; }
};

function _jobWtScheduleNextModal(task, jobId) {
  const _freqOpts = sel => ['Weekly','Fortnightly','Monthly','Quarterly','Annual'].map(f =>
    `<option value="${f}"${f === sel ? ' selected' : ''}>${f}</option>`).join('');
  const _adv = (iso, freq) => {
    if (!iso) return '';
    const d = new Date(iso + 'T00:00:00');
    switch ((freq || '').toLowerCase()) {
      case 'weekly':      d.setDate(d.getDate() + 7); break;
      case 'fortnightly': d.setDate(d.getDate() + 14); break;
      case 'monthly':     d.setMonth(d.getMonth() + 1); break;
      case 'quarterly':   d.setMonth(d.getMonth() + 3); break;
      case 'annual':      d.setFullYear(d.getFullYear() + 1); break;
    }
    return d.toISOString().slice(0, 10);
  };
  const base = task.due_date || isoToday();
  const suggested = _adv(base, task.recur_frequency);
  const bd = createModal({
    width: '420px',
    html: `<div class="modal-hdr">Schedule next task</div>
      <div class="modal-body">
        <p style="margin:0 0 14px">Schedule the next occurrence of <strong>${esc(task.title)}</strong>?</p>
        <div class="modal-field"><label class="modal-lbl">Frequency</label>
          <select class="modal-inp" id="jwt-next-freq">
            <option value="">— none —</option>
            ${_freqOpts(task.recur_frequency)}
          </select>
        </div>
        <div class="modal-field"><label class="modal-lbl">Due date</label>
          <input class="modal-inp" type="date" id="jwt-next-due" value="${suggested}">
        </div>
      </div>
      <div class="modal-acts">
        <button class="btn btn-outline btn-sm" id="jwt-next-skip">Skip</button>
        <button class="btn btn-primary btn-sm" id="jwt-next-sched">Schedule →</button>
      </div>`
  });
  bd.querySelector('#jwt-next-freq').onchange = function() {
    bd.querySelector('#jwt-next-due').value = _adv(base, this.value);
  };
  bd.querySelector('#jwt-next-skip').onclick = () => { bd.remove(); _jobRefreshDetail(jobId, 'tasks'); };
  bd.querySelector('#jwt-next-sched').onclick = async function() {
    this.disabled = true;
    const freq = bd.querySelector('#jwt-next-freq').value;
    const due  = bd.querySelector('#jwt-next-due').value;
    try {
      const r = await fetch('/api/work-tasks', {
        method: 'POST', credentials: 'include',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          contact_id:      task.contact_id,
          job_id:          task.job_id || null,
          opp_id:          task.opp_id || null,
          title:           task.title,
          is_recurring:    1,
          recur_frequency: freq || null,
          due_date:        due  || null,
        })
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Failed');
      toast('Next task scheduled');
    } catch(e) { toast(e.message, 'err'); }
    bd.remove();
    _jobRefreshDetail(jobId, 'tasks');
  };
}

window._jobCompleteTask = async function(tid, jobId, btn) {
  if (btn) btn.disabled = true;
  try {
    const r = await fetch(`/api/work-tasks/${tid}/complete`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({is_done: true}),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed');
    toast('Task marked done');
    if (j.data?.recurring) {
      _jobWtScheduleNextModal(j.data.recurring, jobId);
    } else {
      await _jobRefreshDetail(jobId, 'tasks');
    }
  } catch(e) { toast(e.message, 'err'); }
};

window._jobDelTask = async function(tid, jobId) {
  if (!await confirmDlg('Delete this task?')) return;
  try {
    const r = await fetch(`/api/work-tasks/${tid}`, { method:'DELETE', credentials:'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Delete failed');
    toast('Deleted');
    await _jobRefreshDetail(jobId, 'tasks');
  } catch(e) { toast(e.message, 'err'); }
};

window._jobCrmDone = async function(tid, jobId) {
  try {
    const r = await fetch(`/api/crm/tasks/${tid}/complete`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: '{}',
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed');
    toast('Task done');
    await _jobRefreshDetail(jobId, 'tasks');
  } catch(e) { toast(e.message, 'err'); }
};

window._jobDelCrmTask = async function(tid, jobId) {
  if (!await confirmDlg('Delete this task?')) return;
  try {
    const r = await fetch(`/api/crm/tasks/${tid}`, { method:'DELETE', credentials:'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Delete failed');
    toast('Deleted');
    await _jobRefreshDetail(jobId, 'tasks');
  } catch(e) { toast(e.message, 'err'); }
};

window._jobLinkOrphanTasks = async function(jobId) {
  let orphans;
  try {
    orphans = await apiFetch(`/api/jobs/${jobId}/orphan-tasks`);
  } catch(e) {
    toast('Failed to load contact tasks', 'err'); return;
  }

  const rowsHtml = orphans.length
    ? orphans.map(t => {
        const qty   = parseFloat(t.qty)        || 0;
        const price = parseFloat(t.unit_price) || 0;
        const meta  = qty ? `${qty} × $${price.toFixed(2)}` : (price ? `$${price.toFixed(2)}` : '');
        return `
      <div class="jot-row" style="display:flex;align-items:center;gap:8px;
           padding:8px 0;border-bottom:1px solid var(--border)">
        <div style="flex:1">
          <strong>${esc(t.title)}</strong>
          ${meta ? `<span style="font-size:11.5px;color:var(--ink2);margin-left:6px">${meta}</span>` : ''}
          ${t.due_date ? `<span class="wt-due" style="margin-left:6px">Due ${fmtDate(t.due_date)}</span>` : ''}
          ${t.description ? `<div style="font-size:11.5px;color:var(--ink3);margin-top:2px">${esc(t.description)}</div>` : ''}
        </div>
        <button class="btn btn-primary btn-xs" onclick="_jobLinkTask(${t.id},${jobId},this)">Add →</button>
      </div>`;}).join('')
    : '<div class="state-empty" style="padding:14px 0">No unlinked tasks for this contact</div>';

  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:min(500px,96vw)">
    <div class="modal-hdr">
      <span>Link tasks from contact</span>
      <button class="modal-x" onclick="this.closest('.modal-bd').remove()">&#10005;</button>
    </div>
    <div class="modal-body" style="max-height:400px;overflow-y:auto">${rowsHtml}</div>
    <div class="modal-foot">
      <button class="btn btn-outline" onclick="this.closest('.modal-bd').remove()">Close</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  bd.addEventListener('click', ev => { if (ev.target === bd) bd.remove(); });
};

window._jobLinkTask = async function(taskId, jobId, btn) {
  if (btn) btn.disabled = true;
  try {
    const r = await fetch(`/api/crm/tasks/${taskId}`, {
      method: 'PATCH', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ job_id: jobId }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Link failed');
    btn?.closest('.jot-row')?.remove();
    toast('Task linked to job');
    _jobRefreshDetail(jobId, 'tasks');
  } catch(e) {
    toast(e.message, 'err');
    if (btn) btn.disabled = false;
  }
};

window._jobMakeBillable = function(tid, jobId) {
  const task = _jobCrmTaskCache.find(t => t.id === tid);
  if (!task) { toast('Task not found', 'err'); return; }
  const jobContactId = _jobDetail?.job?.contact_id || '';
  const conOpts = `<option value="">— Select contact —</option>` +
    (_jobContacts||[]).map(c=>`<option value="${c.id}"${c.id==jobContactId?' selected':''}>${esc(c.name)}</option>`).join('');
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:380px;display:flex;flex-direction:column">
    <div class="modal-hdr">Convert to Billable Task</div>
    <div class="modal-body">
      <div class="edt-field" style="margin-bottom:12px">
        <label class="edt-lbl">Task</label>
        <div style="padding:6px 0;font-weight:500">${esc(task.title)}</div>
      </div>
      <div class="edt-field" style="margin-bottom:12px">
        <label class="edt-lbl">Contact *</label>
        <select class="edt-sel" id="bill-contact">${conOpts}</select>
      </div>
      <div style="display:flex;gap:12px">
        <div class="edt-field" style="flex:0 0 80px"><label class="edt-lbl">Qty</label>
          <input class="edt-inp" id="bill-qty" type="number" min="0.01" step="0.01" value="1" style="width:70px"></div>
        <div class="edt-field" style="flex:1"><label class="edt-lbl">Unit Price ($)</label>
          <input class="edt-inp" id="bill-price" type="number" min="0" step="0.01" value="" placeholder="0.00"></div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-primary" id="bill-confirm-btn">Convert</button>
      <button class="btn btn-outline" onclick="this.closest('.modal-bd').remove()">Cancel</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  bd.querySelector('#bill-price').focus();
  bd.querySelector('#bill-confirm-btn').addEventListener('click', async () => {
    const contact_id = parseInt(bd.querySelector('#bill-contact').value) || null;
    if (!contact_id) { toast('Select a contact', 'err'); return; }
    const qty   = parseFloat(bd.querySelector('#bill-qty').value)   || 1;
    const price = parseFloat(bd.querySelector('#bill-price').value) || 0;
    const btn   = bd.querySelector('#bill-confirm-btn');
    btn.disabled = true; btn.textContent = 'Saving…';
    try {
      const r1 = await fetch('/api/work-tasks', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contact_id,
          job_id:     jobId,
          title:      task.title,
          description: task.description || null,
          qty,
          unit_price: price,
        }),
      });
      const j1 = await r1.json();
      if (!j1.ok) throw new Error(j1.error || 'Failed to create billable task');
      if (task.is_done) {
        const rc = await fetch(`/api/work-tasks/${j1.data.id}/complete`, { method:'POST', credentials:'include', headers:{'Content-Type':'application/json'}, body:'{}' });
        const jc = await rc.json();
        if (!jc.ok) throw new Error(jc.error || 'Failed to mark task done');
      }
      const r2 = await fetch(`/api/crm/tasks/${tid}`, { method: 'DELETE', credentials: 'include' });
      const j2 = await r2.json();
      if (!j2.ok) throw new Error(j2.error || 'Failed to remove original task');
      bd.remove();
      toast('Converted to billable task');
      await _jobRefreshDetail(jobId, 'tasks');
    } catch(e) { toast(e.message, 'err'); btn.disabled = false; btn.textContent = 'Convert'; }
  });
};

window._jobInvoiceTasks = async function(jobId, taskIds) {
  if (!taskIds.length) { toast('No completed tasks to invoice', 'err'); return; }
  const createClaim = document.getElementById('job-create-claim-chk')?.checked || false;
  if (!await confirmDlg(`Create a draft invoice from ${taskIds.length} completed task${taskIds.length!==1?'s':''}?`)) return;
  try {
    const r = await fetch(`/api/jobs/${jobId}/work-tasks/invoice`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({task_ids: taskIds, create_claim: createClaim})
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed');
    toast('Invoice created — opening…');
    detClose();
    _jobAll = await apiFetch('/api/jobs') || _jobAll;
    const tasksInvId = j.data.invoice_id;
    navigate('invoices');
    setTimeout(async () => {
      const invData = await apiFetch(`/api/invoices/${tasksInvId}`);
      if (!invData) { toast('Invoice not found', 'err'); return; }
      document.getElementById('det-overlay').classList.add('open');
      document.getElementById('det-panel').classList.add('open');
      document.getElementById('det-title').textContent = 'Invoice';
      document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading…</div>';
      document.getElementById('det-foot').innerHTML = '';
      await invEditOpen(invData);
    }, 500);
  } catch(e) { toast(e.message, 'err'); }
};

// ── Quotes tab ────────────────────────────────────────────────────────────────
function _jobTabQuotes(el, quotes, job) {
  const rows = quotes.map(q => {
    const canAccept  = q.status==='Draft'||q.status==='Sent';
    const canConvert = q.status==='Accepted'&&!q.invoice_id;
    const canPO      = q.status==='Accepted'&&!q.po_id;
    const actions = [
      canAccept  ? `<button class="btn btn-green btn-sm-green" onclick="event.stopPropagation();_jobAcceptQuote(${q.id},${job.id})">✓ Accept</button>` : '',
      canConvert ? `<button class="btn btn-primary btn-sm-primary" onclick="event.stopPropagation();_jobConvertQuote(${q.id})">→ Invoice</button>` : '',
      canPO      ? `<button class="btn btn-secondary btn-sm" onclick="event.stopPropagation();_jobCreatePO(${q.id},${job.id})">Create PO</button>` : '',
      q.invoice_id ? `<span class="quote-invoiced-lbl">✓ Invoiced</span>` : '',
      q.po_id      ? `<span class="quote-invoiced-lbl col-green">✓ PO</span>` : '',
      `<button class="btn btn-ghost btn-sm-outline" onclick="_jobOpenQuote(${q.id},${job.id})">View →</button>`,
    ].filter(Boolean).join('');
    return `
      <div class="quote-row" onclick="_jobOpenQuote(${q.id},${job.id})">
        <div class="quote-row-body">
          <div class="quote-row-hdr">
            ${_jobQuoteBadge(q.status)}
            <span class="quote-row-num">${esc(q.quote_number)}</span>
            <span class="inv-amt quote-row-amt">${fmt(q.total)}</span>
          </div>
          <div class="quote-row-meta">${fmtDate(q.quote_date)}${q.expiry_date?' · Expires '+fmtDate(q.expiry_date):''}</div>
        </div>
        <div class="quote-row-actions">${actions}</div>
      </div>`;
  }).join('');

  el.innerHTML = `
    <div class="tab-add-row job-sticky-toolbar">
      <button class="btn btn-outline btn-sm-outline" onclick="_jobNewQuote(${job.id},${job.contact_id||'null'})">+ New Quote</button>
    </div>
    ${rows || '<div class="det-empty">No quotes yet — click + New Quote to get started.</div>'}`;
}

window._jobOpenQuote = async function(qid, jobId) {
  document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading…</div>';
  document.getElementById('det-foot').innerHTML = '';
  try {
    const data = await apiFetch(`/api/crm/quotes/${qid}`);
    _jobRenderQuoteDetail(data, jobId);
  } catch(e) {
    document.getElementById('det-body').innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
  }
};

function _jobRenderQuoteDetail(data, jobId) {
  const q = data.quote, lines = data.lines || [];
  document.getElementById('det-title').textContent = `Quote ${esc(q.quote_number)}`;
  const linesHtml = `
    <table class="det-lines">
      <thead><tr><th>Description</th><th class="th-r">Qty</th><th class="th-r">Price</th><th>Tax</th><th class="th-r">Total</th></tr></thead>
      <tbody>${lines.map(l=>`<tr>
        <td>${esc(l.description)}</td>
        <td class="td-r-mono">${l.quantity}</td>
        <td class="td-r-mono">${fmt(l.unit_price)}</td>
        <td><span class="inv-mono">${esc(l.tax_code)}</span></td>
        <td class="td-r-mono">${fmt(l.line_total)}</td>
      </tr>`).join('')}</tbody>
    </table>
    <div class="det-totals">
      <div class="det-tot-row"><span>Subtotal</span><span>${fmt(q.subtotal)}</span></div>
      <div class="det-tot-row"><span>GST</span><span>${fmt(q.gst_total)}</span></div>
      <div class="det-tot-row grand"><span>Total</span><span>${fmt(q.total)}</span></div>
    </div>`;

  document.getElementById('det-body').innerHTML = `
    <div class="det-badge-row">${_jobQuoteBadge(q.status)}</div>
    <div class="det-meta">
      <div><div class="det-lbl">Quote Date</div><div class="det-val mono">${fmtDate(q.quote_date)}</div></div>
      <div><div class="det-lbl">Expiry</div><div class="det-val mono">${fmtDate(q.expiry_date)}</div></div>
      <div><div class="det-lbl">Contact</div><div class="det-val">${esc(q.contact_name||'—')}</div></div>
      <div><div class="det-lbl">Status</div><div class="det-val">${esc(q.status)}</div></div>
      ${q.accepted_date?`<div><div class="det-lbl">Accepted</div><div class="det-val mono">${fmtDate(q.accepted_date)}</div></div>`:''}
      ${q.invoice_id?`<div><div class="det-lbl">Invoice</div><div class="det-val"><a href="#" onclick="invOpen(${q.invoice_id});return false" class="det-inv-link">#${q.invoice_id}</a></div></div>`:''}
      ${q.po_id?`<div><div class="det-lbl">PO</div><div class="det-val col-green">PO #${q.po_id}</div></div>`:''}
    </div>
    ${q.intro_text?`<div class="det-section-block"><div class="det-lbl det-lbl-gap">Intro</div><div class="det-note">${esc(q.intro_text)}</div></div>`:''}
    ${linesHtml}
    ${q.terms_text?`<div class="det-section-top"><div class="det-lbl det-lbl-gap">Terms</div><div class="det-note">${esc(q.terms_text)}</div></div>`:''}
    ${q.internal_notes?`<div class="det-section-top"><div class="det-lbl det-lbl-gap">Internal Notes</div><div class="det-note">${esc(q.internal_notes)}</div></div>`:''}`;

  const canAccept  = q.status==='Draft'||q.status==='Sent';
  const canConvert = q.status==='Accepted'&&!q.invoice_id;
  const canPO      = q.status==='Accepted'&&!q.po_id;
  document.getElementById('det-foot').innerHTML = `
    ${canAccept  ? `<button class="btn btn-green"    onclick="_jobAcceptQuote(${q.id},${jobId})">✓ Accept</button>` : ''}
    ${canConvert ? `<button class="btn btn-primary"  onclick="_jobConvertQuote(${q.id})">→ Create Invoice</button>` : ''}
    ${canPO      ? `<button class="btn btn-secondary" onclick="_jobCreatePO(${q.id},${jobId})">Create PO</button>` : ''}
    <button class="btn btn-outline" onclick="_jobEditQuote(${q.id},${jobId})">✏ Edit</button>
    <button class="btn btn-outline" onclick="window.open('/api/crm/quotes/${q.id}/pdf')">PDF</button>
    ${q.status!=='Accepted'&&q.status!=='Invoiced'?`<button class="btn btn-danger" onclick="_jobDelQuote(${q.id},${jobId})">Delete</button>`:''}
    <button class="btn btn-outline" onclick="_jobTab('quotes')">← Back</button>`;
}

window._jobAcceptQuote = async function(qid, jobId) {
  if (!await confirmDlg('Accept this quote? Other draft quotes will be superseded.')) return;
  try {
    const r = await fetch(`/api/crm/quotes/${qid}/accept`, { method:'POST', credentials:'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed');
    toast('Quote accepted');
    await _jobRefreshDetail(jobId, 'quotes');
  } catch(e) { toast(e.message, 'err'); }
};

window._jobConvertQuote = async function(qid) {
  if (!await confirmDlg('Convert this quote to a draft invoice?')) return;
  try {
    const r = await fetch(`/api/crm/quotes/${qid}/convert`, { method:'POST', credentials:'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed');
    toast('Invoice created — opening…');
    detClose();
    _jobAll = await apiFetch('/api/jobs') || _jobAll;
    const quoteInvId = j.data.invoice_id;
    navigate('invoices');
    setTimeout(async () => {
      const invData = await apiFetch(`/api/invoices/${quoteInvId}`);
      if (!invData) { toast('Invoice not found', 'err'); return; }
      document.getElementById('det-overlay').classList.add('open');
      document.getElementById('det-panel').classList.add('open');
      document.getElementById('det-title').textContent = 'Invoice';
      document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading…</div>';
      document.getElementById('det-foot').innerHTML = '';
      await invEditOpen(invData);
    }, 500);
  } catch(e) { toast(e.message, 'err'); }
};

window._jobCreatePO = async function(qid, jobId) {
  let suppliers = [];
  try {
    const contacts = await apiFetch('/api/contacts');
    suppliers = (contacts||[]).filter(c => ['Supplier','Both'].includes(c.contact_type));
  } catch(e) { toast(e.message, 'err'); return; }

  const supOpts = suppliers.map(s => `<option value="${s.id}">${esc(s.name)}</option>`).join('');
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box" style="width:min(420px,95vw)">
      <div class="modal-hdr"><span>Create PO from Quote</span>
        <button class="det-close" onclick="this.closest('.modal-bd').remove()">✕</button>
      </div>
      <div class="modal-body" style="padding:16px 20px">
        <p style="margin:0 0 12px;font-size:13px;color:var(--ink2)">Creates a supplier PO using lines from this quote.</p>
        <label class="edt-lbl">Supplier *</label>
        <select id="job-po-supp" class="edt-field edt-field-mb">
          <option value="">— Select supplier —</option>${supOpts}
        </select>
        <label class="edt-lbl">PO Date</label>
        <input id="job-po-date" type="date" class="edt-field edt-field-mb" value="${isoToday()}">
        <label class="edt-lbl">Expected Date</label>
        <input id="job-po-exp" type="date" class="edt-field edt-field-mb" value="">
      </div>
      <div class="modal-foot">
        <button class="btn btn-secondary" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary" id="job-po-create-btn" onclick="_jobDoCreatePO(${qid},${jobId})">Create PO</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
};

window._jobDoCreatePO = async function(qid, jobId) {
  const suppEl = document.getElementById('job-po-supp');
  if (!suppEl?.value) { toast('Select a supplier', 'err'); return; }
  const btn = document.getElementById('job-po-create-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Creating…'; }
  try {
    const r = await fetch(`/api/crm/quotes/${qid}/create-po`, {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        supplier_id:   parseInt(suppEl.value),
        po_date:       document.getElementById('job-po-date')?.value || null,
        expected_date: document.getElementById('job-po-exp')?.value  || null,
      }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed');
    btn?.closest('.modal-bd')?.remove();
    toast(`Purchase Order created (PO #${j.po_id})`);
    await _jobRefreshDetail(jobId, 'quotes');
  } catch(e) {
    if (btn) { btn.disabled = false; btn.textContent = 'Create PO'; }
    toast(e.message, 'err');
  }
};

window._jobDelQuote = async function(qid, jobId) {
  if (!await confirmDlg('Delete this quote?')) return;
  try {
    const r = await fetch(`/api/crm/quotes/${qid}`, { method:'DELETE', credentials:'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Delete failed');
    toast('Deleted');
    await _jobRefreshDetail(jobId, 'quotes');
  } catch(e) { toast(e.message, 'err'); }
};

// ── Quote editor ──────────────────────────────────────────────────────────────
async function _jobEnsureAccts() {
  if (_jobEditAccts) return;
  try {
    const accts = await apiFetch('/api/accounts');
    _jobEditAccts = (accts||[]).filter(a => ['Revenue','Income','Other Income'].includes(a.account_type));
    if (!_jobEditAccts.length) _jobEditAccts = accts||[];
  } catch(_) { _jobEditAccts = []; }
}

window._jobNewQuote = async function(jobId, contactId) {
  _jobQuoteLines = [{ description:'', quantity:1, unit_price:0, tax_code:'GST', account_id:null, item_id:null, line_type:'item' }];
  await _jobEnsureAccts();
  _jobShowQuoteForm({ job_id:jobId, contact_id:contactId, quote_date:isoToday(), expiry_date:isoAddDays(30), status:'Draft' }, jobId, false);
};

window._jobEditQuote = async function(qid, jobId) {
  try {
    const [data] = await Promise.all([apiFetch(`/api/crm/quotes/${qid}`), _jobEnsureAccts()]);
    const def = { description:'', quantity:1, unit_price:0, tax_code:'GST', account_id:null, item_id:null, line_type:'item' };
    _jobQuoteLines = data.lines.length ? data.lines.map(l=>({...def,...l})) : [def];
    _jobShowQuoteForm(data.quote, jobId, true);
  } catch(e) { toast(e.message, 'err'); }
};

function _jobShowQuoteForm(q, jobId, isEdit) {
  const statuses = _jobMeta.quote_status || ['Draft','Sent'];
  const conOpts = (_jobContacts||[]).map(c =>
    `<option value="${c.id}"${c.id===q.contact_id?' selected':''}>${esc(c.name)}</option>`
  ).join('');

  document.getElementById('det-title').textContent = isEdit ? `Edit Quote ${q.quote_number||''}` : 'New Quote';
  document.getElementById('det-body').innerHTML = `
    <div class="edt-grid edt-grid-mb">
      <div class="edt-field"><label class="edt-lbl">Quote Date *</label>
        <input class="edt-inp" id="qf-date" type="date" value="${q.quote_date||''}"></div>
      <div class="edt-field"><label class="edt-lbl">Expiry Date</label>
        <input class="edt-inp" id="qf-expiry" type="date" value="${q.expiry_date||''}"></div>
      <div class="edt-field">
        <div class="lbl-line">
          <label class="edt-lbl">Contact</label>
          <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();_jobNewContact('qf-contact','Customer')">+ New</a>
        </div>
        <select class="edt-sel" id="qf-contact"><option value="">— Select —</option>${conOpts}</select></div>
      <div class="edt-field"><label class="edt-lbl">Status</label>
        <select class="edt-sel" id="qf-status">${statuses.map(s=>`<option${s===q.status?' selected':''}>${s}</option>`).join('')}</select></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Intro Text</label>
        <textarea class="edt-ta" id="qf-intro" placeholder="Optional intro paragraph…">${esc(q.intro_text||'')}</textarea></div>
    </div>
    <div class="edt-section-lbl">Line Items</div>
    <div class="edt-lines-hdr"><span></span><span></span><span>Description</span><span>Qty</span><span>Unit Price</span><span>Tax</span><span>GST</span><span>Total</span><span></span></div>
    <div id="qf-lines"></div>
    <button class="btn btn-outline edt-add-btn" onclick="_jobQfAddLine()">+ Add Line</button>
    <div class="edt-totals-preview" id="qf-totals"></div>
    <div class="edt-divider"></div>
    <div class="edt-grid">
      <div class="edt-field edt-span"><label class="edt-lbl">Terms</label>
        <textarea class="edt-ta" id="qf-terms" placeholder="Payment terms, conditions…">${esc(q.terms_text||'')}</textarea></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Internal Notes</label>
        <textarea class="edt-ta" id="qf-notes" placeholder="Internal notes (not shown on quote)">${esc(q.internal_notes||'')}</textarea></div>
    </div>`;

  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-primary" id="qf-save-btn"
      onclick="_jobSaveQuote(${q.id||'null'},${jobId})">${isEdit?'Save Changes':'Create Quote'}</button>
    <button class="btn btn-outline"
      onclick="${isEdit?`_jobOpenQuote(${q.id},${jobId})`:'_jobRenderDetail()'}">Cancel</button>`;

  _jobQfRenderLines();
}

window._jobQfAddLine = function() {
  _jobQuoteLines.push({ description:'', quantity:1, unit_price:0, tax_code:'GST', account_id:null, item_id:null, line_type:'item' });
  _jobQfRenderLines();
};

window._jobQfRemoveLine = function(i) {
  _jobQuoteLines.splice(i, 1);
  if (!_jobQuoteLines.length) {
    _jobQuoteLines = [{ description:'', quantity:1, unit_price:0, tax_code:'GST', account_id:null, item_id:null, line_type:'item' }];
  }
  _jobQfRenderLines();
};

window._jobQfToggleType = function(i) {
  const l = _jobQuoteLines[i];
  l.line_type = l.line_type === 'comment' ? 'item' : 'comment';
  if (l.line_type === 'comment') { l.quantity=0; l.unit_price=0; l.account_id=null; l.item_id=null; }
  else { l.quantity=1; l.unit_price=0; }
  _jobQfRenderLines();
  _jobQfCalc();
  if (l.line_type !== 'comment') _jobWireQfTypeahead(i);
};

function _jobQfRenderLines() {
  const el = document.getElementById('qf-lines');
  if (!el) return;
  const accts = _jobEditAccts || [];
  el.innerHTML = _jobQuoteLines.map((l, i) => {
    const isComment = l.line_type === 'comment';
    const toggleBtn = `<button class="edt-type-btn${isComment?' is-comment':''}"
      title="${isComment?'Switch to item':'Switch to comment'}"
      onclick="_jobQfToggleType(${i})">${isComment?'T':'≡'}</button>`;
    const dnd = `draggable="true" ondragstart="_jobQfDragStart(event,${i})"
      ondragover="_jobQfDragOver(event,${i})" ondrop="_jobQfDrop(event,${i})" ondragend="_jobQfDragEnd(event)"`;

    if (isComment) {
      return `
        <div class="edt-line-wrap" id="qf-line-${i}" ${dnd}>
          <div class="edt-line-row edt-comment-row">
            <span class="edt-drag-handle" title="Drag to reorder">⠿</span>
            ${toggleBtn}
            <textarea class="edt-inp edt-comment-ta" id="qf-desc-${i}"
              placeholder="Comment or heading…"
              oninput="_jobQuoteLines[${i}].description=this.value">${esc(l.description||'')}</textarea>
            <button class="edt-rm-btn" onclick="_jobQfRemoveLine(${i})">✕</button>
          </div>
        </div>`;
    }

    const ex   = parseFloat(l.quantity||1) * parseFloat(l.unit_price||0);
    const rate = l.tax_code === 'GST' ? 0.1 : 0;
    const g    = Math.round(ex * rate * 100) / 100;
    const tot  = Math.round((ex + g) * 100) / 100;
    const acctOpts = accts.map(a =>
      `<option value="${a.id}"${a.id===l.account_id?' selected':''}>${esc((a.code?a.code+' ':'')+a.name)}</option>`
    ).join('');

    return `
      <div class="edt-line-wrap" id="qf-line-${i}" ${dnd}>
        <div class="edt-line-row">
          <span class="edt-drag-handle" title="Drag to reorder">⠿</span>
          ${toggleBtn}
          <input class="edt-inp" type="text" id="qf-desc-${i}" value="${esc(l.description||'')}"
            placeholder="Description or search catalogue…"
            oninput="_jobQuoteLines[${i}].description=this.value">
          <input class="edt-inp" type="number" id="qf-qty-${i}" step="0.01" min="0" value="${l.quantity||1}"
            oninput="_jobQuoteLines[${i}].quantity=parseFloat(this.value)||0;_jobQfLineCalc(${i})">
          <input class="edt-inp" type="number" id="qf-price-${i}" step="0.01" min="0" value="${l.unit_price||0}"
            oninput="_jobQuoteLines[${i}].unit_price=parseFloat(this.value)||0;_jobQfLineCalc(${i})">
          <select class="edt-sel" onchange="_jobQuoteLines[${i}].tax_code=this.value;_jobQfLineCalc(${i})">
            ${['GST','FRE','N-T'].map(tc=>`<option${(l.tax_code||'GST')===tc?' selected':''}>${tc}</option>`).join('')}
          </select>
          <span class="edt-calc" id="qf-gst-${i}">${fmt(g)}</span>
          <span class="edt-calc edt-calc-total" id="qf-tot-${i}">${fmt(tot)}</span>
          <button class="edt-rm-btn" onclick="_jobQfRemoveLine(${i})">✕</button>
        </div>
        <div class="edt-line-acct">
          <span class="edt-acct-lbl">Account</span>
          <select class="edt-sel edt-acct-sel" id="qf-acct-${i}"
            onchange="_jobQuoteLines[${i}].account_id=this.value?+this.value:null">
            <option value="">— default (Sales) —</option>${acctOpts}
          </select>
        </div>
      </div>`;
  }).join('');

  _jobQuoteLines.forEach((l, i) => { if (l.line_type !== 'comment') _jobWireQfTypeahead(i); });
  _jobQfCalc();
}

let _jobQfDragSrc = null;
window._jobQfDragStart = function(e, i) {
  _jobQfDragSrc = i;
  e.dataTransfer.effectAllowed = 'move';
  setTimeout(() => document.getElementById(`qf-line-${i}`)?.classList.add('is-dragging'), 0);
};
window._jobQfDragOver = function(e, i) {
  if (_jobQfDragSrc === null || _jobQfDragSrc === i) return;
  e.preventDefault();
  document.querySelectorAll('#qf-lines .edt-line-wrap').forEach(el => el.classList.remove('drag-over-top'));
  document.getElementById(`qf-line-${i}`)?.classList.add('drag-over-top');
};
window._jobQfDrop = function(e, i) {
  e.preventDefault();
  if (_jobQfDragSrc === null || _jobQfDragSrc === i) return;
  const [moved] = _jobQuoteLines.splice(_jobQfDragSrc, 1);
  _jobQuoteLines.splice(i, 0, moved);
  _jobQfDragSrc = null;
  _jobQfRenderLines();
};
window._jobQfDragEnd = function() {
  _jobQfDragSrc = null;
  document.querySelectorAll('#qf-lines .edt-line-wrap').forEach(el =>
    el.classList.remove('is-dragging', 'drag-over-top'));
};

function _jobWireQfTypeahead(i) {
  const inp = document.getElementById(`qf-desc-${i}`);
  if (!inp || inp.dataset.taWired) return;
  inp.dataset.taWired = '1';
  _attachTypeahead(inp, item => {
    _jobQuoteLines[i].description = item.description || item.name;
    _jobQuoteLines[i].unit_price  = parseFloat(item.unit_price) || 0;
    _jobQuoteLines[i].tax_code    = item.tax_code || 'GST';
    _jobQuoteLines[i].account_id  = item.account_id || null;
    _jobQuoteLines[i].item_id     = item.id;
    const priceInp = document.getElementById(`qf-price-${i}`);
    if (priceInp) priceInp.value = (parseFloat(item.unit_price)||0).toFixed(2);
    const taxSel = document.querySelector(`#qf-line-${i} select`);
    if (taxSel) taxSel.value = item.tax_code || 'GST';
    const acctSel = document.getElementById(`qf-acct-${i}`);
    if (acctSel && item.account_id) acctSel.value = item.account_id;
    _jobQfLineCalc(i);
  });
}

window._jobQfLineCalc = function(i) {
  const l = _jobQuoteLines[i];
  if (l.line_type === 'comment') { _jobQfCalc(); return; }
  const ex  = parseFloat(l.quantity||0) * parseFloat(l.unit_price||0);
  const rate = l.tax_code === 'GST' ? 0.1 : 0;
  const g   = Math.round(ex * rate * 100) / 100;
  const tot = Math.round((ex + g) * 100) / 100;
  const gEl = document.getElementById(`qf-gst-${i}`);
  const tEl = document.getElementById(`qf-tot-${i}`);
  if (gEl) gEl.textContent = fmt(g);
  if (tEl) tEl.textContent = fmt(tot);
  _jobQfCalc();
};

function _jobQfCalc() {
  let sub = 0, gst = 0;
  _jobQuoteLines.forEach(l => {
    if (l.line_type === 'comment') return;
    const ex = parseFloat(l.quantity||0) * parseFloat(l.unit_price||0);
    const g  = l.tax_code === 'GST' ? Math.round(ex * 0.1 * 100) / 100 : 0;
    sub += ex; gst += g;
  });
  sub = Math.round(sub * 100) / 100;
  gst = Math.round(gst * 100) / 100;
  const el = document.getElementById('qf-totals');
  if (el) el.innerHTML = `
    <span>Subtotal <b>${fmt(sub)}</b></span>
    <span>GST <b>${fmt(gst)}</b></span>
    <span class="grand">Total <b>${fmt(Math.round((sub+gst)*100)/100)}</b></span>`;
}

window._jobSaveQuote = async function(qid, jobId) {
  const date = document.getElementById('qf-date')?.value;
  if (!date) { toast('Quote date is required', 'err'); return; }
  const lines = _jobQuoteLines.filter(l => l.description.trim());
  if (!lines.length) { toast('Add at least one line item', 'err'); return; }
  const btn = document.getElementById('qf-save-btn');
  btn.disabled = true; btn.textContent = 'Saving…';
  const contactId = parseInt(document.getElementById('qf-contact')?.value||0) || null;
  const body = {
    quote: {
      id:             qid || undefined,
      job_id:         jobId,
      contact_id:     contactId,
      quote_date:     date,
      expiry_date:    document.getElementById('qf-expiry')?.value || null,
      status:         document.getElementById('qf-status')?.value || 'Draft',
      intro_text:     document.getElementById('qf-intro')?.value.trim() || null,
      terms_text:     document.getElementById('qf-terms')?.value.trim() || null,
      internal_notes: document.getElementById('qf-notes')?.value.trim() || null,
    },
    lines: lines.map(l => ({
      description: l.description,
      quantity:    l.line_type === 'comment' ? 0 : l.quantity,
      unit_price:  l.line_type === 'comment' ? 0 : l.unit_price,
      tax_code:    l.tax_code || 'GST',
      account_id:  l.account_id || null,
      item_id:     l.item_id || null,
      line_type:   l.line_type || 'item',
    })),
  };
  try {
    const method = qid ? 'PUT' : 'POST';
    const url    = qid ? `/api/crm/quotes/${qid}` : '/api/crm/quotes';
    const r = await fetch(url, {
      method, credentials:'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    toast(qid ? 'Quote updated' : 'Quote created');
    const newQid = qid || j.data.id;
    await _jobRefreshDetail(jobId, 'quotes');
    // Re-open the quote detail view
    if (newQid) _jobOpenQuote(newQid, jobId);
  } catch(e) { toast(e.message, 'err'); btn.disabled = false; btn.textContent = qid?'Save Changes':'Create Quote'; }
};

// ── Claims tab ────────────────────────────────────────────────────────────────
function _jobTabClaims(el, claims, wrkTasks, job, pl, txns) {
  // A claim whose invoice was voided is marked Void and no longer counts.
  const totalClaimed = claims.filter(c => c.status !== 'Void').reduce((s, c) => s + (c.amount_inc_gst || 0), 0);
  const jobValue     = job.value || 0;
  const claimedPct   = jobValue ? Math.round(totalClaimed / jobValue * 100) : null;

  const rows = claims.map(c => {
    const statCls = {
      Draft:'claim-status-draft', Claimed:'claim-status-claimed',
      Invoiced:'claim-status-invoiced', Paid:'claim-status-paid', Void:'claim-status-void',
    }[c.status] || 'claim-status-draft';
    const actions = [];
    if (c.status === 'Draft') {
      actions.push(`<button class="btn btn-outline btn-sm-outline" onclick="_jobSubmitClaim(${c.id},${job.id})">Submit</button>`);
      actions.push(`<button class="btn btn-outline btn-sm-outline" onclick="_jobConvertClaim(${c.id},${job.id})">New Invoice</button>`);
      actions.push(`<button class="btn btn-outline btn-sm-outline" onclick="_jobLinkInvoiceToClaim(${c.id},${job.id})">Link Invoice</button>`);
    } else if (c.status === 'Claimed') {
      actions.push(`<button class="btn btn-outline btn-sm-outline" onclick="_jobConvertClaim(${c.id},${job.id})">New Invoice</button>`);
      actions.push(`<button class="btn btn-outline btn-sm-outline" onclick="_jobLinkInvoiceToClaim(${c.id},${job.id})">Link Invoice</button>`);
    } else if (c.invoice_id) {
      actions.push(`<button class="btn btn-outline btn-sm-outline" onclick="detClose();setTimeout(()=>{navigate('invoices');setTimeout(()=>invOpen(${c.invoice_id}),400)},200)">View Invoice</button>`);
    }
    if (c.status === 'Draft' || c.status === 'Claimed') {
      actions.push(`<button onclick="_jobDelClaim(${c.id},${job.id})" class="btn-icon-del-r" title="Delete">✕</button>`);
    }
    return `
      <div class="task-detail-row">
        <div class="claim-row-body">
          <div class="claim-num">${esc(c.claim_number)}</div>
          <div class="claim-meta">${fmtDate(c.claim_date)} · ${esc(c.description||'—')}${c.cumulative_pct ? ` · ${c.cumulative_pct}% cumulative` : ''}</div>
        </div>
        <span class="claim-status ${statCls}">${esc(c.status)}</span>
        <span class="inv-amt">${fmt(c.amount_inc_gst)}</span>
        ${actions.join('')}
      </div>`;
  }).join('');

  const summaryHtml = jobValue ? `
    <div class="job-pl-card" style="margin-bottom:12px">
      <div class="job-pl-row"><span class="col-ink2">Job Value</span><span class="inv-mono">${fmt(jobValue)}</span></div>
      <div class="job-pl-row"><span class="col-ink2">Total Claimed (inc. GST)</span><span class="inv-mono">${fmt(totalClaimed)}</span></div>
      <div class="job-pl-row"><span class="col-ink2">Remaining</span><span class="inv-mono" style="color:${jobValue-totalClaimed>=0?'var(--green)':'var(--red)'}">${fmt(jobValue-totalClaimed)}</span></div>
      ${claimedPct !== null ? `<div class="job-budget-bar" style="margin-top:6px"><div style="height:100%;width:${Math.min(claimedPct,100)}%;background:${claimedPct>=100?'var(--red)':'var(--accent)'};border-radius:4px"></div></div>
      <div style="font-size:11px;color:var(--ink3);margin-top:4px">${claimedPct}% claimed</div>` : ''}
    </div>` : '';

  // Hourly tasks go on as text lines under one labour line for the job's
  // unbilled visit hours (core/job_billing.py hourly_task_lines).
  const uninvoicedTasks = wrkTasks.filter(t => t.is_done && !t.invoice_id);
  const hasHourly   = uninvoicedTasks.some(t => t.billing === 'hourly');
  const labourHrs   = Math.round((_jobDetail?.visits || []).filter(v => !v.invoice_id && v.hours > 0)
                        .reduce((s, v) => s + (+v.hours), 0) * 100) / 100;
  const invoicedTasks   = wrkTasks.filter(t => t.is_done && t.invoice_id);
  const uninvoicedIds   = uninvoicedTasks.map(t => t.id);
  // POs flagged "Charge to customer" — they go on the same invoice
  // (core/jobs.py _invoice_tasks → job_billing.flagged_materials).
  const chargePos = (_jobDetail?.pos || []).filter(p => p.charge_customer && !p.charged_invoice_number
                      && p.status !== 'Cancelled')
                      .sort((a, b) => (a.po_date || '').localeCompare(b.po_date || '') || a.id - b.id);

  const taskRowClaim = t => t.billing === 'hourly' ? `
    <div class="task-detail-row">
      <div class="task-row-body">
        <div class="task-title">${esc(t.title)}</div>
        <div class="task-meta">Hourly — goes on as a text line under the labour</div>
      </div>
      <span class="task-billable-badge task-hourly-badge">Hourly</span>
    </div>` : `
    <div class="task-detail-row">
      <div class="task-row-body">
        <div class="task-title">${esc(t.title)}</div>
        <div class="task-meta">${t.qty_invoiced > 0
          ? `${+t.qty_invoiced} of ${+t.qty} already billed — remaining ${fmt(_jobTaskRemaining(t))}`
          : `${fmt(t.unit_price||0)} × ${t.qty||1} = ${fmt((t.unit_price||0)*(t.qty||1))}`}</div>
      </div>
      <span class="task-billable-badge">${fmt(_jobTaskRemaining(t))}</span>
    </div>`;

  const taskSectionHtml = (uninvoicedTasks.length || invoicedTasks.length) ? `
    <div class="wt-section-hdr" style="margin-top:16px">Billable Tasks</div>
    ${uninvoicedTasks.map(taskRowClaim).join('')}
    ${hasHourly ? `
    <div class="task-detail-row">
      <div class="task-row-body">
        <div class="task-title">Labour — visit hours not yet billed</div>
        <div class="task-meta">${labourHrs
          ? (job.hourly_rate ? `${labourHrs} hrs @ ${fmt(job.hourly_rate)}/hr` : `${labourHrs} hrs — set an hourly rate on the job to bill them`)
          : 'No hours logged yet — use Log time on the hourly task'}</div>
      </div>
      ${labourHrs && job.hourly_rate ? `<span class="task-billable-badge">${fmt(labourHrs * job.hourly_rate)}</span>` : ''}
    </div>` : ''}
    ${uninvoicedTasks.length ? chargePos.map(p => `
    <div class="task-detail-row">
      <div class="task-row-body">
        <div class="task-title">Materials — ${esc(p.po_number)}</div>
        <div class="task-meta">Charge to customer · ${esc(p.contact_name_live||p.contact_name||'')} · cost ${fmt(p.subtotal||0)} + ${+(p.charge_markup ?? 15)}%</div>
      </div>
      <span class="po-charge-badge">To invoice</span>
    </div>`).join('') : ''}
    ${uninvoicedTasks.length ? `
      <div class="wt-invoice-bar">
        <label class="chk-label"><input type="checkbox" id="job-create-claim-chk"> Create claim</label>
        <button class="btn btn-primary btn-sm" onclick="_jobInvoiceTasks(${job.id},[${uninvoicedIds}])">
          Invoice ${uninvoicedTasks.length} completed task${uninvoicedTasks.length!==1?'s':''}
        </button>
      </div>` : ''}
    ${invoicedTasks.length ? `
      <div class="wt-section-hdr wt-section-invoiced">Invoiced Tasks</div>
      ${invoicedTasks.map(t => `
        <div class="task-detail-row is-void">
          <div class="task-row-body">
            <div class="task-title-done">${esc(t.title)}</div>
            <div class="task-meta">${t.billing === 'hourly' ? 'Hourly — charged via visit hours' : `${fmt(t.unit_price||0)} × ${t.qty||1}`}</div>
          </div>
          ${t.invoice_id ? `<button class="btn btn-outline btn-sm-outline" onclick="detClose();setTimeout(()=>{navigate('invoices');setTimeout(()=>invOpen(${t.invoice_id}),400)},200)">View Invoice</button>` : ''}
        </div>`).join('')}` : ''}
  ` : '';

  // ── Billing health (shown when no claims exist) ───────────────────────────
  let noClainsHtml = '';
  if (!claims.length) {
    const invTxns      = (txns || []).filter(t => t.source_type === 'invoice');
    const totalInvoiced = pl?.revenue || 0;

    if (!invTxns.length) {
      noClainsHtml = `
        <div class="job-billing-health">
          <div class="job-bh-title">No invoices on this job yet.</div>
          <div class="job-bh-note">Progress claims suit contract jobs with milestone billing.
          For a single invoice at completion, raise it directly from Invoices.</div>
        </div>`;
    } else {
      const invRows = invTxns.map(t => `
        <div class="job-pl-row">
          <span class="col-ink2">${esc(t.ref_number||'Invoice')} · ${fmtDate(t.txn_date)}</span>
          <span class="inv-mono">${fmt(t.amount||0)}</span>
        </div>`).join('');
      const valueRows = jobValue ? `
        <div class="job-pl-row job-bh-divider">
          <span class="col-ink2">Job Value</span>
          <span class="inv-mono">${fmt(jobValue)}</span>
        </div>
        <div class="job-pl-row">
          <span class="col-ink2">Total Invoiced</span>
          <span class="inv-mono">${fmt(totalInvoiced)}</span>
        </div>
        <div class="job-pl-row">
          <span class="col-ink2">Difference</span>
          <span class="inv-mono">${fmt(totalInvoiced - jobValue)}</span>
        </div>` : `
        <div class="job-pl-row job-bh-divider">
          <span class="col-ink2">Total Invoiced</span>
          <span class="inv-mono">${fmt(totalInvoiced)}</span>
        </div>`;
      noClainsHtml = `
        <div class="job-pl-card" style="margin-bottom:12px">
          <div class="job-bh-title" style="margin-bottom:8px">Billing Summary</div>
          ${invRows}
          ${valueRows}
          <div class="job-bh-note" style="margin-top:10px">
            This job is already invoiced directly.
            Use progress claims only if you need milestone-based billing.
          </div>
        </div>`;
    }
  }

  el.innerHTML = `
    <div class="tab-add-row job-sticky-toolbar">
      <button class="btn btn-outline btn-sm-outline" onclick="_jobClaimBuilder(${job.id})">+ New Claim</button>
      <button class="btn btn-outline btn-sm-outline jcb-manual-btn" onclick="_jobNewClaim(${job.id},${job.contact_id||'null'},${jobValue},${totalClaimed})">Manual claim</button>
    </div>
    ${summaryHtml}
    ${rows || noClainsHtml}
    ${taskSectionHtml}`;
}

// ── Claim builder ─────────────────────────────────────────────────────────────
// One claim from everything unbilled on the job: fixed-price tasks (whole or
// part, by qty to date), labour from visit hours × rate, completed hourly
// tasks listed as notes, and materials. Creates a Draft invoice + claim via
// core/job_billing.py: build_claim_invoice — the server re-checks everything.
let _jcbData = null;

const _jcbR2 = n => Math.round((n + Number.EPSILON) * 100) / 100;

// Mirror of core/job_billing.py: to_date_amount — keep the two in step.
function _jcbTaskAmount(t, qtyToDate) {
  if (!(qtyToDate > t.qty_billed)) return 0;
  const toDate = qtyToDate >= t.qty ? t.contract : _jcbR2(t.contract * qtyToDate / t.qty);
  return _jcbR2(toDate - t.amount_billed);
}

window._jobClaimBuilder = async function(jobId) {
  const body = document.getElementById('det-body');
  body.innerHTML = '<div class="state-loading">Loading…</div>';
  document.getElementById('det-foot').innerHTML = '';
  try { _jcbData = await apiFetch(`/api/jobs/${jobId}/claim-builder`); }
  catch(e) { body.innerHTML = `<div class="state-error">${esc(e.message)}</div>`; return; }
  const d = _jcbData;
  if (!d.job.contact_id) {
    body.innerHTML = '<div class="state-error">This job has no client. Set one on the job before raising a claim.</div>';
    document.getElementById('det-foot').innerHTML = `<button class="btn btn-outline" onclick="_jobRenderDetail()">Back</button>`;
    return;
  }

  const taskRows = d.fixed_tasks.map(t => {
    const part  = t.qty_billed > 0;
    const defQ  = t.is_done ? t.qty : '';
    return `<tr>
      <td class="jcb-chk"><input type="checkbox" class="jcb-task" data-id="${t.id}"${t.is_done ? ' checked' : ''} onchange="this.dataset.manual='1';_jcbRecalc()"></td>
      <td>${esc(t.title)}
        <div class="jcb-sub">${fmt(t.unit_price)} × ${+t.qty} = ${fmt(t.contract)}${part ? ` · ${+t.qty_billed} already billed` : ''}${t.is_done ? '' : ' · in progress'}</div></td>
      <td class="jcb-qty-cell">
        <input class="edt-inp jcb-qty" type="number" step="any" min="${t.qty_billed}" max="${t.qty}" data-id="${t.id}"
          value="${defQ}" placeholder="${part ? '> ' + (+t.qty_billed) : 'qty'}" oninput="_jcbTaskQtyInput(this)">
        <span class="jcb-sub">of ${+t.qty}</span></td>
      <td class="td-r-mono" id="jcb-task-amt-${t.id}">—</td>
    </tr>`;
  }).join('');

  // Visits: ticking one fills in the tasks from the work recorded on it
  // (Visits tab → Tasks). Past visits with work or hours start ticked.
  const today = isoToday();
  const visitRows = d.visits.map(v => {
    const hasHrs = v.hours > 0;
    const time = v.all_day || !v.start_time ? 'All day' : `${v.start_time}–${v.end_time || ''}`;
    const work = (v.work || []).map(w =>
      w.billing === 'fixed' && (+w.qty) > 1 && (+w.qty_done) > 0 && !w.completed
        ? `${+w.qty_done} × ${esc(w.title)}` : `✓ ${esc(w.title)}`).join(', ');
    const def = v.event_date <= today && (hasHrs || (v.work || []).length);
    return `<tr>
      <td class="jcb-chk"><input type="checkbox" class="jcb-visit" data-id="${v.id}" data-hours="${v.hours || 0}"
        ${def ? 'checked' : ''} onchange="_jcbVisitsChanged()"></td>
      <td>${fmtDate(v.event_date)} <span class="jcb-sub">${esc(time)}</span>
        <div class="jcb-sub">${work || 'no work recorded'}</div></td>
      <td class="td-r-mono" id="jcb-visit-hrs-${v.id}">${hasHrs ? (+v.hours).toFixed(2) + ' hrs' : '<span class="jcb-sub">no hours</span>'}</td>
    </tr>`;
  }).join('');

  const hourlyRows = d.hourly_tasks.map(t => `<tr>
      <td class="jcb-chk"><input type="checkbox" class="jcb-hourly" data-id="${t.id}"${t.is_done ? ' checked' : ''} onchange="this.dataset.manual='1'"></td>
      <td>${esc(t.title)}${t.is_done ? '' : ' <span class="jcb-sub">· not marked done</span>'}</td>
    </tr>`).join('');

  const m = d.materials;
  const matRows = [
    // Flagged "Charge to customer" on the PO — ticked, like logged time,
    // itemised at the PO's own markup.
    ...(m.flagged || []).map(f => `<tr>
      <td class="jcb-chk"><input type="checkbox" class="jcb-mat" data-type="po" data-id="${f.po_id}" data-sell="${f.sell}" checked onchange="_jcbRecalc()"></td>
      <td>${esc(f.po_number)} <span class="po-charge-badge">To invoice</span> <span class="jcb-sub">${esc(f.supplier||'')} · ${f.lines.length} line${f.lines.length!==1?'s':''} · cost ${fmt(f.cost)} + ${+f.markup}%</span></td>
      <td class="td-r-mono">${fmt(f.sell)}</td></tr>`),
    ...m.bom.map(b => `<tr>
      <td class="jcb-chk"><input type="checkbox" class="jcb-mat" data-type="bom" data-id="${b.id}" data-sell="${_jcbR2((b.qty||0)*(b.unit_price||0))}" onchange="_jcbRecalc()"></td>
      <td>${esc(b.description)} <span class="jcb-sub">materials list · ${+b.qty} × ${fmt(b.unit_price||0)}</span></td>
      <td class="td-r-mono">${fmt(_jcbR2((b.qty||0)*(b.unit_price||0)))}</td></tr>`),
    ...m.bills.map(b => `<tr>
      <td class="jcb-chk"><input type="checkbox" class="jcb-mat" data-type="bill" data-id="${b.id}" data-cost="${b.subtotal||0}" onchange="_jcbRecalc()"></td>
      <td>${esc(b.bill_number)} <span class="jcb-sub">bill · ${esc(b.contact_name||'')} · cost ${fmt(b.subtotal||0)}</span></td>
      <td class="td-r-mono jcb-mat-sell" data-type="bill" data-id="${b.id}">—</td></tr>`),
    ...m.pos.map(p => `<tr>
      <td class="jcb-chk"><input type="checkbox" class="jcb-mat" data-type="po" data-id="${p.id}" data-cost="${p.subtotal||0}" onchange="_jcbRecalc()"></td>
      <td>${esc(p.po_number)} <span class="jcb-sub">purchase order · ${esc(p.contact_name||'')} · cost ${fmt(p.subtotal||0)}</span></td>
      <td class="td-r-mono jcb-mat-sell" data-type="po" data-id="${p.id}">—</td></tr>`),
  ].join('');
  const hasCostMats = m.bills.length + m.pos.length > 0;

  const section = (title, inner, extra = '') => `
    <div class="jcb-section">
      <div class="job-section-row"><div class="job-section-hdr">${title}</div>${extra}</div>
      ${inner}
    </div>`;
  const empty = msg => `<div class="jcb-empty">${msg}</div>`;

  body.innerHTML = `
    <h3 class="form-section-hdr">New Progress Claim</h3>
    <div class="edt-grid">
      <div class="edt-field"><label class="edt-lbl">Claim Date</label>
        <input class="edt-inp" id="jcb-date" type="date" value="${isoToday()}"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Description</label>
        <input class="edt-inp" id="jcb-desc" placeholder="Leave blank to describe it automatically"></div>
    </div>

    ${section('Visits',
      d.visits.length ? `<table class="inv-list-table tbl-sm jcb-tbl"><tbody>${visitRows}</tbody></table>
        <div class="jcb-total-line"><span id="jcb-lab-sum">—</span><span class="td-r-mono" id="jcb-lab-amt">—</span></div>
        <div class="jcb-hint">Ticking a visit fills in the tasks from the work recorded on it. Leave <b>Include time</b> off when the time is built into your prices — those hours are then marked <b>not charged</b> and won't be offered again.</div>`
      : empty('No unclaimed visits. Add visits on the Visits tab.'),
      d.visits.length ? `<span class="jcb-inline"><label class="jcb-time-lbl"><input type="checkbox" id="jcb-time"${d.job.hourly_rate ? ' checked' : ''} onchange="_jcbRecalc()"> Include time on invoice</label>
          <span id="jcb-rate-wrap">· Rate $<input class="edt-inp jcb-rate" id="jcb-rate" type="number" step="0.01" min="0"
          value="${d.job.hourly_rate ?? ''}" placeholder="per hr" oninput="_jcbRecalc()"> /hr</span></span>` : '')}

    ${section('Fixed-price tasks',
      d.fixed_tasks.length ? `<table class="inv-list-table tbl-sm jcb-tbl"><tbody>${taskRows}</tbody></table>
        <div class="jcb-hint">For work in progress, enter the quantity completed <b>to date</b> — the amount is the value done so far less what's already been billed.</div>`
      : empty('No fixed-price tasks left to bill.'))}

    ${d.hourly_tasks.length ? section('Hourly tasks — listed as done',
      `<table class="inv-list-table tbl-sm jcb-tbl"><tbody>${hourlyRows}</tbody></table>`) : ''}

    ${section('Materials',
      matRows ? `<table class="inv-list-table tbl-sm jcb-tbl"><tbody>${matRows}</tbody></table>`
      : empty('No unbilled materials.'),
      hasCostMats ? `<label class="jcb-inline">Markup <input class="edt-inp jcb-rate" id="jcb-margin" type="number" step="1" min="0"
          value="15" oninput="_jcbRecalc()"> % on bills/POs</label>` : '')}

    <div class="job-pl-card jcb-totals">
      <div class="job-pl-row"><span class="col-ink2">This claim (ex GST)</span><span class="inv-mono" id="jcb-ex">—</span></div>
      <div class="job-pl-row"><span class="col-ink2">${d.gst_registered ? 'GST' : 'GST (not registered)'}</span><span class="inv-mono" id="jcb-gst">—</span></div>
      <div class="job-pl-row jcb-grand"><span>This claim (inc GST)</span><span class="inv-mono" id="jcb-inc">—</span></div>
      ${d.job.value ? `
      <div class="job-pl-row job-bh-divider"><span class="col-ink2">Claimed before this</span><span class="inv-mono">${fmt(d.claimed_inc_gst)}</span></div>
      <div class="job-pl-row"><span class="col-ink2">Job value</span><span class="inv-mono">${fmt(d.job.value)}</span></div>
      <div class="job-pl-row"><span class="col-ink2">Remaining after this claim</span><span class="inv-mono" id="jcb-remaining">—</span></div>` : ''}
    </div>`;

  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-primary" id="jcb-save" onclick="_jcbCreate(${jobId})">Create Claim &amp; Draft Invoice</button>
    <button class="btn btn-outline" onclick="_jobNewClaim(${jobId},${d.job.contact_id},${d.job.value||0},${d.claimed_inc_gst||0})">Manual claim</button>
    <button class="btn btn-outline ml-auto" onclick="_jobRenderDetail()">Cancel</button>`;
  _jcbVisitsChanged();
};

window._jcbTaskQtyInput = function(inp) {
  inp.dataset.manual = '1';
  const chk = document.querySelector(`.jcb-task[data-id="${inp.dataset.id}"]`);
  if (chk) chk.checked = inp.value !== '';
  _jcbRecalc();
};

// Fill tasks from the work recorded on the ticked visits: a quantity task
// goes to (already billed + qty done on those visits); a task ticked Done on
// one of them is claimed in full. Only tasks that have visit work are
// touched, and never one the user has already adjusted by hand.
window._jcbVisitsChanged = function() {
  const d = _jcbData; if (!d) return;
  const ticked = new Set([...document.querySelectorAll('.jcb-visit:checked')].map(c => +c.dataset.id));
  const onVisits = new Set(), prog = {}, done = {};
  d.visits.forEach(v => (v.work || []).forEach(w => {
    onVisits.add(w.task_id);
    if (!ticked.has(v.id)) return;
    prog[w.task_id] = (prog[w.task_id] || 0) + (+w.qty_done || 0);
    if (w.completed) done[w.task_id] = true;
  }));
  d.fixed_tasks.forEach(t => {
    if (!onVisits.has(t.id)) return;
    const chk = document.querySelector(`.jcb-task[data-id="${t.id}"]`);
    const inp = document.querySelector(`.jcb-qty[data-id="${t.id}"]`);
    if (chk.dataset.manual || inp.dataset.manual) return;
    const q = done[t.id] ? t.qty : (prog[t.id] ? Math.min(t.qty, t.qty_billed + prog[t.id]) : 0);
    chk.checked = q > t.qty_billed;
    inp.value = chk.checked ? +q.toFixed(4) : '';
  });
  d.hourly_tasks.forEach(t => {
    if (!onVisits.has(t.id)) return;
    const c = document.querySelector(`.jcb-hourly[data-id="${t.id}"]`);
    if (c && !c.dataset.manual) c.checked = !!done[t.id];
  });
  _jcbRecalc();
};

// Build the selection sent to the server (and used for the preview totals).
function _jcbSpec() {
  const d = _jcbData;
  const tasks = [...document.querySelectorAll('.jcb-task:checked')].map(c => {
    const t = d.fixed_tasks.find(x => x.id === +c.dataset.id);
    const v = document.querySelector(`.jcb-qty[data-id="${c.dataset.id}"]`).value;
    return { id: t.id, qty_to_date: v === '' ? t.qty : Math.min(parseFloat(v), t.qty) };
  });
  return {
    claim_date:      document.getElementById('jcb-date').value,
    description:     document.getElementById('jcb-desc').value.trim(),
    tasks,
    visit_ids:       [...document.querySelectorAll('.jcb-visit:checked')].map(c => +c.dataset.id),
    include_time:    !!document.getElementById('jcb-time')?.checked,
    hourly_rate:     document.getElementById('jcb-rate')?.value || null,
    hourly_task_ids: [...document.querySelectorAll('.jcb-hourly:checked')].map(c => +c.dataset.id),
    materials:       [...document.querySelectorAll('.jcb-mat:checked')].map(c => ({ type: c.dataset.type, id: +c.dataset.id })),
    margin_pct:      parseFloat(document.getElementById('jcb-margin')?.value) || 0,
  };
}

window._jcbRecalc = function() {
  const d = _jcbData; if (!d) return;
  const lines = [];
  d.fixed_tasks.forEach(t => {
    const chk = document.querySelector(`.jcb-task[data-id="${t.id}"]`);
    const v   = document.querySelector(`.jcb-qty[data-id="${t.id}"]`).value;
    const q   = v === '' ? t.qty : Math.min(parseFloat(v), t.qty);
    const amt = chk.checked ? _jcbTaskAmount(t, q) : 0;
    const cell = document.getElementById(`jcb-task-amt-${t.id}`);
    cell.textContent = chk.checked ? (amt > 0 ? fmt(amt) : 'nothing new') : '—';
    cell.classList.toggle('jcb-warn', chk.checked && !(amt > 0));
    if (chk.checked && amt > 0) lines.push(amt);
  });

  const withTime = !!document.getElementById('jcb-time')?.checked;
  const rate = parseFloat(document.getElementById('jcb-rate')?.value) || 0;
  const tickedVisits = [...document.querySelectorAll('.jcb-visit:checked')];
  const hrs  = tickedVisits.reduce((s, c) => s + (+c.dataset.hours), 0);
  const rw = document.getElementById('jcb-rate-wrap');
  if (rw) rw.style.display = withTime ? '' : 'none';
  // With time on, a ticked visit with no hours can't be billed — flag it.
  document.querySelectorAll('.jcb-visit').forEach(c =>
    document.getElementById(`jcb-visit-hrs-${c.dataset.id}`)?.classList.toggle('jcb-warn', withTime && c.checked && !(+c.dataset.hours > 0)));
  if (document.getElementById('jcb-lab-sum')) {
    document.getElementById('jcb-lab-sum').textContent = !tickedVisits.length ? 'No visits selected'
      : withTime ? `Labour: ${_jcbR2(hrs)} hrs × ${rate ? fmt(rate) : '(set a rate)'}`
      : `${_jcbR2(hrs)} hrs — not charged (built into prices)`;
    document.getElementById('jcb-lab-amt').textContent = withTime && hrs && rate ? fmt(_jcbR2(hrs * rate)) : '—';
  }
  if (withTime && hrs && rate) lines.push(_jcbR2(hrs * rate));

  const margin = parseFloat(document.getElementById('jcb-margin')?.value) || 0;
  document.querySelectorAll('.jcb-mat').forEach(c => {
    // BOM lines and flagged POs carry their own sell price; bills/POs get the markup.
    const sell = c.dataset.sell !== undefined ? +c.dataset.sell : _jcbR2((+c.dataset.cost) * (1 + margin / 100));
    const cell = document.querySelector(`.jcb-mat-sell[data-type="${c.dataset.type}"][data-id="${c.dataset.id}"]`);
    if (cell) cell.textContent = fmt(sell);
    if (c.checked) lines.push(sell);
  });

  const ex  = _jcbR2(lines.reduce((s, a) => s + a, 0));
  const gst = d.gst_registered ? _jcbR2(lines.reduce((s, a) => s + _jcbR2(a * 0.1), 0)) : 0;
  document.getElementById('jcb-ex').textContent  = fmt(ex);
  document.getElementById('jcb-gst').textContent = fmt(gst);
  document.getElementById('jcb-inc').textContent = fmt(_jcbR2(ex + gst));
  const rem = document.getElementById('jcb-remaining');
  if (rem) {
    const left = _jcbR2(d.job.value - d.claimed_inc_gst - ex - gst);
    rem.textContent = fmt(left);
    rem.classList.toggle('jcb-warn', left < 0);
  }
  document.getElementById('jcb-save').disabled = !(ex > 0);
};

window._jcbCreate = async function(jobId) {
  const spec = _jcbSpec();
  if (spec.visit_ids.length && spec.include_time && !(parseFloat(spec.hourly_rate) > 0)) { toast('Enter an hourly rate for the labour, or untick Include time', 'err'); return; }
  const btn = document.getElementById('jcb-save');
  btn.disabled = true; btn.textContent = 'Creating…';
  try {
    const r = await fetch(`/api/jobs/${jobId}/claim-builder`, {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(spec),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Could not create the claim');
    toast(`${j.data.claim_number} created — draft invoice ${fmt(j.data.total)}`);
    _jcbData = null;
    await _jobRefreshDetail(jobId, 'claims');
    window._calRefreshJobs?.();
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = 'Create Claim & Draft Invoice';
  }
};

window._jobNewClaim = function(jobId, contactId, jobValue, prevClaimedIncGst) {
  const valueHint = jobValue ? `<div style="font-size:11px;color:var(--ink3);margin-top:4px">Job value: ${fmt(jobValue)} inc. GST</div>` : '';
  document.getElementById('det-body').innerHTML = `
    <div class="det-tabs" id="job-tabs" style="display:none"></div>
    <div id="job-tab-content">
    <h3 class="form-section-hdr">New Progress Claim</h3>
    <div class="edt-grid">
      <div class="edt-field"><label class="edt-lbl">Claim Date *</label>
        <input class="edt-inp" id="clm-date" type="date" value="${isoToday()}"></div>
      <div class="edt-field"><label class="edt-lbl">Amount ex-GST *</label>
        <input class="edt-inp" id="clm-amount" type="number" step="0.01" min="0" placeholder="0.00"
          oninput="_clmAutoCalcPct(${jobValue||0},${prevClaimedIncGst||0})">
        ${valueHint}</div>
      <div class="edt-field edt-span"><label class="edt-lbl">Description</label>
        <input class="edt-inp" id="clm-desc" placeholder="Work completed this claim period"></div>
      <div class="edt-field"><label class="edt-lbl">Cumulative % Claimed</label>
        <input class="edt-inp" id="clm-pct" type="number" step="0.1" min="0" max="100" placeholder="0"></div>
    </div></div>`;
  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-primary" id="clm-save-btn" onclick="_jobSaveClaim(${jobId},${contactId||'null'})">Create Claim</button>
    <button class="btn btn-outline" onclick="_jobRenderDetail()">Cancel</button>`;
  document.getElementById('clm-amount')?.focus();
};

// Cumulative = all earlier claims on the job + this one, as % of job value
window._clmAutoCalcPct = function(jobValueIncGst, prevClaimedIncGst) {
  if (!jobValueIncGst) return;
  const ex  = parseFloat(document.getElementById('clm-amount')?.value || 0);
  const inc = (prevClaimedIncGst || 0) + ex * 1.1;
  const pct = Math.round(inc / jobValueIncGst * 1000) / 10;
  const el  = document.getElementById('clm-pct');
  if (el) el.value = pct > 0 ? pct : '';
};

window._jobSaveClaim = async function(jobId, contactId) {
  const date   = document.getElementById('clm-date')?.value;
  const amount = parseFloat(document.getElementById('clm-amount')?.value || 0);
  if (!date || !amount) { toast('Date and amount are required', 'err'); return; }
  const btn = document.getElementById('clm-save-btn');
  btn.disabled = true; btn.textContent = 'Saving…';
  try {
    const r = await fetch('/api/crm/claims', {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        job_id:        jobId,
        contact_id:    contactId || null,
        claim_date:    date,
        amount_ex_gst: amount,
        description:   document.getElementById('clm-desc')?.value.trim() || '',
        cumulative_pct:parseFloat(document.getElementById('clm-pct')?.value || 0),
        tax_code:      'GST',
      }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    toast('Claim created');
    await _jobRefreshDetail(jobId, 'claims');
  } catch(e) { toast(e.message, 'err'); btn.disabled = false; btn.textContent = 'Create Claim'; }
};

window._jobConvertClaim = async function(cid, jobId) {
  if (!await confirmDlg('Convert this progress claim to a draft invoice?')) return;
  try {
    const r = await fetch(`/api/crm/claims/${cid}/convert`, { method:'POST', credentials:'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed');
    toast('Invoice created — opening…');
    detClose();
    _jobAll = await apiFetch('/api/jobs') || _jobAll;
    const claimInvId = j.data.invoice_id;
    navigate('invoices');
    setTimeout(async () => {
      const invData = await apiFetch(`/api/invoices/${claimInvId}`);
      if (!invData) { toast('Invoice not found', 'err'); return; }
      document.getElementById('det-overlay').classList.add('open');
      document.getElementById('det-panel').classList.add('open');
      document.getElementById('det-title').textContent = 'Invoice';
      document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading…</div>';
      document.getElementById('det-foot').innerHTML = '';
      await invEditOpen(invData);
    }, 500);
  } catch(e) { toast(e.message, 'err'); }
};

window._jobLinkInvoiceToClaim = async function(cid, jobId) {
  const contactId = _jobDetail?.job?.contact_id;
  if (!contactId) { toast('Job has no contact', 'err'); return; }
  let invoices = [];
  try {
    const all = await apiFetch('/api/invoices');
    invoices = all.filter(i =>
      i.contact_id === contactId &&
      !['Void', 'Voided', 'Written Off'].includes(i.status)
    );
  } catch(e) {
    toast('Could not load invoices', 'err');
    return;
  }
  if (!invoices.length) {
    toast('No invoices found for this contact', 'err');
    return;
  }
  const opts = invoices.map(i =>
    `<option value="${i.id}">${esc(i.invoice_number)} — ${fmtDate(i.invoice_date)} — ${fmt(i.total||0)} (${esc(i.status)})</option>`
  ).join('');
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:min(460px,96vw)">
    <div class="modal-title">Link Invoice to Claim</div>
    <div class="modal-field"><label class="modal-lbl">Invoice</label>
      <select class="modal-inp" id="clm-inv-sel">${opts}</select></div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary btn-sm" id="clm-inv-btn" onclick="_jobDoLinkInvoice(${cid},${jobId})">Link Invoice</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
};

window._jobDoLinkInvoice = async function(cid, jobId) {
  const invId = parseInt(document.getElementById('clm-inv-sel')?.value);
  if (!invId) { toast('Select an invoice', 'err'); return; }
  const btn = document.getElementById('clm-inv-btn');
  btn.disabled = true; btn.textContent = 'Linking…';
  try {
    const r = await fetch(`/api/crm/claims/${cid}/link-invoice`, {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ invoice_id: invId }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed');
    btn.closest('.modal-bd')?.remove();
    toast('Invoice linked');
    await _jobRefreshDetail(jobId, 'claims');
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = 'Link Invoice';
  }
};

window._jobInvoiceExpenses = function(jobId) {
  if (!_jobDetail) return;
  const { job, bills, pos } = _jobDetail;
  // Bills/POs already charged to the customer (here or as a BOM line) are
  // left out — the server refuses them too (core/job_billing.py).
  const blk = _jobDetail.recharge_blocked || { bill: [], po: [] };
  const billItems = (bills||[]).filter(b => !['Void','Voided'].includes(b.status) && !blk.bill.includes(b.id));
  const poItems   = (pos||[]).filter(p => !['Cancelled','Billed'].includes(p.status) && !blk.po.includes(p.id));
  if (!billItems.length && !poItems.length) {
    toast('No expenses left to charge on this job', 'err');
    return;
  }
  const DFLT_MARGIN = 15;
  const makeRow = (type, item) => {
    const ref  = type === 'bill' ? (item.bill_number||'—') : (item.po_number||'—');
    const name = item.contact_name || item.contact_name_live || '—';
    const cost = item.subtotal || 0;
    return `<tr>
      <td style="width:28px;padding:6px 4px">
        <input type="checkbox" class="exp-chk" data-type="${type}" data-id="${item.id}" data-cost="${cost}" checked style="width:14px;height:14px;accent-color:var(--accent)">
      </td>
      <td><span class="job-src-badge job-src-${type}">${type==='bill'?'Bill':'PO'}</span></td>
      <td class="inv-mono">${esc(ref)}</td>
      <td style="font-size:13px">${esc(name)}</td>
      <td class="td-r-mono">${fmt(cost)}</td>
      <td class="td-r-mono exp-sell-cell" data-type="${type}" data-id="${item.id}">—</td>
    </tr>`;
  };
  const rows = [
    ...billItems.map(b => makeRow('bill', b)),
    ...poItems.map(p => makeRow('po', p)),
  ].join('');
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="min-width:560px;max-width:700px">
    <div class="modal-hdr">Invoice Job Expenses</div>
    <div class="modal-body">
      <div class="job-exp-margin-row">
        <label class="modal-lbl" style="margin:0">Markup margin</label>
        <input class="modal-inp" id="exp-margin" type="number" min="0" max="999" step="1" value="${DFLT_MARGIN}" style="width:90px">
        <span class="col-ink3" style="font-size:13px">%</span>
        <span style="font-size:12px;color:var(--ink3);margin-left:8px">Sell = cost × (1 + margin%)</span>
      </div>
      <table class="inv-list-table" style="margin-bottom:12px">
        <thead><tr>
          <th style="width:28px"></th>
          <th>Type</th><th>Ref</th><th>Supplier</th>
          <th class="th-r">Cost (ex-GST)</th>
          <th class="th-r">Sell (ex-GST)</th>
        </tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="job-exp-total-row">
        <span>Invoice total (ex-GST)</span>
        <span class="inv-mono" id="exp-grand-total">—</span>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-outline" id="exp-cancel-btn">Cancel</button>
      <button class="btn btn-primary" id="exp-confirm-btn">Create Invoice</button>
    </div>
  </div>`;
  document.body.appendChild(bd);

  function recalc() {
    const margin = parseFloat(document.getElementById('exp-margin').value) || 0;
    let grand = 0;
    bd.querySelectorAll('.exp-chk').forEach(chk => {
      const cost = parseFloat(chk.dataset.cost) || 0;
      const sell = chk.checked ? cost * (1 + margin / 100) : 0;
      const cell = bd.querySelector(`.exp-sell-cell[data-type="${chk.dataset.type}"][data-id="${chk.dataset.id}"]`);
      if (cell) cell.textContent = chk.checked ? fmt(sell) : '—';
      if (chk.checked) grand += sell;
    });
    document.getElementById('exp-grand-total').textContent = fmt(grand);
  }
  recalc();
  bd.querySelector('#exp-margin').addEventListener('input', recalc);
  bd.querySelectorAll('.exp-chk').forEach(c => c.addEventListener('change', recalc));
  bd.querySelector('#exp-cancel-btn').addEventListener('click', () => bd.remove());
  bd.addEventListener('click', e => { if (e.target === bd) bd.remove(); });
  bd.querySelector('#exp-confirm-btn').addEventListener('click', async () => {
    const margin = parseFloat(document.getElementById('exp-margin').value) || 0;
    const items = [];
    bd.querySelectorAll('.exp-chk:checked').forEach(chk => {
      items.push({ type: chk.dataset.type, id: parseInt(chk.dataset.id), cost: parseFloat(chk.dataset.cost)||0 });
    });
    if (!items.length) { toast('Select at least one expense', 'err'); return; }
    const btn = bd.querySelector('#exp-confirm-btn');
    btn.disabled = true; btn.textContent = 'Creating…';
    try {
      const r = await fetch(`/api/jobs/${jobId}/invoice_from_expenses`, {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ margin_pct: margin, items }),
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Failed');
      bd.remove();
      toast('Invoice created — opening…');
      const expInvId = j.data.invoice_id;
      navigate('invoices');
      setTimeout(async () => {
        const invData = await apiFetch(`/api/invoices/${expInvId}`);
        if (!invData) { toast('Invoice not found', 'err'); return; }
        document.getElementById('det-overlay').classList.add('open');
        document.getElementById('det-panel').classList.add('open');
        document.getElementById('det-title').textContent = 'Invoice';
        document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading…</div>';
        document.getElementById('det-foot').innerHTML = '';
        await invEditOpen(invData);
      }, 500);
    } catch(e) {
      toast(e.message, 'err');
      btn.disabled = false; btn.textContent = 'Create Invoice';
    }
  });
};


window._jobSubmitClaim = async function(cid, jobId) {
  if (!await confirmDlg('Mark this claim as submitted to the client?')) return;
  try {
    const r = await fetch(`/api/crm/claims/${cid}`, {
      method: 'PUT', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'Claimed' }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed');
    toast('Claim marked as submitted');
    await _jobRefreshDetail(jobId, 'claims');
  } catch(e) { toast(e.message, 'err'); }
};

window._jobDelClaim = async function(cid, jobId) {
  if (!await confirmDlg('Delete this progress claim?')) return;
  try {
    const r = await fetch(`/api/crm/claims/${cid}`, { method:'DELETE', credentials:'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Delete failed');
    toast('Deleted');
    await _jobRefreshDetail(jobId, 'claims');
  } catch(e) { toast(e.message, 'err'); }
};

// ── Materials / BOM tab ───────────────────────────────────────────────────────

function _jobBomStatus(line) {
  if (line.is_on_hand)           return { cls:'bom-st-onhand',  label:'On Hand' };
  if (line.is_customer_supplied) return { cls:'bom-st-client',  label:'Client — Awaiting' };
  if (line.po_id)                return { cls:'bom-st-ordered', label:`Ordered` };
  return                                { cls:'bom-st-pending',  label:'Pending' };
}

function _jobTabMaterials(el, bom, pos, job) {
  const totalCost  = bom.filter(l=>!l.is_customer_supplied).reduce((s,l)=>s+l.qty*l.unit_cost,0);
  const totalPrice = bom.filter(l=>!l.is_customer_supplied).reduce((s,l)=>s+l.qty*l.unit_price,0);
  const clientLines = bom.filter(l=>l.is_customer_supplied);
  const pending    = bom.filter(l=>!l.is_customer_supplied && !l.po_id && !l.is_on_hand);

  const rows = bom.length ? bom.map(line => {
    const st = _jobBomStatus(line);
    const poLink = line.po_id
      ? `<span class="bom-po-tag" title="PO: ${esc(line.po_number||'')}">
           <a href="#" onclick="detClose();setTimeout(()=>{navigate('purchase_orders');setTimeout(()=>_poOpenDet(${line.po_id}),400)},200);return false">${esc(line.po_number||'PO')}</a>
           <button class="bom-po-unlink" title="Unlink PO" onclick="_jobBomUnlinkPO(${line.id},${job.id})">✕</button>
         </span>`
      : (!line.is_customer_supplied
          ? `<button class="btn btn-xs btn-outline" onclick="_jobBomLinkPO(${line.id},${job.id})">Link PO</button>`
          : '—');
    return `<tr>
      <td>${esc(line.description)}</td>
      <td class="td-r-mono">${parseFloat(line.qty||1)%1===0 ? parseInt(line.qty) : parseFloat(line.qty).toFixed(2)}</td>
      <td class="td-r-mono">${line.is_customer_supplied ? '—' : fmt(line.unit_cost)}</td>
      <td class="td-r-mono">${line.is_customer_supplied ? '—' : fmt(line.unit_price)}</td>
      <td>${poLink}</td>
      <td>
        <span class="bom-status ${st.cls}">${st.label}</span>
      </td>
      <td style="white-space:nowrap">
        <button class="btn btn-xs ${line.is_on_hand ? 'bom-onhand-btn' : 'btn-outline'}"
                title="${line.is_on_hand ? 'Mark not on hand' : 'Mark on hand'}"
                onclick="_jobBomToggleOnHand(${line.id},${job.id})">
          ${line.is_on_hand ? '✓ On Hand' : 'On Hand?'}
        </button>
        <button class="btn btn-xs btn-outline" style="margin-left:4px"
                onclick="_jobBomEdit(${line.id},${job.id})">Edit</button>
        <button class="btn btn-xs btn-danger"  style="margin-left:4px"
                onclick="_jobBomDelete(${line.id},${job.id})">✕</button>
      </td>
    </tr>`;
  }).join('') : `<tr><td colspan="7" class="state-empty-sm">No materials added yet</td></tr>`;

  el.innerHTML = `
    <div class="purch-section">
      <div class="purch-section-hdr job-sticky-toolbar">
        <span class="purch-section-title">Bill of Materials</span>
        <div style="display:flex;gap:6px">
          ${pending.length ? `<button class="btn btn-sm btn-primary" onclick="_jobBomCreatePO(${job.id})">→ Create PO</button>` : ''}
          <button class="btn btn-sm btn-outline" onclick="window.open('/api/jobs/${job.id}/bom/pdf','_blank')">Print BOM</button>
          <button class="btn btn-sm btn-outline" onclick="_jobBomAdd(${job.id})">+ Add Material</button>
        </div>
      </div>
      <table class="inv-list-table bom-table">
        <thead><tr>
          <th>Description</th>
          <th class="th-r">Qty</th>
          <th class="th-r">Unit Cost</th>
          <th class="th-r">Unit Price</th>
          <th>PO</th>
          <th>Status</th>
          <th></th>
        </tr></thead>
        <tbody>${rows}</tbody>
      </table>
      ${bom.length ? `
      <div class="bom-totals">
        <div class="bom-total-card">
          <div class="bom-total-lbl">Our Cost</div>
          <div class="bom-total-val">${fmt(totalCost)}</div>
        </div>
        <div class="bom-total-card">
          <div class="bom-total-lbl">Billable</div>
          <div class="bom-total-val">${fmt(totalPrice)}</div>
        </div>
        ${totalPrice > totalCost ? `<div class="bom-total-card">
          <div class="bom-total-lbl">Margin</div>
          <div class="bom-total-val" style="color:var(--green)">${fmt(totalPrice - totalCost)}</div>
        </div>` : ''}
        ${clientLines.length ? `<div class="bom-total-card">
          <div class="bom-total-lbl">Client Supplied</div>
          <div class="bom-total-val" style="color:var(--ink2)">${clientLines.length} line${clientLines.length!==1?'s':''}</div>
        </div>` : ''}
        ${pending.length ? `<div class="bom-total-card" style="border-color:var(--amber)">
          <div class="bom-total-lbl" style="color:var(--amber)">Pending</div>
          <div class="bom-total-val" style="color:var(--amber)">${pending.length} line${pending.length!==1?'s':''}</div>
        </div>` : `<div class="bom-total-card" style="border-color:var(--green)">
          <div class="bom-total-lbl" style="color:var(--green)">Ready</div>
          <div class="bom-total-val" style="color:var(--green)">All actioned</div>
        </div>`}
      </div>` : ''}
    </div>`;
}

function _jobBomAdd(jobId) {
  _jobBomOpenModal(null, jobId);
}

function _jobBomEdit(lineId, jobId) {
  const line = (_jobDetail?.bom || []).find(l => l.id === lineId);
  if (!line) return;
  _jobBomOpenModal(line, jobId);
}

function _jobBomOpenModal(line, jobId) {
  document.getElementById('job-bom-modal')?.remove();
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'job-bom-modal';
  const isClient = line?.is_customer_supplied ? 'checked' : '';
  bd.innerHTML = `<div class="modal-box" style="max-width:480px">
    <div class="modal-hdr">
      <span>${line ? 'Edit Material' : 'Add Material'}</span>
      <button class="modal-close" onclick="document.getElementById('job-bom-modal').remove()">✕</button>
    </div>
    <div class="modal-body" style="padding:16px;display:flex;flex-direction:column;gap:12px">
      <div>
        <label class="form-lbl">Description *</label>
        <input class="form-inp" id="bom-desc" value="${esc(line?.description||'')}" placeholder="Material description">
      </div>
      <div style="display:flex;gap:12px">
        <div style="flex:1">
          <label class="form-lbl">Qty</label>
          <input class="form-inp" id="bom-qty" type="number" min="0.001" step="any" value="${line?.qty??1}">
        </div>
        <div style="flex:1" id="bom-cost-wrap">
          <label class="form-lbl">Unit Cost ($)</label>
          <input class="form-inp" id="bom-cost" type="number" min="0" step="0.01" value="${line?.unit_cost??0}">
        </div>
        <div style="flex:1" id="bom-price-wrap">
          <label class="form-lbl">Unit Price ($)</label>
          <input class="form-inp" id="bom-price" type="number" min="0" step="0.01" value="${line?.unit_price??0}">
        </div>
      </div>
      <label style="display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer">
        <input type="checkbox" id="bom-client" ${isClient} onchange="_jobBomClientToggle(this)">
        Customer supplied (no cost to us)
      </label>
      <div>
        <label class="form-lbl">Notes (optional)</label>
        <input class="form-inp" id="bom-notes" value="${esc(line?.notes||'')}" placeholder="Supplier, spec, etc.">
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-sec" onclick="document.getElementById('job-bom-modal').remove()">Cancel</button>
      <button class="btn btn-primary" onclick="_jobBomSave(${line?.id||'null'},${jobId})">
        ${line ? 'Save' : 'Add'}
      </button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  if (line?.is_customer_supplied) _jobBomClientToggle(bd.querySelector('#bom-client'));
  bd.querySelector('#bom-desc').focus();
}

function _jobBomClientToggle(cb) {
  const hide = cb.checked;
  document.getElementById('bom-cost-wrap') ?.style && (document.getElementById('bom-cost-wrap').style.display  = hide ? 'none' : '');
  document.getElementById('bom-price-wrap')?.style && (document.getElementById('bom-price-wrap').style.display = hide ? 'none' : '');
}

async function _jobBomSave(lineId, jobId) {
  const desc = (document.getElementById('bom-desc')?.value||'').trim();
  if (!desc) { toast('Description is required', 'err'); return; }
  const data = {
    id:                   lineId || undefined,
    job_id:               jobId,
    description:          desc,
    qty:                  parseFloat(document.getElementById('bom-qty')?.value||1),
    unit_cost:            parseFloat(document.getElementById('bom-cost')?.value||0),
    unit_price:           parseFloat(document.getElementById('bom-price')?.value||0),
    is_customer_supplied: document.getElementById('bom-client')?.checked ? 1 : 0,
    notes:                document.getElementById('bom-notes')?.value||'',
  };
  try {
    const r = await fetch(`/api/jobs/${jobId}/bom`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(data),
    }).then(r=>r.json());
    if (!r.ok) throw new Error(r.error||'Save failed');
    document.getElementById('job-bom-modal')?.remove();
    await _jobRefreshDetail(jobId, 'materials');
  } catch(e) {
    toast(e.message||'Save failed', 'err');
  }
}

async function _jobBomDelete(lineId, jobId) {
  if (!confirm('Remove this material from the BOM?')) return;
  try {
    const r = await fetch(`/api/jobs/bom/${lineId}`, {method:'DELETE'}).then(r=>r.json());
    if (!r.ok) throw new Error(r.error||'Delete failed');
    await _jobRefreshDetail(jobId, 'materials');
  } catch(e) {
    toast(e.message||'Delete failed', 'err');
  }
}

async function _jobBomToggleOnHand(lineId, jobId) {
  try {
    const r = await fetch(`/api/jobs/bom/${lineId}/on-hand`, {method:'PATCH'}).then(r=>r.json());
    if (!r.ok) throw new Error(r.error||'Update failed');
    await _jobRefreshDetail(jobId, 'materials');
  } catch(e) {
    toast(e.message||'Update failed', 'err');
  }
}

function _jobBomLinkPO(lineId, jobId) {
  const pos = _jobDetail?.pos || [];
  if (!pos.length) {
    toast('No purchase orders on this job yet — create one on the Purchasing tab first', 'err');
    return;
  }
  document.getElementById('job-bom-po-modal')?.remove();
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'job-bom-po-modal';
  bd.innerHTML = `<div class="modal-box" style="max-width:380px">
    <div class="modal-hdr">
      <span>Link Purchase Order</span>
      <button class="modal-close" onclick="document.getElementById('job-bom-po-modal').remove()">✕</button>
    </div>
    <div class="modal-body" style="padding:12px 16px;display:flex;flex-direction:column;gap:6px">
      ${pos.map(p=>`
        <button class="bom-po-pick-row" onclick="_jobBomSetPO(${lineId},${p.id},${jobId})">
          <span class="inv-mono">${esc(p.po_number)}</span>
          <span style="color:var(--ink2);font-size:12px">${esc(p.contact_name_live||p.contact_name||'')}</span>
          <span class="purch-status purch-st-${(p.status||'').toLowerCase().replace(/\s/g,'-')}" style="margin-left:auto">${esc(p.status)}</span>
        </button>`).join('')}
    </div>
    <div class="modal-foot">
      <button class="btn btn-sec" onclick="document.getElementById('job-bom-po-modal').remove()">Cancel</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

async function _jobBomSetPO(lineId, poId, jobId) {
  document.getElementById('job-bom-po-modal')?.remove();
  try {
    const r = await fetch(`/api/jobs/bom/${lineId}/po`, {
      method: 'PATCH',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({po_id: poId}),
    }).then(r=>r.json());
    if (!r.ok) throw new Error(r.error||'Link failed');
    await _jobRefreshDetail(jobId, 'materials');
  } catch(e) {
    toast(e.message||'Link failed', 'err');
  }
}

async function _jobBomUnlinkPO(lineId, jobId) {
  try {
    const r = await fetch(`/api/jobs/bom/${lineId}/po`, {
      method: 'PATCH',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({po_id: null}),
    }).then(r=>r.json());
    if (!r.ok) throw new Error(r.error||'Unlink failed');
    await _jobRefreshDetail(jobId, 'materials');
  } catch(e) {
    toast(e.message||'Unlink failed', 'err');
  }
}

async function _jobBomCreatePO(jobId) {
  const bom = _jobDetail?.bom || [];
  const pending = bom.filter(l => !l.is_customer_supplied && !l.po_id);
  if (!pending.length) { toast('No unordered materials to action', 'err'); return; }

  // Load suppliers
  let contacts = [];
  try { contacts = await apiFetch('/api/contacts'); } catch(_) {}
  const suppliers = contacts.filter(c => ['Supplier','Both'].includes(c.contact_type));

  document.getElementById('job-bom-po-create-modal')?.remove();
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'job-bom-po-create-modal';
  bd.innerHTML = `<div class="modal-box" style="max-width:520px">
    <div class="modal-hdr">
      <span>Create PO from BOM</span>
      <button class="modal-close" onclick="document.getElementById('job-bom-po-create-modal').remove()">✕</button>
    </div>
    <div class="modal-body" style="padding:16px;display:flex;flex-direction:column;gap:14px">
      <div style="display:flex;gap:12px">
        <div style="flex:2">
          <label class="form-lbl">Supplier *</label>
          <select class="form-inp" id="bom-po-supplier">
            <option value="">— Select supplier —</option>
            ${suppliers.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}
          </select>
        </div>
        <div style="flex:1">
          <label class="form-lbl">PO Date *</label>
          <input class="form-inp" type="date" id="bom-po-date" value="${isoToday()}">
        </div>
      </div>
      <div>
        <label class="form-lbl" style="margin-bottom:6px">Select lines to include</label>
        <div style="display:flex;flex-direction:column;gap:4px" id="bom-po-lines">
          ${pending.map(l=>`
            <label class="bom-po-pick-row" style="cursor:pointer">
              <input type="checkbox" checked value="${l.id}" style="margin:0">
              <span style="flex:1">${esc(l.description)}</span>
              <span class="inv-mono" style="font-size:12px;color:var(--ink2)">
                qty ${l.qty%1===0?parseInt(l.qty):parseFloat(l.qty).toFixed(2)}
                ${l.unit_cost ? ` · $${parseFloat(l.unit_cost).toFixed(2)}ea` : ''}
              </span>
            </label>`).join('')}
        </div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-sec" onclick="document.getElementById('job-bom-po-create-modal').remove()">Cancel</button>
      <button class="btn btn-primary" onclick="_jobBomCreatePOConfirm(${jobId})">Create PO</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

async function _jobBomCreatePOConfirm(jobId) {
  const suppId = document.getElementById('bom-po-supplier')?.value;
  if (!suppId) { toast('Select a supplier', 'err'); return; }
  const poDate  = document.getElementById('bom-po-date')?.value || isoToday();
  const lineIds = [...document.querySelectorAll('#bom-po-lines input[type=checkbox]:checked')]
    .map(cb => parseInt(cb.value));
  if (!lineIds.length) { toast('Select at least one line', 'err'); return; }
  try {
    const r = await fetch(`/api/jobs/${jobId}/bom/create-po`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ contact_id: parseInt(suppId), po_date: poDate, line_ids: lineIds }),
    }).then(r=>r.json());
    if (!r.ok) throw new Error(r.error || 'Failed');
    document.getElementById('job-bom-po-create-modal')?.remove();
    toast(`PO ${r.data.po_number} created`);
    await _jobRefreshDetail(jobId, 'materials');
  } catch(e) {
    toast(e.message || 'Failed to create PO', 'err');
  }
}

// ── Purchasing tab ────────────────────────────────────────────────────────────
function _jobTabPurchasing(el, pos, bills, job) {
  const poStatusCls = s => ({ Draft:'purch-st-draft', Sent:'purch-st-sent',
    'Partially Received':'purch-st-partial', Received:'purch-st-received',
    Billed:'purch-st-billed', Cancelled:'purch-st-cancelled' }[s] || 'purch-st-draft');
  const billStatusCls = s => ({ Draft:'purch-st-draft', 'Awaiting Payment':'purch-st-sent',
    Paid:'purch-st-received', Overdue:'purch-st-cancelled', Void:'purch-st-cancelled' }[s] || 'purch-st-draft');

  const poRows = pos.length
    ? pos.map(p => `
      <tr>
        <td class="inv-mono">${esc(p.po_number||'—')}</td>
        <td>${esc(p.contact_name_live||p.contact_name||'—')}</td>
        <td class="inv-mono">${fmtDate(p.po_date)||'—'}</td>
        <td><span class="purch-status ${poStatusCls(p.status)}">${esc(p.status)}</span>${p.charge_customer && p.status !== 'Cancelled'
          ? (p.charged_invoice_number
              ? ` <span class="po-charge-badge po-charge-done" title="Materials charged to the customer">Charged · ${esc(p.charged_invoice_number)}</span>`
              : ` <span class="po-charge-badge" title="Goes on the job's next invoice or claim at ${+(p.charge_markup ?? 15)}% markup">To invoice</span>`)
          : ''}</td>
        <td class="td-r-mono">${fmt(p.total)}</td>
        <td>
          <button class="btn btn-sm btn-outline btn-xs"
            onclick="detClose();setTimeout(()=>{navigate('purchase_orders');setTimeout(()=>_poOpenDet(${p.id}),400)},200)">View</button>
        </td>
      </tr>`).join('')
    : `<tr><td colspan="6" class="state-empty-sm">No purchase orders yet</td></tr>`;

  const billRows = bills.length
    ? bills.map(b => `
      <tr>
        <td class="inv-mono">${esc(b.bill_number||'—')}</td>
        <td>${esc(b.contact_name||'—')}</td>
        <td class="inv-mono">${fmtDate(b.bill_date)||'—'}</td>
        <td><span class="purch-status ${billStatusCls(b.status)}">${esc(b.status)}</span></td>
        <td class="td-r-mono">${fmt(b.total)}</td>
        <td>
          <button class="btn btn-sm btn-outline btn-xs"
            onclick="detClose();setTimeout(()=>{navigate('bills');setTimeout(()=>billOpen(${b.id}),400)},200)">View</button>
        </td>
      </tr>`).join('')
    : `<tr><td colspan="6" class="state-empty-sm">No bills yet</td></tr>`;

  const hasExpenses = bills.filter(b=>!['Void','Voided'].includes(b.status)).length
                   + pos.filter(p=>!['Cancelled','Billed'].includes(p.status)).length;
  el.innerHTML = `
    ${hasExpenses ? `<div class="purch-exp-bar">
      <span class="col-ink2" style="font-size:13px">${hasExpenses} billable expense${hasExpenses!==1?'s':''} on this job</span>
      <button class="btn btn-sm btn-primary" onclick="_jobInvoiceExpenses(${job.id})">→ Invoice Expenses</button>
    </div>` : ''}
    <div class="purch-section">
      <div class="purch-section-hdr job-sticky-toolbar">
        <span class="purch-section-title">Purchase Orders</span>
        <button class="btn btn-sm btn-outline" onclick="_jobNewPO(${job.id},${job.contact_id||'null'})">+ New PO</button>
      </div>
      <table class="inv-list-table purch-table">
        <thead><tr>
          <th>PO #</th><th>Supplier</th><th>Date</th><th>Status</th><th class="th-r">Total</th><th></th>
        </tr></thead>
        <tbody>${poRows}</tbody>
      </table>
    </div>
    <div class="purch-section">
      <div class="purch-section-hdr job-sticky-toolbar">
        <span class="purch-section-title">Bills</span>
        <button class="btn btn-sm btn-outline" onclick="_jobNewBill(${job.id},${job.contact_id||'null'})">+ New Bill</button>
      </div>
      <table class="inv-list-table purch-table">
        <thead><tr>
          <th>Bill #</th><th>Supplier</th><th>Date</th><th>Status</th><th class="th-r">Total</th><th></th>
        </tr></thead>
        <tbody>${billRows}</tbody>
      </table>
    </div>`;
}

async function _jobEnsureExpAccts() {
  if (_jobExpAccts) return;
  try {
    const accts = await apiFetch('/api/accounts');
    _jobExpAccts = (accts||[]).filter(a => a.account_type === 'Expense');
    if (!_jobExpAccts.length) _jobExpAccts = accts||[];
  } catch(_) { _jobExpAccts = []; }
}

window._jobNewPO = async function(jobId, contactId) {
  _jobPurchLines = [{ description:'', quantity:1, unit_price:0, tax_code:'GST', account_id:null }];
  await _jobEnsureExpAccts();
  _jobShowPurchForm({ job_id:jobId, contact_id:contactId, po_date:isoToday(), status:'Draft' }, jobId, 'po');
};

window._jobNewBill = async function(jobId, contactId) {
  await billNew({ contact_id: contactId, job_id: jobId });
};

function _jobShowPurchForm(data, jobId, type) {
  const isPO   = type === 'po';
  const title  = isPO ? 'New Purchase Order' : 'New Bill';
  const dateLabel = isPO ? 'PO Date *'   : 'Bill Date *';
  const dateVal   = isPO ? (data.po_date||isoToday()) : (data.bill_date||isoToday());
  const date2Label   = isPO ? 'Expected Date'   : 'Due Date';
  const date2Val     = isPO ? (data.expected_date||'') : (data.due_date||isoAddDays(14));

  const conOpts = (_jobContacts||[]).map(c =>
    `<option value="${c.id}"${data.contact_id==c.id?' selected':''}>${esc(c.name)}</option>`
  ).join('');

  document.getElementById('det-title').textContent = title;
  document.getElementById('det-body').innerHTML = `
    <h3 class="form-section-hdr">Details</h3>
    <div class="pf-grid">
      <div class="modal-field pf-full">
        <div class="lbl-line">
          <label class="modal-lbl">Supplier *</label>
          <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();_jobNewContact('pf-contact','Supplier')">+ New</a>
        </div>
        <select class="modal-sel" id="pf-contact"><option value="">— Select supplier —</option>${conOpts}</select>
      </div>
      <div class="modal-field">
        <label class="modal-lbl">${dateLabel}</label>
        <input class="modal-inp" id="pf-date" type="date" value="${dateVal}">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">${date2Label}</label>
        <input class="modal-inp" id="pf-date2" type="date" value="${date2Val}">
      </div>
      <div class="modal-field pf-full">
        <label class="modal-lbl">Notes</label>
        <input class="modal-inp" id="pf-notes" value="${esc(data.notes||'')}" placeholder="Supplier reference, delivery instructions…">
      </div>
      ${isPO ? `<div class="modal-field pf-full po-charge-wrap">
        <label class="po-charge-lbl"><input type="checkbox" id="pf-charge" checked
          onchange="document.getElementById('pf-charge-markup-wrap').style.display=this.checked?'':'none'"> Charge to customer</label>
        <span class="po-charge-markup" id="pf-charge-markup-wrap">+ <input id="pf-charge-markup" class="modal-inp po-charge-pct"
          type="number" min="0" step="1" value="15"> % markup</span>
        <div class="po-charge-hint">These materials go on the job's next invoice or claim, like logged time.</div>
      </div>` : ''}
    </div>
    <h3 class="form-section-hdr">Line Items</h3>
    <div id="pf-lines"></div>
    <button class="edt-add-btn" onclick="_jobPfAddLine()">+ Add Line</button>
    <div class="edt-totals" id="pf-totals"></div>`;

  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-primary" id="pf-save-btn" onclick="_jobSavePurch(${jobId},'${type}')">
      ${isPO ? 'Create PO' : 'Create Bill'}
    </button>
    <button class="btn btn-outline" onclick="_jobRenderDetail()">Cancel</button>`;

  _jobPfRenderLines();
}

function _jobPfRenderLines() {
  const el = document.getElementById('pf-lines');
  if (!el) return;
  const accts = _jobExpAccts || [];
  el.innerHTML = _jobPurchLines.map((l, i) => {
    const acctOpts = accts.map(a =>
      `<option value="${a.id}"${l.account_id==a.id?' selected':''}>${esc(a.code+' '+a.name)}</option>`
    ).join('');
    return `
      <div class="edt-line" draggable="true"
        ondragstart="_jobPfDragStart(${i})" ondragover="event.preventDefault()"
        ondrop="_jobPfDrop(${i})">
        <div class="edt-line-main">
          <input class="edt-inp" type="text" placeholder="Description"
            value="${esc(l.description||'')}"
            oninput="_jobPurchLines[${i}].description=this.value">
          <input class="edt-inp edt-qty" type="number" step="0.01" min="0"
            value="${l.quantity||1}"
            oninput="_jobPurchLines[${i}].quantity=parseFloat(this.value)||0;_jobPfLineCalc(${i})">
          <input class="edt-inp edt-price" type="number" step="0.01" min="0"
            value="${l.unit_price||0}"
            oninput="_jobPurchLines[${i}].unit_price=parseFloat(this.value)||0;_jobPfLineCalc(${i})">
          <select class="edt-sel"
            onchange="_jobPurchLines[${i}].tax_code=this.value;_jobPfLineCalc(${i})">
            ${['GST','FRE','N-T'].map(tc=>`<option${(l.tax_code||'GST')===tc?' selected':''}>${tc}</option>`).join('')}
          </select>
          <span class="edt-line-amt" id="pf-amt-${i}">
            ${fmt((l.quantity||0)*(l.unit_price||0))}
          </span>
          <button class="edt-rm-btn" onclick="_jobPfRemoveLine(${i})">✕</button>
        </div>
        <div class="edt-line-acct">
          <span class="edt-acct-lbl">Account</span>
          <select class="edt-sel edt-acct-sel"
            onchange="_jobPurchLines[${i}].account_id=this.value?+this.value:null">
            <option value="">— default (Expenses) —</option>${acctOpts}
          </select>
        </div>
      </div>`;
  }).join('');
  _jobPfCalc();
}

let _jobPfDragSrc = null;
window._jobPfDragStart = function(i) { _jobPfDragSrc = i; };
window._jobPfDrop = function(i) {
  if (_jobPfDragSrc === null || _jobPfDragSrc === i) return;
  const [moved] = _jobPurchLines.splice(_jobPfDragSrc, 1);
  _jobPurchLines.splice(i, 0, moved);
  _jobPfDragSrc = null;
  _jobPfRenderLines();
};

window._jobPfAddLine = function() {
  _jobPurchLines.push({ description:'', quantity:1, unit_price:0, tax_code:'GST', account_id:null });
  _jobPfRenderLines();
};

window._jobPfRemoveLine = function(i) {
  _jobPurchLines.splice(i, 1);
  if (!_jobPurchLines.length) {
    _jobPurchLines = [{ description:'', quantity:1, unit_price:0, tax_code:'GST', account_id:null }];
  }
  _jobPfRenderLines();
};

window._jobPfLineCalc = function(i) {
  const l = _jobPurchLines[i];
  const ex = (l.quantity||0) * (l.unit_price||0);
  const el = document.getElementById(`pf-amt-${i}`);
  if (el) el.textContent = fmt(ex);
  _jobPfCalc();
};

function _jobPfCalc() {
  let sub = 0, gst = 0;
  _jobPurchLines.forEach(l => {
    const ex = (l.quantity||0) * (l.unit_price||0);
    sub += ex;
    if ((l.tax_code||'GST') === 'GST') gst += ex * 0.1;
  });
  const el = document.getElementById('pf-totals');
  if (!el) return;
  el.innerHTML = `
    <div class="edt-total-row"><span>Subtotal</span><span>${fmt(sub)}</span></div>
    <div class="edt-total-row"><span>GST</span><span>${fmt(gst)}</span></div>
    <div class="edt-total-row edt-grand"><span>Total</span><span>${fmt(sub + gst)}</span></div>`;
}

window._jobSavePurch = async function(jobId, type) {
  const isPO = type === 'po';
  const contactId = parseInt(document.getElementById('pf-contact')?.value||0) || null;
  const date  = document.getElementById('pf-date')?.value;
  const date2 = document.getElementById('pf-date2')?.value || null;
  const notes = (document.getElementById('pf-notes')?.value || '').trim() || null;
  if (!contactId) { toast('Supplier is required', 'err'); return; }
  if (!date)      { toast('Date is required', 'err'); return; }
  const lines = _jobPurchLines.filter(l => (l.description||'').trim());
  if (!lines.length) { toast('Add at least one line item', 'err'); return; }

  const btn = document.getElementById('pf-save-btn');
  btn.disabled = true; btn.textContent = 'Saving…';
  try {
    if (isPO) {
      const body = {
        po: { contact_id:contactId, po_date:date, expected_date:date2,
               status:'Draft', notes, job_id:jobId,
               charge_customer: !!document.getElementById('pf-charge')?.checked,
               charge_markup: (() => { const v = document.getElementById('pf-charge-markup')?.value;
                                       return v === '' || v == null ? null : parseFloat(v); })() },
        lines: lines.map(l => ({
          description: l.description, quantity: l.quantity||1,
          unit_price:  l.unit_price||0, tax_code: l.tax_code||'GST',
          account_id:  l.account_id||null,
        })),
      };
      const r = await fetch('/api/purchase-orders', {
        method:'POST', credentials:'include',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify(body),
      });
      const j = await r.json();
      if (!j.po_id && !j.ok) throw new Error(j.error || 'Save failed');
      toast('Purchase order created');
    } else {
      const body = {
        contact_id: contactId, bill_date: date, due_date: date2,
        status: 'Draft', notes, job_id: jobId,
        lines: lines.map(l => ({
          description: l.description, quantity: l.quantity||1,
          unit_price:  l.unit_price||0, tax_code: l.tax_code||'GST',
          account_id:  l.account_id||null,
        })),
      };
      const r = await fetch('/api/bills', {
        method:'POST', credentials:'include',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify(body),
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Save failed');
      toast('Bill created');
    }
    await _jobRefreshDetail(jobId, 'purchasing');
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = isPO ? 'Create PO' : 'Create Bill';
  }
};

// ── Financials tab ────────────────────────────────────────────────────────────
function _jobTabFinancials(el, pl, txns, job) {
  const budget   = job.budget_amount || 0;
  const pct      = budget ? Math.min((pl.total_costs||0) / budget * 100, 150) : 0;
  const barColor = pct > 100 ? 'var(--red)' : pct > 80 ? 'var(--amber)' : 'var(--green)';
  const margin   = pl.revenue ? ((pl.gross_profit||0) / pl.revenue * 100).toFixed(1) : null;

  const txnRows = txns.length ? txns.map(t => `
    <tr>
      <td><span class="job-src-badge${t.source_type==='invoice'?' job-src-invoice':t.source_type==='bill'?' job-src-bill':''}">${esc(t.source_type||'')}</span></td>
      <td class="inv-mono">${esc(t.ref_number||t.source_id||'')}</td>
      <td class="inv-mono">${fmtDate(t.txn_date)||'—'}</td>
      <td>${esc(t.contact_name||'—')}</td>
      <td class="inv-amt">${fmt(t.amount||0)}</td>
      <td class="job-note">${esc(t.notes||'')}</td>
      <td><button class="btn btn-sm btn-danger btn-xs" onclick="_jobDeallocate(${t.id},${job.id})">Remove</button></td>
    </tr>`).join('') : '';

  el.innerHTML = `
    <div class="job-stat-grid">
      <div class="job-stat-card">
        <div class="job-stat-lbl">Revenue</div>
        <div class="job-stat-val col-green">${fmt(pl.revenue||0)}</div>
      </div>
      <div class="job-stat-card">
        <div class="job-stat-lbl">Total Costs</div>
        <div class="job-stat-val col-red">${fmt(pl.total_costs||0)}</div>
      </div>
      <div class="job-stat-card">
        <div class="job-stat-lbl">Gross Profit</div>
        <div class="job-stat-val" style="color:${(pl.gross_profit||0)>=0?'var(--green)':'var(--red)'}">${fmt(pl.gross_profit||0)}</div>
      </div>
    </div>

    <div class="job-pl-card">
      <div class="job-pl-row"><span class="col-ink2">Materials (bills)</span><span class="inv-mono col-red">${fmt(pl.bill_costs||0)}</span></div>
      <div class="job-pl-row"><span class="col-ink2">Labour (time entries)</span><span class="inv-mono col-red">${fmt(pl.labour_costs||0)}</span></div>
      ${(pl.journal_costs||0) ? `<div class="job-pl-row"><span class="col-ink2">Other (journals)</span><span class="inv-mono col-red">${fmt(pl.journal_costs)}</span></div>` : ''}
      <div class="job-pl-sep"></div>
      <div class="job-pl-row-m">
        <span>Gross Margin</span>
        <span class="inv-mono" style="color:${(pl.gross_profit||0)>=0?'var(--green)':'var(--red)'}">
          ${margin !== null ? margin + '%' : '—'}
        </span>
      </div>
      ${budget ? `
      <div class="job-pl-sep"></div>
      <div class="job-budget-row"><span>Budget utilisation</span><span class="inv-mono">${fmt(pl.total_costs||0)} / ${fmt(budget)}</span></div>
      <div class="job-budget-bar"><div style="height:100%;width:${Math.min(pct,100)}%;background:${barColor};border-radius:4px;transition:width .5s"></div></div>
      <div class="job-budget-meta">
        <span>Budget variance</span>
        <span style="color:${(pl.budget_variance||0)>=0?'var(--green)':'var(--red)'}">${fmt(pl.budget_variance||0)}</span>
      </div>` : ''}
    </div>

    ${txns.length ? `
    <div class="job-section-row job-sticky-toolbar">
      <div class="job-section-hdr">Allocated Transactions</div>
      <button class="btn btn-outline btn-sm" onclick="_jobAllocate(${job.id})">+ Allocate</button>
    </div>
    <table class="inv-list-table tbl-sm">
      <thead><tr>
        <th>Type</th><th>Ref</th><th>Date</th><th>Contact</th><th class="r">Amount</th><th>Notes</th><th></th>
      </tr></thead>
      <tbody>${txnRows}</tbody>
    </table>` : `
    <div class="job-empty">
      <div class="job-empty-icon">📎</div>
      <div class="job-empty-sm">No transactions allocated to this job yet.</div>
      <button class="btn btn-outline job-empty-btn" onclick="_jobAllocate(${job.id})">+ Allocate Transaction</button>
    </div>`}`;
}

// ── Allocation picker (inline swap) ──────────────────────────────────────────
window._jobAllocate = async function(jobId) {
  document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading unallocated transactions…</div>';
  document.getElementById('det-foot').innerHTML = '';
  try {
    const data = await apiFetch('/api/jobs/unallocated');
    const invs  = (data && data.invoices)  || [];
    const bills = (data && data.bills)     || [];
    const pmts  = (data && data.payments)  || [];

    if (!invs.length && !bills.length && !pmts.length) {
      document.getElementById('det-body').innerHTML = `
        <div class="job-alloc-empty">
          <div class="job-empty-icon">📭</div>
          <div class="fa-del-hint">No unallocated transactions available.</div>
          <div class="job-alloc-note">All invoices, bills and payments are already allocated to jobs.</div>
        </div>`;
      document.getElementById('det-foot').innerHTML =
        `<button class="btn btn-outline" onclick="_jobTab('financials')">← Back</button>`;
      return;
    }

    const mkRows = (rows, type, numKey, dateKey) => rows.map(item => `
      <tr class="inv-row" onclick="_jobAllocPick(${jobId},${item.id},'${type}',${item.total||item.amount||0})">
        <td><span class="job-src-badge job-src-${type}">${type.charAt(0).toUpperCase()+type.slice(1)}</span></td>
        <td class="inv-mono">${esc(item[numKey]||item.reference||'')}</td>
        <td class="inv-mono">${fmtDate(item[dateKey])||'—'}</td>
        <td>${esc(item.contact_name||'—')}</td>
        <td class="inv-amt">${fmt(item.total||item.amount||0)}</td>
      </tr>`).join('');

    document.getElementById('det-body').innerHTML = `
      <div class="job-alloc-hint">Select a transaction to allocate to this job.</div>
      <table class="inv-list-table">
        <thead><tr><th>Type</th><th>Ref #</th><th>Date</th><th>Contact</th><th class="r">Amount</th></tr></thead>
        <tbody>
          ${mkRows(invs,  'invoice', 'invoice_number', 'invoice_date')}
          ${mkRows(bills, 'bill',    'bill_number',    'bill_date')}
          ${mkRows(pmts,  'payment', 'reference',      'payment_date')}
        </tbody>
      </table>`;
    document.getElementById('det-foot').innerHTML =
      `<button class="btn btn-outline" onclick="_jobTab('financials')">← Back</button>`;
  } catch(e) {
    document.getElementById('det-body').innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`;
    document.getElementById('det-foot').innerHTML =
      `<button class="btn btn-outline" onclick="_jobTab('financials')">← Back</button>`;
  }
};

window._jobAllocPick = function(jobId, sourceId, sourceType, amount) {
  document.getElementById('det-body').innerHTML = `
    <div class="job-confirm-wrap">
      <div class="job-confirm-title">Confirm Allocation</div>
      <div class="job-confirm-sub">${esc(sourceType.charAt(0).toUpperCase()+sourceType.slice(1))} #${sourceId}</div>
      <div class="modal-field">
        <label class="modal-lbl">Amount to allocate</label>
        <input class="modal-inp" id="alloc-amount" type="number" step="0.01" value="${amount||0}" placeholder="0.00">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Notes (optional)</label>
        <input class="modal-inp" id="alloc-notes" placeholder="e.g. Phase 1 materials">
      </div>
    </div>`;
  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-outline" onclick="_jobAllocate(${jobId})">← Back</button>
    <button class="btn btn-primary" onclick="_jobAllocConfirm(${jobId},${sourceId},'${sourceType}')">Allocate</button>`;
};

window._jobAllocConfirm = async function(jobId, sourceId, sourceType) {
  const amount = parseFloat(document.getElementById('alloc-amount').value) || 0;
  const notes  = (document.getElementById('alloc-notes').value || '').trim();
  const btn = document.querySelector('#det-foot .btn-primary');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
  try {
    const r = await fetch(`/api/jobs/${jobId}/allocate`, {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ source_type:sourceType, source_id:parseInt(sourceId), amount, notes }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed');
    toast('Transaction allocated');
    _jobAll = await apiFetch('/api/jobs') || _jobAll;
    _jobRenderView();
    await _jobOpen(jobId);
  } catch(e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Allocate'; }
  }
};

window._jobDeallocate = async function(allocId, jobId) {
  if (!await confirmDlg('Remove this allocation? The transaction will not be deleted.')) return;
  try {
    const r = await fetch(`/api/jobs/allocations/${allocId}`, { method:'DELETE', credentials:'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed');
    toast('Allocation removed');
    _jobAll = await apiFetch('/api/jobs') || _jobAll;
    _jobRenderView();
    await _jobOpen(jobId);
  } catch(e) { toast(e.message, 'err'); }
};

// ── Time tab ──────────────────────────────────────────────────────────────────
function _jobTabTime(el, timeEntries, pl, jobId) {
  const totalHours = timeEntries.reduce((s,e) => s + (e.hours||0), 0);
  const totalCost  = timeEntries.reduce((s,e) => s + (e.hours||0) * (e.hourly_rate||0), 0);

  // Per-employee summary
  const empMap = {};
  for (const e of timeEntries) {
    const k = e.employee_id;
    if (!empMap[k]) empMap[k] = { name:`${e.first_name} ${e.last_name}`, hours:0, cost:0 };
    empMap[k].hours += e.hours || 0;
    empMap[k].cost  += (e.hours||0) * (e.hourly_rate||0);
  }

  const empRows = Object.values(empMap).map(emp => {
    const revShare = totalHours ? (pl.revenue||0) * (emp.hours / totalHours) : 0;
    const profit   = revShare - emp.cost;
    return `<tr>
      <td>${esc(emp.name)}</td>
      <td class="td-r-mono">${emp.hours.toFixed(1)}h</td>
      <td class="td-r-mono">${fmt(emp.cost)}</td>
      <td class="td-r-mono">${fmt(revShare)}</td>
      <td class="td-r-mono" style="color:${profit>=0?'var(--green)':'var(--red)'}">${fmt(profit)}</td>
    </tr>`;
  }).join('');

  if (!timeEntries.length) {
    el.innerHTML = `
      <div class="job-empty">
        <div class="job-empty-icon">⏱</div>
        <div class="job-empty-sm">No time entries logged yet.</div>
        <button class="btn btn-outline job-empty-btn" onclick="_jobTimeForm(${jobId},null)">+ Log Time</button>
      </div>`;
    return;
  }

  el.innerHTML = `
    ${empRows ? `
    <div class="job-section-hdr job-section-mb">By Employee</div>
    <table class="inv-list-table tbl-sm job-tbl-mb">
      <thead><tr>
        <th>Employee</th><th class="th-r">Hours</th><th class="th-r">Cost</th>
        <th class="th-r">Rev Share</th><th class="th-r">Profit</th>
      </tr></thead>
      <tbody>${empRows}</tbody>
    </table>` : ''}
    <div class="job-section-row job-sticky-toolbar">
      <div class="job-section-hdr">Time Entries</div>
      <button class="btn btn-sm btn-outline" onclick="_jobTimeForm(${jobId},null)">+ Log Time</button>
    </div>
    <table class="inv-list-table tbl-sm">
      <thead><tr>
        <th>Employee</th><th>Date</th><th class="th-r">Hours</th>
        <th class="th-r">Rate</th><th class="th-r">Cost</th><th>Notes</th><th></th>
      </tr></thead>
      <tbody>
        ${timeEntries.map(e => `<tr>
          <td>${esc(e.first_name+' '+e.last_name)}</td>
          <td class="inv-mono">${fmtDate(e.entry_date)||'—'}</td>
          <td class="td-r-mono">${(e.hours||0).toFixed(1)}</td>
          <td class="td-r-mono">$${(e.hourly_rate||0).toFixed(2)}</td>
          <td class="td-r-mono">${fmt((e.hours||0)*(e.hourly_rate||0))}</td>
          <td class="job-note">${esc(e.description||'')}</td>
          <td class="job-actions-col">
            <button class="btn btn-sm btn-outline btn-xs" onclick="_jobTimeForm(${jobId},${e.id})">Edit</button>
            ${e.billed
              ? '<span class="badge badge-muted">Billed</span>'
              : `<button class="btn btn-sm btn-outline btn-xs" onclick="_jobTimeBill(${e.id},${jobId})">Bill</button>`}
            <button class="btn btn-sm btn-danger btn-xs ml-3" onclick="_jobTimeDelete(${e.id},${jobId})">✕</button>
          </td>
        </tr>`).join('')}
        <tr class="job-total-row">
          <td>TOTAL</td><td></td>
          <td class="td-r-mono">${totalHours.toFixed(1)}</td>
          <td></td>
          <td class="td-r-mono">${fmt(totalCost)}</td>
          <td colspan="2"></td>
        </tr>
      </tbody>
    </table>`;
}

window._jobTimeBill = async function(entryId, jobId) {
  if (!await confirmDlg('Add this time entry as a billable task?')) return;
  try {
    const r = await fetch(`/api/jobs/${jobId}/time/${entryId}/bill`, {
      method: 'POST', credentials: 'include'
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Failed', 'err'); return; }
    toast('Added to tasks — ready to invoice');
    await _jobRefreshDetail(jobId, 'tasks');
  } catch(e) { toast('Error: ' + e.message, 'err'); }
};

async function _jobLoadTimeEmployees() {
  if (_jobTimeEmployees) return _jobTimeEmployees;
  try {
    const data = await apiFetch('/api/payroll/employees');
    _jobTimeEmployees = Array.isArray(data) ? data : (data && data.employees) || [];
  } catch(_) { _jobTimeEmployees = []; }
  return _jobTimeEmployees;
}

window._jobTimeForm = async function(jobId, entryId) {
  const emps = await _jobLoadTimeEmployees();
  const empOpts = emps.map(e => {
    const name = `${e.first_name} ${e.last_name}`;
    return `<option value="${e.id}" data-rate="${e.hourly_rate||0}">${esc(name)}</option>`;
  }).join('');

  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box modal-460">
      <div class="modal-hdr"><span>${entryId ? 'Edit Time Entry' : 'Log Time'}</span></div>
      <div class="modal-body">
        <div class="modal-field"><label class="modal-lbl">Employee *</label>
          <select class="modal-sel" id="jt-emp" onchange="_jobJtAutoRate(this)">${empOpts}</select></div>
        <div class="modal-field"><label class="modal-lbl">Date *</label>
          <input class="modal-inp" id="jt-date" type="date" value="${isoToday()}"></div>
        <div class="modal-field"><label class="modal-lbl">Hours *</label>
          <input class="modal-inp" id="jt-hours" type="number" step="0.5" min="0.5" value="8"></div>
        <div class="modal-field"><label class="modal-lbl">Hourly Rate ($)</label>
          <input class="modal-inp" id="jt-rate" type="number" step="0.01" min="0">
          <div class="job-time-hint">Auto-filled from employee pay rate</div></div>
        <div class="modal-field"><label class="modal-lbl">Description</label>
          <input class="modal-inp" id="jt-desc" value=""></div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="_jobTimeSave(${jobId},${entryId||'null'})">
          ${entryId ? 'Save Changes' : 'Log Time'}
        </button>
      </div>
    </div>`;
  document.body.appendChild(bd);
  // Auto-fill rate
  const sel = document.getElementById('jt-emp');
  if (sel) _jobJtAutoRate(sel);
};

window._jobJtAutoRate = function(sel) {
  const rate = parseFloat(sel.selectedOptions[0]?.dataset.rate || 0);
  const rateEl = document.getElementById('jt-rate');
  if (rateEl && rate > 0) rateEl.value = rate.toFixed(2);
};

window._jobTimeSave = async function(jobId, entryId) {
  const empId = parseInt(document.getElementById('jt-emp').value) || null;
  const date  = document.getElementById('jt-date').value;
  const hours = parseFloat(document.getElementById('jt-hours').value) || 0;
  const rate  = parseFloat(document.getElementById('jt-rate').value)  || 0;
  const desc  = document.getElementById('jt-desc').value.trim();

  if (!empId)     { toast('Select an employee', 'err'); return; }
  if (!date)      { toast('Date is required', 'err'); return; }
  if (hours <= 0) { toast('Hours must be greater than 0', 'err'); return; }

  const btn = document.querySelector('.modal-bd .btn-primary');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }

  try {
    const r = await fetch(`/api/jobs/${jobId}/time`, {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id:          entryId || null,
        job_id:      jobId,
        employee_id: empId,
        entry_date:  date,
        hours,
        hourly_rate: rate,
        description: desc,
      }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    btn?.closest('.modal-bd')?.remove();
    toast(entryId ? 'Time entry updated' : 'Time logged');
    await _jobRefreshDetail(jobId, 'time');
  } catch(e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = entryId ? 'Save Changes' : 'Log Time'; }
  }
};

window._jobTimeDelete = async function(entryId, jobId) {
  if (!await confirmDlg('Delete this time entry?')) return;
  try {
    const r = await fetch(`/api/jobs/time/${entryId}`, { method:'DELETE', credentials:'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed');
    toast('Time entry deleted');
    await _jobRefreshDetail(jobId, 'time');
  } catch(e) { toast(e.message, 'err'); }
};

// ── Visits tab ────────────────────────────────────────────────────────────────
// A visit is a Schedule event linked to this job (event_type 'Visit') — one
// per trip to do the work. Saved through the Schedule API so Google Calendar
// sync and the job's calendar span are handled in one place.

function _jobVisitTime(v) {
  if (v.all_day || !v.start_time) return 'All day';
  return `${v.start_time}–${v.end_time || ''}`;
}

function _jobTabVisits(el, visits, job) {
  const totalHrs    = visits.reduce((s, v) => s + (v.hours || 0), 0);
  const unbilledHrs = visits.filter(v => !v.invoice_id).reduce((s, v) => s + (v.hours || 0), 0);

  if (!visits.length) {
    el.innerHTML = `
      <div class="job-empty">
        <div class="job-empty-icon">&#128197;</div>
        <div class="job-empty-sm">No visits yet. Log each trip to do this job's work — date, time and hours.</div>
        <button class="btn btn-outline job-empty-btn" onclick="_jobVisitForm(${job.id},null)">+ Add Visit</button>
      </div>`;
    return;
  }

  el.innerHTML = `
    <div class="job-section-row job-sticky-toolbar">
      <div class="job-section-hdr">Visits</div>
      <button class="btn btn-sm btn-outline" onclick="_jobVisitForm(${job.id},null)">+ Add Visit</button>
    </div>
    <table class="inv-list-table tbl-sm">
      <thead><tr>
        <th>Date</th><th>Time</th><th>Worker</th><th class="th-r">Hours</th><th>Tasks</th><th>Notes</th><th></th>
      </tr></thead>
      <tbody>
        ${visits.map(v => { const tc = (_jobDetail?.visit_task_counts || {})[v.id]; return `<tr>
          <td class="inv-mono">${v.gcal_event_id ? '<span class="chip-gcal-badge" title="Synced with Google Calendar">☁</span>' : ''}${fmtDate(v.event_date)}</td>
          <td class="inv-mono">${esc(_jobVisitTime(v))}</td>
          <td>${v.worker_name ? esc(v.worker_name) : '<span class="col-ink3">—</span>'}</td>
          <td class="td-r-mono">${v.hours != null ? Number(v.hours).toFixed(2) : '—'}</td>
          <td class="jvt-count">${tc ? `${tc.tasks} task${tc.tasks === 1 ? '' : 's'}${tc.done ? ` · ${tc.done} done` : ''}` : '<span class="col-ink3">—</span>'}</td>
          <td class="job-note">${esc(v.event_type !== 'Visit' ? `${v.event_type}: ${v.title}` : (v.description || v.title || ''))}</td>
          <td class="job-actions-col">
            ${v.event_type === 'Visit' ? `<button class="btn btn-sm btn-outline btn-xs" onclick="_jobVisitTasks(${job.id},${v.id})">Tasks</button>
              <button class="btn btn-sm btn-outline btn-xs" title="Print this visit's worksheet" onclick="window.open('/api/jobs/visits/${v.id}/worksheet','_blank')">Print</button>` : ''}
            ${v.invoice_id
              ? (v.time_charged === 0
                  ? '<span class="badge badge-muted" title="Claimed without its time — the hours were built into the prices">Claimed · time not charged</span>'
                  : '<span class="badge badge-muted">Billed</span>')
              : `<button class="btn btn-sm btn-outline btn-xs" onclick="_jobVisitForm(${job.id},${v.id})">Edit</button>
                 <button class="btn btn-sm btn-danger btn-xs ml-3" onclick="_jobVisitDelete(${v.id},${job.id})">✕</button>`}
          </td>
        </tr>`; }).join('')}
        <tr class="job-total-row">
          <td>TOTAL</td><td></td><td></td>
          <td class="td-r-mono">${totalHrs.toFixed(2)}</td>
          <td colspan="3" class="col-ink3">${unbilledHrs.toFixed(2)} hrs unbilled</td>
        </tr>
      </tbody>
    </table>`;
}

// opts.taskId: opened from a task's "+ Log time" — that task starts ticked
// (even if already done). opts.tab: the tab to return to after saving.
window._jobVisitForm = function(jobId, visitId, opts = {}) {
  const job = _jobDetail?.job;
  const v   = visitId ? (_jobDetail?.visits || []).find(x => x.id === visitId) : null;
  // Worker picker appears once the list loads (with + New to add a contractor)
  loadWorkers().then(ws => {
    const sel = document.getElementById('jv-worker');
    if (!sel) return;
    sel.innerHTML = workerOptsHtml(ws, v?.worker_contact_id, v?.worker_name);
    document.getElementById('jv-worker-wrap').style.display = '';
  });
  if (!job || (visitId && !v)) { toast('Visit not found', 'err'); return; }
  const allDay = v ? !!v.all_day : false;
  // Oldest first — the order they were added to the job, same as the visit Tasks modal.
  const openTasks = (_jobDetail?.work_tasks || [])
    .filter(t => !t.invoice_id && (!t.is_done || t.id === opts.taskId)).sort((a, b) => a.id - b.id);
  const forTask = opts.taskId ? openTasks.find(t => t.id === opts.taskId) : null;

  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box modal-460">
      <div class="modal-hdr"><span>${v ? 'Edit Visit' : forTask ? 'Log Time' : 'Add Visit'}</span></div>
      <div class="modal-body">
        <div class="modal-field"><label class="modal-lbl">Title *</label>
          <input class="modal-inp" id="jv-title" value="${esc(v?.title || `${job.job_number} – ${forTask ? forTask.title : job.name}`)}"></div>
        <div class="modal-field"><label class="modal-lbl">Date *</label>
          <input class="modal-inp" id="jv-date" type="date" value="${v?.event_date || isoToday()}"></div>
        <div class="modal-field"><label class="modal-lbl">All Day</label>
          <select class="modal-sel" id="jv-allday" onchange="_jobVisitToggleTimes()">
            <option value="0"${!allDay ? ' selected' : ''}>No</option>
            <option value="1"${allDay ? ' selected' : ''}>Yes</option>
          </select></div>
        <div class="modal-field" id="jv-times"${allDay ? ' style="display:none"' : ''}>
          <label class="modal-lbl">Start – End</label>
          <div class="jv-time-pair">
            <input class="modal-inp" id="jv-start" type="time" value="${v?.start_time || '08:00'}" oninput="_jobVisitAutoHours()">
            <input class="modal-inp" id="jv-end"   type="time" value="${v?.end_time   || '16:00'}" oninput="_jobVisitAutoHours()">
          </div></div>
        <div class="modal-field" id="jv-worker-wrap" style="display:none">
          <div class="lbl-line"><label class="modal-lbl">Worker</label>
            <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();workerNewInto('jv-worker')">+ Add contractor</a></div>
          <select class="modal-sel" id="jv-worker"></select></div>
        <div class="modal-field"><label class="modal-lbl">Hours worked</label>
          <input class="modal-inp" id="jv-hours" type="number" step="0.25" min="0" value="${v?.hours ?? ''}" oninput="this.dataset.touched='1'">
          <div class="job-time-hint">Billable hours — filled from start/end, change it for breaks</div></div>
        <div class="modal-field"><label class="modal-lbl">Notes</label>
          <textarea class="modal-inp edt-ta-resize" id="jv-desc" rows="2" placeholder="Work done this visit">${esc(v?.description || '')}</textarea></div>
        ${!v && openTasks.length ? `<div class="modal-field"><label class="modal-lbl">Tasks for this visit</label>
          <div class="jv-plan-list">${openTasks.map(t => `<label class="jv-plan-item"><input type="checkbox" class="jv-plan" value="${t.id}"${t.id === opts.taskId ? ' checked' : ''}>
            ${esc(t.title)}${t.billing === 'hourly' ? ' <span class="jcb-sub">hourly</span>' : (+t.qty > 1 ? ` <span class="jcb-sub">${+t.qty}</span>` : '')}</label>`).join('')}</div>
          <div class="job-time-hint">You can change these later with the visit's Tasks button</div></div>` : ''}
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" id="jv-save-btn" onclick="_jobVisitSave(${jobId},${visitId || 'null'},'${opts.tab || 'visits'}')">
          ${v ? 'Save Changes' : forTask ? 'Log Time' : 'Add Visit'}
        </button>
      </div>
    </div>`;
  document.body.appendChild(bd);
  if (!v || v.hours == null) _jobVisitAutoHours();
};

// ── Visit tasks: plan + record progress ───────────────────────────────────────
// The job's task list is the master; a visit picks from it and records what
// got done there (core/visit_tasks.py). One modal does both: tick which
// tasks are on the visit, then — after the visit — tick Done / enter qty.
let _jvtData = null;

window._jobVisitTasks = async function(jobId, visitId) {
  try { _jvtData = await apiFetch(`/api/schedule/events/${visitId}/tasks`); }
  catch(e) { toast(e.message, 'err'); return; }
  const d = _jvtData;
  const isQty = t => t.billing === 'fixed' && (+t.qty) > 1;

  const onRow = t => {
    const claimed = !!t.claimed_invoice_id;
    const others = isQty(t) ? (+t.progress) - (+t.qty_done || 0) : 0;
    return `<tr data-task="${t.task_id}"${claimed ? ' class="jvt-claimed"' : ''}>
      <td class="jcb-chk"><input type="checkbox" class="jvt-on" checked${claimed ? ' disabled' : ''} onchange="_jvtRowToggle(this)"></td>
      <td>${esc(t.title)}${t.billing === 'hourly' ? ' <span class="task-billable-badge task-hourly-badge">Hourly</span>' : ''}
        ${claimed ? ' <span class="badge badge-muted">Claimed</span>' : ''}
        ${isQty(t) ? `<div class="jcb-sub">${+t.progress} of ${+t.qty} done so far${others > 0 ? ` (${others} on other visits)` : ''}</div>` : ''}</td>
      <td class="jvt-done-cell"><label class="jvt-done"><input type="checkbox" class="jvt-completed"${t.completed ? ' checked' : ''}${claimed ? ' disabled' : ''}> Done</label></td>
      <td class="jcb-qty-cell">${isQty(t)
        ? `<input class="edt-inp jcb-qty jvt-qty" type="number" step="any" min="0" max="${(+t.qty) - others}"
             value="${t.qty_done ?? ''}" placeholder="qty"${claimed ? ' disabled' : ''}> <span class="jcb-sub">this visit</span>`
        : ''}</td>
    </tr>`;
  };
  const availRow = t => `<tr data-task="${t.task_id}" class="jvt-avail">
      <td class="jcb-chk"><input type="checkbox" class="jvt-on" onchange="_jvtRowToggle(this)"></td>
      <td>${esc(t.title)}${t.billing === 'hourly' ? ' <span class="task-billable-badge task-hourly-badge">Hourly</span>' : ''}
        ${isQty(t) ? `<div class="jcb-sub">${+t.progress} of ${+t.qty} done so far</div>` : ''}</td>
      <td class="jvt-done-cell"><label class="jvt-done"><input type="checkbox" class="jvt-completed" disabled> Done</label></td>
      <td class="jcb-qty-cell">${isQty(t)
        ? `<input class="edt-inp jcb-qty jvt-qty" type="number" step="any" min="0" max="${(+t.qty) - (+t.progress)}" placeholder="qty" disabled> <span class="jcb-sub">this visit</span>`
        : ''}</td>
    </tr>`;

  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex'; bd.id = 'jvt-modal';
  bd.innerHTML = `
    <div class="modal-box jvt-box">
      <div class="modal-hdr"><span>Visit tasks — ${fmtDate(d.visit.event_date)}</span></div>
      <div class="modal-body">
        <div class="jcb-hint jvt-intro">Tick the tasks for this visit. Afterwards, come back and tick <b>Done</b> or enter the quantity done — the job's task list updates from here.</div>
        <table class="inv-list-table tbl-sm jcb-tbl">
          <tbody>
            ${d.tasks.map(onRow).join('') || ''}
            ${d.available.length ? `<tr class="jvt-sep"><td colspan="4">Other open tasks on this job</td></tr>${d.available.map(availRow).join('')}` : ''}
            ${!d.tasks.length && !d.available.length ? '<tr><td colspan="4" class="jcb-empty">No open tasks on this job — add one below.</td></tr>' : ''}
          </tbody>
        </table>
        <div class="jvt-new">
          <div class="job-section-hdr">+ New task (adds to the job too)</div>
          <div class="jvt-new-row">
            <input class="edt-inp" id="jvt-new-title" placeholder="Task title">
            <select class="edt-sel" id="jvt-new-billing" onchange="document.getElementById('jvt-new-price-wrap').style.display=this.value==='hourly'?'none':''">
              <option value="fixed">Fixed price</option><option value="hourly">Hourly</option>
            </select>
            <span id="jvt-new-price-wrap">
              <input class="edt-inp jcb-qty" id="jvt-new-qty" type="number" step="any" min="0" value="1" title="Qty">
              × $<input class="edt-inp jcb-qty" id="jvt-new-price" type="number" step="0.01" min="0" value="0" title="Unit price">
            </span>
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" id="jvt-save" onclick="_jvtSave(${jobId},${visitId})">Save</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
};

window._jvtRowToggle = function(chk) {
  const tr = chk.closest('tr');
  tr.querySelectorAll('.jvt-completed, .jvt-qty').forEach(i => { i.disabled = !chk.checked; if (!chk.checked) { i.checked = false; if (i.type === 'number') i.value = ''; } });
};

window._jvtSave = async function(jobId, visitId) {
  const tasks = [...document.querySelectorAll('#jvt-modal tr[data-task]')]
    .filter(tr => tr.querySelector('.jvt-on').checked)
    .map(tr => ({
      task_id:   +tr.dataset.task,
      completed: tr.querySelector('.jvt-completed').checked,
      qty_done:  tr.querySelector('.jvt-qty')?.value || null,
    }));
  const newTitle = document.getElementById('jvt-new-title').value.trim();
  const new_tasks = newTitle ? [{
    title: newTitle,
    billing: document.getElementById('jvt-new-billing').value,
    qty: document.getElementById('jvt-new-qty').value,
    unit_price: document.getElementById('jvt-new-price').value,
  }] : [];
  const btn = document.getElementById('jvt-save');
  btn.disabled = true; btn.textContent = 'Saving…';
  try {
    const r = await fetch(`/api/schedule/events/${visitId}/tasks`, {
      method: 'PUT', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tasks, new_tasks }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    document.getElementById('jvt-modal')?.remove();
    toast('Visit tasks saved');
    await _jobRefreshDetail(jobId, 'visits');
    // A recurring task finished on this visit offers its next occurrence,
    // the same as ticking Done on the Tasks tab.
    for (const t of (j.data.recurring || [])) _jobWtScheduleNextModal(t, jobId);
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = 'Save';
  }
};

window._jobVisitToggleTimes = function() {
  const allDay = document.getElementById('jv-allday')?.value === '1';
  document.getElementById('jv-times').style.display = allDay ? 'none' : '';
};

// Fills hours from start/end until the user types their own figure.
window._jobVisitAutoHours = function() {
  const hrsEl = document.getElementById('jv-hours');
  if (!hrsEl || hrsEl.dataset.touched) return;
  const [sh, sm] = (document.getElementById('jv-start')?.value || '').split(':').map(Number);
  const [eh, em] = (document.getElementById('jv-end')?.value   || '').split(':').map(Number);
  if ([sh, sm, eh, em].some(isNaN)) return;
  const hrs = ((eh * 60 + em) - (sh * 60 + sm)) / 60;
  if (hrs > 0) hrsEl.value = String(Math.round(hrs * 100) / 100);
};

window._jobVisitSave = async function(jobId, visitId, tab = 'visits') {
  const job    = _jobDetail?.job;
  const old    = visitId ? (_jobDetail?.visits || []).find(x => x.id === visitId) : null;
  const title  = document.getElementById('jv-title').value.trim();
  const date   = document.getElementById('jv-date').value;
  const allDay = document.getElementById('jv-allday').value === '1';
  const start  = allDay ? null : (document.getElementById('jv-start').value || null);
  const end    = allDay ? null : (document.getElementById('jv-end').value   || null);
  const hrsRaw = document.getElementById('jv-hours').value;

  if (!title) { toast('Title is required', 'err'); return; }
  if (!date)  { toast('Date is required', 'err'); return; }
  if (!allDay && (!start || !end)) { toast('Start and end time are required — or set All Day to Yes', 'err'); return; }
  if (!allDay && end <= start)     { toast('End time must be after start time', 'err'); return; }
  if (hrsRaw !== '' && parseFloat(hrsRaw) < 0) { toast("Hours can't be negative", 'err'); return; }

  // PUT rewrites every event field, so an edit carries over the ones this
  // form doesn't show (contact, end date) from the existing row.
  const payload = {
    title,
    event_type:  'Visit',
    job_id:      jobId,
    contact_id:  old ? old.contact_id : (job?.contact_id || null),
    event_date:  date,
    end_date:    old?.end_date || null,
    all_day:     allDay,
    start_time:  start,
    end_time:    end,
    hours:       hrsRaw === '' ? null : parseFloat(hrsRaw),
    description: document.getElementById('jv-desc').value.trim() || null,
    ...workerField('jv-worker'),
  };

  const btn = document.getElementById('jv-save-btn');
  btn.disabled = true; btn.textContent = 'Saving…';
  try {
    const r = await fetch(visitId ? `/api/schedule/events/${visitId}` : '/api/schedule/events', {
      method: visitId ? 'PUT' : 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    const doneIds = new Set((_jobDetail?.work_tasks || []).filter(t => t.is_done).map(t => t.id));
    const planned = [...document.querySelectorAll('.jv-plan:checked')]
      .map(c => ({ task_id: +c.value, completed: doneIds.has(+c.value) }));
    if (!visitId && planned.length) {
      const r2 = await fetch(`/api/schedule/events/${j.data.id}/tasks`, {
        method: 'PUT', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tasks: planned }),
      });
      const j2 = await r2.json();
      if (!j2.ok) toast(`Visit added, but its tasks weren't saved: ${j2.error}`, 'err');
    }
    btn.closest('.modal-bd').remove();
    toast(visitId ? 'Visit updated' : tab === 'tasks' ? 'Time logged' : 'Visit added');
    await _jobRefreshDetail(jobId, tab);
    window._calRefreshJobs?.();
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = visitId ? 'Save Changes' : 'Add Visit';
  }
};

window._jobVisitDelete = async function(visitId, jobId) {
  if (!await confirmDlg('Delete this visit? It will also be removed from Google Calendar if synced.')) return;
  try {
    let r = await fetch(`/api/schedule/events/${visitId}`, { method:'DELETE', credentials:'include' });
    let j = await r.json();
    if (r.status === 409) {
      // Task progress was recorded on it — make sure that's intended.
      if (!await confirmDlg(`${j.error}. Delete anyway?`)) return;
      r = await fetch(`/api/schedule/events/${visitId}?force=1`, { method:'DELETE', credentials:'include' });
      j = await r.json();
    }
    if (!j.ok) throw new Error(j.error || 'Delete failed');
    toast('Visit deleted');
    await _jobRefreshDetail(jobId, 'visits');
    window._calRefreshJobs?.();
  } catch(e) { toast(e.message, 'err'); }
};

// ═══════════════════════════════════════════════════════════════════════════
// NEW / EDIT JOB FORM
// ═══════════════════════════════════════════════════════════════════════════

window._jobNew = async function() {
  await _jobForm(null);
};

window._jobEditForm = async function() {
  if (!_jobDetail) return;
  await _jobForm(_jobDetail.job);
};

async function _jobForm(existing) {
  // _jobContacts is normally populated by pageJobs() on load — but "+ New
  // Job" can also be opened from the Schedule page, which never runs that
  // fetch, leaving the Client/Contact picker empty (or, if a contact was
  // added since the last fetch, stale). Always refresh it on open so the
  // form has current contacts regardless of which page opened it.
  _jobContacts = (await apiFetch('/api/contacts')) || [];
  const nextNum = existing
    ? existing.job_number
    : (await apiFetch('/api/jobs/next-number')) || '';

  const conOpts     = (_jobContacts||[]).map(c =>
    `<option value="${c.id}"${existing?.contact_id==c.id?' selected':''}>${esc(c.name)}</option>`
  ).join('');
  const stageOpts   = PIPELINE_STAGES.map(s =>
    `<option${(existing?.stage||'Lead')===s?' selected':''}>${s}</option>`
  ).join('');
  const srcOpts     = JOB_SOURCES.map(s =>
    `<option${existing?.source===s?' selected':''}>${s}</option>`
  ).join('');

  const isEdit = !!existing;
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = isEdit
    ? `Edit Job — ${existing.job_number}` : 'New Job';

  document.getElementById('det-body').innerHTML = `
    <h3 class="form-section-hdr">Job Details</h3>
    <div class="job-form-grid">
      <div class="modal-field">
        <label class="modal-lbl">Job Number</label>
        <input class="modal-inp" id="jf-num" value="${esc(nextNum||'')}" placeholder="e.g. JOB-2026-0001">
      </div>
      <div class="modal-field job-grid-full">
        <label class="modal-lbl">Job Name *</label>
        <input class="modal-inp" id="jf-name" placeholder="e.g. Office Fitout — Level 3" value="${esc(existing?.name||'')}">
      </div>
      <div class="modal-field job-grid-full">
        <label class="modal-lbl">Description</label>
        <textarea class="modal-inp edt-ta-resize" id="jf-desc" rows="2">${esc(existing?.description||'')}</textarea>
      </div>
      <div class="modal-field">
        <div class="lbl-line">
          <label class="modal-lbl">Client / Contact</label>
          <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();_jobNewContact('jf-contact','Customer')">+ New</a>
        </div>
        <select class="modal-sel" id="jf-contact">
          <option value="">— None —</option>${conOpts}
        </select>
      </div>
      <div class="modal-field job-grid-full">
        <div class="lbl-line">
          <label class="modal-lbl">Site Address</label>
          <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();_jobUseClientAddress()">Use client's address</a>
        </div>
        <textarea class="modal-inp edt-ta-resize" id="jf-site" rows="2"
          placeholder="Where the work is done, if not the client's address">${esc(existing?.site_address||'')}</textarea>
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Manager</label>
        <input class="modal-inp" id="jf-manager" list="jf-manager-list"
               value="${esc(existing?.manager||'')}" placeholder="Type or select…" autocomplete="off">
        <datalist id="jf-manager-list">
          ${(_jobContacts||[]).map(c=>`<option value="${esc(c.name)}">`).join('')}
        </datalist>
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Start Date</label>
        <input class="modal-inp" id="jf-start" type="date" value="${existing?.start_date||isoToday()}">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">End Date</label>
        <input class="modal-inp" id="jf-end" type="date" value="${existing?.end_date||''}">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Budget Amount</label>
        <input class="modal-inp" id="jf-budget" type="number" step="0.01" min="0"
               placeholder="0.00" value="${existing?.budget_amount||''}">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Budget Notes</label>
        <input class="modal-inp" id="jf-budget-notes" value="${esc(existing?.budget_notes||'')}">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Hourly Rate ($, ex GST)</label>
        <input class="modal-inp" id="jf-rate" type="number" step="0.01" min="0"
               placeholder="Charge-out rate" value="${existing?.hourly_rate ?? ''}">
      </div>
    </div>

    <h3 class="form-section-hdr" style="margin-top:18px">Pipeline</h3>
    <div class="job-form-grid">
      <div class="modal-field">
        <label class="modal-lbl">Stage</label>
        <select class="modal-sel" id="jf-stage">${stageOpts}</select>
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Source</label>
        <select class="modal-sel" id="jf-source">
          <option value="">— None —</option>${srcOpts}
        </select>
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Est. Value ($)</label>
        <input class="modal-inp" id="jf-value" type="number" step="0.01" min="0" value="${existing?.value||''}">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Probability (%)</label>
        <input class="modal-inp" id="jf-prob" type="number" step="1" min="0" max="100" value="${existing?.probability??50}">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Owner</label>
        <input class="modal-inp" id="jf-owner" list="jf-owner-list"
               value="${esc(existing?.owner||'')}" placeholder="Type or select…" autocomplete="off">
        <datalist id="jf-owner-list">
          ${(_jobContacts||[]).map(c=>`<option value="${esc(c.name)}">`).join('')}
        </datalist>
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Target Close</label>
        <input class="modal-inp" id="jf-close" type="date" value="${existing?.target_close||''}">
      </div>
      <div class="modal-field job-grid-full">
        <label class="modal-lbl">Internal Notes</label>
        <textarea class="modal-inp edt-ta-resize" id="jf-notes" rows="2">${esc(existing?.notes||'')}</textarea>
      </div>
    </div>`;

  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-outline" onclick="${isEdit ? `_jobOpen(${existing.id})` : 'detClose()'}">Cancel</button>
    <button class="btn btn-primary" onclick="_jobSave(${existing?.id||'null'})">
      ${isEdit ? 'Save Changes' : 'Create Job'}
    </button>`;

  setTimeout(() => document.getElementById('jf-name')?.focus(), 80);
}

// Fill the site address from the chosen client's address
function _jobUseClientAddress() {
  const id = parseInt(document.getElementById('jf-contact')?.value) || null;
  const c = (_jobContacts||[]).find(x => x.id === id);
  if (!c) { toast('Choose a client first', 'err'); return; }
  const line2 = [c.city, c.state, c.postcode].filter(Boolean).join(' ');
  const addr = [c.address, line2].filter(Boolean).join('\n');
  if (!addr) { toast(`${c.name} has no address saved`, 'err'); return; }
  document.getElementById('jf-site').value = addr;
}

window._jobSave = async function(editId) {
  const name = (document.getElementById('jf-name')?.value || '').trim();
  if (!name) { toast('Job name is required', 'err'); return; }

  const payload = {
    id:            editId || null,
    job_number:    document.getElementById('jf-num')?.value,
    name,
    description:   document.getElementById('jf-desc')?.value.trim() || null,
    site_address:  document.getElementById('jf-site')?.value.trim() || null,
    contact_id:    parseInt(document.getElementById('jf-contact')?.value) || null,
    status:        document.getElementById('jf-status')?.value || 'Active',
    start_date:    document.getElementById('jf-start')?.value  || null,
    end_date:      document.getElementById('jf-end')?.value    || null,
    budget_amount: parseFloat(document.getElementById('jf-budget')?.value) || null,
    budget_notes:  document.getElementById('jf-budget-notes')?.value.trim() || null,
    hourly_rate:   document.getElementById('jf-rate')?.value === '' ? null
                     : parseFloat(document.getElementById('jf-rate')?.value),
    manager:       document.getElementById('jf-manager')?.value.trim() || null,
    stage:         document.getElementById('jf-stage')?.value  || 'Lead',
    source:        document.getElementById('jf-source')?.value || null,
    value:         parseFloat(document.getElementById('jf-value')?.value) || null,
    probability:   parseInt(document.getElementById('jf-prob')?.value) || 50,
    owner:         document.getElementById('jf-owner')?.value.trim() || null,
    target_close:  document.getElementById('jf-close')?.value  || null,
    notes:         document.getElementById('jf-notes')?.value.trim() || null,
  };

  const saveBtn = document.querySelector('#det-foot .btn-primary');
  if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'Saving…'; }

  try {
    const r = await fetch('/api/jobs', {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    toast(editId ? 'Job updated' : `Job ${payload.job_number} created`);
    _jobAll = await apiFetch('/api/jobs') || _jobAll;
    _jobRenderView();
    window._calRefreshJobs?.();
    const newId = (j.data && j.data.id) || editId;
    if (newId) {
      _jobActiveTab = 'overview';
      await _jobOpen(newId);
    } else {
      detClose();
    }
  } catch(e) {
    toast(e.message, 'err');
    if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = editId ? 'Save Changes' : 'Create Job'; }
  }
};

// ── Copy job ──────────────────────────────────────────────────────────────────
// Copies the open job as a new Lead with a new number and no dates. Tasks,
// materials and to-dos are optional; history and money (comms, quotes,
// claims, visits, time, invoices, bills, POs) stay with the original.
window._jobCopyDlg = async function() {
  if (!_jobDetail) return;
  const { job, work_tasks, bom, crm_tasks } = _jobDetail;
  try { _jobContacts = (await apiFetch('/api/contacts')) || []; } catch(e) {}
  const conOpts = `<option value="">— none —</option>` + (_jobContacts||[]).map(c =>
    `<option value="${c.id}"${job.contact_id==c.id?' selected':''}>${esc(c.name)}</option>`).join('');
  const box = (id, label, n) => `
    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:4px 0">
      <input type="checkbox" id="${id}" ${n ? 'checked' : 'disabled'}>
      ${label} (${n})
    </label>`;
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:min(460px,96vw)">
    <div class="modal-hdr">Copy Job — ${esc(job.job_number)}</div>
    <div class="modal-body">
      <div class="modal-field"><label class="modal-lbl">New job name *</label>
        <input class="modal-inp" id="jcp-name" value="${esc(job.name + ' (copy)')}"></div>
      <div class="modal-field">
        <div class="lbl-line">
          <label class="modal-lbl">Client / Contact</label>
          <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();_jobNewContact('jcp-contact','Customer')">+ New</a>
        </div>
        <select class="modal-sel" id="jcp-contact">${conOpts}</select></div>
      <div class="modal-field"><label class="modal-lbl">Also copy</label>
        ${box('jcp-tasks', 'Tasks', (work_tasks||[]).length)}
        ${box('jcp-materials', 'Materials', (bom||[]).length)}
        ${box('jcp-todos', 'To-dos', (crm_tasks||[]).length)}
      </div>
      <div class="jcb-hint">The copy starts as a Lead with a new job number and no dates.
        Tasks and to-dos start open; nothing is invoiced or ordered. Comms, quotes, claims, visits,
        time and purchases stay with the original.</div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-primary" id="jcp-go" onclick="_jobCopyDo(${job.id})">Copy Job</button>
      <button class="btn btn-outline" onclick="this.closest('.modal-bd').remove()">Cancel</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  bd.addEventListener('click', e => { if (e.target === bd) bd.remove(); });
  setTimeout(() => { const n = document.getElementById('jcp-name'); n?.focus(); n?.select(); }, 50);
};

window._jobCopyDo = async function(jobId) {
  const name = document.getElementById('jcp-name')?.value.trim();
  if (!name) { toast('Job name is required', 'err'); return; }
  const btn = document.getElementById('jcp-go');
  if (btn) { btn.disabled = true; btn.textContent = 'Copying…'; }
  const payload = {
    name,
    contact_id: document.getElementById('jcp-contact')?.value || '',
    tasks:      !!document.getElementById('jcp-tasks')?.checked,
    materials:  !!document.getElementById('jcp-materials')?.checked,
    todos:      !!document.getElementById('jcp-todos')?.checked,
  };
  try {
    const r = await fetch(`/api/jobs/${jobId}/copy`, {
      method:'POST', credentials:'include',
      headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Copy failed');
    btn?.closest('.modal-bd')?.remove();
    toast(`Job ${j.data.job_number} created`);
    _jobAll = await apiFetch('/api/jobs') || _jobAll;
    _jobRenderView();
    window._calRefreshJobs?.();
    _jobActiveTab = 'overview';
    await _jobOpen(j.data.id);
  } catch(e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Copy Job'; }
  }
};

// ── Job Card PDF ──────────────────────────────────────────────────────────────
window._jobCardPdf = function(jobId) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:320px">
    <div class="modal-hdr">Job Card PDF</div>
    <div class="modal-body" style="padding:16px 20px 8px">
      <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:14px">
        <input type="checkbox" id="jc-financials" style="width:15px;height:15px;accent-color:var(--accent)">
        Include P&amp;L Summary
      </label>
    </div>
    <div class="modal-foot">
      <button class="btn btn-primary" onclick="
        const fin = document.getElementById('jc-financials').checked ? '1' : '0';
        window.open('/api/jobs/${jobId}/pdf?financials='+fin,'_blank');
        this.closest('.modal-bd').remove();
      ">Open PDF</button>
      <button class="btn btn-outline" onclick="this.closest('.modal-bd').remove()">Cancel</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  bd.addEventListener('click', e => { if (e.target === bd) bd.remove(); });
};

// ── Delete ────────────────────────────────────────────────────────────────────
window._jobDelete = async function(id) {
  const job = _jobAll.find(j => j.id === id);
  const name = job ? `'${job.name}'` : 'this job';
  if (!await confirmDlg(`Delete job ${name}? Allocations will be removed but transactions are kept.`)) return;
  try {
    const r = await fetch(`/api/jobs/${id}`, { method:'DELETE', credentials:'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Delete failed');
    toast('Job deleted');
    detClose();
    _jobAll = _jobAll.filter(j => j.id !== id);
    _jobSelectedId = null;
    _jobRenderView();
    window._calRefreshJobs?.();
  } catch(e) { toast(e.message, 'err'); }
};

// ── Quick Stage modal ─────────────────────────────────────────────────────────
window._jobQuickStage = function(jobId, currentStage) {
  const opts = PIPELINE_STAGES.map(s =>
    `<option value="${s}"${s===currentStage?' selected':''}>${s}</option>`
  ).join('');

  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box" style="width:min(340px,94vw)">
      <div class="modal-hdr"><span>Move Stage</span></div>
      <div class="modal-body">
        <div class="edt-field">
          <label class="edt-lbl">Stage</label>
          <select class="edt-sel" id="qs-stage">${opts}</select>
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" id="qs-apply">Apply</button>
      </div>
    </div>`;
  document.body.appendChild(bd);

  bd.querySelector('#qs-apply').onclick = async () => {
    const newStage = bd.querySelector('#qs-stage').value;
    bd.querySelector('#qs-apply').disabled = true;
    try {
      const r = await fetch(`/api/jobs/${jobId}/stage`, {
        method: 'PATCH', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stage: newStage }),
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Save failed');
      toast('Stage updated');
      bd.remove();
      _jobAll = await apiFetch('/api/jobs') || _jobAll;
      _jobRenderView();
      window._calRefreshJobs?.();
      await _jobOpen(jobId);
    } catch(e) {
      toast(e.message, 'err');
      bd.querySelector('#qs-apply').disabled = false;
    }
  };
};

// ═══════════════════════════════════════════════════════════════════════════
// SHARED REFRESH HELPER
// ═══════════════════════════════════════════════════════════════════════════

async function _jobRefreshDetail(jobId, tab) {
  try {
    const [det, time] = await Promise.all([
      apiFetch(`/api/jobs/${jobId}`),
      apiFetch(`/api/jobs/${jobId}/time`),
    ]);
    _jobDetail = { ...det, time: time || [] };
    _jobAll    = await apiFetch('/api/jobs') || _jobAll;
    _jobRenderView();

    // Restore the det-panel content cleanly
    const titleEl = document.getElementById('det-title');
    const bodyEl  = document.getElementById('det-body');
    const footEl  = document.getElementById('det-foot');
    if (!titleEl || !bodyEl || !footEl) return;

    _jobActiveTab = tab || _jobActiveTab;
    _jobRenderDetail();
  } catch(e) {
    toast(`Refresh failed: ${e.message}`, 'err');
  }
}

// Expose legacy alias used by older bookmarks/tests
window.jobOpen          = window._jobOpen;
window.jobNew           = window._jobNew;
window.jobDelete        = window._jobDelete;
window._jobRenderDetail = _jobRenderDetail;
