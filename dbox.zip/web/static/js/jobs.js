// ═══════════════════════════════════════════════════════════════════════════
// jobs.js — Jobs & Project Costing module  (Stage 5c)
// Depends on shared helpers in dashboard.html:
//   GET, POST, DELETE, fmt, fmtDate, esc, today, toast, confirm,
//   detClose(), _attachTypeahead(), _loadItems()
//   Shared slide-over: det-panel / det-overlay / det-title / det-body / det-foot
// ═══════════════════════════════════════════════════════════════════════════

'use strict';

// ── Self-contained API helpers (dashboard.html exposes apiFetch/confirmDlg) ──
async function _jApi(path, opts = {}) {
  const res = await fetch(path, {
    credentials: 'include',
    method: opts.method || 'GET',
    headers: opts.body ? { 'Content-Type': 'application/json' } : undefined,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  if (res.redirected || res.status === 401) { window.location.href = '/login'; return null; }
  const j = await res.json();
  if (!j.ok) throw new Error(j.error || 'API error');
  return j;
}
const _jGet    = p          => _jApi(p);
const _jPost   = (p, body)  => _jApi(p, { method: 'POST',   body });
const _jDelete = p          => _jApi(p, { method: 'DELETE' });

// ── Module state ──────────────────────────────────────────────────────────────
let _allJobs      = [];
let _jobsFilter   = '';     // active status pill value
let _jobsSort     = { col: 'id', dir: 'desc' };
let _jobSearch    = '';
let _contactCache = null;   // lazily loaded for new/edit form

// ── Entry point ───────────────────────────────────────────────────────────────
window.pageJobs = async function () {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading…</div>';

  try {
    const jobs = (await _jGet('/api/jobs')).data;
    _allJobs = jobs;
    _jobsFilter = '';
    _jobsSort   = { col: 'id', dir: 'desc' };
    _jobSearch  = '';
    _renderJobsPage(mod);
    _renderJobsTable();
  } catch (e) {
    mod.innerHTML = `<div class="state-error">Failed to load jobs: ${esc(e.message)}</div>`;
  }
};

// ── Page scaffold ─────────────────────────────────────────────────────────────
function _renderJobsPage(container) {
  const statuses = ['Active', 'On Hold', 'Completed', 'Cancelled'];
  const pills = statuses.map(s =>
    `<button class="filter-btn" data-status="${esc(s)}" onclick="_jobPill(this,'${esc(s)}')">${esc(s)}</button>`
  ).join('');

  container.innerHTML = `
    <div class="inv-toolbar">
      <div class="inv-filter-group">
        <button class="filter-btn active" data-status="" onclick="_jobPill(this,'')">All</button>
        ${pills}
      </div>
      <input class="inv-search" id="jobs-search" placeholder="Search jobs…"
             oninput="_jobSearch=this.value;_renderJobsTable()">
      <span class="count-pill" id="jobs-count"></span>
      <button class="btn btn-primary ml-auto" onclick="jobNew()">+ New Job</button>
    </div>

    <div class="inv-list-panel">
      <table class="inv-list-table" id="jobs-table">
        <thead>
          <tr>
            <th onclick="_jobSort('job_number')">#</th>
            <th onclick="_jobSort('name')">Job Name</th>
            <th onclick="_jobSort('contact_name')">Contact</th>
            <th onclick="_jobSort('status')">Status</th>
            <th onclick="_jobSort('start_date')">Start</th>
            <th onclick="_jobSort('manager')">Manager</th>
            <th class="r" onclick="_jobSort('budget_amount')">Budget</th>
            <th></th>
          </tr>
        </thead>
        <tbody id="jobs-body"></tbody>
      </table>
    </div>`;
}

// ── Table render ──────────────────────────────────────────────────────────────
function _filteredJobs() {
  const q = (_jobSearch || '').toLowerCase();
  return _allJobs.filter(j => {
    if (_jobsFilter && j.status !== _jobsFilter) return false;
    if (q && !((j.job_number||'').toLowerCase().includes(q) ||
               (j.name||'').toLowerCase().includes(q) ||
               (j.contact_name||'').toLowerCase().includes(q) ||
               (j.manager||'').toLowerCase().includes(q))) return false;
    return true;
  }).sort((a, b) => {
    const { col, dir } = _jobsSort;
    const av = a[col] ?? '', bv = b[col] ?? '';
    const cmp = typeof av === 'number' ? av - bv : String(av).localeCompare(String(bv));
    return dir === 'asc' ? cmp : -cmp;
  });
}

function _renderJobsTable() {
  const rows = _filteredJobs();
  const cnt  = document.getElementById('jobs-count');
  if (cnt) cnt.textContent = `${rows.length} job${rows.length !== 1 ? 's' : ''}`;

  // Update sort indicators
  document.querySelectorAll('#jobs-table th').forEach(th => {
    th.classList.remove('sort-asc', 'sort-desc');
    const col = (th.getAttribute('onclick') || '').match(/'([^']+)'/);
    if (col && col[1] === _jobsSort.col) {
      th.classList.add(_jobsSort.dir === 'asc' ? 'sort-asc' : 'sort-desc');
    }
  });

  const tbody = document.getElementById('jobs-body');
  if (!tbody) return;

  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="8">
      <div class="job-list-empty">
        <div class="job-list-empty-icon">🏗</div>
        No jobs found. <button class="btn btn-outline ml-8" onclick="jobNew()">+ New Job</button>
      </div></td></tr>`;
    return;
  }

  tbody.innerHTML = rows.map(j => `
    <tr class="inv-row" onclick="jobOpen(${j.id})">
      <td class="inv-mono">${esc(j.job_number||'')}</td>
      <td class="inv-contact">${esc(j.name||'')}</td>
      <td>${esc(j.contact_name||'—')}</td>
      <td>${_jobStatusBadge(j.status)}</td>
      <td class="inv-mono">${fmtDate(j.start_date)||'—'}</td>
      <td>${esc(j.manager||'—')}</td>
      <td class="inv-amt">${j.budget_amount ? fmt(j.budget_amount) : '—'}</td>
      <td class="job-actions-col">
        <button class="btn btn-sm btn-outline btn-xs-md"
                onclick="event.stopPropagation();jobEdit(${j.id})">Edit</button>
        <button class="btn btn-sm btn-danger btn-xs-md ml-4"
                onclick="event.stopPropagation();jobDelete(${j.id})">Delete</button>
      </td>
    </tr>`).join('');
}

// ── Filter / sort controls ────────────────────────────────────────────────────
window._jobPill = function (el, status) {
  document.querySelectorAll('.inv-filter-group .filter-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  _jobsFilter = status;
  _renderJobsTable();
};

window._jobSort = function (col) {
  if (_jobsSort.col === col) {
    _jobsSort.dir = _jobsSort.dir === 'asc' ? 'desc' : 'asc';
  } else {
    _jobsSort = { col, dir: 'asc' };
  }
  _renderJobsTable();
};

// ── Status badge ──────────────────────────────────────────────────────────────
function _jobStatusBadge(status) {
  const clsMap = {
    'Active':    'job-badge-active',
    'On Hold':   'job-badge-hold',
    'Completed': 'job-badge-completed',
    'Cancelled': 'job-badge-cancelled',
    'Draft':     'job-badge-draft',
  };
  const cls = clsMap[status] || '';
  return `<span class="job-badge ${cls}">${esc(status||'—')}</span>`;
}

// ═══════════════════════════════════════════════════════════════════════════
// SLIDE-OVER DETAIL
// ═══════════════════════════════════════════════════════════════════════════

// Helper: open the shared slide-over and show a loading state
function _jPanelLoading(title) {
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = title || 'Job';
  document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading…</div>';
  document.getElementById('det-foot').innerHTML = '';
}

// Helper: populate the shared slide-over with content + footer buttons
function _jPanelOpen(title, bodyHTML, footerButtons) {
  document.getElementById('det-title').textContent = title;
  document.getElementById('det-body').innerHTML    = bodyHTML;
  document.getElementById('det-foot').innerHTML    = footerButtons
    .map(b => `<button class="btn ${b.cls||'btn-outline'}" onclick="${b.fn}">${esc(b.label)}</button>`)
    .join('');
}

// ── Open job detail ───────────────────────────────────────────────────────────
window.jobOpen = async function (id) {
  _jPanelLoading('Job');
  try {
    const [detRes, timeRes, tasksRes] = await Promise.all([
      _jGet(`/api/jobs/${id}`),
      _jGet(`/api/jobs/${id}/time`),
      _jGet(`/api/jobs/${id}/tasks`),
    ]);
    const tasksData = tasksRes.data || {};
    _renderJobDetail(
      detRes.data.job, detRes.data.pl,
      detRes.data.transactions || [],
      timeRes.data || [],
      tasksData.crm_tasks  || [],
      tasksData.work_tasks || [],
    );
  } catch (e) {
    document.getElementById('det-body').innerHTML =
      `<div class="state-error">Failed to load: ${esc(e.message)}</div>`;
  }
};

function _renderJobDetail(job, pl, transactions, timeEntries, crmTasks, workTasks) {
  timeEntries = timeEntries || [];
  const budget   = job.budget_amount || 0;
  const pct      = budget ? Math.min((pl.total_costs || 0) / budget * 100, 150) : 0;
  const barClass = pct > 100 ? 'var(--red)' : pct > 80 ? 'var(--amber)' : 'var(--green)';
  const margin   = pl.revenue ? ((pl.gross_profit / pl.revenue) * 100).toFixed(1) : null;

  crmTasks  = crmTasks  || [];
  workTasks = workTasks || [];
  const totalTaskCount = crmTasks.length + workTasks.length;

  // ── Tabs ──────────────────────────────────────────────────────────────────
  const tabBar = `
    <div class="job-tab-bar">
      <button class="job-tab-btn active" data-tab="meta" onclick="_jobTab(this,'meta',${job.id})">
        Details
      </button>
      <button class="job-tab-btn" data-tab="pl" onclick="_jobTab(this,'pl',${job.id})">
        P&amp;L
      </button>
      <button class="job-tab-btn" data-tab="txns" onclick="_jobTab(this,'txns',${job.id})">
        Transactions
        ${transactions.length ? `<span class="job-tab-count">${transactions.length}</span>` : ''}
      </button>
      <button class="job-tab-btn" data-tab="tasks" onclick="_jobTab(this,'tasks',${job.id})">
        Tasks
        ${totalTaskCount ? `<span class="job-tab-count">${totalTaskCount}</span>` : ''}
      </button>
      <button class="job-tab-btn" data-tab="time" onclick="_jobTab(this,'time',${job.id})">
        Employee Time
      </button>
    </div>`;

  // ── Meta tab ──────────────────────────────────────────────────────────────
  const metaBody = `
    <div class="det-meta">
      <div>
        <div class="det-lbl">Job Number</div>
        <div class="job-mono-bold">${esc(job.job_number||'')}</div>
      </div>
      <div>
        <div class="det-lbl">Status</div>
        <div>${_jobStatusBadge(job.status)}</div>
      </div>
      <div>
        <div class="det-lbl">Client / Contact</div>
        <div>${esc(job.contact_name||'—')}</div>
      </div>
      <div>
        <div class="det-lbl">Manager</div>
        <div>${esc(job.manager||'—')}</div>
      </div>
      <div>
        <div class="det-lbl">Start Date</div>
        <div class="inv-mono">${fmtDate(job.start_date)||'—'}</div>
      </div>
      <div>
        <div class="det-lbl">End Date</div>
        <div class="inv-mono">${fmtDate(job.end_date)||'Ongoing'}</div>
      </div>
      ${job.budget_amount ? `
      <div>
        <div class="det-lbl">Budget</div>
        <div class="job-mono-bold">${fmt(job.budget_amount)}</div>
      </div>` : ''}
      ${job.budget_notes ? `
      <div>
        <div class="det-lbl">Budget Notes</div>
        <div class="job-txt-sm">${esc(job.budget_notes)}</div>
      </div>` : ''}
      ${job.description ? `
      <div class="job-grid-full">
        <div class="det-lbl">Description</div>
        <div class="job-txt-sm-ink2">${esc(job.description)}</div>
      </div>` : ''}
    </div>`;

  // ── P&L tab ───────────────────────────────────────────────────────────────
  const plBody = `
    <div class="job-stat-grid">
      <div class="job-stat-card">
        <div class="job-stat-lbl">Revenue</div>
        <div class="job-stat-val col-green">${fmt(pl.revenue||0)}</div>
      </div>
      <div class="job-stat-card">
        <div class="job-stat-lbl">Total Costs</div>
        <div class="job-stat-val col-red">${fmt(pl.total_costs||0)}</div>
      </div>
      <div class="job-stat-card">
        <div class="job-stat-lbl">Gross Profit</div>
        <div class="job-stat-val" style="color:${(pl.gross_profit||0)>=0?'var(--green)':'var(--red)'}">${fmt(pl.gross_profit||0)}</div>
      </div>
    </div>

    <div class="job-pl-card">
      <div class="job-pl-row">
        <span class="col-ink2">Bill Costs</span>
        <span class="inv-mono col-red">${fmt(pl.bill_costs||0)}</span>
      </div>
      <div class="job-pl-row">
        <span class="col-ink2">Journal Costs</span>
        <span class="inv-mono col-red">${fmt(pl.journal_costs||0)}</span>
      </div>
      <div class="job-pl-sep"></div>
      <div class="job-pl-row-m">
        <span>Gross Margin</span>
        <span class="inv-mono" style="color:${(pl.gross_profit||0)>=0?'var(--green)':'var(--red)'}">
          ${margin !== null ? margin + '%' : '—'}
        </span>
      </div>
      ${budget ? `
      <div class="job-pl-sep"></div>
      <div class="job-budget-row">
        <span>Budget utilisation</span>
        <span class="inv-mono">${fmt(pl.total_costs||0)} / ${fmt(budget)}</span>
      </div>
      <div class="job-budget-bar">
        <div style="height:100%;width:${Math.min(pct,100)}%;background:${barClass};border-radius:4px;transition:width 0.5s ease"></div>
      </div>
      <div class="job-budget-meta">
        <span>Budget variance</span>
        <span style="color:${(pl.budget_variance||0)>=0?'var(--green)':'var(--red)'}">${fmt(pl.budget_variance||0)}</span>
      </div>` : ''}
    </div>`;

  // ── Transactions tab ──────────────────────────────────────────────────────
  const txnsBody = transactions.length ? `
    <table class="inv-list-table tbl-sm">
      <thead><tr>
        <th>Type</th><th>Ref</th><th>Date</th><th>Contact</th>
        <th class="r">Amount</th><th>Notes</th><th></th>
      </tr></thead>
      <tbody>
        ${transactions.map(t => `<tr>
          <td><span class="job-src-badge">${esc(t.source_type||'')}</span></td>
          <td class="inv-mono">${esc(t.ref_number||t.source_id||'')}</td>
          <td class="inv-mono">${fmtDate(t.txn_date)||'—'}</td>
          <td>${esc(t.contact_name||'—')}</td>
          <td class="inv-amt">${fmt(t.amount||0)}</td>
          <td class="job-note">${esc(t.notes||'')}</td>
          <td><button class="btn btn-sm btn-danger btn-xs"
              onclick="jobDeallocate(${t.id},${job.id})">Remove</button></td>
        </tr>`).join('')}
      </tbody>
    </table>
    <div class="job-alloc-mt">
      <button class="btn btn-outline" onclick="jobAllocate(${job.id})">+ Allocate Transaction</button>
    </div>` : `
    <div class="job-empty">
      <div class="job-empty-icon">📎</div>
      <div class="job-empty-sm">No transactions allocated to this job yet.</div>
      <button class="btn btn-outline job-empty-btn" onclick="jobAllocate(${job.id})">+ Allocate Transaction</button>
    </div>`;

  // ── Tasks tab ─────────────────────────────────────────────────────────────
  function _taskPriBadge(p) {
    const cls = { Low: 'job-badge-draft', Normal: '', High: 'job-badge-hold', Urgent: 'job-badge-active' }[p] || '';
    return `<span class="job-badge ${cls}" style="font-size:11px">${esc(p||'Normal')}</span>`;
  }

  const _crmSection = crmTasks.length ? `
    <div class="job-section-hdr job-section-mb">CRM Tasks</div>
    <table class="inv-list-table tbl-sm job-tbl-mb">
      <thead><tr>
        <th>Title</th><th>Type</th><th>Opportunity</th>
        <th>Due</th><th>Assigned</th><th>Priority</th><th></th>
      </tr></thead>
      <tbody>
        ${crmTasks.map(t => `<tr class="${t.is_done ? 'job-task-done-row' : ''}">
          <td>${esc(t.title||'')}</td>
          <td>${esc(t.task_type||'')}</td>
          <td class="inv-mono">${t.opp_number ? esc(t.opp_number) : '—'}</td>
          <td class="inv-mono">${fmtDate(t.due_date)||'—'}</td>
          <td>${esc(t.assigned_to||'—')}</td>
          <td>${_taskPriBadge(t.priority)}</td>
          <td style="text-align:center;color:var(--green)">${t.is_done ? '✓' : ''}</td>
        </tr>`).join('')}
      </tbody>
    </table>` : '';

  const _workSection = workTasks.length ? `
    <div class="job-section-hdr job-section-mb">Contact Tasks</div>
    <table class="inv-list-table tbl-sm">
      <thead><tr>
        <th>Title</th><th>Contact</th><th>Qty</th>
        <th class="r">Unit Price</th><th>Opportunity</th><th></th>
      </tr></thead>
      <tbody>
        ${workTasks.map(t => `<tr class="${t.is_done ? 'job-task-done-row' : ''}">
          <td>${esc(t.title||'')}</td>
          <td>${esc(t.contact_name||'—')}</td>
          <td class="inv-mono">${(t.qty||1) != 1 ? t.qty : ''}</td>
          <td class="inv-amt">${t.unit_price ? fmt(t.unit_price) : '—'}</td>
          <td class="inv-mono">${t.opp_number ? esc(t.opp_number) : '—'}</td>
          <td style="text-align:center;color:var(--green)">${t.is_done ? '✓' : ''}</td>
        </tr>`).join('')}
      </tbody>
    </table>` : '';

  const tasksBody = (crmTasks.length || workTasks.length) ? `
    ${_crmSection}${_workSection}` : `
    <div class="job-empty">
      <div class="job-empty-icon">✅</div>
      <div class="job-empty-sm">No tasks linked to this job.</div>
      <div class="job-empty-sm" style="font-size:12px;margin-top:4px">
        Link tasks by setting the Job field on a CRM task or contact task.
      </div>
    </div>`;

  // ── Employee Time tab ─────────────────────────────────────────────────────
  const totalHours = timeEntries.reduce((s, e) => s + (e.hours || 0), 0);
  const totalCost  = timeEntries.reduce((s, e) => s + (e.hours || 0) * (e.hourly_rate || 0), 0);

  // Per-employee profitability summary
  const empMap = {};
  for (const e of timeEntries) {
    const key = e.employee_id;
    if (!empMap[key]) empMap[key] = { name: `${e.first_name} ${e.last_name}`, hours: 0, cost: 0 };
    empMap[key].hours += e.hours || 0;
    empMap[key].cost  += (e.hours || 0) * (e.hourly_rate || 0);
  }
  const empSummaryRows = Object.values(empMap).map(emp => {
    const revShare = totalHours ? (pl.revenue || 0) * (emp.hours / totalHours) : 0;
    const profit   = revShare - emp.cost;
    return `<tr>
      <td>${esc(emp.name)}</td>
      <td class="td-r-mono">${emp.hours.toFixed(1)}h</td>
      <td class="td-r-mono">${fmt(emp.cost)}</td>
      <td class="td-r-mono">${fmt(revShare)}</td>
      <td class="td-r-mono" style="color:${profit>=0?'var(--green)':'var(--red)'}">${fmt(profit)}</td>
    </tr>`;
  }).join('');

  const timeBody = timeEntries.length ? `
    ${empSummaryRows ? `
    <div class="job-section-hdr job-section-mb">By Employee</div>
    <table class="inv-list-table tbl-sm job-tbl-mb">
      <thead><tr>
        <th>Employee</th><th class="th-r">Hours</th><th class="th-r">Cost</th>
        <th class="th-r">Rev Share</th><th class="th-r">Profit</th>
      </tr></thead>
      <tbody>${empSummaryRows}</tbody>
    </table>` : ''}
    <div class="job-section-row">
      <div class="job-section-hdr">Time Entries</div>
      <button class="btn btn-sm btn-outline" onclick="_jobTimeForm(${job.id},null)">+ Log Time</button>
    </div>
    <table class="inv-list-table tbl-sm">
      <thead><tr>
        <th>Employee</th><th>Date</th><th class="th-r">Hours</th>
        <th class="th-r">Rate</th><th class="th-r">Cost</th><th>Notes</th><th></th>
      </tr></thead>
      <tbody>
        ${timeEntries.map(e => `<tr>
          <td>${esc(e.first_name + ' ' + e.last_name)}</td>
          <td class="inv-mono">${fmtDate(e.entry_date)||'—'}</td>
          <td class="td-r-mono">${(e.hours||0).toFixed(1)}</td>
          <td class="td-r-mono">$${(e.hourly_rate||0).toFixed(2)}</td>
          <td class="td-r-mono">${fmt((e.hours||0)*(e.hourly_rate||0))}</td>
          <td class="job-note">${esc(e.description||'')}</td>
          <td class="job-actions-col">
            <button class="btn btn-sm btn-outline btn-xs"
              onclick="_jobTimeForm(${job.id},${e.id})">Edit</button>
            <button class="btn btn-sm btn-danger btn-xs ml-3"
              onclick="_jobTimeDelete(${e.id},${job.id})">✕</button>
          </td>
        </tr>`).join('')}
        <tr class="job-total-row">
          <td>TOTAL</td><td></td>
          <td class="td-r-mono">${totalHours.toFixed(1)}</td>
          <td></td>
          <td class="td-r-mono">${fmt(totalCost)}</td>
          <td colspan="2"></td>
        </tr>
      </tbody>
    </table>` : `
    <div class="job-empty">
      <div class="job-empty-icon">⏱</div>
      <div class="job-empty-sm">No time entries logged yet.</div>
      <button class="btn btn-outline job-empty-btn"
        onclick="_jobTimeForm(${job.id},null)">+ Log Time</button>
    </div>`;

  // Store tab content for switching without refetch
  document.getElementById('det-body').dataset.jobId  = job.id;
  document.getElementById('det-body').dataset.meta   = metaBody;
  document.getElementById('det-body').dataset.pl     = plBody;
  document.getElementById('det-body').dataset.txns   = txnsBody;
  document.getElementById('det-body').dataset.tasks  = tasksBody;
  document.getElementById('det-body').dataset.time   = timeBody;

  document.getElementById('det-title').textContent = `${job.job_number} — ${job.name}`;
  document.getElementById('det-body').innerHTML = tabBar + metaBody;
  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-outline" onclick="jobEdit(${job.id})">✎ Edit</button>
    <button class="btn btn-outline" onclick="jobAllocate(${job.id})">+ Allocate</button>
    <button class="btn btn-outline" onclick="_jobPrintPdf(${job.id})">⎙ Print</button>
    <button class="btn btn-danger"  onclick="jobDelete(${job.id})">Delete</button>
    <button class="btn btn-outline ml-auto" onclick="detClose()">Close</button>`;
}

// Tab switcher
window._jobTab = function (el, tab, jobId) {
  document.querySelectorAll('.job-tab-btn').forEach(t => t.classList.remove('active'));
  el.classList.add('active');

  const body = document.getElementById('det-body');
  const tabBar = body.querySelector('.job-tab-bar');
  const tabBarHTML = tabBar ? tabBar.outerHTML : '';

  const content = {
    meta: body.dataset.meta, pl: body.dataset.pl,
    txns: body.dataset.txns, tasks: body.dataset.tasks, time: body.dataset.time,
  };
  body.innerHTML = tabBarHTML + (content[tab] || '');

  // Re-cache datasets (innerHTML wipe clears them)
  body.dataset.jobId = jobId;
  body.dataset.meta  = content.meta;
  body.dataset.pl    = content.pl;
  body.dataset.txns  = content.txns;
  body.dataset.tasks = content.tasks;
  body.dataset.time  = content.time;
};

// ═══════════════════════════════════════════════════════════════════════════
// NEW / EDIT FORM
// ═══════════════════════════════════════════════════════════════════════════

window.jobNew = async function () {
  await _jobForm(null);
};

window.jobEdit = async function (id) {
  _jPanelLoading('Loading…');
  try {
    const { data } = await _jGet(`/api/jobs/${id}`);
    await _jobForm(data.job);
  } catch (e) {
    document.getElementById('det-body').innerHTML =
      `<div class="state-error">Failed to load: ${esc(e.message)}</div>`;
  }
};

async function _jobForm(existing) {
  // Load contacts + next number in parallel if needed
  const [contacts, nextNum] = await Promise.all([
    _loadContacts(),
    existing ? Promise.resolve(existing.job_number) : _jGet('/api/jobs/next-number').then(r => r.data),
  ]);

  const statuses = ['Active', 'On Hold', 'Completed', 'Cancelled'];
  const conOpts  = contacts.map(c =>
    `<option value="${c.id}" ${existing?.contact_id == c.id ? 'selected' : ''}>${esc(c.name)}</option>`
  ).join('');

  const formHTML = `
    <div class="job-form-grid">

      <div class="modal-field">
        <label class="modal-lbl">Job Number</label>
        <input class="modal-inp job-readonly-inp" id="jf-num" value="${esc(nextNum||'')}" readonly>
      </div>

      <div class="modal-field">
        <label class="modal-lbl">Status</label>
        <select class="modal-sel" id="jf-status">
          ${statuses.map(s =>
            `<option ${s === (existing?.status || 'Active') ? 'selected' : ''}>${esc(s)}</option>`
          ).join('')}
        </select>
      </div>

      <div class="modal-field job-grid-full">
        <label class="modal-lbl">Job Name *</label>
        <input class="modal-inp" id="jf-name" placeholder="e.g. Office Fitout — Level 3"
               value="${esc(existing?.name||'')}">
      </div>

      <div class="modal-field job-grid-full">
        <label class="modal-lbl">Description</label>
        <textarea class="modal-inp edt-ta-resize" id="jf-desc" rows="2">${esc(existing?.description||'')}</textarea>
      </div>

      <div class="modal-field">
        <label class="modal-lbl">Client / Contact</label>
        <select class="modal-sel" id="jf-contact">
          <option value="">— None —</option>
          ${conOpts}
        </select>
      </div>

      <div class="modal-field">
        <label class="modal-lbl">Manager</label>
        <input class="modal-inp" id="jf-manager" list="jf-manager-list"
               value="${esc(existing?.manager||'')}" placeholder="Type or select…" autocomplete="off">
        <datalist id="jf-manager-list">
          ${contacts.filter(c => c.has_employee || c.contact_type === 'Supplier')
            .map(c => `<option value="${esc(c.name)}">`).join('')}
        </datalist>
      </div>

      <div class="modal-field">
        <label class="modal-lbl">Start Date</label>
        <input class="modal-inp" id="jf-start" type="date"
               value="${existing?.start_date || isoToday()}">
      </div>

      <div class="modal-field">
        <label class="modal-lbl">End Date</label>
        <input class="modal-inp" id="jf-end" type="date"
               value="${existing?.end_date||''}">
      </div>

      <div class="modal-field">
        <label class="modal-lbl">Budget Amount</label>
        <input class="modal-inp" id="jf-budget" type="number" step="0.01" min="0"
               placeholder="0.00" value="${existing?.budget_amount||''}">
      </div>

      <div class="modal-field">
        <label class="modal-lbl">Budget Notes</label>
        <input class="modal-inp" id="jf-budget-notes" value="${esc(existing?.budget_notes||'')}">
      </div>

    </div>`;

  const isEdit = !!existing;
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = isEdit
    ? `Edit Job — ${existing.job_number}`
    : 'New Job';
  document.getElementById('det-body').innerHTML = formHTML;
  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-outline" onclick="detClose()">Cancel</button>
    <button class="btn btn-primary" onclick="_jobSave(${existing?.id || 'null'})">
      ${isEdit ? 'Save Changes' : 'Create Job'}
    </button>`;

  // Focus name field
  const nameEl = document.getElementById('jf-name');
  if (nameEl) setTimeout(() => nameEl.focus(), 80);
}

window._jobSave = async function (editId) {
  const name = (document.getElementById('jf-name').value || '').trim();
  if (!name) { toast('Job name is required', 'err'); return; }

  const payload = {
    id:            editId || null,
    job_number:    document.getElementById('jf-num').value,
    name,
    description:   document.getElementById('jf-desc').value,
    contact_id:    parseInt(document.getElementById('jf-contact').value) || null,
    status:        document.getElementById('jf-status').value,
    start_date:    document.getElementById('jf-start').value || null,
    end_date:      document.getElementById('jf-end').value   || null,
    budget_amount: parseFloat(document.getElementById('jf-budget').value) || null,
    budget_notes:  document.getElementById('jf-budget-notes').value || null,
    manager:       document.getElementById('jf-manager').value || null,
  };

  const saveBtn = document.querySelector('#det-foot .btn-primary');
  if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'Saving…'; }

  try {
    const res = await _jPost('/api/jobs', payload);
    toast(editId ? 'Job updated' : `Job ${payload.job_number} created`);
    detClose();
    // Refresh list + re-open detail if editing
    const jobs = (await _jGet('/api/jobs')).data;
    _allJobs = jobs;
    _renderJobsTable();
    if (editId) {
      await jobOpen(res.data.id || editId);
    }
  } catch (e) {
    toast(e.message, 'err');
    if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = editId ? 'Save Changes' : 'Create Job'; }
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// DELETE
// ═══════════════════════════════════════════════════════════════════════════

window.jobDelete = async function (id) {
  const job = _allJobs.find(j => j.id === id);
  const name = job ? `'${job.name}'` : 'this job';
  const ok = await confirmDlg(
    `Delete job ${name}? This will remove all allocations but keep the transactions.`
  );
  if (!ok) return;
  try {
    await _jDelete(`/api/jobs/${id}`);
    toast('Job deleted');
    detClose();
    _allJobs = _allJobs.filter(j => j.id !== id);
    _renderJobsTable();
  } catch (e) {
    toast(e.message, 'err');
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// ALLOCATE TRANSACTION PICKER
// ═══════════════════════════════════════════════════════════════════════════

window.jobAllocate = async function (jobId) {
  // Show allocation picker inside a second slide-over using the modal layer
  // to avoid fighting the slide-over state, we use an inline approach
  // within the slide-over body itself.
  const body = document.getElementById('det-body');
  const prevBody = body.innerHTML;
  const prevFoot = document.getElementById('det-foot').innerHTML;

  body.innerHTML = '<div class="state-loading">Loading unallocated transactions…</div>';
  document.getElementById('det-foot').innerHTML = '';

  try {
    const { data } = await _jGet('/api/jobs/unallocated');
    const invs  = data.invoices || [];
    const bills = data.bills    || [];
    const pmts  = data.payments || [];

    if (!invs.length && !bills.length && !pmts.length) {
      body.innerHTML = `
        <div class="job-alloc-empty">
          <div class="job-empty-icon">📭</div>
          <div class="fa-del-hint">No unallocated transactions available.</div>
          <div class="job-alloc-note">
            All invoices, bills and payments are already allocated to jobs.
          </div>
        </div>`;
      document.getElementById('det-foot').innerHTML = `
        <button class="btn btn-outline" onclick="jobOpen(${jobId})">← Back</button>`;
      return;
    }

    // Build a combined picker
    const invRows = invs.map(i => `
      <tr class="inv-row" onclick="_jobAllocPick(${jobId},${i.id},'invoice',${i.total||0})">
        <td><span class="job-src-badge job-src-invoice">Invoice</span></td>
        <td class="inv-mono">${esc(i.invoice_number||'')}</td>
        <td class="inv-mono">${fmtDate(i.invoice_date)||'—'}</td>
        <td>${esc(i.contact_name||'—')}</td>
        <td class="inv-amt">${fmt(i.total||0)}</td>
      </tr>`).join('');

    const billRows = bills.map(b => `
      <tr class="inv-row" onclick="_jobAllocPick(${jobId},${b.id},'bill',${b.total||0})">
        <td><span class="job-src-badge job-src-bill">Bill</span></td>
        <td class="inv-mono">${esc(b.bill_number||'')}</td>
        <td class="inv-mono">${fmtDate(b.bill_date)||'—'}</td>
        <td>${esc(b.contact_name||'—')}</td>
        <td class="inv-amt">${fmt(b.total||0)}</td>
      </tr>`).join('');

    const pmtRows = pmts.map(p => `
      <tr class="inv-row" onclick="_jobAllocPick(${jobId},${p.id},'payment',${p.amount||0})">
        <td><span class="job-src-badge">Payment</span></td>
        <td class="inv-mono">${esc(p.reference||'')}</td>
        <td class="inv-mono">${fmtDate(p.payment_date)||'—'}</td>
        <td>${esc(p.contact_name||'—')}</td>
        <td class="inv-amt">${fmt(p.amount||0)}</td>
      </tr>`).join('');

    body.innerHTML = `
      <div class="job-alloc-hint">
        Select a transaction to allocate to this job. Click a row to continue.
      </div>
      <table class="inv-list-table">
        <thead><tr>
          <th>Type</th><th>Ref #</th><th>Date</th><th>Contact</th><th class="r">Amount</th>
        </tr></thead>
        <tbody>${invRows}${billRows}${pmtRows}</tbody>
      </table>`;

    document.getElementById('det-foot').innerHTML = `
      <button class="btn btn-outline" onclick="jobOpen(${jobId})">← Back</button>`;

  } catch (e) {
    body.innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`;
    document.getElementById('det-foot').innerHTML = `
      <button class="btn btn-outline" onclick="jobOpen(${jobId})">← Back</button>`;
  }
};

// Called when user clicks a row in the allocation picker
window._jobAllocPick = async function (jobId, sourceId, sourceType, amount) {
  // Show a small amount confirmation form inline
  const body = document.getElementById('det-body');
  body.innerHTML = `
    <div class="job-confirm-wrap">
      <div class="job-confirm-title">Confirm Allocation</div>
      <div class="job-confirm-sub">
        ${esc(sourceType.charAt(0).toUpperCase() + sourceType.slice(1))} ${sourceId}
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Amount to allocate</label>
        <input class="modal-inp" id="alloc-amount" type="number" step="0.01"
               value="${amount||0}" placeholder="0.00">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Notes (optional)</label>
        <input class="modal-inp" id="alloc-notes" placeholder="e.g. Phase 1 materials">
      </div>
    </div>`;

  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-outline" onclick="jobAllocate(${jobId})">← Back</button>
    <button class="btn btn-primary" onclick="_jobAllocConfirm(${jobId},${sourceId},'${sourceType}')">
      Allocate
    </button>`;
};

window._jobAllocConfirm = async function (jobId, sourceId, sourceType) {
  const amount = parseFloat(document.getElementById('alloc-amount').value) || 0;
  const notes  = (document.getElementById('alloc-notes').value || '').trim();

  const btn = document.querySelector('#det-foot .btn-primary');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }

  try {
    await _jPost(`/api/jobs/${jobId}/allocate`, {
      source_type: sourceType,
      source_id:   parseInt(sourceId),
      amount,
      notes,
    });
    toast('Transaction allocated');
    // Refresh list and detail
    _allJobs = (await _jGet('/api/jobs')).data;
    _renderJobsTable();
    await jobOpen(jobId);   // re-opens detail panel with fresh data
  } catch (e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Allocate'; }
  }
};

// ── Remove allocation ─────────────────────────────────────────────────────────
window.jobDeallocate = async function (allocId, jobId) {
  const ok = await confirmDlg('Remove this allocation? The transaction will not be deleted.');
  if (!ok) return;
  try {
    await _jDelete(`/api/jobs/allocations/${allocId}`);
    toast('Allocation removed');
    _allJobs = (await _jGet('/api/jobs')).data;
    _renderJobsTable();
    await jobOpen(jobId);
  } catch (e) {
    toast(e.message, 'err');
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// EMPLOYEE TIME — Log / Edit / Delete
// ═══════════════════════════════════════════════════════════════════════════

let _jobTimeEmployees = null;  // cache

async function _loadJobTimeEmployees() {
  if (_jobTimeEmployees) return _jobTimeEmployees;
  try {
    const data = await apiFetch('/api/payroll/employees');
    _jobTimeEmployees = Array.isArray(data) ? data : (data.employees || []);
  } catch (e) {
    _jobTimeEmployees = [];
  }
  return _jobTimeEmployees;
}

window._jobTimeForm = async function (jobId, entryId) {
  const [emps, existing] = await Promise.all([
    _loadJobTimeEmployees(),
    entryId ? _jGet(`/api/jobs/${jobId}/time/${entryId}`).then(r => r.data) : Promise.resolve(null),
  ]);

  const empOpts = emps.map(e => {
    const name = `${e.first_name} ${e.last_name}`;
    const sel  = existing && existing.employee_id === e.id ? 'selected' : '';
    return `<option value="${e.id}" data-rate="${e.hourly_rate||0}" ${sel}>${esc(name)}</option>`;
  }).join('');

  const today = isoToday();

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box modal-460">
      <div class="modal-hdr"><span>${entryId ? 'Edit Time Entry' : 'Log Time'}</span></div>
      <div class="modal-body">
        <div class="modal-field">
          <label class="modal-lbl">Employee *</label>
          <select class="modal-sel" id="jt-emp" onchange="_jtAutoRate(this)">${empOpts}</select>
        </div>
        <div class="modal-field">
          <label class="modal-lbl">Date *</label>
          <input class="modal-inp" id="jt-date" type="date"
                 value="${existing?.entry_date || today}">
        </div>
        <div class="modal-field">
          <label class="modal-lbl">Hours *</label>
          <input class="modal-inp" id="jt-hours" type="number" step="0.5" min="0.5"
                 value="${existing?.hours || 8}">
        </div>
        <div class="modal-field">
          <label class="modal-lbl">Hourly Rate ($)</label>
          <input class="modal-inp" id="jt-rate" type="number" step="0.01" min="0"
                 value="${existing?.hourly_rate || ''}">
          <div class="job-time-hint">Auto-filled from employee pay rate</div>
        </div>
        <div class="modal-field">
          <label class="modal-lbl">Description</label>
          <input class="modal-inp" id="jt-desc" value="${esc(existing?.description||'')}">
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="_jobTimeSave(${jobId},${entryId||'null'})">
          ${entryId ? 'Save Changes' : 'Log Time'}
        </button>
      </div>
    </div>`;
  document.body.appendChild(bd);

  // Auto-fill rate for initial selection if no existing rate
  if (!existing) {
    const sel = document.getElementById('jt-emp');
    if (sel) _jtAutoRate(sel);
  }
};

window._jtAutoRate = function (sel) {
  const rate = parseFloat(sel.selectedOptions[0]?.dataset.rate || 0);
  const rateEl = document.getElementById('jt-rate');
  if (rateEl && rate > 0) rateEl.value = rate.toFixed(2);
};

window._jobTimeSave = async function (jobId, entryId) {
  const empId = parseInt(document.getElementById('jt-emp').value) || null;
  const date  = document.getElementById('jt-date').value;
  const hours = parseFloat(document.getElementById('jt-hours').value) || 0;
  const rate  = parseFloat(document.getElementById('jt-rate').value)  || 0;
  const desc  = document.getElementById('jt-desc').value.trim();

  if (!empId)    { toast('Select an employee', 'err'); return; }
  if (!date)     { toast('Date is required', 'err'); return; }
  if (hours <= 0){ toast('Hours must be greater than 0', 'err'); return; }

  const btn = document.querySelector('.modal-bd .btn-primary');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }

  try {
    await _jPost(`/api/jobs/${jobId}/time`, {
      id: entryId || null, job_id: jobId,
      employee_id: empId, entry_date: date,
      hours, hourly_rate: rate, description: desc,
    });
    document.querySelector('.modal-bd')?.remove();
    toast(entryId ? 'Time entry updated' : 'Time logged');
    await jobOpen(jobId);
  } catch (e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = entryId ? 'Save Changes' : 'Log Time'; }
  }
};

window._jobTimeDelete = async function (entryId, jobId) {
  const ok = await confirmDlg('Delete this time entry?');
  if (!ok) return;
  try {
    await _jDelete(`/api/jobs/time/${entryId}`);
    toast('Time entry deleted');
    await jobOpen(jobId);
  } catch (e) {
    toast(e.message, 'err');
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════════════════

async function _loadContacts() {
  if (_contactCache) return _contactCache;
  try {
    _contactCache = (await _jGet('/api/contacts')).data || [];
  } catch (e) {
    _contactCache = [];
  }
  return _contactCache;
}

window._jobPrintPdf = function (jobId) {
  window.open(`/api/jobs/${jobId}/pdf`, '_blank');
};
