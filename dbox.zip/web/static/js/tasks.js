// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ═══════════════════════════════════════════════════════════════════════════
// tasks.js — Billable Tasks hub page (prefix: _tsk)
// Same work_tasks record contacts.js/jobs.js already create — this is just a
// third entry point (Jobs & Quotes hub, no Job/Contact context to inherit
// from) so it's the only one of the three that shows a Client picker.
// Uses shared helpers from dashboard.html: apiFetch, esc, fmtDate, isoToday,
// quickNewContact, confirmDlg
// ═══════════════════════════════════════════════════════════════════════════

'use strict';

let _tskAll      = [];
let _tskContacts = [];
let _tskJobs     = [];
let _tskFilter   = 'Open';   // 'All' | 'Open' | 'Completed'
let _tskSearch   = '';

window.pageTasks = async function () {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    [_tskAll, _tskContacts, _tskJobs] = await Promise.all([
      apiFetch('/api/work-tasks'),
      apiFetch('/api/contacts'),
      apiFetch('/api/jobs'),
    ]);
    _tskAll      = _tskAll      || [];
    _tskContacts = _tskContacts || [];
    _tskJobs     = _tskJobs     || [];
    _tskRenderPage();
  } catch (e) {
    mod.innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`;
  }
};

function _tskFiltered () {
  const q = _tskSearch.toLowerCase();
  return _tskAll.filter(t => {
    if (_tskFilter === 'Open' && t.is_done) return false;
    if (_tskFilter === 'Completed' && !t.is_done) return false;
    if (q && ![t.title, t.contact_name, t.job_number, t.job_name].some(
      v => (v || '').toLowerCase().includes(q))) return false;
    return true;
  }).sort((a, b) => {
    if (a.is_done !== b.is_done) return a.is_done ? 1 : -1;
    return b.id - a.id;
  });
}

function _tskRenderPage () {
  const rows = _tskFiltered();
  const openCount = _tskAll.filter(t => !t.is_done).length;
  const mod = document.getElementById('module-content');

  const panelHtml = !_tskAll.length
    ? `<div class="state-empty">
        <svg class="state-empty-icon" aria-hidden="true"><use href="#ic-file-check"/></svg>
        <div class="state-empty-title">No tasks yet</div>
        <div class="state-empty-sub">Add a billable task for a client — with or without a Job attached.</div>
        <button class="btn btn-primary" onclick="_tskAddModal()">+ New Task</button>
      </div>`
    : !rows.length
    ? `<div class="state-empty">
        <svg class="state-empty-icon" aria-hidden="true"><use href="#ic-file-check"/></svg>
        <div class="state-empty-title">No tasks match your search</div>
        <div class="state-empty-sub">Try adjusting your filters or search term.</div>
        <button class="btn btn-outline btn-sm" onclick="_tskFilter='All';_tskSearch='';_tskRenderPage()">Clear filters</button>
      </div>`
    : `<div class="tbl-overflow-x"><table class="inv-list-table"><thead><tr>
        <th>Task</th><th>Client</th><th>Job</th><th>Due</th>
        <th class="th-r">Qty × Price</th><th>Status</th><th></th>
      </tr></thead><tbody>${rows.map(_tskRow).join('')}</tbody></table></div>`;

  mod.innerHTML = `
    <div class="inv-toolbar">
      <input class="inv-search" id="tsk-q" placeholder="Search task, client, job…" value="${esc(_tskSearch)}">
      <div class="inv-filter-group">
        ${['All', 'Open', 'Completed'].map(s =>
          `<button class="filter-btn${_tskFilter === s ? ' active' : ''}" onclick="_tskSetFilter('${s}')">
            ${s}${s === 'Open' && openCount ? ` <span class="filter-count">(${openCount})</span>` : ''}</button>`
        ).join('')}
      </div>
      <button class="btn btn-primary" onclick="_tskAddModal()">+ New Task</button>
    </div>
    <div class="inv-list-panel">${panelHtml}</div>
    <div class="mt-8"><span class="count-pill">${rows.length} of ${_tskAll.length} task${_tskAll.length !== 1 ? 's' : ''}</span></div>`;

  const q = document.getElementById('tsk-q');
  if (q) q.addEventListener('input', e => { _tskSearch = e.target.value; _tskRenderPage(); });
}

window._tskSetFilter = function (s) { _tskFilter = s; _tskRenderPage(); };

function _tskRow (t) {
  const today = isoToday();
  const due = t.due_date && !t.is_done
    ? `<span class="${t.due_date < today ? 'wt-overdue' : 'wt-due'}">${fmtDate(t.due_date)}</span>`
    : '<span style="color:var(--ink3)">—</span>';
  const jobLbl = t.job_number ? `${esc(t.job_number)} — ${esc(t.job_name || '')}` : '<span style="color:var(--ink3)">—</span>';
  // Hourly tasks carry no price of their own — charged via a job's visit hours.
  const total  = t.billing === 'hourly' ? 'Hourly'
    : (t.qty * t.unit_price).toLocaleString('en-AU', { style: 'currency', currency: 'AUD' });
  const status = t.is_done
    ? '<span class="badge badge-green">Done</span>'
    : '<span class="badge badge-muted">Open</span>';
  return `<tr class="${t.is_done ? 'is-void' : ''}">
    <td>${esc(t.title)}</td>
    <td>${esc(t.contact_name || '—')}</td>
    <td>${jobLbl}</td>
    <td>${due}</td>
    <td class="th-r">${t.qty} × ${total}</td>
    <td>${status}</td>
    <td class="th-r">
      <button class="btn btn-outline btn-sm-action" onclick="_tskToggleDone(${t.id},${t.is_done ? 0 : 1})">${t.is_done ? 'Reopen' : 'Done'}</button>
      <button class="btn btn-outline btn-sm-action" onclick="_tskEditModal(${t.id})">Edit</button>
      <button onclick="_tskDelete(${t.id})" class="btn-icon-del-r" title="Delete">✕</button>
    </td>
  </tr>`;
}

// ── Done / Delete ─────────────────────────────────────────────────────────────

window._tskToggleDone = async function (tid, makeDone) {
  try {
    const r = await fetch(`/api/work-tasks/${tid}/complete`, {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ is_done: !!makeDone }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed to update task');
    const t = _tskAll.find(x => x.id === tid);
    if (t) t.is_done = !!makeDone;
    _tskRenderPage();
  } catch (e) { toast(e.message, 'err'); }
};

window._tskDelete = async function (tid) {
  if (!await confirmDlg('Delete this task?')) return;
  try {
    const r = await fetch(`/api/work-tasks/${tid}`, { method: 'DELETE', credentials: 'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed to delete task');
    _tskAll = _tskAll.filter(t => t.id !== tid);
    toast('Task deleted');
    _tskRenderPage();
  } catch (e) { toast(e.message, 'err'); }
};

// ── Add ──────────────────────────────────────────────────────────────────────

function _tskJobOptsFor (contactId, selectedJobId) {
  const cid = contactId ? parseInt(contactId) : null;
  const jobs = _tskJobs.filter(j => !cid || !j.contact_id || j.contact_id === cid);
  return `<option value="">No job</option>` + jobs.map(j =>
    `<option value="${j.id}"${selectedJobId === j.id ? ' selected' : ''}>${esc(j.job_number + ' — ' + j.name)}</option>`
  ).join('');
}

window._tskAddModal = function () {
  const today = isoToday();
  const conOpts = `<option value="">— Select client —</option>` +
    _tskContacts.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('');
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:min(520px,96vw)">
    <div class="modal-title">New Task</div>
    <div class="modal-field">
      <div class="lbl-line">
        <label class="modal-lbl">Client *</label>
        <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();_tskNewContact()">+ New</a>
      </div>
      <select class="modal-inp" id="tka-contact" onchange="_tskAddContactChanged()">${conOpts}</select>
    </div>
    <div class="modal-field"><label class="modal-lbl">Title *</label>
      <input class="modal-inp" id="tka-title" placeholder="Task title"></div>
    <div class="modal-field"><label class="modal-lbl">Description</label>
      <input class="modal-inp" id="tka-desc" placeholder="Notes (optional)"></div>
    <div class="modal-field" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="modal-lbl">Qty</label>
        <input class="modal-inp" id="tka-qty" type="number" step="0.01" value="1"></div>
      <div><label class="modal-lbl">Unit Price ($)</label>
        <input class="modal-inp" id="tka-price" type="number" step="0.01" value="0"></div>
    </div>
    <div class="modal-field" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="modal-lbl">Date Added</label>
        <input class="modal-inp" id="tka-added" type="date" value="${today}"></div>
      <div><label class="modal-lbl">Due Date</label>
        <input class="modal-inp" id="tka-due" type="date"></div>
    </div>
    <div class="modal-field"><label class="modal-lbl">Job</label>
      <select class="modal-inp" id="tka-job">${_tskJobOptsFor(null)}</select></div>
    <div class="modal-field" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
      <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
        <input type="checkbox" id="tka-recurring"
          onchange="document.getElementById('tka-freq-wrap').style.display=this.checked?'flex':'none'">
        Recurring task
      </label>
      <div id="tka-freq-wrap" style="display:none;align-items:center;gap:6px">
        <label class="modal-lbl" style="margin:0">Frequency</label>
        <select class="modal-inp" id="tka-freq" style="margin:0">
          <option value="">— none —</option>
          ${_WT_FREQUENCIES.map(f => `<option>${f}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary btn-sm" id="tka-save-btn" onclick="_tskAdd()">Add Task</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  setTimeout(() => document.getElementById('tka-contact')?.focus(), 50);
};

window._tskAddContactChanged = function () {
  const cid = document.getElementById('tka-contact')?.value;
  const jobSel = document.getElementById('tka-job');
  if (jobSel) jobSel.innerHTML = _tskJobOptsFor(cid);
};

async function _tskNewContact () {
  const c = await quickNewContact('Customer');
  if (!c) return;
  _tskContacts.push(c);
  const sel = document.getElementById('tka-contact');
  if (sel) { sel.appendChild(new Option(c.name, c.id, true, true)); _tskAddContactChanged(); }
}

window._tskAdd = async function () {
  const contactId = parseInt(document.getElementById('tka-contact')?.value) || null;
  const title = (document.getElementById('tka-title')?.value || '').trim();
  if (!contactId) { toast('Client is required', 'err'); return; }
  if (!title) { toast('Title is required', 'err'); return; }
  const btn = document.getElementById('tka-save-btn');
  btn.disabled = true; btn.textContent = 'Saving…';
  try {
    const r = await fetch('/api/work-tasks', {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contact_id:      contactId,
        title,
        description:     (document.getElementById('tka-desc')?.value || '').trim(),
        qty:              parseFloat(document.getElementById('tka-qty')?.value   || '1') || 1,
        unit_price:       parseFloat(document.getElementById('tka-price')?.value || '0') || 0,
        job_id:           parseInt(document.getElementById('tka-job')?.value) || null,
        created_at:       document.getElementById('tka-added')?.value || null,
        due_date:         document.getElementById('tka-due')?.value   || null,
        is_recurring:     document.getElementById('tka-recurring')?.checked ? 1 : 0,
        recur_frequency:  document.getElementById('tka-freq')?.value  || null,
      }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    document.querySelector('.modal-bd')?.remove();
    toast('Task added');
    await pageTasks();
  } catch (e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = 'Add Task';
  }
};

// ── Edit ─────────────────────────────────────────────────────────────────────
// No Client field — save_work_task() never updates contact_id on an existing
// task (same as the Contacts-page and Job-page edit flows), so re-assigning
// the client isn't offered here either.

window._tskEditModal = function (tid) {
  const t = _tskAll.find(x => x.id === tid);
  if (!t) return;
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:min(520px,96vw)">
    <div class="modal-title">Edit Task</div>
    <div class="modal-field"><label class="modal-lbl">Client</label>
      <input class="modal-inp" value="${esc(t.contact_name || '')}" disabled></div>
    <div class="modal-field"><label class="modal-lbl">Title *</label>
      <input class="modal-inp" id="tke-title" value="${esc(t.title)}"></div>
    <div class="modal-field"><label class="modal-lbl">Description</label>
      <input class="modal-inp" id="tke-desc" value="${esc(t.description || '')}"></div>
    <div class="modal-field" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="modal-lbl">Qty</label>
        <input class="modal-inp" id="tke-qty" type="number" step="0.01" value="${t.qty}"></div>
      <div><label class="modal-lbl">Unit Price ($)</label>
        <input class="modal-inp" id="tke-price" type="number" step="0.01" value="${t.unit_price}"></div>
    </div>
    <div class="modal-field"><label class="modal-lbl">Job</label>
      <select class="modal-inp" id="tke-job">${_tskJobOptsFor(t.contact_id, t.job_id)}</select></div>
    <div class="modal-field" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label class="modal-lbl">Date Added</label>
        <input class="modal-inp" id="tke-added" type="date" value="${t.created_at ? t.created_at.split(' ')[0] : ''}"></div>
      <div><label class="modal-lbl">Due Date</label>
        <input class="modal-inp" id="tke-due" type="date" value="${t.due_date || ''}"></div>
    </div>
    <div class="modal-field" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
      <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
        <input type="checkbox" id="tke-recurring"${t.is_recurring ? ' checked' : ''}
          onchange="document.getElementById('tke-freq-wrap').style.display=this.checked?'flex':'none'">
        Recurring task
      </label>
      <div id="tke-freq-wrap" style="display:${t.is_recurring ? 'flex' : 'none'};align-items:center;gap:6px">
        <label class="modal-lbl" style="margin:0">Frequency</label>
        <select class="modal-inp" id="tke-freq" style="margin:0">
          <option value="">— none —</option>
          ${_WT_FREQUENCIES.map(f => `<option${t.recur_frequency === f ? ' selected' : ''}>${f}</option>`).join('')}
        </select>
      </div>
    </div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary btn-sm" id="tke-save-btn" onclick="_tskSaveEdit(${tid})">Save</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  setTimeout(() => document.getElementById('tke-title')?.focus(), 50);
};

window._tskSaveEdit = async function (tid) {
  const title = (document.getElementById('tke-title')?.value || '').trim();
  if (!title) { toast('Title is required', 'err'); return; }
  const btn = document.getElementById('tke-save-btn');
  btn.disabled = true; btn.textContent = 'Saving…';
  try {
    const r = await fetch(`/api/work-tasks/${tid}`, {
      method: 'PUT', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        description:     (document.getElementById('tke-desc')?.value || '').trim(),
        qty:              parseFloat(document.getElementById('tke-qty')?.value   || '1') || 1,
        unit_price:       parseFloat(document.getElementById('tke-price')?.value || '0') || 0,
        job_id:           parseInt(document.getElementById('tke-job')?.value) || null,
        created_at:       document.getElementById('tke-added')?.value || null,
        due_date:         document.getElementById('tke-due')?.value   || null,
        is_recurring:     document.getElementById('tke-recurring')?.checked ? 1 : 0,
        recur_frequency:  document.getElementById('tke-freq')?.value  || null,
      }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    document.querySelector('.modal-bd')?.remove();
    toast('Task updated');
    await pageTasks();
  } catch (e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = 'Save';
  }
};
