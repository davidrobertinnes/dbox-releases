// Dogbox Accounting — Purchase Orders web UI
// Copyright © 2026 David Robert Innes trading as Dogbox Software

'use strict';

// ─── module state ────────────────────────────────────────────────────────────
let _poFilter = 'All';
let _poSearch = '';
let _poList   = [];
let _poDetId  = null;

// ─── entry point ─────────────────────────────────────────────────────────────
async function pagePurchaseOrders() {
  document.getElementById('module-content').innerHTML = `
    <div class="po-page">
      <div class="inv-toolbar">
        <input class="inv-search" id="po-q" placeholder="Search PO #, supplier…" value="${_esc(_poSearch)}">
        <div class="inv-filter-group" id="po-filter-bar"></div>
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          <button class="btn btn-primary"  onclick="_poNew()">+ New PO</button>
          <button class="btn btn-outline"  onclick="_poReceiveSelected()">Receive</button>
          <button class="btn btn-outline"  onclick="_poReceiveAllSelected()">Receive All</button>
          <button class="btn btn-outline"  onclick="_poConvertSelected()">→ Bill</button>
          <button class="btn btn-outline"  onclick="_poPdfSelected()">PDF</button>
          <button class="btn btn-danger"   onclick="_poCancelSelected()">Cancel</button>
        </div>
      </div>
      <div class="inv-list-panel" id="po-list-wrap">
        <div class="state-loading">Loading…</div>
      </div>
      <div class="mt-8"><span class="count-pill" id="po-count"></span></div>
    </div>`;

  _poRenderFilters();

  const q = document.getElementById('po-q');
  if (q) q.addEventListener('input', e => { _poSearch = e.target.value; _poRenderList(true); });

  _poLoad();
}

// ─── filter pills ─────────────────────────────────────────────────────────────
function _poRenderFilters() {
  const bar = document.getElementById('po-filter-bar');
  if (!bar) return;
  const statuses = ['All','Draft','Sent','Partially Received','Received','Billed','Cancelled'];
  bar.innerHTML = statuses.map(s =>
    `<button class="filter-btn${_poFilter===s?' active':''}" onclick="_poSetFilter('${s}')">${s}</button>`
  ).join('');
}

function _poSetFilter(s) {
  _poFilter = s;
  _poRenderFilters();
  _poRenderList();
}

// ─── list ─────────────────────────────────────────────────────────────────────
async function _poLoad() {
  const wrap = document.getElementById('po-list-wrap');
  if (!wrap) return;
  wrap.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    _poList = await apiFetch('/api/purchase-orders');
    _poRenderList();
  } catch(e) {
    wrap.innerHTML = `<div class="state-error">Failed to load: ${_esc(e.message)}</div>`;
  }
}

function _poRenderList(restoreFocus) {
  const wrap  = document.getElementById('po-list-wrap');
  const count = document.getElementById('po-count');
  if (!wrap) return;
  const q = _poSearch.toLowerCase();
  const rows = _poList.filter(po => {
    if (_poFilter !== 'All' && po.status !== _poFilter) return false;
    if (q && ![(po.po_number||''), (po.contact_name_live||po.contact_name||'')]
               .some(v => v.toLowerCase().includes(q))) return false;
    return true;
  });
  if (count) count.textContent = `${rows.length} of ${_poList.length} purchase order${_poList.length!==1?'s':''}`;
  if (!rows.length) {
    wrap.innerHTML = '<div class="state-empty">No purchase orders found.</div>';
    if (restoreFocus) { const qi=document.getElementById('po-q'); if(qi){qi.focus();qi.setSelectionRange(qi.value.length,qi.value.length);} }
    return;
  }
  wrap.innerHTML = `
    <div class="tbl-overflow-x">
      <table class="inv-list-table">
        <thead><tr>
          <th>PO #</th>
          <th>Supplier</th>
          <th>Date</th>
          <th>Expected</th>
          <th class="th-r">Total</th>
          <th>Status</th>
          <th class="th-c">Bill?</th>
        </tr></thead>
        <tbody>
          ${rows.map(po => `
            <tr class="inv-row ${_poRowClass(po.status)}" data-id="${po.id}" onclick="_poOpenDet(${po.id})">
              <td class="td-mono">${po.po_number}</td>
              <td>${_esc(po.contact_name_live||po.contact_name||'')}</td>
              <td class="td-mono">${_fmtDate(po.po_date)}</td>
              <td class="td-mono">${po.expected_date ? _fmtDate(po.expected_date) : '<span class="col-ink3">—</span>'}</td>
              <td class="inv-amt">$${_fmtAmt(po.total)}</td>
              <td><span class="po-badge po-badge-${_poStatusClass(po.status)}">${po.status}</span></td>
              <td class="th-c">${po.bill_id ? '<span class="col-green">✓</span>' : '<span class="col-ink3">—</span>'}</td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
  if (restoreFocus) { const qi = document.getElementById('po-q'); if(qi){qi.focus();qi.setSelectionRange(qi.value.length,qi.value.length);} }
}

function _poStatusClass(s) {
  return {
    'Draft':'draft', 'Sent':'sent',
    'Partially Received':'partial', 'Received':'received',
    'Billed':'billed', 'Cancelled':'cancelled'
  }[s] || 'draft';
}

function _poRowClass(s) {
  if (s === 'Partially Received') return 'po-row-partial';
  if (s === 'Received')           return 'po-row-received';
  if (s === 'Cancelled')          return 'is-void';
  return '';
}

// ─── detail slide-over ────────────────────────────────────────────────────────
function _poRenderDet(d) {
  const po = d.po;
  const lines = d.lines || [];

  const statusCls = _poStatusClass(po.status);
  const canReceive = ['Sent','Partially Received'].includes(po.status);
  const canConvert = ['Received','Partially Received','Sent'].includes(po.status);
  const canCancel  = !['Cancelled','Billed'].includes(po.status);

  document.getElementById('det-title').textContent = po.po_number;
  document.getElementById('det-body').innerHTML = `
    <div class="po-det-meta">
      <div class="po-det-row"><span class="po-det-lbl">Supplier</span><span class="po-det-val">${_esc(po.contact_name_live||po.contact_name||'')}</span></div>
      <div class="po-det-row"><span class="po-det-lbl">Status</span><span class="po-det-val"><span class="po-badge po-badge-${statusCls}">${po.status}</span></span></div>
      <div class="po-det-row"><span class="po-det-lbl">PO Date</span><span class="po-det-val">${_fmtDate(po.po_date)}</span></div>
      <div class="po-det-row"><span class="po-det-lbl">Expected</span><span class="po-det-val">${po.expected_date ? _fmtDate(po.expected_date) : '—'}</span></div>
      ${po.bill_id ? `<div class="po-det-row"><span class="po-det-lbl">Bill</span><span class="po-det-val col-green">Bill #${po.bill_id}</span></div>` : ''}
      ${po.delivery_address ? `<div class="po-det-row"><span class="po-det-lbl">Deliver to</span><span class="po-det-val">${_esc(po.delivery_address)}</span></div>` : ''}
      ${po.notes ? `<div class="po-det-row"><span class="po-det-lbl">Notes</span><span class="po-det-val">${_esc(po.notes)}</span></div>` : ''}
    </div>

    <table class="dbox-table po-lines-tbl">
      <thead><tr>
        <th>Description</th>
        <th class="th-r">Qty</th>
        <th class="th-r">Unit Price</th>
        <th class="th-r">GST</th>
        <th class="th-r">Total</th>
        <th class="th-r">Received</th>
      </tr></thead>
      <tbody>
        ${lines.map(l => {
          const outstanding = (parseFloat(l.quantity)||0) - (parseFloat(l.qty_received)||0);
          const allRec = outstanding <= 0;
          return `<tr>
            <td>${_esc(l.description)}</td>
            <td class="td-r-mono">${_fmtQty(l.quantity)}</td>
            <td class="td-r-mono">$${_fmtAmt(l.unit_price)}</td>
            <td class="td-r-mono">$${_fmtAmt(l.gst_amount||0)}</td>
            <td class="td-r-mono-bold">$${_fmtAmt(l.line_total)}</td>
            <td class="td-r-mono ${allRec?'col-green':'col-amber'}">${_fmtQty(l.qty_received||0)} / ${_fmtQty(l.quantity)}</td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>

    <div class="po-det-totals">
      <div class="po-tot-row"><span>Subtotal</span><span>$${_fmtAmt(po.subtotal)}</span></div>
      <div class="po-tot-row"><span>GST (10%)</span><span>$${_fmtAmt(po.gst_total)}</span></div>
      <div class="po-tot-row po-tot-total"><span>Total</span><span>$${_fmtAmt(po.total)}</span></div>
    </div>

    <div class="edt-section">
      <div class="edt-lbl po-att-mb">📎 Attachments</div>
      <div id="po-det-att-pane"></div>
    </div>`;

  setTimeout(() => _attLoad('po-det-att-pane', 'purchase_order', po.id), 0);

  const foot = document.getElementById('det-foot');
  foot.innerHTML = '';
  const mk = (label, cls, fn) => {
    const btn = document.createElement('button');
    btn.className = `btn ${cls}`;
    btn.textContent = label;
    btn.onclick = fn;
    foot.appendChild(btn);
  };
  mk('✎ Edit', 'btn-outline', () => _poNew(_poDetId));
  if (canReceive)  mk('📦 Receive',     'btn-secondary', () => _poShowReceiveModal(_poDetId));
  if (canReceive)  mk('📦 Receive All', 'btn-secondary', () => _poDoReceiveAll(_poDetId));
  if (canConvert)  mk('🧾 → Bill',      'btn-purple',    () => _poDoConvert(_poDetId));
  mk('⎙ PDF', 'btn-orange', () => _poDownloadPdf(_poDetId));
  if (canCancel)   mk('✕ Cancel',       'btn-danger',    () => _poDoCancel(_poDetId));
  mk('+ New PO', 'btn-outline', () => _poNew(null));
}

function _poCloseDet() {
  document.getElementById('det-overlay').classList.remove('open');
  document.getElementById('det-panel').classList.remove('open');
  _poDetId = null;
}

// ─── toolbar action helpers ───────────────────────────────────────────────────
function _poGetSelected() {
  const rows = document.querySelectorAll('#po-list-wrap .inv-row.selected');
  if (rows.length) return parseInt(rows[0].dataset.id);
  return _poDetId || null;
}

function _poOpenDet(id) {
  _poDetId = id;
  document.querySelectorAll('#po-list-wrap .inv-row').forEach(r =>
    r.classList.toggle('selected', parseInt(r.dataset.id) === id));
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = 'Purchase Order';
  document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading…</div>';
  document.getElementById('det-foot').innerHTML = '';
  apiFetch(`/api/purchase-orders/${id}`)
    .then(_poRenderDet)
    .catch(e => { document.getElementById('det-body').innerHTML = `<div class="state-error">${_esc(e.message)}</div>`; });
}

function _poReceiveSelected() {
  const id = _poGetSelected();
  if (!id) { alert('Select a PO first.'); return; }
  _poShowReceiveModal(id);
}
function _poReceiveAllSelected() {
  const id = _poGetSelected();
  if (!id) { alert('Select a PO first.'); return; }
  _poDoReceiveAll(id);
}
function _poConvertSelected() {
  const id = _poGetSelected();
  if (!id) { alert('Select a PO first.'); return; }
  _poDoConvert(id);
}
function _poPdfSelected() {
  const id = _poGetSelected();
  if (!id) { alert('Select a PO first.'); return; }
  _poDownloadPdf(id);
}
function _poCancelSelected() {
  const id = _poGetSelected();
  if (!id) { alert('Select a PO first.'); return; }
  _poDoCancel(id);
}

// ─── new / edit form ──────────────────────────────────────────────────────────
async function _poNew(editId) {
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = editId ? 'Edit Purchase Order' : 'New Purchase Order';
  document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading…</div>';
  document.getElementById('det-foot').innerHTML = '';

  let existing = null;
  let contacts = [], accounts = [], items = [];
  try {
    [contacts, accounts, items] = await Promise.all([
      apiFetch('/api/contacts'),
      apiFetch('/api/accounts'),
      apiFetch('/api/items/all').catch(() => []),
    ]);
    if (editId) existing = await apiFetch(`/api/purchase-orders/${editId}`);
  } catch(e) {
    document.getElementById('det-body').innerHTML = `<div class="state-error">Failed to load: ${_esc(e.message)}</div>`;
    return;
  }

  const po    = existing?.po    || {};
  const lines = existing?.lines || [null];

  const today = isoToday();
  const supOpts = contacts
    .filter(c => ['Supplier','Both'].includes(c.contact_type))
    .map(c => `<option value="${c.id}" ${po.contact_id==c.id?'selected':''}>${_esc(c.name)}</option>`)
    .join('');
  const accOpts = ['<option value=""></option>',
    ...accounts.map(a => `<option value="${a.id}">${_esc(a.code+'  '+a.name)}</option>`)
  ].join('');
  const statusOpts = ['Draft','Sent','Partially Received','Received','Billed','Cancelled']
    .map(s => `<option ${(po.status||'Draft')===s?'selected':''}>${s}</option>`).join('');

  document.getElementById('det-body').innerHTML = `
    <div class="po-edit-grid">
      <div class="po-edit-col">
        <label class="edt-lbl">Supplier *</label>
        <select id="po-supp" class="edt-field edt-field-mb"><option value="">— Select supplier —</option>${supOpts}</select>
        <label class="edt-lbl">PO Date *</label>
        <input id="po-date" type="date" class="edt-field edt-field-mb" value="${po.po_date || today}">
        <label class="edt-lbl">Expected Date</label>
        <input id="po-exp" type="date" class="edt-field edt-field-mb" value="${po.expected_date || ''}">
      </div>
      <div class="po-edit-col">
        <label class="edt-lbl">Status</label>
        <select id="po-status" class="edt-field edt-field-mb">${statusOpts}</select>
        <label class="edt-lbl">Delivery Address</label>
        <input id="po-addr" class="edt-field edt-field-mb" value="${_esc(po.delivery_address||'')}">
        <label class="edt-lbl">Notes</label>
        <input id="po-notes" class="edt-field edt-field-mb" value="${_esc(po.notes||'')}">
      </div>
    </div>

    <div class="po-lines-section">
      <div class="po-lines-hdr-row">
        <span class="po-line-flex3">Description</span>
        <span class="po-line-flex1r">Qty</span>
        <span class="po-line-flex1r">Unit Price</span>
        <span class="po-line-flex1">Tax</span>
        <span class="po-line-flex2">Account</span>
        <span class="po-line-flex1r">Total</span>
        <span style="width:28px"></span>
      </div>
      <div id="po-lines-body">
        ${lines.map((l, i) => _poLineRow(i, l, accOpts, items)).join('')}
      </div>
      <button class="btn btn-secondary btn-sm po-add-line-btn" onclick="_poAddLine()">+ Add Line</button>
    </div>

    <div class="po-edit-totals" id="po-edit-totals"><span></span></div>

    <div class="edt-section">
      <div class="edt-lbl po-att-mb">📎 Attachments</div>
      ${editId
        ? `<div id="po-att-pane"></div>`
        : `<div class="det-empty po-att-save-hint">Save the PO first, then open it to add attachments.</div>`
      }
    </div>`;

  const body = document.getElementById('det-body');
  body._accOpts = accOpts;
  body._items   = items;

  setTimeout(() => {
    document.querySelectorAll('#po-lines-body .po-line-row').forEach(row =>
      _wirePoLineTypeahead(parseInt(row.dataset.lineId))
    );
    if (editId) _attLoad('po-att-pane', 'purchase_order', editId);
  }, 0);

  const foot = document.getElementById('det-foot');
  foot.innerHTML = '';
  const cancelBtn = document.createElement('button');
  cancelBtn.className = 'btn btn-secondary';
  cancelBtn.textContent = 'Cancel';
  cancelBtn.onclick = editId ? () => _poOpenDet(editId) : _poCloseDet;
  foot.appendChild(cancelBtn);
  const saveBtn = document.createElement('button');
  saveBtn.className = 'btn btn-primary';
  saveBtn.textContent = 'Save';
  saveBtn.onclick = () => _poSave(editId || null);
  foot.appendChild(saveBtn);

  _poUpdateLineTotals();
}

let _poLineCounter = 100;

function _poLineRow(idx, l, accOpts, items) {
  const id    = _poLineCounter++;
  const desc  = l?.description  || '';
  const qty   = l?.quantity      != null ? l.quantity   : '';
  const price = l?.unit_price    != null ? l.unit_price : '';
  const tax   = l?.tax_code      || 'GST';
  const accId = l?.account_id    || '';
  const itemId= l?.item_id       || '';

  const taxOpts = ['GST','FRE','N-T'].map(t =>
    `<option${tax===t?' selected':''}>${t}</option>`).join('');

  const accOptsWithSel = accOpts.replace(
    `value="${accId}"`, `value="${accId}" selected`);

  return `
    <div class="po-line-row" data-line-id="${id}" data-item-id="${itemId}">
      <div class="po-line-desc po-line-flex3">
        <input class="edt-field po-line-desc-in" data-lid="${id}"
               value="${_esc(desc)}" placeholder="Description"
               autocomplete="off">
      </div>
      <input class="edt-field po-line-qty po-line-flex1r" data-lid="${id}"
             value="${qty}" placeholder="1" oninput="_poUpdateLineTotals()">
      <input class="edt-field po-line-price po-line-flex1r" data-lid="${id}"
             value="${price}" placeholder="0.00" oninput="_poUpdateLineTotals()">
      <select class="edt-field po-line-tax po-line-flex1" data-lid="${id}"
              onchange="_poUpdateLineTotals()">${taxOpts}</select>
      <select class="edt-field po-line-acc po-line-flex2" data-lid="${id}">${accOptsWithSel}</select>
      <span class="po-line-total td-r-mono po-line-total-span" data-lid="${id}"></span>
      <button class="po-line-del" onclick="_poDelLine(${id})" title="Remove line">✕</button>
    </div>`;
}

function _poAddLine() {
  const body = document.getElementById('det-body');
  if (!body) return;
  const linesBody = document.getElementById('po-lines-body');
  const lid = _poLineCounter;
  const div = document.createElement('div');
  div.innerHTML = _poLineRow(_poLineCounter, null, body._accOpts || '', body._items || []);
  linesBody.appendChild(div.firstElementChild);
  _wirePoLineTypeahead(lid);
  _poUpdateLineTotals();
}

function _poDelLine(lid) {
  const row = document.querySelector(`.po-line-row[data-line-id="${lid}"]`);
  if (row) row.remove();
  _poUpdateLineTotals();
}

function _wirePoLineTypeahead(lid) {
  const row = document.querySelector(`.po-line-row[data-line-id="${lid}"]`);
  if (!row) return;
  const inp = row.querySelector('.po-line-desc-in');
  if (!inp || inp.dataset.taWired) return;
  _attachTypeahead(inp, item => {
    row.dataset.itemId = item.id;
    const priceInp = row.querySelector('.po-line-price');
    if (priceInp && !priceInp.value)
      priceInp.value = item.purchase_price != null ? item.purchase_price : (item.unit_price || 0);
    const taxSel = row.querySelector('.po-line-tax');
    if (taxSel) taxSel.value = item.tax_code || 'GST';
    _poUpdateLineTotals();
  });
}

function _poUpdateLineTotals() {
  let sub = 0, gst = 0;
  document.querySelectorAll('#po-lines-body .po-line-row').forEach(row => {
    const qty   = parseFloat(row.querySelector('.po-line-qty')?.value   || 0) || 0;
    const price = parseFloat(row.querySelector('.po-line-price')?.value || 0) || 0;
    const tax   = row.querySelector('.po-line-tax')?.value || 'GST';
    const ex    = qty * price;
    const g     = tax === 'GST' ? ex * 0.1 : 0;
    const tot   = ex + g;
    sub += ex; gst += g;
    const span = row.querySelector('.po-line-total');
    if (span) span.textContent = tot ? '$' + _fmtAmt(tot) : '';
  });
  const totalEl = document.getElementById('po-edit-totals');
  if (totalEl) {
    const total = sub + gst;
    totalEl.innerHTML = `
      <span class="po-edit-tot-sub">Subtotal $${_fmtAmt(sub)}</span>
      <span class="po-edit-tot-gst">GST $${_fmtAmt(gst)}</span>
      <span class="po-edit-tot-total">Total $${_fmtAmt(total)}</span>`;
  }
}

async function _poSave(editId) {
  const suppEl = document.getElementById('po-supp');
  if (!suppEl || !suppEl.value) { alert('Select a supplier.'); return; }

  const lines = [];
  document.querySelectorAll('#po-lines-body .po-line-row').forEach(row => {
    const desc  = row.querySelector('.po-line-desc-in')?.value?.trim() || '';
    if (!desc) return;
    const qty   = parseFloat(row.querySelector('.po-line-qty')?.value   || 1) || 1;
    const price = parseFloat(row.querySelector('.po-line-price')?.value || 0) || 0;
    const tax   = row.querySelector('.po-line-tax')?.value   || 'GST';
    const accId = row.querySelector('.po-line-acc')?.value   || null;
    const itemId= parseInt(row.dataset.itemId) || null;
    lines.push({ description:desc, quantity:qty, unit_price:price,
                 tax_code:tax, account_id:accId?parseInt(accId):null, item_id:itemId });
  });
  if (!lines.length) { alert('Add at least one line.'); return; }

  const payload = {
    po: {
      id:               editId || null,
      contact_id:       parseInt(suppEl.value),
      po_date:          document.getElementById('po-date')?.value || null,
      expected_date:    document.getElementById('po-exp')?.value  || null,
      status:           document.getElementById('po-status')?.value || 'Draft',
      notes:            document.getElementById('po-notes')?.value?.trim() || null,
      delivery_address: document.getElementById('po-addr')?.value?.trim()  || null,
    },
    lines
  };

  const url    = editId ? `/api/purchase-orders/${editId}` : '/api/purchase-orders';
  const method = editId ? 'PUT' : 'POST';
  try {
    const r = await fetch(url, {
      method, credentials:'include',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || 'Save failed');
    await _poLoad();
    if (editId) _poOpenDet(editId);
    else if (d.po_id) _poOpenDet(d.po_id);
    else _poCloseDet();
  } catch(e) { alert('Save failed: ' + e.message); }
}

// ─── receive modal ────────────────────────────────────────────────────────────
async function _poShowReceiveModal(id) {
  let d;
  try {
    d = await apiFetch(`/api/purchase-orders/${id}`);
  } catch(e) { alert('Error: ' + e.message); return; }

  const po    = d.po;
  const lines = d.lines || [];

  if (['Draft','Billed','Cancelled','Received'].includes(po.status)) {
    alert(`This PO is ${po.status} — cannot receive goods.`); return;
  }

  const today = isoToday();
  const overlay = document.createElement('div');
  overlay.className = 'modal-bd'; overlay.style.display = 'flex';
  overlay.id = 'po-rcv-overlay';
  overlay.innerHTML = `
    <div class="modal-box po-rcv-box">
      <div class="modal-hdr">
        <span>Receive Stock / Services — ${po.po_number}</span>
        <button class="det-close" onclick="document.getElementById('po-rcv-overlay').remove()">✕</button>
      </div>
      <div class="modal-body">
        <div class="po-rcv-date-row">
          <label class="edt-lbl">Received Date</label>
          <input id="po-rcv-date" type="date" class="edt-field" value="${today}">
        </div>
        <table class="dbox-table po-rcv-tbl">
          <thead><tr>
            <th>Description</th>
            <th class="th-r">Ordered</th>
            <th class="th-r">Prev. Received</th>
            <th class="th-r">Outstanding</th>
            <th class="th-r">Receive Now</th>
          </tr></thead>
          <tbody>
            ${lines.map(l => {
              const outstanding = Math.max(0, (parseFloat(l.quantity)||0) - (parseFloat(l.qty_received)||0));
              return `<tr>
                <td>${_esc(l.description)}</td>
                <td class="td-r-mono">${_fmtQty(l.quantity)}</td>
                <td class="td-r-mono">${_fmtQty(l.qty_received||0)}</td>
                <td class="td-r-mono ${outstanding>0?'col-amber':'col-green'}">${_fmtQty(outstanding)}</td>
                <td><input class="edt-field po-rcv-qty po-rcv-inp" data-lid="${l.id}"
                           value="${outstanding.toFixed(2)}"></td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>
      <div class="modal-foot">
        <button class="btn btn-secondary" onclick="document.getElementById('po-rcv-overlay').remove()">Cancel</button>
        <button class="btn btn-primary" id="po-rcv-post-btn" onclick="_poPostReceipt(${id})">Post Receipt</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
}

async function _poPostReceipt(id) {
  const btn = document.getElementById('po-rcv-post-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Posting…'; }
  const received = {};
  document.querySelectorAll('.po-rcv-qty').forEach(inp => {
    const qty = parseFloat(inp.value) || 0;
    if (qty > 0) received[parseInt(inp.dataset.lid)] = qty;
  });
  if (!Object.keys(received).length) {
    if (btn) { btn.disabled = false; btn.textContent = 'Post Receipt'; }
    alert('Enter at least one quantity.'); return;
  }
  const receivedDate = document.getElementById('po-rcv-date')?.value || null;
  try {
    const r = await fetch(`/api/purchase-orders/${id}/receive`, {
      method:'POST', credentials:'include',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ received, received_date: receivedDate })
    });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || 'Failed');
    if (btn) { btn.disabled = false; btn.textContent = 'Post Receipt'; }
    document.getElementById('po-rcv-overlay')?.remove();
    toast(`Receipt posted. PO status: ${d.status}`);
    await _poLoad();
    if (_poDetId === id) _poOpenDet(id);
  } catch(e) {
    if (btn) { btn.disabled = false; btn.textContent = 'Post Receipt'; }
    alert('Error: ' + e.message);
  }
}

async function _poDoReceiveAll(id) {
  let d;
  try {
    d = await apiFetch(`/api/purchase-orders/${id}`);
  } catch(e) { alert('Error: ' + e.message); return; }
  const po = d.po;
  if (['Billed','Cancelled','Received'].includes(po.status)) {
    alert(`PO is already ${po.status} — nothing to receive.`); return;
  }
  const outstanding = (d.lines||[]).filter(l =>
    (parseFloat(l.quantity)||0) - (parseFloat(l.qty_received)||0) > 0);
  if (!outstanding.length) { alert('All lines have already been received.'); return; }
  if (!confirm(`Mark all ${outstanding.length} outstanding line(s) as received?`)) return;
  try {
    const r = await fetch(`/api/purchase-orders/${id}/receive-all`, {
      method:'POST', credentials:'include',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({})
    });
    const rd = await r.json();
    if (!r.ok) throw new Error(rd.error || 'Failed');
    toast(`PO marked as ${rd.status}`);
    await _poLoad();
    if (_poDetId === id) _poOpenDet(id);
  } catch(e) { alert('Error: ' + e.message); }
}

// ─── convert to bill ──────────────────────────────────────────────────────────
async function _poDoConvert(id) {
  let d;
  try {
    d = await apiFetch(`/api/purchase-orders/${id}`);
  } catch(e) { alert('Error: ' + e.message); return; }
  const po = d.po;
  if (!['Received','Partially Received','Sent'].includes(po.status)) {
    alert('PO must be at least Sent status to convert to a Bill.'); return;
  }
  if (!confirm(`Convert ${po.po_number} to a Bill?\n\nThis will create an Approved bill.`)) return;
  try {
    const r = await fetch(`/api/purchase-orders/${id}/convert-bill`, {
      method:'POST', credentials:'include',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({})
    });
    const rd = await r.json();
    if (!r.ok) throw new Error(rd.error || 'Failed');
    toast(`Bill created (ID ${rd.bill_id}).`);
    await _poLoad();
    if (_poDetId === id) _poOpenDet(id);
  } catch(e) { alert('Error: ' + e.message); }
}

// ─── cancel ───────────────────────────────────────────────────────────────────
async function _poDoCancel(id) {
  const d = _poList.find(p => p.id === id);
  if (!confirm(`Cancel PO${d ? ' ' + d.po_number : ''}?`)) return;
  try {
    const r = await fetch(`/api/purchase-orders/${id}/cancel`, {
      method:'POST', credentials:'include',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({})
    });
    const rd = await r.json();
    if (!r.ok) throw new Error(rd.error || 'Failed');
    await _poLoad();
    if (_poDetId === id) _poOpenDet(id);
  } catch(e) { alert('Error: ' + e.message); }
}

// ─── PDF download ─────────────────────────────────────────────────────────────
function _poDownloadPdf(id) {
  window.open(`/api/purchase-orders/${id}/pdf`, '_blank');
}

// ─── helpers ──────────────────────────────────────────────────────────────────
function _fmtDate(iso) {
  if (!iso) return '';
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
}
function _fmtAmt(v) {
  return parseFloat(v||0).toLocaleString('en-AU', {minimumFractionDigits:2, maximumFractionDigits:2});
}
function _fmtQty(v) {
  const n = parseFloat(v||0);
  return n % 1 === 0 ? n.toFixed(0) : n.toFixed(2);
}
function _esc(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
