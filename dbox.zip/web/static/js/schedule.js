// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ═══════════════════════════════════════════════════════════════════════════
// schedule.js — Job Calendar / Scheduler  (prefix: _cal)
// Uses shared helpers from dashboard.html: apiFetch, esc, fmtDate, isoToday,
// quickNewContact, detClose
// Calls jobOpen() / jobNew() from jobs.js
// ═══════════════════════════════════════════════════════════════════════════

'use strict';

const EVENT_TYPES = ['Personal', 'Appointment', 'Meeting', 'Reminder', 'Visit', 'Other'];

let _calJobs     = [];
let _calEvents   = [];
let _calContacts = [];
let _calAnchor   = '';     // ISO date YYYY-MM-DD — anchor for current view
let _calView     = 'week'; // 'day' | 'week' | 'month' | 'list' (remembered)
// Job start–end bars in the calendar grids: on unless unticked (jobs with visits are
// shown by their visits, so the bars are only for jobs with none yet)
let _calShowJobRanges = localStorage.getItem('dbox.cal.jobRanges') !== '0';
const CAL_HOUR_PX = 48;   // height of one hour in the day/week time grid
// Day view: a column per worker (plus Unassigned) when there are employees
let _calByWorker = localStorage.getItem('dbox.cal.byWorker') !== '0';
let _calWorkers  = [];
let _evtSelectedId = null;
let _calDragItem   = null; // {kind, id} of the chip currently being dragged
let _calGcalConnected  = false;
let _calGcalLastSynced = null;

// ── Entry point ──────────────────────────────────────────────────────────────

window.pageSchedule = async function () {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    [_calJobs, _calEvents, _calContacts, _calWorkers] = await Promise.all([
      apiFetch('/api/jobs'),
      apiFetch('/api/schedule/events'),
      apiFetch('/api/contacts'),
      loadWorkers(true),
    ]);
    _calJobs     = _calJobs || [];
    _calEvents   = _calEvents || [];
    _calContacts = _calContacts || [];
    _calAnchor = _calIso(new Date());
    _calView   = localStorage.getItem('dbox.cal.view') || 'week';
    _calRenderPage(mod);
  } catch (e) {
    mod.innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`;
    return;
  }
  _calRefreshSyncStatus(); // non-blocking — page is already usable with local data
};

// ── Page scaffold ─────────────────────────────────────────────────────────────

function _calRenderPage (container) {
  const vBtn = v => {
    const label = v.charAt(0).toUpperCase() + v.slice(1);
    return `<button class="btn btn-sm ${_calView === v ? 'btn-primary' : 'btn-outline'}"
      onclick="_calSetView('${v}')">${label}</button>`;
  };
  container.innerHTML = `
    <div class="inv-toolbar">
      <div class="cal-nav-group">
        <button class="btn btn-outline btn-sm" onclick="_calToday()">Today</button>
        <button class="btn btn-outline btn-sm" onclick="_calPrev()">&#8249;</button>
        <button class="btn btn-outline btn-sm" onclick="_calNext()">&#8250;</button>
        <span class="cal-month-label" id="cal-month-label"></span>
      </div>
      <div class="cal-view-btns">
        ${vBtn('day')}${vBtn('week')}${vBtn('month')}${vBtn('list')}
      </div>
      ${_calView !== 'list' ? `<label class="cal-toggle" title="Show each job as a bar from its start to end date">
        <input type="checkbox" ${_calShowJobRanges ? 'checked' : ''} onchange="_calToggleJobRanges(this.checked)"> Job date ranges</label>` : ''}
      ${_calView === 'day' && (_calWorkers || []).length ? `<label class="cal-toggle" title="A column for each worker">
        <input type="checkbox" ${_calByWorker ? 'checked' : ''} onchange="_calToggleByWorker(this.checked)"> By worker</label>` : ''}
      <div class="cal-sync-status" id="cal-sync-status"></div>
      <div class="cal-actions ml-auto">
        <button class="btn btn-outline btn-sm" onclick="_evtNew()">+ New Event</button>
        <button class="btn btn-primary btn-sm" onclick="jobNew()">+ New Job</button>
      </div>
    </div>
    <div id="cal-body"></div>`;
  _calRedraw();
  _calRenderSyncIndicator();
}

// ── Google Calendar sync indicator ───────────────────────────────────────────

function _calRenderSyncIndicator () {
  const el = document.getElementById('cal-sync-status');
  if (!el) return;
  if (!_calGcalConnected) { el.innerHTML = ''; return; }
  const when = _calGcalLastSynced || 'never';
  el.innerHTML = `<span class="cal-sync-label">Google Calendar synced ${esc(when)}</span>
    <button class="btn btn-outline btn-sm" id="cal-sync-btn" onclick="_calSyncNow(false)">Sync now</button>`;
}

async function _calRefreshSyncStatus () {
  try {
    const s = await apiFetch('/api/gcal/status');
    _calGcalConnected  = !!(s && s.connected);
    _calGcalLastSynced = s ? s.last_synced_at : null;
  } catch (e) {
    _calGcalConnected = false; // not connected, or not entitled — either way, stay quiet
  }
  _calRenderSyncIndicator();
  if (_calGcalConnected) _calSyncNow(true);
}

async function _calSyncNow (silent) {
  const btn = document.getElementById('cal-sync-btn');
  if (btn && !silent) { btn.disabled = true; btn.textContent = 'Syncing…'; }
  try {
    const r = await fetch('/api/gcal/sync', { method: 'POST', credentials: 'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Sync failed');
    [_calEvents, _calGcalLastSynced] = await Promise.all([
      apiFetch('/api/schedule/events'),
      apiFetch('/api/gcal/status').then(s => s ? s.last_synced_at : null),
    ]);
    _calEvents = _calEvents || [];
    _calRenderSyncIndicator();
    _calRedraw();
    if (!silent) toast('Synced with Google Calendar');
  } catch (e) {
    // A background auto-sync failing must not interrupt the page with a
    // toast — the Settings page's own "Sync now" is the place for that.
    if (!silent) toast(e.message, 'err');
  } finally {
    if (btn && !silent) { btn.disabled = false; btn.textContent = 'Sync now'; }
  }
}

// ── Cross-module refresh hook ──────────────────────────────────────────────────
// jobs.js edits/deletes/stage-changes a job through its own det-panel, which
// can be opened from the Schedule page's calendar chips. jobs.js has no idea
// the calendar is showing, so it can't refresh it itself — it calls this
// (guarded, since schedule.js may not be the active page) after any job
// change instead of leaving the calendar showing stale data until a manual
// page refresh.
window._calRefreshJobs = async function () {
  if (!document.getElementById('cal-body')) return; // Schedule isn't the active page
  // Refetch events too — a job's Visits tab adds/edits events.
  const [jobs, events] = await Promise.all([apiFetch('/api/jobs'), apiFetch('/api/schedule/events')]);
  _calJobs   = jobs   || [];
  _calEvents = events || [];
  _calRedraw();
};

// ── Navigation ────────────────────────────────────────────────────────────────

window._calToday   = function () { _calAnchor = _calIso(new Date()); _calRedraw(); };
window._calSetView = function (v) {
  _calView = v; localStorage.setItem('dbox.cal.view', v);
  _calRenderPage(document.getElementById('module-content'));
};
window._calToggleByWorker = function (on) {
  _calByWorker = !!on; localStorage.setItem('dbox.cal.byWorker', on ? '1' : '0'); _calRedraw();
};
window._calToggleJobRanges = function (on) {
  _calShowJobRanges = !!on; localStorage.setItem('dbox.cal.jobRanges', on ? '1' : '0'); _calRedraw();
};

window._calPrev = function () {
  const d = new Date(_calAnchor + 'T00:00:00');
  if (_calView === 'week') { d.setDate(d.getDate() - 7); }
  else if (_calView === 'day') { d.setDate(d.getDate() - 1); }
  else { d.setDate(1); d.setMonth(d.getMonth() - 1); }
  _calAnchor = _calIso(d);
  _calRedraw();
};

window._calNext = function () {
  const d = new Date(_calAnchor + 'T00:00:00');
  if (_calView === 'week') { d.setDate(d.getDate() + 7); }
  else if (_calView === 'day') { d.setDate(d.getDate() + 1); }
  else { d.setDate(1); d.setMonth(d.getMonth() + 1); }
  _calAnchor = _calIso(d);
  _calRedraw();
};

// ── Redraw ────────────────────────────────────────────────────────────────────

function _calRedraw () {
  const label = document.getElementById('cal-month-label');
  const body  = document.getElementById('cal-body');
  if (!label || !body) return;
  label.textContent = _calViewLabel();
  if      (_calView === 'week')  body.innerHTML = _calBuildTimeGrid(7);
  else if (_calView === 'day')   body.innerHTML = _calBuildTimeGrid(1);
  else if (_calView === 'month') body.innerHTML = _calBuildMonth();
  else                           body.innerHTML = _calBuildList();
}

function _calViewLabel () {
  if (_calView === 'list') return 'All Jobs & Events';
  const d = new Date(_calAnchor + 'T00:00:00');
  if (_calView === 'day') return d.toLocaleString('default', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  if (_calView === 'month') return d.toLocaleString('default', { month: 'long', year: 'numeric' });
  const mon = _calWeekMon(d);
  const sun = new Date(mon); sun.setDate(mon.getDate() + 6);
  if (mon.getMonth() === sun.getMonth())
    return `${mon.getDate()} – ${sun.getDate()} ${sun.toLocaleString('default', { month: 'long', year: 'numeric' })}`;
  return `${mon.toLocaleString('default', { day: 'numeric', month: 'short' })} – ${sun.toLocaleString('default', { day: 'numeric', month: 'short', year: 'numeric' })}`;
}

// ── Unified calendar items (jobs + events) ────────────────────────────────────

window._calOpenItem = function (kind, id) {
  if (kind === 'event') _evtOpen(id); else jobOpen(id);
};

function _calItems (includeJobs = true) {
  // A job with visits is shown by its visits, not its start–end span —
  // matches what Google Calendar gets (core/gcal.py: push_job).
  const jobsWithVisits = new Set((_calEvents || [])
    .filter(e => e.event_type === 'Visit' && e.job_id).map(e => e.job_id));
  const jobs = !includeJobs ? [] : (_calJobs || []).filter(j => j.start_date && !jobsWithVisits.has(j.id)).map(j => ({
    id: j.id, kind: 'job',
    start_date: j.start_date, end_date: j.end_date || j.start_date,
    chipCls: _calChipCls(j.status),
    label: `${j.job_number} – ${j.name}`,
    contLabel: j.name,
    subLabel: j.contact_name || '',
  }));
  const events = (_calEvents || []).filter(e => e.event_date).map(e => ({
    id: e.id, kind: 'event',
    start_date: e.event_date, end_date: e.end_date || e.event_date,
    chipCls: 'chip-p',
    label: _calEvtLabel(e),
    contLabel: e.title,
    subLabel: e.event_type === 'Visit' && e.job_number ? `Visit · ${e.job_number}` : (e.event_type || ''),
    synced: !!e.gcal_event_id,
  }));
  return jobs.concat(events);
}

// "08:00 Rough-in wiring — Kitchen rewire" for timed visits; the title otherwise
function _calEvtLabel (e) {
  const t = !e.all_day && e.start_time ? e.start_time.slice(0, 5) + ' ' : '';
  const job = e.event_type === 'Visit' && e.job_name && e.job_name !== e.title ? ` — ${e.job_name}` : '';
  return t + e.title + job;
}

function _calMin (t) { const [h, m] = String(t || '0:0').split(':').map(Number); return (h || 0) * 60 + (m || 0); }
function _calHHMM (min) { min = Math.max(0, Math.min(24 * 60 - 1, min)); return String(Math.floor(min / 60)).padStart(2, '0') + ':' + String(min % 60).padStart(2, '0'); }
function _calHourLbl (h) { return `${h % 12 || 12}${h < 12 ? 'am' : 'pm'}`; }
const _calTimed = e => !e.all_day && !!e.start_time;

// Day or week as an hourly grid. Timed events sit at their times (side by side when they
// overlap); all-day events and (optionally) job date ranges go in the strip at the top.
function _calBuildTimeGrid (nDays) {
  const todayISO = _calIso(new Date());
  const first = nDays === 7 ? _calWeekMon(new Date(_calAnchor + 'T00:00:00')) : new Date(_calAnchor + 'T00:00:00');
  const days = Array.from({ length: nDays }, (_, i) => { const d = new Date(first); d.setDate(first.getDate() + i); return _calIso(d); });
  const events = (_calEvents || []).filter(e => e.event_date && days.includes(e.event_date));
  const timed = events.filter(_calTimed);

  // 6am–7pm, widened to fit anything earlier or later
  let lo = 6, hi = 19;
  for (const e of timed) {
    lo = Math.min(lo, Math.floor(_calMin(e.start_time) / 60));
    hi = Math.max(hi, Math.ceil((_calMin(e.end_time) || _calMin(e.start_time) + 60) / 60));
  }
  const hours = Array.from({ length: hi - lo }, (_, i) => lo + i);

  const allDay = _calItems(_calShowJobRanges).filter(it => !(it.kind === 'event' && _calTimed((_calEvents || []).find(e => e.id === it.id) || {})));
  // emp: -1 = all workers (one column per day); 0 = Unassigned; else an employee id
  const byWorker = nDays === 1 && _calByWorker && (_calWorkers || []).length;
  const colDefs = byWorker
    ? [{ iso: days[0], emp: 0, label: 'Unassigned' }, ...(_calWorkers || []).map(w => ({ iso: days[0], emp: w.id, label: w.name }))]
    : days.map(iso => ({ iso, emp: -1 }));
  const empOf = e => e.employee_id || 0;
  const inCol = (c, e) => c.emp === -1 || empOf(e) === c.emp;
  const evOf = it => it.kind === 'event' ? (_calEvents || []).find(e => e.id === it.id) : null;
  const head = colDefs.map(c => {
    if (c.emp !== -1) return `<div class="calt-dh calt-dh-worker"><b>${esc(c.label)}</b></div>`;
    const d = new Date(c.iso + 'T00:00:00');
    return `<div class="calt-dh${c.iso === todayISO ? ' is-today' : ''}">
      <span>${d.toLocaleString('default', { weekday: 'short' })}</span> <b>${d.getDate()}</b></div>`;
  }).join('');
  const strip = colDefs.map(c => {
    const iso = c.iso;
    // By worker: all-day events by their worker; job date ranges under Unassigned
    const items = allDay.filter(it => it.start_date <= iso && it.end_date >= iso
      && (c.emp === -1 || (evOf(it) ? empOf(evOf(it)) === c.emp : c.emp === 0)));
    return `<div class="calt-ad-cell" ondragover="_calRowDragOver(event)" ondrop="_calAlldayDrop(event,'${iso}')">
      ${items.map(it => `<div class="cal-chip ${it.chipCls} chip-s chip-e calt-ad-chip" draggable="true"
        ondragstart="_calDragStart(event,'${it.kind}',${it.id})" ondragend="_calDragEnd(event)"
        onclick="_calOpenItem('${it.kind}',${it.id})" title="${esc(it.label)}"><span class="chip-lbl">${esc(it.label)}</span></div>`).join('')}
    </div>`;
  }).join('');

  const cols = colDefs.map(c => {
    const iso = c.iso;
    const dayEv = timed.filter(e => e.event_date === iso && inCol(c, e))
      .map(e => ({ e, s: _calMin(e.start_time), f: Math.max(_calMin(e.end_time), _calMin(e.start_time) + 30) }))
      .sort((a, b) => a.s - b.s || b.f - a.f);
    // Overlapping events share the column: cluster, then give each a lane
    let cluster = [], clusterEnd = -1;
    const flush = () => {
      const laneEnds = [];
      for (const x of cluster) {
        let l = laneEnds.findIndex(end => end <= x.s);
        if (l < 0) { l = laneEnds.length; laneEnds.push(0); }
        laneEnds[l] = x.f; x.lane = l;
      }
      cluster.forEach(x => { x.lanes = laneEnds.length; });
      cluster = []; clusterEnd = -1;
    };
    for (const x of dayEv) { if (cluster.length && x.s >= clusterEnd) flush(); cluster.push(x); clusterEnd = Math.max(clusterEnd, x.f); }
    flush();
    const blocks = dayEv.map(({ e, s, f, lane, lanes }) => {
      const top = (s - lo * 60) / 60 * CAL_HOUR_PX, h = Math.max(18, (f - s) / 60 * CAL_HOUR_PX - 2);
      const site = (e.site_address || '').split('\n')[0];
      const sub = [c.emp === -1 ? e.worker_name : '', e.event_type === 'Visit' && e.job_number ? e.job_number : '',
                   e.job_name && e.job_name !== e.title ? e.job_name : '', site].filter(Boolean).join(' · ');
      const short = h < 36;   // under ~45 minutes: time and title on one line
      return `<div class="calt-ev ${e.event_type === 'Visit' ? 'chip-p' : 'chip-a'}${short ? ' is-short' : ''}" draggable="true"
        style="top:${top}px;height:${h}px;left:calc(${lane / lanes * 100}% + 1px);width:calc(${100 / lanes}% - 3px)"
        ondragstart="_calDragStart(event,'event',${e.id})" ondragend="_calDragEnd(event)"
        onclick="event.stopPropagation();_calOpenItem('event',${e.id})"
        title="${esc(`${e.start_time.slice(0, 5)}${e.end_time ? '–' + e.end_time.slice(0, 5) : ''} ${e.title}${sub ? '\n' + sub : ''}`)}">
        <div class="calt-ev-time">${esc(e.start_time.slice(0, 5))}${e.end_time ? '–' + esc(e.end_time.slice(0, 5)) : ''}</div>
        <div class="calt-ev-title">${esc(e.title)}</div>
        ${sub ? `<div class="calt-ev-sub">${esc(sub)}</div>` : ''}
      </div>`;
    }).join('');
    return `<div class="calt-col${iso === todayISO ? ' is-today' : ''}" style="height:${hours.length * CAL_HOUR_PX}px"
      ondragover="_calRowDragOver(event)" ondrop="_calColDrop(event,'${iso}',${lo},${c.emp})" onclick="_calSlotClick(event,'${iso}',${lo},${c.emp})">
      ${hours.map((_, i) => `<div class="calt-hr" style="top:${i * CAL_HOUR_PX}px"></div>`).join('')}
      ${blocks}</div>`;
  }).join('');

  return `<div class="calt-wrap">
    <div class="calt" style="--calt-days:${colDefs.length}">
      <div class="calt-sticky">
        <div class="calt-row calt-head"><div class="calt-gut"></div>${head}</div>
        <div class="calt-row calt-ad"><div class="calt-gut calt-gut-lbl">All day</div>${strip}</div>
      </div>
      <div class="calt-row calt-body">
        <div class="calt-gut">${hours.map(h => `<div class="calt-hl" style="height:${CAL_HOUR_PX}px">${_calHourLbl(h)}</div>`).join('')}</div>
        ${cols}
      </div>
    </div>
    ${_calUnscheduledHtml()}
  </div>`;
}

// Open jobs (accepted / in progress / on hold) with no visit booked from today on
function _calUnscheduledJobs () {
  const today = _calIso(new Date());
  const booked = new Set((_calEvents || []).filter(e => e.job_id && e.event_date >= today).map(e => e.job_id));
  return (_calJobs || []).filter(j => ['Accepted', 'In Progress', 'On Hold'].includes(j.stage) && !booked.has(j.id));
}

function _calUnscheduledHtml () {
  const jobs = _calUnscheduledJobs();
  return `<aside class="calt-side">
    <div class="calt-side-hdr">Unscheduled jobs (${jobs.length})</div>
    <div class="calt-side-hint">${jobs.length ? 'Drag a job onto the calendar to book a visit.' : 'Every open job has a visit booked.'}</div>
    ${jobs.map(j => `<div class="calt-uj" draggable="true" ondragstart="_calDragStart(event,'job',${j.id})" ondragend="_calDragEnd(event)"
        onclick="_calOpenItem('job',${j.id})" title="Drag onto the calendar to book a visit — click to open">
      <div class="calt-uj-name">${esc(j.name)}</div>
      <div class="calt-uj-sub">${esc([j.job_number, j.contact_name].filter(Boolean).join(' · '))}</div>
      ${j.site_address ? `<div class="calt-uj-sub">${esc(j.site_address.split('\n')[0])}</div>` : ''}
      <div class="calt-uj-sub">${esc(j.stage || '')}</div>
    </div>`).join('')}
  </aside>`;
}

// Minutes from midnight at a y-position in a time column, snapped to 15 minutes
function _calYToMin (ev, colEl, lo, grabY = 0) {
  const y = ev.clientY - colEl.getBoundingClientRect().top - grabY;
  return lo * 60 + Math.max(0, Math.round(y / CAL_HOUR_PX * 4)) * 15;
}

// Click an empty slot: new event at that time (an hour long)
window._calSlotClick = async function (ev, iso, lo, emp = -1) {
  if (ev.target.closest('.calt-ev')) return;
  const start = _calYToMin(ev, ev.currentTarget, lo);
  const startHalf = Math.floor(start / 30) * 30;
  await _evtNewAt(iso, _calHHMM(startHalf), _calHHMM(startHalf + 60), emp > 0 ? emp : null);
};

window._evtNewAt = async function (iso, start, end, employeeId = null) {
  await _evtForm(null);
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v; };
  set('ef-date', iso); set('ef-end-date', iso); set('ef-allday', '0');
  if (typeof _evtToggleTimes === 'function') _evtToggleTimes();
  set('ef-start-time', start); set('ef-end-time', end);
  if (employeeId) set('ef-worker', String(employeeId));
};

// Drop on a time column: move an event there (keeping its length), or book a visit for a job
window._calColDrop = async function (ev, iso, lo, emp = -1) {
  // emp: dropped in a worker's column (Day view, by worker) → assign that worker
  if (!_calDragItem) return;
  ev.preventDefault();
  const drag = _calDragItem; _calDragItem = null;
  const start = _calYToMin(ev, ev.currentTarget, lo, drag.grabY || 0);
  try {
    if (drag.kind === 'event') {
      const evt = (_calEvents || []).find(e => e.id === drag.id);
      if (!evt) return;
      const len = _calTimed(evt) ? Math.max(15, (_calMin(evt.end_time) || _calMin(evt.start_time) + 60) - _calMin(evt.start_time)) : 60;
      const body = { ...evt, all_day: false, event_date: iso, end_date: iso, start_time: _calHHMM(start), end_time: _calHHMM(start + len) };
      if (emp !== -1) body.employee_id = emp || null;
      const r = await fetch(`/api/schedule/events/${evt.id}`, { method: 'PUT', credentials: 'include',
        headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Failed to move event');
      toast(`Moved to ${fmtDate(iso)} ${_calHHMM(start)}`);
    } else {
      const job = (_calJobs || []).find(x => x.id === drag.id);
      if (!job) return;
      const r = await fetch('/api/schedule/events', { method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: job.name, event_type: 'Visit', all_day: false, event_date: iso, end_date: iso,
                               start_time: _calHHMM(start), end_time: _calHHMM(start + 120),
                               job_id: job.id, contact_id: job.contact_id || null,
                               ...(emp > 0 ? { employee_id: emp } : {}) }) });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Failed to book the visit');
      toast(`Visit booked: ${job.name}, ${fmtDate(iso)} ${_calHHMM(start)}`);
    }
    _calEvents = (await apiFetch('/api/schedule/events')) || [];
    _calRedraw();
  } catch (e) { toast(e.message, 'err'); }
};

// Drop on a day in the all-day strip: same as dropping on that day in the month view
window._calAlldayDrop = async function (ev, iso) {
  if (!_calDragItem) return;
  ev.preventDefault();
  const drag = _calDragItem; _calDragItem = null;
  await _calMoveToDate(drag, iso);
};

// ── Week view (month-style row; kept for reference — the week view is now the time grid) ──

function _calBuildWeek () {
  const todayISO = _calIso(new Date());
  const mon      = _calWeekMon(new Date(_calAnchor + 'T00:00:00'));
  const week     = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(mon); d.setDate(mon.getDate() + i); return d;
  });
  const hdr = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
    .map(h => `<div class="cal-hdr-cell">${h}</div>`).join('');
  return `<div class="cal-grid cal-week-grid">
    <div class="cal-day-headers">${hdr}</div>
    ${_calBuildWeekRow(week, todayISO, -1)}
  </div>`;
}

// ── Month view ────────────────────────────────────────────────────────────────

function _calBuildMonth () {
  const todayISO = _calIso(new Date());
  const d        = new Date(_calAnchor + 'T00:00:00');
  const year     = d.getFullYear();
  const month    = d.getMonth();
  const start    = _calWeekMon(new Date(year, month, 1));
  const weeks    = Array.from({ length: 6 }, (_, w) =>
    Array.from({ length: 7 }, (__, i) => {
      const day = new Date(start); day.setDate(start.getDate() + w * 7 + i); return day;
    })
  );
  const hdr  = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
    .map(h => `<div class="cal-hdr-cell">${h}</div>`).join('');
  const rows = weeks.map(wk => _calBuildWeekRow(wk, todayISO, month)).join('');
  return `<div class="cal-grid">
    <div class="cal-day-headers">${hdr}</div>
    ${rows}
  </div>`;
}

// ── Shared week row ───────────────────────────────────────────────────────────

function _calBuildWeekRow (week, todayISO, displayMonth) {
  const weekStartISO = _calIso(week[0]);
  const weekEndISO   = _calIso(week[6]);

  const dayCells = week.map(day => {
    const iso   = _calIso(day);
    const today = iso === todayISO;
    const other = displayMonth >= 0 && day.getMonth() !== displayMonth;
    return `<div class="cal-day-num-cell${other ? ' other-mo' : ''}">
      <span class="cal-day-num${today ? ' today-num' : ''}">${day.getDate()}</span>
    </div>`;
  }).join('');

  // Jobs + events overlapping this week
  const overlapping = _calItems(_calShowJobRanges).filter(it => {
    return it.start_date <= weekEndISO && it.end_date >= weekStartISO;
  }).sort((a, b) => {
    if (a.start_date !== b.start_date) return a.start_date < b.start_date ? -1 : 1;
    return _calDur(b) - _calDur(a); // longer items first within same start
  });

  // Lane assignment — max 4 lanes before overflow
  const MAX    = 4;
  const lanes  = Array.from({ length: MAX }, () => Array(7).fill(null));
  const oflo   = Array(7).fill(0);

  for (const item of overlapping) {
    const slots = week.map(day => { const iso = _calIso(day); return iso >= item.start_date && iso <= item.end_date; });
    let placed  = false;
    for (let l = 0; l < MAX; l++) {
      if (slots.every((on, d) => !on || lanes[l][d] === null)) {
        slots.forEach((on, d) => { if (on) lanes[l][d] = item; });
        placed = true; break;
      }
    }
    if (!placed) slots.forEach((on, d) => { if (on) oflo[d]++; });
  }

  const laneRows = lanes
    .filter(lane => lane.some(it => it !== null))
    .map(lane => _calRenderLane(lane, weekStartISO, weekEndISO))
    .join('');

  const ofCells = oflo.map((n, d) =>
    `<div${n ? ' class="cal-more-cell"' : ''} style="grid-column:${d + 1}">${n ? `<span class="cal-more-pill">+${n} more</span>` : ''}</div>`
  ).join('');
  const ofRow = oflo.some(n => n > 0) ? `<div class="cal-event-row">${ofCells}</div>` : '';

  return `<div class="cal-week-row" ondragover="_calRowDragOver(event)" ondrop="_calRowDrop(event,'${weekStartISO}')">
    <div class="cal-day-nums">${dayCells}</div>
    ${laneRows}${ofRow}
  </div>`;
}

function _calRenderLane (lane, weekStartISO, weekEndISO) {
  const cells = [];
  let d = 0;
  while (d < 7) {
    const item = lane[d];
    if (!item) { cells.push(`<div style="grid-column:${d + 1}"></div>`); d++; continue; }
    let e = d + 1;
    while (e < 7 && lane[e] === item) e++;
    const span = e - d;
    const isS  = item.start_date >= weekStartISO;
    const isE  = item.end_date <= weekEndISO;
    const cls   = `cal-chip ${item.chipCls}${isS ? ' chip-s' : ''}${isE ? ' chip-e' : ''}`;
    const badge = item.synced ? '<span class="chip-gcal-badge" title="Synced with Google Calendar">☁</span>' : '';
    const lbl   = isS
      ? `<span class="chip-lbl">${badge}${esc(item.label)}</span>`
      : `<span class="chip-lbl chip-cont">↳ ${esc(item.contLabel)}</span>`;
    cells.push(`<div class="${cls}" style="grid-column:${d + 1}/span ${span}" draggable="true"
      ondragstart="_calDragStart(event,'${item.kind}',${item.id})" ondragend="_calDragEnd(event)"
      onclick="_calOpenItem('${item.kind}',${item.id})" title="Drag to reschedule — click to open&#10;${esc(item.label)}">${lbl}</div>`);
    d = e;
  }
  return `<div class="cal-event-row">${cells.join('')}</div>`;
}

// ── List view ─────────────────────────────────────────────────────────────────

function _calBuildList () {
  const sorted = _calItems().sort((a, b) => a.start_date < b.start_date ? -1 : 1);

  if (!sorted.length) {
    return `<div class="job-empty" style="margin-top:48px">
      <div class="job-empty-icon">&#128197;</div>
      <div class="job-empty-sm">No scheduled jobs or events. Set a Start Date on a job, or add an event, to see it here.</div>
    </div>`;
  }

  let lastMo = '';
  const rows = sorted.map(it => {
    const mo = it.start_date.slice(0, 7);
    let hdr  = '';
    if (mo !== lastMo) {
      lastMo = mo;
      const dt = new Date(it.start_date + 'T00:00:00');
      hdr = `<div class="cal-list-hdr">${dt.toLocaleString('default', { month: 'long', year: 'numeric' })}</div>`;
    }
    const dates = it.end_date && it.end_date !== it.start_date
      ? `${fmtDate(it.start_date)} – ${fmtDate(it.end_date)}`
      : fmtDate(it.start_date);
    const badge = it.synced ? '<span class="chip-gcal-badge" title="Synced with Google Calendar">☁</span>' : '';
    return `${hdr}<div class="cal-list-row" onclick="_calOpenItem('${it.kind}',${it.id})">
      <span class="cal-list-dot ${it.chipCls}"></span>
      <span class="cal-list-dates">${dates}</span>
      <span class="cal-list-name">${badge}${esc(it.label)}</span>
      <span class="cal-list-contact">${esc(it.subLabel || '')}</span>
    </div>`;
  }).join('');

  return `<div class="cal-list-wrap">${rows}</div>`;
}

// ── Drag & drop reschedule ────────────────────────────────────────────────────
// One dragover/drop listener per week row (not per day cell) — the target day
// is worked out from the drop's x-position across the row's 7 equal columns,
// so dropping anywhere in that day's column works, including directly on top
// of another chip.

window._calDragStart = function (ev, kind, id) {
  const blk = ev.currentTarget.classList.contains('calt-ev') ? ev.currentTarget.getBoundingClientRect() : null;
  _calDragItem = { kind, id, grabY: blk ? ev.clientY - blk.top : 0 };
  ev.dataTransfer.effectAllowed = 'move';
  ev.dataTransfer.setData('text/plain', `${kind}:${id}`); // required by Firefox for drag to start
  ev.currentTarget.classList.add('cal-dragging');
};

window._calDragEnd = function (ev) {
  ev.currentTarget.classList.remove('cal-dragging');
  _calDragItem = null;
};

window._calRowDragOver = function (ev) {
  if (!_calDragItem) return;
  ev.preventDefault();
  ev.dataTransfer.dropEffect = 'move';
};

window._calRowDrop = async function (ev, weekStartISO) {
  if (!_calDragItem) return;
  ev.preventDefault();
  const drag = _calDragItem;
  _calDragItem = null;

  const rect   = ev.currentTarget.getBoundingClientRect();
  const dayIdx = Math.max(0, Math.min(6, Math.floor((ev.clientX - rect.left) / (rect.width / 7))));
  await _calMoveToDate(drag, _calAddDays(weekStartISO, dayIdx));
};

// Move a job's dates or an event to start on targetDate (same length, same times)
async function _calMoveToDate (drag, targetDate) {
  const item = _calItems().find(it => it.kind === drag.kind && it.id === drag.id);
  if (!item || item.start_date === targetDate) return;

  const span     = _calDur(item); // whole days between start/end — 0 for a single-day item
  const newStart = targetDate;
  const newEnd   = _calAddDays(targetDate, span);

  try {
    if (drag.kind === 'job') {
      const job = (_calJobs || []).find(j => j.id === drag.id);
      if (!job) return;
      const r = await fetch('/api/jobs', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...job, start_date: newStart, end_date: newEnd }),
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Failed to reschedule job');
      job.start_date = newStart; job.end_date = newEnd;
      toast('Job rescheduled');
    } else {
      const evt = (_calEvents || []).find(e => e.id === drag.id);
      if (!evt) return;
      const r = await fetch(`/api/schedule/events/${drag.id}`, {
        method: 'PUT', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...evt, event_date: newStart, end_date: newEnd }),
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Failed to reschedule event');
      evt.event_date = newStart; evt.end_date = newEnd;
      toast('Event rescheduled');
    }
    _calRedraw();
  } catch (e) {
    toast(e.message, 'err');
  }
};

function _calAddDays (iso, days) {
  const d = new Date(iso + 'T00:00:00');
  d.setDate(d.getDate() + days);
  return _calIso(d);
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function _calIso (d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function _calWeekMon (d) {
  const day = new Date(d);
  const dow = day.getDay();
  day.setDate(day.getDate() - (dow === 0 ? 6 : dow - 1));
  return day;
}

function _calDur (it) {
  if (!it.end_date || it.end_date === it.start_date) return 0;
  return (new Date(it.end_date + 'T00:00:00') - new Date(it.start_date + 'T00:00:00')) / 86400000;
}

function _calChipCls (status) {
  return { 'Active': 'chip-a', 'On Hold': 'chip-h', 'Completed': 'chip-c', 'Cancelled': 'chip-x', 'Draft': 'chip-d' }[status] || 'chip-a';
}

// ═══════════════════════════════════════════════════════════════════════════
// NEW / EDIT EVENT FORM
// ═══════════════════════════════════════════════════════════════════════════

window._evtNew = async function () {
  await _evtForm(null);
};

window._evtOpen = async function (id) {
  const existing = (_calEvents || []).find(e => e.id === id);
  if (!existing) { toast('Event not found', 'err'); return; }
  await _evtForm(existing);
};

async function _evtForm (existing) {
  const isEdit = !!existing;
  _evtSelectedId = existing?.id || null;

  const typeOpts = EVENT_TYPES.map(t =>
    `<option${(existing?.event_type || 'Personal') === t ? ' selected' : ''}>${t}</option>`
  ).join('');
  const conOpts = (_calContacts || []).map(c =>
    `<option value="${c.id}"${existing?.contact_id == c.id ? ' selected' : ''}>${esc(c.name)}</option>`
  ).join('');
  const jobOpts = (_calJobs || []).map(j =>
    `<option value="${j.id}"${existing?.job_id == j.id ? ' selected' : ''}>${esc(j.job_number + ' – ' + j.name)}</option>`
  ).join('');
  const allDay = existing ? !!existing.all_day : true;

  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = isEdit ? 'Edit Event' : 'New Event';

  document.getElementById('det-body').innerHTML = `
    <h3 class="form-section-hdr">Event Details</h3>
    <div class="job-form-grid">
      <div class="modal-field job-grid-full">
        <label class="modal-lbl">Title *</label>
        <input class="modal-inp" id="ef-title" placeholder="e.g. Dentist appointment" value="${esc(existing?.title || '')}">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Type</label>
        <select class="modal-sel" id="ef-type" onchange="_evtToggleHours()">${typeOpts}</select>
      </div>
      <div class="modal-field">
        <label class="modal-lbl">All Day</label>
        <select class="modal-sel" id="ef-allday" onchange="_evtToggleTimes()">
          <option value="1"${allDay ? ' selected' : ''}>Yes</option>
          <option value="0"${!allDay ? ' selected' : ''}>No</option>
        </select>
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Date</label>
        <input class="modal-inp" id="ef-date" type="date" value="${existing?.event_date || isoToday()}">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">End Date</label>
        <input class="modal-inp" id="ef-end-date" type="date" value="${existing?.end_date || ''}">
      </div>
      <div class="modal-field" id="ef-start-time-field" style="${allDay ? 'display:none' : ''}">
        <label class="modal-lbl">Start Time</label>
        <input class="modal-inp" id="ef-start-time" type="time" value="${existing?.start_time || ''}">
      </div>
      <div class="modal-field" id="ef-end-time-field" style="${allDay ? 'display:none' : ''}">
        <label class="modal-lbl">End Time</label>
        <input class="modal-inp" id="ef-end-time" type="time" value="${existing?.end_time || ''}">
      </div>
      <div class="modal-field" id="ef-hours-field" style="${existing?.event_type === 'Visit' ? '' : 'display:none'}">
        <label class="modal-lbl">Hours worked</label>
        <input class="modal-inp" id="ef-hours" type="number" step="0.25" min="0" value="${existing?.hours ?? ''}">
      </div>
      <div class="modal-field job-grid-full">
        <label class="modal-lbl">Description</label>
        <textarea class="modal-inp edt-ta-resize" id="ef-desc" rows="2">${esc(existing?.description || '')}</textarea>
      </div>
      <div class="modal-field">
        <div class="lbl-line">
          <label class="modal-lbl">Contact</label>
          <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();_evtNewContact('ef-contact')">+ New</a>
        </div>
        <select class="modal-sel" id="ef-contact">
          <option value="">— None —</option>${conOpts}
        </select>
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Job</label>
        <select class="modal-sel" id="ef-job">
          <option value="">— None —</option>${jobOpts}
        </select>
      </div>
      ${(_calWorkers || []).length ? `<div class="modal-field">
        <label class="modal-lbl">Worker</label>
        <select class="modal-sel" id="ef-worker">${workerOptsHtml(_calWorkers, existing?.employee_id)}</select>
      </div>` : ''}
    </div>`;

  const canConvert = isEdit && !existing.job_id;
  document.getElementById('det-foot').innerHTML = `
    ${isEdit ? `<button class="btn btn-outline" onclick="_evtDelete(${existing.id})">Delete</button>` : ''}
    ${canConvert ? `<button class="btn btn-outline" onclick="_evtConvertToJob(${existing.id})">Convert to Job</button>` : ''}
    ${isEdit && existing.job_id ? `<button class="btn btn-outline" onclick="jobOpen(${existing.job_id})">Open Job</button>` : ''}
    <button class="btn btn-outline ml-auto" onclick="${isEdit ? `_evtOpen(${existing.id})` : 'detClose()'}">Cancel</button>
    <button class="btn btn-primary" onclick="_evtSave(${existing?.id || 'null'})">
      ${isEdit ? 'Save Changes' : 'Create Event'}
    </button>`;

  setTimeout(() => document.getElementById('ef-title')?.focus(), 80);
}

window._evtToggleHours = function () {
  const isVisit = document.getElementById('ef-type')?.value === 'Visit';
  document.getElementById('ef-hours-field').style.display = isVisit ? '' : 'none';
};

window._evtToggleTimes = function () {
  const allDay = document.getElementById('ef-allday')?.value === '1';
  document.getElementById('ef-start-time-field').style.display = allDay ? 'none' : '';
  document.getElementById('ef-end-time-field').style.display   = allDay ? 'none' : '';
};

async function _evtNewContact (selId) {
  const c = await quickNewContact('Customer');
  if (!c) return;
  _calContacts.push(c);
  const sel = document.getElementById(selId);
  if (sel) sel.appendChild(new Option(c.name, c.id, true, true));
}

window._evtSave = async function (editId) {
  const title = (document.getElementById('ef-title')?.value || '').trim();
  if (!title) { toast('Title is required', 'err'); return; }

  const allDay   = document.getElementById('ef-allday')?.value === '1';
  const startTime = document.getElementById('ef-start-time')?.value || null;
  const endTime   = document.getElementById('ef-end-time')?.value || null;
  if (!allDay && (!startTime || !endTime)) {
    toast('Start and end time are required for a timed event — or switch All Day to Yes', 'err');
    return;
  }
  const eventType = document.getElementById('ef-type')?.value || 'Personal';
  const jobId     = parseInt(document.getElementById('ef-job')?.value) || null;
  if (eventType === 'Visit' && !jobId) { toast('A visit must be linked to a job', 'err'); return; }
  const hrsRaw = document.getElementById('ef-hours')?.value ?? '';

  const payload = {
    id:          editId || null,
    title,
    event_type:  eventType,
    all_day:     allDay,
    event_date:  document.getElementById('ef-date')?.value,
    end_date:    document.getElementById('ef-end-date')?.value || null,
    start_time:  startTime,
    end_time:    endTime,
    description: document.getElementById('ef-desc')?.value.trim() || null,
    contact_id:  parseInt(document.getElementById('ef-contact')?.value) || null,
    job_id:      jobId,
    hours:       hrsRaw === '' ? null : parseFloat(hrsRaw),
    ...workerField('ef-worker'),
  };

  try {
    const r = await fetch(editId ? `/api/schedule/events/${editId}` : '/api/schedule/events', {
      method: editId ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(payload),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed to save event');
    toast(editId ? 'Event updated' : 'Event created');
    _calEvents = (await apiFetch('/api/schedule/events')) || [];
    detClose();
    _calRedraw();
  } catch (e) { toast(e.message, 'err'); }
};

window._evtDelete = async function (id) {
  if (!confirm('Delete this event?')) return;
  try {
    let r = await fetch(`/api/schedule/events/${id}`, { method: 'DELETE', credentials: 'include' });
    let j = await r.json();
    if (r.status === 409) {
      // A job visit with task progress recorded — confirm before losing it.
      if (!confirm(`${j.error}. Delete anyway?`)) return;
      r = await fetch(`/api/schedule/events/${id}?force=1`, { method: 'DELETE', credentials: 'include' });
      j = await r.json();
    }
    if (!j.ok) throw new Error(j.error || 'Failed to delete event');
    toast('Event deleted');
    _calEvents = _calEvents.filter(e => e.id !== id);
    detClose();
    _calRedraw();
  } catch (e) { toast(e.message, 'err'); }
};

window._evtConvertToJob = async function (id) {
  if (!confirm('Convert this event into a Job? The event stays on the calendar as the new job\'s first visit.')) return;
  try {
    const r = await fetch(`/api/schedule/events/${id}/convert-to-job`, { method: 'POST', credentials: 'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed to convert event');
    toast('Converted to job');
    [_calJobs, _calEvents] = await Promise.all([
      apiFetch('/api/jobs'), apiFetch('/api/schedule/events'),
    ]);
    detClose();
    _calRedraw();
    jobOpen(j.data.id);
  } catch (e) { toast(e.message, 'err'); }
};
