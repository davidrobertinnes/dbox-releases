// ═══════════════════════════════════════════════════════════════════════════
// schedule.js — Job Calendar / Scheduler  (prefix: _cal)
// Uses shared helpers from dashboard.html: apiFetch, esc, fmtDate
// Calls jobOpen() / jobNew() from jobs.js
// ═══════════════════════════════════════════════════════════════════════════

'use strict';

let _calJobs   = [];
let _calAnchor = '';     // ISO date YYYY-MM-DD — anchor for current view
let _calView   = 'week'; // 'week' | 'month' | 'list'

// ── Entry point ──────────────────────────────────────────────────────────────

window.pageSchedule = async function () {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    _calJobs   = (await apiFetch('/api/jobs')) || [];
    _calAnchor = _calIso(new Date());
    _calView   = 'week';
    _calRenderPage(mod);
  } catch (e) {
    mod.innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`;
  }
};

// ── Page scaffold ─────────────────────────────────────────────────────────────

function _calRenderPage (container) {
  const vBtn = v => {
    const label = v.charAt(0).toUpperCase() + v.slice(1);
    return `<button class="btn btn-sm ${_calView === v ? 'btn-primary' : 'btn-outline'}"
      onclick="_calSetView('${v}')">${label}</button>`;
  };
  container.innerHTML = `
    <div class="inv-toolbar">
      <div class="cal-nav-group">
        <button class="btn btn-outline btn-sm" onclick="_calToday()">Today</button>
        <button class="btn btn-outline btn-sm" onclick="_calPrev()">&#8249;</button>
        <button class="btn btn-outline btn-sm" onclick="_calNext()">&#8250;</button>
        <span class="cal-month-label" id="cal-month-label"></span>
      </div>
      <div class="cal-view-btns">
        ${vBtn('week')}${vBtn('month')}${vBtn('list')}
      </div>
      <button class="btn btn-primary btn-sm ml-auto" onclick="jobNew()">+ New Job</button>
    </div>
    <div id="cal-body"></div>`;
  _calRedraw();
}

// ── Navigation ────────────────────────────────────────────────────────────────

window._calToday   = function () { _calAnchor = _calIso(new Date()); _calRedraw(); };
window._calSetView = function (v) { _calView = v; _calRenderPage(document.getElementById('module-content')); };

window._calPrev = function () {
  const d = new Date(_calAnchor + 'T00:00:00');
  if (_calView === 'week') { d.setDate(d.getDate() - 7); }
  else { d.setDate(1); d.setMonth(d.getMonth() - 1); }
  _calAnchor = _calIso(d);
  _calRedraw();
};

window._calNext = function () {
  const d = new Date(_calAnchor + 'T00:00:00');
  if (_calView === 'week') { d.setDate(d.getDate() + 7); }
  else { d.setDate(1); d.setMonth(d.getMonth() + 1); }
  _calAnchor = _calIso(d);
  _calRedraw();
};

// ── Redraw ────────────────────────────────────────────────────────────────────

function _calRedraw () {
  const label = document.getElementById('cal-month-label');
  const body  = document.getElementById('cal-body');
  if (!label || !body) return;
  label.textContent = _calViewLabel();
  if      (_calView === 'week')  body.innerHTML = _calBuildWeek();
  else if (_calView === 'month') body.innerHTML = _calBuildMonth();
  else                           body.innerHTML = _calBuildList();
}

function _calViewLabel () {
  if (_calView === 'list') return 'All Jobs';
  const d = new Date(_calAnchor + 'T00:00:00');
  if (_calView === 'month') return d.toLocaleString('default', { month: 'long', year: 'numeric' });
  const mon = _calWeekMon(d);
  const sun = new Date(mon); sun.setDate(mon.getDate() + 6);
  if (mon.getMonth() === sun.getMonth())
    return `${mon.getDate()} – ${sun.getDate()} ${sun.toLocaleString('default', { month: 'long', year: 'numeric' })}`;
  return `${mon.toLocaleString('default', { day: 'numeric', month: 'short' })} – ${sun.toLocaleString('default', { day: 'numeric', month: 'short', year: 'numeric' })}`;
}

// ── Week view ─────────────────────────────────────────────────────────────────

function _calBuildWeek () {
  const todayISO = _calIso(new Date());
  const mon      = _calWeekMon(new Date(_calAnchor + 'T00:00:00'));
  const week     = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(mon); d.setDate(mon.getDate() + i); return d;
  });
  const hdr = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
    .map(h => `<div class="cal-hdr-cell">${h}</div>`).join('');
  return `<div class="cal-grid cal-week-grid">
    <div class="cal-day-headers">${hdr}</div>
    ${_calBuildWeekRow(week, todayISO, -1)}
  </div>`;
}

// ── Month view ────────────────────────────────────────────────────────────────

function _calBuildMonth () {
  const todayISO = _calIso(new Date());
  const d        = new Date(_calAnchor + 'T00:00:00');
  const year     = d.getFullYear();
  const month    = d.getMonth();
  const start    = _calWeekMon(new Date(year, month, 1));
  const weeks    = Array.from({ length: 6 }, (_, w) =>
    Array.from({ length: 7 }, (__, i) => {
      const day = new Date(start); day.setDate(start.getDate() + w * 7 + i); return day;
    })
  );
  const hdr  = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
    .map(h => `<div class="cal-hdr-cell">${h}</div>`).join('');
  const rows = weeks.map(wk => _calBuildWeekRow(wk, todayISO, month)).join('');
  return `<div class="cal-grid">
    <div class="cal-day-headers">${hdr}</div>
    ${rows}
  </div>`;
}

// ── Shared week row ───────────────────────────────────────────────────────────

function _calBuildWeekRow (week, todayISO, displayMonth) {
  const weekStartISO = _calIso(week[0]);
  const weekEndISO   = _calIso(week[6]);

  const dayCells = week.map(day => {
    const iso   = _calIso(day);
    const today = iso === todayISO;
    const other = displayMonth >= 0 && day.getMonth() !== displayMonth;
    return `<div class="cal-day-num-cell${other ? ' other-mo' : ''}">
      <span class="cal-day-num${today ? ' today-num' : ''}">${day.getDate()}</span>
    </div>`;
  }).join('');

  // Jobs overlapping this week (have a start_date)
  const overlapping = _calJobs.filter(j => {
    if (!j.start_date) return false;
    const end = j.end_date || j.start_date;
    return j.start_date <= weekEndISO && end >= weekStartISO;
  }).sort((a, b) => {
    if (a.start_date !== b.start_date) return a.start_date < b.start_date ? -1 : 1;
    return _calDur(b) - _calDur(a); // longer jobs first within same start
  });

  // Lane assignment — max 4 lanes before overflow
  const MAX    = 4;
  const lanes  = Array.from({ length: MAX }, () => Array(7).fill(null));
  const oflo   = Array(7).fill(0);

  for (const job of overlapping) {
    const end   = job.end_date || job.start_date;
    const slots = week.map(day => { const iso = _calIso(day); return iso >= job.start_date && iso <= end; });
    let placed  = false;
    for (let l = 0; l < MAX; l++) {
      if (slots.every((on, d) => !on || lanes[l][d] === null)) {
        slots.forEach((on, d) => { if (on) lanes[l][d] = job; });
        placed = true; break;
      }
    }
    if (!placed) slots.forEach((on, d) => { if (on) oflo[d]++; });
  }

  const laneRows = lanes
    .filter(lane => lane.some(j => j !== null))
    .map(lane => _calRenderLane(lane, weekStartISO, weekEndISO))
    .join('');

  const ofCells = oflo.map((n, d) =>
    `<div${n ? ' class="cal-more-cell"' : ''} style="grid-column:${d + 1}">${n ? `<span class="cal-more-pill">+${n} more</span>` : ''}</div>`
  ).join('');
  const ofRow = oflo.some(n => n > 0) ? `<div class="cal-event-row">${ofCells}</div>` : '';

  return `<div class="cal-week-row">
    <div class="cal-day-nums">${dayCells}</div>
    ${laneRows}${ofRow}
  </div>`;
}

function _calRenderLane (lane, weekStartISO, weekEndISO) {
  const cells = [];
  let d = 0;
  while (d < 7) {
    const job = lane[d];
    if (!job) { cells.push(`<div style="grid-column:${d + 1}"></div>`); d++; continue; }
    let e = d + 1;
    while (e < 7 && lane[e] === job) e++;
    const span = e - d;
    const end  = job.end_date || job.start_date;
    const isS  = job.start_date >= weekStartISO;
    const isE  = end <= weekEndISO;
    const cls  = `cal-chip ${_calChipCls(job.status)}${isS ? ' chip-s' : ''}${isE ? ' chip-e' : ''}`;
    const lbl  = isS
      ? `<span class="chip-lbl">${esc(job.job_number + ' – ' + job.name)}</span>`
      : `<span class="chip-lbl chip-cont">↳ ${esc(job.name)}</span>`;
    cells.push(`<div class="${cls}" style="grid-column:${d + 1}/span ${span}"
      onclick="jobOpen(${job.id})" title="${esc(job.job_number + ' – ' + job.name)}">${lbl}</div>`);
    d = e;
  }
  return `<div class="cal-event-row">${cells.join('')}</div>`;
}

// ── List view ─────────────────────────────────────────────────────────────────

function _calBuildList () {
  const sorted = _calJobs
    .filter(j => j.start_date)
    .sort((a, b) => a.start_date < b.start_date ? -1 : 1);

  if (!sorted.length) {
    return `<div class="job-empty" style="margin-top:48px">
      <div class="job-empty-icon">&#128197;</div>
      <div class="job-empty-sm">No scheduled jobs. Set a Start Date on a job to see it here.</div>
    </div>`;
  }

  let lastMo = '';
  const rows = sorted.map(j => {
    const mo = j.start_date.slice(0, 7);
    let hdr  = '';
    if (mo !== lastMo) {
      lastMo = mo;
      const dt = new Date(j.start_date + 'T00:00:00');
      hdr = `<div class="cal-list-hdr">${dt.toLocaleString('default', { month: 'long', year: 'numeric' })}</div>`;
    }
    const dates = j.end_date
      ? `${fmtDate(j.start_date)} – ${fmtDate(j.end_date)}`
      : fmtDate(j.start_date);
    return `${hdr}<div class="cal-list-row" onclick="jobOpen(${j.id})">
      <span class="cal-list-dot ${_calChipCls(j.status)}"></span>
      <span class="cal-list-dates">${dates}</span>
      <span class="cal-list-name">${esc(j.job_number)} — ${esc(j.name)}</span>
      <span class="cal-list-contact">${esc(j.contact_name || '')}</span>
    </div>`;
  }).join('');

  return `<div class="cal-list-wrap">${rows}</div>`;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function _calIso (d) {
  return d.toISOString().slice(0, 10);
}

function _calWeekMon (d) {
  const day = new Date(d);
  const dow = day.getDay();
  day.setDate(day.getDate() - (dow === 0 ? 6 : dow - 1));
  return day;
}

function _calDur (j) {
  if (!j.end_date) return 0;
  return (new Date(j.end_date + 'T00:00:00') - new Date(j.start_date + 'T00:00:00')) / 86400000;
}

function _calChipCls (status) {
  return { 'Active': 'chip-a', 'On Hold': 'chip-h', 'Completed': 'chip-c', 'Cancelled': 'chip-x', 'Draft': 'chip-d' }[status] || 'chip-a';
}
