// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ═══════════════════════════════════════════════════════════════════════════
// schedule.js — Job Calendar / Scheduler  (prefix: _cal)
// Uses shared helpers from dashboard.html: apiFetch, esc, fmtDate, isoToday,
// quickNewContact, detClose
// Calls jobOpen() / jobNew() from jobs.js
// ═══════════════════════════════════════════════════════════════════════════

'use strict';

const EVENT_TYPES = ['Personal', 'Appointment', 'Meeting', 'Reminder', 'Visit', 'Other'];

let _calJobs     = [];
let _calEvents   = [];
let _calContacts = [];
let _calAnchor   = '';     // ISO date YYYY-MM-DD — anchor for current view
let _calView     = 'month'; // 'week' | 'month' | 'list'
let _evtSelectedId = null;
let _calDragItem   = null; // {kind, id} of the chip currently being dragged
let _calGcalConnected  = false;
let _calGcalLastSynced = null;

// ── Entry point ──────────────────────────────────────────────────────────────

window.pageSchedule = async function () {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    [_calJobs, _calEvents, _calContacts] = await Promise.all([
      apiFetch('/api/jobs'),
      apiFetch('/api/schedule/events'),
      apiFetch('/api/contacts'),
    ]);
    _calJobs     = _calJobs || [];
    _calEvents   = _calEvents || [];
    _calContacts = _calContacts || [];
    _calAnchor = _calIso(new Date());
    _calView   = 'month';
    _calRenderPage(mod);
  } catch (e) {
    mod.innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`;
    return;
  }
  _calRefreshSyncStatus(); // non-blocking — page is already usable with local data
};

// ── Page scaffold ─────────────────────────────────────────────────────────────

function _calRenderPage (container) {
  const vBtn = v => {
    const label = v.charAt(0).toUpperCase() + v.slice(1);
    return `<button class="btn btn-sm ${_calView === v ? 'btn-primary' : 'btn-outline'}"
      onclick="_calSetView('${v}')">${label}</button>`;
  };
  container.innerHTML = `
    <div class="inv-toolbar">
      <div class="cal-nav-group">
        <button class="btn btn-outline btn-sm" onclick="_calToday()">Today</button>
        <button class="btn btn-outline btn-sm" onclick="_calPrev()">&#8249;</button>
        <button class="btn btn-outline btn-sm" onclick="_calNext()">&#8250;</button>
        <span class="cal-month-label" id="cal-month-label"></span>
      </div>
      <div class="cal-view-btns">
        ${vBtn('week')}${vBtn('month')}${vBtn('list')}
      </div>
      <div class="cal-sync-status" id="cal-sync-status"></div>
      <div class="cal-actions ml-auto">
        <button class="btn btn-outline btn-sm" onclick="_evtNew()">+ New Event</button>
        <button class="btn btn-primary btn-sm" onclick="jobNew()">+ New Job</button>
      </div>
    </div>
    <div id="cal-body"></div>`;
  _calRedraw();
  _calRenderSyncIndicator();
}

// ── Google Calendar sync indicator ───────────────────────────────────────────

function _calRenderSyncIndicator () {
  const el = document.getElementById('cal-sync-status');
  if (!el) return;
  if (!_calGcalConnected) { el.innerHTML = ''; return; }
  const when = _calGcalLastSynced || 'never';
  el.innerHTML = `<span class="cal-sync-label">Google Calendar synced ${esc(when)}</span>
    <button class="btn btn-outline btn-sm" id="cal-sync-btn" onclick="_calSyncNow(false)">Sync now</button>`;
}

async function _calRefreshSyncStatus () {
  try {
    const s = await apiFetch('/api/gcal/status');
    _calGcalConnected  = !!(s && s.connected);
    _calGcalLastSynced = s ? s.last_synced_at : null;
  } catch (e) {
    _calGcalConnected = false; // not connected, or not entitled — either way, stay quiet
  }
  _calRenderSyncIndicator();
  if (_calGcalConnected) _calSyncNow(true);
}

async function _calSyncNow (silent) {
  const btn = document.getElementById('cal-sync-btn');
  if (btn && !silent) { btn.disabled = true; btn.textContent = 'Syncing…'; }
  try {
    const r = await fetch('/api/gcal/sync', { method: 'POST', credentials: 'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Sync failed');
    [_calEvents, _calGcalLastSynced] = await Promise.all([
      apiFetch('/api/schedule/events'),
      apiFetch('/api/gcal/status').then(s => s ? s.last_synced_at : null),
    ]);
    _calEvents = _calEvents || [];
    _calRenderSyncIndicator();
    _calRedraw();
    if (!silent) toast('Synced with Google Calendar');
  } catch (e) {
    // A background auto-sync failing must not interrupt the page with a
    // toast — the Settings page's own "Sync now" is the place for that.
    if (!silent) toast(e.message, 'err');
  } finally {
    if (btn && !silent) { btn.disabled = false; btn.textContent = 'Sync now'; }
  }
}

// ── Cross-module refresh hook ──────────────────────────────────────────────────
// jobs.js edits/deletes/stage-changes a job through its own det-panel, which
// can be opened from the Schedule page's calendar chips. jobs.js has no idea
// the calendar is showing, so it can't refresh it itself — it calls this
// (guarded, since schedule.js may not be the active page) after any job
// change instead of leaving the calendar showing stale data until a manual
// page refresh.
window._calRefreshJobs = async function () {
  if (!document.getElementById('cal-body')) return; // Schedule isn't the active page
  // Refetch events too — a job's Visits tab adds/edits events.
  const [jobs, events] = await Promise.all([apiFetch('/api/jobs'), apiFetch('/api/schedule/events')]);
  _calJobs   = jobs   || [];
  _calEvents = events || [];
  _calRedraw();
};

// ── Navigation ────────────────────────────────────────────────────────────────

window._calToday   = function () { _calAnchor = _calIso(new Date()); _calRedraw(); };
window._calSetView = function (v) { _calView = v; _calRenderPage(document.getElementById('module-content')); };

window._calPrev = function () {
  const d = new Date(_calAnchor + 'T00:00:00');
  if (_calView === 'week') { d.setDate(d.getDate() - 7); }
  else { d.setDate(1); d.setMonth(d.getMonth() - 1); }
  _calAnchor = _calIso(d);
  _calRedraw();
};

window._calNext = function () {
  const d = new Date(_calAnchor + 'T00:00:00');
  if (_calView === 'week') { d.setDate(d.getDate() + 7); }
  else { d.setDate(1); d.setMonth(d.getMonth() + 1); }
  _calAnchor = _calIso(d);
  _calRedraw();
};

// ── Redraw ────────────────────────────────────────────────────────────────────

function _calRedraw () {
  const label = document.getElementById('cal-month-label');
  const body  = document.getElementById('cal-body');
  if (!label || !body) return;
  label.textContent = _calViewLabel();
  if      (_calView === 'week')  body.innerHTML = _calBuildWeek();
  else if (_calView === 'month') body.innerHTML = _calBuildMonth();
  else                           body.innerHTML = _calBuildList();
}

function _calViewLabel () {
  if (_calView === 'list') return 'All Jobs & Events';
  const d = new Date(_calAnchor + 'T00:00:00');
  if (_calView === 'month') return d.toLocaleString('default', { month: 'long', year: 'numeric' });
  const mon = _calWeekMon(d);
  const sun = new Date(mon); sun.setDate(mon.getDate() + 6);
  if (mon.getMonth() === sun.getMonth())
    return `${mon.getDate()} – ${sun.getDate()} ${sun.toLocaleString('default', { month: 'long', year: 'numeric' })}`;
  return `${mon.toLocaleString('default', { day: 'numeric', month: 'short' })} – ${sun.toLocaleString('default', { day: 'numeric', month: 'short', year: 'numeric' })}`;
}

// ── Unified calendar items (jobs + events) ────────────────────────────────────

window._calOpenItem = function (kind, id) {
  if (kind === 'event') _evtOpen(id); else jobOpen(id);
};

function _calItems () {
  // A job with visits is shown by its visits, not its start–end span —
  // matches what Google Calendar gets (core/gcal.py: push_job).
  const jobsWithVisits = new Set((_calEvents || [])
    .filter(e => e.event_type === 'Visit' && e.job_id).map(e => e.job_id));
  const jobs = (_calJobs || []).filter(j => j.start_date && !jobsWithVisits.has(j.id)).map(j => ({
    id: j.id, kind: 'job',
    start_date: j.start_date, end_date: j.end_date || j.start_date,
    chipCls: _calChipCls(j.status),
    label: `${j.job_number} – ${j.name}`,
    contLabel: j.name,
    subLabel: j.contact_name || '',
  }));
  const events = (_calEvents || []).filter(e => e.event_date).map(e => ({
    id: e.id, kind: 'event',
    start_date: e.event_date, end_date: e.end_date || e.event_date,
    chipCls: 'chip-p',
    label: e.title,
    contLabel: e.title,
    subLabel: e.event_type === 'Visit' && e.job_number ? `Visit · ${e.job_number}` : (e.event_type || ''),
    synced: !!e.gcal_event_id,
  }));
  return jobs.concat(events);
}

// ── Week view ─────────────────────────────────────────────────────────────────

function _calBuildWeek () {
  const todayISO = _calIso(new Date());
  const mon      = _calWeekMon(new Date(_calAnchor + 'T00:00:00'));
  const week     = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(mon); d.setDate(mon.getDate() + i); return d;
  });
  const hdr = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
    .map(h => `<div class="cal-hdr-cell">${h}</div>`).join('');
  return `<div class="cal-grid cal-week-grid">
    <div class="cal-day-headers">${hdr}</div>
    ${_calBuildWeekRow(week, todayISO, -1)}
  </div>`;
}

// ── Month view ────────────────────────────────────────────────────────────────

function _calBuildMonth () {
  const todayISO = _calIso(new Date());
  const d        = new Date(_calAnchor + 'T00:00:00');
  const year     = d.getFullYear();
  const month    = d.getMonth();
  const start    = _calWeekMon(new Date(year, month, 1));
  const weeks    = Array.from({ length: 6 }, (_, w) =>
    Array.from({ length: 7 }, (__, i) => {
      const day = new Date(start); day.setDate(start.getDate() + w * 7 + i); return day;
    })
  );
  const hdr  = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
    .map(h => `<div class="cal-hdr-cell">${h}</div>`).join('');
  const rows = weeks.map(wk => _calBuildWeekRow(wk, todayISO, month)).join('');
  return `<div class="cal-grid">
    <div class="cal-day-headers">${hdr}</div>
    ${rows}
  </div>`;
}

// ── Shared week row ───────────────────────────────────────────────────────────

function _calBuildWeekRow (week, todayISO, displayMonth) {
  const weekStartISO = _calIso(week[0]);
  const weekEndISO   = _calIso(week[6]);

  const dayCells = week.map(day => {
    const iso   = _calIso(day);
    const today = iso === todayISO;
    const other = displayMonth >= 0 && day.getMonth() !== displayMonth;
    return `<div class="cal-day-num-cell${other ? ' other-mo' : ''}">
      <span class="cal-day-num${today ? ' today-num' : ''}">${day.getDate()}</span>
    </div>`;
  }).join('');

  // Jobs + events overlapping this week
  const overlapping = _calItems().filter(it => {
    return it.start_date <= weekEndISO && it.end_date >= weekStartISO;
  }).sort((a, b) => {
    if (a.start_date !== b.start_date) return a.start_date < b.start_date ? -1 : 1;
    return _calDur(b) - _calDur(a); // longer items first within same start
  });

  // Lane assignment — max 4 lanes before overflow
  const MAX    = 4;
  const lanes  = Array.from({ length: MAX }, () => Array(7).fill(null));
  const oflo   = Array(7).fill(0);

  for (const item of overlapping) {
    const slots = week.map(day => { const iso = _calIso(day); return iso >= item.start_date && iso <= item.end_date; });
    let placed  = false;
    for (let l = 0; l < MAX; l++) {
      if (slots.every((on, d) => !on || lanes[l][d] === null)) {
        slots.forEach((on, d) => { if (on) lanes[l][d] = item; });
        placed = true; break;
      }
    }
    if (!placed) slots.forEach((on, d) => { if (on) oflo[d]++; });
  }

  const laneRows = lanes
    .filter(lane => lane.some(it => it !== null))
    .map(lane => _calRenderLane(lane, weekStartISO, weekEndISO))
    .join('');

  const ofCells = oflo.map((n, d) =>
    `<div${n ? ' class="cal-more-cell"' : ''} style="grid-column:${d + 1}">${n ? `<span class="cal-more-pill">+${n} more</span>` : ''}</div>`
  ).join('');
  const ofRow = oflo.some(n => n > 0) ? `<div class="cal-event-row">${ofCells}</div>` : '';

  return `<div class="cal-week-row" ondragover="_calRowDragOver(event)" ondrop="_calRowDrop(event,'${weekStartISO}')">
    <div class="cal-day-nums">${dayCells}</div>
    ${laneRows}${ofRow}
  </div>`;
}

function _calRenderLane (lane, weekStartISO, weekEndISO) {
  const cells = [];
  let d = 0;
  while (d < 7) {
    const item = lane[d];
    if (!item) { cells.push(`<div style="grid-column:${d + 1}"></div>`); d++; continue; }
    let e = d + 1;
    while (e < 7 && lane[e] === item) e++;
    const span = e - d;
    const isS  = item.start_date >= weekStartISO;
    const isE  = item.end_date <= weekEndISO;
    const cls   = `cal-chip ${item.chipCls}${isS ? ' chip-s' : ''}${isE ? ' chip-e' : ''}`;
    const badge = item.synced ? '<span class="chip-gcal-badge" title="Synced with Google Calendar">☁</span>' : '';
    const lbl   = isS
      ? `<span class="chip-lbl">${badge}${esc(item.label)}</span>`
      : `<span class="chip-lbl chip-cont">↳ ${esc(item.contLabel)}</span>`;
    cells.push(`<div class="${cls}" style="grid-column:${d + 1}/span ${span}" draggable="true"
      ondragstart="_calDragStart(event,'${item.kind}',${item.id})" ondragend="_calDragEnd(event)"
      onclick="_calOpenItem('${item.kind}',${item.id})" title="Drag to reschedule — click to open&#10;${esc(item.label)}">${lbl}</div>`);
    d = e;
  }
  return `<div class="cal-event-row">${cells.join('')}</div>`;
}

// ── List view ─────────────────────────────────────────────────────────────────

function _calBuildList () {
  const sorted = _calItems().sort((a, b) => a.start_date < b.start_date ? -1 : 1);

  if (!sorted.length) {
    return `<div class="job-empty" style="margin-top:48px">
      <div class="job-empty-icon">&#128197;</div>
      <div class="job-empty-sm">No scheduled jobs or events. Set a Start Date on a job, or add an event, to see it here.</div>
    </div>`;
  }

  let lastMo = '';
  const rows = sorted.map(it => {
    const mo = it.start_date.slice(0, 7);
    let hdr  = '';
    if (mo !== lastMo) {
      lastMo = mo;
      const dt = new Date(it.start_date + 'T00:00:00');
      hdr = `<div class="cal-list-hdr">${dt.toLocaleString('default', { month: 'long', year: 'numeric' })}</div>`;
    }
    const dates = it.end_date && it.end_date !== it.start_date
      ? `${fmtDate(it.start_date)} – ${fmtDate(it.end_date)}`
      : fmtDate(it.start_date);
    const badge = it.synced ? '<span class="chip-gcal-badge" title="Synced with Google Calendar">☁</span>' : '';
    return `${hdr}<div class="cal-list-row" onclick="_calOpenItem('${it.kind}',${it.id})">
      <span class="cal-list-dot ${it.chipCls}"></span>
      <span class="cal-list-dates">${dates}</span>
      <span class="cal-list-name">${badge}${esc(it.label)}</span>
      <span class="cal-list-contact">${esc(it.subLabel || '')}</span>
    </div>`;
  }).join('');

  return `<div class="cal-list-wrap">${rows}</div>`;
}

// ── Drag & drop reschedule ────────────────────────────────────────────────────
// One dragover/drop listener per week row (not per day cell) — the target day
// is worked out from the drop's x-position across the row's 7 equal columns,
// so dropping anywhere in that day's column works, including directly on top
// of another chip.

window._calDragStart = function (ev, kind, id) {
  _calDragItem = { kind, id };
  ev.dataTransfer.effectAllowed = 'move';
  ev.dataTransfer.setData('text/plain', `${kind}:${id}`); // required by Firefox for drag to start
  ev.currentTarget.classList.add('cal-dragging');
};

window._calDragEnd = function (ev) {
  ev.currentTarget.classList.remove('cal-dragging');
  _calDragItem = null;
};

window._calRowDragOver = function (ev) {
  if (!_calDragItem) return;
  ev.preventDefault();
  ev.dataTransfer.dropEffect = 'move';
};

window._calRowDrop = async function (ev, weekStartISO) {
  if (!_calDragItem) return;
  ev.preventDefault();
  const drag = _calDragItem;
  _calDragItem = null;

  const rect   = ev.currentTarget.getBoundingClientRect();
  const dayIdx = Math.max(0, Math.min(6, Math.floor((ev.clientX - rect.left) / (rect.width / 7))));
  const targetDate = _calAddDays(weekStartISO, dayIdx);

  const item = _calItems().find(it => it.kind === drag.kind && it.id === drag.id);
  if (!item || item.start_date === targetDate) return;

  const span     = _calDur(item); // whole days between start/end — 0 for a single-day item
  const newStart = targetDate;
  const newEnd   = _calAddDays(targetDate, span);

  try {
    if (drag.kind === 'job') {
      const job = (_calJobs || []).find(j => j.id === drag.id);
      if (!job) return;
      const r = await fetch('/api/jobs', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...job, start_date: newStart, end_date: newEnd }),
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Failed to reschedule job');
      job.start_date = newStart; job.end_date = newEnd;
      toast('Job rescheduled');
    } else {
      const evt = (_calEvents || []).find(e => e.id === drag.id);
      if (!evt) return;
      const r = await fetch(`/api/schedule/events/${drag.id}`, {
        method: 'PUT', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...evt, event_date: newStart, end_date: newEnd }),
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Failed to reschedule event');
      evt.event_date = newStart; evt.end_date = newEnd;
      toast('Event rescheduled');
    }
    _calRedraw();
  } catch (e) {
    toast(e.message, 'err');
  }
};

function _calAddDays (iso, days) {
  const d = new Date(iso + 'T00:00:00');
  d.setDate(d.getDate() + days);
  return _calIso(d);
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function _calIso (d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function _calWeekMon (d) {
  const day = new Date(d);
  const dow = day.getDay();
  day.setDate(day.getDate() - (dow === 0 ? 6 : dow - 1));
  return day;
}

function _calDur (it) {
  if (!it.end_date || it.end_date === it.start_date) return 0;
  return (new Date(it.end_date + 'T00:00:00') - new Date(it.start_date + 'T00:00:00')) / 86400000;
}

function _calChipCls (status) {
  return { 'Active': 'chip-a', 'On Hold': 'chip-h', 'Completed': 'chip-c', 'Cancelled': 'chip-x', 'Draft': 'chip-d' }[status] || 'chip-a';
}

// ═══════════════════════════════════════════════════════════════════════════
// NEW / EDIT EVENT FORM
// ═══════════════════════════════════════════════════════════════════════════

window._evtNew = async function () {
  await _evtForm(null);
};

window._evtOpen = async function (id) {
  const existing = (_calEvents || []).find(e => e.id === id);
  if (!existing) { toast('Event not found', 'err'); return; }
  await _evtForm(existing);
};

async function _evtForm (existing) {
  const isEdit = !!existing;
  _evtSelectedId = existing?.id || null;

  const typeOpts = EVENT_TYPES.map(t =>
    `<option${(existing?.event_type || 'Personal') === t ? ' selected' : ''}>${t}</option>`
  ).join('');
  const conOpts = (_calContacts || []).map(c =>
    `<option value="${c.id}"${existing?.contact_id == c.id ? ' selected' : ''}>${esc(c.name)}</option>`
  ).join('');
  const jobOpts = (_calJobs || []).map(j =>
    `<option value="${j.id}"${existing?.job_id == j.id ? ' selected' : ''}>${esc(j.job_number + ' – ' + j.name)}</option>`
  ).join('');
  const allDay = existing ? !!existing.all_day : true;

  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = isEdit ? 'Edit Event' : 'New Event';

  document.getElementById('det-body').innerHTML = `
    <h3 class="form-section-hdr">Event Details</h3>
    <div class="job-form-grid">
      <div class="modal-field job-grid-full">
        <label class="modal-lbl">Title *</label>
        <input class="modal-inp" id="ef-title" placeholder="e.g. Dentist appointment" value="${esc(existing?.title || '')}">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Type</label>
        <select class="modal-sel" id="ef-type" onchange="_evtToggleHours()">${typeOpts}</select>
      </div>
      <div class="modal-field">
        <label class="modal-lbl">All Day</label>
        <select class="modal-sel" id="ef-allday" onchange="_evtToggleTimes()">
          <option value="1"${allDay ? ' selected' : ''}>Yes</option>
          <option value="0"${!allDay ? ' selected' : ''}>No</option>
        </select>
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Date</label>
        <input class="modal-inp" id="ef-date" type="date" value="${existing?.event_date || isoToday()}">
      </div>
      <div class="modal-field">
        <label class="modal-lbl">End Date</label>
        <input class="modal-inp" id="ef-end-date" type="date" value="${existing?.end_date || ''}">
      </div>
      <div class="modal-field" id="ef-start-time-field" style="${allDay ? 'display:none' : ''}">
        <label class="modal-lbl">Start Time</label>
        <input class="modal-inp" id="ef-start-time" type="time" value="${existing?.start_time || ''}">
      </div>
      <div class="modal-field" id="ef-end-time-field" style="${allDay ? 'display:none' : ''}">
        <label class="modal-lbl">End Time</label>
        <input class="modal-inp" id="ef-end-time" type="time" value="${existing?.end_time || ''}">
      </div>
      <div class="modal-field" id="ef-hours-field" style="${existing?.event_type === 'Visit' ? '' : 'display:none'}">
        <label class="modal-lbl">Hours worked</label>
        <input class="modal-inp" id="ef-hours" type="number" step="0.25" min="0" value="${existing?.hours ?? ''}">
      </div>
      <div class="modal-field job-grid-full">
        <label class="modal-lbl">Description</label>
        <textarea class="modal-inp edt-ta-resize" id="ef-desc" rows="2">${esc(existing?.description || '')}</textarea>
      </div>
      <div class="modal-field">
        <div class="lbl-line">
          <label class="modal-lbl">Contact</label>
          <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();_evtNewContact('ef-contact')">+ New</a>
        </div>
        <select class="modal-sel" id="ef-contact">
          <option value="">— None —</option>${conOpts}
        </select>
      </div>
      <div class="modal-field">
        <label class="modal-lbl">Job</label>
        <select class="modal-sel" id="ef-job">
          <option value="">— None —</option>${jobOpts}
        </select>
      </div>
    </div>`;

  const canConvert = isEdit && !existing.job_id;
  document.getElementById('det-foot').innerHTML = `
    ${isEdit ? `<button class="btn btn-outline" onclick="_evtDelete(${existing.id})">Delete</button>` : ''}
    ${canConvert ? `<button class="btn btn-outline" onclick="_evtConvertToJob(${existing.id})">Convert to Job</button>` : ''}
    ${isEdit && existing.job_id ? `<button class="btn btn-outline" onclick="jobOpen(${existing.job_id})">Open Job</button>` : ''}
    <button class="btn btn-outline ml-auto" onclick="${isEdit ? `_evtOpen(${existing.id})` : 'detClose()'}">Cancel</button>
    <button class="btn btn-primary" onclick="_evtSave(${existing?.id || 'null'})">
      ${isEdit ? 'Save Changes' : 'Create Event'}
    </button>`;

  setTimeout(() => document.getElementById('ef-title')?.focus(), 80);
}

window._evtToggleHours = function () {
  const isVisit = document.getElementById('ef-type')?.value === 'Visit';
  document.getElementById('ef-hours-field').style.display = isVisit ? '' : 'none';
};

window._evtToggleTimes = function () {
  const allDay = document.getElementById('ef-allday')?.value === '1';
  document.getElementById('ef-start-time-field').style.display = allDay ? 'none' : '';
  document.getElementById('ef-end-time-field').style.display   = allDay ? 'none' : '';
};

async function _evtNewContact (selId) {
  const c = await quickNewContact('Customer');
  if (!c) return;
  _calContacts.push(c);
  const sel = document.getElementById(selId);
  if (sel) sel.appendChild(new Option(c.name, c.id, true, true));
}

window._evtSave = async function (editId) {
  const title = (document.getElementById('ef-title')?.value || '').trim();
  if (!title) { toast('Title is required', 'err'); return; }

  const allDay   = document.getElementById('ef-allday')?.value === '1';
  const startTime = document.getElementById('ef-start-time')?.value || null;
  const endTime   = document.getElementById('ef-end-time')?.value || null;
  if (!allDay && (!startTime || !endTime)) {
    toast('Start and end time are required for a timed event — or switch All Day to Yes', 'err');
    return;
  }
  const eventType = document.getElementById('ef-type')?.value || 'Personal';
  const jobId     = parseInt(document.getElementById('ef-job')?.value) || null;
  if (eventType === 'Visit' && !jobId) { toast('A visit must be linked to a job', 'err'); return; }
  const hrsRaw = document.getElementById('ef-hours')?.value ?? '';

  const payload = {
    id:          editId || null,
    title,
    event_type:  eventType,
    all_day:     allDay,
    event_date:  document.getElementById('ef-date')?.value,
    end_date:    document.getElementById('ef-end-date')?.value || null,
    start_time:  startTime,
    end_time:    endTime,
    description: document.getElementById('ef-desc')?.value.trim() || null,
    contact_id:  parseInt(document.getElementById('ef-contact')?.value) || null,
    job_id:      jobId,
    hours:       hrsRaw === '' ? null : parseFloat(hrsRaw),
  };

  try {
    const r = await fetch(editId ? `/api/schedule/events/${editId}` : '/api/schedule/events', {
      method: editId ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(payload),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed to save event');
    toast(editId ? 'Event updated' : 'Event created');
    _calEvents = (await apiFetch('/api/schedule/events')) || [];
    detClose();
    _calRedraw();
  } catch (e) { toast(e.message, 'err'); }
};

window._evtDelete = async function (id) {
  if (!confirm('Delete this event?')) return;
  try {
    let r = await fetch(`/api/schedule/events/${id}`, { method: 'DELETE', credentials: 'include' });
    let j = await r.json();
    if (r.status === 409) {
      // A job visit with task progress recorded — confirm before losing it.
      if (!confirm(`${j.error}. Delete anyway?`)) return;
      r = await fetch(`/api/schedule/events/${id}?force=1`, { method: 'DELETE', credentials: 'include' });
      j = await r.json();
    }
    if (!j.ok) throw new Error(j.error || 'Failed to delete event');
    toast('Event deleted');
    _calEvents = _calEvents.filter(e => e.id !== id);
    detClose();
    _calRedraw();
  } catch (e) { toast(e.message, 'err'); }
};

window._evtConvertToJob = async function (id) {
  if (!confirm('Convert this event into a Job? The event stays on the calendar as the new job\'s first visit.')) return;
  try {
    const r = await fetch(`/api/schedule/events/${id}/convert-to-job`, { method: 'POST', credentials: 'include' });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed to convert event');
    toast('Converted to job');
    [_calJobs, _calEvents] = await Promise.all([
      apiFetch('/api/jobs'), apiFetch('/api/schedule/events'),
    ]);
    detClose();
    _calRedraw();
    jobOpen(j.data.id);
  } catch (e) { toast(e.message, 'err'); }
};
