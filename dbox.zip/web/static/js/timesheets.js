// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// Work Diary — cross-job daily time entry view
// Prefix: _ts

let _tsDate        = null;
let _tsEmpFilter   = '';
let _tsEntries     = [];
let _tsEmployees   = [];
let _tsJobs        = [];
let _tsMetaLoaded  = false;

async function pageTimesheets() {
  if (!_tsDate) _tsDate = new Date().toISOString().slice(0, 10);

  const mod = document.getElementById('module-content');
  mod.innerHTML = `
<div class="inv-toolbar">
  <div class="ts-date-nav">
    <button class="btn btn-outline btn-sm" onclick="_tsPrevDay()">&#8249;</button>
    <input type="date" id="ts-date-inp" value="${_tsDate}"
           onchange="_tsDateChange(this.value)"
           style="font-size:13px;padding:4px 8px;border:1px solid var(--border);
                  border-radius:4px;background:var(--surface);color:var(--ink)">
    <button class="btn btn-outline btn-sm" onclick="_tsNextDay()">&#8250;</button>
    <button class="btn btn-outline btn-sm" id="ts-today-btn" onclick="_tsGoToday()">Today</button>
  </div>
  <select id="ts-emp-filter" onchange="_tsEmpFilterChange(this.value)"
    style="font-size:12.5px;padding:4px 8px;border:1px solid var(--border);
           border-radius:4px;background:var(--surface);color:var(--ink);height:30px">
    <option value="">All employees</option>
  </select>
  <button class="btn btn-primary" onclick="_tsOpenForm(null)">+ Add Entry</button>
</div>
<div class="inv-list-panel">
  <div class="tbl-overflow-x">
    <table class="inv-list-table">
      <thead><tr>
        <th>Employee</th>
        <th>Job</th>
        <th>Description</th>
        <th class="td-r-mono">Hrs</th>
        <th class="td-r-mono">Rate</th>
        <th class="td-r-mono">Cost</th>
        <th>Status</th>
        <th style="width:100px"></th>
      </tr></thead>
      <tbody id="ts-tbody"><tr><td colspan="8" class="state-loading">Loading…</td></tr></tbody>
      <tfoot id="ts-tfoot"></tfoot>
    </table>
  </div>
</div>
<div class="count-pill" id="ts-count"></div>`;

  try {
    if (!_tsMetaLoaded) {
      [_tsEmployees, _tsJobs] = await Promise.all([
        apiFetch('/api/payroll/employees').catch(() => []),
        apiFetch('/api/jobs').catch(() => []),
      ]);
      _tsMetaLoaded = true;
    }
    _tsPopulateEmpFilter();
    await _tsLoad();
  } catch(e) {
    const tb = document.getElementById('ts-tbody');
    if (tb) tb.innerHTML = `<tr><td colspan="8" class="state-empty">Failed to load</td></tr>`;
  }
}

function _tsPopulateEmpFilter() {
  const sel = document.getElementById('ts-emp-filter');
  if (!sel) return;
  // Remove existing dynamic options
  while (sel.options.length > 1) sel.remove(1);
  _tsEmployees.forEach(e => {
    const opt = document.createElement('option');
    opt.value  = e.id;
    opt.textContent = `${e.last_name}, ${e.first_name}`;
    if (String(e.id) === String(_tsEmpFilter)) opt.selected = true;
    sel.appendChild(opt);
  });
}

async function _tsLoad() {
  const tb = document.getElementById('ts-tbody');
  if (!tb) return;
  const params = new URLSearchParams({ date: _tsDate });
  if (_tsEmpFilter) params.set('employee_id', _tsEmpFilter);
  try {
    _tsEntries = await apiFetch('/api/jobs/time-entries?' + params);
    _tsRender();
  } catch(e) {
    tb.innerHTML = `<tr><td colspan="8" class="state-empty">${esc(e.message || 'Error loading entries')}</td></tr>`;
  }
}

function _tsRender() {
  const tb    = document.getElementById('ts-tbody');
  const tft   = document.getElementById('ts-tfoot');
  const count = document.getElementById('ts-count');
  if (!tb) return;

  if (!_tsEntries.length) {
    tb.innerHTML = `<tr><td colspan="8" class="state-empty">No entries for this date — click <strong>+ Add Entry</strong> to log time</td></tr>`;
    if (tft)   tft.innerHTML  = '';
    if (count) count.textContent = '';
    return;
  }

  tb.innerHTML = _tsEntries.map(e => {
    const empName  = `${e.first_name} ${e.last_name}`;
    const jobRef   = `${e.job_number} — ${e.job_name}`;
    const cost     = (Number(e.hours) * Number(e.hourly_rate)).toFixed(2);
    const isPend   = (e.status || 'Pending') === 'Pending';
    const badge    = isPend
      ? `<span class="ts-badge ts-badge-pending">Pending</span>`
      : `<span class="ts-badge ts-badge-approved">Approved</span>`;
    const appLabel = isPend ? 'Approve' : 'Undo';
    return `<tr>
      <td>${esc(empName)}</td>
      <td class="ts-job-ref">${esc(jobRef)}</td>
      <td>${esc(e.description || '—')}</td>
      <td class="td-r-mono">${Number(e.hours).toFixed(2)}</td>
      <td class="td-r-mono">$${Number(e.hourly_rate).toFixed(2)}</td>
      <td class="td-r-mono">$${cost}</td>
      <td>${badge}</td>
      <td style="text-align:right;white-space:nowrap">
        <button class="btn btn-sm btn-outline btn-xs"
          onclick="_tsToggleApprove(${e.id},'${e.status||'Pending'}')">${appLabel}</button>
        <button class="btn btn-sm btn-outline btn-xs ml-3"
          onclick="_tsOpenForm(${e.id})">Edit</button>
        <button class="btn btn-sm btn-danger btn-xs ml-3"
          onclick="_tsDelete(${e.id})">&#10005;</button>
      </td>
    </tr>`;
  }).join('');

  const totalHrs  = _tsEntries.reduce((s, e) => s + Number(e.hours), 0);
  const totalCost = _tsEntries.reduce((s, e) => s + Number(e.hours) * Number(e.hourly_rate), 0);

  if (tft) {
    tft.innerHTML = `<tr class="ts-totals-row">
      <td colspan="3"><strong>Total</strong></td>
      <td class="td-r-mono"><strong>${totalHrs.toFixed(2)}</strong></td>
      <td></td>
      <td class="td-r-mono"><strong>$${totalCost.toFixed(2)}</strong></td>
      <td colspan="2"></td>
    </tr>`;
  }
  if (count) {
    const n = _tsEntries.length;
    count.textContent = `${n} entr${n === 1 ? 'y' : 'ies'} · ${totalHrs.toFixed(2)} hrs · $${totalCost.toFixed(2)}`;
  }
}

function _tsPrevDay() {
  const d = new Date(_tsDate + 'T00:00:00');
  d.setDate(d.getDate() - 1);
  _tsDate = d.toISOString().slice(0, 10);
  const inp = document.getElementById('ts-date-inp');
  if (inp) inp.value = _tsDate;
  _tsLoad();
}

function _tsNextDay() {
  const d = new Date(_tsDate + 'T00:00:00');
  d.setDate(d.getDate() + 1);
  _tsDate = d.toISOString().slice(0, 10);
  const inp = document.getElementById('ts-date-inp');
  if (inp) inp.value = _tsDate;
  _tsLoad();
}

function _tsGoToday() {
  _tsDate = new Date().toISOString().slice(0, 10);
  const inp = document.getElementById('ts-date-inp');
  if (inp) inp.value = _tsDate;
  _tsLoad();
}

function _tsDateChange(val) {
  if (!val) return;
  _tsDate = val;
  _tsLoad();
}

function _tsEmpFilterChange(val) {
  _tsEmpFilter = val;
  _tsLoad();
}

function _tsOpenForm(entryId) {
  const entry = entryId ? _tsEntries.find(e => e.id === entryId) : null;
  const title = entry ? 'Edit Time Entry' : 'Add Time Entry';

  const empOpts = _tsEmployees.length
    ? _tsEmployees.map(e =>
        `<option value="${e.id}"${entry && e.id === entry.employee_id ? ' selected' : ''}>${esc(e.last_name)}, ${esc(e.first_name)}</option>`
      ).join('')
    : `<option value="" disabled>No employees found</option>`;

  const activeJobs = _tsJobs.filter(j => j.status !== 'Cancelled' && j.status !== 'Completed');
  const jobOpts = activeJobs.length
    ? activeJobs.map(j =>
        `<option value="${j.id}"${entry && j.id === entry.job_id ? ' selected' : ''}>${esc(j.job_number)} — ${esc(j.name)}</option>`
      ).join('')
    : `<option value="" disabled>No active jobs found</option>`;

  const existing = document.getElementById('ts-form-modal');
  if (existing) existing.remove();

  const bd = document.createElement('div');
  bd.className     = 'modal-bd';
  bd.style.display = 'flex';
  bd.id            = 'ts-form-modal';
  bd.innerHTML = `<div class="modal-box" style="width:440px;max-width:95vw">
  <div class="modal-hdr">
    <span>${title}</span>
    <button class="modal-x" onclick="document.getElementById('ts-form-modal').remove()">&#10005;</button>
  </div>
  <div class="modal-body">
    <input type="hidden" id="ts-f-id" value="${entry ? entry.id : ''}">
    <input type="hidden" id="ts-f-job-id" value="${entry ? entry.job_id : ''}">
    <div class="edt-field">
      <label class="edt-lbl">Date</label>
      <input type="date" class="edt-inp" id="ts-f-date"
             value="${entry ? entry.entry_date : _tsDate}">
    </div>
    <div class="edt-field">
      <label class="edt-lbl">Employee</label>
      <select class="edt-inp" id="ts-f-emp" onchange="_tsFillRate()">
        <option value="">&#8212; Select employee &#8212;</option>
        ${empOpts}
      </select>
    </div>
    <div class="edt-field">
      <label class="edt-lbl">Job</label>
      <select class="edt-inp" id="ts-f-job">
        <option value="">&#8212; Select job &#8212;</option>
        ${jobOpts}
      </select>
    </div>
    <div style="display:flex;gap:12px">
      <div class="edt-field" style="flex:1">
        <label class="edt-lbl">Hours</label>
        <input type="number" class="edt-inp" id="ts-f-hours"
               value="${entry ? entry.hours : ''}"
               min="0" step="0.25" placeholder="0.00">
      </div>
      <div class="edt-field" style="flex:1">
        <label class="edt-lbl">Rate ($/hr)</label>
        <input type="number" class="edt-inp" id="ts-f-rate"
               value="${entry ? entry.hourly_rate : ''}"
               min="0" step="0.01" placeholder="0.00">
      </div>
    </div>
    <div class="edt-field">
      <label class="edt-lbl">Description</label>
      <input class="edt-inp" id="ts-f-desc"
             value="${entry ? esc(entry.description || '') : ''}"
             placeholder="Work performed…">
    </div>
  </div>
  <div class="modal-foot">
    <button class="btn btn-outline"
      onclick="document.getElementById('ts-form-modal').remove()">Cancel</button>
    <button class="btn btn-primary" onclick="_tsSave()">Save</button>
  </div>
</div>`;

  document.body.appendChild(bd);
  bd.addEventListener('click', ev => { if (ev.target === bd) bd.remove(); });

  // Auto-fill rate for new entry when employee pre-selected
  if (!entry) {
    const empSel = document.getElementById('ts-f-emp');
    if (empSel && _tsEmpFilter) {
      empSel.value = _tsEmpFilter;
      _tsFillRate();
    }
  }
  document.getElementById('ts-f-hours').focus();
}

function _tsFillRate() {
  const rateInp = document.getElementById('ts-f-rate');
  if (!rateInp || rateInp.value) return;
  const empId = parseInt(document.getElementById('ts-f-emp')?.value || '0');
  if (!empId) return;
  const emp = _tsEmployees.find(e => e.id === empId);
  if (emp && (emp.hourly_rate || emp.base_rate)) {
    rateInp.value = (emp.hourly_rate || emp.base_rate || 0).toFixed(2);
  }
}

async function _tsSave() {
  const id      = document.getElementById('ts-f-id')?.value;
  const date    = document.getElementById('ts-f-date')?.value;
  const empId   = document.getElementById('ts-f-emp')?.value;
  const jobId   = document.getElementById('ts-f-job')?.value;
  const hours   = document.getElementById('ts-f-hours')?.value;
  const rate    = document.getElementById('ts-f-rate')?.value;
  const desc    = (document.getElementById('ts-f-desc')?.value || '').trim();

  if (!date)                        { toast('Date is required', 'err');                return; }
  if (!empId)                       { toast('Select an employee', 'err');              return; }
  if (!jobId)                       { toast('Select a job', 'err');                    return; }
  if (!hours || parseFloat(hours) <= 0) { toast('Hours must be greater than 0', 'err'); return; }

  const payload = {
    employee_id:  parseInt(empId),
    job_id:       parseInt(jobId),
    entry_date:   date,
    hours:        parseFloat(hours),
    hourly_rate:  parseFloat(rate) || 0,
    description:  desc,
  };

  try {
    let r, j;
    if (id) {
      payload.id = parseInt(id);
      r = await fetch(`/api/jobs/time/${id}`, {
        method: 'PUT', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      j = await r.json();
    } else {
      r = await fetch(`/api/jobs/${parseInt(jobId)}/time`, {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      j = await r.json();
    }
    if (!j.ok) { toast(j.error || 'Save failed', 'err'); return; }
    document.getElementById('ts-form-modal')?.remove();
    toast(id ? 'Entry updated' : 'Time entry saved');
    await _tsLoad();
  } catch(_) {
    toast('Save failed', 'err');
  }
}

async function _tsToggleApprove(entryId, currentStatus) {
  const newStatus = currentStatus === 'Pending' ? 'Approved' : 'Pending';
  try {
    const r = await fetch(`/api/jobs/time/${entryId}`, {
      method: 'PUT', credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: entryId, status: newStatus }),
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Update failed', 'err'); return; }
    const entry = _tsEntries.find(e => e.id === entryId);
    if (entry) { entry.status = newStatus; _tsRender(); }
  } catch(_) {
    toast('Failed to update status', 'err');
  }
}

async function _tsDelete(entryId) {
  if (!confirm('Delete this time entry?')) return;
  try {
    const r = await fetch(`/api/jobs/time/${entryId}`, {
      method: 'DELETE', credentials: 'include',
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Delete failed', 'err'); return; }
    toast('Entry deleted');
    await _tsLoad();
  } catch(_) {
    toast('Delete failed', 'err');
  }
}
