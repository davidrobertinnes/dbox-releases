// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ══════════════════════════════════════════════════════════════════════════════
//  WARRANTIES — Web UI module
//  Namespace: _wx*
//  Entry:     pageWarranties()
//
//  Features:
//    • Warranty register list with status filter pills + search
//    • Slide-over: warranty detail with claim history
//    • New / Edit warranty form (slide-over)
//    • Lodge Claim modal (all 9 outcomes from CLAIM_OUTCOMES)
//    • Delete confirmation modal
// ══════════════════════════════════════════════════════════════════════════════

"use strict";

// ── Module state ──────────────────────────────────────────────────────────────
let _wxAll      = [];       // full warranty list from server
let _wxFilter   = "All";    // active status filter
let _wxTypeFilter = "";     // source type filter: "" | "invoice" | "bill" | "payment" | "journal"
let _wxSearch   = "";
let _wxSortCol  = "warranty_expiry";
let _wxSortAsc  = true;

// ── Constants ─────────────────────────────────────────────────────────────────
const _WX_FILTERS      = ["All", "Active", "Expiring", "Expired", "Claimed"];
const _WX_TYPE_FILTERS = [
    { val: "",        label: "All Types" },
    { val: "invoice", label: "Invoice" },
    { val: "bill",    label: "Bill" },
    { val: "payment", label: "Payment" },
    { val: "journal", label: "Journal" },
];

// Mirrors CLAIM_OUTCOMES keys + labels from core/warranty.py
const _WX_OUTCOMES = {
    "replace":             "Replacement — new unit, new serial number",
    "refund":              "Full Refund — warranty voided, full amount back",
    "partial_refund":      "Partial Refund — partial amount returned, warranty voided",
    "partial_refund_keep": "Partial Refund — partial amount returned, warranty stays active",
    "repair":              "Repair / Service — item repaired, warranty continues",
    "exchange":            "Exchange — swapped for different model",
    "rejected":            "Claim Rejected — supplier declined, warranty still active",
    "rejected_void":       "Claim Rejected — voided (e.g. tampering, broken seal)",
    "withdraw":            "Withdraw Claim — cancel/undo a lodged claim",
};

// Outcomes that require new-warranty fields (replace / exchange)
const _WX_NEW_WARRANTY_OUTCOMES = new Set(["replace", "exchange"]);

// Outcomes that require a claim amount
const _WX_AMOUNT_OUTCOMES = new Set(["partial_refund", "partial_refund_keep"]);

// ── Entry point ───────────────────────────────────────────────────────────────
async function pageWarranties() {
    document.getElementById("module-content").innerHTML = `
        <div class="inv-toolbar">
            <input class="inv-search" id="wx-search" placeholder="Search warranties…" oninput="_wxOnSearch(this.value)">
            <div class="inv-filter-group" id="wx-filter-pills"></div>
            <div class="inv-filter-group" id="wx-type-pills"></div>
            <button class="btn btn-primary btn-sm" onclick="_wxNewWarranty()">+ Add Warranty</button>
        </div>

        <div class="inv-list-panel">
            <div class="tbl-overflow-x">
                <table class="inv-list-table" id="wx-table">
                    <thead>
                        <tr>
                            <th id="wx-th-item"    onclick="_wxSort('item_description')">Item / Description</th>
                            <th id="wx-th-serial"  onclick="_wxSort('serial_number')">Serial No.</th>
                            <th id="wx-th-prov"    onclick="_wxSort('provider')">Provider</th>
                            <th id="wx-th-contact" onclick="_wxSort('contact_name')">Contact</th>
                            <th id="wx-th-src"     onclick="_wxSort('source_ref')">Source</th>
                            <th id="wx-th-purch"   onclick="_wxSort('purchase_date')">Purchased</th>
                            <th id="wx-th-expiry"  onclick="_wxSort('warranty_expiry')" class="sort-asc">Expiry</th>
                            <th id="wx-th-status"  onclick="_wxSort('status_label')">Status</th>
                        </tr>
                    </thead>
                    <tbody id="wx-tbody"></tbody>
                </table>
            </div>
        </div>

        <div class="mt-8">
            <span class="count-pill" id="wx-count"></span>
        </div>

        <!-- Slide-over -->
        <div class="det-overlay" id="wx-overlay" onclick="wxDetClose()"></div>
        <div class="det-panel"   id="wx-panel">
            <div class="det-hdr">
                <span class="det-title" id="wx-det-title">Warranty</span>
                <button class="det-close" onclick="wxDetClose()">✕</button>
            </div>
            <div class="det-body" id="wx-body"></div>
            <div class="det-foot" id="wx-foot"></div>
        </div>
    `;

    _wxBuildFilterPills();
    _wxBuildTypePills();
    await _wxLoad();
}

// ── Filter pills ──────────────────────────────────────────────────────────────
function _wxBuildFilterPills() {
    const container = document.getElementById("wx-filter-pills");
    container.innerHTML = _WX_FILTERS.map(f => `
        <button class="filter-btn${f === _wxFilter ? " active" : ""}" onclick="_wxSetFilter('${f}')">${f}</button>
    `).join("");
}

function _wxBuildTypePills() {
    const container = document.getElementById("wx-type-pills");
    if (!container) return;
    container.innerHTML = _WX_TYPE_FILTERS.map(f => `
        <button class="filter-btn${f.val === _wxTypeFilter ? " active" : ""}" onclick="_wxSetTypeFilter('${f.val}')">${f.label}</button>
    `).join("");
}

function _wxSetFilter(f) {
    _wxFilter = f;
    _wxBuildFilterPills();
    _wxRender();
}

function _wxSetTypeFilter(val) {
    _wxTypeFilter = val;
    _wxBuildTypePills();
    _wxRender();
}

function _wxOnSearch(v) {
    _wxSearch = v.trim().toLowerCase();
    _wxRender();
}

// ── Data load ─────────────────────────────────────────────────────────────────
async function _wxLoad() {
    try {
        _wxAll = await apiFetch("/api/warranties");
    } catch (e) {
        document.getElementById("wx-tbody").innerHTML =
            `<tr><td colspan="8" class="tbl-empty-row">Failed to load warranties: ${_h(e.message)}</td></tr>`;
        return;
    }
    _wxRender();
}

// ── Render list ───────────────────────────────────────────────────────────────
function _wxRender() {
    const filterMap = {
        "All":      null,
        "Active":   "active",
        "Expiring": "expiring",
        "Expired":  "expired",
        "Claimed":  "claimed",
    };
    const filterKey = filterMap[_wxFilter];

    let rows = _wxAll.filter(w => {
        if (filterKey) {
            const label = (w.status_label || "").toLowerCase();
            if (filterKey === "active"   && !(label.includes("remaining") || label === "expires today")) return false;
            if (filterKey === "expiring" && !label.includes("expiring in")) return false;
            if (filterKey === "expired"  && !label.includes("expired")) return false;
            if (filterKey === "claimed"  && !(label.includes("replaced") || label.includes("refunded") ||
                                               label.includes("repair") || label.includes("rejected") ||
                                               label.includes("voided") || label.includes("exchanged") ||
                                               label.includes("partial"))) return false;
        }
        if (_wxTypeFilter && w.source_type !== _wxTypeFilter) return false;
        if (_wxSearch) {
            const haystack = [
                w.item_description, w.serial_number, w.provider,
                w.contact_name, w.source_ref, w.notes,
            ].join(" ").toLowerCase();
            if (!haystack.includes(_wxSearch)) return false;
        }
        return true;
    });

    // Sort
    rows = rows.slice().sort((a, b) => {
        let av = a[_wxSortCol] ?? "";
        let bv = b[_wxSortCol] ?? "";
        if (typeof av === "string") av = av.toLowerCase();
        if (typeof bv === "string") bv = bv.toLowerCase();
        if (av < bv) return _wxSortAsc ? -1 : 1;
        if (av > bv) return _wxSortAsc ? 1 : -1;
        return 0;
    });

    const tbody = document.getElementById("wx-tbody");
    if (!rows.length) {
        tbody.innerHTML = `<tr><td colspan="8" class="tbl-empty-row">No warranties found.</td></tr>`;
        document.getElementById("wx-count").textContent = "0 warranties";
        return;
    }

    tbody.innerHTML = rows.map(w => {
        const badge = _wxBadge(w);
        return `<tr class="inv-row" onclick="_wxOpenDetail(${w.id})">
            <td><span class="inv-contact">${_h(w.item_description || "—")}</span></td>
            <td><span class="inv-mono">${_h(w.serial_number || "—")}</span></td>
            <td>${_h(w.provider || "—")}</td>
            <td>${_h(w.contact_name || "—")}</td>
            <td><span class="td-ref">${_h(w.source_ref || "—")}</span></td>
            <td><span class="inv-mono">${fmtDate(w.purchase_date)}</span></td>
            <td><span class="inv-mono">${fmtDate(w.warranty_expiry)}</span></td>
            <td>${badge}</td>
        </tr>`;
    }).join("");

    const total = _wxAll.length;
    document.getElementById("wx-count").textContent =
        rows.length === total ? `${total} warranties` : `${rows.length} of ${total} warranties`;
}

// ── Sort ──────────────────────────────────────────────────────────────────────
function _wxSort(col) {
    if (_wxSortCol === col) {
        _wxSortAsc = !_wxSortAsc;
    } else {
        _wxSortCol = col;
        _wxSortAsc = true;
    }
    // Update th classes
    document.querySelectorAll("#wx-table th").forEach(th => th.classList.remove("sort-asc", "sort-desc"));
    const idMap = {
        item_description: "wx-th-item", serial_number: "wx-th-serial",
        provider: "wx-th-prov", contact_name: "wx-th-contact",
        source_ref: "wx-th-src", purchase_date: "wx-th-purch",
        warranty_expiry: "wx-th-expiry", status_label: "wx-th-status",
    };
    const thEl = document.getElementById(idMap[col]);
    if (thEl) thEl.classList.add(_wxSortAsc ? "sort-asc" : "sort-desc");
    _wxRender();
}

// ── Detail slide-over ─────────────────────────────────────────────────────────
async function _wxOpenDetail(id) {
    const w = _wxAll.find(x => x.id === id);
    if (!w) return;

    document.getElementById("wx-det-title").textContent = w.item_description || `Warranty #${id}`;
    document.getElementById("wx-overlay").classList.add("open");
    document.getElementById("wx-panel").classList.add("open");
    document.getElementById("wx-body").innerHTML = `<div class="state-loading">Loading…</div>`;
    document.getElementById("wx-foot").innerHTML = "";

    // Fetch full record
    let detail;
    try {
        detail = await apiFetch(`/api/warranties/${id}`);
    } catch (e) {
        document.getElementById("wx-body").innerHTML =
            `<div class="state-error">Failed to load: ${_h(e.message)}</div>`;
        return;
    }

    _wxRenderDetail(detail);
}

function _wxRenderDetail(w) {
    const claimSection = w.claim_status && w.claim_status !== "active"
        ? _wxRenderClaimSection(w)
        : "";

    const parentNote = w.parent_warranty_id
        ? `<div class="wx-parent-note">Replacement for warranty #${w.parent_warranty_id}</div>`
        : "";

    document.getElementById("wx-body").innerHTML = `
        <div class="det-meta">
            <div><div class="det-lbl">Item / Description</div><div class="det-val">${_h(w.item_description || "—")}</div></div>
            <div><div class="det-lbl">Status</div><div class="det-val">${_wxBadge(w)}</div></div>
            <div><div class="det-lbl">Serial Number</div><div class="det-val mono">${_h(w.serial_number || "—")}</div></div>
            <div><div class="det-lbl">Provider</div><div class="det-val">${_h(w.provider || "—")}</div></div>
            <div><div class="det-lbl">Purchase Date</div><div class="det-val mono">${fmtDate(w.purchase_date)}</div></div>
            <div><div class="det-lbl">Warranty Expiry</div><div class="det-val mono">${fmtDate(w.warranty_expiry)}</div></div>
            <div><div class="det-lbl">Source</div><div class="det-val col-ink3">${_h(w.source_type || "—")} ${_h(w.source_ref || "")}</div></div>
            <div><div class="det-lbl">Contact</div><div class="det-val">${_h(w.contact_name || "—")}</div></div>
        </div>
        ${parentNote}
        ${w.notes ? `<div class="det-section-title">Notes</div><div class="det-note">${_h(w.notes)}</div>` : ""}
        ${claimSection}
    `;

    // Footer buttons
    const foot = document.getElementById("wx-foot");
    foot.innerHTML = "";

    const isVoided = w.claim_status === "voided" || w.claim_status === "rejected_void";

    if (!isVoided) {
        const btnEdit = document.createElement("button");
        btnEdit.className = "btn btn-primary btn-sm";
        btnEdit.textContent = "✎ Edit";
        btnEdit.onclick = () => _wxEditWarranty(w.id);
        foot.appendChild(btnEdit);

        const btnClaim = document.createElement("button");
        btnClaim.className = "btn btn-amber btn-sm";
        btnClaim.textContent = "Lodge Claim…";
        btnClaim.onclick = () => _wxClaimDialog(w);
        foot.appendChild(btnClaim);
    }

    const btnDel = document.createElement("button");
    btnDel.className = "btn btn-danger btn-sm";
    btnDel.textContent = "Delete";
    btnDel.onclick = () => _wxDeleteDialog(w.id, w.item_description);
    foot.appendChild(btnDel);
}

function _wxRenderClaimSection(w) {
    const outcomeLabel = _WX_OUTCOMES[w.claim_outcome] || w.claim_outcome || "—";
    const amtLine = w.claim_amount != null
        ? `<div><div class="det-lbl">Claim Amount</div><div class="det-val mono">${_fmtAmt(w.claim_amount)}</div></div>`
        : "";
    const newLine = w.new_warranty_id
        ? `<div><div class="det-lbl">Replacement Warranty</div><div class="det-val"><a class="lnk-accent" href="#" onclick="_wxOpenDetail(${w.new_warranty_id});return false">Warranty #${w.new_warranty_id}</a></div></div>`
        : "";

    return `
        <div class="det-section-title">Claim Details</div>
        <div class="det-meta">
            <div><div class="det-lbl">Outcome</div><div class="det-val">${_h(outcomeLabel)}</div></div>
            <div><div class="det-lbl">Claim Date</div><div class="det-val mono">${fmtDate(w.claim_date)}</div></div>
            ${amtLine}
            ${newLine}
        </div>
        ${w.claim_notes ? `<div class="det-section-title">Claim Notes</div><div class="det-note">${_h(w.claim_notes)}</div>` : ""}
    `;
}

function wxDetClose() {
    document.getElementById("wx-overlay").classList.remove("open");
    document.getElementById("wx-panel").classList.remove("open");
}

// ── New / Edit form ───────────────────────────────────────────────────────────
function _wxNewWarranty() { _wxOpenForm(null); }

function _wxEditWarranty(id) {
    const w = _wxAll.find(x => x.id === id);
    if (w) _wxOpenForm(w);
}

async function _wxOpenForm(w) {
    const isEdit = !!w;
    document.getElementById("wx-det-title").textContent = isEdit ? "Edit Warranty" : "New Warranty";
    document.getElementById("wx-overlay").classList.add("open");
    document.getElementById("wx-panel").classList.add("open");
    document.getElementById("wx-body").innerHTML = `<div class="state-loading">Loading…</div>`;
    document.getElementById("wx-foot").innerHTML = "";

    // Load transaction picker options
    let txnOptions = [];
    try {
        txnOptions = await apiFetch("/api/warranties/txn_options");
    } catch (_) {}

    // If editing and the current source isn't in the recent 50, prepend it
    const curKey = w?.source_type && w?.source_id ? `${w.source_type}:${w.source_id}` : "";
    let hasCur = !curKey || txnOptions.some(o => o.key === curKey);
    if (!hasCur) {
        txnOptions = [
            { key: curKey, label: `${w.source_type.charAt(0).toUpperCase()+w.source_type.slice(1)} #${w.source_id} (current)` },
            ...txnOptions,
        ];
    }

    const txnSelect = `
        <select class="edt-sel" id="wxf-txn" onchange="_wxOnTxnChange()">
            <option value="">— None —</option>
            ${txnOptions.map(o =>
                `<option value="${_h(o.key)}"${o.key === curKey ? " selected" : ""}>${_h(o.label)}</option>`
            ).join("")}
        </select>`;

    document.getElementById("wx-body").innerHTML = `
        <div class="edt-section">
            <div class="edt-row">
                <div class="edt-field full">
                    <label class="edt-lbl">Item / Description *</label>
                    <input class="edt-inp" id="wxf-desc" type="text" value="${_h(w?.item_description || "")}">
                </div>
            </div>
            <div class="edt-row">
                <div class="edt-field">
                    <label class="edt-lbl">Serial Number</label>
                    <input class="edt-inp" id="wxf-serial" type="text" value="${_h(w?.serial_number || "")}">
                </div>
                <div class="edt-field">
                    <label class="edt-lbl">Provider / Supplier</label>
                    <input class="edt-inp" id="wxf-provider" type="text" value="${_h(w?.provider || "")}">
                </div>
            </div>
            <div class="edt-row">
                <div class="edt-field">
                    <label class="edt-lbl">Purchase Date</label>
                    <input class="edt-inp" id="wxf-purchase" type="date" value="${w?.purchase_date || ""}">
                </div>
                <div class="edt-field">
                    <label class="edt-lbl">Warranty Expiry *</label>
                    <input class="edt-inp" id="wxf-expiry" type="date" value="${w?.warranty_expiry || ""}">
                </div>
            </div>
            <div class="edt-row">
                <div class="edt-field full">
                    <label class="edt-lbl">Linked Transaction</label>
                    ${txnSelect}
                </div>
            </div>
            <div class="edt-divider"></div>
            <div class="edt-row">
                <div class="edt-field full">
                    <label class="edt-lbl">Notes</label>
                    <textarea class="edt-ta edt-ta-resize" id="wxf-notes">${_h(w?.notes || "")}</textarea>
                </div>
            </div>
            <div class="edt-divider"></div>
            <div id="wxf-attach-section"></div>
        </div>
    `;

    const foot = document.getElementById("wx-foot");
    foot.innerHTML = "";

    const btnCancel = document.createElement("button");
    btnCancel.className = "btn btn-outline btn-sm";
    btnCancel.textContent = "Cancel";
    btnCancel.onclick = isEdit ? () => _wxOpenDetail(w.id) : () => wxDetClose();
    foot.appendChild(btnCancel);

    const btnSave = document.createElement("button");
    btnSave.className = "btn btn-primary btn-sm";
    btnSave.textContent = "✓ Save";
    btnSave.onclick = () => _wxSaveForm(isEdit ? w.id : null);
    foot.appendChild(btnSave);

    // Load attachment section for current source
    const [initSrcType, initSrcId] = _wxTxnKeyParts();
    _wxLoadAttachments(initSrcType, initSrcId, isEdit ? w.id : null);
}

// ── Attachment linking helpers ────────────────────────────────────────────────
function _wxTxnKeyParts() {
    const key = document.getElementById("wxf-txn")?.value || "";
    if (!key) return ["", 0];
    const sep = key.indexOf(":");
    return [key.slice(0, sep), parseInt(key.slice(sep + 1)) || 0];
}

function _wxOnTxnChange() {
    const [srcType, srcId] = _wxTxnKeyParts();
    _wxLoadAttachments(srcType, srcId, null);
}

async function _wxLoadAttachments(srcType, srcId, warrantyId) {
    const sec = document.getElementById("wxf-attach-section");
    if (!sec) return;

    if (!srcType || !srcId) {
        sec.innerHTML = `<p class="edt-hint">Select a linked transaction to see its attachments.</p>`;
        return;
    }

    sec.innerHTML = `<p class="edt-hint">Loading attachments…</p>`;

    let attachments = [], linkedIds = new Set();
    try { attachments = await apiFetch(`/api/attachments/${srcType}/${srcId}`); } catch (_) {}
    if (warrantyId) {
        try {
            const ids = await apiFetch(`/api/warranties/${warrantyId}/linked_attachments`);
            linkedIds = new Set(ids);
        } catch (_) {}
    }

    if (!attachments.length) {
        sec.innerHTML = `<p class="edt-hint">No files attached to this transaction. Open it and attach the receipt there first, then link it here.</p>`;
        return;
    }

    const rows = attachments.map(a => `
        <label class="wx-attach-row">
            <input type="checkbox" class="wxf-att-cb" value="${a.id}"${linkedIds.has(a.id) ? " checked" : ""}>
            <span class="wx-attach-name">${_h(a.filename)}</span>
            <span class="wx-attach-size">${a.file_size ? Math.round(a.file_size / 1024) + " KB" : ""}</span>
        </label>`).join("");

    sec.innerHTML = `
        <div class="edt-lbl edt-lbl-mb6">Receipt &amp; Documents</div>
        <div class="wx-attach-list">${rows}</div>
        <p class="edt-hint">Tick to link files from the transaction. No duplicate storage.</p>`;
}

async function _wxSaveForm(warrantyId) {
    const desc   = document.getElementById("wxf-desc").value.trim();
    const expiry = document.getElementById("wxf-expiry").value;
    const txnKey = document.getElementById("wxf-txn").value;  // "type:id" or ""

    if (!desc)   { toast("Item description is required.", 'err'); return; }
    if (!expiry) { toast("Warranty expiry date is required.", 'err'); return; }

    let srcType = "invoice", srcId = 0;
    if (txnKey) {
        const sep = txnKey.indexOf(":");
        srcType = txnKey.slice(0, sep);
        srcId   = parseInt(txnKey.slice(sep + 1)) || 0;
    }

    const payload = {
        item_description: desc,
        serial_number:    document.getElementById("wxf-serial").value.trim(),
        provider:         document.getElementById("wxf-provider").value.trim(),
        purchase_date:    document.getElementById("wxf-purchase").value || null,
        warranty_expiry:  expiry,
        source_type:      srcType,
        source_id:        srcId,
        notes:            document.getElementById("wxf-notes").value.trim(),
        warranty_id:      warrantyId || null,
    };

    try {
        const r = await fetch("/api/warranties", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });
        const d = await r.json();
        if (!d.ok) { toast(d.error || "Save failed.", 'err'); return; }

        // Persist attachment links
        const finalId = warrantyId || d.data?.id;
        if (finalId) {
            const checkedIds = [...document.querySelectorAll(".wxf-att-cb:checked")]
                .map(cb => parseInt(cb.value));
            try {
                await fetch(`/api/warranties/${finalId}/linked_attachments`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ attachment_ids: checkedIds }),
                });
            } catch (_) {}
        }

        toast(warrantyId ? "Warranty updated." : "Warranty created.");
        await _wxLoad();
        // Reopen detail if edit, close if new
        if (warrantyId) {
            const updated = _wxAll.find(x => x.id === warrantyId);
            if (updated) _wxRenderDetail(updated);
        } else {
            const newId = d.data?.id;
            if (newId) {
                const created = _wxAll.find(x => x.id === newId);
                if (created) _wxOpenDetail(newId);
            } else {
                wxDetClose();
            }
        }
    } catch (e) {
        toast("Save failed: " + e.message, 'err');
    }
}

// ── Lodge Claim modal ─────────────────────────────────────────────────────────
function _wxClaimDialog(w) {
    const bd = document.createElement("div");
    bd.className = "modal-bd";
    bd.style.display = "flex";
    bd.id = "wx-claim-modal";

    bd.innerHTML = `
        <div class="modal-box modal-580 modal-tall">
            <div class="modal-hdr"><span>Lodge Warranty Claim — ${_h(w.item_description)}</span></div>
            <div class="modal-body modal-body-scroll">
                <div class="form-grid">
                    <div class="form-field">
                        <label class="form-lbl">Outcome *</label>
                        <select class="form-input" id="wxc-outcome" onchange="_wxClaimOutcomeChange()">
                            <option value="">— Select outcome —</option>
                            ${Object.entries(_WX_OUTCOMES).map(([k, v]) =>
                                `<option value="${k}">${v}</option>`
                            ).join("")}
                        </select>
                    </div>
                    <div class="form-field">
                        <label class="form-lbl">Claim Date *</label>
                        <input class="form-input" id="wxc-date" type="date" value="${isoToday()}">
                    </div>
                </div>

                <!-- Claim amount (shown for partial refund outcomes) -->
                <div class="form-grid" id="wxc-amount-row" style="display:none">
                    <div class="form-field">
                        <label class="form-lbl">Claim Amount</label>
                        <input class="form-input" id="wxc-amount" type="number" min="0" step="0.01" placeholder="0.00">
                    </div>
                </div>

                <!-- New warranty fields (shown for replace / exchange) -->
                <div id="wxc-new-warranty-section" style="display:none">
                    <div class="edt-divider edt-divider-mv"></div>
                    <div class="det-section-title det-sec-mb10">Replacement Warranty Details</div>
                    <div class="form-grid">
                        <div class="form-field">
                            <label class="form-lbl">New Item Description</label>
                            <input class="form-input" id="wxc-new-desc" type="text" placeholder="${_h(w.item_description)}">
                        </div>
                        <div class="form-field">
                            <label class="form-lbl">New Serial Number</label>
                            <input class="form-input" id="wxc-new-serial" type="text">
                        </div>
                    </div>
                    <div class="form-grid">
                        <div class="form-field">
                            <label class="form-lbl">New Expiry Date</label>
                            <input class="form-input" id="wxc-new-expiry" type="date" value="${w.warranty_expiry || ""}">
                        </div>
                        <div class="form-field">
                            <label class="form-lbl">Notes for replacement</label>
                            <input class="form-input" id="wxc-new-notes" type="text">
                        </div>
                    </div>
                </div>

                <div class="form-grid form-grid-1 form-grid-mt">
                    <div class="form-field">
                        <label class="form-lbl">Claim Notes</label>
                        <textarea class="form-input edt-ta-resize" id="wxc-notes" rows="3"></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-foot">
                <button class="btn btn-outline btn-sm" onclick="document.getElementById('wx-claim-modal').remove()">Cancel</button>
                <button class="btn btn-amber btn-sm" onclick="_wxSubmitClaim(${w.id})">Lodge Claim</button>
            </div>
        </div>
    `;
    document.body.appendChild(bd);
}

function _wxClaimOutcomeChange() {
    const outcome = document.getElementById("wxc-outcome").value;
    const amountRow = document.getElementById("wxc-amount-row");
    const newSection = document.getElementById("wxc-new-warranty-section");
    amountRow.style.display  = _WX_AMOUNT_OUTCOMES.has(outcome) ? "" : "none";
    newSection.style.display = _WX_NEW_WARRANTY_OUTCOMES.has(outcome) ? "" : "none";
}

async function _wxSubmitClaim(warrantyId) {
    const outcome = document.getElementById("wxc-outcome").value;
    const claimDate = document.getElementById("wxc-date").value;

    if (!outcome)   { toast("Please select a claim outcome.", 'err'); return; }
    if (!claimDate) { toast("Claim date is required.", 'err'); return; }

    const payload = {
        outcome,
        claim_date:  claimDate,
        claim_notes: document.getElementById("wxc-notes").value.trim(),
        claim_amount: _WX_AMOUNT_OUTCOMES.has(outcome)
            ? (parseFloat(document.getElementById("wxc-amount").value) || null)
            : null,
        new_serial:           _WX_NEW_WARRANTY_OUTCOMES.has(outcome) ? document.getElementById("wxc-new-serial").value.trim() : "",
        new_item_description: _WX_NEW_WARRANTY_OUTCOMES.has(outcome) ? document.getElementById("wxc-new-desc").value.trim() : "",
        new_expiry:           _WX_NEW_WARRANTY_OUTCOMES.has(outcome) ? document.getElementById("wxc-new-expiry").value : "",
        new_notes:            _WX_NEW_WARRANTY_OUTCOMES.has(outcome) ? document.getElementById("wxc-new-notes").value.trim() : "",
    };

    try {
        const r = await fetch(`/api/warranties/${warrantyId}/claim`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });
        const d = await r.json();
        if (!d.ok) { toast(d.error || "Failed to lodge claim.", 'err'); return; }

        document.getElementById("wx-claim-modal").remove();
        toast("Claim lodged.");
        await _wxLoad();
        // Reopen detail with refreshed data
        const updated = _wxAll.find(x => x.id === warrantyId);
        if (updated) {
            document.getElementById("wx-det-title").textContent = updated.item_description || `Warranty #${warrantyId}`;
            // Fetch full detail
            try {
                const detail = await apiFetch(`/api/warranties/${warrantyId}`);
                _wxRenderDetail(detail);
            } catch (_) {}
        }
    } catch (e) {
        toast("Failed to lodge claim: " + e.message, 'err');
    }
}

// ── Delete ────────────────────────────────────────────────────────────────────
function _wxDeleteDialog(id, desc) {
    const bd = document.createElement("div");
    bd.className = "modal-bd";
    bd.style.display = "flex";
    bd.innerHTML = `
        <div class="modal-box modal-xs-tight">
            <div class="modal-hdr"><span>Delete Warranty</span></div>
            <div class="modal-body">
                <p class="modal-del-q">Delete warranty for <strong>${_h(desc || `#${id}`)}</strong>?</p>
                <p class="col-ink3 modal-del-hint">This cannot be undone. Any linked attachments will also be removed.</p>
            </div>
            <div class="modal-foot">
                <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
                <button class="btn btn-danger btn-sm" onclick="_wxConfirmDelete(${id}, this.closest('.modal-bd'))">Delete</button>
            </div>
        </div>
    `;
    document.body.appendChild(bd);
}

async function _wxConfirmDelete(id, modalEl) {
    try {
        const r = await fetch(`/api/warranties/${id}`, { method: "DELETE" });
        const d = await r.json();
        if (!d.ok) { toast(d.error || "Delete failed.", 'err'); return; }
        modalEl.remove();
        wxDetClose();
        toast("Warranty deleted.");
        await _wxLoad();
    } catch (e) {
        toast("Delete failed: " + e.message, 'err');
    }
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function _wxBadge(w) {
    const label = w.status_label || "";
    const lower = label.toLowerCase();
    if (lower.includes("expired") && !lower.includes("expiring"))  return `<span class="badge badge-overdue">${_h(label)}</span>`;
    if (lower.includes("expiring") || lower.includes("expires today")) return `<span class="badge badge-pending">${_h(label)}</span>`;
    if (lower.includes("remaining"))                                return `<span class="badge badge-paid">${_h(label)}</span>`;
    if (lower.includes("repair") || lower.includes("rejected"))    return `<span class="badge badge-sent">${_h(label)}</span>`;
    // Voided / claimed outcomes
    return `<span class="badge badge-draft">${_h(label)}</span>`;
}

function _fmtAmt(v) {
    if (v == null || v === "") return "—";
    return "$" + Number(v).toLocaleString("en-AU", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function _h(s) {
    if (s == null) return "";
    return String(s)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}
