// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ── Supplier Payment Run state ────────────────────────────────────────────────
let _sprCandidates = [];       // rows from /api/bills/payment-run/candidates
let _sprSelected   = new Set();// selected bill_ids (integers)
let _sprBanks      = [];       // bank accounts for From Bank dropdown
let _sprPosting    = false;
let _billGSTReg    = null;     // null = not yet loaded; true/false from company.gst_registered
let _ccAccts       = [];       // credit card accounts for bill payment dropdown

async function pageBills() {
  if (_billGSTReg === null) {
    try { const me = await apiFetch('/api/me'); _billGSTReg = me ? me.gst_registered !== 0 : true; }
    catch(e) { _billGSTReg = true; }
  }
  try {
    const [bills,accts]=await Promise.all([apiFetch('/api/bills'),apiFetch('/api/accounts')]);
    _billAll=bills||[]; _bankAccts=(accts||[]).filter(a=>a.is_bank); _ccAccts=(accts||[]).filter(a=>a.is_credit_card);
    renderBillsPage();
  } catch(e){
    document.getElementById('module-content').innerHTML=`<div class="state-error">Failed to load bills: ${esc(e.message)}</div>`;
  }
}

function _billFiltered() {
  const q=_billSearch.toLowerCase();
  return _billAll.filter(b=>{
    if(_billFilter!=='All'&&_billEffSt(b)!==_billFilter) return false;
    if(q&&![b.bill_number,b.contact_name,b.status].some(v=>(v||'').toLowerCase().includes(q))) return false;
    return true;
  }).sort((a,c)=>{
    const col=_billSort.col,av=a[col]??'',bv=c[col]??'';
    return(typeof av==='number'?(av-bv):String(av).localeCompare(String(bv)))*_billSort.dir;
  });
}

function renderBillsPage(restoreFocus) {
  const rows=_billFiltered();
  const counts=Object.fromEntries(BILL_STATS.map(s=>[s,0]));
  counts['All']=_billAll.length;
  _billAll.forEach(b=>{const s=_billEffSt(b);if(s in counts)counts[s]++;});
  const mc=document.getElementById('module-content');
  mc.innerHTML=`
    <div class="inv-toolbar">
      <input class="inv-search" id="bill-q" placeholder="Search number, supplier\u2026" value="${esc(_billSearch)}">
      <div class="inv-filter-group">
        ${BILL_STATS.map(s=>`<button class="filter-btn${_billFilter===s?' active':''}" onclick="billFilter('${s}')">
          ${s}${counts[s]?` <span class="filter-count">(${counts[s]})</span>`:''}</button>`).join('')}
      </div>
      <button class="btn btn-primary" onclick="billNew()">+ New Bill</button>
      <button class="btn btn-outline" onclick="_billFromTemplate()">From Template</button>
      <button class="btn btn-outline" onclick="sprOpen()" title="Batch-pay multiple bills and optionally generate an ABA file">💳 Payment Run</button>
      <button class="btn btn-outline" onclick="abaExportOpen()" title="Generate ABA direct-entry file from posted payments">📥 ABA Export</button>
    </div>
    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        ${billTh('bill_number','#')}${billTh('contact_name','Supplier')}
        ${billTh('bill_date','Date')}${billTh('due_date','Due')}
        ${billTh('total','Total','r')}${billTh('amount_paid','Paid','r')}
        <th class="th-r">Balance</th>${billTh('status','Status')}
      </tr></thead><tbody>
        ${rows.length?rows.map(billRow).join(''):`<tr class="tbl-empty-row"><td colspan="8">No bills match your filter</td></tr>`}
      </tbody></table>
    </div></div>
    <div class="mt-8"><span class="count-pill">${rows.length} of ${_billAll.length} bill${_billAll.length!==1?'s':''}</span></div>`;
  const q=document.getElementById('bill-q');
  if(q){
    q.addEventListener('input',e=>{_billSearch=e.target.value;renderBillsPage(true);});
    if(restoreFocus){q.focus();q.setSelectionRange(q.value.length,q.value.length);}
  }
}

function billTh(col,label,align) {
  const cls=_billSort.col===col?(_billSort.dir>0?'sort-asc':'sort-desc'):'';
  const st=align==='r'?' class="th-r"':'';
  return `<th class="${cls}"${st} onclick="billSort('${col}')">${label}</th>`;
}

function billRow(b) {
  const bal=(b.total||0)-(b.amount_paid||0),eff=_billEffSt(b);
  const rc=eff==='Void'?'is-void':eff==='Paid'?'is-paid':eff==='Overdue'?'is-overdue':'';
  return `<tr class="inv-row ${rc}" onclick="billOpen(${b.id})">
    <td><span class="inv-mono">${esc(b.bill_number||'#'+b.id)}</span></td>
    <td><span class="inv-contact">${esc(b.contact_name||'\u2014')}</span></td>
    <td><span class="inv-mono">${fmtDate(b.bill_date)}</span></td>
    <td><span class="inv-mono">${fmtDate(b.due_date)}${eff==='Overdue'?' <span class="overdue-tag">OVERDUE</span>':''}</span></td>
    <td class="inv-amt">${fmt(b.total)}</td>
    <td class="inv-amt inv-amt-paid">${(b.amount_paid||0)>0?fmt(b.amount_paid):'\u2014'}</td>
    <td class="inv-amt ${bal>0.005?'inv-amt-amber':'inv-amt-green'}">${fmt(bal)}</td>
    <td><span class="badge ${BILL_BADGE[eff]||'badge-draft'}">${eff}</span></td>
  </tr>`;
}

function billSort(col){_billSort={col,dir:_billSort.col===col?_billSort.dir*-1:1};renderBillsPage();}
function billFilter(f){_billFilter=f;renderBillsPage();}

async function billOpen(id) {
  _billSelected=id;
  _rcptLoadedFor=null;
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-body').innerHTML='<div class="state-loading">Loading\u2026</div>';
  document.getElementById('det-foot').innerHTML='';
  document.getElementById('det-title').textContent='Bill';
  try{const data=await apiFetch(`/api/bills/${id}`);renderBillDetail(data);}
  catch(e){document.getElementById('det-body').innerHTML=`<div class="state-error">${esc(e.message)}</div>`;}
}

function renderBillDetail(data) {
  _rcptLoadedFor=null;
  const b=data.bill,lines=data.lines||[],bal=(b.total||0)-(b.amount_paid||0),eff=_billEffSt(b);
  document.getElementById('det-title').textContent=`Bill ${b.bill_number||'#'+b.id}`;
  const TABS=[['lines','\uD83D\uDCCB Lines'],['notes','\uD83D\uDCDD Notes'],['comments','\uD83D\uDD12 Comments'],['receipts','\uD83D\uDCE6 Receipts'],['attachments','\uD83D\uDCCE Attachments']];
  document.getElementById('det-body').innerHTML=`
    <div class="det-meta">
      <div><div class="det-lbl">Supplier</div><div class="det-val">${esc(b.contact_name||'\u2014')}</div></div>
      <div><div class="det-lbl">Status</div><div class="det-val"><span class="badge ${BILL_BADGE[eff]||'badge-draft'}">${eff}</span></div></div>
      <div><div class="det-lbl">Bill Date</div><div class="det-val mono">${fmtDate(b.bill_date)}</div></div>
      <div><div class="det-lbl">Due Date</div><div class="det-val mono">${fmtDate(b.due_date)}${eff==='Overdue'?' <span class="overdue-tag overdue-tag-lg">OVERDUE</span>':''}</div></div>
      <div><div class="det-lbl">Total</div><div class="det-val mono det-val-lg det-val-accent">${fmt(b.total)}</div></div>
      <div><div class="det-lbl">Balance</div><div class="det-val mono det-val-lg ${bal>0.005?'det-val-bal-amber':'det-val-bal-green'}">${fmt(bal)}</div></div>
      ${b.job_name?`<div><div class="det-lbl">Job / Project</div><div class="det-val"><span class="lnk-accent" style="cursor:pointer" onclick="navigate('jobs')">${esc(b.job_name)}</span></div></div>`:''}
      ${b.po_number?`<div><div class="det-lbl">Purchase Order</div><div class="det-val"><span class="lnk-accent" style="cursor:pointer" onclick="navigate('purchase_orders');setTimeout(()=>_poOpenDet(${b.po_id}),400)">${esc(b.po_number)}</span></div></div>`:''}
    </div>
    <div class="det-tabs">${TABS.map(([k,l],i)=>`<div class="det-tab${i===0?' active':''}" data-tab="${k}" onclick="billTab('${k}')">${l}</div>`).join('')}</div>
    <div class="det-pane active" id="bilt-lines">
      <table class="det-lines"><thead><tr><th>Description</th><th>Qty</th>
        <th class="th-r">Unit</th><th class="th-r">GST</th><th class="th-r">Total</th>
      </tr></thead><tbody>${lines.length?lines.map(l=>{
        const q=parseFloat(l.quantity)||0,p=parseFloat(l.unit_price)||0;
        const rate=(l.tax_code==='GST'||l.tax_code==='CAP')?0.1:0,gst=Math.round(q*p*rate*100)/100;
        return `<tr><td>${esc(l.description)}<span class="det-line-tax">${l.tax_code||'GST'}</span>${l.account_name?`<span class="line-acct-name">${esc(l.account_name)}</span>`:''}</td>
          <td class="td-c-mono">${q}</td>
          <td class="td-r-mono">${fmt(p)}</td>
          <td class="td-r-mono">${fmt(gst)}</td>
          <td class="td-r-mono-bold">${fmt(q*p+gst)}</td></tr>`;
      }).join(''):`<tr class="tbl-empty-sm"><td colspan="5">No line items</td></tr>`}
      </tbody></table>
      <div class="det-totals">
        <div class="det-tot-row"><span>Subtotal (ex GST)</span><span>${fmt(b.subtotal)}</span></div>
        <div class="det-tot-row"><span>GST (10%)</span><span>${fmt(b.gst_total)}</span></div>
        ${(b.amount_paid||0)>0?`<div class="det-tot-row det-tot-row-paid"><span>Paid</span><span>${fmt(b.amount_paid)}</span></div>`:''}
        <div class="det-tot-row grand"><span>Total</span><span>${fmt(b.total)}</span></div>
      </div>
    </div>
    <div class="det-pane" id="bilt-notes">${b.notes?`<div class="det-note">${esc(b.notes)}</div>`:`<div class="det-empty">No notes.</div>`}</div>
    <div class="det-pane" id="bilt-comments">${b.internal_comments?`<div class="det-note">${esc(b.internal_comments)}</div>`:`<div class="det-empty">No internal comments.</div>`}</div>
    <div class="det-pane" id="bilt-receipts"><div class="det-empty det-loading-pad">Loading…</div></div>
    <div class="det-pane" id="bilt-attachments"><div class="det-empty det-loading-pad">Loading…</div></div>`;

  const foot=document.getElementById('det-foot'); foot.innerHTML='';
  const addBtn=(label,cls,fn)=>{const btn=document.createElement('button');btn.className=`btn ${cls}`;btn.textContent=label;btn.onclick=fn;foot.appendChild(btn);};
  if(['Draft','Approved'].includes(b.status))           addBtn('\u270F\uFE0F Edit','btn-outline',()=>billEditOpen(data));
  if(b.status==='Draft')                                addBtn('\u2713 Approve','btn-green',()=>billMarkApproved(b.id));
  if(b.status!=='Void'&&b.status!=='Paid'&&bal>0.005)  addBtn('\uD83D\uDCB0 Record Payment','btn-green',()=>billPayModalOpen(b));
  if(!['Void','Paid'].includes(b.status))               addBtn('Void','btn-danger',()=>billVoid(b.id));
  if(['Approved','Overdue'].includes(eff))              addBtn('\uD83D\uDCE6 Receive Stock','btn-outline',()=>_rcptNew(b.id,lines));
  addBtn('\uD83D\uDCE7 Email','btn-outline',()=>billEmailOpen(b));
  addBtn('\u2399 Download PDF','btn-outline',()=>window.open(`/api/bills/${b.id}/pdf`));
  addBtn('\u29c9 Copy','btn-outline',()=>billCopy(b.id));
  addBtn('+ New Bill','btn-outline',billNew);
}

// Track which bill's receipts have been loaded so we only fetch once per open
let _rcptLoadedFor = null;

function billTab(key){
  document.querySelectorAll('.det-tab').forEach(t=>t.classList.toggle('active',t.dataset.tab===key));
  document.querySelectorAll('.det-pane').forEach(p=>p.classList.toggle('active',p.id===`bilt-${key}`));
  if(key==='receipts'&&_billSelected&&_rcptLoadedFor!==_billSelected){
    _rcptLoadedFor=_billSelected;
    _rcptLoadPane(_billSelected);
  }
  if(key==='attachments'&&_billSelected&&(!_attLoadedFor||_attLoadedFor.type!=='bill'||_attLoadedFor.id!==_billSelected)){
    _attLoad('bilt-attachments','bill',_billSelected);
  }
}

function billDetClose(){document.getElementById('det-overlay').classList.remove('open');document.getElementById('det-panel').classList.remove('open');_billSelected=null;}

async function billMarkApproved(id){
  try{const r=await fetch(`/api/bills/${id}/mark-approved`,{method:'POST',credentials:'include'});const j=await r.json();if(!j.ok)throw new Error(j.error);toast('Bill approved');await _billRefresh(id);}
  catch(e){toast(e.message,'err');}
}
async function billCopy(id) {
  try {
    const r = await fetch(`/api/bills/${id}/copy`, {method:'POST', credentials:'include'});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Copy failed');
    toast('Copied as new draft bill');
    _billAll = (await apiFetch('/api/bills')) || [];
    renderBillsPage();
    billOpen(j.data.id);
  } catch(e) { toast(e.message, 'err'); }
}

async function billVoid(id){
  if(!await confirmDlg('Void this bill? This reverses the journal entries and cannot be undone.')) return;
  try{const r=await fetch(`/api/bills/${id}/void`,{method:'POST',credentials:'include'});const j=await r.json();if(!j.ok)throw new Error(j.error);toast('Bill voided');billDetClose();_billAll=(await apiFetch('/api/bills'))||[];renderBillsPage();}
  catch(e){toast(e.message,'err');}
}
async function _billRefresh(id){
  _billAll=(await apiFetch('/api/bills'))||[];renderBillsPage();
  if(_billSelected===id){try{renderBillDetail(await apiFetch(`/api/bills/${id}`));}catch(e){}}
}

async function billEmailOpen(b) {
  const num=b.bill_number||('#'+b.id);
  const bd=document.createElement('div');
  bd.className='modal-bd'; bd.style.display='flex';
  bd.innerHTML=`<div class="modal-box" style="width:min(560px,96vw)">
    <div class="modal-title">Email Bill ${esc(num)}</div>
    <div class="modal-field"><label class="modal-lbl">To *</label>
      <input class="modal-inp" type="email" id="eml-to" placeholder="supplier@example.com"></div>
    <div class="modal-field"><label class="modal-lbl">Subject</label>
      <input class="modal-inp" type="text" id="eml-subj" value="${esc('Bill '+num)}"></div>
    <div class="modal-field"><label class="modal-lbl">Message</label>
      <textarea class="modal-inp" id="eml-body" rows="5" style="resize:vertical;min-height:90px"></textarea></div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary btn-sm" id="eml-send-btn" onclick="_billDoEmail(${b.id})">📧 Send</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  try {
    const contact=await apiFetch(`/api/contacts/${b.contact_id}`);
    if(contact?.email) document.getElementById('eml-to').value=contact.email;
    document.getElementById('eml-body').value=
      `Please find attached bill ${num} for ${fmt(b.total)}.\n\nRegards`;
  } catch(e){}
}

async function _billDoEmail(id) {
  const to=(document.getElementById('eml-to')?.value||'').trim();
  if(!to){toast('Recipient email is required','err');return;}
  const btn=document.getElementById('eml-send-btn');
  btn.disabled=true; btn.textContent='Sending…';
  try {
    const r=await fetch(`/api/bills/${id}/email`,{method:'POST',credentials:'include',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({to,subject:document.getElementById('eml-subj')?.value||'',
        body:document.getElementById('eml-body')?.value||''})});
    const j=await r.json();
    if(!j.ok) throw new Error(j.error||'Send failed');
    btn.closest('.modal-bd')?.remove();
    toast('Bill emailed');
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent='📧 Send';
  }
}

// ── Bill pay modal (reuses the same modal HTML, with bill context) ────────────
let _bpmId=null, _bpmBill=null;
function billPayModalOpen(b){
  _bpmId=b.id; _bpmBill=b;
  const bal=(b.total||0)-(b.amount_paid||0);
  document.getElementById('pm-amount').value=bal.toFixed(2);
  document.getElementById('pm-date').value=isoToday();
  document.getElementById('pm-method').value='EFT';
  document.getElementById('pm-ref').value='';
  document.getElementById('pm-account').innerHTML=(_bankAccts.length||_ccAccts.length)
    ?((_bankAccts.length?`<optgroup label="Bank Accounts">${_bankAccts.map(a=>`<option value="${a.id}">${esc((a.code||'')+' '+a.name)}</option>`).join('')}</optgroup>`:'')
      +(_ccAccts.length?`<optgroup label="Credit Cards">${_ccAccts.map(a=>`<option value="${a.id}">${esc((a.code||'')+' '+a.name)}</option>`).join('')}</optgroup>`:''))
    :'<option value="">— No payment accounts —</option>';
  // Retitle modal for bills context
  document.querySelector('#pay-modal .modal-title').textContent='Record Supplier Payment';
  document.getElementById('pm-save').onclick=billPaySave;
  document.getElementById('pay-modal').classList.add('open');
}
async function billPaySave(){
  const amount=parseFloat(document.getElementById('pm-amount').value);
  if(!amount||amount<=0){toast('Enter a valid amount','err');return;}
  const btn=document.getElementById('pm-save');btn.disabled=true;btn.textContent='Saving\u2026';
  try{
    const r=await fetch(`/api/bills/${_bpmId}/payment`,{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',
      body:JSON.stringify({amount,payment_date:document.getElementById('pm-date').value,
        reference:document.getElementById('pm-ref').value,account_id:parseInt(document.getElementById('pm-account').value)||null})});
    const j=await r.json();if(!j.ok)throw new Error(j.error);
    toast('Payment recorded');
    // Reset modal title for invoices
    document.querySelector('#pay-modal .modal-title').textContent='Record Payment';
    document.getElementById('pm-save').onclick=paySave;
    payModalClose();
    await _billRefresh(_bpmId);
  }catch(e){toast(e.message,'err');}
  finally{btn.disabled=false;btn.textContent='Save Payment';}
}

// ── Bill inline editor ────────────────────────────────────────────────────
let _billEditData=null, _billEditLines=[], _billEditContacts=null, _billEditAccts=[], _billEditJobs=null;

async function billNew(opts={}){
  const td=isoToday();
  const due=isoAddDays(30);
  const blank={bill:{id:null,contact_id:opts.contact_id||null,opp_id:opts.opp_id||null,job_id:opts.job_id||null,bill_date:td,due_date:due,status:'Draft',
    bill_number:'',notes:'',internal_comments:'',subtotal:0,gst_total:0,total:0,amount_paid:0},lines:[]};
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent='New Bill';
  await billEditOpen(blank);
}

async function billEditOpen(data) {
  _billEditData=data;
  const _defTax = _billGSTReg ? 'GST' : 'INP';
  _billEditLines=(data.lines||[]).map(l=>({
    description:l.description||'',quantity:parseFloat(l.quantity)||1,
    unit_price:parseFloat(l.unit_price)||0,tax_code:l.tax_code||_defTax,account_id:l.account_id||null,item_id:l.item_id||null,
  }));
  if(_billEditLines.length===0) _billEditLines.push({description:'',quantity:1,unit_price:0,tax_code:_defTax,account_id:null,item_id:null});
  try{
    const [contacts,accts,jobs]=await Promise.all([
      _billEditContacts?Promise.resolve(_billEditContacts):apiFetch('/api/contacts'),
      _billEditAccts.length?Promise.resolve(_billEditAccts):apiFetch('/api/accounts'),
      _billEditJobs?Promise.resolve(_billEditJobs):apiFetch('/api/jobs'),
    ]);
    _billEditContacts=contacts||[];
    _billEditAccts=(accts||[]).filter(a=>['Expense','Asset','Equity'].includes(a.account_type));
    if(_billEditAccts.length===0) _billEditAccts=(accts||[]).filter(a=>a.account_type);
    _billEditJobs=jobs||[];
  }catch(e){toast('Could not load contacts/accounts: '+e.message,'err');return;}
  billEditRender();
}

async function _billNewContact() {
  const c = await quickNewContact('Supplier');
  if (!c) return;
  if (_billEditContacts) _billEditContacts.push(c);
  const sel = document.getElementById('bedt-contact');
  if (sel) sel.appendChild(new Option(c.name, c.id, true, true));
}

function billEditRender() {
  const b=_billEditData.bill;
  const suppOpts=(_billEditContacts||[])
    .filter(c=>c.contact_type==='Supplier'||c.contact_type==='Both'||!c.contact_type)
    .map(c=>`<option value="${c.id}" ${c.id===b.contact_id?'selected':''}>${esc(c.name)}</option>`)
    .join('');
  const jobOpts=(_billEditJobs||[]).map(j=>`<option value="${j.id}" ${j.id===b.job_id?'selected':''}>${esc((j.job_number?j.job_number+'  ':'')+j.name)}</option>`).join('');
  const linesHtml=_billEditLines.map((l,i)=>_billLineHtml(i,l)).join('');
  const {sub,gst,total}=_billEditTotals();

  document.getElementById('det-body').innerHTML=`
    <div class="edt-section">
      <div class="edt-row">
        <div class="edt-field">
          <div class="lbl-line">
            <label class="edt-lbl">Supplier *</label>
            <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();_billNewContact()">+ New</a>
          </div>
          <select class="edt-sel" id="bedt-contact"><option value="">— Select supplier —</option>${suppOpts}</select>
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Status</label>
          <select class="edt-sel" id="bedt-status">
            <option ${b.status==='Draft'?'selected':''}>Draft</option>
            <option ${b.status==='Approved'?'selected':''}>Approved</option>
          </select>
        </div>
      </div>
      <div class="edt-row">
        <div class="edt-field">
          <label class="edt-lbl">Bill Number</label>
          <input class="edt-inp" type="text" id="bedt-number" placeholder="Supplier reference" value="${esc(b.bill_number||'')}">
        </div>
        <div class="edt-field"></div>
      </div>
      <div class="edt-row">
        <div class="edt-field">
          <label class="edt-lbl">Bill Date *</label>
          <input class="edt-inp" type="date" id="bedt-date" value="${b.bill_date||''}">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Due Date *</label>
          <input class="edt-inp" type="date" id="bedt-due" value="${b.due_date||''}">
        </div>
      </div>
      ${jobOpts?`<div class="edt-row">
        <div class="edt-field full">
          <label class="edt-lbl">Job / Project</label>
          <select class="edt-sel" id="bedt-job"><option value="">— None —</option>${jobOpts}</select>
        </div>
      </div>`:''}
    </div>
    <div class="edt-divider"></div>
    <div class="edt-section">
      <div class="edt-lines-hdr">
        <span></span><span></span><span>Description</span><span>Qty</span><span>Unit Price</span>
        <span>Tax</span><span class="span-r">GST</span>
        <span class="span-r">Total</span><span></span>
      </div>
      <div id="bedt-lines-body">${linesHtml}</div>
      <button class="btn btn-outline edt-add-btn" onclick="billEditAddLine()">+ Add Line</button>
      <div class="edt-totals-preview" id="bedt-totals">
        <span><span>Subtotal (ex GST)</span><b>${fmt(sub)}</b></span>
        <span><span>GST (10%)</span><b>${fmt(gst)}</b></span>
        <span class="grand"><span>Total</span><b>${fmt(total)}</b></span>
      </div>
    </div>
    <div class="edt-divider"></div>
    <div class="edt-section">
      <div class="edt-field edt-field-mb">
        <label class="edt-lbl">Notes</label>
        <textarea class="edt-ta" id="bedt-notes">${esc(b.notes||'')}</textarea>
      </div>
      <div class="edt-field">
        <label class="edt-lbl">Internal Comments (not printed)</label>
        <textarea class="edt-ta" id="bedt-comments">${esc(b.internal_comments||'')}</textarea>
      </div>
    </div>

    <div class="edt-divider"></div>

    <div class="edt-section">
      <div class="edt-lbl" style="margin-bottom:8px">📎 Attachments</div>
      ${b.id
        ? `<div id="bedt-att-pane"></div>`
        : `<div class="det-empty" style="font-size:12px">Save the bill first, then open it to add attachments.</div>`
      }
    </div>`;

  if (b.id) {
    setTimeout(() => _attLoad('bedt-att-pane', 'bill', b.id), 0);
  }

  const foot=document.getElementById('det-foot');foot.innerHTML='';
  const mk=(label,cls,fn)=>{const btn=document.createElement('button');btn.className=`btn ${cls}`;btn.textContent=label;btn.onclick=fn;foot.appendChild(btn);};
  mk('Save Bill','btn-primary',billEditSave);
  mk('Save as Template','btn-outline',_billSaveAsTemplate);
  mk('Cancel','btn-outline',()=>{
    if(_billEditData.bill.id) billOpen(_billEditData.bill.id);
    else billDetClose();
  });

  // Wire typeaheads on all rendered description inputs
  _billEditLines.forEach((_,i) => _wireBillLineTypeahead(i));
}

function _setBillLineBadge(i, linked) {
  const badge = document.getElementById(`bedt-badge-${i}`);
  const inp   = document.getElementById(`bedt-desc-${i}`);
  if (badge) badge.style.display = linked ? '' : 'none';
  if (inp)   inp.style.borderColor = linked ? 'var(--accent2, #2980b9)' : '';
}

function _wireBillLineTypeahead(i) {
  const inp = document.getElementById(`bedt-desc-${i}`);
  if (!inp || inp.dataset.taWired) return;
  inp.dataset.taWired = '1';
  // If line already has item_id (editing existing bill), show badge immediately
  if (_billEditLines[i] && _billEditLines[i].item_id) _setBillLineBadge(i, true);
  _attachTypeahead(inp, item => {
    _billEditLines[i].description = item.description || item.name;
    _billEditLines[i].unit_price  = item.unit_price || 0;
    _billEditLines[i].tax_code    = item.tax_code || 'GST';
    _billEditLines[i].account_id  = item.account_id || null;
    _billEditLines[i].item_id     = item.id;
    const row = document.getElementById(`bedt-line-${i}`);
    if (row) {
      const inputs = row.querySelectorAll('input[type="number"]');
      if (inputs[1]) inputs[1].value = item.unit_price || 0;
      const taxSel = row.querySelector('.edt-line-row select');
      if (taxSel) taxSel.value = item.tax_code || 'GST';
      const acctSel = document.getElementById(`bedt-acct-${i}`);
      if (acctSel && item.account_id) acctSel.value = item.account_id;
    }
    billLineSet(i, 'unit_price', item.unit_price || 0);
    _checkStock(item.id, _billEditLines[i].quantity || 1, `bedt-stock-${i}`);
    _setBillLineBadge(i, true);
  });
  // Clear item_id and badge only when user actually types in the description
  inp.addEventListener('input', () => {
    if (_billEditLines[i] && _billEditLines[i].item_id) {
      _billEditLines[i].item_id = null;
      _setBillLineBadge(i, false);
    }
  });
}

function _billLineHtml(i, l) {
  const q=l.quantity||1,p=l.unit_price||0;
  const rate=(l.tax_code==='GST'||l.tax_code==='CAP')?0.1:0;
  const gst=Math.round(q*p*rate*100)/100,total=q*p+gst;
  const acctOpts=_billEditAccts.map(a=>`<option value="${a.id}"${a.id===l.account_id?' selected':''}>${esc((a.code?a.code+' ':'')+a.name)}</option>`).join('');
  return `<div class="edt-line-wrap" id="bedt-line-${i}" draggable="true" ondragstart="billLineDragStart(event,${i})" ondragover="billLineDragOver(event,${i})" ondrop="billLineDrop(event,${i})" ondragend="billLineDragEnd(event)">
    <div class="edt-line-row">
      <span class="edt-drag-handle" title="Drag to reorder">⠿</span>
      <span id="bedt-badge-${i}" title="Catalogue item — edit description to unlink" class="item-link-badge" style="display:${l.item_id?'':' none'}">📦</span>
      <input class="edt-inp" type="text" placeholder="Description or search catalogue…"
        id="bedt-desc-${i}" value="${esc(l.description)}" oninput="billLineSet(${i},'description',this.value)">
      <input class="edt-inp" type="number" min="0" step="any" value="${q}"
        oninput="billLineSet(${i},'quantity',+this.value);_checkStock(_billEditLines[${i}]&&_billEditLines[${i}].item_id,+this.value,'bedt-stock-${i}')">
      <input class="edt-inp" type="number" min="0" step="0.01" value="${p}"
        oninput="billLineSet(${i},'unit_price',+this.value)">
      <select class="edt-sel" onchange="billLineSet(${i},'tax_code',this.value)">
        ${['GST','FRE','INP','N-T','CAP'].map(t=>`<option${l.tax_code===t?' selected':''}>${t}</option>`).join('')}
      </select>
      <div class="edt-calc" id="bedt-gst-${i}">${fmt(gst)}</div>
      <div class="edt-calc edt-calc-total" id="bedt-tot-${i}">${fmt(total)}</div>
      <button class="edt-rm-btn" onclick="billEditRemoveLine(${i})" title="Remove">✕</button>
    </div>
    <div class="edt-line-acct">
      <span class="edt-acct-lbl">Account</span>
      <select class="edt-sel edt-acct-sel" id="bedt-acct-${i}" onchange="billLineSet(${i},'account_id',this.value?+this.value:null)">
        <option value="">— select account —</option>${acctOpts}
      </select>
    </div>
    <div class="ta-stock-warn ta-stock-warn-row" id="bedt-stock-${i}"></div>
  </div>`;
}

let _billDragSrc = null;
function billLineDragStart(e, i) {
  _billDragSrc = i;
  e.dataTransfer.effectAllowed = 'move';
  e.dataTransfer.setData('text/plain', String(i));
  setTimeout(() => { document.getElementById(`bedt-line-${i}`)?.classList.add('is-dragging'); }, 0);
}
function billLineDragOver(e, i) {
  if (_billDragSrc === null || _billDragSrc === i) return;
  e.preventDefault();
  document.querySelectorAll('#bedt-lines-body .edt-line-wrap').forEach(el => el.classList.remove('drag-over-top'));
  document.getElementById(`bedt-line-${i}`)?.classList.add('drag-over-top');
}
function billLineDrop(e, i) {
  e.preventDefault();
  if (_billDragSrc === null || _billDragSrc === i) return;
  const active = _billEditLines.map((l, idx) => ({l, idx})).filter(x => x.l !== null);
  const srcPos = active.findIndex(x => x.idx === _billDragSrc);
  const dstPos = active.findIndex(x => x.idx === i);
  if (srcPos < 0 || dstPos < 0) return;
  const [moved] = active.splice(srcPos, 1);
  active.splice(dstPos, 0, moved);
  _billEditLines = active.map(x => x.l);
  _billDragSrc = null;
  _billRenderAllLines();
}
function billLineDragEnd(e) {
  _billDragSrc = null;
  document.querySelectorAll('#bedt-lines-body .edt-line-wrap').forEach(el => {
    el.classList.remove('is-dragging', 'drag-over-top');
  });
}
function _billRenderAllLines() {
  const body = document.getElementById('bedt-lines-body');
  if (!body) return;
  body.innerHTML = _billEditLines.map((l, i) => _billLineHtml(i, l)).join('');
  _billEditLines.forEach((l, i) => { if (l) _wireBillLineTypeahead(i); });
  _billEditRefreshTotals();
}

function billLineSet(i,field,val){
  _billEditLines[i][field]=val;
  const l=_billEditLines[i],q=l.quantity||0,p=l.unit_price||0;
  const rate=(l.tax_code==='GST'||l.tax_code==='CAP')?0.1:0;
  const gst=Math.round(q*p*rate*100)/100,total=q*p+gst;
  const ge=document.getElementById(`bedt-gst-${i}`),te=document.getElementById(`bedt-tot-${i}`);
  if(ge)ge.textContent=fmt(gst);if(te)te.textContent=fmt(total);
  _billEditRefreshTotals();
}
function billEditAddLine(){
  const i=_billEditLines.length;
  _billEditLines.push({description:'',quantity:1,unit_price:0,tax_code:_billGSTReg?'GST':'INP',account_id:null,item_id:null});
  const row=document.createElement('div');
  row.innerHTML=_billLineHtml(i,_billEditLines[i]);
  document.getElementById('bedt-lines-body').appendChild(row.firstElementChild);
  _billEditRefreshTotals();
  _wireBillLineTypeahead(i);
  const el = document.getElementById(`bedt-desc-${i}`);
  if (el) el.focus();
}
function billEditRemoveLine(i){
  _billEditLines[i]=null;
  const el=document.getElementById(`bedt-line-${i}`);if(el)el.remove();
  _billEditRefreshTotals();
}
function _billEditTotals(){
  let sub=0,gst=0;
  (_billEditLines||[]).forEach(l=>{
    if(!l)return;
    const q=l.quantity||0,p=l.unit_price||0,rate=(l.tax_code==='GST'||l.tax_code==='CAP')?0.1:0;
    gst+=Math.round(q*p*rate*100)/100;sub+=q*p;
  });
  return{sub:Math.round(sub*100)/100,gst:Math.round(gst*100)/100,total:Math.round((sub+gst)*100)/100};
}
function _billEditRefreshTotals(){
  const {sub,gst,total}=_billEditTotals();
  const el=document.getElementById('bedt-totals');
  if(el)el.innerHTML=`
    <span><span>Subtotal (ex GST)</span><b>${fmt(sub)}</b></span>
    <span><span>GST (10%)</span><b>${fmt(gst)}</b></span>
    <span class="grand"><span>Total</span><b>${fmt(total)}</b></span>`;
}

async function billEditSave(){
  const contactId=parseInt(document.getElementById('bedt-contact').value);
  const billDate=document.getElementById('bedt-date').value;
  const dueDate=document.getElementById('bedt-due').value;
  const status=document.getElementById('bedt-status').value;
  if(!contactId){toast('Select a supplier','err');return;}
  if(!billDate){toast('Enter a bill date','err');return;}
  if(!dueDate){toast('Enter a due date','err');return;}
  const lines=(_billEditLines||[]).filter(l=>l&&l.description.trim());
  if(!lines.length){toast('Add at least one line item','err');return;}
  const payload={
    id:_billEditData.bill.id,
    opp_id:_billEditData.bill.opp_id||null,
    contact_id:contactId,
    bill_number:document.getElementById('bedt-number').value,
    bill_date:billDate,
    due_date:dueDate,
    status,
    notes:document.getElementById('bedt-notes').value,
    internal_comments:document.getElementById('bedt-comments').value,
    job_id:parseInt(document.getElementById('bedt-job')?.value||0)||null,
    lines:lines.map(l=>({description:l.description,quantity:l.quantity,unit_price:l.unit_price,tax_code:l.tax_code,account_id:l.account_id||null,item_id:l.item_id||null})),
  };
  const btn=document.querySelector('.det-foot .btn-primary');
  if(btn){btn.disabled=true;btn.textContent='Saving\u2026';}
  try{
    let r,j;
    if(payload.id){
      r=await fetch(`/api/bills/${payload.id}`,{method:'PUT',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      j=await r.json();if(!j.ok)throw new Error(j.error);
      toast('Bill saved');
      _billEditData=null;_billEditLines=[];
      await _billRefresh(payload.id);
      billOpen(payload.id);
    }else{
      r=await fetch('/api/bills',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      j=await r.json();if(!j.ok)throw new Error(j.error);
      toast('Bill created');
      _billEditData=null;_billEditLines=[];
      _billAll=(await apiFetch('/api/bills'))||[];
      if (typeof _page !== 'undefined' && _page === 'bills') renderBillsPage();
      billOpen(j.data.id);
    }
  }catch(e){
    toast(e.message,'err');
    if(btn){btn.disabled=false;btn.textContent='Save Bill';}
  }
}




// ══════════════════════════════════════════════════════════════════════════════
// SUPPLIER PAYMENT RUN  (Stage 5S)
// Full-screen modal: select bills → confirm → post payments → optional ABA
// ══════════════════════════════════════════════════════════════════════════════

function _sprModalHtml() {
  return `
<div id="spr-overlay" class="spr-overlay" onclick="if(event.target===this)sprClose()">
  <div class="spr-box">
    <!-- Header -->
    <div class="spr-hdr">
      <div>
        <div class="spr-title">Supplier Payment Run</div>
        <div class="spr-subtitle">Select bills to pay. Payments are consolidated per supplier.</div>
      </div>
      <button class="spr-close-btn" onclick="sprClose()" title="Close">&times;</button>
    </div>

    <!-- Controls bar -->
    <div class="spr-controls">
      <div class="spr-controls-row">
        <label class="spr-lbl">Payment Date</label>
        <input type="date" id="spr-date" class="edt-inp spr-date-inp"
               value="${isoToday()}">
        <label class="spr-lbl spr-lbl-gap">From Bank</label>
        <select id="spr-bank" class="edt-sel spr-bank-sel">
          ${_sprBanks.length
            ? _sprBanks.map(a=>`<option value="${a.id}">${esc((a.code||'')+' '+a.name)}</option>`).join('')
            : '<option value="">— No bank accounts —</option>'}
        </select>
      </div>
      <div class="spr-controls-btns">
        <button class="btn btn-sm btn-outline" onclick="sprSelectAll()">Select All</button>
        <button class="btn btn-sm btn-outline" onclick="sprSelectNone()">Select None</button>
        <button class="btn btn-sm btn-outline btn-amber" onclick="sprSelectOverdue()">Overdue Only</button>
      </div>
    </div>

    <!-- Bills table -->
    <div class="spr-table-wrap">
      <table class="spr-table">
        <thead><tr>
          <th class="th-chk"></th>
          <th>Supplier</th>
          <th>Bill #</th>
          <th>Bill Date</th>
          <th>Due Date</th>
          <th class="th-r">Balance</th>
          <th class="th-c">Bank Details</th>
        </tr></thead>
        <tbody id="spr-tbody">
          <tr class="tbl-empty-row"><td colspan="7">Loading…</td></tr>
        </tbody>
      </table>
    </div>

    <!-- Footer -->
    <div class="spr-foot">
      <div class="modal-stack">
        <div id="spr-summary" class="spr-summary">Selected: $0.00 | 0 bills | 0 suppliers</div>
        <label class="spr-aba-label">
          <input type="checkbox" id="spr-aba-chk" class="aba-chk-lbl">
          Generate ABA file for bank upload
          <span id="spr-aba-warn" class="aba-warn-inline">
            ⚠ Some suppliers lack bank details — they will be excluded from the ABA
          </span>
        </label>
      </div>
      <div class="modal-foot-row">
        <button class="btn btn-outline" onclick="sprClose()">Cancel</button>
        <button class="btn btn-primary" id="spr-post-btn" onclick="sprPost()">💳 Post Payments</button>
      </div>
    </div>
  </div>
</div>`;
}

function _sprInjectStyles() {
  if (document.getElementById('spr-styles')) return;
  const s = document.createElement('style');
  s.id = 'spr-styles';
  s.textContent = `
.spr-overlay {
  position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:350;
  display:flex;align-items:center;justify-content:center;
  animation:spr-fade .15s ease;
}
@keyframes spr-fade{from{opacity:0}to{opacity:1}}
.spr-box {
  background:var(--surface);border:1px solid var(--border);border-radius:10px;
  width:min(960px,96vw);max-height:88vh;display:flex;flex-direction:column;
  box-shadow:0 20px 60px rgba(0,0,0,.35);overflow:hidden;
}
.spr-hdr {
  display:flex;justify-content:space-between;align-items:flex-start;
  padding:18px 22px 14px;border-bottom:1px solid var(--border);flex-shrink:0;
}
.spr-title{font-size:16px;font-weight:700;color:var(--ink)}
.spr-subtitle{font-size:12px;color:var(--ink3);margin-top:3px}
.spr-close-btn {
  background:none;border:none;font-size:22px;line-height:1;color:var(--ink3);
  cursor:pointer;padding:0 4px;
}
.spr-close-btn:hover{color:var(--ink)}
.spr-controls {
  display:flex;justify-content:space-between;align-items:center;
  padding:12px 22px;border-bottom:1px solid var(--border);
  background:var(--bg);flex-shrink:0;gap:10px;flex-wrap:wrap;
}
.spr-lbl{font-size:12px;color:var(--ink2);white-space:nowrap}
.spr-table-wrap{overflow-y:auto;flex:1;min-height:0}
.spr-table {
  width:100%;border-collapse:collapse;font-size:13px;
}
.spr-table thead th {
  position:sticky;top:0;background:var(--bg);padding:8px 12px;
  text-align:left;font-size:11px;text-transform:uppercase;
  letter-spacing:.06em;color:var(--ink3);border-bottom:1px solid var(--border);
  font-weight:600;
}
.spr-table tbody tr{border-bottom:1px solid var(--border);cursor:pointer;background:var(--surface,var(--panel))}
.spr-table tbody tr:hover{background:var(--row-alt,rgba(128,128,128,.06))}
.spr-table tbody tr.spr-selected{background:var(--accent-dim)}
.spr-table tbody tr.spr-overdue td:nth-child(5){color:var(--red)}
.spr-table td{padding:9px 12px;vertical-align:middle}
.spr-chk {
  width:16px;height:16px;cursor:pointer;accent-color:var(--accent);
}
.spr-no-bank{font-size:10px;color:var(--amber);font-family:'DM Mono',monospace}
.spr-has-bank{font-size:10px;color:var(--green);font-family:'DM Mono',monospace}
.spr-foot {
  display:flex;justify-content:space-between;align-items:center;
  padding:14px 22px;border-top:1px solid var(--border);
  background:var(--bg);flex-shrink:0;gap:12px;flex-wrap:wrap;
}
.spr-summary{font-size:13px;color:var(--ink2);font-family:'DM Mono',monospace}
.spr-aba-label{font-size:12px;color:var(--ink2);display:flex;align-items:center;cursor:pointer}
  `;
  document.head.appendChild(s);
}

async function sprOpen() {
  _sprInjectStyles();

  // Load candidates and bank accounts in parallel
  let [candidates, accts] = [[], []];
  try {
    [candidates, accts] = await Promise.all([
      apiFetch('/api/bills/payment-run/candidates'),
      apiFetch('/api/accounts'),
    ]);
  } catch(e) { toast('Could not load payment run data: ' + e.message, 'err'); return; }

  _sprCandidates = candidates || [];
  _sprBanks      = (accts || []).filter(a => a.is_bank);
  _sprSelected   = new Set();

  // Inject modal if not present
  if (!document.getElementById('spr-overlay')) {
    const div = document.createElement('div');
    div.innerHTML = _sprModalHtml();
    document.body.appendChild(div.firstElementChild);
  } else {
    // Modal exists — refresh bank dropdown and date
    const bankSel = document.getElementById('spr-bank');
    if (bankSel) {
      bankSel.innerHTML = _sprBanks.length
        ? _sprBanks.map(a=>`<option value="${a.id}">${esc((a.code||'')+' '+a.name)}</option>`).join('')
        : '<option value="">— No bank accounts —</option>';
    }
    document.getElementById('spr-date').value = isoToday();
    document.getElementById('spr-aba-chk').checked = false;
    document.getElementById('spr-overlay').classList.remove('spr-hidden');
  }

  document.getElementById('spr-overlay').style.display = 'flex';
  sprRenderTable();
}

function sprClose() {
  const el = document.getElementById('spr-overlay');
  if (el) el.style.display = 'none';
}

function sprRenderTable() {
  const today = isoToday();
  const tbody  = document.getElementById('spr-tbody');
  if (!tbody) return;

  if (!_sprCandidates.length) {
    tbody.innerHTML = `<tr class="tbl-empty-row"><td colspan="7">No payable bills found. Bills must be in <strong>Approved</strong> or <strong>Overdue</strong> status with a balance remaining.</td></tr>`;
    sprUpdateSummary();
    return;
  }

  tbody.innerHTML = _sprCandidates.map(b => {
    const sel      = _sprSelected.has(b.bill_id);
    const overdue  = b.due_date && b.due_date < today;
    const rowCls   = [sel ? 'spr-selected' : '', overdue ? 'spr-overdue' : ''].filter(Boolean).join(' ');
    const bankHtml = b.has_bank
      ? `<span class="bank-ok">✓ BSB &amp; Account</span>`
      : `<span class="bank-missing">⚠ Missing</span>`;
    return `<tr class="${rowCls}" onclick="sprToggle(${b.bill_id})" data-bid="${b.bill_id}" data-due="${b.due_date||''}">
      <td><input type="checkbox" class="spr-chk" ${sel?'checked':''} onclick="event.stopPropagation();sprToggle(${b.bill_id})"></td>
      <td class="td-name">${esc(b.supplier_name||'—')}</td>
      <td class="td-r-mono">${esc(b.bill_number||'—')}</td>
      <td class="td-r-mono">${fmtDate(b.bill_date)}</td>
      <td class="td-r-mono">${fmtDate(b.due_date)}</td>
      <td class="td-r-mono-bold">${fmt(b.balance_due)}</td>
      <td class="td-c-mono">${bankHtml}</td>
    </tr>`;
  }).join('');

  sprUpdateSummary();
}

function sprToggle(billId) {
  if (_sprSelected.has(billId)) _sprSelected.delete(billId);
  else _sprSelected.add(billId);

  // Update row appearance without full re-render
  const row = document.querySelector(`#spr-tbody tr[data-bid="${billId}"]`);
  if (row) {
    const chk = row.querySelector('.spr-chk');
    if (_sprSelected.has(billId)) {
      row.classList.add('spr-selected');
      if (chk) chk.checked = true;
    } else {
      row.classList.remove('spr-selected');
      if (chk) chk.checked = false;
    }
  }
  sprUpdateSummary();
}

function sprSelectAll() {
  _sprCandidates.forEach(b => _sprSelected.add(b.bill_id));
  sprRenderTable();
}
function sprSelectNone() {
  _sprSelected.clear();
  sprRenderTable();
}
function sprSelectOverdue() {
  const today = isoToday();
  _sprSelected.clear();
  _sprCandidates.forEach(b => { if (b.due_date && b.due_date < today) _sprSelected.add(b.bill_id); });
  sprRenderTable();
}

function sprUpdateSummary() {
  const sel    = _sprCandidates.filter(b => _sprSelected.has(b.bill_id));
  const total  = sel.reduce((s, b) => s + b.balance_due, 0);
  const supps  = new Set(sel.map(b => b.contact_id)).size;
  const noBnk  = sel.filter(b => !b.has_bank).length;

  const sumEl  = document.getElementById('spr-summary');
  if (sumEl) {
    sumEl.textContent = `Selected: ${fmt(total)} | ${sel.length} bill${sel.length!==1?'s':''} | ${supps} supplier${supps!==1?'s':''}`;
  }

  // Show ABA warning if any selected suppliers lack bank details
  const warnEl = document.getElementById('spr-aba-warn');
  if (warnEl) warnEl.style.display = noBnk > 0 ? 'inline' : 'none';
}

async function sprPost() {
  if (_sprPosting) return;

  const billIds       = [..._sprSelected];
  const bankAccountId = parseInt(document.getElementById('spr-bank')?.value || 0);
  const paymentDate   = document.getElementById('spr-date')?.value;
  const generateAba   = document.getElementById('spr-aba-chk')?.checked;

  if (!billIds.length)    { toast('Select at least one bill', 'err'); return; }
  if (!bankAccountId)     { toast('Select a bank account', 'err'); return; }
  if (!paymentDate)       { toast('Enter a payment date', 'err'); return; }

  // Confirmation
  const sel   = _sprCandidates.filter(b => _sprSelected.has(b.bill_id));
  const total = sel.reduce((s, b) => s + b.balance_due, 0);
  const supps = new Set(sel.map(b => b.contact_id)).size;
  const abaNote = generateAba ? '\n\nAn ABA file will be generated for bank upload.' : '';

  const confirmed = await confirmDlg(
    `Post ${sel.length} payment${sel.length!==1?'s':''} to ` +
    `${supps} supplier${supps!==1?'s':''} ` +
    `totalling ${fmt(total)}?\n\n` +
    `Payment date: ${paymentDate}${abaNote}`
  );
  if (!confirmed) return;

  _sprPosting = true;
  const btn = document.getElementById('spr-post-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Posting…'; }

  try {
    const _r = await fetch('/api/bills/payment-run', {
      method:      'POST',
      headers:     {'Content-Type': 'application/json'},
      credentials: 'include',
      body:        JSON.stringify({
        bill_ids:        billIds,
        bank_account_id: bankAccountId,
        payment_date:    paymentDate,
        generate_aba:    generateAba,
        aba_description: 'SUPPLIERS',
      }),
    });
    const j = await _r.json();
    if (!j.ok) throw new Error(j.error || 'Payment run failed');
    const d = j.data || {};

    // Download ABA file if returned
    if (d.aba_content) {
      const filename = `suppliers_${paymentDate.replace(/-/g,'')}.aba`;
      _sprDownloadText(d.aba_content, filename);
    }

    // Build result message
    const postedCount = d.posted?.length || 0;
    let msg = `Posted ${postedCount} payment${postedCount!==1?'s':''} totalling ${fmt(total)}.`;
    if (d.aba_content)       msg += '\n\nABA file downloaded — upload it to your bank.';
    if (d.missing_bank?.length) {
      msg += `\n\n⚠ ${d.missing_bank.length} supplier${d.missing_bank.length!==1?'s were':' was'} excluded from the ABA (no bank details):\n`
           + d.missing_bank.slice(0, 5).join(', ')
           + (d.missing_bank.length > 5 ? ` and ${d.missing_bank.length - 5} more…` : '');
    }
    if (d.errors?.length) {
      msg += `\n\n${d.errors.length} error${d.errors.length!==1?'s':''}:\n` + d.errors.slice(0, 3).join('\n');
      toast(msg, 'err');
    } else {
      toast(msg);
    }

    sprClose();

    // Refresh the bills list
    _billAll = (await apiFetch('/api/bills')) || [];
    renderBillsPage();

  } catch(e) {
    toast(e.message, 'err');
  } finally {
    _sprPosting = false;
    if (btn) { btn.disabled = false; btn.textContent = '💳 Post Payments'; }
  }
}

function _sprDownloadText(content, filename) {
  const blob = new Blob([content], { type: 'text/plain' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = filename;
  a.style.display = 'none';
  document.body.appendChild(a);
  a.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

// ══════════════════════════════════════════════════════════════════════════════
// ABA EXPORT  (Stage 5T)
// Date range picker → selectable payment table → preview viewer → download/print
// ══════════════════════════════════════════════════════════════════════════════

let _abaPayments  = [];        // loaded payments from API
let _abaSelected  = new Set(); // selected payment IDs
let _abaPreset    = 'today';   // 'today'|'month'|'lastmonth'|null
let _abaView      = 'select';  // 'select' | 'preview'
let _abaContent   = null;      // generated ABA string

// ── Date helpers ──────────────────────────────────────────────────────────────
function _abaDateRange(preset) {
  const now   = new Date();
  const pad   = n => String(n).padStart(2,'0');
  const iso   = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
  if (preset === 'today') {
    const t = iso(now);
    return [t, t];
  }
  if (preset === 'month') {
    const from = `${now.getFullYear()}-${pad(now.getMonth()+1)}-01`;
    const last = new Date(now.getFullYear(), now.getMonth()+1, 0);
    return [from, iso(last)];
  }
  if (preset === 'lastmonth') {
    const first = new Date(now.getFullYear(), now.getMonth()-1, 1);
    const last  = new Date(now.getFullYear(), now.getMonth(), 0);
    return [iso(first), iso(last)];
  }
  return [iso(now), iso(now)];
}

// ── Styles ────────────────────────────────────────────────────────────────────
function _abaInjectStyles() {
  if (document.getElementById('aba-styles')) return;
  const s = document.createElement('style');
  s.id = 'aba-styles';
  s.textContent = `
.aba-overlay {
  position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:350;
  display:none;align-items:center;justify-content:center;
}
.aba-overlay.open { display:flex; animation:spr-fade .15s ease; }
.aba-box {
  background:var(--surface);border:1px solid var(--border);border-radius:10px;
  width:min(860px,95vw);max-height:88vh;display:flex;flex-direction:column;
  box-shadow:0 20px 60px rgba(0,0,0,.35);overflow:hidden;
}
.aba-hdr {
  display:flex;justify-content:space-between;align-items:flex-start;
  padding:16px 22px 12px;border-bottom:1px solid var(--border);flex-shrink:0;
  background:var(--surface);
}
.aba-title { font-size:15px;font-weight:700;color:var(--ink) }
.aba-subtitle { font-size:12px;color:var(--ink3);margin-top:2px }
.aba-close {
  background:none;border:none;font-size:22px;line-height:1;
  color:var(--ink3);cursor:pointer;padding:0 4px;
}
.aba-close:hover { color:var(--ink) }
.aba-range {
  display:flex;align-items:center;gap:8px;padding:12px 22px;
  border-bottom:1px solid var(--border);background:var(--bg);
  flex-shrink:0;flex-wrap:wrap;
}
.aba-preset {
  padding:5px 12px;border:1.5px solid var(--border);border-radius:6px;
  background:var(--surface);color:var(--ink2);font-size:12px;
  cursor:pointer;font-family:'Instrument Sans',sans-serif;transition:all .12s;
}
.aba-preset:hover { border-color:var(--accent);color:var(--accent) }
.aba-preset.active {
  background:var(--accent);border-color:var(--accent);color:#fff;font-weight:600;
}
.aba-date-inp {
  padding:5px 10px;border:1.5px solid var(--border);border-radius:6px;
  background:var(--surface);color:var(--ink);font-size:12px;
  font-family:'Instrument Sans',sans-serif;
}
.aba-date-inp:focus { outline:none;border-color:var(--accent) }
.aba-load-btn {
  padding:5px 14px;border:1.5px solid var(--accent);border-radius:6px;
  background:var(--accent);color:#fff;font-size:12px;cursor:pointer;
  font-family:'Instrument Sans',sans-serif;font-weight:600;
}
.aba-load-btn:hover { opacity:.88 }
.aba-body { overflow-y:auto;flex:1;min-height:0 }
.aba-table {
  width:100%;border-collapse:collapse;font-size:13px;
}
.aba-table thead th {
  position:sticky;top:0;background:var(--bg);padding:8px 14px;
  text-align:left;font-size:10px;text-transform:uppercase;
  letter-spacing:.07em;color:var(--ink3);border-bottom:1px solid var(--border);
  font-weight:600;
}
.aba-table tbody tr {
  border-bottom:1px solid var(--border);cursor:pointer;
  background:var(--surface);
}
.aba-table tbody tr:hover { background:var(--row-alt) }
.aba-table tbody tr.aba-sel { background:var(--accent-dim) }
.aba-table td { padding:9px 14px;vertical-align:middle }
.aba-chk { width:16px;height:16px;cursor:pointer;accent-color:var(--accent) }
.aba-foot {
  display:flex;justify-content:space-between;align-items:center;
  padding:12px 22px;border-top:1px solid var(--border);
  background:var(--bg);flex-shrink:0;gap:10px;flex-wrap:wrap;
}
.aba-summary { font-size:13px;color:var(--ink2);font-family:'DM Mono',monospace }

/* ── Preview panel ── */
.aba-preview-wrap { padding:20px 22px }
.aba-preview-hdr {
  display:flex;justify-content:space-between;align-items:flex-start;
  margin-bottom:16px;flex-wrap:wrap;gap:8px;
}
.aba-preview-meta { font-size:12px;color:var(--ink2);line-height:1.8 }
.aba-preview-meta strong { color:var(--ink) }
.aba-preview-table {
  width:100%;border-collapse:collapse;font-size:12px;margin-bottom:16px;
}
.aba-preview-table th {
  padding:7px 12px;text-align:left;font-size:10px;text-transform:uppercase;
  letter-spacing:.07em;color:var(--ink3);border-bottom:2px solid var(--border);
  font-weight:600;background:var(--bg);
}
.aba-preview-table td {
  padding:8px 12px;border-bottom:1px solid var(--border);
  font-family:'DM Mono',monospace;font-size:12px;color:var(--ink);
}
.aba-preview-table tr:last-child td { border-bottom:none }
.aba-preview-total {
  text-align:right;padding:10px 12px 0;font-size:13px;font-weight:700;
  color:var(--ink);border-top:2px solid var(--border);font-family:'DM Mono',monospace;
}

/* ── Print stylesheet ── */
@media print {
  body > *:not(#aba-print-root) { display:none !important }
  #aba-print-root {
    display:block !important;font-family:'Courier New',monospace;font-size:11pt;
    color:#000;background:#fff;padding:20mm;
  }
  .aba-print-title { font-size:16pt;font-weight:bold;margin-bottom:4pt }
  .aba-print-meta  { font-size:10pt;color:#444;margin-bottom:12pt;line-height:1.6 }
  .aba-print-table { width:100%;border-collapse:collapse;font-size:10pt }
  .aba-print-table th {
    border-bottom:2pt solid #000;padding:4pt 8pt;text-align:left;font-weight:bold;
  }
  .aba-print-table td { border-bottom:1pt solid #ccc;padding:4pt 8pt }
  .aba-print-total { text-align:right;font-weight:bold;padding-top:6pt;font-size:11pt }
  .no-print { display:none !important }
}
  `;
  document.head.appendChild(s);
}

// ── Open / close ──────────────────────────────────────────────────────────────
function abaExportOpen() {
  _abaInjectStyles();
  _abaPayments = [];
  _abaSelected = new Set();
  _abaView     = 'select';
  _abaContent  = null;
  _abaPreset   = 'today';

  if (!document.getElementById('aba-overlay')) {
    const div = document.createElement('div');
    div.id = 'aba-overlay';
    div.className = 'aba-overlay';
    div.onclick = e => { if (e.target === div) abaExportClose(); };
    div.innerHTML = `
      <div class="aba-box" id="aba-box">
        <div class="aba-hdr">
          <div>
            <div class="aba-title">ABA Export</div>
            <div class="aba-subtitle" id="aba-subtitle">Select a date range to load payments</div>
          </div>
          <button class="aba-close" onclick="abaExportClose()">&times;</button>
        </div>
        <div class="aba-range" id="aba-range">
          <button class="aba-preset active" id="aba-p-today"    onclick="abaPreset('today')">Today</button>
          <button class="aba-preset"        id="aba-p-month"    onclick="abaPreset('month')">This Month</button>
          <button class="aba-preset"        id="aba-p-lastmonth" onclick="abaPreset('lastmonth')">Last Month</button>
          <span class="aba-range-lbl">From</span>
          <input type="date" class="aba-date-inp" id="aba-from" oninput="abaDateTyped()">
          <span class="aba-range-lbl-bare">To</span>
          <input type="date" class="aba-date-inp" id="aba-to"   oninput="abaDateTyped()">
          <button class="aba-load-btn" onclick="abaLoad()">Load</button>
        </div>
        <div class="aba-body" id="aba-body">
          <div class="state-loading">Loading…</div>
        </div>
        <div class="aba-foot" id="aba-foot">
          <div class="aba-summary" id="aba-summary">—</div>
          <div class="aba-foot-btns">
            <button class="btn btn-outline" onclick="abaExportClose()">Close</button>
            <button class="btn btn-primary" id="aba-preview-btn" onclick="abaShowPreview()" disabled>Preview ABA</button>
          </div>
        </div>
      </div>`;
    document.body.appendChild(div);
  }

  document.getElementById('aba-overlay').classList.add('open');
  _abaSetDates(..._abaDateRange('today'));
  abaLoad();
}

function abaExportClose() {
  const el = document.getElementById('aba-overlay');
  if (el) el.classList.remove('open');
}

// ── Preset / date handling ────────────────────────────────────────────────────
function abaPreset(preset) {
  _abaPreset = preset;
  ['today','month','lastmonth'].forEach(p => {
    const btn = document.getElementById(`aba-p-${p}`);
    if (btn) btn.classList.toggle('active', p === preset);
  });
  _abaSetDates(..._abaDateRange(preset));
  abaLoad();
}

function _abaSetDates(from, to) {
  const f = document.getElementById('aba-from');
  const t = document.getElementById('aba-to');
  if (f) f.value = from;
  if (t) t.value = to;
}

function abaDateTyped() {
  // Deselect all presets when user manually edits dates
  _abaPreset = null;
  ['today','month','lastmonth'].forEach(p => {
    const btn = document.getElementById(`aba-p-${p}`);
    if (btn) btn.classList.remove('active');
  });
}

// ── Load payments ─────────────────────────────────────────────────────────────
async function abaLoad() {
  const from = document.getElementById('aba-from')?.value;
  const to   = document.getElementById('aba-to')?.value;
  if (!from || !to) { toast('Enter both dates', 'err'); return; }
  if (from > to)    { toast('From date must be before To date', 'err'); return; }

  const body = document.getElementById('aba-body');
  if (body) body.innerHTML = '<div class="state-loading">Loading…</div>';
  document.getElementById('aba-subtitle').textContent = `${fmtDate(from)} — ${fmtDate(to)}`;

  try {
    _abaPayments = await apiFetch(`/api/bills/aba-candidates?from=${from}&to=${to}`) || [];
    _abaSelected = new Set(_abaPayments.map(p => p.payment_id));  // select all by default
    _abaRenderTable();
  } catch(e) {
    if (body) body.innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
  }
}


// ── Selection table ───────────────────────────────────────────────────────────
function _abaRenderTable() {
  const body = document.getElementById('aba-body');
  if (!body) return;

  if (!_abaPayments.length) {
    body.innerHTML = `<div class="state-loading">No supplier payments found for this date range.</div>`;
    _abaUpdateSummary();
    return;
  }

  body.innerHTML = `<table class="aba-table">
    <thead><tr>
      <th class="th-chk"></th>
      <th>Date</th>
      <th>Supplier</th>
      <th>Reference</th>
      <th class="th-r">Amount</th>
      <th class="th-c">BSB / Account</th>
    </tr></thead>
    <tbody>
    ${_abaPayments.map(p => {
      const sel     = _abaSelected.has(p.payment_id);
      const hasBnk  = p.dest_bsb && p.dest_account;
      const bankHtml = hasBnk
        ? `<span class="bank-ok">✓ ${esc(p.dest_bsb)}</span>`
        : `<span class="bank-missing">⚠ Missing</span>`;
      return `<tr class="${sel?'aba-sel':''}" onclick="abaToggle(${p.payment_id})" data-pid="${p.payment_id}">
        <td><input type="checkbox" class="aba-chk" ${sel?'checked':''} onclick="event.stopPropagation();abaToggle(${p.payment_id})"></td>
        <td class="td-r-mono">${fmtDate(p.payment_date)}</td>
        <td class="td-name">${esc(p.dest_name||'—')}</td>
        <td class="td-ref">${esc(p.lodgement_ref||'—')}</td>
        <td class="td-r-mono-bold">${fmt(p.amount)}</td>
        <td class="td-c-mono">${bankHtml}</td>
      </tr>`;
    }).join('')}
    </tbody>
  </table>`;

  _abaUpdateSummary();
}

function abaToggle(pid) {
  if (_abaSelected.has(pid)) _abaSelected.delete(pid);
  else _abaSelected.add(pid);
  const row = document.querySelector(`#aba-body tr[data-pid="${pid}"]`);
  if (row) {
    const chk = row.querySelector('.aba-chk');
    row.classList.toggle('aba-sel', _abaSelected.has(pid));
    if (chk) chk.checked = _abaSelected.has(pid);
  }
  _abaUpdateSummary();
}

function _abaUpdateSummary() {
  const sel   = _abaPayments.filter(p => _abaSelected.has(p.payment_id));
  const total = sel.reduce((s,p) => s + parseFloat(p.amount||0), 0);
  const noBnk = sel.filter(p => !p.dest_bsb || !p.dest_account).length;

  const sumEl = document.getElementById('aba-summary');
  if (sumEl) {
    let txt = `Selected: ${fmt(total)} | ${sel.length} payment${sel.length!==1?'s':''}`;
    if (noBnk) txt += ` | ⚠ ${noBnk} missing bank details (will be excluded)`;
    sumEl.textContent = txt;
  }
  const btn = document.getElementById('aba-preview-btn');
  if (btn) btn.disabled = sel.length === 0;
}

// ── Preview ───────────────────────────────────────────────────────────────────
async function abaShowPreview() {
  const from = document.getElementById('aba-from')?.value;
  const to   = document.getElementById('aba-to')?.value;
  const sel  = _abaPayments.filter(p => _abaSelected.has(p.payment_id));
  if (!sel.length) { toast('Select at least one payment', 'err'); return; }

  // Use the latest from-date among selected payments as process date
  const processDate = sel.reduce((max,p) => p.payment_date > max ? p.payment_date : max, sel[0].payment_date);

  const btn = document.getElementById('aba-preview-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Building…'; }

  try {
    const r = await fetch('/api/bills/aba-generate', {
      method:      'POST',
      headers:     {'Content-Type':'application/json'},
      credentials: 'include',
      body:        JSON.stringify({
        payment_ids:  sel.map(p => p.payment_id),
        process_date: processDate,
        description:  'SUPPLIERS',
      }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'ABA generation failed');
    const d = j.data || {};
    _abaContent = d.aba_content;
    _abaRenderPreview(sel, d.aba_content, processDate, from, to);
  } catch(e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Preview ABA'; }
  }
}

function _abaRenderPreview(payments, abaContent, processDate, from, to) {
  _abaView = 'preview';
  const total = payments.reduce((s,p) => s + parseFloat(p.amount||0), 0);

  const rangeLabel = from === to ? fmtDate(from)
    : `${fmtDate(from)} — ${fmtDate(to)}`;

  // Update subtitle
  document.getElementById('aba-subtitle').textContent = 'Review before downloading';

  // Render preview body
  const body = document.getElementById('aba-body');
  body.innerHTML = `
    <div class="aba-preview-wrap" id="aba-print-root">
      <div class="aba-preview-hdr">
        <div>
          <div class="aba-print-title aba-print-title-text">
            ABA Payment File
          </div>
          <div class="aba-preview-meta aba-print-meta">
            <strong>Period:</strong> ${rangeLabel}<br>
            <strong>Process Date:</strong> ${fmtDate(processDate)}<br>
            <strong>Payments:</strong> ${payments.length}<br>
            <strong>Total:</strong> ${fmt(total)}
          </div>
        </div>
      </div>

      <table class="aba-preview-table aba-print-table">
        <thead><tr>
          <th>#</th>
          <th>Supplier</th>
          <th>BSB</th>
          <th>Account</th>
          <th>Reference</th>
          <th class="th-r">Amount</th>
        </tr></thead>
        <tbody>
        ${payments.map((p,i) => `<tr>
          <td class="col-ink3">${i+1}</td>
          <td class="td-name">${esc(p.dest_name||'—')}</td>
          <td>${esc(p.dest_bsb||'—')}</td>
          <td>${esc(p.dest_account||'—')}</td>
          <td class="col-ink3">${esc(p.lodgement_ref||'—')}</td>
          <td class="td-r-mono-bold">${fmt(p.amount)}</td>
        </tr>`).join('')}
        </tbody>
      </table>
      <div class="aba-preview-total aba-print-total">Total: ${fmt(total)}</div>
    </div>`;

  // Update footer
  const foot = document.getElementById('aba-foot');
  foot.innerHTML = `
    <div class="aba-summary">
      ${payments.length} payment${payments.length!==1?'s':''} — ${fmt(total)}
    </div>
    <div class="aba-foot-btns">
      <button class="btn btn-outline no-print" onclick="abaBackToSelect()">← Back</button>
      <button class="btn btn-outline no-print" onclick="abaPrint()">🖨 Print</button>
      <button class="btn btn-primary no-print" onclick="abaDownload('${processDate}')">⬇ Download .aba</button>
    </div>`;
}

function abaBackToSelect() {
  _abaView    = 'select';
  _abaContent = null;
  document.getElementById('aba-subtitle').textContent =
    `${document.getElementById('aba-from')?.value||''} — ${document.getElementById('aba-to')?.value||''}`;
  _abaRenderTable();
  // Restore footer
  document.getElementById('aba-foot').innerHTML = `
    <div class="aba-summary" id="aba-summary">—</div>
    <div class="aba-foot-btns">
      <button class="btn btn-outline" onclick="abaExportClose()">Close</button>
      <button class="btn btn-primary" id="aba-preview-btn" onclick="abaShowPreview()">Preview ABA</button>
    </div>`;
  _abaUpdateSummary();
}

function abaDownload(processDate) {
  if (!_abaContent) { toast('No ABA content — go back and regenerate', 'err'); return; }
  const filename = `suppliers_${(processDate||'').replace(/-/g,'')}.aba`;
  _sprDownloadText(_abaContent, filename);
  toast('ABA file downloaded');
}

function abaPrint() {
  // Temporarily mark aba-print-root so print stylesheet shows only it
  const root = document.getElementById('aba-print-root');
  if (root) {
    // Make it a direct child of body temporarily for the print selector
    document.body.appendChild(root);
    window.print();
    // Return it to its place
    const body = document.getElementById('aba-body');
    if (body) body.appendChild(root);
  } else {
    window.print();
  }
}


// ══════════════════════════════════════════════════════════════════════════════
// STOCK RECEIPTS  (Stage 6B)
// Read receipts tab, inline new-receipt form, save, delete
// Routes (server.py already done):
//   GET  /api/bills/<id>/receipts         → [{id, line_id, description, qty_ordered,
//                                             qty_received, received_date, reference, notes}]
//   POST /api/bills/<id>/receipts         → {ok, data: {id}}
//   DELETE /api/bills/<id>/receipts/<rid> → {ok}
// ══════════════════════════════════════════════════════════════════════════════

// ── Load & render receipts pane ───────────────────────────────────────────────
async function _rcptLoadPane(billId) {
  const pane = document.getElementById('bilt-receipts');
  if (!pane) return;
  // Preserve form if open; only show loading in the table area
  if (!document.getElementById('rcpt-form')) {
    pane.innerHTML = '<div class="det-empty det-loading-pad">Loading…</div>';
  }
  try {
    const rows = await apiFetch(`/api/bills/${billId}/receipts`) || [];
    _rcptRenderPane(billId, rows);
  } catch(e) {
    if (!document.getElementById('rcpt-form')) {
      pane.innerHTML = `<div class="det-empty det-loading-pad det-error">Failed to load receipts: ${esc(e.message)}</div>`;
    }
  }
}

function _rcptRenderPane(billId, rows) {
  const pane = document.getElementById('bilt-receipts');
  if (!pane) return;

  // Preserve any open form — only update the table container
  const formHtml = document.getElementById('rcpt-form')?.outerHTML || '';

  if (!rows.length) {
    pane.innerHTML = formHtml +
      `<div class="rcv-hdr-row">
        <span class="rcv-hdr-lbl">No stock receipts recorded.</span>
      </div>`;
    return;
  }

  const totalOrdered  = rows.reduce((s,r) => s + (r.qty_ordered  || 0), 0);
  const totalReceived = rows.reduce((s,r) => s + (r.qty_received || 0), 0);

  pane.innerHTML = formHtml + `
    <div class="rcv-det-tbl-wrap">
      <table class="det-lines rcv-det-tbl">
        <thead><tr>
          <th>Date</th>
          <th>Line / Item</th>
          <th class="th-r">Qty Ordered</th>
          <th class="th-r">Qty Received</th>
          <th>Reference</th>
          <th>Notes</th>
          <th></th>
        </tr></thead>
        <tbody>
          ${rows.map(r => `<tr>
            <td class="td-r-mono">${fmtDate(r.received_date)}</td>
            <td>${esc(r.description || '—')}</td>
            <td class="td-r-mono">${r.qty_ordered  != null ? r.qty_ordered  : '—'}</td>
            <td class="td-r-mono ${(r.qty_received||0)<(r.qty_ordered||0)?'col-amber':'col-green'}">${r.qty_received != null ? r.qty_received : '—'}</td>
            <td class="td-ref">${esc(r.reference || '—')}</td>
            <td class="col-ink3">${esc(r.notes || '')}</td>
            <td><button class="edt-rm-btn" title="Delete receipt" onclick="_rcptDelete(${billId},${r.id})">✕</button></td>
          </tr>`).join('')}
        </tbody>
        <tfoot>
          <tr class="rcv-tot-row">
            <td colspan="2" class="rcv-tot-lbl">Totals</td>
            <td class="rcv-tot-num">${totalOrdered}</td>
            <td class="rcv-tot-num ${totalReceived<totalOrdered?'col-amber':'col-green'}">${totalReceived}</td>
            <td colspan="3"></td>
          </tr>
        </tfoot>
      </table>
    </div>`;
}

// ── Receive Stock modal (Stage 6B) ────────────────────────────────────────────
// Matches BillReceiveStockDialog from bills_ui.py exactly:
//   • Only shows lines where item_id is set AND is_inventoried = true
//   • Shows Ordered / Received / Outstanding per line with qty inputs
//   • "Receive All Outstanding" fills outstanding qty into every input
//   • On post: sends {receipt_date, lines:[{line_id,item_id,qty,unit_price}]}
//     to existing POST /api/bills/<id>/receipts
//   • Shows "No inventoried items on this bill" if none qualify
// Data comes from new GET /api/bills/<id>/receive-lines endpoint.

async function _rcptNew(billId /*, lines — ignored, now fetched server-side */) {
  // Inject styles once
  if (!document.getElementById('rcv-styles')) {
    const s = document.createElement('style');
    s.id = 'rcv-styles';
    s.textContent = `
      .rcv-overlay{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:1200;display:none;align-items:center;justify-content:center}
      .rcv-overlay.open{display:flex}
      .rcv-box{background:var(--bg,#fff);border-radius:12px;width:min(780px,96vw);max-height:88vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 8px 40px rgba(0,0,0,.35)}
      .rcv-hdr{background:var(--accent);padding:14px 20px;display:flex;justify-content:space-between;align-items:flex-start;flex-shrink:0}
      .rcv-title{font-size:15px;font-weight:700;color:#fff}
      .rcv-sub{font-size:12px;color:rgba(255,255,255,.8);margin-top:2px}
      .rcv-close{background:none;border:none;color:#fff;font-size:18px;cursor:pointer;line-height:1;padding:2px 6px;opacity:.8}
      .rcv-close:hover{opacity:1}
      .rcv-body{flex:1;overflow-y:auto;padding:16px 20px}
      .rcv-footer{padding:12px 20px;border-top:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;background:var(--bg,#fff);flex-shrink:0}
      .rcv-date-row{display:flex;align-items:center;gap:10px;margin-bottom:12px}
      .rcv-date-row label{font-size:12px;font-weight:600;color:var(--ink2);white-space:nowrap}
      .rcv-col-hdr{display:grid;grid-template-columns:2fr 72px 72px 88px 88px 108px;gap:4px;padding:5px 8px;background:var(--bg);border-radius:4px;margin-bottom:3px;font-size:11px;font-weight:600;color:var(--ink2)}
      .rcv-col-hdr span,.rcv-row span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      .rcv-row{display:grid;grid-template-columns:2fr 72px 72px 88px 88px 108px;gap:4px;padding:5px 8px;align-items:center;font-size:12px;border-radius:4px}
      .rcv-row:nth-child(odd){background:var(--row-alt,rgba(0,0,0,.03))}
      .rcv-row input[type=number]{width:72px;padding:3px 6px;border:1px solid var(--border);border-radius:4px;background:var(--entry-bg,var(--bg));color:var(--ink);font-size:12px;text-align:right;font-family:'DM Mono',monospace}
      .rcv-num{text-align:right;font-family:'DM Mono',monospace}
      .rcv-status{font-size:11px;overflow:hidden;text-overflow:ellipsis}
    `;
    document.head.appendChild(s);
  }

  // Build overlay if not already in DOM
  let overlay = document.getElementById('rcv-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'rcv-overlay';
    overlay.className = 'rcv-overlay';
    overlay.innerHTML = `
      <div class="rcv-box">
        <div class="rcv-hdr">
          <div>
            <div class="rcv-title" id="rcv-title">Receive Stock</div>
            <div class="rcv-sub"  id="rcv-sub"></div>
          </div>
          <button class="rcv-close" onclick="rcvClose()">✕</button>
        </div>
        <div class="rcv-body" id="rcv-body">
          <div class="det-empty" style="padding:32px 0">Loading…</div>
        </div>
        <div class="rcv-footer">
          <button class="btn btn-outline" onclick="rcvClose()">Cancel</button>
          <div class="rcv-btn-row">
            <button class="btn" id="rcv-all-btn"
              style="display:none;background:var(--accent2,#2980b9);color:#fff;border:none"
              onclick="_rcvReceiveAll()">Receive All Outstanding</button>
            <button class="btn btn-primary" id="rcv-post-btn"
              style="display:none" onclick="_rcvPost()">Post Receipts</button>
          </div>
        </div>
      </div>`;
    document.body.appendChild(overlay);
  }

  // Reset and show
  document.getElementById('rcv-title').textContent = 'Receive Stock';
  document.getElementById('rcv-sub').textContent   = '';
  document.getElementById('rcv-body').innerHTML    = '<div class="det-empty det-loading-lg">Loading…</div>';
  document.getElementById('rcv-all-btn').style.display  = 'none';
  const _postBtn = document.getElementById('rcv-post-btn');
  _postBtn.style.display = 'none';
  _postBtn.disabled = false;
  _postBtn.textContent = 'Post Receipts';
  overlay._billId = billId;   // stash for _rcvPost / _rcvReceiveAll
  overlay.classList.add('open');

  // Fetch inventoried lines from new endpoint
  try {
    const d = await apiFetch(`/api/bills/${billId}/receive-lines`);
    _rcvRenderBody(d);
  } catch(e) {
    document.getElementById('rcv-body').innerHTML =
      `<div class="det-empty det-loading-lg det-error">Failed to load: ${esc(e.message)}</div>`;
  }
}

function rcvClose() {
  const ov = document.getElementById('rcv-overlay');
  if (ov) ov.classList.remove('open');
}

function _rcvRenderBody(d) {
  const lines  = d.lines || [];
  document.getElementById('rcv-title').textContent = `Receive Stock — ${d.bill_number || ''}`;
  document.getElementById('rcv-sub').textContent   = d.contact_name ? `Supplier: ${d.contact_name}` : '';

  const body    = document.getElementById('rcv-body');
  const allBtn  = document.getElementById('rcv-all-btn');
  const postBtn = document.getElementById('rcv-post-btn');

  if (!lines.length) {
    body.innerHTML = `<div class="det-empty det-loading-lg">No inventoried items on this bill.</div>`;
    allBtn.style.display  = 'none';
    postBtn.style.display = 'none';
    return;
  }

  allBtn.style.display  = '';
  postBtn.style.display = '';

  const today = isoToday();

  let html = `
    <div class="rcv-date-row">
      <label>Received Date:</label>
      <input class="edt-inp rcv-date-inp" type="date" id="rcv-date" value="${today}">
    </div>
    <p class="rcv-note">
      Enter qty received today for each item. Leave 0 to skip.
    </p>
    <div class="rcv-col-hdr">
      <span>Item</span>
      <span class="rcv-col-hdr">Ordered</span>
      <span class="rcv-col-hdr">Received</span>
      <span class="rcv-col-hdr">Outstanding</span>
      <span class="rcv-col-hdr">Receive Now</span>
      <span>Status</span>
    </div>`;

  lines.forEach((ln, i) => {
    const outstanding = ln.outstanding;
    const defVal      = outstanding > 0.001 ? outstanding.toFixed(2) : '0';
    // Initial status label mirroring tkinter _upd logic
    const total0      = ln.received;
    let   stText, stColor;
    if (total0 <= 0.001) {
      stText = 'Pending'; stColor = 'var(--ink3)';
    } else if (total0 >= ln.ordered - 0.001) {
      stText = 'Fully Received'; stColor = 'var(--green)';
    } else {
      stText = `Partial ${total0.toFixed(1)}/${ln.ordered.toFixed(1)}`; stColor = 'var(--amber)';
    }
    // After pre-filling outstanding the status will update via oninput
    html += `
      <div class="rcv-row"
           data-line-id="${ln.line_id}" data-item-id="${ln.item_id}"
           data-ordered="${ln.ordered}" data-received="${ln.received}"
           data-unit-price="${ln.unit_price}">
        <span title="${esc(ln.item_name)}">${esc(ln.item_name.length > 34 ? ln.item_name.slice(0,33)+'…' : ln.item_name)}</span>
        <span class="rcv-num col-ink2">${ln.ordered.toFixed(2)}</span>
        <span class="rcv-num col-green">${ln.received.toFixed(2)}</span>
        <span class="rcv-num ${outstanding > 0.001 ? 'col-red' : 'col-green'}">${outstanding.toFixed(2)}</span>
        <span class="span-r">
          <input type="number" id="rcv-qty-${i}" value="${defVal}"
                 min="0" step="any" oninput="_rcvUpdateStatus(this,${i})">
        </span>
        <span class="rcv-status" id="rcv-st-${i}" style="color:${stColor}">${stText}</span>
      </div>`;
  });

  body.innerHTML = html;
  // Store lines array on body element for receive-all and post
  body._rcvLines = lines;

  // Trigger status update for pre-filled values
  lines.forEach((_, i) => {
    const inp = document.getElementById(`rcv-qty-${i}`);
    if (inp) _rcvUpdateStatus(inp, i);
  });
}

function _rcvUpdateStatus(input, idx) {
  const row      = input.closest('.rcv-row');
  const ordered  = parseFloat(row.dataset.ordered)  || 0;
  const received = parseFloat(row.dataset.received) || 0;
  const now      = parseFloat(input.value) || 0;
  const total    = received + now;
  const st       = document.getElementById(`rcv-st-${idx}`);
  if (!st) return;
  if (total <= 0.001) {
    st.textContent = 'Pending';           st.style.color = 'var(--ink3)';
  } else if (total >= ordered - 0.001) {
    st.textContent = 'Fully Received';    st.style.color = 'var(--green)';
  } else {
    st.textContent = `Partial ${total.toFixed(1)}/${ordered.toFixed(1)}`;
    st.style.color = 'var(--amber)';
  }
}

function _rcvReceiveAll() {
  const body  = document.getElementById('rcv-body');
  const lines = body?._rcvLines || [];
  lines.forEach((ln, i) => {
    const inp = document.getElementById(`rcv-qty-${i}`);
    if (!inp) return;
    inp.value = ln.outstanding > 0.001 ? ln.outstanding.toFixed(2) : '0';
    _rcvUpdateStatus(inp, i);
  });
}

async function _rcvPost() {
  const overlay = document.getElementById('rcv-overlay');
  const billId  = overlay?._billId;
  if (!billId) return;

  const dateEl = document.getElementById('rcv-date');
  if (!dateEl?.value) { toast('Enter a received date', 'err'); return; }

  const body  = document.getElementById('rcv-body');
  const lines = body?._rcvLines || [];

  const toPost = [];
  for (let i = 0; i < lines.length; i++) {
    const ln  = lines[i];
    const qty = parseFloat(document.getElementById(`rcv-qty-${i}`)?.value || 0);
    if (qty > 0.001) {
      const outstanding = Math.max(0, ln.ordered - ln.received);
      if (qty > outstanding + 0.001) {
        toast(`${ln.item_name}: cannot receive ${qty.toFixed(2)} — only ${outstanding.toFixed(2)} outstanding`, 'err');
        return;
      }
      toPost.push({ line_id: ln.line_id, item_id: ln.item_id, qty, unit_price: ln.unit_price });
    }
  }

  if (!toPost.length) {
    toast('Enter a quantity > 0 for at least one item', 'err');
    return;
  }

  const summary = toPost.map(p => {
    const ln = lines.find(x => x.line_id === p.line_id);
    return `${ln?.item_name || 'Item'}: ${p.qty}`;
  }).join('\n');

  if (!await confirmDlg(`Post these stock receipts?\n\n${summary}`)) return;

  const btn = document.getElementById('rcv-post-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Posting…'; }

  try {
    const r = await fetch(`/api/bills/${billId}/receipts`, {
      method:  'POST',
      headers: {'Content-Type': 'application/json'},
      credentials: 'include',
      body:    JSON.stringify({ receipt_date: dateEl.value, lines: toPost }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed to post receipts');
    toast('Stock received');
    if (btn) { btn.disabled = false; btn.textContent = 'Post Receipts'; }
    rcvClose();
    _rcptLoadedFor = null;   // force receipts history to re-fetch
    // If the receipts tab is currently showing, refresh it
    _rcptLoadPane(billId);
    // Reload the bill detail so qty_received on lines updates
    if (_billSelected === billId) billOpen(billId);
  } catch(e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Post Receipts'; }
  }
}

// _rcptSave kept as no-op stub (was called from old inline form; form no longer rendered)
function _rcptSave() {}

// ── Delete ────────────────────────────────────────────────────────────────────
async function _rcptDelete(billId, rcptId) {
  if (!await confirmDlg('Delete this stock receipt?')) return;
  try {
    const r = await fetch(`/api/bills/${billId}/receipts/${rcptId}`, {
      method: 'DELETE', credentials: 'include',
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Delete failed');
    toast('Receipt deleted');
    _rcptLoadedFor = null;
    _rcptLoadPane(billId);
  } catch(e) {
    toast(e.message, 'err');
  }
}

// ─── Recurring templates ───────────────────────────────────────────────────────

async function _billFromTemplate() {
  let templates;
  try {
    const all = await apiFetch('/api/recurring');
    templates = (all || []).filter(t => t.template_type === 'Bill' && t.is_active && t.contact_id);
  } catch(e) { toast(e.message, 'err'); return; }

  if (!templates.length) {
    toast('No Bill templates found — create one in the Recurring module.', 'err'); return;
  }

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="min-width:500px;max-width:640px">
    <div class="modal-hdr"><strong>From Template</strong></div>
    <div class="modal-body" style="overflow-y:auto;max-height:60vh;padding:0">
      <table class="inv-list-table">
        <thead><tr><th>Template</th><th>Supplier</th><th>Frequency</th><th class="th-r">Total (inc GST)</th></tr></thead>
        <tbody>
          ${templates.map(t => {
            const lines = JSON.parse(t.lines_json || '[]');
            let total;
            if (lines.length) {
              total = lines.reduce((s, l) => {
                const ex = (parseFloat(l.quantity)||1) * (parseFloat(l.unit_price)||0);
                return s + ex + ((l.tax_code==='GST'||l.tax_code==='CAP') ? ex*0.1 : 0);
              }, 0);
            } else {
              const ex = parseFloat(t.amount) || 0;
              total = ex + (t.tax_code==='GST' ? ex*0.1 : 0);
            }
            return `<tr class="inv-row" style="cursor:pointer" onclick="_billApplyTemplate(${t.id},this.closest('.modal-bd'))">
              <td>${esc(t.name)}</td><td>${esc(t.contact_name||'—')}</td>
              <td>${esc(t.frequency)}</td><td class="td-r-mono">${fmt(Math.round(total*100)/100)}</td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>
    <div class="modal-foot">
      <button class="btn btn-outline" onclick="this.closest('.modal-bd').remove()">Cancel</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  bd.addEventListener('click', e => { if (e.target === bd) bd.remove(); });
}

async function _billApplyTemplate(tid, modalEl) {
  if (modalEl) modalEl.remove();
  let t;
  try { t = await apiFetch(`/api/recurring/${tid}`); }
  catch(e) { toast(e.message, 'err'); return; }

  const rawLines = JSON.parse(t.lines_json || '[]');
  const lines = rawLines.length
    ? rawLines.map(l => ({description:l.description||'',quantity:parseFloat(l.quantity)||1,
        unit_price:parseFloat(l.unit_price)||0,tax_code:l.tax_code||'GST',
        account_id:l.account_id||null,item_id:null}))
    : [{description:t.description||t.name||'',quantity:1,unit_price:parseFloat(t.amount)||0,
        tax_code:t.tax_code||'GST',account_id:t.account_id||null,item_id:null}];

  const data = {
    bill: {id:null,contact_id:t.contact_id||null,bill_date:isoToday(),due_date:isoAddDays(30),
      status:'Draft',bill_number:'',notes:t.description||'',
      internal_comments:'',subtotal:0,gst_total:0,total:0,amount_paid:0},
    lines,
  };
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = 'New Bill';
  await billEditOpen(data);
}

async function _billSaveAsTemplate() {
  const contactId = parseInt(document.getElementById('bedt-contact')?.value || 0) || null;
  const contactName = document.getElementById('bedt-contact')?.selectedOptions[0]?.text || '';
  const firstDesc = (_billEditLines||[]).find(l => l && l.description)?.description || '';
  const defName = [contactName, firstDesc].filter(Boolean).join(' — ') || 'New Template';

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="min-width:360px">
    <div class="modal-hdr"><strong>Save as Recurring Template</strong></div>
    <div class="modal-body" style="padding:18px 20px;display:flex;flex-direction:column;gap:14px">
      <label class="fld-lbl">Template name *
        <input type="text" id="bsat-name" class="fld" value="${esc(defName)}">
      </label>
      <label class="fld-lbl">Frequency
        <select id="bsat-freq" class="fld">
          ${['Weekly','Fortnightly','Monthly','Quarterly','Annual'].map(f=>`<option ${f==='Monthly'?'selected':''}>${f}</option>`).join('')}
        </select>
      </label>
      <label class="fld-lbl">Next due date
        <input type="date" id="bsat-due" class="fld" value="${isoToday()}">
      </label>
    </div>
    <div class="modal-foot" style="gap:8px">
      <button class="btn btn-outline" id="bsat-cancel">Cancel</button>
      <button class="btn btn-primary" id="bsat-ok">Save Template</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  document.getElementById('bsat-cancel').onclick = () => bd.remove();
  bd.addEventListener('click', e => { if (e.target === bd) bd.remove(); });

  document.getElementById('bsat-ok').onclick = async () => {
    const name = document.getElementById('bsat-name').value.trim();
    const due  = document.getElementById('bsat-due').value;
    if (!name || !due) { toast('Name and due date are required', 'err'); return; }
    bd.remove();
    const linesJson = JSON.stringify((_billEditLines||[])
      .filter(l => l && l.description)
      .map(l => ({description:l.description,quantity:l.quantity,unit_price:l.unit_price,
        tax_code:l.tax_code||'GST',account_id:l.account_id||null})));
    const payload = {
      name, template_type:'Bill',
      frequency: document.getElementById('bsat-freq').value,
      next_due: due, is_active: 1, contact_id: contactId,
      description: document.getElementById('bedt-notes')?.value.trim() || '',
      lines_json: linesJson,
    };
    try {
      const r = await fetch('/api/recurring',{method:'POST',credentials:'include',
        headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Failed');
      toast('Template saved');
    } catch(e) { toast(e.message, 'err'); }
  };
}

