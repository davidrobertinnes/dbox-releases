// help.js — In-app help viewer
// Prefix: _help

let _helpGuides  = null;
let _helpCurrent = 0;
let _helpQuery   = '';

async function pageHelp() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = `
    <div class="help-wrap">
      <div class="help-sidebar">
        <input id="help-search" class="help-search-input" type="search"
               placeholder="Search help…" oninput="_helpSearch(this.value)" autocomplete="off">
        <div id="help-nav" class="help-nav"></div>
      </div>
      <div id="help-pane" class="help-pane">
        <div class="state-loading">Loading…</div>
      </div>
    </div>`;

  if (!_helpGuides) {
    try {
      _helpGuides = await apiFetch('/api/help');
    } catch(e) {
      document.getElementById('help-pane').innerHTML =
        `<p style="color:var(--red);padding:24px">Could not load help content.</p>`;
      return;
    }
  }
  _helpRenderNav(_helpGuides);
  _helpShow(_helpCurrent);
}

function _helpRenderNav(guides) {
  const nav = document.getElementById('help-nav');
  if (!nav) return;
  nav.innerHTML = guides.map((g, i) =>
    `<div class="help-nav-item${i===_helpCurrent?' active':''}"
          onclick="_helpShow(${i})">${g.title}</div>`
  ).join('');
}

function _helpShow(idx) {
  if (!_helpGuides) return;
  _helpCurrent = idx;
  const g = _helpGuides[idx];

  // Update nav highlight
  document.querySelectorAll('.help-nav-item').forEach((el, i) =>
    el.classList.toggle('active', i === idx));

  const q = _helpQuery.toLowerCase();

  const html = `
    <div class="help-guide-hdr">
      <div class="help-guide-title">${esc(g.title)}</div>
      <div class="help-guide-sub">${esc(g.subtitle)}</div>
    </div>
    ${g.sections.map(s => `
      <div class="help-section">
        <div class="help-sec-hdr">${esc(s.heading)}</div>
        <div class="help-sec-body">${_helpFormatBody(s.body, q)}</div>
      </div>`).join('')}`;

  const pane = document.getElementById('help-pane');
  if (pane) { pane.innerHTML = html; pane.scrollTop = 0; }
}

function _helpFormatBody(text, highlight) {
  const lines = text.split('\n');
  let out = '';
  let inCode = false;

  for (const raw of lines) {
    const line = raw.trimEnd();
    const isCode   = line.startsWith('    ') || line.startsWith('\t');
    const isBullet = line.trimStart().startsWith('•');
    const isEmpty  = line.trim() === '';

    if (isEmpty) {
      if (inCode) { out += '</pre>'; inCode = false; }
      out += '<br>';
      continue;
    }
    if (isCode && !isBullet) {
      if (!inCode) { out += '<pre class="help-code">'; inCode = true; }
      out += esc(line.trim()) + '\n';
      continue;
    }
    if (inCode) { out += '</pre>'; inCode = false; }

    const content = highlight ? _helpHL(esc(line.trim()), highlight) : esc(line.trim());
    if (isBullet) {
      out += `<div class="help-bullet">${content}</div>`;
    } else {
      out += `<div class="help-para">${content}</div>`;
    }
  }
  if (inCode) out += '</pre>';
  return out;
}

function _helpHL(html, q) {
  if (!q) return html;
  const re = new RegExp(`(${q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')})`, 'gi');
  return html.replace(re, '<mark class="help-mark">$1</mark>');
}


function _helpSearch(q) {
  _helpQuery = q.trim();
  if (!_helpGuides) return;
  const ql = _helpQuery.toLowerCase();

  if (!ql) {
    _helpRenderNav(_helpGuides);
    _helpShow(_helpCurrent);
    return;
  }

  // Filter sidebar to matching guides
  const matched = _helpGuides
    .map((g, i) => ({ g, i }))
    .filter(({ g }) =>
      g.title.toLowerCase().includes(ql) ||
      g.subtitle.toLowerCase().includes(ql) ||
      g.sections.some(s =>
        s.heading.toLowerCase().includes(ql) ||
        s.body.toLowerCase().includes(ql)
      )
    );

  const nav = document.getElementById('help-nav');
  if (!nav) return;
  if (!matched.length) {
    nav.innerHTML = '<div style="padding:12px;color:var(--ink3);font-size:13px">No results</div>';
    document.getElementById('help-pane').innerHTML =
      '<div style="padding:24px;color:var(--ink3)">No help topics match your search.</div>';
    return;
  }

  nav.innerHTML = matched.map(({ g, i }) =>
    `<div class="help-nav-item${i===_helpCurrent?' active':''}"
          onclick="_helpShow(${i})">${_helpHL(esc(g.title), ql)}</div>`
  ).join('');

  // Show first match if current isn't in results
  if (!matched.find(({ i }) => i === _helpCurrent)) {
    _helpCurrent = matched[0].i;
    document.querySelectorAll('.help-nav-item')[0]?.classList.add('active');
  }
  _helpShow(_helpCurrent);
}
