// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ═══════════════════════════════════════════════════════════════════════════
// INVENTORY MODULE
// Tabs: Stock Levels | Movements | Low Stock
// Mirrors InventoryFrame in ui/items_ui.py
// ═══════════════════════════════════════════════════════════════════════════

// ── ATO Livestock Prescribed Values (ITAA 1997 s70-75) ─────────────────────
const _stkAtoCategories = [
  { key: 'cattle_horses_deer', label: 'Cattle / Horses / Deer',  prescribed: 20.00 },
  { key: 'pigs',               label: 'Pigs',                    prescribed: 12.00 },
  { key: 'emus',               label: 'Emus / Ostriches',        prescribed:  8.00 },
  { key: 'sheep_goats',        label: 'Sheep / Goats',           prescribed:  4.00 },
  { key: 'poultry',            label: 'Poultry',                 prescribed:  0.35 },
];
function _stkAtoValue(key) {
  return (_stkAtoCategories.find(c => c.key === key) || {}).prescribed ?? null;
}

// ── Det panel helpers (safe wrappers — detOpen/detClose defined in invoices.js) ─
function _detOpen()  { if (typeof detOpen  === 'function') detOpen();  else { document.getElementById('det-overlay')?.classList.add('open'); document.getElementById('det-panel')?.classList.add('open'); } }
function _detClose() { if (typeof detClose === 'function') detClose(); else { document.getElementById('det-overlay')?.classList.remove('open'); document.getElementById('det-panel')?.classList.remove('open'); } }

let _stkTab = 'stock';          // active tab: 'stock' | 'movements' | 'low'
let _stkItems = [];             // cached stock items for filter/sort
let _stkSortCol = null;
let _stkSortAsc = true;
let _stkSearch  = '';
let _stkAccCache = null;        // cached accounts list for settings form

// ── Movement filter state ──────────────────────────────────────────────────
function _stkMovDefaults() {
  const today = new Date();
  const fy = today.getMonth() >= 6 ? today.getFullYear() : today.getFullYear() - 1;
  const pad = n => String(n).padStart(2,'0');
  const todayStr = `${today.getFullYear()}-${pad(today.getMonth()+1)}-${pad(today.getDate())}`;
  return { from: `${fy}-07-01`, to: todayStr, type: 'All' };
}
let _stkMovFilter = _stkMovDefaults();

// ═══════════════════════════════════════════════════════════════════════════
// ENTRY POINT
// ═══════════════════════════════════════════════════════════════════════════

async function pageInventory() {
  document.getElementById('module-content').innerHTML = `
    <div class="inv-toolbar">
      <input class="inv-search" id="stk-q" placeholder="Search items…" value="${_stkSearch}"
        oninput="_stkSearch=this.value;if(_stkTab==='stock')_stkRenderStock()">
      <div style="display:flex;gap:6px;flex-wrap:wrap">
        <button class="btn btn-sm btn-primary" onclick="_stkReceiveStock()">🔼 Receive Stock</button>
        <button class="btn btn-sm btn-outline" onclick="_stkAdjustStock()">📦 Adjust Stock</button>
        <button class="btn btn-sm btn-outline" onclick="_stkStocktake()">📋 Stocktake</button>
        <button class="btn btn-sm btn-outline" onclick="_stkValuationPdf()">📄 Valuation PDF</button>
        <button class="btn btn-sm btn-outline" onclick="pageInventory()">⟳ Refresh</button>
      </div>
    </div>
    <div class="inv-banner" id="inv-banner">
      <div class="inv-card"><div class="inv-card-lbl">Tracked Items</div><div class="inv-card-val" id="inv-s-tracked">—</div></div>
      <div class="inv-card"><div class="inv-card-lbl">Stock Value</div><div class="inv-card-val col-green" id="inv-s-value">—</div></div>
      <div class="inv-card"><div class="inv-card-lbl">Low Stock</div><div class="inv-card-val col-amber" id="inv-s-low">—</div></div>
      <div class="inv-card"><div class="inv-card-lbl">Negative Stock</div><div class="inv-card-val col-red" id="inv-s-neg">—</div></div>
    </div>
    <div class="inv-tabs">
      <div class="inv-tab active" id="inv-tab-stock"    onclick="_stkSwitchTab('stock')">📦 Stock Levels</div>
      <div class="inv-tab"        id="inv-tab-movements" onclick="_stkSwitchTab('movements')">📋 Movements</div>
      <div class="inv-tab"        id="inv-tab-low"      onclick="_stkSwitchTab('low')">⚠ Low Stock</div>
    </div>
    <div id="inv-tab-body"></div>
  `;

  await _stkLoadAll();
}

// ═══════════════════════════════════════════════════════════════════════════
// TAB SWITCH
// ═══════════════════════════════════════════════════════════════════════════

function _stkSwitchTab(tab) {
  _stkTab = tab;
  ['stock','movements','low'].forEach(t => {
    document.getElementById(`inv-tab-${t}`)?.classList.toggle('active', t === tab);
  });
  if (tab === 'stock')     _stkRenderStock();
  if (tab === 'movements') _stkRenderMovements();
  if (tab === 'low')       _stkRenderLow();
}

// ═══════════════════════════════════════════════════════════════════════════
// DATA LOAD
// ═══════════════════════════════════════════════════════════════════════════

async function _stkLoadAll() {
  try {
    const [summary, items, analytics] = await Promise.all([
      apiFetch('/api/inventory/summary'),
      apiFetch('/api/inventory/items'),
      apiFetch('/api/inventory/analytics'),
    ]);
    _stkRenderBanner(summary);
    // Merge analytics into items
    const an = analytics || {};
    _stkItems = (items || []).map(it => ({
      ...it,
      _an: an[it.id] || {},
    }));
    _stkSwitchTab(_stkTab);
  } catch(e) {
    document.getElementById('inv-tab-body').innerHTML =
      `<div class="state-error">Failed to load inventory: ${esc(String(e))}</div>`;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// BANNER
// ═══════════════════════════════════════════════════════════════════════════

function _stkRenderBanner(s) {
  const $ = id => document.getElementById(id);
  $('inv-s-tracked').textContent = s.tracked_items ?? '—';
  $('inv-s-value').textContent   = s.total_stock_value != null
    ? fmt(s.total_stock_value) : '—';
  const lowEl = $('inv-s-low');
  lowEl.textContent = s.low_stock_count ?? '—';
  lowEl.className = `inv-card-val ${(s.low_stock_count > 0) ? 'col-amber' : ''}`;
  const negEl = $('inv-s-neg');
  negEl.textContent = s.negative_stock_count ?? '—';
  negEl.className = `inv-card-val ${(s.negative_stock_count > 0) ? 'col-red' : ''}`;
}

// ═══════════════════════════════════════════════════════════════════════════
// STOCK LEVELS TAB
// ═══════════════════════════════════════════════════════════════════════════

function _stkRenderStock() {
  const body = document.getElementById('inv-tab-body');
  if (!_stkItems.length) {
    body.innerHTML = `<div class="state-empty">No inventoried items found.<br>
      Enable inventory tracking on an item via <a class="lnk-accent" onclick="navigate('items')">Item Catalogue</a>.</div>`;
    return;
  }

  const cols = [
    { key: 'code',        label: 'Code',        cls: '' },
    { key: 'name',        label: 'Name',        cls: '' },
    { key: 'qty_on_hand', label: 'On Hand',     cls: 'td-r-mono' },
    { key: '_price',      label: 'Sale Price',  cls: 'td-r-mono' },
    { key: '_margin',     label: 'Margin %',    cls: 'td-r-mono' },
    { key: 'unit_cost',   label: 'Avg Cost',    cls: 'td-r-mono' },
    { key: '_cost6m',     label: 'Cost (6m)',   cls: 'td-r-mono' },
    { key: '_value',      label: 'Value',       cls: 'td-r-mono-bold' },
    { key: '_sold',       label: 'Sold/Mo',     cls: 'td-r-mono' },
    { key: '_cover',      label: 'Mths Cover',  cls: 'td-r-mono' },
    { key: 'reorder_level',label: 'Reorder Lvl',cls: 'td-r-mono' },
    { key: 'location',    label: 'Location',    cls: '' },
    { key: '_status',     label: 'Status',      cls: '' },
  ];

  const thHTML = cols.map(c => {
    const sorted = _stkSortCol === c.key;
    const arrow  = sorted ? (_stkSortAsc ? ' ↑' : ' ↓') : '';
    return `<th class="sortable${sorted?' sorted':''}" onclick="_stkSort('${c.key}')">${c.label}${arrow}</th>`;
  }).join('');

  const _allSorted = _stkSortedItems();
  const q = _stkSearch.trim().toLowerCase();
  const sorted = q ? _allSorted.filter(it =>
    (it.name||'').toLowerCase().includes(q) ||
    (it.code||'').toLowerCase().includes(q) ||
    (it.location||'').toLowerCase().includes(q)
  ) : _allSorted;

  const rowsHTML = sorted.map(it => {
    const qty   = parseFloat(it.qty_on_hand || 0);
    const cost  = parseFloat(it.unit_cost   || 0);
    const price = parseFloat(it.unit_price  || 0);
    const rl    = parseFloat(it.reorder_level || 0);
    const an    = it._an || {};
    const recentCost = an.avg_cost_recent;
    const costForMargin = recentCost != null ? recentCost : cost;

    const marginStr = (price > 0 && costForMargin > 0)
      ? `${((price - costForMargin) / price * 100).toFixed(1)}%` : '—';
    const cost6mStr = recentCost != null ? `$${recentCost.toFixed(4)}` : '—';
    const soldStr   = an.avg_sold_per_month != null ? an.avg_sold_per_month.toFixed(1) : '—';
    const coverStr  = an.months_cover       != null ? an.months_cover.toFixed(1)       : '—';
    const valueStr  = `$${(qty * cost).toLocaleString('en-AU',{minimumFractionDigits:2,maximumFractionDigits:2})}`;
    const rlStr     = rl > 0 ? rl.toFixed(2) : '—';

    const isNeg      = qty < 0;
    const isLow      = rl > 0 && qty <= rl;
    const isBelowCst = price > 0 && costForMargin > 0 && price < costForMargin;
    const rowCls = isNeg ? 'inv-row-neg' : isLow ? 'inv-row-low' : isBelowCst ? 'inv-row-below' : '';
    const statusTxt = isNeg ? '⚠ OVERSOLD' : isLow ? '⚠ Low' : isBelowCst ? '⚠ Below cost' : 'OK';
    const statusCls = isNeg ? 'col-red' : isLow ? 'col-amber' : isBelowCst ? 'col-amber' : 'col-green';

    return `<tr class="${rowCls}" onclick="_stkOpenItem(${it.id})" style="cursor:pointer">
      <td>${esc(it.code||'')}</td>
      <td>${esc(it.name)}</td>
      <td class="td-r-mono">${qty.toFixed(2)}</td>
      <td class="td-r-mono">${price > 0 ? fmt(price) : '—'}</td>
      <td class="td-r-mono">${marginStr}</td>
      <td class="td-r-mono">$${cost.toFixed(4)}</td>
      <td class="td-r-mono">${cost6mStr}</td>
      <td class="td-r-mono-bold">${valueStr}</td>
      <td class="td-r-mono">${soldStr}</td>
      <td class="td-r-mono">${coverStr}</td>
      <td class="td-r-mono">${rlStr}</td>
      <td>${esc(it.location||'')}</td>
      <td class="${statusCls}">${statusTxt}</td>
    </tr>`;
  }).join('');

  body.innerHTML = `
    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table inv-tbl">
        <thead><tr>${thHTML}</tr></thead>
        <tbody>${rowsHTML || `<tr class="tbl-empty-row"><td colspan="13">${q?'No items match your search':'No items'}</td></tr>`}</tbody>
      </table>
    </div></div>
    <div style="margin-top:8px"><span class="count-pill">${sorted.length}${q?' of '+_stkItems.length:''} item${_stkItems.length!==1?'s':''}</span></div>
    <div class="inv-hint">Click a row to view movements for that item</div>
  `;
}

function _stkSort(col) {
  if (_stkSortCol === col) {
    _stkSortAsc = !_stkSortAsc;
  } else {
    _stkSortCol = col;
    _stkSortAsc = true;
  }
  _stkRenderStock();
}

function _stkSortedItems() {
  if (!_stkSortCol) return _stkItems;
  return [..._stkItems].sort((a, b) => {
    let av = _stkSortVal(a, _stkSortCol);
    let bv = _stkSortVal(b, _stkSortCol);
    if (av == null) av = typeof bv === 'number' ? -Infinity : '';
    if (bv == null) bv = typeof av === 'number' ? -Infinity : '';
    const cmp = (typeof av === 'number' && typeof bv === 'number')
      ? av - bv
      : String(av).localeCompare(String(bv), undefined, { numeric: true });
    return _stkSortAsc ? cmp : -cmp;
  });
}

function _stkSortVal(it, col) {
  const an = it._an || {};
  const numOrNull = v => (v != null && v !== '') ? parseFloat(v) : null;
  switch(col) {
    case 'code':         return (it.code||'').toLowerCase();
    case 'name':         return (it.name||'').toLowerCase();
    case 'qty_on_hand':  return numOrNull(it.qty_on_hand);
    case '_price':       return numOrNull(it.unit_price);
    case 'unit_cost':    return numOrNull(it.unit_cost);
    case 'reorder_level':return numOrNull(it.reorder_level);
    case 'location':     return (it.location||'').toLowerCase();
    case '_value': {
      const q = parseFloat(it.qty_on_hand||0), c = parseFloat(it.unit_cost||0);
      return q * c;
    }
    case '_margin': {
      const p = parseFloat(it.unit_price||0);
      const rc = an.avg_cost_recent;
      const cf = rc != null ? rc : parseFloat(it.unit_cost||0);
      return (p > 0 && cf > 0) ? (p - cf) / p * 100 : null;
    }
    case '_cost6m':  return an.avg_cost_recent ?? null;
    case '_sold':    return an.avg_sold_per_month ?? null;
    case '_cover':   return an.months_cover ?? null;
    case '_status': {
      const q = parseFloat(it.qty_on_hand||0);
      const rl = parseFloat(it.reorder_level||0);
      if (q < 0) return 0;
      if (rl > 0 && q <= rl) return 1;
      return 2;
    }
    default: return null;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// MOVEMENTS TAB
// ═══════════════════════════════════════════════════════════════════════════

function _stkRenderMovements() {
  const f = _stkMovFilter;
  const body = document.getElementById('inv-tab-body');
  body.innerHTML = `
    <div class="inv-mov-filters">
      <div>
        <label class="edt-lbl">From</label>
        <input class="edt-inp" type="date" id="inv-mov-from" value="${f.from}" onchange="_stkMovFilterChange()">
      </div>
      <div>
        <label class="edt-lbl">To</label>
        <input class="edt-inp" type="date" id="inv-mov-to" value="${f.to}" onchange="_stkMovFilterChange()">
      </div>
      <div>
        <label class="edt-lbl">Type</label>
        <select class="edt-sel" id="inv-mov-type" onchange="_stkMovFilterChange()">
          ${['All','PURCHASE','SALE','ADJUSTMENT','WRITE_OFF','RETURN_IN','RETURN_OUT',
              'NATURAL_INCREASE','DEATH','PRIVATE_USE']
            .map(t => `<option${t===f.type?' selected':''}>${t}</option>`).join('')}
        </select>
      </div>
      <button class="btn btn-sm btn-primary" onclick="_stkLoadMovements()">🔍 Filter</button>
    </div>
    <div id="inv-mov-body"><div class="state-loading">Loading…</div></div>
  `;
  _stkLoadMovements();
}

function _stkMovFilterChange() {
  _stkMovFilter.from = document.getElementById('inv-mov-from')?.value || _stkMovFilter.from;
  _stkMovFilter.to   = document.getElementById('inv-mov-to')?.value   || _stkMovFilter.to;
  _stkMovFilter.type = document.getElementById('inv-mov-type')?.value || _stkMovFilter.type;
}

async function _stkLoadMovements() {
  _stkMovFilterChange();
  const { from, to, type } = _stkMovFilter;
  const movBody = document.getElementById('inv-mov-body');
  if (!movBody) return;
  movBody.innerHTML = '<div class="state-loading">Loading…</div>';

  try {
    let url = `/api/inventory/movements?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`;
    if (type !== 'All') url += `&type=${encodeURIComponent(type)}`;
    const movs = await apiFetch(url);

    const INBOUND = new Set(['PURCHASE','ADJUSTMENT','RETURN_IN','NATURAL_INCREASE']);
    if (!movs.length) {
      movBody.innerHTML = '<div class="state-empty">No movements in this range.</div>';
      return;
    }

    const rows = movs.map(m => {
      const qty = parseFloat(m.qty || 0);
      const inbound = INBOUND.has(m.movement_type);
      const qtyCls  = inbound ? 'inv-qty-in' : 'inv-qty-out';
      return `<tr>
        <td>${fmtDate(m.movement_date)}</td>
        <td><span class="inv-mov-badge ${m.movement_type.toLowerCase()}">${m.movement_type}</span></td>
        <td>${esc(m.item_code ? m.item_code + '  ' : '')}${esc(m.item_name||'')}</td>
        <td class="td-r-mono ${qtyCls}">${qty >= 0 ? '+' : ''}${qty.toFixed(2)}</td>
        <td class="td-r-mono">${m.unit_cost != null ? '$'+parseFloat(m.unit_cost).toFixed(4) : '—'}</td>
        <td class="td-r-mono">${m.total_cost != null ? fmt(m.total_cost) : '—'}</td>
        <td class="td-r-mono">${m.unit_price != null ? fmt(m.unit_price) : '—'}</td>
        <td>${esc(m.reference||'')}</td>
        <td class="td-sm">${esc(m.notes||'')}</td>
      </tr>`;
    }).join('');

    movBody.innerHTML = `
      <div class="inv-list-panel"><div class="tbl-overflow-x">
        <table class="inv-list-table">
          <thead><tr>
            <th>Date</th><th>Type</th><th>Item</th>
            <th class="th-r">Qty</th><th class="th-r">Unit Cost</th>
            <th class="th-r">Total Cost</th><th class="th-r">Unit Price</th>
            <th>Reference</th><th>Notes</th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div></div>
      <div class="count-pill">${movs.length} movement${movs.length!==1?'s':''}</div>
    `;
  } catch(e) {
    movBody.innerHTML = `<div class="state-error">Error loading movements: ${esc(String(e))}</div>`;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// LOW STOCK TAB
// ═══════════════════════════════════════════════════════════════════════════

function _stkRenderLow() {
  const body = document.getElementById('inv-tab-body');

  try {
    const lowItems = _stkItems.filter(it =>
      parseFloat(it.reorder_level || 0) > 0 &&
      parseFloat(it.qty_on_hand   || 0) <= parseFloat(it.reorder_level || 0)
    );

    if (!lowItems.length) {
      body.innerHTML = `<div class="state-empty">✓ No items at or below reorder level.</div>`;
      return;
    }

    const rows = lowItems.map(it => {
      const qty = parseFloat(it.qty_on_hand || 0);
      const rl  = parseFloat(it.reorder_level || 0);
      const rq  = parseFloat(it.reorder_qty  || 0);
      const shortfall = Math.max(0, rl - qty);
      const isNeg = qty < 0;
      const rowCls = isNeg ? 'inv-row-neg' : 'inv-row-low';

      // Last movement — we don't have it in the items list, show — for now
      return `<tr class="${rowCls}" onclick="_stkOpenItem(${it.id})" style="cursor:pointer">
        <td>${esc(it.code||'')}</td>
        <td>${esc(it.name)}</td>
        <td class="td-r-mono ${isNeg?'col-red':'col-amber'}">${qty.toFixed(2)}</td>
        <td class="td-r-mono">${rl.toFixed(2)}</td>
        <td class="td-r-mono col-red">${shortfall.toFixed(2)}</td>
        <td class="td-r-mono">${rq > 0 ? rq.toFixed(2) : '—'}</td>
        <td class="td-sm">${esc(it.location||'')}</td>
      </tr>`;
    }).join('');

    body.innerHTML = `
      <div class="inv-low-info">Items at or below reorder level — consider placing a purchase order.</div>
      <div class="inv-list-panel"><div class="tbl-overflow-x">
        <table class="inv-list-table">
          <thead><tr>
            <th>Code</th><th>Name</th>
            <th class="th-r">On Hand</th><th class="th-r">Reorder Level</th>
            <th class="th-r">Shortfall</th><th class="th-r">Reorder Qty</th>
            <th>Location</th>
          </tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div></div>
      <div class="count-pill">${lowItems.length} item${lowItems.length!==1?'s':''} need attention</div>
    `;
  } catch(e) {
    body.innerHTML = `<div class="state-error">Error: ${esc(String(e))}</div>`;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// ITEM DRILL-DOWN — switch to movements tab filtered to this item
// ═══════════════════════════════════════════════════════════════════════════

async function _stkOpenItem(itemId) {
  // Show movement history for a specific item in a slide-over detail panel
  const item = _stkItems.find(it => it.id === itemId);
  if (!item) return;
  const qty   = parseFloat(item.qty_on_hand || 0);
  const cost  = parseFloat(item.unit_cost   || 0);
  const price = parseFloat(item.unit_price  || 0);
  const rl    = parseFloat(item.reorder_level || 0);
  const an    = item._an || {};

  // Build detail HTML
  const field = (label, val) =>
    `<div class="det-field"><div class="det-lbl">${label}</div><div class="det-val">${val}</div></div>`;

  const recentCost = an.avg_cost_recent;
  const cfm = recentCost != null ? recentCost : cost;
  const margin = (price > 0 && cfm > 0)
    ? ((price - cfm) / price * 100).toFixed(1) + '%' : '—';

  const isNeg  = qty < 0;
  const isLow  = rl > 0 && qty <= rl;
  const status = isNeg ? '<span class="col-red">⚠ OVERSOLD</span>'
               : isLow ? '<span class="col-amber">⚠ Low Stock</span>'
               : '<span class="col-green">OK</span>';

  document.getElementById('det-title').textContent = item.name;
  document.getElementById('det-body').innerHTML = `
    <div class="det-section">
      <div class="det-section-hdr">Stock Position</div>
      ${field('Code',         esc(item.code||'—'))}
      ${field('On Hand',      `<span class="det-val-lg ${isNeg?'col-red':isLow?'col-amber':''}">${qty.toFixed(2)}</span>`)}
      ${field('Status',       status)}
      ${field('Reorder Level',rl > 0 ? rl.toFixed(2) : '—')}
      ${field('Reorder Qty',  parseFloat(item.reorder_qty||0) > 0 ? parseFloat(item.reorder_qty).toFixed(2) : '—')}
      ${field('Location',     esc(item.location||'—'))}
    </div>
    <div class="det-section">
      <div class="det-section-hdr">Pricing & Cost</div>
      ${field('Sale Price',   price > 0 ? fmt(price) : '—')}
      ${field('Avg Cost',     cost > 0  ? '$'+cost.toFixed(4) : '—')}
      ${field('Cost (6m)',    recentCost != null ? '$'+recentCost.toFixed(4) : '—')}
      ${field('Margin',       margin)}
      ${field('Stock Value',  fmt(qty * cost))}
    </div>
    <div class="det-section">
      <div class="det-section-hdr">Analytics (6 months)</div>
      ${field('Avg Sold/Mo',  an.avg_sold_per_month != null ? an.avg_sold_per_month.toFixed(1) : '—')}
      ${field('Total Sold',   an.total_sold != null ? an.total_sold.toFixed(0) : '—')}
      ${field('Months Cover', an.months_cover != null ? an.months_cover.toFixed(1) : '—')}
    </div>
    <div class="det-section">
      <div class="det-section-hdr">Actions</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:6px">
        <button class="btn btn-sm btn-primary" onclick="_stkEditSettings(${itemId})">⚙ Edit Settings</button>
        <button class="btn btn-sm btn-outline" onclick="_stkAdjustStock(${itemId})">📦 Adjust Stock</button>
        <button class="btn btn-sm btn-outline" onclick="_stkReceiveStock(${itemId})">🔼 Receive Stock</button>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${!item.is_livestock ? `<button class="btn btn-sm btn-outline" onclick="_stkRecordMovement(${itemId},'SALE','Record Sale (Manual)')">💲 Record Sale</button>` : ''}
        <button class="btn btn-sm btn-outline" onclick="_stkRecordMovement(${itemId},'WRITE_OFF','Write Off Stock')">🗑 Write Off</button>
        <button class="btn btn-sm btn-outline" onclick="_stkRecordMovement(${itemId},'RETURN_IN','Customer Return (In)')">↩ Return In</button>
        <button class="btn btn-sm btn-outline" onclick="_detClose();_stkSwitchTab('movements')">📋 View Movements</button>
      </div>
      ${item.is_livestock ? `
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">
          <button class="btn btn-sm btn-outline" onclick="_stkRecordMovement(${itemId},'NATURAL_INCREASE','Natural Increase')">🐄 Natural Increase</button>
          <button class="btn btn-sm btn-outline" onclick="_stkRecordMovement(${itemId},'DEATH','Record Deaths')">Record Deaths</button>
          <button class="btn btn-sm btn-outline" onclick="_stkRecordMovement(${itemId},'PRIVATE_USE','Private Use')">Private Use</button>
        </div>
        <div style="margin-top:8px;font-size:0.82em;color:var(--ink3)">Sales are automatically recorded when an invoice is raised — no manual sale entry needed.</div>
      ` : ''}
    </div>
    <div id="inv-det-movements">
      <div class="det-section-hdr" style="margin-top:16px">Recent Movements</div>
      <div class="state-loading">Loading…</div>
    </div>
  `;
  _detOpen();

  // Load recent movements for this item
  try {
    const movs = await apiFetch(`/api/inventory/movements?item_id=${itemId}&limit=20`);
    const INBOUND = new Set(['PURCHASE','ADJUSTMENT','RETURN_IN','NATURAL_INCREASE']);
    const movHTML = movs.length
      ? movs.map(m => {
          const qty = parseFloat(m.qty || 0);
          const inbound = INBOUND.has(m.movement_type);
          return `<div class="inv-det-mov-row">
            <span class="inv-mov-badge ${m.movement_type.toLowerCase()}">${m.movement_type}</span>
            <span class="inv-det-mov-date">${fmtDate(m.movement_date)}</span>
            <span class="inv-det-mov-qty ${inbound?'inv-qty-in':'inv-qty-out'}">${qty>=0?'+':''}${qty.toFixed(2)}</span>
            <span class="inv-det-mov-ref">${esc(m.reference||'')}</span>
          </div>`;
        }).join('')
      : '<div class="tbl-empty-sm">No movements recorded.</div>';
    document.getElementById('inv-det-movements').innerHTML =
      `<div class="det-section-hdr" style="margin-top:16px">Recent Movements</div>${movHTML}`;
  } catch(e) {
    document.getElementById('inv-det-movements').innerHTML =
      '<div class="tbl-empty-sm">Could not load movements.</div>';
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// TOOLBAR ACTIONS — stubs (require dialogs or navigate to items)
// ═══════════════════════════════════════════════════════════════════════════

function _stkReceiveStock(itemId) {
  // Receive stock is done via Bills → Receive Stock in the web UI.
  // For now, guide the user there.
  alert('To receive stock, open the relevant supplier bill and use the Receive Stock button.\n\nNavigating to Bills…');
  navigate('bills');
}

async function _stkAdjustStock(itemId) {
  // Simple stock adjustment dialog
  const item = itemId ? _stkItems.find(it => it.id === itemId) : null;

  // Build item picker options
  const opts = _stkItems.map(it =>
    `<option value="${it.id}"${it.id===itemId?' selected':''}>${esc(it.name)}${it.code?' ['+it.code+']':''}</option>`
  ).join('');

  const html = `
    <div class="edt-body-pad">
      <div class="edt-field-mb">
        <label class="edt-lbl">Item</label>
        <select class="edt-sel" id="adj-item-id" onchange="_stkAdjItemChange()">${opts}</select>
      </div>
      <div class="edt-field-mb">
        <label class="edt-lbl">Current On Hand</label>
        <div id="adj-current" class="det-val">—</div>
      </div>
      <div class="edt-field-mb">
        <label class="edt-lbl">New Quantity (count result)</label>
        <input class="edt-inp" type="number" id="adj-new-qty" step="0.01" placeholder="0.00">
      </div>
      <div class="edt-field-mb">
        <label class="edt-lbl">Reason</label>
        <input class="edt-inp" type="text" id="adj-reason" value="Stock count correction">
      </div>
      <div class="edt-field-mb">
        <label class="edt-lbl">Date</label>
        <input class="edt-inp" type="date" id="adj-date" value="${isoToday()}">
      </div>
    </div>
  `;

  _detClose();
  document.getElementById('det-title').textContent = '📦 Adjust Stock';
  document.getElementById('det-body').innerHTML = html +
    `<div style="display:flex;gap:8px;padding:0 16px 16px">
      <button class="btn btn-sm btn-primary" onclick="_stkAdjSave()">Save Adjustment</button>
      <button class="btn btn-sm btn-outline" onclick="_detClose()">Cancel</button>
     </div>`;
  _detOpen();
  _stkAdjItemChange();
}

function _stkAdjItemChange() {
  const sel = document.getElementById('adj-item-id');
  if (!sel) return;
  const id = parseInt(sel.value);
  const item = _stkItems.find(it => it.id === id);
  const el = document.getElementById('adj-current');
  if (el && item) el.textContent = parseFloat(item.qty_on_hand || 0).toFixed(2);
}

async function _stkAdjSave() {
  const itemId  = parseInt(document.getElementById('adj-item-id')?.value);
  const newQty  = parseFloat(document.getElementById('adj-new-qty')?.value);
  const reason  = document.getElementById('adj-reason')?.value?.trim() || 'Stock count correction';
  const adjDate = document.getElementById('adj-date')?.value;

  if (!itemId || isNaN(newQty)) {
    alert('Please select an item and enter a quantity.');
    return;
  }

  try {
    await apiFetch('/api/inventory/adjust', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ item_id: itemId, new_qty: newQty, reason, adjustment_date: adjDate }),
    });
    _detClose();
    await _stkLoadAll();
  } catch(e) {
    alert('Adjustment failed: ' + e);
  }
}

async function _stkValuationPdf() {
  try {
    const url = '/api/inventory/valuation/pdf';
    const resp = await fetch(url, { credentials: 'include' });
    if (!resp.ok) { alert('Failed to generate PDF'); return; }
    const blob = await resp.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `stock-valuation-${isoToday()}.pdf`;
    a.click();
  } catch(e) {
    alert('Error generating valuation PDF: ' + e);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// PRICING MODE HELPERS
// ═══════════════════════════════════════════════════════════════════════════

function _stkCalcPrice(cost, mode, markup) {
  cost   = parseFloat(cost   || 0);
  markup = parseFloat(markup || 0);
  switch (mode) {
    case 'pct_margin':
      if (markup >= 100) return cost * 10;
      return cost > 0 ? cost / (1 - markup / 100) : 0;
    case 'dollar_margin':
      return cost + markup;
    case 'pct_markup':
      return cost * (1 + markup / 100);
    default: // fixed
      return markup; // markup_val holds the price directly in fixed mode
  }
}

function _stkUpdatePricePreview() {
  const modeEl = document.querySelector('input[name="stk-pmode"]:checked');
  const mode   = modeEl ? modeEl.value : 'fixed';
  const cost   = parseFloat(document.getElementById('stk-unit-cost')?.value || 0);
  const markup = parseFloat(document.getElementById('stk-markup-val')?.value || 0);

  const hints = {
    fixed:         'Fixed Sale Price ($)',
    pct_markup:    'Markup % above cost',
    pct_margin:    'Target gross margin %',
    dollar_margin: 'Dollar margin above cost ($)',
  };
  const lbl = document.getElementById('stk-markup-lbl');
  if (lbl) lbl.textContent = hints[mode] || 'Value';

  const preview   = document.getElementById('stk-price-preview');
  const belowCost = document.getElementById('stk-below-cost');
  if (!preview) return;

  if (mode === 'fixed') {
    preview.textContent = '';
    if (belowCost) belowCost.style.display = 'none';
    return;
  }
  const price = _stkCalcPrice(cost, mode, markup);
  preview.textContent = `→ Sale price: $${price.toFixed(4)}`;
  if (belowCost) {
    if (cost > 0 && price < cost) {
      belowCost.textContent = `⚠ Selling below avg cost ($${cost.toFixed(4)})`;
      belowCost.style.display = '';
    } else {
      belowCost.style.display = 'none';
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// EDIT ITEM SETTINGS
// ═══════════════════════════════════════════════════════════════════════════

async function _stkEditSettings(itemId) {
  _detClose();
  document.getElementById('det-title').textContent = '⚙ Inventory Settings';
  document.getElementById('det-body').innerHTML = '<div class="state-loading" style="padding:24px">Loading…</div>';
  _detOpen();

  try {
    const [item, accs] = await Promise.all([
      apiFetch(`/api/inventory/item/${itemId}`),
      _stkGetAccounts(),
    ]);

    const assetTypes = new Set(['Asset','Current Asset','Other Asset','Fixed Asset']);
    const expTypes   = new Set(['Cost of Goods Sold','Expense','Other Expense','Direct Cost']);
    const assetAccs  = accs.filter(a => assetTypes.has(a.account_type));
    const expAccs    = accs.filter(a => expTypes.has(a.account_type));
    const otherAccs  = accs.filter(a => !assetTypes.has(a.account_type) && !expTypes.has(a.account_type));

    const accOpt = (a, selId) =>
      `<option value="${a.id}"${a.id == selId ? ' selected' : ''}>${esc(a.code || '')}  ${esc(a.name)}</option>`;
    const accGrouped = (preferred, others, selId) =>
      `<option value="">— None —</option>` +
      (preferred.length ? `<optgroup label="Suggested">${preferred.map(a=>accOpt(a,selId)).join('')}</optgroup>` : '') +
      (others.length   ? `<optgroup label="Other">${others.map(a=>accOpt(a,selId)).join('')}</optgroup>` : '');

    const pm  = item.pricing_mode  || 'fixed';
    const mv  = item.markup_value  != null ? item.markup_value  : 0;
    // In fixed mode, markup_val holds the sale price directly
    const mvDisplay = (pm === 'fixed') ? (item.unit_price || 0) : mv;
    const modes = [
      ['fixed',         'Fixed price (set manually)'],
      ['pct_markup',    'Cost + markup %'],
      ['pct_margin',    'Target gross margin %'],
      ['dollar_margin', 'Cost + fixed $ margin'],
    ];
    const radioHTML = modes.map(([val,lbl]) =>
      `<label class="inv-pricing-mode-opt">
        <input type="radio" name="stk-pmode" value="${val}"${pm===val?' checked':''} onchange="_stkUpdatePricePreview()">
        ${lbl}
      </label>`
    ).join('');

    document.getElementById('det-body').innerHTML = `
      <div class="edt-body-pad">
        <div class="edt-field-mb inv-settings-track-row">
          <label><input type="checkbox" id="stk-inv-tracked"${item.is_inventoried?' checked':''}> Enable inventory tracking for this item</label>
        </div>
        <div class="edt-field-mb inv-settings-track-row">
          <label><input type="checkbox" id="stk-is-livestock"${item.is_livestock?' checked':''} onchange="_stkLivestockToggle()"> Livestock item (enables natural increase, deaths &amp; private use)</label>
        </div>
        <div id="stk-livestock-section" style="display:${item.is_livestock?'block':'none'}">
          <div class="edt-sep"></div>
          <div class="edt-field-mb">
            <label>ATO Category</label>
            <select class="edt-sel" id="stk-livestock-cat" onchange="_stkUpdateNiPreview()">
              <option value="">— Select category —</option>
              ${_stkAtoCategories.map(c =>
                `<option value="${c.key}"${item.livestock_category===c.key?' selected':''}>${esc(c.label)} — $${c.prescribed.toFixed(2)}/head prescribed</option>`
              ).join('')}
            </select>
          </div>
          <div class="edt-field-mb">
            <label>Natural Increase Valuation</label>
            <div class="inv-pricing-modes">
              <label class="inv-pricing-mode-opt">
                <input type="radio" name="stk-ni-method" value="prescribed"${(!item.livestock_ni_method||item.livestock_ni_method==='prescribed')?' checked':''} onchange="_stkUpdateNiPreview()">
                ATO Prescribed (recommended)
              </label>
              <label class="inv-pricing-mode-opt">
                <input type="radio" name="stk-ni-method" value="actual"${item.livestock_ni_method==='actual'?' checked':''} onchange="_stkUpdateNiPreview()">
                Actual Cost (WAC)
              </label>
            </div>
            <div id="stk-ni-preview" class="inv-price-preview" style="margin-top:4px"></div>
          </div>
          <div class="edt-field-mb">
            <label>Private Use Valuation</label>
            <div class="inv-pricing-modes">
              <label class="inv-pricing-mode-opt">
                <input type="radio" name="stk-pu-method" value="market"${(!item.livestock_pu_method||item.livestock_pu_method==='market')?' checked':''}>
                Market Value (ATO required — user enters when recording)
              </label>
              <label class="inv-pricing-mode-opt">
                <input type="radio" name="stk-pu-method" value="cost"${item.livestock_pu_method==='cost'?' checked':''}>
                At Cost (WAC)
              </label>
            </div>
          </div>
        </div>
        <div class="edt-sep"></div>
        <div class="edt-field-mb">
          <label class="edt-lbl">Reorder Level</label>
          <input class="edt-inp" type="number" id="stk-reorder-level" min="0" step="0.01" value="${item.reorder_level||0}">
        </div>
        <div class="edt-field-mb">
          <label class="edt-lbl">Reorder Qty</label>
          <input class="edt-inp" type="number" id="stk-reorder-qty" min="0" step="0.01" value="${item.reorder_qty||0}">
        </div>
        <div class="edt-field-mb">
          <label class="edt-lbl">Avg Unit Cost ($)</label>
          <input class="edt-inp" type="number" id="stk-unit-cost" min="0" step="0.0001" value="${item.unit_cost||0}" oninput="_stkUpdatePricePreview()">
        </div>
        <div class="edt-field-mb">
          <label class="edt-lbl">Location / Bin</label>
          <input class="edt-inp" type="text" id="stk-location" value="${esc(item.location||'')}">
        </div>
        <div class="edt-field-mb">
          <label class="edt-lbl">Barcode</label>
          <input class="edt-inp" type="text" id="stk-barcode" value="${esc(item.barcode||'')}">
        </div>
        <div class="edt-field-mb">
          <label class="edt-lbl">Stock Asset Account</label>
          <select class="edt-sel" id="stk-stock-acc">
            ${accGrouped(assetAccs, expAccs.concat(otherAccs), item.stock_account_id)}
          </select>
        </div>
        <div class="edt-field-mb">
          <label class="edt-lbl">COGS Account</label>
          <select class="edt-sel" id="stk-cogs-acc">
            ${accGrouped(expAccs, assetAccs.concat(otherAccs), item.cogs_account_id)}
          </select>
        </div>
        <div class="edt-sep"></div>
        <div class="edt-field-mb">
          <label style="font-weight:600">Sale Price Calculation</label>
          <div class="inv-pricing-modes">${radioHTML}</div>
        </div>
        <div class="edt-field-mb">
          <label class="edt-lbl" id="stk-markup-lbl">Fixed Sale Price ($)</label>
          <input class="edt-inp" type="number" id="stk-markup-val" step="0.0001" value="${mvDisplay}" oninput="_stkUpdatePricePreview()">
          <div id="stk-price-preview" class="inv-price-preview"></div>
          <div id="stk-below-cost" class="col-red" style="font-size:11px;display:none"></div>
        </div>
        <div style="display:flex;gap:8px;padding:8px 0 4px">
          <button class="btn btn-sm btn-primary" onclick="_stkSaveSettings(${itemId})">Save Settings</button>
          <button class="btn btn-sm btn-outline" onclick="_detClose()">Cancel</button>
        </div>
      </div>
    `;
    _stkUpdatePricePreview();
  } catch(e) {
    document.getElementById('det-body').innerHTML =
      `<div class="state-error" style="padding:16px">Failed to load settings: ${esc(String(e))}</div>`;
  }
}

function _stkLivestockToggle() {
  const checked = document.getElementById('stk-is-livestock')?.checked;
  const section = document.getElementById('stk-livestock-section');
  if (section) section.style.display = checked ? 'block' : 'none';
  if (!checked) return;
  _stkUpdateNiPreview();
}

function _stkUpdateNiPreview() {
  const preview = document.getElementById('stk-ni-preview');
  if (!preview) return;
  const cat    = document.getElementById('stk-livestock-cat')?.value;
  const method = document.querySelector('input[name="stk-ni-method"]:checked')?.value || 'prescribed';
  const cost   = parseFloat(document.getElementById('stk-unit-cost')?.value || 0);
  if (method === 'prescribed') {
    const pv = _stkAtoValue(cat);
    preview.textContent = pv != null
      ? `ATO prescribed: $${pv.toFixed(2)}/head — will be used as cost for new natural increase entries`
      : cat ? 'Select a category to see prescribed value' : 'Select a category';
  } else {
    preview.textContent = `Actual cost (WAC): $${cost.toFixed(4)}/head will be used`;
  }
}

async function _stkGetAccounts() {
  if (!_stkAccCache) {
    _stkAccCache = await apiFetch('/api/accounts');
  }
  return _stkAccCache;
}

async function _stkSaveSettings(itemId) {
  const isTracked       = document.getElementById('stk-inv-tracked')?.checked ? 1 : 0;
  const isLivestock     = document.getElementById('stk-is-livestock')?.checked ? 1 : 0;
  const livestockCat    = document.getElementById('stk-livestock-cat')?.value || null;
  const livestockNiMeth = document.querySelector('input[name="stk-ni-method"]:checked')?.value || 'prescribed';
  const livestockPuMeth = document.querySelector('input[name="stk-pu-method"]:checked')?.value || 'market';
  const reorderLevel = parseFloat(document.getElementById('stk-reorder-level')?.value || 0);
  const reorderQty   = parseFloat(document.getElementById('stk-reorder-qty')?.value   || 0);
  const unitCost     = parseFloat(document.getElementById('stk-unit-cost')?.value      || 0);
  const location     = document.getElementById('stk-location')?.value.trim() || null;
  const barcode      = document.getElementById('stk-barcode')?.value.trim()  || null;
  const stockAccId   = parseInt(document.getElementById('stk-stock-acc')?.value) || null;
  const cogsAccId    = parseInt(document.getElementById('stk-cogs-acc')?.value)  || null;
  const mode         = document.querySelector('input[name="stk-pmode"]:checked')?.value || 'fixed';
  const markupVal    = parseFloat(document.getElementById('stk-markup-val')?.value || 0);
  const unitPrice    = _stkCalcPrice(unitCost, mode, markupVal);

  if (unitCost > 0 && mode !== 'fixed' && unitPrice < unitCost) {
    if (!confirm(`The calculated sale price $${unitPrice.toFixed(4)} is below average cost $${unitCost.toFixed(4)}.\n\nSave anyway?`)) {
      return;
    }
  }

  try {
    const r = await fetch(`/api/inventory/item/${itemId}/settings`, {
      method: 'PUT',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        is_inventoried:      isTracked,
        is_livestock:        isLivestock,
        livestock_category:  livestockCat,
        livestock_ni_method: livestockNiMeth,
        livestock_pu_method: livestockPuMeth,
        reorder_level: reorderLevel,
        reorder_qty:   reorderQty,
        unit_cost:     unitCost,
        location,
        barcode,
        stock_account_id: stockAccId,
        cogs_account_id:  cogsAccId,
        pricing_mode:  mode,
        markup_value:  markupVal,
        unit_price:    unitPrice,
      }),
    });
    const j = await r.json();
    if (!j.ok) { alert('Save failed: ' + (j.error || 'Unknown error')); return; }
    _detClose();
    _stkAccCache = null; // bust accounts cache in case it changed
    await _stkLoadAll();
    toast('Inventory settings saved');
  } catch(e) {
    alert('Save failed: ' + e);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// RECORD STOCK MOVEMENT (SALE / WRITE_OFF / RETURN_IN / RETURN_OUT)
// ═══════════════════════════════════════════════════════════════════════════

function _stkRecordMovement(itemId, movType, movLabel) {
  const item     = _stkItems.find(it => it.id === itemId);
  const isSale   = movType === 'SALE';
  const isNI     = movType === 'NATURAL_INCREASE';
  const isPU     = movType === 'PRIVATE_USE';
  const isLivestockSale = isSale && item?.is_livestock;
  const today    = isoToday();

  // Determine cost pre-fill and hint for livestock movements
  let prefill = item ? parseFloat(item.unit_cost || 0) : 0;
  let costHint = '';
  if (item && isNI) {
    const niMethod = item.livestock_ni_method || 'prescribed';
    const cat      = item.livestock_category  || '';
    if (niMethod === 'prescribed' && cat) {
      const pv = _stkAtoValue(cat);
      if (pv != null) { prefill = pv; costHint = `ATO prescribed: $${pv.toFixed(2)}/head`; }
    } else {
      costHint = `Actual cost (WAC): $${prefill.toFixed(4)}/head`;
    }
  } else if (item && isPU) {
    const puMethod = item.livestock_pu_method || 'market';
    if (puMethod === 'market') {
      prefill  = 0;
      costHint = 'ATO requires disposal at market value — enter current market price';
    } else {
      costHint = `At cost (WAC): $${prefill.toFixed(4)}/head`;
    }
  }

  const opts = _stkItems.map(it =>
    `<option value="${it.id}"${it.id===itemId?' selected':''}>${esc(it.name)}${it.code?' ['+esc(it.code)+']':''}</option>`
  ).join('');

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="max-width:460px;width:100%">
    <div class="modal-hdr">
      <span>${esc(movLabel)}</span>
      <button class="modal-close" onclick="this.closest('.modal-bd').remove()">✕</button>
    </div>
    <div class="modal-body edt-body-pad">
      <div class="edt-field-mb">
        <label class="edt-lbl">Item</label>
        <select class="edt-sel" id="smov-item" onchange="_stkMovItemChange()">
          ${opts}
        </select>
      </div>
      <div id="smov-onhand" style="font-size:11px;color:var(--ink3);margin:-6px 0 10px"></div>
      <div class="edt-field-mb">
        <label class="edt-lbl">${isNI ? 'Number of head (natural increase)' : isPU ? 'Number of head (private use)' : 'Quantity'} *</label>
        <input class="edt-inp" type="number" id="smov-qty" min="0.0001" step="1" placeholder="0">
      </div>
      <div class="edt-field-mb">
        <label class="edt-lbl">${isPU ? 'Market Value per Head ($)' : 'Unit Cost ($)'}</label>
        <input class="edt-inp" type="number" id="smov-cost" min="0" step="0.01"
          value="${prefill > 0 ? prefill : ''}"
          placeholder="${prefill > 0 ? prefill.toFixed(2) : '0.00'}">
        ${costHint ? `<div style="font-size:11px;color:var(--ink3);margin-top:3px">${esc(costHint)}</div>` : ''}
      </div>
      ${isSale ? `<div class="edt-field-mb">
        <label class="edt-lbl">Sale Price per Unit ($)</label>
        <input class="edt-inp" type="number" id="smov-price" min="0" step="0.01" value="${item?parseFloat(item.unit_price||0).toFixed(2):''}">
      </div>` : ''}
      <div class="edt-field-mb">
        <label class="edt-lbl">Date *</label>
        <input class="edt-inp" type="date" id="smov-date" value="${today}">
      </div>
      ${isLivestockSale ? `
      <div class="edt-field-mb">
        <label class="edt-lbl">Invoice * <span style="font-size:11px;color:var(--ink3)">(livestock sales must be linked to an invoice)</span></label>
        <select class="edt-sel" id="smov-invoice" onchange="_stkLivestockInvChange()">
          <option value="">Loading invoices…</option>
        </select>
        <div id="smov-inv-hint" style="font-size:11px;color:var(--ink3);margin-top:3px"></div>
      </div>` : `
      <div class="edt-field-mb">
        <label class="edt-lbl">Reference</label>
        <input class="edt-inp" type="text" id="smov-ref" placeholder="e.g. INV-001">
      </div>`}
      <div class="edt-field-mb">
        <label class="edt-lbl">Notes</label>
        <input class="edt-inp" type="text" id="smov-notes" placeholder="">
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-sm btn-outline" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-sm btn-primary" onclick="_stkPostMovement(${itemId},'${movType}')">Post ${esc(movLabel)}</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  bd.addEventListener('click', e => { if (e.target === bd) bd.remove(); });
  _stkMovItemChange();
  if (isLivestockSale) _stkLoadInvoicesForPicker();
}

async function _stkLoadInvoicesForPicker() {
  const sel = document.getElementById('smov-invoice');
  if (!sel) return;
  try {
    const invs = await apiFetch('/api/invoices');
    const active = invs.filter(i => (i.status || '').toLowerCase() !== 'void');
    active.sort((a, b) => (b.invoice_number || '').localeCompare(a.invoice_number || ''));
    sel.innerHTML = '<option value="">— Select invoice —</option>' +
      active.map(i =>
        `<option value="${i.id}" data-num="${esc(i.invoice_number||'')}">` +
        `${esc(i.invoice_number||'#'+i.id)} — ${esc(i.contact_name||'')} — $${(i.total_amount||0).toFixed(2)}` +
        `</option>`
      ).join('');
  } catch(e) {
    sel.innerHTML = '<option value="">— Failed to load invoices —</option>';
  }
}

function _stkLivestockInvChange() {
  const sel  = document.getElementById('smov-invoice');
  const hint = document.getElementById('smov-inv-hint');
  if (!sel || !hint) return;
  const opt = sel.options[sel.selectedIndex];
  hint.textContent = opt?.value ? `Linked to ${opt.dataset.num || 'invoice #'+opt.value}` : '';
}

function _stkMovItemChange() {
  const sel = document.getElementById('smov-item');
  if (!sel) return;
  const id   = parseInt(sel.value);
  const item = _stkItems.find(it => it.id === id);
  const el   = document.getElementById('smov-onhand');
  if (el && item) {
    const qty  = parseFloat(item.qty_on_hand || 0);
    const cost = parseFloat(item.unit_cost   || 0);
    el.textContent = `On hand: ${qty.toFixed(2)}  |  Avg cost: $${cost.toFixed(4)}`;
    const costEl = document.getElementById('smov-cost');
    if (costEl && !costEl.value && cost > 0) costEl.value = cost.toFixed(4);
  }
}

async function _stkPostMovement(defaultItemId, movType) {
  const itemId  = parseInt(document.getElementById('smov-item')?.value || defaultItemId);
  const qty     = parseFloat(document.getElementById('smov-qty')?.value   || 0);
  const cost    = document.getElementById('smov-cost')?.value;
  const price   = document.getElementById('smov-price')?.value;
  const movDate = document.getElementById('smov-date')?.value;
  const notes   = document.getElementById('smov-notes')?.value.trim() || '';

  const invSel  = document.getElementById('smov-invoice');
  const invId   = invSel ? (parseInt(invSel.value) || null) : null;
  const invNum  = invSel ? (invSel.options[invSel.selectedIndex]?.dataset?.num || '') : '';
  const ref     = invId ? invNum : (document.getElementById('smov-ref')?.value.trim() || '');

  const item = _stkItems.find(it => it.id === itemId);
  const isLivestockSale = movType === 'SALE' && item?.is_livestock;

  if (!itemId || qty <= 0) { alert('Select an item and enter a positive quantity.'); return; }
  if (!movDate) { alert('Date is required.'); return; }
  if (isLivestockSale && !invId) { toast('Livestock sales must be linked to an invoice.', 'err'); return; }

  try {
    const r = await fetch('/api/inventory/movement', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        item_id:         itemId,
        movement_type:   movType,
        movement_date:   movDate,
        qty,
        unit_cost:       cost  && cost  !== '' ? parseFloat(cost)  : null,
        unit_price:      price && price !== '' ? parseFloat(price) : null,
        reference:       ref,
        source_doc_type: invId ? 'invoice' : null,
        source_doc_id:   invId,
        notes,
      }),
    });
    const j = await r.json();
    if (!j.ok) { alert('Failed: ' + (j.error || 'Unknown error')); return; }
    document.querySelector('.modal-bd')?.remove();
    _detClose();
    await _stkLoadAll();
    toast('Movement posted');
  } catch(e) {
    alert('Error: ' + e);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// STOCKTAKE — batch physical count
// ═══════════════════════════════════════════════════════════════════════════

async function _stkStocktake() {
  const today = isoToday();

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'stk-take-modal';
  bd.innerHTML = `<div class="modal-box inv-stk-modal">
    <div class="modal-hdr">
      <span>📋 Stocktake — Physical Count</span>
      <div style="display:flex;align-items:center;gap:10px;margin-left:auto">
        <label style="font-size:12px;color:var(--ink2)">Count Date
          <input type="date" id="stk-take-date" value="${today}" style="margin-left:6px">
        </label>
        <button class="modal-close" onclick="this.closest('.modal-bd').remove()">✕</button>
      </div>
    </div>
    <div class="modal-body">
      <div style="padding:8px 16px;font-size:11px;color:var(--ink3)">
        Enter the physical count for each item. Variances are highlighted. Only changed items will be posted.
      </div>
      <table class="inv-stk-tbl">
        <thead>
          <tr>
            <th>Code</th>
            <th>Name</th>
            <th class="th-r">System Qty</th>
            <th class="th-r">Counted Qty</th>
            <th class="th-r">Variance</th>
            <th class="th-r">Value Δ</th>
          </tr>
        </thead>
        <tbody id="stk-take-body">
          <tr><td colspan="6" class="tbl-empty-sm">Loading…</td></tr>
        </tbody>
      </table>
    </div>
    <div class="modal-foot" style="justify-content:space-between;align-items:center">
      <span id="stk-take-summary" style="font-size:11px;color:var(--ink3)"></span>
      <div style="display:flex;gap:8px">
        <button class="btn btn-sm btn-outline" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-sm btn-outline" onclick="_stkTakePreview()">📊 Preview Variances</button>
        <button class="btn btn-sm btn-primary" onclick="_stkTakePost()">✓ Post Stocktake</button>
      </div>
    </div>
  </div>`;
  document.body.appendChild(bd);
  bd.addEventListener('click', e => { if (e.target === bd) bd.remove(); });

  // Use cached items if available, otherwise fetch
  let items = _stkItems.length ? _stkItems : [];
  if (!items.length) {
    try { items = await apiFetch('/api/inventory/items'); }
    catch(e) {
      document.getElementById('stk-take-body').innerHTML =
        `<tr><td colspan="6" class="state-error">Failed to load items: ${esc(String(e))}</td></tr>`;
      return;
    }
  }

  if (!items.length) {
    document.getElementById('stk-take-body').innerHTML =
      '<tr><td colspan="6" class="tbl-empty-sm">No inventoried items found.</td></tr>';
    return;
  }

  const rows = items.map((item, i) => {
    const sysQty = parseFloat(item.qty_on_hand || 0);
    const cost   = parseFloat(item.unit_cost   || 0);
    const bg     = i % 2 ? 'background:var(--row-alt)' : '';
    return `<tr style="${bg}" data-item-id="${item.id}" data-sys-qty="${sysQty}" data-cost="${cost}">
      <td>${esc(item.code||'')}</td>
      <td>${esc(item.name)}</td>
      <td class="td-r-mono">${sysQty.toFixed(2)}</td>
      <td class="th-r"><input type="number" class="stk-take-input" data-id="${item.id}"
        value="${sysQty.toFixed(2)}" step="0.01" style="width:90px;text-align:right"
        oninput="_stkTakeRowChange(this,${sysQty},${cost})"></td>
      <td class="td-r-mono" id="stk-var-${item.id}">—</td>
      <td class="td-r-mono" id="stk-vdelta-${item.id}">—</td>
    </tr>`;
  }).join('');
  document.getElementById('stk-take-body').innerHTML = rows;
  _stkTakeSummary();
}

function _stkTakeRowChange(inputEl, sysQty, cost) {
  const itemId  = parseInt(inputEl.dataset.id);
  const counted = parseFloat(inputEl.value);
  const varEl   = document.getElementById(`stk-var-${itemId}`);
  const dEl     = document.getElementById(`stk-vdelta-${itemId}`);
  if (!varEl || !dEl) return;

  if (isNaN(counted)) {
    varEl.textContent = '?'; varEl.className = 'td-r-mono col-red';
    dEl.textContent = ''; return;
  }
  const variance  = counted - sysQty;
  const valDelta  = variance * cost;
  if (Math.abs(variance) < 0.001) {
    varEl.textContent = '—'; varEl.className = 'td-r-mono';
    dEl.textContent   = '—'; dEl.className   = 'td-r-mono';
  } else {
    const sign = variance > 0 ? '+' : '';
    varEl.textContent = `${sign}${variance.toFixed(2)}`;
    varEl.className   = `td-r-mono ${variance > 0 ? 'stk-var-pos' : 'stk-var-neg'}`;
    const ds = valDelta >= 0 ? '+' : '';
    dEl.textContent = `${ds}$${Math.abs(valDelta).toFixed(2)}`;
    dEl.className   = `td-r-mono ${valDelta >= 0 ? 'stk-var-pos' : 'stk-var-neg'}`;
  }
  _stkTakeSummary();
}

function _stkTakeSummary() {
  const inputs = document.querySelectorAll('.stk-take-input');
  let changed = 0;
  inputs.forEach(inp => {
    const sysQty = parseFloat(inp.closest('tr').dataset.sysQty || 0);
    const val    = parseFloat(inp.value);
    if (!isNaN(val) && Math.abs(val - sysQty) > 0.001) changed++;
  });
  const el = document.getElementById('stk-take-summary');
  if (el) el.textContent = `${inputs.length} items  ·  ${changed} variance${changed !== 1 ? 's' : ''}  ·  ${inputs.length - changed} match system`;
}

function _stkTakePreview() {
  const inputs = document.querySelectorAll('.stk-take-input');
  const lines  = [];
  inputs.forEach(inp => {
    const row    = inp.closest('tr');
    const sysQty = parseFloat(row.dataset.sysQty || 0);
    const counted = parseFloat(inp.value);
    if (isNaN(counted) || Math.abs(counted - sysQty) <= 0.001) return;
    const cost     = parseFloat(row.dataset.cost || 0);
    const variance = counted - sysQty;
    const name     = row.querySelector('td:nth-child(2)')?.textContent || '';
    lines.push(`${name.padEnd(30,' ')}  sys=${sysQty.toFixed(2).padStart(8)}  counted=${counted.toFixed(2).padStart(8)}  var=${(variance>0?'+':'')+variance.toFixed(2).padStart(8)}  Δ$${(variance>0?'+':'')+Math.round(variance*cost).toFixed(0)}`);
  });
  if (!lines.length) {
    alert('All counted quantities match system. Nothing to post.');
  } else {
    alert(`Items with variances (${lines.length}):\n\n` + lines.join('\n'));
  }
}

async function _stkTakePost() {
  const countDate = document.getElementById('stk-take-date')?.value;
  if (!countDate) { alert('Count date is required.'); return; }

  const lines = [];
  document.querySelectorAll('.stk-take-input').forEach(inp => {
    const sysQty  = parseFloat(inp.closest('tr').dataset.sysQty || 0);
    const newQty  = parseFloat(inp.value);
    if (!isNaN(newQty) && Math.abs(newQty - sysQty) > 0.001) {
      lines.push({ item_id: parseInt(inp.dataset.id), new_qty: newQty });
    }
  });

  if (!lines.length) { alert('All counts match system. Nothing to post.'); return; }

  if (!confirm(`Post ${lines.length} stock adjustment${lines.length !== 1 ? 's' : ''}?\n\nCount date: ${countDate}\n\nThis will update stock quantities and post cost variance journals.`)) return;

  try {
    const r = await fetch('/api/inventory/stocktake', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ count_date: countDate, lines }),
    });
    const j = await r.json();
    if (!j.ok) { alert('Stocktake failed: ' + (j.error || 'Unknown error')); return; }
    const { posted, errors } = j.data || {};
    let msg = `Posted ${posted} adjustment${posted !== 1 ? 's' : ''}. Stock quantities updated.`;
    if (errors && errors.length) {
      msg += `\n\n${errors.length} error(s):\n` + errors.slice(0,5).map(e=>`${e.item_id}: ${e.error}`).join('\n');
      alert(msg);
    } else {
      alert(msg);
    }
    document.getElementById('stk-take-modal')?.remove();
    await _stkLoadAll();
  } catch(e) {
    alert('Error: ' + e);
  }
}
