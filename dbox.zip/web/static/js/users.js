// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ── Users module (_usr* namespace) ───────────────────────────────────────────
// Admin-only. User list with create/edit/deactivate, change password, audit log.

const ROLES = ['Admin', 'Accountant', 'Staff', 'ReadOnly'];

let _usrAll        = [];
let _usrShowAll    = false;   // false = active only, true = all incl inactive
let _usrTab        = 'users'; // 'users' | 'audit'
let _usrSort       = { col: 'username', asc: true };
let _usrAuditAll   = [];

// ── Entry point ───────────────────────────────────────────────────────────────

async function pageUsers() {
  // Role guard — only Admin may manage users
  let me;
  try { me = await apiFetch('/api/me'); } catch(e) { me = {}; }
  if (me.role !== 'Admin') {
    document.getElementById('module-content').innerHTML = `
      <div class="coming-soon">
        <div class="cs-icon">🔒</div>
        <div class="cs-msg">Access restricted</div>
        <div class="cs-sub">Only Admin users can manage users and view the audit log.</div>
      </div>`;
    return;
  }
  await _usrRender();
}

async function _usrRender() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = `
    <div class="inv-toolbar">
      <input class="inv-search" id="usr-search" placeholder="Search users…" oninput="_usrApply()">
      <div class="inv-filter-group">
        <button class="filter-btn ${!_usrShowAll?'active':''}" onclick="_usrSetFilter(false)">Active</button>
        <button class="filter-btn ${_usrShowAll?'active':''}"  onclick="_usrSetFilter(true)">All</button>
      </div>
      <button class="btn btn-primary btn-sm" onclick="_usrNewForm()">+ New User</button>
    </div>

    <div class="usr-tab-bar">
      <button class="usr-tab ${_usrTab==='users'?'active':''}" onclick="_usrSwitchTab('users')">👥 Users</button>
      <button class="usr-tab ${_usrTab==='audit'?'active':''}" onclick="_usrSwitchTab('audit')">📋 Audit Log</button>
    </div>

    <div id="usr-panel">
      <div class="state-loading">Loading…</div>
    </div>
    <div class="mt-8"><span class="count-pill" id="usr-count"></span></div>`;

  await _usrLoad();
}

// ── Data loading ──────────────────────────────────────────────────────────────

async function _usrLoad() {
  if (_usrTab === 'users') {
    await _usrLoadUsers();
  } else {
    await _usrLoadAudit();
  }
}

async function _usrLoadUsers() {
  try {
    _usrAll = await apiFetch(`/api/users?active_only=${_usrShowAll ? 0 : 1}`);
  } catch(e) {
    document.getElementById('usr-panel').innerHTML =
      `<div class="state-error">Failed to load users: ${e.message}</div>`;
    return;
  }
  _usrApply();
}

async function _usrLoadAudit() {
  try {
    _usrAuditAll = await apiFetch('/api/users/audit-log');
  } catch(e) {
    document.getElementById('usr-panel').innerHTML =
      `<div class="state-error">Failed to load audit log: ${e.message}</div>`;
    return;
  }
  _usrRenderAudit();
}

// ── Users tab ─────────────────────────────────────────────────────────────────

function _usrApply() {
  const q = (document.getElementById('usr-search')?.value || '').toLowerCase();
  let rows = _usrAll.filter(u =>
    u.username.toLowerCase().includes(q) ||
    u.display_name.toLowerCase().includes(q) ||
    u.role.toLowerCase().includes(q)
  );

  // Sort
  rows.sort((a, b) => {
    let av = (a[_usrSort.col] || '').toString().toLowerCase();
    let bv = (b[_usrSort.col] || '').toString().toLowerCase();
    return _usrSort.asc ? av.localeCompare(bv) : bv.localeCompare(av);
  });

  _usrRenderTable(rows);
  const countEl = document.getElementById('usr-count');
  if (countEl) countEl.textContent = `${rows.length} of ${_usrAll.length} users`;
}

function _usrRenderTable(rows) {
  const cols = [
    { key: 'username',     label: 'Username' },
    { key: 'display_name', label: 'Display Name' },
    { key: 'role',         label: 'Role' },
    { key: 'last_login',   label: 'Last Login' },
    { key: '_status',      label: 'Status' },
    { key: '_actions',     label: '' },
  ];

  const thCells = cols.map(c => {
    if (c.key.startsWith('_')) return `<th></th>`;
    const cls = _usrSort.col === c.key
      ? (_usrSort.asc ? 'sort-asc' : 'sort-desc') : '';
    return `<th class="${cls}" onclick="_usrSortBy('${c.key}')">${c.label}</th>`;
  }).join('');

  const bodyRows = rows.length === 0
    ? `<tr><td colspan="6" class="tbl-empty-row">No users found.</td></tr>`
    : rows.map(u => {
        const statusBadge = u.is_active
          ? `<span class="badge badge-paid">Active</span>`
          : `<span class="badge badge-overdue">Inactive</span>`;

        const roleBadge = _usrRoleBadge(u.role);

        const lastLogin = u.last_login
          ? `<span class="inv-mono">${fmtDate(u.last_login.slice(0, 10))}</span>`
          : `<span class="col-ink3">Never</span>`;

        const toggleBtn = u.is_active
          ? `<button class="btn btn-amber btn-sm" onclick="_usrToggleActive(${u.id},false)" title="Deactivate">Deactivate</button>`
          : `<button class="btn btn-success btn-sm" onclick="_usrToggleActive(${u.id},true)" title="Reactivate">Reactivate</button>`;

        return `<tr class="inv-row" onclick="_usrEditForm(${u.id})">
          <td><span class="inv-contact">${_esc(u.username)}</span></td>
          <td><span class="inv-mono">${_esc(u.display_name)}</span></td>
          <td>${roleBadge}</td>
          <td>${lastLogin}</td>
          <td>${statusBadge}</td>
          <td onclick="event.stopPropagation()" class="usr-actions-cell">
            <button class="btn btn-outline btn-sm" onclick="_usrPasswordModal(${u.id},'${_esc(u.username)}')">🔑 Password</button>
            ${toggleBtn}
          </td>
        </tr>`;
      }).join('');

  document.getElementById('usr-panel').innerHTML = `
    <div class="inv-list-panel">
      <div class="tbl-overflow-x">
        <table class="inv-list-table">
          <thead><tr>${thCells}</tr></thead>
          <tbody>${bodyRows}</tbody>
        </table>
      </div>
    </div>`;
}

function _usrRoleBadge(role) {
  const map = {
    'Admin':      'badge-overdue',
    'Accountant': 'badge-partial',
    'Staff':      'badge-pending',
    'ReadOnly':   'badge-draft',
  };
  const cls = map[role] || 'badge-draft';
  return `<span class="badge ${cls}">${role}</span>`;
}

function _usrSortBy(col) {
  if (_usrSort.col === col) {
    _usrSort.asc = !_usrSort.asc;
  } else {
    _usrSort = { col, asc: true };
  }
  _usrApply();
}

function _usrSetFilter(showAll) {
  _usrShowAll = showAll;
  // Re-render toolbar state
  document.querySelectorAll('.inv-filter-group .filter-btn').forEach((btn, i) => {
    btn.classList.toggle('active', showAll ? i === 1 : i === 0);
  });
  _usrLoadUsers();
}

function _usrSwitchTab(tab) {
  _usrTab = tab;
  document.querySelectorAll('.usr-tab').forEach(b =>
    b.classList.toggle('active', b.textContent.includes(tab === 'users' ? 'Users' : 'Audit')));
  // Hide/show toolbar elements that only belong to users tab
  const search = document.getElementById('usr-search');
  const filterGroup = document.querySelector('.inv-filter-group');
  const newBtn = document.querySelector('.inv-toolbar .btn-primary');
  const countPill = document.getElementById('usr-count');
  const show = tab === 'users';
  if (search) search.closest('.inv-toolbar').querySelectorAll(
    '.inv-search, .inv-filter-group, .btn-primary').forEach(el => {
    el.style.display = show ? '' : 'none';
  });
  if (countPill) countPill.textContent = '';
  document.getElementById('usr-panel').innerHTML = '<div class="state-loading">Loading…</div>';
  _usrLoad();
}

// ── Audit log tab ─────────────────────────────────────────────────────────────

function _usrRenderAudit() {
  const rows = _usrAuditAll;
  const bodyRows = rows.length === 0
    ? `<tr><td colspan="5" class="tbl-empty-row">No audit entries found.</td></tr>`
    : rows.map(e => `
        <tr class="inv-row">
          <td><span class="inv-mono">${_esc(e.logged_at ? e.logged_at.slice(0,16).replace('T',' ') : '')}</span></td>
          <td><span class="inv-contact">${_esc(e.username||'')}</span></td>
          <td>${_esc(e.action||'')}</td>
          <td><span class="col-ink3">${_esc(e.target_type||'')}${e.target_id ? ' #'+e.target_id : ''}</span></td>
          <td class="td-sm col-ink3">${_esc(e.detail||'')}</td>
        </tr>`).join('');

  document.getElementById('usr-panel').innerHTML = `
    <div class="inv-list-panel">
      <div class="tbl-overflow-x">
        <table class="inv-list-table">
          <thead><tr>
            <th>When</th>
            <th>User</th>
            <th>Action</th>
            <th>Target</th>
            <th>Detail</th>
          </tr></thead>
          <tbody>${bodyRows}</tbody>
        </table>
      </div>
    </div>`;

  const countEl = document.getElementById('usr-count');
  if (countEl) countEl.textContent = `${rows.length} entries (most recent 200)`;
}

// ── Slide-over: New / Edit user ───────────────────────────────────────────────

async function _usrNewForm() {
  _usrOpenForm(null, {
    username: '', display_name: '', role: 'Staff', is_active: 1
  });
}

async function _usrEditForm(id) {
  let user;
  try { user = await apiFetch(`/api/users/${id}`); }
  catch(e) { toast('Failed to load user', 'err'); return; }
  _usrOpenForm(id, user);
}

function _usrOpenForm(id, user) {
  const isNew = !id;
  const title = isNew ? 'New User' : `Edit User — ${user.username}`;

  const roleOptions = ROLES.map(r =>
    `<option value="${r}" ${r === user.role ? 'selected' : ''}>${r}</option>`
  ).join('');

  document.getElementById('det-body').innerHTML = `
    <div class="edt-section">
      <div class="edt-row">
        <div class="edt-field">
          <label class="edt-lbl">Username *</label>
          <input class="edt-inp" id="usr-f-username" type="text"
            value="${_esc(user.username)}" ${isNew ? '' : 'readonly'} autocomplete="off">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Display Name *</label>
          <input class="edt-inp" id="usr-f-display" type="text"
            value="${_esc(user.display_name)}" autocomplete="off">
        </div>
      </div>
      <div class="edt-row">
        <div class="edt-field">
          <label class="edt-lbl">Role *</label>
          <select class="edt-sel" id="usr-f-role">${roleOptions}</select>
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Status</label>
          <select class="edt-sel" id="usr-f-active">
            <option value="1" ${user.is_active ? 'selected' : ''}>Active</option>
            <option value="0" ${!user.is_active ? 'selected' : ''}>Inactive</option>
          </select>
        </div>
      </div>
      ${isNew ? `
      <div class="edt-divider"></div>
      <div class="edt-row">
        <div class="edt-field">
          <label class="edt-lbl">Password *</label>
          <input class="edt-inp" id="usr-f-pw" type="password" autocomplete="new-password">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Confirm Password *</label>
          <input class="edt-inp" id="usr-f-pw2" type="password" autocomplete="new-password">
        </div>
      </div>` : ''}
      ${!isNew && user.role === 'Admin' ? `
      <div class="usr-admin-note">
        ⚠ This is an Admin account. Role changes take effect on next login.
      </div>` : ''}
    </div>`;

  document.getElementById('det-title').textContent = title;
  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-primary" onclick="_usrSave(${id || 'null'})">
      ${isNew ? 'Create User' : 'Save Changes'}
    </button>
    <button class="btn btn-outline" onclick="detClose()">Cancel</button>`;

  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('usr-f-display').focus();
}

async function _usrSave(id) {
  const isNew = !id;
  const username    = document.getElementById('usr-f-username')?.value.trim();
  const displayName = document.getElementById('usr-f-display')?.value.trim();
  const role        = document.getElementById('usr-f-role')?.value;
  const isActive    = parseInt(document.getElementById('usr-f-active')?.value || '1');

  if (!username)    { toast('Username is required', 'err'); return; }
  if (!displayName) { toast('Display name is required', 'err'); return; }

  let payload = { display_name: displayName, role, is_active: isActive };

  if (isNew) {
    const pw  = document.getElementById('usr-f-pw')?.value || '';
    const pw2 = document.getElementById('usr-f-pw2')?.value || '';
    if (!pw)         { toast('Password is required', 'err'); return; }
    if (pw !== pw2)  { toast('Passwords do not match', 'err'); return; }
    if (pw.length < 6) { toast('Password must be at least 6 characters', 'err'); return; }
    payload.username = username;
    payload.password = pw;
  }

  try {
    if (isNew) {
      await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload),
      }).then(async r => {
        const d = await r.json();
        if (!d.ok) throw new Error(d.error || 'Save failed');
      });
      toast('User created');
    } else {
      await fetch(`/api/users/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload),
      }).then(async r => {
        const d = await r.json();
        if (!d.ok) throw new Error(d.error || 'Save failed');
      });
      toast('User saved');
    }
    detClose();
    await _usrLoadUsers();
  } catch(e) {
    toast(e.message || 'Save failed', 'err');
  }
}

// ── Toggle active/inactive ────────────────────────────────────────────────────

async function _usrToggleActive(id, activate) {
  const action = activate ? 'reactivate' : 'deactivate';
  if (!confirm(`${activate ? 'Reactivate' : 'Deactivate'} this user?`)) return;
  try {
    const r = await fetch(`/api/users/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ is_active: activate ? 1 : 0 }),
    });
    const d = await r.json();
    if (!d.ok) throw new Error(d.error || 'Update failed');
    toast(activate ? 'User reactivated' : 'User deactivated');
    await _usrLoadUsers();
  } catch(e) {
    toast(e.message || 'Update failed', 'err');
  }
}

// ── Change password modal ─────────────────────────────────────────────────────

function _usrPasswordModal(id, username) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box" style="width:min(420px,96vw)">
      <div class="modal-hdr">
        <span>Change Password — ${_esc(username)}</span>
      </div>
      <div class="modal-body">
        <div class="edt-field" style="margin-bottom:12px">
          <label class="edt-lbl">New Password *</label>
          <input class="edt-inp" id="usr-pw-new" type="password" autocomplete="new-password">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Confirm Password *</label>
          <input class="edt-inp" id="usr-pw-confirm" type="password" autocomplete="new-password">
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="_usrSavePassword(${id})">Set Password</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
  bd.querySelector('#usr-pw-new').focus();
}

async function _usrSavePassword(id) {
  const pw  = document.getElementById('usr-pw-new')?.value || '';
  const pw2 = document.getElementById('usr-pw-confirm')?.value || '';
  if (!pw)          { toast('Password is required', 'err'); return; }
  if (pw !== pw2)   { toast('Passwords do not match', 'err'); return; }
  if (pw.length < 6){ toast('Password must be at least 6 characters', 'err'); return; }

  try {
    const r = await fetch(`/api/users/${id}/set-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ password: pw }),
    });
    const d = await r.json();
    if (!d.ok) throw new Error(d.error || 'Failed');
    document.querySelector('.modal-bd')?.remove();
    toast('Password changed');
  } catch(e) {
    toast(e.message || 'Failed to change password', 'err');
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function _esc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
