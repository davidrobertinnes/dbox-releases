// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ── Users module (_usr* namespace) ───────────────────────────────────────────
// Admin-only. User list with create/edit/deactivate, change password, audit log.

const ROLES = [
  { value: 'Admin',      label: 'Admin / Owner',  desc: 'Full access including user management' },
  { value: 'Accountant', label: 'Accountant',      desc: 'Accounting, reports, payroll, and fixed assets' },
  { value: 'Trades',     label: 'Trades',           desc: 'Jobs, quotes, invoices, POs, and field work' },
  { value: 'Retail',     label: 'Retail',           desc: 'POS, table service, inventory, and invoices' },
  { value: 'ReadOnly',   label: 'Read Only',        desc: 'View invoices, bills, and reports' },
];

let _usrAll        = [];
let _usrShowAll    = false;   // false = active only, true = all incl inactive
let _usrTab        = 'users'; // 'users' | 'audit'
let _usrSort       = { col: 'username', asc: true };
let _usrAuditAll   = [];

// ── Entry point ───────────────────────────────────────────────────────────────

async function pageUsers() {
  // Role guard — only Admin may manage users
  let me;
  try { me = await apiFetch('/api/me'); } catch(e) { me = {}; }
  if (me.role !== 'Admin') {
    document.getElementById('module-content').innerHTML = `
      <div class="coming-soon">
        <div class="cs-icon">🔒</div>
        <div class="cs-msg">Access restricted</div>
        <div class="cs-sub">Only Admin users can manage users and view the audit log.</div>
      </div>`;
    return;
  }
  await _usrRender();
}

async function _usrRender() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = `
    <div class="inv-toolbar">
      <input class="inv-search" id="usr-search" placeholder="Search users…" oninput="_usrApply()">
      <div class="inv-filter-group">
        <button class="filter-btn ${!_usrShowAll?'active':''}" onclick="_usrSetFilter(false)">Active</button>
        <button class="filter-btn ${_usrShowAll?'active':''}"  onclick="_usrSetFilter(true)">All</button>
      </div>
      <button class="btn btn-primary btn-sm" onclick="_usrNewForm()">+ New User</button>
    </div>

    <div class="usr-tab-bar">
      <button class="usr-tab ${_usrTab==='users'?'active':''}" onclick="_usrSwitchTab('users')">👥 Users</button>
      <button class="usr-tab ${_usrTab==='audit'?'active':''}" onclick="_usrSwitchTab('audit')">📋 Audit Log</button>
    </div>

    <div id="usr-panel">
      <div class="state-loading">Loading…</div>
    </div>
    <div class="mt-8"><span class="count-pill" id="usr-count"></span></div>`;

  await _usrLoad();
}

// ── Data loading ──────────────────────────────────────────────────────────────

async function _usrLoad() {
  if (_usrTab === 'users') {
    await _usrLoadUsers();
  } else {
    await _usrLoadAudit();
  }
}

async function _usrLoadUsers() {
  try {
    _usrAll = await apiFetch(`/api/users?active_only=${_usrShowAll ? 0 : 1}`);
  } catch(e) {
    document.getElementById('usr-panel').innerHTML =
      `<div class="state-error">Failed to load users: ${e.message}</div>`;
    return;
  }
  _usrApply();
}

async function _usrLoadAudit() {
  try {
    _usrAuditAll = await apiFetch('/api/users/audit-log');
  } catch(e) {
    document.getElementById('usr-panel').innerHTML =
      `<div class="state-error">Failed to load audit log: ${e.message}</div>`;
    return;
  }
  _usrRenderAudit();
}

// ── Users tab ─────────────────────────────────────────────────────────────────

function _usrApply() {
  const q = (document.getElementById('usr-search')?.value || '').toLowerCase();
  let rows = _usrAll.filter(u =>
    u.username.toLowerCase().includes(q) ||
    u.display_name.toLowerCase().includes(q) ||
    u.role.toLowerCase().includes(q)
  );

  // Sort
  rows.sort((a, b) => {
    let av = (a[_usrSort.col] || '').toString().toLowerCase();
    let bv = (b[_usrSort.col] || '').toString().toLowerCase();
    return _usrSort.asc ? av.localeCompare(bv) : bv.localeCompare(av);
  });

  _usrRenderTable(rows);
  const countEl = document.getElementById('usr-count');
  if (countEl) countEl.textContent = `${rows.length} of ${_usrAll.length} users`;
}

function _usrRenderTable(rows) {
  const cols = [
    { key: 'username',     label: 'Username' },
    { key: 'display_name', label: 'Display Name' },
    { key: 'role',         label: 'Role' },
    { key: 'last_login',   label: 'Last Login' },
    { key: '_status',      label: 'Status' },
    { key: '_actions',     label: '' },
  ];

  const thCells = cols.map(c => {
    if (c.key.startsWith('_')) return `<th></th>`;
    const cls = _usrSort.col === c.key
      ? (_usrSort.asc ? 'sort-asc' : 'sort-desc') : '';
    return `<th class="${cls}" onclick="_usrSortBy('${c.key}')">${c.label}</th>`;
  }).join('');

  const bodyRows = rows.length === 0
    ? `<tr><td colspan="6" class="tbl-empty-row">No users found.</td></tr>`
    : rows.map(u => {
        const statusBadge = u.is_active
          ? `<span class="badge badge-paid">Active</span>`
          : `<span class="badge badge-overdue">Inactive</span>`;

        const roleBadge = _usrRoleBadge(u.role);

        const lastLogin = u.last_login
          ? `<span class="inv-mono">${fmtDate(u.last_login.slice(0, 10))}</span>`
          : `<span class="col-ink3">Never</span>`;

        const toggleBtn = u.is_active
          ? `<button class="btn btn-amber btn-sm" onclick="_usrToggleActive(${u.id},false)" title="Deactivate">Deactivate</button>`
          : `<button class="btn btn-success btn-sm" onclick="_usrToggleActive(${u.id},true)" title="Reactivate">Reactivate</button>`;

        return `<tr class="inv-row" onclick="_usrEditForm(${u.id})">
          <td><span class="inv-contact">${esc(u.username)}</span></td>
          <td><span class="inv-mono">${esc(u.display_name)}</span></td>
          <td>${roleBadge}</td>
          <td>${lastLogin}</td>
          <td>${statusBadge}</td>
          <td onclick="event.stopPropagation()" class="usr-actions-cell">
            <button class="btn btn-outline btn-sm" onclick="_usrPasswordModal(${u.id},'${esc(u.username)}')">🔑 Password</button>
            <button class="btn btn-outline btn-sm" onclick="_usrPosPinModal(${u.id},'${esc(u.display_name)}',${u.has_pos_pin ? 1 : 0})" title="POS register PIN">
              ${u.has_pos_pin ? '🔐 PIN set' : '📟 Set PIN'}
            </button>
            ${toggleBtn}
          </td>
        </tr>`;
      }).join('');

  document.getElementById('usr-panel').innerHTML = `
    <div class="inv-list-panel">
      <div class="tbl-overflow-x">
        <table class="inv-list-table">
          <thead><tr>${thCells}</tr></thead>
          <tbody>${bodyRows}</tbody>
        </table>
      </div>
    </div>`;
}

function _usrRoleBadge(role) {
  const map = {
    'Admin':      ['badge-overdue',  'Admin / Owner'],
    'Accountant': ['badge-partial',  'Accountant'],
    'Trades':     ['badge-paid',     'Trades'],
    'Retail':     ['badge-pending',  'Retail'],
    'ReadOnly':   ['badge-draft',    'Read Only'],
    'Staff':      ['badge-pending',  'Staff'],  // legacy
  };
  const [cls, label] = map[role] || ['badge-draft', role];
  return `<span class="badge ${cls}">${label}</span>`;
}

function _usrSortBy(col) {
  if (_usrSort.col === col) {
    _usrSort.asc = !_usrSort.asc;
  } else {
    _usrSort = { col, asc: true };
  }
  _usrApply();
}

function _usrSetFilter(showAll) {
  _usrShowAll = showAll;
  // Re-render toolbar state
  document.querySelectorAll('.inv-filter-group .filter-btn').forEach((btn, i) => {
    btn.classList.toggle('active', showAll ? i === 1 : i === 0);
  });
  _usrLoadUsers();
}

function _usrSwitchTab(tab) {
  _usrTab = tab;
  document.querySelectorAll('.usr-tab').forEach(b =>
    b.classList.toggle('active', b.textContent.includes(tab === 'users' ? 'Users' : 'Audit')));
  // Hide/show toolbar elements that only belong to users tab
  const search = document.getElementById('usr-search');
  const filterGroup = document.querySelector('.inv-filter-group');
  const newBtn = document.querySelector('.inv-toolbar .btn-primary');
  const countPill = document.getElementById('usr-count');
  const show = tab === 'users';
  if (search) search.closest('.inv-toolbar').querySelectorAll(
    '.inv-search, .inv-filter-group, .btn-primary').forEach(el => {
    el.style.display = show ? '' : 'none';
  });
  if (countPill) countPill.textContent = '';
  document.getElementById('usr-panel').innerHTML = '<div class="state-loading">Loading…</div>';
  _usrLoad();
}

// ── Audit log tab ─────────────────────────────────────────────────────────────

function _usrRenderAudit() {
  const rows = _usrAuditAll;
  const bodyRows = rows.length === 0
    ? `<tr><td colspan="5" class="tbl-empty-row">No audit entries found.</td></tr>`
    : rows.map(e => `
        <tr class="inv-row">
          <td><span class="inv-mono">${esc(e.logged_at ? e.logged_at.slice(0,16).replace('T',' ') : '')}</span></td>
          <td><span class="inv-contact">${esc(e.username||'')}</span></td>
          <td>${esc(e.action||'')}</td>
          <td><span class="col-ink3">${esc(e.target_type||'')}${e.target_id ? ' #'+e.target_id : ''}</span></td>
          <td class="td-sm col-ink3">${esc(e.detail||'')}</td>
        </tr>`).join('');

  document.getElementById('usr-panel').innerHTML = `
    <div class="inv-list-panel">
      <div class="tbl-overflow-x">
        <table class="inv-list-table">
          <thead><tr>
            <th>When</th>
            <th>User</th>
            <th>Action</th>
            <th>Target</th>
            <th>Detail</th>
          </tr></thead>
          <tbody>${bodyRows}</tbody>
        </table>
      </div>
    </div>`;

  const countEl = document.getElementById('usr-count');
  if (countEl) countEl.textContent = `${rows.length} entries (most recent 200)`;
}

// ── Slide-over: New / Edit user ───────────────────────────────────────────────

async function _usrNewForm() {
  _usrOpenForm(null, {
    username: '', display_name: '', role: 'Staff', is_active: 1
  });
}

async function _usrEditForm(id) {
  let user;
  try { user = await apiFetch(`/api/users/${id}`); }
  catch(e) { toast('Failed to load user', 'err'); return; }
  _usrOpenForm(id, user);
}

function _usrOpenForm(id, user) {
  const isNew = !id;
  const title = isNew ? 'New User' : `Edit User — ${user.username}`;

  const knownRoles = ROLES.map(r => r.value);
  const legacyOption = !knownRoles.includes(user.role) && user.role
    ? `<option value="${esc(user.role)}" selected>${esc(user.role)} (legacy — please reassign)</option>`
    : '';
  const roleOptions = legacyOption + ROLES.map(r =>
    `<option value="${r.value}" ${r.value === user.role ? 'selected' : ''}>${r.label}</option>`
  ).join('');

  document.getElementById('det-body').innerHTML = `
    <div class="edt-section">
      <div class="edt-row">
        <div class="edt-field">
          <label class="edt-lbl">Username *</label>
          <input class="edt-inp" id="usr-f-username" type="text"
            value="${esc(user.username)}" ${isNew ? '' : 'readonly'} autocomplete="off">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Display Name *</label>
          <input class="edt-inp" id="usr-f-display" type="text"
            value="${esc(user.display_name)}" autocomplete="off">
        </div>
      </div>
      <div class="edt-row">
        <div class="edt-field">
          <label class="edt-lbl">Role *</label>
          <select class="edt-sel" id="usr-f-role" onchange="_usrRoleHint()">${roleOptions}</select>
          <div id="usr-role-hint" style="font-size:12px;color:var(--ink3);margin-top:4px">${_usrRoleHintText(user.role)}</div>
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Status</label>
          <select class="edt-sel" id="usr-f-active">
            <option value="1" ${user.is_active ? 'selected' : ''}>Active</option>
            <option value="0" ${!user.is_active ? 'selected' : ''}>Inactive</option>
          </select>
        </div>
      </div>
      ${isNew ? `
      <div class="edt-divider"></div>
      <div class="edt-row">
        <div class="edt-field">
          <label class="edt-lbl">Password *</label>
          <input class="edt-inp" id="usr-f-pw" type="password" autocomplete="new-password">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Confirm Password *</label>
          <input class="edt-inp" id="usr-f-pw2" type="password" autocomplete="new-password">
        </div>
      </div>` : ''}
      ${!isNew && user.role === 'Admin' ? `
      <div class="usr-admin-note">
        ⚠ This is an Admin account. Role changes take effect on next login.
      </div>` : ''}
    </div>`;

  document.getElementById('det-title').textContent = title;
  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-primary" onclick="_usrSave(${id || 'null'})">
      ${isNew ? 'Create User' : 'Save Changes'}
    </button>
    <button class="btn btn-outline" onclick="detClose()">Cancel</button>`;

  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('usr-f-display').focus();
}

async function _usrSave(id) {
  const isNew = !id;
  const username    = document.getElementById('usr-f-username')?.value.trim();
  const displayName = document.getElementById('usr-f-display')?.value.trim();
  const role        = document.getElementById('usr-f-role')?.value;
  const isActive    = parseInt(document.getElementById('usr-f-active')?.value || '1');

  if (!username)    { toast('Username is required', 'err'); return; }
  if (!displayName) { toast('Display name is required', 'err'); return; }

  let payload = { display_name: displayName, role, is_active: isActive };

  if (isNew) {
    const pw  = document.getElementById('usr-f-pw')?.value || '';
    const pw2 = document.getElementById('usr-f-pw2')?.value || '';
    if (!pw)         { toast('Password is required', 'err'); return; }
    if (pw !== pw2)  { toast('Passwords do not match', 'err'); return; }
    if (pw.length < 6) { toast('Password must be at least 6 characters', 'err'); return; }
    payload.username = username;
    payload.password = pw;
  }

  try {
    if (isNew) {
      await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload),
      }).then(async r => {
        const d = await r.json();
        if (!d.ok) throw new Error(d.error || 'Save failed');
      });
      toast('User created');
    } else {
      await fetch(`/api/users/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(payload),
      }).then(async r => {
        const d = await r.json();
        if (!d.ok) throw new Error(d.error || 'Save failed');
      });
      toast('User saved');
    }
    detClose();
    await _usrLoadUsers();
  } catch(e) {
    toast(e.message || 'Save failed', 'err');
  }
}

// ── Toggle active/inactive ────────────────────────────────────────────────────

async function _usrToggleActive(id, activate) {
  const action = activate ? 'reactivate' : 'deactivate';
  if (!confirm(`${activate ? 'Reactivate' : 'Deactivate'} this user?`)) return;
  try {
    const r = await fetch(`/api/users/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ is_active: activate ? 1 : 0 }),
    });
    const d = await r.json();
    if (!d.ok) throw new Error(d.error || 'Update failed');
    toast(activate ? 'User reactivated' : 'User deactivated');
    await _usrLoadUsers();
  } catch(e) {
    toast(e.message || 'Update failed', 'err');
  }
}

// ── Change password modal ─────────────────────────────────────────────────────

function _usrPasswordModal(id, username) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box" style="width:min(420px,96vw)">
      <div class="modal-hdr">
        <span>Change Password — ${esc(username)}</span>
      </div>
      <div class="modal-body">
        <div class="edt-field" style="margin-bottom:12px">
          <label class="edt-lbl">New Password *</label>
          <input class="edt-inp" id="usr-pw-new" type="password" autocomplete="new-password">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Confirm Password *</label>
          <input class="edt-inp" id="usr-pw-confirm" type="password" autocomplete="new-password">
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="_usrSavePassword(${id})">Set Password</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
  bd.querySelector('#usr-pw-new').focus();
}

async function _usrSavePassword(id) {
  const pw  = document.getElementById('usr-pw-new')?.value || '';
  const pw2 = document.getElementById('usr-pw-confirm')?.value || '';
  if (!pw)          { toast('Password is required', 'err'); return; }
  if (pw !== pw2)   { toast('Passwords do not match', 'err'); return; }
  if (pw.length < 6){ toast('Password must be at least 6 characters', 'err'); return; }

  try {
    const r = await fetch(`/api/users/${id}/set-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ password: pw }),
    });
    const d = await r.json();
    if (!d.ok) throw new Error(d.error || 'Failed');
    document.querySelector('.modal-bd')?.remove();
    toast('Password changed');
  } catch(e) {
    toast(e.message || 'Failed to change password', 'err');
  }
}

function _usrPosPinModal(id, displayName, hasPin) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'usr-pin-bd';
  bd.innerHTML = `<div class="modal-box" style="width:340px">
    <div class="modal-hdr">
      <span>POS PIN — ${esc(displayName)}</span>
      <button class="modal-close" onclick="document.getElementById('usr-pin-bd').remove()">✕</button>
    </div>
    <div class="modal-body" style="padding:18px 16px;display:flex;flex-direction:column;gap:10px">
      <p style="margin:0;font-size:13px;color:var(--ink2)">4–6 digit numeric PIN used to sign on to the POS register.</p>
      <label style="font-size:13px;font-weight:500">New PIN</label>
      <input id="usr-pin-new" type="password" inputmode="numeric" maxlength="6"
             placeholder="Enter PIN" autocomplete="new-password"
             style="padding:8px 10px;border:1px solid var(--border);border-radius:6px;font-size:16px;letter-spacing:4px;width:100%;box-sizing:border-box">
      <label style="font-size:13px;font-weight:500">Confirm PIN</label>
      <input id="usr-pin-confirm" type="password" inputmode="numeric" maxlength="6"
             placeholder="Confirm PIN" autocomplete="new-password"
             style="padding:8px 10px;border:1px solid var(--border);border-radius:6px;font-size:16px;letter-spacing:4px;width:100%;box-sizing:border-box">
    </div>
    <div class="modal-foot">
      ${hasPin ? `<button class="btn btn-danger btn-sm" onclick="_usrClearPin(${id})">Remove PIN</button>` : ''}
      <button class="btn btn-sec" onclick="document.getElementById('usr-pin-bd').remove()">Cancel</button>
      <button class="btn" onclick="_usrSavePin(${id})">Save PIN</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  setTimeout(() => document.getElementById('usr-pin-new')?.focus(), 60);
}

async function _usrSavePin(id) {
  const pin  = document.getElementById('usr-pin-new')?.value || '';
  const pin2 = document.getElementById('usr-pin-confirm')?.value || '';
  if (!pin)        { toast('PIN is required', 'err'); return; }
  if (pin !== pin2){ toast('PINs do not match', 'err'); return; }
  if (!/^\d{4,6}$/.test(pin)) { toast('PIN must be 4–6 digits', 'err'); return; }
  try {
    const r = await fetch(`/api/users/${id}/pos-pin`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      credentials: 'include',
      body: JSON.stringify({ pin }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Failed');
    document.getElementById('usr-pin-bd')?.remove();
    toast('POS PIN saved');
    _usrLoadUsers();
  } catch(e) {
    toast(e.message || 'Failed to save PIN', 'err');
  }
}

async function _usrClearPin(id) {
  try {
    const r = await fetch(`/api/users/${id}/pos-pin`, {
      method: 'DELETE', credentials: 'include',
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Failed');
    document.getElementById('usr-pin-bd')?.remove();
    toast('POS PIN removed');
    _usrLoadUsers();
  } catch(e) {
    toast(e.message || 'Failed', 'err');
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function _usrRoleHintText(roleValue) {
  const r = ROLES.find(x => x.value === roleValue);
  return r ? r.desc : '';
}

function _usrRoleHint() {
  const sel = document.getElementById('usr-f-role');
  const hint = document.getElementById('usr-role-hint');
  if (sel && hint) hint.textContent = _usrRoleHintText(sel.value);
}

