// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ── General Journal Module ────────────────────────────────────────────────────
// List all journal entries (all types) with type filter, date range, search.
// Manual Journal entries support: new, edit, void, reverse.
// System-generated entries (Invoice, Bill, etc.) are read-only.

let _jAll = [], _jTypeFilter = 'All', _jSort = {col:'entry_date', dir:-1};
let _jSelected = null;
let _jDateFrom = '', _jDateTo = '', _jSearch = '';
let _jLines = [];   // working line array for new/edit form

const _J_TAX_CODES = ['', 'GST', 'FRE', 'INP', 'N-T', 'CAP', 'EXP'];
const _J_GST_RATE  = 0.10;

const _J_TYPES = ['All','Journal','Invoice','Bill','Payment','Receipt','Payroll','CreditCard'];

// ── Page entry ────────────────────────────────────────────────────────────────
async function pageJournal() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading\u2026</div>';
  try {
    _jAll = await apiFetch('/api/journal?limit=500');
  } catch(e) {
    mod.innerHTML = `<div class="state-error">Failed to load journal: ${esc(e.message)}</div>`;
    return;
  }
  _jSelected = null;
  renderJPage();
}

// ── Filter / sort ─────────────────────────────────────────────────────────────
function _jFiltered() {
  let list = _jAll.slice();
  if (_jTypeFilter !== 'All') list = list.filter(e => e.entry_type === _jTypeFilter);

  const s = _jSearch.trim().toLowerCase();
  if (s)         list = list.filter(e =>
    (e.description||'').toLowerCase().includes(s) ||
    (e.reference||'').toLowerCase().includes(s)
  );
  if (_jDateFrom) list = list.filter(e => e.entry_date >= _jDateFrom);
  if (_jDateTo)   list = list.filter(e => e.entry_date <= _jDateTo);

  const {col, dir} = _jSort;
  list.sort((a, b) => {
    let av = a[col] ?? '', bv = b[col] ?? '';
    if (!isNaN(parseFloat(av)) && !isNaN(parseFloat(bv)))
      return (parseFloat(av) - parseFloat(bv)) * dir;
    return String(av).localeCompare(String(bv)) * dir;
  });
  return list;
}

function _jCounts() {
  const c = {All: _jAll.length};
  _jAll.forEach(e => { c[e.entry_type] = (c[e.entry_type]||0)+1; });
  return c;
}

function jSetType(t) { _jTypeFilter = t; renderJPage(); }
function jSortBy(col) {
  _jSort = {col, dir: _jSort.col===col ? _jSort.dir*-1 : -1};
  renderJPage();
}

// ── Entry-type badge ──────────────────────────────────────────────────────────
function jTypeBadge(t) {
  const map = {
    Journal:'badge-blue', Invoice:'badge-green', Bill:'badge-amber',
    Payment:'badge-green', Receipt:'badge-green',
    Payroll:'badge-muted', CreditCard:'badge-muted',
  };
  return `<span class="badge ${map[t]||'badge-muted'}">${t||'—'}</span>`;
}

// ── Render list ───────────────────────────────────────────────────────────────
function renderJPage(restoreFocus) {
  const mod      = document.getElementById('module-content');
  const counts   = _jCounts();
  const filtered = _jFiltered();

  const th = (col, lbl) => {
    const active = _jSort.col === col;
    const arrow  = active ? (_jSort.dir > 0 ? ' \u2191' : ' \u2193') : '';
    return `<th class="sortable${active?' sorted':''}" onclick="jSortBy('${col}')">${lbl}${arrow}</th>`;
  };

  mod.innerHTML = `
  <div class="inv-toolbar">
    <div class="inv-filter-group">
      ${_J_TYPES.map(t => `<button class="filter-btn${_jTypeFilter===t?' active':''}" onclick="jSetType('${t}')">
        ${t}${counts[t] ? ` <span style="font-size:10px;opacity:0.75;margin-left:2px">${counts[t]}</span>` : ''}
      </button>`).join('')}
    </div>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-left:auto">
      <label style="font-size:12px;color:var(--ink3)">From</label>
      <input id="j-from" type="date" class="edt-inp" style="width:140px"
        value="${_jDateFrom}" onchange="_jDateFrom=this.value;renderJPage()">
      <label style="font-size:12px;color:var(--ink3)">To</label>
      <input id="j-to" type="date" class="edt-inp" style="width:140px"
        value="${_jDateTo}" onchange="_jDateTo=this.value;renderJPage()">
      <input id="j-search" class="inv-search" placeholder="Search\u2026"
        value="${esc(_jSearch)}" oninput="_jSearch=this.value;renderJPage(true)" style="max-width:180px">
      <button class="btn btn-sm btn-primary" onclick="jNew()">+ New Entry</button>
    </div>
  </div>

  <div class="inv-list-panel"><div class="tbl-overflow-x">
    <table class="inv-list-table">
      <thead><tr>
        ${th('entry_date','Date')}
        ${th('entry_type','Type')}
        ${th('reference','Reference')}
        ${th('description','Description')}
        ${th('line_count','Lines')}
        ${th('total_debit','Debit')}
        ${th('total_credit','Credit')}
        <th>Status</th>
      </tr></thead>
      <tbody>
        ${filtered.length
          ? filtered.map(e => _jRow(e)).join('')
          : '<tr class="tbl-empty-row"><td colspan="8">No entries found</td></tr>'}
      </tbody>
    </table>
  </div></div>`;
  if(restoreFocus){const q=document.getElementById('j-search');if(q){q.focus();q.setSelectionRange(q.value.length,q.value.length);}}
}

function _jRow(e) {
  const voided = !!e.is_void;
  return `<tr class="inv-row${voided?' is-void':''}" onclick="jOpen(${e.id})">
    <td>${fmtDate(e.entry_date)}</td>
    <td>${jTypeBadge(e.entry_type)}</td>
    <td><span class="td-code">${esc(e.reference||'—')}</span></td>
    <td>${esc(e.description||'—')}</td>
    <td class="td-c-mono">${e.line_count||0}</td>
    <td class="td-r-mono">${fmt(e.total_debit)}</td>
    <td class="td-r-mono">${fmt(e.total_credit)}</td>
    <td>${voided
      ? '<span class="badge badge-red">Void</span>'
      : '<span class="badge badge-green">Posted</span>'}</td>
  </tr>`;
}

// ── Detail slide-over ─────────────────────────────────────────────────────────
async function jOpen(jid) {
  _jSelected = jid;
  _jPanelLoading('Journal Entry');
  let data;
  try { data = await apiFetch(`/api/journal/${jid}`); }
  catch(e) {
    document.getElementById('det-body').innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
    return;
  }
  _renderJDetail(data);
}

function _jPanelOpen() {
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
}

function _jPanelLoading(title) {
  _jPanelOpen();
  document.getElementById('det-title').textContent = title || 'Journal Entry';
  document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading\u2026</div>';
  document.getElementById('det-foot').innerHTML = '';
}

function _renderJDetail(data) {
  const e     = data.entry;
  const lines = data.lines||[];

  const isManual   = e.entry_type === 'Journal';
  const isVoided   = !!e.is_void;
  const canEdit    = isManual && !isVoided;
  const canVoid    = isManual && !isVoided;
  const canReverse = !isVoided;

  let runDr = 0, runCr = 0;
  lines.forEach(l => { runDr += l.debit||0; runCr += l.credit||0; });
  const balanced = Math.abs(runDr - runCr) < 0.005;

  _jPanelOpen();
  document.getElementById('det-title').textContent =
    e.entry_type === 'Journal' ? `JNL-${e.id}` : (e.description || 'Entry');

  document.getElementById('det-body').innerHTML = `
  <div class="det-meta" style="margin-bottom:16px">
    <div><div class="det-lbl">Date</div>
      <div class="det-val">${fmtDate(e.entry_date)}</div></div>
    <div><div class="det-lbl">Type</div>
      <div class="det-val">${jTypeBadge(e.entry_type)}${isVoided ? ' <span class="badge badge-red">Void</span>' : ''}</div></div>
    ${e.reference ? `<div><div class="det-lbl">Reference</div>
      <div class="det-val mono">${esc(e.reference)}</div></div>` : ''}
    <div class="edt-span"><div class="det-lbl">Description</div>
      <div class="det-val">${esc(e.description||'—')}</div></div>
  </div>

  <table class="det-lines" style="margin-bottom:10px">
    <thead><tr>
      <th>Account</th>
      <th>Description</th>
      <th class="th-r">Debit</th>
      <th class="th-r">Credit</th>
    </tr></thead>
    <tbody>
      ${lines.map(l => `<tr>
        <td><span class="td-code">${esc(l.account_code||l.account_id||'')}</span>
          ${esc(l.account_name||'')}</td>
        <td class="td-note">${esc(l.description||'')}</td>
        <td class="td-r-mono">${l.debit ? fmt(l.debit) : '—'}</td>
        <td class="td-r-mono">${l.credit ? fmt(l.credit) : '—'}</td>
      </tr>`).join('')}
    </tbody>
    <tfoot>
      <tr class="jnl-tot-row">
        <td colspan="2">Totals ${!balanced
          ? '<span class="col-red" style="font-size:11px;font-weight:400">\u26a0 Out of balance</span>' : ''}</td>
        <td class="td-r-mono">${fmt(runDr)}</td>
        <td class="td-r-mono">${fmt(runCr)}</td>
      </tr>
    </tfoot>
  </table>

  ${!isManual ? `<div class="jnl-sys-note">
    &#9432; System-generated entry &mdash; editing not available in the web UI.
  </div>` : ''}`;

  const foot = document.getElementById('det-foot');
  foot.innerHTML = '';
  const addBtn = (label, cls, fn, extraStyle) => {
    const b = document.createElement('button');
    b.className = `btn ${cls}`; b.innerHTML = label;
    if (extraStyle) b.style.cssText = extraStyle;
    b.onclick = fn; foot.appendChild(b);
  };
  if (canEdit)    addBtn('&#9998; Edit',      'btn-outline', () => jEdit(e.id));
  if (canReverse) addBtn('&#8635; Reverse',   'btn-outline', () => jReverse(e.id));
  if (canVoid)    addBtn('Void', 'btn-outline', () => jVoid(e.id), 'margin-left:auto;color:var(--red);border-color:var(--red)');
}

// ── New / Edit form ───────────────────────────────────────────────────────────
let _jAccounts = [];

async function _loadJAccounts() {
  if (_jAccounts.length) return;
  try { _jAccounts = await apiFetch('/api/accounts'); } catch(_) {}
}

async function jNew() {
  await _loadJAccounts();
  _jLines = [
    {account_id:'', debit:0, credit:0, description:'', tax_code:'', gst_amount:0},
    {account_id:'', debit:0, credit:0, description:'', tax_code:'', gst_amount:0},
  ];
  _renderJForm({entry_date:today(), description:'', reference:''}, null, false);
}

async function jEdit(jid) {
  await _loadJAccounts();
  let data;
  try { data = await apiFetch(`/api/journal/${jid}`); }
  catch(e) { toast(e.message, 'err'); return; }
  if (data.entry.entry_type !== 'Journal') {
    toast('Only manual journal entries can be edited', 'err'); return;
  }
  _jLines = (data.lines||[]).map(l => ({
    account_id: l.account_id, debit: l.debit||0,
    credit: l.credit||0, description: l.description||'',
    tax_code: l.tax_code||'', gst_amount: l.gst_amount||0,
  }));
  if (_jLines.length < 2)
    _jLines.push({account_id:'', debit:0, credit:0, description:''});
  _renderJForm(data.entry, jid, true);
}

function _renderJForm(entry, jid, isEdit) {
  _jPanelOpen();
  document.getElementById('det-title').textContent =
    isEdit ? `Edit JNL-${jid}` : 'New Journal Entry';

  document.getElementById('det-body').innerHTML = `
  <div class="edt-grid" style="margin-bottom:14px">
    <div class="edt-field"><label class="edt-lbl">Date *</label>
      <input class="edt-inp" id="jf-date" type="date" value="${entry.entry_date||today()}"></div>
    <div class="edt-field"><label class="edt-lbl">Reference</label>
      <input class="edt-inp" id="jf-ref" type="text" placeholder="e.g. ADJ-001"
        value="${esc(entry.reference||'')}"></div>
    <div class="edt-field edt-span"><label class="edt-lbl">Description *</label>
      <input class="edt-inp" id="jf-desc" type="text" placeholder="Purpose of this entry\u2026"
        value="${esc(entry.description||'')}"></div>
  </div>

  <div class="tbl-overflow-x" style="margin-bottom:0">
    <div style="min-width:650px">
      <div class="jnl-hdr-row">
        <span>Account</span><span style="text-align:right">Debit</span>
        <span style="text-align:right">Credit</span><span>Line Description</span>
        <span style="text-align:center">Tax</span><span style="text-align:right">GST</span><span></span>
      </div>
      <div id="jf-lines"></div>
      <div style="display:flex;gap:8px;margin-top:8px;align-items:center">
        <button class="btn btn-outline edt-add-btn" onclick="jAddLine()">+ Add Line</button>
        <button class="btn btn-outline edt-add-btn" onclick="jAutoBalance()" title="Fill last empty line to make entry balance">↹ Auto-balance</button>
      </div>
    </div>
  </div>

  <div id="jf-balance" class="jnl-bal"></div>`;

  const foot = document.getElementById('det-foot');
  foot.innerHTML = '';
  const addBtn = (label, cls, fn, id) => {
    const b = document.createElement('button');
    b.className = `btn ${cls}`; b.innerHTML = label;
    if (id) b.id = id;
    b.onclick = fn; foot.appendChild(b);
  };
  addBtn(isEdit ? 'Save Changes' : 'Post Entry', 'btn-primary',
    () => jSave(jid||null), 'jf-save-btn');
  addBtn('Cancel', 'btn-outline',
    () => isEdit ? jOpen(jid) : detClose());

  jRenderLines();
}

function jRenderLines() {
  const el = document.getElementById('jf-lines');
  if (!el) return;

  const accOpts = _jAccounts.map(a =>
    `<option value="${a.id}">${esc(a.code)} — ${esc(a.name)}</option>`).join('');
  const taxOpts = _J_TAX_CODES.map(c =>
    `<option value="${c}">${c||'—'}</option>`).join('');

  el.innerHTML = _jLines.map((l, i) => `
  <div class="jnl-line-row">
    <select class="edt-sel" id="jl-acc-${i}"
      onchange="_jLines[${i}].account_id=parseInt(this.value)||'';jBalCheck()">
      <option value="">— Account —</option>${accOpts.replace(
        `value="${l.account_id}"`, `value="${l.account_id}" selected`)}
    </select>
    <input class="edt-inp" type="number" step="0.01" min="0" id="jl-dr-${i}"
      value="${l.debit||''}" placeholder="0.00"
      oninput="_jLines[${i}].debit=parseFloat(this.value)||0;
               if(this.value)document.getElementById('jl-cr-${i}').value='',_jLines[${i}].credit=0;
               _jGstAuto(${i});jBalCheck()">
    <input class="edt-inp" type="number" step="0.01" min="0" id="jl-cr-${i}"
      value="${l.credit||''}" placeholder="0.00"
      oninput="_jLines[${i}].credit=parseFloat(this.value)||0;
               if(this.value)document.getElementById('jl-dr-${i}').value='',_jLines[${i}].debit=0;
               _jGstAuto(${i});jBalCheck()">
    <input class="edt-inp" type="text" id="jl-desc-${i}" value="${esc(l.description||'')}"
      placeholder="Line description\u2026"
      oninput="_jLines[${i}].description=this.value">
    <select class="edt-sel" id="jl-tax-${i}"
      onchange="_jLines[${i}].tax_code=this.value;_jGstAuto(${i})">
      ${taxOpts.replace(`value="${l.tax_code||''}"`, `value="${l.tax_code||''}" selected`)}
    </select>
    <input class="edt-inp" type="number" step="0.01" min="0" id="jl-gst-${i}"
      value="${l.gst_amount||''}" placeholder="0.00"
      oninput="_jLines[${i}].gst_amount=parseFloat(this.value)||0">
    <button style="background:none;border:none;color:var(--red);cursor:pointer;
      font-size:14px;padding:0 4px" onclick="jRemoveLine(${i})">&times;</button>
  </div>`).join('');

  jBalCheck();
}

function _jGstAuto(i) {
  const tc    = document.getElementById(`jl-tax-${i}`)?.value || '';
  const amt   = parseFloat(document.getElementById(`jl-dr-${i}`)?.value) ||
                parseFloat(document.getElementById(`jl-cr-${i}`)?.value) || 0;
  const gstEl = document.getElementById(`jl-gst-${i}`);
  if (!gstEl) return;
  if ((tc === 'GST' || tc === 'CAP') && amt) {
    const g = Math.round(amt * _J_GST_RATE * 100) / 100;
    gstEl.value = g;
    _jLines[i].gst_amount = g;
  } else if (['FRE','INP','N-T','EXP'].includes(tc)) {
    gstEl.value = '';
    _jLines[i].gst_amount = 0;
  }
}

function jAutoBalance() {
  let dr = 0, cr = 0;
  _jLines.forEach(l => { dr += parseFloat(l.debit)||0; cr += parseFloat(l.credit)||0; });
  dr = Math.round(dr*100)/100; cr = Math.round(cr*100)/100;
  const diff = Math.round((dr - cr)*100)/100;
  if (Math.abs(diff) < 0.005) return;
  // Try to fill the last empty row first
  for (let i = _jLines.length - 1; i >= 0; i--) {
    const l = _jLines[i];
    if (!l.debit && !l.credit) {
      if (diff > 0) {
        l.credit = Math.round(diff * 100) / 100;
        _jLines[i] = l;
      } else {
        l.debit = Math.round(-diff * 100) / 100;
        _jLines[i] = l;
      }
      jRenderLines();
      return;
    }
  }
  // No empty row — add a new one
  if (diff > 0) {
    _jLines.push({account_id:'', debit:0, credit:Math.round(diff*100)/100, description:'', tax_code:'', gst_amount:0});
  } else {
    _jLines.push({account_id:'', debit:Math.round(-diff*100)/100, credit:0, description:'', tax_code:'', gst_amount:0});
  }
  jRenderLines();
}

function jAddLine() {
  _jLines.push({account_id:'', debit:0, credit:0, description:'', tax_code:'', gst_amount:0});
  jRenderLines();
  const idx = _jLines.length - 1;
  const el = document.getElementById(`jl-acc-${idx}`);
  if (el) el.focus();
}

function jRemoveLine(i) {
  if (_jLines.length <= 2) { toast('Journal must have at least 2 lines', 'err'); return; }
  _jLines.splice(i, 1);
  jRenderLines();
}

function jBalCheck() {
  const el = document.getElementById('jf-balance');
  if (!el) return;
  let dr = 0, cr = 0;
  _jLines.forEach(l => { dr += parseFloat(l.debit)||0; cr += parseFloat(l.credit)||0; });
  dr = Math.round(dr*100)/100; cr = Math.round(cr*100)/100;
  const diff = Math.round((dr-cr)*100)/100;
  const ok = Math.abs(diff) < 0.005;
  el.style.background = ok ? 'var(--green-dim)' : 'var(--red-dim)';
  el.style.borderColor = ok ? 'var(--green)' : 'var(--red)';
  el.style.color       = ok ? 'var(--green)' : 'var(--red)';
  el.innerHTML = ok
    ? `<strong>&#10003; Balanced</strong> &mdash; Dr ${fmt(dr)} = Cr ${fmt(cr)}`
    : `<strong>&#9888; Out of balance</strong> &mdash; Dr ${fmt(dr)} / Cr ${fmt(cr)}
       &mdash; difference ${fmt(Math.abs(diff))}`;
}

// ── Save ──────────────────────────────────────────────────────────────────────
async function jSave(jid) {
  const dateVal = document.getElementById('jf-date')?.value;
  const descVal = document.getElementById('jf-desc')?.value.trim();
  if (!dateVal)  { toast('Date is required', 'err'); return; }
  if (!descVal)  { toast('Description is required', 'err'); return; }

  // Re-read lines from DOM to catch any direct edits
  _jLines.forEach((l, i) => {
    const accEl = document.getElementById(`jl-acc-${i}`);
    const drEl  = document.getElementById(`jl-dr-${i}`);
    const crEl  = document.getElementById(`jl-cr-${i}`);
    const dEl   = document.getElementById(`jl-desc-${i}`);
    const txEl  = document.getElementById(`jl-tax-${i}`);
    const gstEl = document.getElementById(`jl-gst-${i}`);
    if (accEl) l.account_id  = parseInt(accEl.value)||'';
    if (drEl)  l.debit       = parseFloat(drEl.value)||0;
    if (crEl)  l.credit      = parseFloat(crEl.value)||0;
    if (dEl)   l.description = dEl.value||'';
    if (txEl)  l.tax_code    = txEl.value||'';
    if (gstEl) l.gst_amount  = parseFloat(gstEl.value)||0;
  });

  const validLines = _jLines.filter(l => l.account_id && (l.debit || l.credit));
  if (validLines.length < 2) { toast('Need at least 2 account lines', 'err'); return; }

  const dr = validLines.reduce((s,l) => s + (l.debit||0), 0);
  const cr = validLines.reduce((s,l) => s + (l.credit||0), 0);
  if (Math.abs(dr - cr) >= 0.005) { toast('Entry is out of balance — debits must equal credits', 'err'); return; }

  const btn = document.getElementById('jf-save-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Posting\u2026'; }

  const body = {
    entry_date:  dateVal,
    description: descVal,
    reference:   document.getElementById('jf-ref')?.value.trim()||'',
    lines: validLines.map(l => ({
      account_id:  l.account_id,
      debit:       l.debit||0,
      credit:      l.credit||0,
      description: l.description||'',
      tax_code:    l.tax_code||null,
      gst_amount:  l.gst_amount||0,
    })),
  };

  try {
    const method = jid ? 'PUT' : 'POST';
    const url    = jid ? `/api/journal/${jid}` : '/api/journal';
    const r = await fetch(url, {
      method, credentials:'include',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(body),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error||'Save failed');
    toast(jid ? 'Entry updated' : 'Entry posted');
    _jAll = await apiFetch('/api/journal?limit=500');
    renderJPage();
    const savedId = jid || j.data?.id;
    if (savedId) jOpen(savedId);
  } catch(e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = jid ? 'Save Changes' : 'Post Entry'; }
  }
}

async function jVoid(jid) {
  if (!confirm('Void this journal entry? A reversing entry will be posted automatically.')) return;
  try {
    const r = await fetch(`/api/journal/${jid}/void`, {
      method: 'POST', credentials: 'include',
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Void failed');
    toast('Entry voided');
    _jAll = await apiFetch('/api/journal?limit=500');
    renderJPage();
    jOpen(jid);
  } catch(e) { toast(e.message, 'err'); }
}

async function jReverse(jid) {
  const reverseDate = prompt('Reversal date (YYYY-MM-DD):', isoToday());
  if (!reverseDate) return;
  try {
    const r = await fetch(`/api/journal/${jid}/reverse`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({reverse_date: reverseDate}),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Reverse failed');
    toast('Reversal entry posted');
    _jAll = await apiFetch('/api/journal?limit=500');
    renderJPage();
    if (j.data?.reversal_id) jOpen(j.data.reversal_id);
  } catch(e) { toast(e.message, 'err'); }
}
