// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ═══════════════════════════════════════════════════════════════════════════
// settings.js  —  Settings module for Dogbox web UI
//
// Sections mirroring the tkinter app menus:
//   File      → Company Details · Email/SMTP Settings
//   View      → Colour Scheme  (sidebar swatches; shown as info here)
//   Users     → Manage Users · Discount Limits · Audit Log (→ users.js)
//   Payroll   → nav shortcuts (→ payroll.js)
//   Journal   → nav shortcut (→ journal.js)
//
// Namespace prefix: _set*
// Entry point:      pageSettings()
// ═══════════════════════════════════════════════════════════════════════════

// ── State ────────────────────────────────────────────────────────────────────
let _setActiveSection = 'company';

// ── Entry point ──────────────────────────────────────────────────────────────
function pageSettings() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = `
    <div class="set-layout">

      <!-- Left nav -->
      <div class="set-nav" id="set-nav">
        <div class="set-nav-group">File</div>
        <div class="set-nav-item active" data-sec="company"   onclick="_setNav('company')">🏢  Company Details</div>
        <div class="set-nav-item"        data-sec="email"     onclick="_setNav('email')">✉  Email / SMTP</div>
        <div class="set-nav-item"        data-sec="docnums"   onclick="_setNav('docnums')">🔢  Document Numbers</div>
        <div class="set-nav-item"        data-sec="licence"   onclick="_setNav('licence')">🔑  Licence</div>

        <div class="set-nav-group">View</div>
        <div class="set-nav-item"        data-sec="theme"     onclick="_setNav('theme')">🎨  Colour Scheme</div>

        <div class="set-nav-group">Users</div>
        <div class="set-nav-item"        onclick="navigate('users')">👤  Manage Users</div>
        <div class="set-nav-item"        data-sec="discounts" onclick="_setNav('discounts')">🏷  Discount Limits</div>
        <div class="set-nav-item"        onclick="navigate('users')">📋  Audit Log</div>
        <div class="set-nav-item"        data-sec="eula"      onclick="_setNav('eula')">📄  Licence Agreement</div>

        <div class="set-nav-group">Wizards</div>
        <div class="set-nav-item"        onclick="navigate('wizard')">🧙  Setup Wizard</div>
        <div class="set-nav-item"        data-sec="opening"   onclick="_setNav('opening')">🧮  Opening Balances</div>
        <div class="set-nav-item"        data-sec="arap"      onclick="_setNav('arap')">↔  AR/AP Reconciliation</div>
        <div class="set-nav-item"        data-sec="txn_import" onclick="_setNav('txn_import')">📥  Transaction Import</div>
        <div class="set-nav-item"        data-sec="migration" onclick="_setNav('migration')">🔄  Import from Software</div>
        <div class="set-nav-item"        data-sec="backup"    onclick="_setNav('backup')">💾  Auto-Backup</div>
        <div class="set-nav-item"        data-sec="files"     onclick="_setNav('files')">📁  Files &amp; Folders</div>
        <div class="set-nav-item"        data-sec="eofy"      onclick="_setNav('eofy')">📅  EOFY Rollover</div>

        <div class="set-nav-group">Maintenance</div>
        <div class="set-nav-item"        data-sec="repair"    onclick="_setNav('repair')">🔧  Data Repair</div>

        <div class="set-nav-group">Shortcuts</div>
        <div class="set-nav-item"        onclick="navigate('payroll')">💼  Payroll</div>
        <div class="set-nav-item"        onclick="navigate('journal')">📓  Journal</div>
        <div class="set-nav-item"        onclick="navigate('reports')">📈  Reports</div>
      </div>

      <!-- Right content -->
      <div class="set-body" id="set-body">
        <div class="state-loading">Loading…</div>
      </div>

    </div>`;

  _setNav(_setActiveSection);
}

function _setNav(sec) {
  const INLINE_SECTIONS = new Set(['company','email','docnums','licence','theme','discounts','opening','arap','txn_import','migration','backup','files','eula','repair','eofy']);
  if (INLINE_SECTIONS.has(sec)) _setActiveSection = sec;
  document.querySelectorAll('.set-nav-item[data-sec]').forEach(el =>
    el.classList.toggle('active', el.dataset.sec === sec));

  const body = document.getElementById('set-body');
  body.innerHTML = '<div class="state-loading">Loading…</div>';

  const dispatch = {
    company:   _setLoadCompany,
    email:     _setLoadEmail,
    docnums:   _setLoadDocNums,
    licence:   _setLoadLicence,
    theme:     _setLoadTheme,
    discounts: _setLoadDiscounts,
    opening:    _setLoadOpening,
    arap:       _setLoadArap,
    txn_import: _tiShow,
    migration:  _migShow,
    backup:    _setLoadBackup,
    files:     _setLoadFiles,
    eula:      _setLoadEula,
    repair:    _setLoadRepair,
    eofy:      _setLoadEofy,
  };
  (dispatch[sec] || (() => { body.innerHTML = '<div class="coming-soon"><div class="cs-icon">🚧</div><div class="cs-msg">Coming soon.</div></div>'; }))();
}

// ── Desktop-only stub ─────────────────────────────────────────────────────────
function _setLoadDesktopStub(icon, title, desc) {
  document.getElementById('set-body').innerHTML = `
    <div class="set-section-hdr">${icon}  ${esc(title)}</div>
    <div class="coming-soon" style="margin-top:32px">
      <div class="cs-icon">🖥</div>
      <div class="cs-msg">${esc(title)}</div>
      <div class="cs-sub">${esc(desc)}</div>
    </div>`;
}

// ═══════════════════════════════════════════════════════════════════════════
// COMPANY DETAILS
// ═══════════════════════════════════════════════════════════════════════════
async function _setLoadCompany() {
  let company = {}, me = {};
  try {
    [company, me] = await Promise.all([
      apiFetch('/api/company').catch(() => ({})),
      apiFetch('/api/me').catch(() => ({})),
    ]);
    company = company || {};
    me = me || {};
  } catch(e) { document.getElementById('set-body').innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`; return; }
  const isPro = (me.tier_caps || []).includes('recurring');

  document.getElementById('set-body').innerHTML = `
    <div class="set-section-hdr">🏢  Company Details</div>
    <div class="set-form-grid set-form-2col">
      <div class="set-field">
        <label class="set-lbl">Company Name *</label>
        <input class="set-inp" id="sf-name" type="text" value="${esc(company.name||'')}">
      </div>
      <div class="set-field">
        <label class="set-lbl">ABN</label>
        <input class="set-inp" id="sf-abn" type="text" value="${esc(company.abn||'')}">
      </div>
      <div class="set-field">
        <label class="set-lbl">ACN</label>
        <input class="set-inp" id="sf-acn" type="text" value="${esc(company.acn||'')}">
      </div>
      <div class="set-field">
        <label class="set-lbl">Phone</label>
        <input class="set-inp" id="sf-phone" type="text" value="${esc(company.phone||'')}">
      </div>
      <div class="set-field">
        <label class="set-lbl">Email</label>
        <input class="set-inp" id="sf-email" type="email" value="${esc(company.email||'')}">
      </div>
      <div class="set-field">
        <label class="set-lbl">Website</label>
        <input class="set-inp" id="sf-website" type="text" value="${esc(company.website||'')}">
      </div>
    </div>

    <div class="set-form-grid set-form-1col" style="margin-top:12px">
      <div class="set-field">
        <label class="set-lbl">Address</label>
        <input class="set-inp" id="sf-address" type="text" value="${esc(company.address||'')}">
      </div>
    </div>
    <div class="set-form-grid set-form-3col" style="margin-top:8px">
      <div class="set-field">
        <label class="set-lbl">City / Suburb</label>
        <input class="set-inp" id="sf-city" type="text" value="${esc(company.city||'')}">
      </div>
      <div class="set-field">
        <label class="set-lbl">State</label>
        <input class="set-inp" id="sf-state" type="text" value="${esc(company.state||'')}">
      </div>
      <div class="set-field">
        <label class="set-lbl">Postcode</label>
        <input class="set-inp" id="sf-postcode" type="text" value="${esc(company.postcode||'')}">
      </div>
    </div>

    <div class="set-divider"></div>

    <div class="set-form-grid set-form-1col">
      <div class="set-field">
        <label class="set-lbl">Default Payment Instructions</label>
        <div class="set-hint">Pre-fills new invoices · e.g. BSB, account number, bank name</div>
        <textarea class="set-inp set-ta" id="sf-pmt" rows="3">${esc(company.default_payment_instructions||'')}</textarea>
      </div>
    </div>

    <div class="set-form-grid set-form-1col" style="margin-top:12px">
      <div class="set-field set-check-field">
        <input type="checkbox" id="sf-gst" ${company.gst_registered ? 'checked' : ''}>
        <label class="set-lbl" for="sf-gst">Registered for GST</label>
      </div>
    </div>

    <div class="set-form-grid set-form-1col" style="margin-top:8px">
      <div class="set-field set-check-field">
        <input type="checkbox" id="sf-branding" ${company.pdf_branding !== 0 ? 'checked' : ''}${isPro ? '' : ' disabled'}>
        <label class="set-lbl" for="sf-branding">Show "Created with Dogbox Accounting" footer on PDFs${isPro ? '' : ' <span style="color:var(--ink3);font-weight:400">(Pro — always on in Free)</span>'}</label>
      </div>
    </div>

    <div class="set-divider"></div>

    <div class="set-form-grid set-form-1col">
      <div class="set-field">
        <label class="set-lbl">Invoice Logo</label>
        <div class="set-hint">PNG / JPG / GIF  ·  Appears on invoices, bills, and receipts  ·  ~45 mm wide</div>
        <div class="set-logo-row" id="sf-logo-row">
          ${company.has_logo
            ? `<img class="set-logo-preview" id="sf-logo-img" src="/api/company/logo?v=${Date.now()}" alt="Company logo">`
            : `<div class="set-logo-empty" id="sf-logo-empty">No logo set</div>`
          }
          <div class="set-logo-btns">
            <label class="btn btn-sm" for="sf-logo-input" style="cursor:pointer">Upload…</label>
            <input type="file" id="sf-logo-input" accept=".png,.jpg,.jpeg,.gif" style="display:none" onchange="_setLogoUpload(this)">
            ${company.has_logo ? `<button class="btn btn-sm btn-danger" onclick="_setLogoClear()">Clear</button>` : ''}
          </div>
        </div>
      </div>
    </div>

    <div class="set-foot">
      <button class="btn btn-primary" onclick="_setCompanySave()">Save Changes</button>
    </div>`;
}

async function _setCompanySave() {
  const name = document.getElementById('sf-name').value.trim();
  if (!name) { toast('Company name is required', 'err'); return; }

  const data = {
    name,
    abn:      document.getElementById('sf-abn').value.trim(),
    acn:      document.getElementById('sf-acn').value.trim(),
    phone:    document.getElementById('sf-phone').value.trim(),
    email:    document.getElementById('sf-email').value.trim(),
    website:  document.getElementById('sf-website').value.trim(),
    address:  document.getElementById('sf-address').value.trim(),
    city:     document.getElementById('sf-city').value.trim(),
    state:    document.getElementById('sf-state').value.trim(),
    postcode: document.getElementById('sf-postcode').value.trim(),
    default_payment_instructions: document.getElementById('sf-pmt').value,
    gst_registered: document.getElementById('sf-gst').checked ? 1 : 0,
    pdf_branding:   document.getElementById('sf-branding')?.checked ? 1 : 0,
  };

  try {
    const r = await fetch('/api/company', {
      method: 'PUT',
      credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(data),
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Save failed', 'err'); return; }
    toast('Company details saved');
    // Refresh company name in sidebar
    document.getElementById('company-name').textContent = name;
  } catch(e) {
    toast('Save failed: ' + e.message, 'err');
  }
}

async function _setLogoUpload(input) {
  if (!input.files.length) return;
  const fd = new FormData();
  fd.append('logo', input.files[0]);
  try {
    const r = await fetch('/api/company/logo', {method:'POST', credentials:'include', body:fd});
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Upload failed', 'err'); return; }
    toast('Logo uploaded');
    _setLoadCompany();
    _refreshSidebarLogo();
  } catch(e) { toast('Upload failed: ' + e.message, 'err'); }
}

async function _setLogoClear() {
  try {
    const r = await fetch('/api/company/logo', {method:'DELETE', credentials:'include'});
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Failed to clear logo', 'err'); return; }
    toast('Logo removed');
    _setLoadCompany();
    _refreshSidebarLogo();
  } catch(e) { toast('Failed: ' + e.message, 'err'); }
}

function _refreshSidebarLogo() {
  const img = document.getElementById('brand-logo');
  const wm  = document.getElementById('brand-wordmark');
  if (!img) return;
  const probe = new Image();
  probe.onload = () => {
    img.src = '/api/company/logo?v=' + Date.now();
    img.style.display = '';
    if (wm) wm.style.display = 'none';
  };
  probe.onerror = () => {
    img.style.display = 'none';
    if (wm) wm.style.display = '';
  };
  probe.src = '/api/company/logo?v=' + Date.now();
}

// ═══════════════════════════════════════════════════════════════════════════
// EMAIL / SMTP SETTINGS
// ═══════════════════════════════════════════════════════════════════════════
async function _setLoadEmail() {
  let s = {};
  try { s = await apiFetch('/api/settings/email') || {}; }
  catch(e) { document.getElementById('set-body').innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`; return; }

  document.getElementById('set-body').innerHTML = `
    <div class="set-section-hdr">✉  Email / SMTP Settings</div>

    <div class="set-hint" style="margin-bottom:14px">
      Gmail tip: Enable 2-Step Verification, then create an App Password under
      Google Account → Security → App passwords. Use that password here, not your regular password.
    </div>

    <div class="set-preset-row">
      <span class="set-lbl">Quick presets:</span>
      <button class="btn btn-outline btn-sm" onclick="_setEmailPreset('smtp.gmail.com',587,true)">Gmail</button>
      <button class="btn btn-outline btn-sm" onclick="_setEmailPreset('smtp-mail.outlook.com',587,true)">Outlook</button>
      <button class="btn btn-outline btn-sm" onclick="_setEmailPreset('smtp.office365.com',587,true)">Office 365</button>
      <button class="btn btn-outline btn-sm" onclick="_setEmailPreset('smtp.mail.yahoo.com',465,true)">Yahoo</button>
    </div>

    <div class="set-form-grid set-form-2col" style="margin-top:14px">
      <div class="set-field">
        <label class="set-lbl">SMTP Host *</label>
        <input class="set-inp" id="em-host" type="text" value="${esc(s.smtp_host||'')}">
      </div>
      <div class="set-field">
        <label class="set-lbl">SMTP Port *</label>
        <input class="set-inp" id="em-port" type="number" value="${esc(s.smtp_port||587)}">
      </div>
      <div class="set-field">
        <label class="set-lbl">Username (email) *</label>
        <input class="set-inp" id="em-user" type="email" value="${esc(s.smtp_user||'')}">
      </div>
      <div class="set-field">
        <label class="set-lbl">Password / App Password *</label>
        <input class="set-inp" id="em-pass" type="password" value="${esc(s.smtp_password||'')}">
      </div>
      <div class="set-field">
        <label class="set-lbl">From Name</label>
        <input class="set-inp" id="em-fromname" type="text" value="${esc(s.from_name||'')}">
      </div>
      <div class="set-field">
        <label class="set-lbl">From Email</label>
        <input class="set-inp" id="em-fromemail" type="email" value="${esc(s.from_email||'')}">
      </div>
    </div>

    <div class="set-form-grid set-form-1col" style="margin-top:8px">
      <div class="set-field set-check-field">
        <input type="checkbox" id="em-tls" ${s.use_tls !== 0 ? 'checked' : ''}>
        <label class="set-lbl" for="em-tls">Use TLS / STARTTLS (recommended)</label>
      </div>
    </div>

    <div class="set-divider"></div>
    <div class="set-section-sub">Email Template</div>

    <div class="set-form-grid set-form-1col">
      <div class="set-field">
        <label class="set-lbl">Subject</label>
        <input class="set-inp" id="em-subj" type="text"
               value="${esc(s.invoice_subject || 'Invoice {invoice_number} from {company_name}')}">
      </div>
      <div class="set-field" style="margin-top:10px">
        <label class="set-lbl">Body</label>
        <textarea class="set-inp set-ta" id="em-body" rows="5">${esc(s.invoice_body || 'Please find attached invoice {invoice_number} for {total}.\n\nThank you for your business.\n\n{company_name}')}</textarea>
        <div class="set-hint">Variables: {invoice_number} {company_name} {total} {due_date} {customer}</div>
      </div>
    </div>

    <div class="set-divider"></div>
    <div class="set-section-sub">Overdue Notice Template</div>
    <div class="set-form-grid set-form-1col">
      <div class="set-field">
        <label class="set-lbl">Subject</label>
        <input class="set-inp" id="em-od-subj" type="text"
               value="${esc(s.overdue_subject || 'Overdue invoice {invoice_number} — {company_name}')}">
      </div>
      <div class="set-field" style="margin-top:10px">
        <label class="set-lbl">Body</label>
        <textarea class="set-inp set-ta" id="em-od-body" rows="6">${esc(s.overdue_body || 'Dear {customer},\n\nThis is a reminder that invoice {invoice_number} for {total} was due on {due_date} and remains unpaid.\n\nPlease arrange payment at your earliest convenience.\n\nRegards,\n{company_name}')}</textarea>
        <div class="set-hint">Variables: {invoice_number} {company_name} {total} {due_date} {days_overdue} {customer}</div>
      </div>
    </div>

    <div class="set-foot">
      <button class="btn btn-primary" onclick="_setEmailSave()">Save Settings</button>
      <button class="btn btn-outline" onclick="_setEmailTest()" style="margin-left:8px">Test Connection</button>
    </div>`;
}

function _setEmailPreset(host, port, tls) {
  const h = document.getElementById('em-host');
  const p = document.getElementById('em-port');
  const t = document.getElementById('em-tls');
  if (h) h.value = host;
  if (p) p.value = port;
  if (t) t.checked = tls;
}

async function _setEmailSave() {
  const data = {
    smtp_host:        document.getElementById('em-host').value.trim(),
    smtp_port:        parseInt(document.getElementById('em-port').value) || 587,
    smtp_user:        document.getElementById('em-user').value.trim(),
    smtp_password:    document.getElementById('em-pass').value,
    from_name:        document.getElementById('em-fromname').value.trim(),
    from_email:       document.getElementById('em-fromemail').value.trim(),
    use_tls:          document.getElementById('em-tls').checked ? 1 : 0,
    invoice_subject:  document.getElementById('em-subj').value,
    invoice_body:     document.getElementById('em-body').value,
    overdue_subject:  document.getElementById('em-od-subj').value,
    overdue_body:     document.getElementById('em-od-body').value,
  };
  try {
    const r = await fetch('/api/settings/email', {
      method: 'POST',
      credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(data),
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Save failed', 'err'); return; }
    toast('Email settings saved');
  } catch(e) {
    toast('Save failed: ' + e.message, 'err');
  }
}

async function _setEmailTest() {
  const host = document.getElementById('em-host').value.trim();
  const port = parseInt(document.getElementById('em-port').value) || 587;
  const user = document.getElementById('em-user').value.trim();
  const pass = document.getElementById('em-pass').value;
  const tls  = document.getElementById('em-tls').checked ? 1 : 0;
  if (!host || !user || !pass) { toast('Fill in host, username, and password first', 'err'); return; }
  const btn = document.querySelector('.set-foot .btn-outline');
  if (btn) { btn.disabled = true; btn.textContent = 'Testing…'; }
  try {
    const r = await fetch('/api/settings/email/test', {
      method: 'POST',
      credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({smtp_host: host, smtp_port: port, smtp_user: user, smtp_password: pass, use_tls: tls}),
    });
    const j = await r.json();
    if (j.ok) toast('Connection successful — settings are working');
    else toast(j.error || 'Connection failed', 'err');
  } catch(e) {
    toast('Test failed: ' + e.message, 'err');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Test Connection'; }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// COLOUR SCHEME
// ═══════════════════════════════════════════════════════════════════════════
function _setLoadTheme() {
  const names = Object.keys(THEMES);
  const swatches = names.map(n => {
    const t = THEMES[n];
    const isActive = n === currentTheme;
    return `
      <div class="set-theme-card ${isActive ? 'active' : ''}" onclick="_setPickTheme('${esc(n)}')">
        <div class="set-theme-strip">
          ${['bg','surface','accent','green','red'].map(k =>
            `<div class="set-theme-swatch" style="background:${t[k]||'#888'}"></div>`
          ).join('')}
        </div>
        <div class="set-theme-name">${esc(n)}</div>
        ${isActive ? '<div class="set-theme-active-badge">✓ Active</div>' : ''}
      </div>`;
  }).join('');

  document.getElementById('set-body').innerHTML = `
    <div class="set-section-hdr">🎨  Colour Scheme</div>
    <div class="set-hint" style="margin-bottom:18px">
      The selected theme applies to both the web UI and desktop app.
      Theme is also accessible via the swatches at the bottom of the sidebar.
    </div>
    <div class="set-theme-grid" id="set-theme-grid">
      ${swatches}
    </div>
    <div class="set-foot" style="margin-top:20px">
      <span class="set-hint">Currently active: <strong>${esc(currentTheme)}</strong></span>
    </div>`;
}

async function _setPickTheme(name) {
  applyTheme(name);
  // Re-render so active badge updates
  _setLoadTheme();
  // Persist to server
  try {
    await fetch('/api/theme', {
      method: 'POST',
      credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({name}),
    });
  } catch(e) { /* non-fatal */ }
}

// ═══════════════════════════════════════════════════════════════════════════
// DISCOUNT LIMITS
// ═══════════════════════════════════════════════════════════════════════════
async function _setLoadDiscounts() {
  let data = {};
  try { data = await apiFetch('/api/settings/discount-limits') || {}; }
  catch(e) { document.getElementById('set-body').innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`; return; }

  const roles = [
    { key: 'Admin',      label: 'Admin',      desc: 'Full authority — recommended 100%' },
    { key: 'Accountant', label: 'Accountant', desc: 'Operational — recommended 10–20%' },
    { key: 'Staff',      label: 'Staff',      desc: 'Counter staff — recommended 0–10%' },
    { key: 'ReadOnly',   label: 'Read Only',  desc: 'Cannot create invoices — keep at 0%' },
  ];

  const rows = roles.map(r => `
    <div class="set-discount-row">
      <div class="set-discount-role">
        <div class="set-discount-name">${esc(r.label)}</div>
        <div class="set-discount-desc">${esc(r.desc)}</div>
      </div>
      <div class="set-discount-pct">
        <input class="set-inp set-inp-sm" id="dl-${r.key}" type="number"
               min="0" max="100" step="1" value="${esc(data[r.key] ?? (r.key==='Admin'?100:r.key==='Accountant'?15:r.key==='Staff'?5:0))}">
        <span class="set-pct-lbl">%</span>
      </div>
    </div>`).join('');

  document.getElementById('set-body').innerHTML = `
    <div class="set-section-hdr">🏷  Discount Authorisation Limits</div>
    <div class="set-hint" style="margin-bottom:18px">
      Set the maximum discount % each role may apply to an item's standard catalogue price
      without triggering an override warning. Set 100 for no ceiling.<br>
      Discounts above the limit prompt confirmation and are recorded in the audit log.
    </div>
    <div class="set-discount-list">
      ${rows}
    </div>
    <div class="set-foot">
      <button class="btn btn-primary" onclick="_setDiscountSave()">Save Limits</button>
    </div>`;
}

async function _setDiscountSave() {
  const roles = ['Admin', 'Accountant', 'Staff', 'ReadOnly'];
  const limits = {};
  for (const r of roles) {
    const el = document.getElementById(`dl-${r}`);
    const v = parseFloat(el ? el.value : 0);
    if (isNaN(v) || v < 0 || v > 100) {
      toast(`${r}: percentage must be 0–100`, 'err'); return;
    }
    limits[r] = v;
  }
  try {
    const r = await fetch('/api/settings/discount-limits', {
      method: 'POST',
      credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(limits),
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Save failed', 'err'); return; }
    toast('Discount limits saved');
  } catch(e) {
    toast('Save failed: ' + e.message, 'err');
  }
}

// ── Opening Balance Wizard ─────────────────────────────────────────────────────

const fmtAmt = n => (+(n||0)).toLocaleString('en-AU', {minimumFractionDigits:2, maximumFractionDigits:2});

let _obStep = 1, _obDate = '', _obAccounts = [], _obEntries = {}, _obImportRows = [];

function _setLoadOpening() {
  _obStep = 1; _obDate = ''; _obEntries = {}; _obImportRows = [];
  _obRender();
}

function _obRender() {
  const c = document.getElementById('set-body');
  c.innerHTML = `<div class="set-section-hdr">🧮  Opening Balance Wizard</div>
<div class="wiz-step-bar">
  <div class="wiz-step ${_obStep===1?'active':_obStep>1?'done':''}" data-s="1">1 Date &amp; Import</div>
  <div class="wiz-step ${_obStep===2?'active':_obStep>2?'done':''}" data-s="2">2 Enter Balances</div>
  <div class="wiz-step ${_obStep===3?'active':''}" data-s="3">3 Review &amp; Post</div>
</div>
<div id="ob-body"></div>`;
  if (_obStep === 1) _obStep1();
  else if (_obStep === 2) _obStep2();
  else _obStep3();
}

function _obStep1() {
  const b = document.getElementById('ob-body');
  b.innerHTML = `
<div class="set-sect">
  <div class="set-section-sub">Start date</div>
  <p class="set-desc">The date your books begin. All opening balances will be posted on this date.</p>
  <label class="set-lbl">Opening balance date</label>
  <input type="date" id="ob-date" class="set-inp" style="max-width:200px" value="${_obDate}">
</div>
<div class="set-sect">
  <div class="set-section-sub">Import from another system <span style="font-weight:400;color:var(--ink3)">(optional)</span></div>
  <p class="set-desc">Upload a Balance Sheet, P&amp;L, or Trial Balance CSV exported from Xero, MYOB, or QuickBooks to pre-fill balances.</p>
  <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
    <label class="btn" style="cursor:pointer;background:var(--surface);border:1px solid var(--border)">
      Browse CSV… <input type="file" accept=".csv" id="ob-file-input" style="display:none" onchange="_obImportCsv(this)">
    </label>
    <span id="ob-import-status" style="font-size:13px;color:var(--ink2)"></span>
  </div>
  <div id="ob-import-preview" style="margin-top:10px"></div>
</div>
<div class="wiz-nav">
  <button class="btn btn-primary" onclick="_obGoStep2()">Next: Enter Balances →</button>
</div>`;
  if (_obDate) document.getElementById('ob-date').value = _obDate;
  if (_obImportRows.length) _obShowImportSummary();
}

async function _obImportCsv(input) {
  const file = input.files[0];
  if (!file) return;
  const st = document.getElementById('ob-import-status');
  st.textContent = 'Parsing…';
  const fd = new FormData();
  fd.append('file', file);
  try {
    const r = await fetch('/api/import/parse-report-csv', {method:'POST', credentials:'include', body:fd});
    const j = await r.json();
    if (!j.ok) { st.textContent = j.error || 'Parse error'; return; }
    const rows = (j.data.rows || []).filter(x => !x.skip && x.amount !== 0);
    _obImportRows = rows;
    const mapped = rows.filter(x => x.confidence !== 'none');
    st.textContent = `${file.name} — ${mapped.length} of ${rows.length} accounts mapped`;
    _obShowImportSummary();
  } catch(e) {
    st.textContent = 'Upload failed: ' + e.message;
  }
}

function _obShowImportSummary() {
  const p = document.getElementById('ob-import-preview');
  if (!p || !_obImportRows.length) return;
  const good = _obImportRows.filter(x => x.confidence !== 'none');
  const bad  = _obImportRows.filter(x => x.confidence === 'none');
  let html = '<div class="ob-list"><div class="ob-hdr-row"><span class="ob-code">Code</span><span class="ob-name">Account</span><span class="ob-type">Type</span><span class="ob-amt">Amount</span><span style="flex:1.2">Source name</span><span style="flex:.8">Confidence</span></div>';
  for (const x of good) {
    const badge = x.confidence==='high' ? 'badge-green' : x.confidence==='medium' ? 'badge-blue' : 'badge-amber';
    html += `<div class="ob-row ob-imported">
      <span class="ob-code">${x.suggested_code}</span>
      <span class="ob-name">${x.suggested_name}</span>
      <span class="ob-type">${x.source_type||''}</span>
      <span class="ob-amt">${fmtAmt(x.amount)}</span>
      <span style="flex:1.2;font-size:11px;color:var(--ink3)">${x.source_name}</span>
      <span style="flex:.8"><span class="badge ${badge}">${x.confidence}</span></span>
    </div>`;
  }
  if (bad.length) {
    html += `<div class="ob-warn-banner">⚠ ${bad.length} account(s) could not be mapped — enter manually in step 2</div>`;
    for (const x of bad) {
      html += `<div class="ob-row" style="opacity:.6"><span class="ob-code">—</span><span class="ob-name">${x.source_name}</span><span class="ob-type">${x.source_type||''}</span><span class="ob-amt">${fmtAmt(x.amount)}</span><span style="flex:2"></span></div>`;
    }
  }
  html += '</div>';
  p.innerHTML = html;
}

async function _obGoStep2() {
  const d = document.getElementById('ob-date');
  if (!d || !d.value) { toast('Select an opening balance date', 'err'); return; }
  _obDate = d.value;
  if (!_obAccounts.length) {
    try {
      _obAccounts = await apiFetch('/api/accounts');
    } catch(e) {
      toast('Could not load accounts: ' + e.message, 'err'); return;
    }
  }
  if (_obImportRows.length && Object.keys(_obEntries).length === 0) {
    const byCode = {};
    for (const acc of _obAccounts) byCode[acc.code] = acc;
    for (const row of _obImportRows) {
      if (row.skip || !row.suggested_code || row.confidence === 'none') continue;
      const acc = byCode[row.suggested_code];
      if (!acc) continue;
      const existing = _obEntries[acc.id];
      if (!existing || row.confidence === 'high')
        _obEntries[acc.id] = Math.abs(row.amount);
    }
  }
  _obStep = 2; _obRender();
}

function _obStep2() {
  const b = document.getElementById('ob-body');
  const TYPES = ['Asset','Bank','Accounts Receivable','Cost of Sales',
                 'Liability','Credit Card','Equity','Income','Expense'];
  const groups = {};
  for (const t of TYPES) groups[t] = [];
  for (const a of _obAccounts) {
    if (groups[a.account_type]) groups[a.account_type].push(a);
  }
  const importedCodes = new Set(
    _obImportRows.filter(x => x.suggested_code && x.confidence !== 'none').map(x => x.suggested_code)
  );
  let html = '<div style="padding:0 4px"><p class="set-desc">Enter the opening balance for each account. Leave blank or 0 to skip.</p>';
  for (const [type, accs] of Object.entries(groups)) {
    if (!accs.length) continue;
    html += `<div class="ob-type-group">
  <div class="ob-type-hdr">${type}</div>
  <div class="ob-list">
    <div class="ob-hdr-row"><span class="ob-code">Code</span><span class="ob-name">Account</span><span class="ob-amt">Opening Balance</span></div>`;
    for (const a of accs) {
      const v = _obEntries[a.id] != null ? _obEntries[a.id] : '';
      const imp = importedCodes.has(a.code) ? ' ob-imported' : '';
      html += `<div class="ob-row${imp}" id="ob-row-${a.id}">
        <span class="ob-code">${a.code}</span>
        <span class="ob-name">${a.name}</span>
        <span class="ob-amt"><input type="number" min="0" step="0.01" class="set-inp ob-amt-input"
          data-id="${a.id}" value="${v}" placeholder="0.00"
          oninput="_obInputChange(${a.id},this.value)"></span>
      </div>`;
    }
    html += '</div></div>';
  }
  html += `</div><div class="wiz-nav">
  <button class="btn" onclick="_obStep=1;_obRender()">← Back</button>
  <button class="btn btn-primary" onclick="_obGoStep3()">Next: Review →</button>
</div>`;
  b.innerHTML = html;
}

function _obInputChange(id, val) {
  const n = parseFloat(val);
  if (!isNaN(n) && n >= 0) _obEntries[id] = n;
  else delete _obEntries[id];
}

function _obGoStep3() {
  document.querySelectorAll('.ob-amt-input').forEach(inp => {
    const id = parseInt(inp.dataset.id);
    const n = parseFloat(inp.value);
    if (!isNaN(n) && n > 0) _obEntries[id] = n;
    else delete _obEntries[id];
  });
  if (!Object.keys(_obEntries).length) { toast('Enter at least one balance', 'err'); return; }
  _obStep = 3; _obRender();
}

function _obStep3() {
  const b = document.getElementById('ob-body');
  const accMap = {};
  for (const a of _obAccounts) accMap[a.id] = a;
  const DEBIT_TYPES = new Set(['Asset','Bank','Expense','Accounts Receivable','Cost of Sales','Credit Card']);
  let totalDr = 0, totalCr = 0;
  let rows = '';
  for (const [id, amt] of Object.entries(_obEntries)) {
    const a = accMap[id];
    if (!a || amt <= 0) continue;
    const isDr = DEBIT_TYPES.has(a.account_type);
    if (isDr) totalDr += amt; else totalCr += amt;
    rows += `<div class="ob-rev-row">
      <span class="ob-code">${a.code}</span>
      <span class="ob-name">${a.name}</span>
      <span class="ob-rev-amt">${isDr ? fmtAmt(amt) : ''}</span>
      <span class="ob-rev-amt">${isDr ? '' : fmtAmt(amt)}</span>
    </div>`;
  }
  const diff = Math.round((totalDr - totalCr) * 100) / 100;
  const balanced = Math.abs(diff) < 0.01;
  const balNote = balanced
    ? '<div class="ob-bal-card ok"><span class="ob-bal-title">✓ Balanced</span></div>'
    : `<div class="ob-bal-card warn"><span class="ob-bal-title">⚠ Out by ${fmtAmt(Math.abs(diff))}</span><span class="ob-bal-row">Difference will be auto-posted to Retained Earnings</span></div>`;
  b.innerHTML = `<div style="padding:0 4px">
<div class="ob-rev-list">
  <div class="ob-hdr-row"><span class="ob-code">Code</span><span class="ob-name">Account</span><span class="ob-rev-amt">Debit</span><span class="ob-rev-amt">Credit</span></div>
  ${rows}
  <div class="ob-hdr-row" style="margin-top:6px">
    <span class="ob-code"></span><span class="ob-name" style="font-weight:600">Total</span>
    <span class="ob-rev-amt" style="font-weight:600">${fmtAmt(totalDr)}</span>
    <span class="ob-rev-amt" style="font-weight:600">${fmtAmt(totalCr)}</span>
  </div>
</div>
${balNote}
<p class="set-desc" style="margin-top:14px">Date: <strong>${_obDate}</strong></p>
</div>
<div class="wiz-nav">
  <button class="btn" onclick="_obStep=2;_obRender()">← Back</button>
  <button class="btn btn-primary" onclick="_obPost()">Post Opening Balances</button>
</div>`;
}

async function _obPost() {
  const entries = Object.entries(_obEntries)
    .filter(([,v]) => v > 0)
    .map(([id, amount]) => ({account_id: parseInt(id), amount}));
  try {
    const r = await fetch('/api/opening-balances', {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({date: _obDate, entries}),
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Post failed', 'err'); return; }
    toast(`Opening balances posted (${j.data.posted} lines)`);
    _obStep = 1; _obDate = ''; _obEntries = {}; _obImportRows = []; _obAccounts = [];
    _obRender();
  } catch(e) {
    toast('Post failed: ' + e.message, 'err');
  }
}

// ── AR/AP Reconciliation Wizard ────────────────────────────────────────────────

let _arapStep = 0, _arapDate = '', _arapArRows = [{name:'',amount:''}],
    _arapApRows = [{name:'',amount:''}], _arapData = null;

const _arapSteps = ['Overview','AR Invoices','AP Bills','Review & Post'];

function _setLoadArap() {
  _arapStep = 0; _arapDate = ''; _arapArRows = [{name:'',amount:''}];
  _arapApRows = [{name:'',amount:''}]; _arapData = null;
  _arapRender();
}

function _arapRender() {
  const c = document.getElementById('set-body');
  const bar = _arapSteps.map((s,i) =>
    `<div class="wiz-step ${i===_arapStep?'active':i<_arapStep?'done':''}">${i+1} ${s}</div>`
  ).join('');
  c.innerHTML = `<div class="set-section-hdr">↔  AR / AP Reconciliation Wizard</div>
<div class="wiz-step-bar">${bar}</div>
<div id="arap-body"></div>`;
  [_arapPage0, () => _arapPageEntries('ar'), () => _arapPageEntries('ap'), _arapPageReview][_arapStep]();
}

async function _arapPage0() {
  try {
    _arapData = await apiFetch('/api/arap-balances');
  } catch(e) {
    document.getElementById('arap-body').innerHTML =
      `<p style="color:var(--red);padding:16px">Could not load balances: ${e.message}</p>`;
    return;
  }
  const obNote = _arapData.ob_date
    ? `<p class="set-desc">Opening balance date: <strong>${_arapData.ob_date}</strong></p>`
    : '<div class="ob-warn-banner">⚠ No opening balances posted yet. Run the Opening Balance Wizard first.</div>';
  document.getElementById('arap-body').innerHTML = `
<div style="padding:0 4px">
${obNote}
<div class="ob-list" style="margin-top:12px">
  <div class="ob-hdr-row">
    <span style="flex:2">Account</span>
    <span class="ob-rev-amt">GL Balance</span>
    <span class="ob-rev-amt">Already reconciled</span>
    <span class="ob-rev-amt">Remaining</span>
  </div>
  <div class="ob-row">
    <span style="flex:2">1-1200 Accounts Receivable</span>
    <span class="ob-rev-amt">${fmtAmt(_arapData.ar.gl)}</span>
    <span class="ob-rev-amt">${fmtAmt(_arapData.ar.reconciled)}</span>
    <span class="ob-rev-amt" style="font-weight:600">${fmtAmt(_arapData.ar.remaining)}</span>
  </div>
  <div class="ob-row">
    <span style="flex:2">2-1100 Accounts Payable</span>
    <span class="ob-rev-amt">${fmtAmt(_arapData.ap.gl)}</span>
    <span class="ob-rev-amt">${fmtAmt(_arapData.ap.reconciled)}</span>
    <span class="ob-rev-amt" style="font-weight:600">${fmtAmt(_arapData.ap.remaining)}</span>
  </div>
</div>
<p class="set-desc" style="margin-top:12px">Enter a date and list each outstanding invoice/bill with its customer/supplier name and amount.</p>
<label class="set-lbl" style="margin-top:14px">Date for opening invoices/bills</label>
<input type="date" id="arap-date" class="set-inp" style="max-width:200px" value="${_arapDate}">
</div>
<div class="wiz-nav">
  <button class="btn btn-primary" onclick="_arapNext(0)">Next: AR Invoices →</button>
</div>`;
}

function _arapNext(fromStep) {
  if (fromStep === 0) {
    const d = document.getElementById('arap-date');
    if (!d || !d.value) { toast('Select a date', 'err'); return; }
    _arapDate = d.value;
  }
  _arapStep = fromStep + 1;
  _arapRender();
}

function _arapPageEntries(side) {
  const rows = side === 'ar' ? _arapArRows : _arapApRows;
  const label = side === 'ar' ? 'Customer' : 'Supplier';
  const remaining = _arapData ? (side === 'ar' ? _arapData.ar.remaining : _arapData.ap.remaining) : 0;
  const rowsHtml = rows.map((r,i) => `
    <div class="ob-row" id="${side}-row-${i}">
      <input type="text" class="set-inp" style="flex:2;margin-right:8px" placeholder="${label} name" value="${r.name||''}"
        oninput="_arapRowChange('${side}',${i},'name',this.value)">
      <input type="number" min="0" step="0.01" class="set-inp ob-amt-input" style="flex:1;margin-right:8px" placeholder="0.00" value="${r.amount||''}"
        oninput="_arapRowChange('${side}',${i},'amount',this.value)">
      <button class="btn" style="padding:4px 8px;min-width:30px" onclick="_arapRemoveRow('${side}',${i})">✕</button>
    </div>`).join('');
  document.getElementById('arap-body').innerHTML = `
<div style="padding:0 4px">
  <div class="ob-warn-banner" style="background:var(--surface);border-color:var(--border);color:var(--ink2)">
    Remaining to reconcile: <strong>${fmtAmt(remaining)}</strong>
  </div>
  <div class="ob-list" style="margin-top:10px">
    <div class="ob-hdr-row"><span style="flex:2">${label}</span><span style="flex:1">Amount</span><span style="width:38px"></span></div>
    <div id="${side}-rows">${rowsHtml}</div>
  </div>
  <div id="${side}-total" style="margin-top:8px;text-align:right;font-size:13px;color:var(--ink2)"></div>
  <button class="btn" style="margin-top:8px" onclick="_arapAddRow('${side}')">+ Add row</button>
</div>
<div class="wiz-nav">
  <button class="btn" onclick="_arapStep--;_arapRender()">← Back</button>
  <button class="btn btn-primary" onclick="_arapSaveEntries('${side}')">${side==='ar' ? 'Next: AP Bills →' : 'Next: Review →'}</button>
</div>`;
  _arapUpdateTotal(side);
}

function _arapRowChange(side, i, field, val) {
  const rows = side === 'ar' ? _arapArRows : _arapApRows;
  rows[i][field] = val;
  _arapUpdateTotal(side);
}

function _arapUpdateTotal(side) {
  const rows = side === 'ar' ? _arapArRows : _arapApRows;
  const total = rows.reduce((s,r) => s + (parseFloat(r.amount)||0), 0);
  const el = document.getElementById(`${side}-total`);
  if (el) el.textContent = `Total: ${fmtAmt(total)}`;
}

function _arapAddRow(side) {
  if (side === 'ar') _arapArRows.push({name:'',amount:''});
  else _arapApRows.push({name:'',amount:''});
  _arapPageEntries(side);
}

function _arapRemoveRow(side, i) {
  if (side === 'ar') { _arapArRows.splice(i,1); if (!_arapArRows.length) _arapArRows=[{name:'',amount:''}]; }
  else { _arapApRows.splice(i,1); if (!_arapApRows.length) _arapApRows=[{name:'',amount:''}]; }
  _arapPageEntries(side);
}

function _arapSaveEntries(side) {
  if (side === 'ar') {
    _arapArRows = _arapArRows.filter(r => parseFloat(r.amount) > 0 && r.name.trim());
    if (!_arapArRows.length) _arapArRows = [{name:'',amount:''}];
  } else {
    _arapApRows = _arapApRows.filter(r => parseFloat(r.amount) > 0 && r.name.trim());
    if (!_arapApRows.length) _arapApRows = [{name:'',amount:''}];
  }
  _arapStep = side === 'ar' ? 2 : 3;
  _arapRender();
}

function _arapPageReview() {
  const arRows = _arapArRows.filter(r => parseFloat(r.amount) > 0 && r.name.trim());
  const apRows = _arapApRows.filter(r => parseFloat(r.amount) > 0 && r.name.trim());
  const arTotal = arRows.reduce((s,r) => s + (parseFloat(r.amount)||0), 0);
  const apTotal = apRows.reduce((s,r) => s + (parseFloat(r.amount)||0), 0);

  const makeTable = (rows, label, total) => rows.length ? `
  <div class="ob-list" style="margin-bottom:14px">
    <div class="ob-hdr-row"><span style="flex:2">${label}</span><span class="ob-rev-amt">Amount</span></div>
    ${rows.map(r => `<div class="ob-row"><span style="flex:2">${r.name}</span><span class="ob-rev-amt">${fmtAmt(parseFloat(r.amount))}</span></div>`).join('')}
    <div class="ob-hdr-row"><span style="flex:2;font-weight:600">Total</span><span class="ob-rev-amt" style="font-weight:600">${fmtAmt(total)}</span></div>
  </div>` : '';

  const noneWarn = (!arRows.length && !apRows.length)
    ? '<div class="ob-warn-banner">No entries — add at least one AR or AP row</div>' : '';

  document.getElementById('arap-body').innerHTML = `
<div style="padding:0 4px">
  <p class="set-desc">Date: <strong>${_arapDate}</strong></p>
  <div class="set-section-sub" style="margin-bottom:6px">Accounts Receivable (${arRows.length} invoice${arRows.length!==1?'s':''})</div>
  ${makeTable(arRows, 'Customer', arTotal)}
  <div class="set-section-sub" style="margin-bottom:6px">Accounts Payable (${apRows.length} bill${apRows.length!==1?'s':''})</div>
  ${makeTable(apRows, 'Supplier', apTotal)}
  ${noneWarn}
</div>
<div class="wiz-nav">
  <button class="btn" onclick="_arapStep=2;_arapRender()">← Back</button>
  <button class="btn btn-primary" onclick="_arapPost()" ${!arRows.length && !apRows.length ? 'disabled' : ''}>Post Opening Invoices &amp; Bills</button>
</div>`;
}

async function _arapPost() {
  const arRows = _arapArRows.filter(r => parseFloat(r.amount) > 0 && r.name.trim());
  const apRows = _arapApRows.filter(r => parseFloat(r.amount) > 0 && r.name.trim());
  try {
    const r = await fetch('/api/arap-reconcile', {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({date: _arapDate, ar_rows: arRows, ap_rows: apRows}),
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Post failed', 'err'); return; }
    const d = j.data;
    const errs = d.errors && d.errors.length ? '\n' + d.errors.join('; ') : '';
    toast(`Posted: AR ${fmtAmt(d.ar_total)}, AP ${fmtAmt(d.ap_total)}${errs}`);
    _arapStep = 0; _arapDate = ''; _arapArRows = [{name:'',amount:''}];
    _arapApRows = [{name:'',amount:''}]; _arapData = null;
    _arapRender();
  } catch(e) {
    toast('Post failed: ' + e.message, 'err');
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// TRANSACTION IMPORT WIZARD
// Namespace prefix: _ti*
// ═══════════════════════════════════════════════════════════════════════════

let _tiStep = 1;
let _tiParsed = null;
let _tiFile = null;
let _tiAcctMap = {};
let _tiBalancing = {};
let _tiContactMap = {};
let _tiDateFrom = '';
let _tiDateTo = '';
let _tiDboxAccounts = [];
let _tiDboxContacts = [];

function _tiShow() {
  _tiStep = 1; _tiParsed = null; _tiFile = null;
  _tiAcctMap = {}; _tiBalancing = {}; _tiContactMap = {};
  _tiDateFrom = ''; _tiDateTo = '';
  _tiDboxAccounts = []; _tiDboxContacts = [];
  _tiRender();
}

function _tiRender() {
  const s = _tiStep;
  document.getElementById('set-body').innerHTML = `
<div class="set-section-hdr">📥  Transaction Import</div>
<div class="wiz-step-bar">
  <div class="wiz-step ${s===1?'active':s>1?'done':''}">1 Upload</div>
  <div class="wiz-step ${s===2?'active':s>2?'done':''}">2 Accounts</div>
  <div class="wiz-step ${s===3?'active':s>3?'done':''}">3 Contacts</div>
  <div class="wiz-step ${s===4?'active':''}">4 Import</div>
</div>
<div id="ti-body"></div>`;
  if (s === 1) _tiStep1();
  else if (s === 2) _tiStep2();
  else if (s === 3) _tiStep3();
  else _tiStep4();
}

// ── Step 1: Upload ────────────────────────────────────────────────────────────

function _tiStep1() {
  document.getElementById('ti-body').innerHTML = `
<div class="set-sect">
  <div class="set-section-sub">Upload transaction CSV</div>
  <p class="set-desc">Upload a Saasu transactions export. The wizard will parse the file and guide you through mapping accounts and contacts to Dogbox.</p>
  <div id="ti-drop" class="ti-drop-zone" ondragover="event.preventDefault()" ondrop="_tiDrop(event)">
    <div class="ti-drop-icon">📄</div>
    <div class="ti-drop-msg">Drag CSV here, or</div>
    <label class="btn" style="cursor:pointer;margin-top:8px">
      Browse… <input type="file" accept=".csv" id="ti-file-input" style="display:none" onchange="_tiFileSelected(this)">
    </label>
  </div>
  <div id="ti-parse-status" style="margin-top:12px;font-size:13px;color:var(--ink2)"></div>
  <div id="ti-summary"></div>
</div>
<div class="wiz-nav">
  <button class="btn btn-primary" id="ti-next1" onclick="_tiGoStep2()" disabled>Next: Map Accounts →</button>
</div>`;
}

function _tiDrop(ev) {
  ev.preventDefault();
  const f = ev.dataTransfer.files[0];
  if (f) _tiParseFile(f);
}

function _tiFileSelected(inp) {
  if (inp.files[0]) _tiParseFile(inp.files[0]);
}

async function _tiParseFile(file) {
  _tiFile = file;
  const st = document.getElementById('ti-parse-status');
  st.textContent = 'Parsing…';
  const fd = new FormData();
  fd.append('file', file);
  try {
    const r = await fetch('/api/txn-import/parse', {method:'POST', credentials:'include', body:fd});
    const j = await r.json();
    if (!j.ok) { st.textContent = j.error || 'Parse error'; return; }
    _tiParsed = j.data;
    const sm = _tiParsed.summary;
    const total = (sm.sales_invoice||0) + (sm.cash_received||0) + (sm.cash_payment||0) + (sm.general_journal||0);
    st.textContent = `${file.name} — ${total} transactions, ${_tiParsed.accounts.length} unique accounts`;
    _tiRenderSummary();
    document.getElementById('ti-next1').disabled = false;
  } catch(e) {
    st.textContent = 'Upload failed: ' + e.message;
  }
}

function _tiRenderSummary() {
  const sm = _tiParsed.summary;
  const types = [
    ['sales_invoice','Sales Invoices'],['cash_received','Cash Received'],
    ['cash_payment','Cash Payments'],['general_journal','General Journals'],
  ].filter(([k]) => sm[k]);
  const rows = types.map(([k,label]) => `<tr><td>${label}</td><td style="text-align:right;font-weight:600">${sm[k]}</td></tr>`).join('');
  const dr = sm.date_from ? `<div style="margin-top:6px;font-size:12px;color:var(--ink3)">${sm.date_from} → ${sm.date_to}</div>` : '';
  document.getElementById('ti-summary').innerHTML = `
<table class="inv-list-table" style="margin-top:12px;max-width:300px">
  <thead><tr><th>Type</th><th style="text-align:right">Transactions</th></tr></thead>
  <tbody>${rows}</tbody>
</table>${dr}`;
}

// ── Step 2: Account mapping ───────────────────────────────────────────────────

async function _tiGoStep2() {
  if (!_tiParsed) return;
  if (!_tiDboxAccounts.length) {
    try { _tiDboxAccounts = await apiFetch('/api/accounts'); }
    catch(e) { toast('Failed to load accounts: ' + e.message, 'err'); return; }
  }
  _tiStep = 2; _tiRender();
}

function _tiMakeAcctOpts(selectedId) {
  return _tiDboxAccounts.map(a =>
    `<option value="${a.id}"${String(a.id)===String(selectedId)?' selected':''}>${esc(a.code)} — ${esc(a.name)}</option>`
  ).join('');
}

function _tiSuggestAcct(extName) {
  const low = extName.toLowerCase();
  const m = _tiDboxAccounts.find(a =>
    a.name.toLowerCase().includes(low) || low.includes(a.name.toLowerCase()));
  return m ? m.id : '';
}

function _tiStep2() {
  const sm = _tiParsed.summary;
  const types = ['sales_invoice','cash_received','cash_payment','general_journal'].filter(t => sm[t]);
  const typeLabels = {
    sales_invoice:   ['Sales Invoices',   'Debit — Accounts Receivable or bank'],
    cash_received:   ['Cash Received',    'Debit — bank / cash account'],
    cash_payment:    ['Cash Payments',    'Credit — bank / card account'],
    general_journal: ['General Journals', 'Credit — card / bank account'],
  };

  const acctRows = _tiParsed.accounts.map((a, i) => {
    const cur = _tiAcctMap[a.ext_id] || _tiSuggestAcct(a.ext_name);
    return `<div class="ti-map-row">
      <div class="ti-map-name">${esc(a.ext_name)}<span class="ti-map-cnt"> (${a.count})</span></div>
      <select class="set-inp ti-map-sel" id="ti-acct-${i}">
        <option value="">— select account —</option>
        ${_tiMakeAcctOpts(cur)}
      </select>
    </div>`;
  }).join('');

  const balRows = types.map(t => {
    const [label, hint] = typeLabels[t];
    const cur = _tiBalancing[t] || '';
    return `<div class="ti-map-row">
      <div class="ti-map-name">${label}<span class="ti-map-cnt"> — ${hint}</span></div>
      <select class="set-inp ti-map-sel" id="ti-bal-${t}">
        <option value="">— select account —</option>
        ${_tiMakeAcctOpts(cur)}
      </select>
    </div>`;
  }).join('');

  document.getElementById('ti-body').innerHTML = `
<div class="set-sect">
  <div class="set-section-sub">Detail account mapping</div>
  <p class="set-desc">Map each external account to a Dogbox account.</p>
  <div class="ti-map-table">${acctRows}</div>
</div>
<div class="set-sect">
  <div class="set-section-sub">Balancing accounts</div>
  <p class="set-desc">Select the offsetting account for each transaction type — the leg not shown in the export.</p>
  <div class="ti-map-table">${balRows}</div>
</div>
<div class="wiz-nav">
  <button class="btn" onclick="_tiStep=1;_tiRender()">← Back</button>
  <button class="btn btn-primary" onclick="_tiGoStep3()">Next: Map Contacts →</button>
</div>`;
}

async function _tiGoStep3() {
  _tiAcctMap = {};
  _tiParsed.accounts.forEach((a, i) => {
    const el = document.getElementById('ti-acct-' + i);
    _tiAcctMap[a.ext_id] = el ? el.value : '';
  });
  for (const a of _tiParsed.accounts) {
    if (!_tiAcctMap[a.ext_id]) {
      toast(`Select a Dogbox account for "${a.ext_name}"`, 'err'); return;
    }
  }
  _tiBalancing = {};
  const sm = _tiParsed.summary;
  const types = ['sales_invoice','cash_received','cash_payment','general_journal'].filter(t => sm[t]);
  for (const t of types) {
    const el = document.getElementById('ti-bal-' + t);
    _tiBalancing[t] = el ? el.value : '';
    if (!_tiBalancing[t]) { toast(`Select a balancing account for ${t}`, 'err'); return; }
  }
  if (!_tiDboxContacts.length) {
    try { _tiDboxContacts = await apiFetch('/api/contacts'); }
    catch(e) { toast('Failed to load contacts: ' + e.message, 'err'); return; }
  }
  _tiStep = 3; _tiRender();
}

// ── Step 3: Contact mapping ───────────────────────────────────────────────────

function _tiSuggestContact(extName) {
  const low = extName.toLowerCase();
  const m = _tiDboxContacts.find(c =>
    c.name.toLowerCase().includes(low) || low.includes(c.name.toLowerCase()));
  return m ? m.id : 0;
}

function _tiMakeContactOpts(selectedId) {
  const skip = `<option value="0"${!selectedId||String(selectedId)==='0'?' selected':''}>— skip (no contact) —</option>`;
  const opts = _tiDboxContacts.map(c =>
    `<option value="${c.id}"${String(c.id)===String(selectedId)?' selected':''}>${esc(c.name)}</option>`
  ).join('');
  return skip + opts;
}

function _tiStep3() {
  const rows = _tiParsed.counterparties.map((cp, i) => {
    const cur = _tiContactMap[cp.ext_id] !== undefined ? _tiContactMap[cp.ext_id] : _tiSuggestContact(cp.ext_name);
    return `<div class="ti-map-row">
      <div class="ti-map-name">${esc(cp.ext_name)}<span class="ti-map-cnt"> (${cp.count})</span></div>
      <select class="set-inp ti-map-sel" id="ti-cp-${i}">
        ${_tiMakeContactOpts(cur)}
      </select>
    </div>`;
  }).join('');

  document.getElementById('ti-body').innerHTML = `
<div class="set-sect">
  <div class="set-section-sub">Contact mapping</div>
  <p class="set-desc">Map each counterparty to a Dogbox contact. "Skip" imports the journal without a contact link.</p>
  <div class="ti-map-table">${rows}</div>
</div>
<div class="wiz-nav">
  <button class="btn" onclick="_tiStep=2;_tiRender()">← Back</button>
  <button class="btn btn-primary" onclick="_tiGoStep4()">Next: Preview & Import →</button>
</div>`;
}

function _tiGoStep4() {
  _tiContactMap = {};
  _tiParsed.counterparties.forEach((cp, i) => {
    const el = document.getElementById('ti-cp-' + i);
    _tiContactMap[cp.ext_id] = el ? el.value : '0';
  });
  _tiStep = 4; _tiRender();
}

// ── Step 4: Preview & Import ──────────────────────────────────────────────────

function _tiStep4() {
  const sm = _tiParsed.summary;
  const total = (sm.sales_invoice||0) + (sm.cash_received||0) + (sm.cash_payment||0) + (sm.general_journal||0);
  document.getElementById('ti-body').innerHTML = `
<div class="set-sect">
  <div class="set-section-sub">Ready to import</div>
  <p class="set-desc">The wizard will create up to <strong>${total}</strong> journal entries (type: TxnImport). Already-imported transactions are skipped automatically by transaction number.</p>
  <div style="display:flex;gap:16px;flex-wrap:wrap;margin-bottom:12px">
    <div>
      <label class="set-lbl">From date (optional)</label>
      <input type="date" id="ti-from" class="set-inp" style="max-width:160px" value="${_tiDateFrom}">
    </div>
    <div>
      <label class="set-lbl">To date (optional)</label>
      <input type="date" id="ti-to" class="set-inp" style="max-width:160px" value="${_tiDateTo}">
    </div>
  </div>
</div>
<div class="wiz-nav">
  <button class="btn" onclick="_tiStep=3;_tiRender()">← Back</button>
  <button class="btn btn-primary" id="ti-import-btn" onclick="_tiImport()">Import ${total} Transactions</button>
</div>
<div id="ti-result" style="margin-top:16px"></div>`;
}

async function _tiImport() {
  _tiDateFrom = (document.getElementById('ti-from') || {}).value || '';
  _tiDateTo   = (document.getElementById('ti-to')   || {}).value || '';
  const btn = document.getElementById('ti-import-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Importing…'; }
  const fd = new FormData();
  fd.append('file', _tiFile);
  fd.append('config', JSON.stringify({
    account_map: _tiAcctMap,
    balancing:   _tiBalancing,
    contact_map: _tiContactMap,
    date_from:   _tiDateFrom,
    date_to:     _tiDateTo,
  }));
  try {
    const r = await fetch('/api/txn-import/confirm', {method:'POST', credentials:'include', body:fd});
    const j = await r.json();
    const res = document.getElementById('ti-result');
    if (!j.ok) {
      if (res) res.innerHTML = `<div class="state-error">${esc(j.error||'Import failed')}</div>`;
      if (btn) { btn.disabled = false; btn.textContent = 'Retry'; }
      return;
    }
    const d = j.data;
    const errHtml = d.errors && d.errors.length
      ? `<div style="margin-top:8px"><strong>Errors (${d.errors.length}):</strong><ul style="margin:4px 0 0 18px;font-size:12px;color:var(--red)">${d.errors.slice(0,20).map(e=>`<li>${esc(e)}</li>`).join('')}</ul></div>` : '';
    if (res) res.innerHTML = `
<div style="background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:16px;max-width:480px">
  <div style="font-size:15px;font-weight:600;color:var(--green)">✓ Import complete</div>
  <div style="margin-top:8px">Imported: <strong>${d.imported}</strong> &nbsp;·&nbsp; Skipped (already imported): <strong>${d.skipped}</strong></div>
  ${errHtml}
</div>`;
    toast(`Imported ${d.imported} transactions`);
  } catch(e) {
    const res = document.getElementById('ti-result');
    if (res) res.innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
    if (btn) { btn.disabled = false; btn.textContent = 'Retry'; }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// MIGRATION IMPORT WIZARD
// Namespace prefix: _mig*
// Supports: Xero CSV, MYOB AccountRight, QuickBooks IIF, BAS Off/FAS3 CSV+XML
// Steps: 1 Upload → 2 Map Accounts → 3 Options → 4 Done
// ═══════════════════════════════════════════════════════════════════════════

let _migStep      = 1;
let _migFile      = null;
let _migParsed    = null;
let _migAcctMap   = {};
let _migDboxAccts = [];

function _migShow() {
  _migStep = 1; _migFile = null; _migParsed = null;
  _migAcctMap = {}; _migDboxAccts = [];
  _migRender();
}

function _migStepBar(active) {
  const steps = ['Upload','Accounts','Options','Done'];
  return `<div style="display:flex;align-items:flex-start;margin-bottom:24px;max-width:520px">
    ${steps.map((lbl, i) => {
      const n = i + 1;
      const cls = n < active ? 'done' : n === active ? 'active' : '';
      return `
        ${n > 1 ? `<div class="wiz-step-line${n <= active ? ' done' : ''}"></div>` : ''}
        <div class="wiz-step-wrap">
          <div class="wiz-step-dot ${cls}">${n < active ? '✓' : n}</div>
          <div class="wiz-step-lbl ${n === active ? 'active' : ''}">${lbl}</div>
        </div>`;
    }).join('')}
  </div>`;
}

function _migRender() {
  document.getElementById('set-body').innerHTML = `
    <div class="set-section-hdr">🔄  Import from Software</div>
    <div style="color:var(--ink2);font-size:13px;margin-bottom:20px">
      Import accounts, contacts, invoices, bills, and journals from Xero, MYOB,
      QuickBooks, or BAS Off / FAS3.
    </div>
    ${_migStepBar(_migStep)}
    <div id="mig-step-content"></div>`;
  if      (_migStep === 1) _migStep1();
  else if (_migStep === 2) _migStep2();
  else if (_migStep === 3) _migStep3();
  else                     _migStep4();
}

// ── Step 1: Upload ────────────────────────────────────────────────────────────

function _migStep1() {
  document.getElementById('mig-step-content').innerHTML = `
    <div class="set-section-sub">Upload export file</div>
    <p style="font-size:13px;color:var(--ink2);margin:0 0 16px">
      Accepted formats: Xero CSV, MYOB AccountRight (tab-delimited TXT/CSV),
      QuickBooks IIF, BAS Off / FAS3 CSV or Glenix XML.
    </p>
    <label id="mig-drop" class="ti-drop-zone" for="mig-file-input"
           ondragover="event.preventDefault()" ondrop="_migDrop(event)">
      <div class="ti-drop-icon">📂</div>
      <div class="ti-drop-msg">Drop file here or <span style="color:var(--accent)">Browse…</span></div>
      <input type="file" accept=".csv,.txt,.iif,.xml"
             id="mig-file-input" style="display:none"
             onchange="_migFileSelected(this)">
    </label>
    <div id="mig-parse-status" style="font-size:13px;color:var(--ink2);margin-top:12px"></div>
    <div style="margin-top:20px">
      <button class="btn btn-primary" id="mig-next1"
              onclick="_migGoStep2()" disabled>Next: Map Accounts →</button>
    </div>`;
}

function _migDrop(ev) {
  ev.preventDefault();
  const f = ev.dataTransfer.files[0];
  if (f) _migParseFile(f);
}

function _migFileSelected(inp) {
  if (inp.files[0]) _migParseFile(inp.files[0]);
}

async function _migParseFile(file) {
  _migFile = file;
  const st  = document.getElementById('mig-parse-status');
  const btn = document.getElementById('mig-next1');
  st.textContent = 'Parsing…';
  if (btn) btn.disabled = true;
  const fd = new FormData();
  fd.append('file', file);
  try {
    const r = await fetch('/api/migration/parse',
                          {method:'POST', credentials:'include', body:fd});
    const j = await r.json();
    if (!j.ok) { st.textContent = '⚠ ' + (j.error || 'Parse error'); return; }
    _migParsed = j.data;
    const c = _migParsed.counts;
    const total = Object.values(c).reduce((a, b) => a + b, 0);
    const parts = [];
    if (c.accounts) parts.push(`${c.accounts} account${c.accounts !== 1 ? 's' : ''}`);
    if (c.contacts) parts.push(`${c.contacts} contact${c.contacts !== 1 ? 's' : ''}`);
    if (c.invoices) parts.push(`${c.invoices} invoice${c.invoices !== 1 ? 's' : ''}`);
    if (c.bills)    parts.push(`${c.bills} bill${c.bills !== 1 ? 's' : ''}`);
    if (c.journals) parts.push(`${c.journals} journal${c.journals !== 1 ? 's' : ''}`);
    st.innerHTML = `<strong>Detected: ${esc(_migParsed.format)}</strong> — `
      + (parts.join(', ') || 'nothing found')
      + (_migParsed.warnings.length
          ? `<br><span style="color:var(--amber)">⚠ ${_migParsed.warnings.length} warning(s)</span>`
          : '');
    if (btn) btn.disabled = (total === 0);
  } catch(e) {
    st.textContent = '⚠ Upload error: ' + e.message;
  }
}

// ── Step 2: Map Accounts ──────────────────────────────────────────────────────

const _MIG_BADGE = {
  high:   '<span class="mig-conf high">● High</span>',
  medium: '<span class="mig-conf medium">● Medium</span>',
  low:    '<span class="mig-conf low">● Low</span>',
};

async function _migGoStep2() {
  if (!_migParsed) return;
  if (_migParsed.accounts.length && !_migDboxAccts.length) {
    try { _migDboxAccts = await apiFetch('/api/accounts'); }
    catch(e) { toast('Could not load accounts: ' + e.message, 'err'); return; }
  }
  _migStep = 2; _migRender();
}

function _migMakeAcctOpts(selectedId) {
  const opts = _migDboxAccts.map(a =>
    `<option value="${a.id}"${a.id == selectedId ? ' selected' : ''}>${
      esc(a.code ? a.code + ' – ' : '')}${esc(a.name)}</option>`
  ).join('');
  return `<option value="">— Create as new —</option>${opts}`;
}

function _migStep2() {
  const accts = (_migParsed && _migParsed.accounts) || [];
  if (!accts.length) {
    document.getElementById('mig-step-content').innerHTML = `
      <div class="set-section-sub">Map accounts</div>
      <p style="color:var(--ink3);font-size:14px">No accounts found in this file.</p>
      <div style="margin-top:16px;display:flex;gap:8px">
        <button class="btn" onclick="_migStep=1;_migRender()">← Back</button>
        <button class="btn btn-primary" onclick="_migStep=3;_migRender()">Next: Options →</button>
      </div>`;
    return;
  }
  const rows = accts.map((a, i) => {
    const existing = _migAcctMap.hasOwnProperty(a.key) ? _migAcctMap[a.key] : undefined;
    const sug   = a.suggestion;
    const selId = (existing !== undefined) ? existing
                : (sug && sug.confidence === 'high' ? sug.id : '');
    const badge = sug ? (_MIG_BADGE[sug.confidence] || '') : '';
    return `<div class="ti-map-row">
      <div class="ti-map-name">
        ${a.code ? `<span style="font-family:'DM Mono',monospace;font-size:11px;color:var(--ink3)">${esc(a.code)}</span> ` : ''}${esc(a.name)}<span style="font-size:11px;color:var(--ink3)"> · ${esc(a.type)}</span>
      </div>
      <div style="font-size:12px;white-space:nowrap">${badge}</div>
      <select class="set-inp mig-acct-sel ti-map-sel" style="max-width:240px"
              data-ext="${esc(a.key)}" id="mig-acct-${i}">
        ${_migMakeAcctOpts(selId)}
      </select>
    </div>`;
  }).join('');

  document.getElementById('mig-step-content').innerHTML = `
    <div class="set-section-sub">Map accounts</div>
    <p style="font-size:13px;color:var(--ink2);margin:0 0 16px">
      For each account in the import file, select the matching dbox account or leave as
      <em>Create as new</em> to add it to your chart of accounts.
    </p>
    <div class="ti-map-table" style="max-height:420px;overflow-y:auto;padding-right:4px">${rows}</div>
    <div style="margin-top:20px;display:flex;gap:8px">
      <button class="btn" onclick="_migStep=1;_migRender()">← Back</button>
      <button class="btn btn-primary" onclick="_migGoStep3()">Next: Options →</button>
    </div>`;
}

function _migGoStep3() {
  _migAcctMap = {};
  document.querySelectorAll('.mig-acct-sel').forEach(sel => {
    _migAcctMap[sel.dataset.ext] = sel.value || null;
  });
  _migStep = 3; _migRender();
}

// ── Step 3: Options ───────────────────────────────────────────────────────────

function _migStep3() {
  const c = (_migParsed && _migParsed.counts) || {};
  const backStep = (_migParsed && _migParsed.accounts.length) ? 2 : 1;
  const opt = (key, label, count) => count > 0 ? `
    <label class="mig-opt-row">
      <input type="checkbox" id="mig-opt-${key}" checked>
      <span>${label}</span>
      <span class="ti-map-cnt">${count}</span>
    </label>` : '';
  const warnHtml = (_migParsed && _migParsed.warnings.length) ? `
    <div style="background:var(--surface2);border:1px solid var(--amber);border-radius:6px;
                padding:10px 14px;font-size:12px;color:var(--ink2);max-width:500px;margin-bottom:20px">
      <strong>⚠ Parse warnings:</strong><br>
      ${_migParsed.warnings.map(w => esc(w)).join('<br>')}
    </div>` : '';
  document.getElementById('mig-step-content').innerHTML = `
    <div class="set-section-sub">Import options</div>
    <p style="font-size:13px;color:var(--ink2);margin:0 0 16px">
      Choose what to import. Records with the same name as an existing record are skipped.
    </p>
    <div style="display:flex;flex-direction:column;gap:10px;max-width:400px;margin-bottom:24px">
      ${opt('accounts', 'Accounts', c.accounts)}
      ${opt('contacts', 'Contacts', c.contacts)}
      ${opt('invoices', 'Invoices', c.invoices)}
      ${opt('bills',    'Bills',    c.bills)}
      ${opt('journals', 'Journal entries', c.journals)}
    </div>
    ${warnHtml}
    <div style="display:flex;gap:8px">
      <button class="btn" onclick="_migStep=${backStep};_migRender()">← Back</button>
      <button class="btn btn-primary" id="mig-import-btn" onclick="_migImport()">Import Now</button>
    </div>`;
}

// ── Import ────────────────────────────────────────────────────────────────────

async function _migImport() {
  const btn = document.getElementById('mig-import-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Importing…'; }
  const boolOpt = key => {
    const el = document.getElementById('mig-opt-' + key);
    return !el || el.checked;
  };
  const config = {
    account_map:     _migAcctMap,
    import_accounts: boolOpt('accounts'),
    import_contacts: boolOpt('contacts'),
    import_invoices: boolOpt('invoices'),
    import_bills:    boolOpt('bills'),
    import_journals: boolOpt('journals'),
  };
  const fd = new FormData();
  fd.append('file', _migFile);
  fd.append('config', JSON.stringify(config));
  try {
    const r = await fetch('/api/migration/import',
                          {method:'POST', credentials:'include', body:fd});
    const j = await r.json();
    if (!j.ok) {
      toast(j.error || 'Import failed', 'err');
      if (btn) { btn.disabled = false; btn.textContent = 'Import Now'; }
      return;
    }
    _migParsed._result = j.data;
    _migStep = 4; _migRender();
  } catch(e) {
    toast('Import error: ' + e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Import Now'; }
  }
}

// ── Step 4: Done ──────────────────────────────────────────────────────────────

function _migStep4() {
  const res      = (_migParsed && _migParsed._result) || {};
  const imported = res.imported || {};
  const errors   = res.errors   || [];
  const LABELS   = {accounts:'accounts', contacts:'contacts', invoices:'invoices',
                    bills:'bills', journals:'journal entries'};
  const rows = Object.entries(imported)
    .filter(([, v]) => v > 0)
    .map(([k, v]) => `<div style="display:flex;gap:8px;font-size:14px;margin-bottom:4px">
      <span style="color:var(--green)">✓</span>
      <span>${v} ${LABELS[k] || k} imported</span>
    </div>`).join('');
  const errHtml = errors.length ? `
    <div style="margin-top:16px">
      <div style="font-weight:600;font-size:13px;color:var(--red);margin-bottom:6px">
        ⚠ ${errors.length} error(s):</div>
      ${errors.slice(0, 30).map(e =>
          `<div style="font-size:12px;color:var(--ink2);margin-bottom:3px">${esc(e)}</div>`
        ).join('')}
      ${errors.length > 30 ? `<div style="font-size:12px;color:var(--ink3)">… and ${errors.length-30} more</div>` : ''}
    </div>` : '';
  document.getElementById('mig-step-content').innerHTML = `
    <div class="set-section-sub">Import complete</div>
    <div style="margin-bottom:16px">
      ${rows || '<div style="color:var(--ink3);font-size:14px">Nothing was imported.</div>'}
    </div>
    ${errHtml}
    <div style="margin-top:24px">
      <button class="btn" onclick="_migShow()">Import another file</button>
    </div>`;
}


// ═══════════════════════════════════════════════════════════════════════════
// BACKUP
// ═══════════════════════════════════════════════════════════════════════════

async function _setLoadBackup() {
  const body = document.getElementById('set-body');
  let cfg = {};
  try { cfg = await apiFetch('/api/backup/settings') || {}; }
  catch(e) { body.innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`; return; }

  const ivals = [
    [1,'Every 1 hour'],[4,'Every 4 hours'],[12,'Every 12 hours'],
    [24,'Every 24 hours'],[168,'Every week'],
  ];
  const keeps = [3,5,10,20,50];

  body.innerHTML = `
    <div class="set-section-hdr">💾  Backup</div>

    <div class="set-sect">
      <div class="set-section-sub">Manual Backup</div>
      <div class="set-hint" style="margin-bottom:12px">Company file: <strong>${esc(cfg.db_name || '—')}</strong></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <button class="btn btn-primary" onclick="_bkBackupNow()">Back Up Now</button>
        <button class="btn btn-outline" id="bk-restore-btn" onclick="_bkRestoreClick()">Restore Backup…</button>
      </div>
      <div id="bk-now-result" style="margin-top:10px;font-size:13px"></div>
    </div>

    <div class="set-divider"></div>

    <div class="set-sect">
      <div class="set-section-sub">Auto-Backup Settings</div>
      <div class="set-hint" style="margin-bottom:12px">
        Auto-backup runs in the background while the app is open.
      </div>
      <div class="set-form-grid set-form-1col">
        <div class="set-field set-check-field">
          <input type="checkbox" id="bk-enabled" ${cfg.enabled ? 'checked' : ''}>
          <label class="set-lbl" for="bk-enabled">Enable auto-backup</label>
        </div>
      </div>
      <div class="set-form-grid set-form-1col" style="margin-top:10px">
        <div class="set-field">
          <label class="set-lbl">Backup Directory</label>
          <div class="set-hint">Folder where backup files are saved</div>
          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            <input class="set-inp" id="bk-dir" type="text"
                   value="${esc(cfg.directory || cfg.suggested_dir || '')}"
                   placeholder="${esc(cfg.suggested_dir || '')}" style="flex:1;min-width:240px;max-width:420px">
            <button class="btn btn-outline btn-sm" onclick="_bkBrowseDir()">Browse…</button>
          </div>
        </div>
      </div>
      <div class="set-form-grid set-form-2col" style="margin-top:10px">
        <div class="set-field">
          <label class="set-lbl">Interval</label>
          <select class="set-inp" id="bk-interval">
            ${ivals.map(([v,l]) => `<option value="${v}"${cfg.interval_hours==v?' selected':''}>${l}</option>`).join('')}
          </select>
        </div>
        <div class="set-field">
          <label class="set-lbl">Keep</label>
          <select class="set-inp" id="bk-keep">
            ${keeps.map(k => `<option value="${k}"${cfg.keep_count==k?' selected':''}>${k} backups</option>`).join('')}
          </select>
        </div>
      </div>
      <div class="set-foot">
        <button class="btn btn-primary" onclick="_bkSaveSettings()">Save Settings</button>
      </div>
    </div>

    <div class="set-divider"></div>

    <div class="set-sect">
      <div class="set-section-sub">Recent Backups</div>
      <div id="bk-list"><div class="state-loading">Loading…</div></div>
    </div>`;

  _bkLoadList();
}

async function _bkSaveSettings() {
  const data = {
    enabled:        document.getElementById('bk-enabled').checked,
    directory:      document.getElementById('bk-dir').value.trim(),
    interval_hours: parseFloat(document.getElementById('bk-interval').value),
    keep_count:     parseInt(document.getElementById('bk-keep').value),
  };
  try {
    const r = await fetch('/api/backup/settings', {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(data),
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Save failed', 'err'); return; }
    toast('Backup settings saved');
    _bkLoadList();
  } catch(e) {
    toast('Save failed: ' + e.message, 'err');
  }
}

async function _bkBackupNow() {
  const res = document.getElementById('bk-now-result');
  const dir = (document.getElementById('bk-dir') || {}).value || '';
  if (res) res.innerHTML = '<span style="color:var(--ink2)">Creating backup…</span>';
  try {
    const r = await fetch('/api/backup/now', {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({directory: dir}),
    });
    const j = await r.json();
    if (!j.ok) {
      toast(j.error || 'Backup failed', 'err');
      if (res) res.innerHTML = '';
      return;
    }
    toast('Backup created: ' + j.data.filename);
    if (res) res.innerHTML = `<span style="color:var(--green)">✓ ${esc(j.data.filename)}</span>`;
    _bkLoadList();
  } catch(e) {
    toast('Backup failed: ' + e.message, 'err');
    if (res) res.innerHTML = '';
  }
}

async function _bkBrowseDir() {
  const btn = document.querySelector('#bk-dir + button') ||
              document.querySelector('button[onclick="_bkBrowseDir()"]');
  if (btn) { btn.disabled = true; btn.textContent = 'Opening…'; }
  try {
    const j = await apiFetch('/api/backup/browse-dir');
    if (j && j.path) {
      const inp = document.getElementById('bk-dir');
      if (inp) inp.value = j.path;
    }
  } catch(e) {
    toast('Could not open folder picker: ' + e.message, 'err');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Browse…'; }
  }
}

let _bkRestorePath = null;
let _bkRestoreBd   = null;

async function _bkRestoreClick() {
  const btn = document.getElementById('bk-restore-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Opening…'; }
  try {
    const j = await apiFetch('/api/backup/pick-file');
    if (!j || !j.path) return;
    _bkRestorePath = j.path;
    const filename = j.path.replace(/.*[\\/]/, '');
    _bkRestoreBd = document.createElement('div');
    _bkRestoreBd.className = 'modal-bd';
    _bkRestoreBd.style.display = 'flex';
    _bkRestoreBd.innerHTML = `
      <div class="modal-box modal-460">
        <div class="modal-hdr"><span>Restore Backup</span></div>
        <div class="modal-body">
          <div style="display:flex;gap:10px;align-items:flex-start;margin-bottom:14px">
            <span style="font-size:22px;line-height:1">⚠</span>
            <div>
              <div style="font-weight:600;margin-bottom:6px">This will overwrite the current company file.</div>
              <div style="font-size:13px;color:var(--ink2)">All data will be replaced with the contents of the selected backup. This cannot be undone.</div>
            </div>
          </div>
          <div style="background:var(--surface);border:1px solid var(--border);border-radius:6px;
                      padding:10px 12px;font-size:13px">
            <div style="color:var(--ink3);font-size:11px;margin-bottom:2px">Selected file</div>
            <div style="font-weight:500;word-break:break-all">${esc(filename)}</div>
          </div>
        </div>
        <div class="modal-foot">
          <button class="btn btn-outline btn-sm" onclick="_bkRestoreCancel()">Cancel</button>
          <button class="btn btn-danger btn-sm" id="bk-restore-confirm-btn"
                  onclick="_bkRestoreConfirm()">Overwrite &amp; Restore</button>
        </div>
      </div>`;
    document.body.appendChild(_bkRestoreBd);
  } catch(e) {
    toast('Could not open file picker: ' + e.message, 'err');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Restore Backup…'; }
  }
}

function _bkRestoreCancel() {
  if (_bkRestoreBd) { _bkRestoreBd.remove(); _bkRestoreBd = null; }
  _bkRestorePath = null;
}

async function _bkRestoreConfirm() {
  if (!_bkRestorePath) return;
  const bd  = _bkRestoreBd;
  const btn = document.getElementById('bk-restore-confirm-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Restoring…'; }
  try {
    const r = await fetch('/api/backup/restore', {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({path: _bkRestorePath}),
    });
    const j = await r.json();
    if (bd) bd.remove();
    _bkRestoreBd = null; _bkRestorePath = null;
    if (!j.ok) { toast(j.error || 'Restore failed', 'err'); return; }
    toast('Company file restored successfully');
  } catch(e) {
    if (bd) bd.remove();
    _bkRestoreBd = null; _bkRestorePath = null;
    toast('Restore failed: ' + e.message, 'err');
  }
}

async function _bkLoadList() {
  const el = document.getElementById('bk-list');
  if (!el) return;
  try {
    const files = await apiFetch('/api/backup/list');
    if (!files || !files.length) {
      el.innerHTML = '<div class="set-hint">No backups found in the configured directory.</div>';
      return;
    }
    const fmt = n => n >= 1048576 ? (n/1048576).toFixed(1)+' MB' : Math.round(n/1024)+' KB';
    el.innerHTML = `<div class="bk-file-list">
      ${files.map(f => `
        <div class="bk-file-row">
          <span class="bk-file-name">${esc(f.filename)}</span>
          <span class="bk-file-meta">${esc(f.modified)}</span>
          <span class="bk-file-size">${fmt(f.size)}</span>
        </div>`).join('')}
    </div>`;
  } catch(e) {
    el.innerHTML = `<div class="set-hint">Could not load backup list: ${esc(e.message)}</div>`;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// FILES & FOLDERS
// ═══════════════════════════════════════════════════════════════════════════
async function _setLoadFiles() {
  const body = document.getElementById('set-body');
  let cfg = {};
  try { cfg = await apiFetch('/api/general/settings') || {}; }
  catch(e) { body.innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`; return; }

  body.innerHTML = `
    <div class="set-section-hdr">📁  Files &amp; Folders</div>

    <div class="set-sect">
      <div class="set-section-sub">Default File Directory</div>
      <div class="set-hint" style="margin-bottom:12px">
        The folder the file browser opens to when you launch the app. Leave blank to start at "This PC".
      </div>
      <div class="set-form-grid set-form-1col">
        <div class="set-field">
          <label class="set-lbl">Default Folder</label>
          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            <input class="set-inp" id="gf-dir" type="text"
                   value="${esc(cfg.default_file_dir || '')}"
                   placeholder="${esc(cfg.suggested_dir || '')}"
                   style="flex:1;min-width:240px;max-width:420px">
            <button class="btn btn-outline btn-sm" onclick="_setFilesBrowse()">Browse…</button>
          </div>
        </div>
      </div>
      <div class="set-foot">
        <button class="btn btn-outline btn-sm" onclick="_setFilesClear()">Clear</button>
        <button class="btn btn-primary" onclick="_setFilesSave()">Save</button>
      </div>
    </div>`;
}

async function _setFilesBrowse() {
  const btn = document.querySelector('button[onclick="_setFilesBrowse()"]');
  if (btn) { btn.disabled = true; btn.textContent = 'Opening…'; }
  try {
    const j = await apiFetch('/api/general/browse-dir');
    if (j && j.path) {
      const inp = document.getElementById('gf-dir');
      if (inp) inp.value = j.path;
    }
  } catch(e) {
    toast('Could not open folder picker: ' + e.message, 'err');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Browse…'; }
  }
}

function _setFilesClear() {
  const inp = document.getElementById('gf-dir');
  if (inp) inp.value = '';
}

async function _setFilesSave() {
  const dir = (document.getElementById('gf-dir') || {}).value || '';
  try {
    const r = await fetch('/api/general/settings', {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({default_file_dir: dir.trim()}),
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Save failed', 'err'); return; }
    toast('Settings saved');
  } catch(e) {
    toast('Save failed: ' + e.message, 'err');
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// DOCUMENT NUMBERS
// ═══════════════════════════════════════════════════════════════════════════
async function _setLoadDocNums() {
  const body = document.getElementById('set-body');
  let co = {};
  try { co = await apiFetch('/api/company') || {}; } catch(e) {}

  const defaults = { inv_prefix:'INV-', inv_next:1, quote_prefix:'QTE-', quote_next:1, po_prefix:'PO-', po_next:1001 };
  const v = f => co[f] ?? defaults[f];

  body.innerHTML = `
    <div class="set-section-hdr">🔢  Document Numbers</div>
    <p style="color:var(--ink2);font-size:.88rem;margin:0 0 20px">
      Set a custom prefix and starting number for each document type.
      The "next" value acts as a floor — if existing records are already higher,
      the sequence continues from the last used number.
    </p>

    <div class="set-card">
      <div class="set-section-sub">Invoices</div>
      <div class="edt-row" style="margin-top:10px">
        <div class="edt-field">
          <label class="edt-lbl">Prefix</label>
          <input class="edt-inp" id="dn-inv-prefix" value="${esc(String(v('inv_prefix')))}" style="max-width:120px">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Next number</label>
          <input class="edt-inp" type="number" min="1" id="dn-inv-next" value="${v('inv_next')}" style="max-width:120px">
        </div>
        <div class="edt-field" style="align-self:flex-end;padding-bottom:4px">
          <span class="col-ink2" style="font-size:.85rem">Preview: <span id="dn-inv-preview" style="font-family:monospace"></span></span>
        </div>
      </div>
    </div>

    <div class="set-card" style="margin-top:12px">
      <div class="set-section-sub">Quotes</div>
      <div class="edt-row" style="margin-top:10px">
        <div class="edt-field">
          <label class="edt-lbl">Prefix</label>
          <input class="edt-inp" id="dn-quote-prefix" value="${esc(String(v('quote_prefix')))}" style="max-width:120px">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Next number</label>
          <input class="edt-inp" type="number" min="1" id="dn-quote-next" value="${v('quote_next')}" style="max-width:120px">
        </div>
        <div class="edt-field" style="align-self:flex-end;padding-bottom:4px">
          <span class="col-ink2" style="font-size:.85rem">Preview: <span id="dn-quote-preview" style="font-family:monospace"></span></span>
        </div>
      </div>
    </div>

    <div class="set-card" style="margin-top:12px">
      <div class="set-section-sub">Purchase Orders</div>
      <div class="edt-row" style="margin-top:10px">
        <div class="edt-field">
          <label class="edt-lbl">Prefix</label>
          <input class="edt-inp" id="dn-po-prefix" value="${esc(String(v('po_prefix')))}" style="max-width:120px">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Next number</label>
          <input class="edt-inp" type="number" min="1" id="dn-po-next" value="${v('po_next')}" style="max-width:120px">
        </div>
        <div class="edt-field" style="align-self:flex-end;padding-bottom:4px">
          <span class="col-ink2" style="font-size:.85rem">Preview: <span id="dn-po-preview" style="font-family:monospace"></span></span>
        </div>
      </div>
    </div>

    <div style="margin-top:20px">
      <button class="btn btn-primary" onclick="_setDnSave()">Save Document Numbers</button>
    </div>`;

  _setDnPreview();

  // Live preview on input
  ['inv-prefix','inv-next','quote-prefix','quote-next','po-prefix','po-next'].forEach(id => {
    document.getElementById(`dn-${id}`)?.addEventListener('input', _setDnPreview);
  });
}

function _setDnPreview() {
  const pad = (prefix, num, width) => {
    const n = Math.max(1, parseInt(num) || 1);
    return `${prefix}${String(n).padStart(width, '0')}`;
  };
  const invP = document.getElementById('dn-inv-prefix')?.value || 'INV-';
  const invN = document.getElementById('dn-inv-next')?.value || '1';
  const qteP = document.getElementById('dn-quote-prefix')?.value || 'QTE-';
  const qteN = document.getElementById('dn-quote-next')?.value || '1';
  const poP  = document.getElementById('dn-po-prefix')?.value || 'PO-';
  const poN  = document.getElementById('dn-po-next')?.value || '1001';

  const el = id => document.getElementById(id);
  if (el('dn-inv-preview'))   el('dn-inv-preview').textContent   = pad(invP, invN, 5);
  if (el('dn-quote-preview')) el('dn-quote-preview').textContent = pad(qteP, qteN, 4);
  if (el('dn-po-preview'))    el('dn-po-preview').textContent    = pad(poP,  poN,  4);
}

async function _setDnSave() {
  const payload = {
    inv_prefix:   document.getElementById('dn-inv-prefix')?.value.trim() || 'INV-',
    inv_next:     Math.max(1, parseInt(document.getElementById('dn-inv-next')?.value || 1)),
    quote_prefix: document.getElementById('dn-quote-prefix')?.value.trim() || 'QTE-',
    quote_next:   Math.max(1, parseInt(document.getElementById('dn-quote-next')?.value || 1)),
    po_prefix:    document.getElementById('dn-po-prefix')?.value.trim() || 'PO-',
    po_next:      Math.max(1, parseInt(document.getElementById('dn-po-next')?.value || 1001)),
  };
  try {
    const r = await fetch('/api/company/doc-numbers', {
      method: 'PUT', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Failed');
    toast('Document numbers saved');
  } catch(e) { toast(e.message, 'err'); }
}


// LICENCE
// ═══════════════════════════════════════════════════════════════════════════
async function _setLoadLicence() {
  const body = document.getElementById('set-body');
  let lic = {};
  try { lic = await apiFetch('/api/licence') || {}; }
  catch(e) { body.innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`; return; }

  const statusLabels = {
    valid:     ['✓ Valid',       'var(--green)'],
    lapsed:    ['⚠ Lapsed',      'var(--amber)'],
    tampered:  ['✕ Tampered',    'var(--red)'],
    missing:   ['— Not found',   'var(--ink3)'],
    malformed: ['✕ Unreadable',  'var(--red)'],
  };
  const [statusText, statusColor] = statusLabels[lic.status] || ['Unknown', 'var(--ink3)'];

  const infoRows = [
    ['Status',    `<span style="color:${statusColor};font-weight:600">${statusText}</span>`],
    ['Issued to', esc(lic.issued_to || '—')],
    ['Contact',   esc(lic.contact   || '—')],
    ['Tier',      esc(lic.tier      || '—')],
    ['Issue date',esc(lic.issue_date || '—')],
    ['Expiry',    lic.is_permanent ? '<em>Permanent (registered)</em>'
                  : lic.eval_expiry
                    ? `${esc(lic.eval_expiry)}${lic.days_remaining != null ? ` (${lic.days_remaining} day${lic.days_remaining !== 1 ? 's' : ''} remaining)` : ''}`
                    : '—'],
    ['Build',     esc(lic.build     || '—')],
    ['File',      esc(lic.path      || 'Not found')],
  ];

  const rows = infoRows.map(([k,v]) => `
    <div class="set-lic-row">
      <span class="set-lic-key">${k}</span>
      <span class="set-lic-val">${v}</span>
    </div>`).join('');

  body.innerHTML = `
    <div class="set-section-hdr">🔑  Licence</div>

    <div class="set-sect">
      <div class="set-section-sub">Current Licence</div>
      <div class="set-lic-table">${rows}</div>
    </div>

    <div class="set-divider"></div>

    <div class="set-sect">
      <div class="set-section-sub">Install Licence File</div>
      <div class="set-hint" style="margin-bottom:12px">
        Upload a <code>dbox.lic</code> file supplied by Dogbox Software. The file
        will be installed next to the app and take effect immediately.
      </div>
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
        <label class="btn" style="cursor:pointer">
          Upload dbox.lic…
          <input type="file" accept=".lic" id="lic-file-input" style="display:none"
                 onchange="_setLicenceUpload(this)">
        </label>
        <span id="lic-upload-status" style="font-size:13px;color:var(--ink2)"></span>
      </div>
    </div>`;
}

async function _setLicenceUpload(input) {
  if (!input.files.length) return;
  const st = document.getElementById('lic-upload-status');
  if (st) st.textContent = 'Uploading…';
  const fd = new FormData();
  fd.append('licence', input.files[0]);
  try {
    const r = await fetch('/api/licence/upload', {method:'POST', credentials:'include', body:fd});
    const j = await r.json();
    if (!j.ok) {
      if (st) st.textContent = j.error || 'Upload failed';
      toast(j.error || 'Licence upload failed', 'err');
      return;
    }
    toast('Licence installed successfully');
    _setLoadLicence();
  } catch(e) {
    if (st) st.textContent = 'Upload failed: ' + e.message;
    toast('Licence upload failed: ' + e.message, 'err');
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// LICENCE AGREEMENT (view-only)
// ═══════════════════════════════════════════════════════════════════════════
async function _setLoadEula() {
  const body = document.getElementById('set-body');
  let data;
  try { data = await apiFetch('/api/eula'); }
  catch(e) { body.innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`; return; }

  const dateStr = data.accepted_date
    ? `Accepted on ${esc(data.accepted_date)}`
    : 'Not yet formally accepted';

  body.innerHTML = `
    <div class="set-section-hdr">📄  Licence Agreement</div>
    <div class="set-hint" style="margin-bottom:16px">
      Dogbox Accounting EULA v${esc(data.version)} &nbsp;·&nbsp; ${dateStr}
    </div>
    <pre style="
      background:var(--surface);
      border:1.5px solid var(--border);
      border-radius:8px;
      padding:18px 20px;
      font-family:'DM Mono',monospace;
      font-size:11.5px;
      line-height:1.7;
      color:var(--ink);
      white-space:pre-wrap;
      word-break:break-word;
      max-height:520px;
      overflow-y:auto;
    ">${esc(data.text)}</pre>`;
}

// ── Data Repair ───────────────────────────────────────────────────────────────
function _setLoadRepair() {
  const body = document.getElementById('set-body');
  body.innerHTML = `
    <div class="set-section-hdr">🔧  Data Repair</div>
    <div class="set-hint" style="margin-bottom:18px">These tools fix known data issues. Each is safe to run more than once — already-correct records are skipped.</div>

    <div class="set-sect" style="margin-bottom:18px">
      <div class="set-section-sub">Missing GL Journals</div>
      <div class="set-hint" style="margin-bottom:10px">Posts missing income/expense journal entries for invoices or bills that were approved using the "Mark Sent" or "Approve" button before a bug fix was applied. Skips any that already have a journal entry.</div>
      <button class="btn btn-primary" id="repair-gl-btn" onclick="_repairMissingGL()">Run Repair</button>
      <div id="repair-gl-result" style="margin-top:10px"></div>
    </div>

    <div class="set-sect">
      <div class="set-section-sub">Orphaned Void Journal Reversals</div>
      <div class="set-hint" style="margin-bottom:10px">Posts missing reversal entries for voided invoices/bills whose GL was never unwound.</div>
      <button class="btn btn-outline" id="repair-void-btn" onclick="_repairVoidJournals()">Run Repair</button>
      <div id="repair-void-result" style="margin-top:10px"></div>
    </div>`;
}

async function _repairMissingGL() {
  const btn = document.getElementById('repair-gl-btn');
  const out = document.getElementById('repair-gl-result');
  btn.disabled = true; btn.textContent = 'Running…';
  try {
    const r = await fetch('/api/admin/repair-missing-gl', {method:'POST', credentials:'include'});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Repair failed');
    const msg = `Done — ${j.data.invoices_repaired} invoice(s) and ${j.data.bills_repaired} bill(s) repaired.`;
    out.innerHTML = `<span style="color:var(--green);font-size:13px">${esc(msg)}</span>`;
    if (j.data.errors && j.data.errors.length)
      out.innerHTML += `<div style="color:var(--red);margin-top:6px;font-size:12px">${j.data.errors.map(e=>esc(e)).join('<br>')}</div>`;
    btn.textContent = 'Run Again';
  } catch(e) {
    out.innerHTML = `<span style="color:var(--red);font-size:13px">${esc(e.message)}</span>`;
    btn.textContent = 'Run Repair';
  }
  btn.disabled = false;
}

async function _repairVoidJournals() {
  const btn = document.getElementById('repair-void-btn');
  const out = document.getElementById('repair-void-result');
  btn.disabled = true; btn.textContent = 'Running…';
  try {
    const r = await fetch('/api/admin/repair-void-journals', {method:'POST', credentials:'include'});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Repair failed');
    const msg = `Done — ${j.data.invoices_repaired} invoice(s) and ${j.data.bills_repaired} bill(s) repaired.`;
    out.innerHTML = `<span style="color:var(--green);font-size:13px">${esc(msg)}</span>`;
    if (j.data.errors && j.data.errors.length)
      out.innerHTML += `<div style="color:var(--red);margin-top:6px;font-size:12px">${j.data.errors.map(e=>esc(e)).join('<br>')}</div>`;
    btn.textContent = 'Run Again';
  } catch(e) {
    out.innerHTML = `<span style="color:var(--red);font-size:13px">${esc(e.message)}</span>`;
    btn.textContent = 'Run Repair';
  }
  btn.disabled = false;
}


// ── EOFY Rollover ─────────────────────────────────────────────────────────────

function _eofyPreflight(s) {
  if (!s.preflight) return '';
  const p   = s.preflight;
  const fmt$ = n => '$' + Math.abs(n).toLocaleString('en-AU',{minimumFractionDigits:2,maximumFractionDigits:2});

  const checks = [
    {
      ok:  p.ar_outstanding.count === 0,
      lbl: 'Accounts Receivable',
      ok_msg:  'All invoices paid or accounted for',
      bad_msg: p.ar_outstanding.count + ' outstanding invoice' + (p.ar_outstanding.count !== 1 ? 's' : '') +
               ' totalling ' + fmt$(p.ar_outstanding.total) +
               ' — <a onclick="navigate(\'invoices\')" style="cursor:pointer;color:var(--accent)">view in Invoices</a>',
    },
    {
      ok:  p.ap_outstanding.count === 0,
      lbl: 'Accounts Payable',
      ok_msg:  'All bills paid or accounted for',
      bad_msg: p.ap_outstanding.count + ' outstanding bill' + (p.ap_outstanding.count !== 1 ? 's' : '') +
               ' totalling ' + fmt$(p.ap_outstanding.total) +
               ' — <a onclick="navigate(\'bills\')" style="cursor:pointer;color:var(--accent)">view in Bills</a>',
    },
    {
      ok:  p.unreconciled_bank === 0,
      lbl: 'Bank Reconciliation',
      ok_msg:  'All bank transactions reconciled',
      bad_msg: p.unreconciled_bank + ' unreconciled bank transaction' + (p.unreconciled_bank !== 1 ? 's' : '') +
               ' — <a onclick="navigate(\'bankrec\')" style="cursor:pointer;color:var(--accent)">open Bank Rec</a>',
    },
  ];

  const allOk = checks.every(c => c.ok);
  const rows  = checks.map(c =>
    '<div style="display:flex;align-items:baseline;gap:10px;padding:7px 0;' +
    'border-bottom:1px solid var(--border)">' +
      '<span style="flex:0 0 18px;font-size:14px">' + (c.ok ? '✓' : '⚠') + '</span>' +
      '<span style="flex:0 0 160px;font-size:13px;font-weight:600;color:var(--ink2)">' + c.lbl + '</span>' +
      '<span style="font-size:13px;color:' + (c.ok ? 'var(--ink3)' : 'var(--amber)') + '">' +
        (c.ok ? c.ok_msg : c.bad_msg) +
      '</span>' +
    '</div>'
  ).join('');

  return '<div style="margin-bottom:24px;padding:14px 18px;background:var(--surface);' +
    'border:1px solid ' + (allOk ? 'var(--border)' : 'var(--amber)') + ';border-radius:8px">' +
    '<div style="font-weight:600;font-size:13px;margin-bottom:10px;color:var(--ink)">' +
      (allOk ? '✓ Pre-rollover checks passed' : '⚠ Review before rolling over') +
    '</div>' +
    rows +
    (!allOk ? '<div style="font-size:12px;color:var(--ink3);margin-top:10px">' +
      'Outstanding balances will still roll over correctly — these are reminders, not blockers.' +
    '</div>' : '') +
  '</div>';
}

async function _setLoadEofy() {
  const body = document.getElementById('set-body');
  body.innerHTML = '<div class="state-loading">Loading…</div>';
  let s;
  try {
    s = await apiFetch('/api/company/rollover-status');
  } catch(e) {
    body.innerHTML = '<div class="set-section-hdr">📅  EOFY Rollover</div>' +
      '<p style="color:var(--red)">' + esc(e.message) + '</p>';
    return;
  }

  const fmt = iso => {
    if (!iso) return '—';
    const [y,m,d] = iso.split('-');
    return d + '/' + m + '/' + y;
  };
  const fmtMoney = n => '$' + Math.abs(n).toLocaleString('en-AU',
    {minimumFractionDigits:2, maximumFractionDigits:2});

  const profitColour = s.net_profit >= 0 ? 'var(--green)' : 'var(--red)';
  const profitLabel  = s.fy_completed ? (s.net_profit >= 0 ? 'Net Profit' : 'Net Loss') : 'YTD Profit/Loss';
  const profitStr    = (s.net_profit < 0 ? '−' : '') + fmtMoney(s.net_profit);

  // Previous lock banner (shown when a prior FY was already closed)
  const prevLockHtml = s.lock_date && !s.already_rolled
    ? '<div style="background:var(--surface);border:1px solid var(--border);border-radius:8px;' +
      'padding:12px 18px;margin-bottom:14px;font-size:13px;color:var(--ink2)">' +
      '<span style="color:var(--green);font-weight:600;margin-right:8px">✓ Previous year closed</span>' +
      'Locked through ' + fmt(s.lock_date) + ' — all transactions dated after that date are unaffected.</div>'
    : '';

  let statusHtml;
  if (s.already_rolled) {
    statusHtml = '<div style="background:var(--surface);border:1px solid var(--green);border-radius:8px;' +
      'padding:16px 20px;margin-bottom:20px">' +
      '<span style="color:var(--green);font-weight:600">✓ ' + s.fy_label + ' is closed</span>' +
      '<span style="color:var(--ink3);margin-left:12px;font-size:13px">Locked through ' + fmt(s.lock_date) + '</span>' +
      '</div>';
  } else if (!s.fy_completed) {
    statusHtml = '<div style="background:var(--surface);border:1px solid var(--border);border-radius:8px;' +
      'padding:16px 20px;margin-bottom:20px">' +
      '<span style="color:var(--ink2);font-weight:600">● ' + s.fy_label + ' in progress</span>' +
      '<span style="color:var(--ink3);margin-left:12px;font-size:13px">Ends ' + fmt(s.fy_end) +
      ' — rollover available after that date</span>' +
      '</div>';
  } else {
    statusHtml = '<div style="background:var(--surface);border:1px solid var(--amber);border-radius:8px;' +
      'padding:16px 20px;margin-bottom:20px">' +
      '<span style="color:var(--amber);font-weight:600">● ' + s.fy_label + ' is ready to close</span>' +
      '</div>';
  }

  body.innerHTML =
    '<div class="set-section-hdr">📅  EOFY Rollover</div>' +
    '<p style="color:var(--ink2);font-size:14px;margin-bottom:16px">' +
    'Posts year-end closing entries (income and expense accounts → Retained Earnings) ' +
    'and locks the closed period against backdated manual journals. ' +
    'Transactions already entered in the current year are unaffected — ' +
    'only new journals dated inside the closed period are blocked.' +
    '</p>' +

    prevLockHtml +
    statusHtml +

    '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:28px">' +
      '<div class="set-card-stat">' +
        '<div class="set-stat-label">Financial Year</div>' +
        '<div class="set-stat-val">' + esc(s.fy_label) + '</div>' +
        '<div class="set-stat-sub">' + fmt(s.fy_start) + ' – ' + fmt(s.fy_end) + '</div>' +
      '</div>' +
      '<div class="set-card-stat">' +
        '<div class="set-stat-label">Total Income</div>' +
        '<div class="set-stat-val" style="color:var(--green)">' + fmtMoney(s.total_income) + '</div>' +
      '</div>' +
      '<div class="set-card-stat">' +
        '<div class="set-stat-label">' + esc(profitLabel) + '</div>' +
        '<div class="set-stat-val" style="color:' + profitColour + '">' + profitStr + '</div>' +
      '</div>' +
    '</div>' +

    _eofyPreflight(s) +

    '<div id="eofy-result"></div>' +

    '<button id="eofy-btn" class="btn-primary"' +
    (s.already_rolled || !s.fy_completed ? ' disabled' : '') + '>' +
    'Roll Over ' + esc(s.fy_label) +
    '</button>' +

    (s.pkg_fy ? (
      '<div style="margin-top:28px;padding-top:22px;border-top:1px solid var(--border)">' +
        '<div style="font-weight:600;font-size:14px;margin-bottom:6px">📦 Accountant Package</div>' +
        '<div style="font-size:13px;color:var(--ink2);margin-bottom:14px">' +
          'Download a ZIP containing Trial Balance, General Ledger, and Fixed Asset Schedule for ' +
          esc(s.pkg_fy.label) + ' (' + fmt(s.pkg_fy.start) + ' – ' + fmt(s.pkg_fy.end) + ').' +
        '</div>' +
        '<button class="btn btn-outline" id="eofy-pkg-btn">⬇ Download ' + esc(s.pkg_fy.label) + ' Package</button>' +
      '</div>'
    ) : '');

  if (!s.already_rolled && s.fy_completed) {
    document.getElementById('eofy-btn').addEventListener('click', () => _eofyRun(s));
  }
  if (s.pkg_fy) {
    document.getElementById('eofy-pkg-btn').addEventListener('click', () => {
      const p = s.pkg_fy;
      window.open('/api/reports/eoy-package?from=' + p.start + '&to=' + p.end +
        '&fy=' + encodeURIComponent(p.label), '_blank');
    });
  }
}

async function _eofyRun(s) {
  if (!confirm(
    'Close ' + s.fy_label + ' (' + s.fy_start + ' to ' + s.fy_end + ')?\n\n' +
    'This will:\n' +
    '  • Post year-end closing journal entries dated ' + s.fy_end + '\n' +
    '  • Transfer the net result to Retained Earnings\n' +
    '  • Lock the period against backdated manual journals\n\n' +
    'This action cannot be undone.'
  )) return;

  const btn    = document.getElementById('eofy-btn');
  const result = document.getElementById('eofy-result');
  btn.disabled = true;
  btn.textContent = 'Rolling over…';

  try {
    const r = await fetch('/api/company/rollover', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({fy_year: s.fy_year}),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Rollover failed');
    const d   = j.data;
    const sign = d.net_profit >= 0 ? '' : '−';
    const amt  = '$' + Math.abs(d.net_profit).toLocaleString('en-AU',{minimumFractionDigits:2});
    result.innerHTML = '<div style="background:var(--surface);border:1px solid var(--green);border-radius:8px;padding:16px 20px;margin-bottom:16px">' +
      '<div style="color:var(--green);font-weight:600;margin-bottom:8px">✓ FY' + d.fy_year + ' closed successfully</div>' +
      '<div style="font-size:13px;color:var(--ink2)">Journal #' + d.journal_id + ' posted · Net result ' + sign + amt + ' transferred to Retained Earnings · Locked through ' + d.lock_date + '</div>' +
      '</div>';
    toast('EOFY rollover complete — FY' + d.fy_year + ' closed, locked through ' + d.lock_date);
    // Reload the section so it advances to show the new current FY
    setTimeout(_setLoadEofy, 800);
  } catch(e) {
    result.innerHTML = '<p style="color:var(--red);font-size:13px">' + esc(e.message) + '</p>';
    btn.disabled = false;
    btn.textContent = 'Roll Over ' + s.fy_label;
  }
}
