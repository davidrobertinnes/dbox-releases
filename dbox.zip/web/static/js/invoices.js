// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ═══════════════════════════════════════════════════════════════════════════
// INVOICES PAGE
// ═══════════════════════════════════════════════════════════════════════════
let _invAll=[],_invFilter='Due',_invSearch='',_invSort={col:'invoice_date',dir:-1},_invSelected=null,_bankAccts=[];
let _invGSTReg = null; // null = not yet loaded; true/false from company.gst_registered
let _invTerminalPollTimer = null;
const INV_STATS=['Due','Draft','Approved','Overdue','Paid','Void','Written Off','Credit Notes','All'];
const INV_BADGE={Paid:'badge-paid',Draft:'badge-draft',Approved:'badge-approved',Sent:'badge-pending',Partial:'badge-partial',Overdue:'badge-overdue',Void:'badge-draft','Written Off':'badge-void','Credit Note':'badge-cn'};

function _effSt(inv) {
  if(['Paid','Void','Draft','Approved','Written Off','Credit Note'].includes(inv.status)) return inv.status;
  const td=isoToday();
  if(inv.due_date&&inv.due_date<td) return 'Overdue';
  return inv.status;
}

async function pageInvoices() {
  if (_invGSTReg === null) {
    try { const me = await apiFetch('/api/me'); _invGSTReg = me ? me.gst_registered !== 0 : true; }
    catch(e) { _invGSTReg = true; }
  }
  try {
    const [invs,accts]=await Promise.all([apiFetch('/api/invoices'),apiFetch('/api/accounts')]);
    _invAll=invs||[]; _bankAccts=(accts||[]).filter(a=>a.is_bank);
    renderInvoicesPage();
  } catch(e){
    document.getElementById('module-content').innerHTML=`<div class="state-error">Failed to load invoices: ${esc(e.message)}</div>`;
  }
}

function _invFiltered() {
  const q=_invSearch.toLowerCase();
  return _invAll.filter(inv=>{
    if(_invFilter==='Due'){if(!['Sent','Partial','Overdue'].includes(_effSt(inv))) return false;}
    else if(_invFilter==='Credit Notes'){if(_effSt(inv)!=='Credit Note') return false;}
    else if(_invFilter!=='All'&&_effSt(inv)!==_invFilter) return false;
    if(q&&![inv.invoice_number,inv.contact_name,inv.status].some(v=>(v||'').toLowerCase().includes(q))) return false;
    return true;
  }).sort((a,b)=>{
    const col=_invSort.col,av=a[col]??'',bv=b[col]??'';
    return(typeof av==='number'?(av-bv):String(av).localeCompare(String(bv)))*_invSort.dir;
  });
}

function renderInvoicesPage(restoreFocus) {
  const rows=_invFiltered();
  const counts=Object.fromEntries(INV_STATS.map(s=>[s,0]));
  counts['All']=_invAll.length;
  _invAll.forEach(inv=>{const s=_effSt(inv);if(s in counts)counts[s]++;if(['Sent','Partial','Overdue'].includes(s))counts['Due']++;if(s==='Credit Note')counts['Credit Notes']++;});
  const panelHtml = _invAll.length===0
    ? `<div class="state-empty">
        <svg class="state-empty-icon" aria-hidden="true"><use href="#ic-file-text"/></svg>
        <div class="state-empty-title">No invoices yet</div>
        <div class="state-empty-sub">Create your first invoice to start getting paid.</div>
        <button class="btn btn-primary" onclick="invNew()">+ New Invoice</button>
      </div>`
    : rows.length===0
    ? `<div class="state-empty">
        <svg class="state-empty-icon" aria-hidden="true"><use href="#ic-file-text"/></svg>
        <div class="state-empty-title">No invoices match your search</div>
        <div class="state-empty-sub">Try adjusting your filters or search term.</div>
        <button class="btn btn-outline btn-sm" onclick="_invFilter='All';_invSearch='';renderInvoicesPage()">Clear filters</button>
      </div>`
    : `<div class="tbl-scroll"><table class="inv-list-table"><thead><tr>
        ${invTh('invoice_number','#')}${invTh('contact_name','Customer')}
        ${invTh('invoice_date','Date')}${invTh('due_date','Due')}
        ${invTh('total','Total','r')}${invTh('amount_paid','Paid','r')}
        <th>Balance</th>${invTh('status','Status')}
      </tr></thead><tbody>${rows.map(invRow).join('')}</tbody></table></div>`;
  const mc=document.getElementById('module-content');
  mc.innerHTML=`
    <div class="inv-toolbar">
      <input class="inv-search" id="inv-q" placeholder="Search number, customer\u2026" value="${esc(_invSearch)}">
      <div class="inv-filter-group">
        ${INV_STATS.map(s=>`<button class="filter-btn${_invFilter===s?' active':''}" onclick="invFilter('${s}')">
          ${s}${counts[s]?` <span class="filter-count">(${counts[s]})</span>`:''}</button>`).join('')}
      </div>
      <button class="btn btn-primary" onclick="invNew()">+ New Invoice</button>
      <button class="btn btn-outline" onclick="_invFromTemplate()">From Template</button>
      <button class="btn btn-outline" onclick="invBulkOverdue()">📧 Bulk Notices</button>
    </div>
    <div class="inv-list-panel">${panelHtml}</div>
    <div class="mt-8"><span class="count-pill">${rows.length} of ${_invAll.length} invoice${_invAll.length!==1?'s':''}</span></div>`;
  const q=document.getElementById('inv-q');
  if(q){
    q.addEventListener('input',e=>{_invSearch=e.target.value;renderInvoicesPage(true);});
    if(restoreFocus){q.focus();q.setSelectionRange(q.value.length,q.value.length);}
  }
}

function invTh(col,label,align) {
  const sortCls=_invSort.col===col?(_invSort.dir>0?'sort-asc':'sort-desc'):'';
  const cls=[sortCls,align==='r'?'th-r':''].filter(Boolean).join(' ');
  return `<th class="${cls}" onclick="invSort('${col}')">${label}</th>`;
}

function invRow(inv) {
  const bal=(inv.total||0)-(inv.amount_paid||0),eff=_effSt(inv);
  const rc=eff==='Void'?'is-void':eff==='Paid'?'is-paid':eff==='Overdue'?'is-overdue':'';
  return `<tr class="inv-row ${rc}" onclick="invOpen(${inv.id})">
    <td><span class="inv-mono">${esc(inv.invoice_number||'#'+inv.id)}</span></td>
    <td><span class="inv-contact">${esc(inv.contact_name||'\u2014')}</span></td>
    <td><span class="inv-mono">${fmtDate(inv.invoice_date)}</span></td>
    <td><span class="inv-mono">${fmtDate(inv.due_date)}${eff==='Overdue'?' <span class="overdue-tag">OVERDUE</span>':''}</span></td>
    <td class="inv-amt">${fmt(inv.total)}</td>
    <td class="inv-amt inv-amt-paid">${(inv.amount_paid||0)>0?fmt(inv.amount_paid):'\u2014'}</td>
    <td class="inv-amt ${bal>0.005?'inv-amt-amber':'inv-amt-green'}">${fmt(bal)}</td>
    <td><span class="badge ${INV_BADGE[eff]||'badge-draft'}">${eff}</span></td>
  </tr>`;
}

function invSort(col){_invSort={col,dir:_invSort.col===col?_invSort.dir*-1:1};renderInvoicesPage();}
function invFilter(f){_invFilter=f;renderInvoicesPage();}
async function invNew(opts={}){
  const td=isoToday();
  const due=isoAddDays(30);
  let defPmt='';
  try{const co=await apiFetch('/api/company');defPmt=co.default_payment_instructions||'';}catch(e){}
  const blank={invoice:{id:null,contact_id:opts.contact_id||null,opp_id:opts.opp_id||null,invoice_date:td,due_date:due,status:'Draft',
    invoice_number:'',notes:'',payment_instructions:defPmt,internal_comments:'',subtotal:0,gst_total:0,total:0,amount_paid:0},lines:[]};
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent='New Invoice';
  document.getElementById('det-body').innerHTML='<div class="state-loading">Loading\u2026</div>';
  document.getElementById('det-foot').innerHTML='';
  await invEditOpen(blank);
}

async function invOpen(id) {
  _invSelected=id;
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-body').innerHTML='<div class="state-loading">Loading\u2026</div>';
  document.getElementById('det-foot').innerHTML='';
  document.getElementById('det-title').textContent='Invoice';
  try{const data=await apiFetch(`/api/invoices/${id}`);renderInvDetail(data);}
  catch(e){document.getElementById('det-body').innerHTML=`<div class="state-error">${esc(e.message)}</div>`;}
}

function renderInvDetail(data) {
  const inv=data.invoice,lines=data.lines||[],bal=(inv.total||0)-(inv.amount_paid||0),eff=_effSt(inv);
  const isCN=inv.is_credit_note===1||inv.is_credit_note===true;
  document.getElementById('det-title').textContent=isCN?`Credit Note ${inv.invoice_number||'#'+inv.id}`:`Invoice ${inv.invoice_number||'#'+inv.id}`;
  const TABS=isCN
    ?[['lines','\uD83D\uDCCB Lines'],['comments','\uD83D\uDD12 Comments'],['attachments','\uD83D\uDCCE Attachments']]
    :[['lines','\uD83D\uDCCB Lines'],['notes','\uD83D\uDCDD Notes'],['payment','\uD83C\uDFE6 Payment'],['comments','\uD83D\uDD12 Comments'],['attachments','\uD83D\uDCCE Attachments'],['activity','\uD83D\uDCEC Activity']];
  document.getElementById('det-body').innerHTML=`
    <div class="det-meta">
      <div><div class="det-lbl">Customer</div><div class="det-val">${esc(inv.contact_name||'\u2014')}</div></div>
      <div><div class="det-lbl">Status</div><div class="det-val"><span class="badge ${INV_BADGE[eff]||'badge-draft'}">${eff}</span></div></div>
      <div><div class="det-lbl">${isCN?'Credit Note Date':'Invoice Date'}</div><div class="det-val mono">${fmtDate(inv.invoice_date)}</div></div>
      ${!isCN?`<div><div class="det-lbl">Due Date</div><div class="det-val mono">${fmtDate(inv.due_date)}${eff==='Overdue'?' <span class="overdue-tag overdue-tag-lg">OVERDUE</span>':''}</div></div>`:''}
      ${isCN&&inv.source_invoice_number?`<div><div class="det-lbl">Credits Invoice</div><div class="det-val"><span class="lnk-accent" style="cursor:pointer" onclick="invOpen(${inv.source_invoice_id})">${esc(inv.source_invoice_number)}</span></div></div>`:''}
      <div><div class="det-lbl">${isCN?'Credit Amount':'Total'}</div><div class="det-val mono det-val-lg det-val-accent">${fmt(inv.total)}</div></div>
      ${isCN?(()=>{const applied=parseFloat(inv.amount_applied||0);const remaining=Math.round((inv.total-applied)*100)/100;return remaining>0.005?`<div><div class="det-lbl">Remaining Credit</div><div class="det-val mono det-val-lg" style="color:var(--green)">${fmt(remaining)}</div></div>`:`<div><div class="det-lbl">Status</div><div class="det-val"><span class="badge badge-paid">Fully Applied</span></div></div>`;})():''}
      ${!isCN?`<div><div class="det-lbl">Balance</div><div class="det-val mono det-val-lg ${bal>0.005?'det-val-bal-amber':'det-val-bal-green'}">${fmt(bal)}</div></div>`:''}
      ${inv.job_name?`<div><div class="det-lbl">Job / Project</div><div class="det-val"><span class="lnk-accent" style="cursor:pointer" onclick="navigate('jobs')">${esc(inv.job_name)}</span></div></div>`:''}
    </div>
    <div class="det-tabs">${TABS.map(([k,l],i)=>`<div class="det-tab${i===0?' active':''}" data-tab="${k}" onclick="invTab('${k}')">${l}</div>`).join('')}</div>
    <div class="det-pane active" id="invt-lines">
      <table class="det-lines"><thead><tr><th>Description</th><th>Qty</th>
        <th class="th-r">Unit</th><th class="th-r">GST</th><th class="th-r">Total</th>
      </tr></thead><tbody>${lines.length?lines.map(l=>{
        if (l.line_type==='comment') {
          return `<tr class="inv-comment-row"><td colspan="5">${esc(l.description)}</td></tr>`;
        }
        const q=parseFloat(l.quantity)||0,p=parseFloat(l.unit_price)||0;
        const rate=(l.tax_code==='GST'||l.tax_code==='CAP')?0.1:0,gst=Math.round(q*p*rate*100)/100;
        return `<tr><td>${esc(l.description)}<span class="line-tax-code">${l.tax_code||'GST'}</span>${l.account_name?`<span class="line-acct-name">${esc(l.account_name)}</span>`:''}</td>
          <td class="td-c-mono">${q}</td>
          <td class="td-r-mono">${fmt(p)}</td>
          <td class="td-r-mono">${fmt(gst)}</td>
          <td class="td-r-mono-bold">${fmt(q*p+gst)}</td></tr>`;
      }).join(''):`<tr class="tbl-empty-sm"><td colspan="5">No line items</td></tr>`}
      </tbody></table>
      <div class="det-totals">
        <div class="det-tot-row"><span>Subtotal (ex GST)</span><span>${fmt(inv.subtotal)}</span></div>
        <div class="det-tot-row"><span>GST (10%)</span><span>${fmt(inv.gst_total)}</span></div>
        ${(!isCN&&(inv.amount_paid||0)>0)?`<div class="det-tot-row paid"><span>Paid</span><span>${fmt(inv.amount_paid)}</span></div>`:''}
        ${(()=>{const cns=inv.credit_notes||[];const ct=cns.reduce((s,cn)=>s+parseFloat(cn.total||0),0);return(!isCN&&ct>0)?`<div class="det-tot-row paid"><span>Credits Applied</span><span>−${fmt(ct)}</span></div>`:''})()}
        <div class="det-tot-row grand"><span>${isCN?'Credit Total':'Total'}</span><span>${fmt(inv.total)}</span></div>
      </div>
      ${(()=>{const cns=inv.credit_notes||[];return cns.length?`<div class="cn-applied-section"><div class="cn-applied-hdr">Credits Applied</div>${cns.map(cn=>`<div class="cn-applied-row"><span class="lnk-accent" style="cursor:pointer" onclick="invOpen(${cn.id})">${esc(cn.invoice_number)}</span><span class="mono" style="color:var(--ink2)">${fmtDate(cn.invoice_date)}</span><span class="mono" style="color:var(--green)">−${fmt(cn.total)}</span></div>`).join('')}</div>`:''})()}
    </div>
    ${!isCN?`<div class="det-pane" id="invt-notes">${inv.notes?`<div class="det-note">${esc(inv.notes)}</div>`:`<div class="det-empty">No customer notes.</div>`}</div>`:''}
    ${!isCN?`<div class="det-pane" id="invt-payment">${inv.payment_instructions?`<div class="det-note">${esc(inv.payment_instructions)}</div>`:`<div class="det-empty">No payment instructions.</div>`}</div>`:''}
    <div class="det-pane" id="invt-comments">${isCN&&inv.notes?`<div class="det-note">${esc(inv.notes)}</div>`:inv.internal_comments?`<div class="det-note">${esc(inv.internal_comments)}</div>`:`<div class="det-empty">${isCN?'No memo.':'No internal comments.'}</div>`}</div>
    <div class="det-pane" id="invt-attachments"><div class="det-empty det-loading-pad">Loading…</div></div>
    ${!isCN?`<div class="det-pane" id="invt-activity"><div class="det-empty det-loading-pad">Loading…</div></div>`:''}`;

  const foot=document.getElementById('det-foot'); foot.innerHTML='';
  const addBtn=(label,cls,fn)=>{const b=document.createElement('button');b.className=`btn ${cls}`;b.textContent=label;b.onclick=fn;foot.appendChild(b);};
  if(isCN) {
    if(inv.source_invoice_id) addBtn('\u2190 View Original Invoice','btn-outline',()=>invOpen(inv.source_invoice_id));
    addBtn('\ud83d\udce7 Email Credit Note','btn-outline',()=>invCNEmailOpen(inv));
    addBtn('\u2399 Download PDF','btn-outline',()=>window.open(`/api/invoices/${inv.id}/pdf`));
  } else {
    if(['Draft','Approved','Sent'].includes(inv.status))     addBtn('\u270F\uFE0F Edit','btn-outline',()=>invEditOpen(data));
    if(!['Void','Paid','Draft','Approved','Written Off'].includes(inv.status)&&bal>0.005) addBtn('\ud83d\uDCB0 Record Payment','btn-green',()=>payModalOpen(inv));
    if(!['Void','Paid','Draft','Approved','Written Off'].includes(inv.status)&&bal>0.005) addBtn('Pay via Terminal','btn-secondary',()=>_invTerminalPay(inv));
    if(inv.status==='Draft')                                 addBtn('\u2713 Approve','btn-secondary',()=>invApprove(inv.id));
    if(['Draft','Approved'].includes(inv.status))            addBtn('\u2709 Mark Sent','btn-outline',()=>invMarkSent(inv.id));
    if(!['Void','Draft','Approved','Written Off','Credit Note'].includes(inv.status))
                                                             addBtn('Issue Credit Note','btn-outline',()=>invCreditNoteOpen(inv,lines));
    if(!['Void','Draft','Approved','Written Off','Credit Note'].includes(inv.status)&&bal>0.005)
                                                             addBtn('Apply Credit','btn-outline',()=>invApplyCreditOpen(inv));
    if(!['Void','Paid','Written Off'].includes(inv.status))  addBtn('Void','btn-danger',()=>invVoid(inv.id));
    if(!['Draft','Approved','Void','Paid','Written Off'].includes(inv.status)&&bal>0.005) addBtn('Write Off','btn-danger',()=>invWriteOffOpen(inv));
    addBtn('\ud83d\udce7 Email','btn-outline',()=>invEmailOpen(inv));
    if(eff==='Overdue') addBtn('\u26A0 Overdue Notice','btn-amber',()=>invOverdueOpen(inv));
    if(eff==='Overdue'||inv.overdue_suppress) {
      const suppressLabel = inv.overdue_suppress ? '\u2713 Show stamp' : '\ud83d\uDEAB Suppress stamp';
      addBtn(suppressLabel,'btn-outline',()=>invToggleSuppress(inv));
    }
    addBtn('\u2399 Download PDF','btn-outline',()=>window.open(`/api/invoices/${inv.id}/pdf`));
    addBtn('\u29c9 Copy','btn-outline',()=>invCopy(inv.id));
    addBtn('+ New Invoice','btn-outline',invNew);
  }
}

function invTab(key){
  document.querySelectorAll('.det-tab').forEach(t=>t.classList.toggle('active',t.dataset.tab===key));
  document.querySelectorAll('.det-pane').forEach(p=>p.classList.toggle('active',p.id===`invt-${key}`));
  if(key==='attachments'&&_invSelected&&(!_attLoadedFor||_attLoadedFor.type!=='invoice'||_attLoadedFor.id!==_invSelected)){
    _attLoad('invt-attachments','invoice',_invSelected);
  }
  if(key==='activity'&&_invSelected) _invLoadActivity(_invSelected);
}

async function _invLoadActivity(id) {
  const el=document.getElementById('invt-activity');
  if(!el) return;
  try {
    const rows=await apiFetch(`/api/invoices/${id}/activity`);
    if(!rows||!rows.length){el.innerHTML='<div class="det-empty">No activity yet — emails sent will appear here.</div>';return;}
    el.innerHTML=`<div class="inv-activity">${rows.map(r=>`
      <div class="inv-act-row">
        <span class="inv-act-date">${fmtDate(r.logged_at?.slice(0,10)||r.comm_date)}</span>
        <span class="inv-act-type">${esc(r.comm_type||'Email')}</span>
        <span class="inv-act-txt">${esc(r.subject||'(no subject)')}</span>
      </div>`).join('')}</div>`;
  } catch(e){el.innerHTML=`<div class="state-error">${esc(e.message)}</div>`;}
}
function detClose(){document.getElementById('det-overlay').classList.remove('open');document.getElementById('det-panel').classList.remove('open');_invSelected=null;_billSelected=null;_conSelected=null;_acctSelected=null;_pmtSelected=null;_recSelected=null;if(typeof _jobSelectedId!=="undefined")_jobSelectedId=null;if(typeof _qSelected!=="undefined")_qSelected=null;if(typeof _awCurrent!=="undefined")_awCurrent=null;}

async function invMarkSent(id){
  try{const r=await fetch(`/api/invoices/${id}/mark-sent`,{method:'POST',credentials:'include'});const j=await r.json();if(!j.ok)throw new Error(j.error);toast('Marked as Sent');await _invRefresh(id);}
  catch(e){toast(e.message,'err');}
}
async function invApprove(id){
  try{const r=await fetch(`/api/invoices/${id}/approve`,{method:'POST',credentials:'include'});const j=await r.json();if(!j.ok)throw new Error(j.error);toast('Invoice approved');await _invRefresh(id);}
  catch(e){toast(e.message,'err');}
}
async function invCopy(id) {
  try {
    const r = await fetch(`/api/invoices/${id}/copy`, {method:'POST', credentials:'include'});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Copy failed');
    toast('Copied as new draft invoice');
    _invAll = (await apiFetch('/api/invoices')) || [];
    renderInvoicesPage();
    invOpen(j.data.id);
  } catch(e) { toast(e.message, 'err'); }
}

async function invVoid(id){
  if(!await confirmDlg('Void this invoice? This reverses the journal entries and cannot be undone.')) return;
  try{const r=await fetch(`/api/invoices/${id}/void`,{method:'POST',credentials:'include'});const j=await r.json();if(!j.ok)throw new Error(j.error);toast('Invoice voided');detClose();_invAll=(await apiFetch('/api/invoices'))||[];renderInvoicesPage();}
  catch(e){toast(e.message,'err');}
}
async function _invRefresh(id){
  _invAll=(await apiFetch('/api/invoices'))||[];renderInvoicesPage();
  if(_invSelected===id){try{renderInvDetail(await apiFetch(`/api/invoices/${id}`));}catch(e){}}
}

async function invEmailOpen(inv) {
  const num=inv.invoice_number||('#'+inv.id);
  const bd=document.createElement('div');
  bd.className='modal-bd'; bd.style.display='flex';
  bd.innerHTML=`<div class="modal-box" style="width:min(560px,96vw)">
    <div class="modal-title">Email Invoice ${esc(num)}</div>
    <div class="modal-field"><label class="modal-lbl">To *</label>
      <input class="modal-inp" type="email" id="eml-to" placeholder="recipient@example.com"></div>
    <div class="modal-field"><label class="modal-lbl">Subject</label>
      <input class="modal-inp" type="text" id="eml-subj" value="${esc('Invoice '+num)}"></div>
    <div class="modal-field"><label class="modal-lbl">Message</label>
      <textarea class="modal-inp" id="eml-body" rows="5" style="resize:vertical;min-height:90px"></textarea></div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary btn-sm" id="eml-send-btn" onclick="_invDoEmail(${inv.id})">📧 Send</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  try {
    const [contact, settings]=await Promise.all([
      apiFetch(`/api/contacts/${inv.contact_id}`),
      apiFetch('/api/settings/email'),
    ]);
    if(contact?.email) document.getElementById('eml-to').value=contact.email;
    const sub=(settings?.invoice_subject||'Invoice {invoice_number} from {company_name}')
      .replace('{invoice_number}',num).replace('{customer}',inv.contact_name||'');
    const bdy=(settings?.invoice_body||`Please find attached invoice ${num}.\n\nThank you.`)
      .replace('{invoice_number}',num).replace('{total}',fmt(inv.total))
      .replace('{due_date}',inv.due_date||'').replace('{customer}',inv.contact_name||'');
    const subjEl=document.getElementById('eml-subj');
    const bodyEl=document.getElementById('eml-body');
    if(subjEl) subjEl.value=sub;
    if(bodyEl) bodyEl.value=bdy;
  } catch(e){}
}

async function _invDoEmail(id) {
  const to=(document.getElementById('eml-to')?.value||'').trim();
  if(!to){toast('Recipient email is required','err');return;}
  const btn=document.getElementById('eml-send-btn');
  btn.disabled=true; btn.textContent='Sending…';
  try {
    const r=await fetch(`/api/invoices/${id}/email`,{method:'POST',credentials:'include',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({to,subject:document.getElementById('eml-subj')?.value||'',
        body:document.getElementById('eml-body')?.value||''})});
    const j=await r.json();
    if(!j.ok) throw new Error(j.error||'Send failed');
    btn.closest('.modal-bd')?.remove();
    toast('Invoice emailed');
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent='📧 Send';
  }
}

async function invOverdueOpen(inv) {
  const num=inv.invoice_number||('#'+inv.id);
  const bd=document.createElement('div');
  bd.className='modal-bd'; bd.style.display='flex';
  bd.innerHTML=`<div class="modal-box" style="width:min(560px,96vw)">
    <div class="modal-title">⚠ Overdue Notice — ${esc(num)}</div>
    <div class="modal-field"><label class="modal-lbl">To *</label>
      <input class="modal-inp" type="email" id="od-to" placeholder="recipient@example.com"></div>
    <div class="modal-field"><label class="modal-lbl">Subject</label>
      <input class="modal-inp" type="text" id="od-subj"></div>
    <div class="modal-field"><label class="modal-lbl">Message</label>
      <textarea class="modal-inp" id="od-body" rows="6" style="resize:vertical;min-height:100px"></textarea></div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-amber btn-sm" id="od-send-btn" onclick="_invDoOverdue(${inv.id})">⚠ Send Notice</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  try {
    const [contact, settings]=await Promise.all([
      apiFetch(`/api/contacts/${inv.contact_id}`),
      apiFetch('/api/settings/email'),
    ]);
    if(contact?.email) document.getElementById('od-to').value=contact.email;
    const today=isoToday(),due=inv.due_date||today;
    const days=Math.max(0,Math.round((new Date(today)-new Date(due))/(1000*86400)));
    const sub=(settings?.overdue_subject||'Overdue invoice {invoice_number} — {company_name}')
      .replace('{invoice_number}',num).replace('{company_name}','');
    const bdy=(settings?.overdue_body||`Dear ${inv.contact_name||''},\n\nThis is a reminder that invoice ${num} for ${fmt(inv.total)} was due on ${inv.due_date||''} and remains unpaid.\n\nPlease arrange payment at your earliest convenience.`)
      .replace('{invoice_number}',num).replace('{customer}',inv.contact_name||'')
      .replace('{total}',fmt(inv.total)).replace('{due_date}',inv.due_date||'')
      .replace('{days_overdue}',String(days));
    const subjEl=document.getElementById('od-subj');
    const bodyEl=document.getElementById('od-body');
    if(subjEl) subjEl.value=sub;
    if(bodyEl) bodyEl.value=bdy;
  } catch(e){}
}

async function _invDoOverdue(id) {
  const to=(document.getElementById('od-to')?.value||'').trim();
  if(!to){toast('Recipient email is required','err');return;}
  const btn=document.getElementById('od-send-btn');
  btn.disabled=true; btn.textContent='Sending…';
  try {
    const r=await fetch(`/api/invoices/${id}/overdue-notice`,{method:'POST',credentials:'include',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({to,subject:document.getElementById('od-subj')?.value||'',
        body:document.getElementById('od-body')?.value||''})});
    const j=await r.json();
    if(!j.ok) throw new Error(j.error||'Send failed');
    btn.closest('.modal-bd')?.remove();
    toast('Overdue notice sent');
    await _invRefresh(id);
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent='⚠ Send Notice';
  }
}

async function invToggleSuppress(inv) {
  const newSuppress = inv.overdue_suppress ? 0 : 1;
  const label = newSuppress ? 'suppress' : 'restore';
  if(!await confirmDlg(`This will ${label} the OVERDUE stamp on the PDF for this invoice. Continue?`)) return;
  try {
    const r=await fetch(`/api/invoices/${inv.id}/suppress-stamp`,{method:'POST',credentials:'include',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({suppress:newSuppress})});
    const j=await r.json();
    if(!j.ok) throw new Error(j.error);
    toast(newSuppress ? 'OVERDUE stamp suppressed' : 'OVERDUE stamp restored');
    await _invRefresh(inv.id);
  } catch(e){toast(e.message,'err');}
}

// ── Bulk Overdue Notices ──────────────────────────────────────────────────

async function invBulkOverdue() {
  const overdue = _invAll.filter(inv => _effSt(inv) === 'Overdue');
  if (!overdue.length) {
    toast('No overdue invoices found', 'err');
    return;
  }

  // Load contacts to get email addresses
  let contactMap = {};
  try {
    const contacts = await apiFetch('/api/contacts');
    (contacts || []).forEach(c => { contactMap[c.id] = c; });
  } catch(e) {}

  const targets = overdue.map(inv => ({
    inv,
    email: contactMap[inv.contact_id]?.email || '',
  })).filter(t => t.email);

  const noEmail = overdue.length - targets.length;

  if (!targets.length) {
    toast('No overdue invoices have a contact email address', 'err');
    return;
  }

  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:min(600px,96vw);display:flex;flex-direction:column;max-height:90vh">
    <div class="modal-title">📧 Bulk Overdue Notices</div>
    ${noEmail ? `<div class="bulk-warn">${noEmail} overdue invoice${noEmail!==1?'s':''} skipped — no contact email.</div>` : ''}
    <div class="bulk-sel-hdr">
      <span id="bovd-count">${targets.length} of ${targets.length} selected</span>
      <span>
        <button class="btn-link" onclick="_bovdToggleAll(true)">Select all</button>
        &nbsp;·&nbsp;
        <button class="btn-link" onclick="_bovdToggleAll(false)">Deselect all</button>
      </span>
    </div>
    <div style="overflow-y:auto;flex:1;max-height:300px;border:1px solid var(--border);border-radius:6px">
      ${targets.map(({inv, email}) => `
        <label class="bulk-row">
          <input type="checkbox" class="bovd-chk" data-iid="${inv.id}" data-email="${esc(email)}" data-name="${esc(inv.contact_name||'')}" checked>
          <span class="bulk-row-name">${esc(inv.contact_name||'—')}</span>
          <span class="bulk-row-meta">${esc(inv.invoice_number)} · ${fmt(inv.total)} · due ${fmtDate(inv.due_date)}</span>
          <span class="bulk-row-email">${esc(email)}</span>
        </label>`).join('')}
    </div>
    <div id="bovd-progress" style="display:none;padding:8px 0;font-size:13px;color:var(--ink3)"></div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" id="bovd-cancel" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-amber btn-sm" id="bovd-send-btn" onclick="_bovdSend()">⚠ Send Notices</button>
    </div>
  </div>`;
  document.body.appendChild(bd);

  bd.addEventListener('change', () => {
    const sel = bd.querySelectorAll('.bovd-chk:checked').length;
    const el = document.getElementById('bovd-count');
    if (el) el.textContent = `${sel} of ${targets.length} selected`;
  });
}

function _bovdToggleAll(state) {
  document.querySelectorAll('.bovd-chk').forEach(cb => { cb.checked = state; });
  const total = document.querySelectorAll('.bovd-chk').length;
  const el = document.getElementById('bovd-count');
  if (el) el.textContent = `${state ? total : 0} of ${total} selected`;
}

async function _bovdSend() {
  const checked = [...document.querySelectorAll('.bovd-chk:checked')].map(cb => ({
    id:    parseInt(cb.dataset.iid),
    email: cb.dataset.email,
    name:  cb.dataset.name,
  }));
  if (!checked.length) { toast('No invoices selected', 'err'); return; }

  const btn      = document.getElementById('bovd-send-btn');
  const cancelBtn= document.getElementById('bovd-cancel');
  const progress = document.getElementById('bovd-progress');
  btn.disabled = cancelBtn.disabled = true;
  progress.style.display = 'block';

  let sent = 0, failed = 0, errors = [];
  for (let i = 0; i < checked.length; i++) {
    const {id, email, name} = checked[i];
    progress.textContent = `Sending ${i + 1} of ${checked.length}: ${name}…`;
    try {
      const r = await fetch(`/api/invoices/${id}/overdue-notice`, {
        method: 'POST', credentials: 'include',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({to: email}),
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Send failed');
      sent++;
    } catch(e) {
      failed++;
      errors.push(`${name}: ${e.message}`);
    }
  }

  if (!failed) {
    btn.closest('.modal-bd').remove();
    toast(`${sent} overdue notice${sent !== 1 ? 's' : ''} sent`);
    _invAll = (await apiFetch('/api/invoices')) || [];
    renderInvoicesPage();
  } else {
    progress.innerHTML = `<strong>${sent} sent, ${failed} failed:</strong><br>${errors.map(e => esc(e)).join('<br>')}`;
    btn.textContent = 'Close';
    btn.disabled = false;
    btn.onclick = () => btn.closest('.modal-bd').remove();
    cancelBtn.style.display = 'none';
  }
}

// ── Bad debt write-off ────────────────────────────────────────────────────

async function invWriteOffOpen(inv) {
  const num = inv.invoice_number || ('#' + inv.id);
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:min(520px,96vw)">
    <div class="modal-title">Write Off Bad Debt — ${esc(num)}</div>
    <div class="modal-field" id="wo-breakdown-wrap">
      <div class="wo-breakdown-loading" style="color:var(--ink3);font-size:13px">Loading…</div>
    </div>
    <div class="modal-field">
      <label class="modal-lbl">Write-off Account *</label>
      <select class="modal-inp" id="wo-acct"><option value="">Loading…</option></select>
    </div>
    <div class="modal-field">
      <label class="modal-lbl">Memo *</label>
      <input class="modal-inp" type="text" id="wo-memo" placeholder="e.g. Debt uncollectable — customer insolvent">
    </div>
    <div class="modal-field" style="display:flex;align-items:center;gap:9px">
      <input type="checkbox" id="wo-inactive" style="width:16px;height:16px;accent-color:var(--accent);cursor:pointer">
      <label for="wo-inactive" style="font-size:14px;font-weight:500;color:var(--ink);cursor:pointer">Mark contact as inactive</label>
    </div>
    <div class="modal-field" id="wo-reason-wrap" style="display:none">
      <label class="modal-lbl">Reason (optional)</label>
      <input class="modal-inp" type="text" id="wo-reason" placeholder="e.g. Customer insolvent">
    </div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-danger btn-sm" id="wo-confirm-btn" onclick="_invDoWriteOff(${inv.id})">Write Off Debt</button>
    </div>
  </div>`;
  document.body.appendChild(bd);

  document.getElementById('wo-inactive').addEventListener('change', function() {
    document.getElementById('wo-reason-wrap').style.display = this.checked ? '' : 'none';
  });

  try {
    const [preview, accts] = await Promise.all([
      apiFetch(`/api/invoices/${inv.id}/write-off`),
      apiFetch('/api/accounts'),
    ]);
    const expenseAccts = (accts || []).filter(a => ['Expense','Cost of Sales'].includes(a.account_type) && a.is_active !== 0);
    const sel = document.getElementById('wo-acct');
    sel.innerHTML = expenseAccts.map(a =>
      `<option value="${a.id}"${a.code === '5-3800' ? ' selected' : ''}>${esc(a.code + ' ' + a.name)}</option>`
    ).join('');
    const wrap = document.getElementById('wo-breakdown-wrap');
    wrap.innerHTML = `<div class="wo-breakdown">
      <div class="wo-breakdown-row"><span>Outstanding balance</span><span class="mono">${fmt(preview.outstanding)}</span></div>
      <div class="wo-breakdown-row wo-breakdown-sub"><span>Net (ex GST)</span><span class="mono">${fmt(preview.net_component)}</span></div>
      ${preview.gst_component > 0 ? `<div class="wo-breakdown-row wo-breakdown-sub"><span>GST decreasing adjustment</span><span class="mono">${fmt(preview.gst_component)}</span></div>` : ''}
    </div>`;
  } catch(e) {
    document.getElementById('wo-breakdown-wrap').innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
  }
}

async function _invDoWriteOff(id) {
  const acctId = parseInt(document.getElementById('wo-acct')?.value || '0');
  const memo   = (document.getElementById('wo-memo')?.value || '').trim();
  const markInactive = document.getElementById('wo-inactive')?.checked || false;
  const reason = (document.getElementById('wo-reason')?.value || '').trim();
  if (!acctId) { toast('Select a write-off account', 'err'); return; }
  if (!memo)   { toast('Memo is required', 'err'); return; }
  const btn = document.getElementById('wo-confirm-btn');
  btn.disabled = true; btn.textContent = 'Writing off…';
  try {
    const r = await fetch(`/api/invoices/${id}/write-off`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({write_off_account_id: acctId, memo,
        mark_contact_inactive: markInactive, inactive_reason: reason}),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Write-off failed');
    btn.closest('.modal-bd')?.remove();
    toast('Invoice written off');
    detClose();
    _invAll = (await apiFetch('/api/invoices')) || [];
    renderInvoicesPage();
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = 'Write Off Debt';
  }
}

// ── Invoice inline editor ─────────────────────────────────────────────────
let _editData = null;      // {invoice, lines} currently being edited
let _editLines = [];       // [{desc,qty,price,tax,gst,total,account_id}, ...]
let _editAccts = [];       // income/revenue accounts for the line account picker
let _editContacts = null;  // contact list cache (shared across edit sessions)
let _editJobs = null;      // jobs list cache
let _discType = 'amount';  // 'amount' or 'percent' — current edit session discount type
let _taskPickData = [];    // work tasks fetched for the picker modal

async function invEditOpen(data) {
  _editData  = data;
  _discType  = data.invoice.discount_type || 'amount';
  const _defTax = _invGSTReg ? 'GST' : 'INP';
  _editLines = (data.lines||[]).map(l=>({
    description: l.description||'', quantity: parseFloat(l.quantity)||1,
    unit_price:  parseFloat(l.unit_price)||0, tax_code: l.tax_code||_defTax,
    account_id:  l.account_id||null, item_id: l.item_id||null,
    line_type:   l.line_type||'item',
  }));
  if (_editLines.length===0) _editLines.push({description:'',quantity:1,unit_price:0,tax_code:_defTax,account_id:null,line_type:'item'});

  // Fetch contacts, accounts, and jobs if not already loaded
  try {
    const [contacts, accts, jobs] = await Promise.all([
      _editContacts ? Promise.resolve(_editContacts) : apiFetch('/api/contacts'),
      _editAccts.length  ? Promise.resolve(_editAccts)   : apiFetch('/api/accounts'),
      _editJobs     ? Promise.resolve(_editJobs)     : apiFetch('/api/jobs'),
    ]);
    _editContacts = contacts||[];
    _editAccts    = (accts||[]).filter(a=>['Revenue','Income','Other Income'].includes(a.account_type));
    if (_editAccts.length===0) _editAccts = (accts||[]).filter(a=>a.account_type);
    _editJobs = jobs||[];
  } catch(e) { toast('Could not load contacts/accounts: '+e.message,'err'); return; }

  invEditRender();
}

function invEditRender() {
  const inv = _editData.invoice;

  // Contact options
  const custOpts = (_editContacts||[])
    .filter(c=>c.contact_type==='Customer'||c.contact_type==='Both'||!c.contact_type)
    .map(c=>`<option value="${c.id}" ${c.id===inv.contact_id?'selected':''}>${esc(c.name)}</option>`)
    .join('');

  // Job options
  const jobOpts = (_editJobs||[]).map(j=>`<option value="${j.id}" ${j.id===inv.job_id?'selected':''}>${esc((j.job_number?j.job_number+'  ':'')+j.name)}</option>`).join('');

  // Line rows HTML
  const linesHtml = _editLines.map((l,i)=>_editLineHtml(i,l)).join('');

  // Totals preview
  const {sub,gst,total} = _editTotals();

  document.getElementById('det-body').innerHTML = `
    <div class="edt-section">
      <div class="edt-row">
        <div class="edt-field">
          <div class="lbl-line">
            <label class="edt-lbl">Customer *</label>
            <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();_invNewContact()">+ New</a>
          </div>
          <select class="edt-sel" id="edt-contact" onchange="invContactChanged()">${custOpts}</select>
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Status</label>
          <select class="edt-sel" id="edt-status">
            <option ${inv.status==='Draft'?'selected':''}>Draft</option>
            <option ${inv.status==='Sent'?'selected':''}>Sent</option>
          </select>
        </div>
      </div>
      <div class="edt-row">
        <div class="edt-field">
          <label class="edt-lbl">Invoice Date *</label>
          <input class="edt-inp" type="date" id="edt-date" value="${inv.invoice_date||''}">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Due Date *</label>
          <input class="edt-inp" type="date" id="edt-due" value="${inv.due_date||''}">
        </div>
      </div>
      ${jobOpts?`<div class="edt-row">
        <div class="edt-field full">
          <label class="edt-lbl">Job / Project</label>
          <select class="edt-sel" id="edt-job"><option value="">— None —</option>${jobOpts}</select>
        </div>
      </div>`:''}
    </div>

    <div class="edt-divider"></div>

    <div class="edt-section">
      <div class="edt-lines-hdr">
        <span></span><span></span><span>Description</span><span>Qty</span><span>Unit Price</span>
        <span>Tax</span><span class="span-r">GST</span>
        <span class="span-r">Total</span><span></span>
      </div>
      <div id="edt-lines-body">${linesHtml}</div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-outline edt-add-btn" onclick="editAddLine()">+ Add Line</button>
        <button class="btn btn-outline edt-add-btn" onclick="invAddTasksModal()">+ Add Tasks</button>
      </div>
      <div class="edt-discount-row">
        <span class="edt-lbl" style="margin:0">Discount</span>
        <div style="display:flex;gap:6px;align-items:center">
          <button class="btn btn-sm edt-disc-toggle" id="edt-disc-toggle" onclick="_invToggleDiscType()">${_discType==='percent'?'%':'$'}</button>
          <input type="number" class="edt-inp edt-disc-inp" id="edt-disc-val" min="0" step="0.01"
            value="${inv.discount_value||''}" placeholder="0" oninput="_editRefreshTotals()">
        </div>
      </div>
      <div class="edt-totals-preview" id="edt-totals">
        <span><span>Subtotal (ex GST)</span><b>${fmt(sub)}</b></span>
        <span><span>GST (10%)</span><b>${fmt(gst)}</b></span>
        <span class="grand"><span>Total</span><b>${fmt(total)}</b></span>
      </div>
    </div>

    <div class="edt-divider"></div>

    <div class="edt-section">
      <div class="edt-field edt-field-mb">
        <label class="edt-lbl">Customer Notes (printed on invoice)</label>
        <textarea class="edt-ta" id="edt-notes">${esc(inv.notes||'')}</textarea>
      </div>
      <div class="edt-field edt-field-mb">
        <label class="edt-lbl">Payment Instructions (printed on invoice)</label>
        <textarea class="edt-ta" id="edt-payment">${esc(inv.payment_instructions||'')}</textarea>
      </div>
      <div class="edt-field">
        <label class="edt-lbl">Internal Comments (not printed)</label>
        <textarea class="edt-ta" id="edt-comments">${esc(inv.internal_comments||'')}</textarea>
      </div>
    </div>

    <div class="edt-divider"></div>

    <div class="edt-section">
      <div class="edt-lbl" style="margin-bottom:8px">📎 Attachments</div>
      ${inv.id
        ? `<div id="edt-att-pane"></div>`
        : `<div class="det-empty" style="font-size:12px">Save the invoice first, then open it to add attachments.</div>`
      }
    </div>`;

  // Load attachments pane for existing invoices
  if (inv.id) {
    // Use setTimeout so the DOM is ready before we try to populate the pane
    setTimeout(() => _attLoad('edt-att-pane', 'invoice', inv.id), 0);
  }
  // Refresh totals after DOM is ready (ensures discount is reflected correctly)
  setTimeout(_editRefreshTotals, 0);

  // Swap footer buttons
  const foot = document.getElementById('det-foot');
  foot.innerHTML = '';
  const mk = (label,cls,fn)=>{const b=document.createElement('button');b.className=`btn ${cls}`;b.textContent=label;b.onclick=fn;foot.appendChild(b);};
  mk('Save Invoice','btn-primary',invEditSave);
  mk('Save as Template','btn-outline',_invSaveAsTemplate);
  mk('Cancel','btn-outline',()=>{
    if (_editData && _editData.invoice && _editData.invoice.id) invOpen(_editData.invoice.id);
    else detClose();
  });

  // Wire typeaheads on item lines; auto-size any comment textareas
  _editLines.forEach((l,i) => {
    if (!l || l.line_type === 'comment') {
      setTimeout(()=>{ const ta=document.getElementById(`edt-desc-${i}`); if(ta) _invTaResize(ta); }, 0);
    } else {
      _wireInvLineTypeahead(i);
    }
  });
}

async function invAddTasksModal() {
  const contactId = parseInt(document.getElementById('edt-contact').value);
  if (!contactId) { toast('Select a customer first', 'err'); return; }

  let tasks;
  try { tasks = await apiFetch(`/api/work-tasks/uninvoiced?contact_id=${contactId}`); }
  catch(e) { toast('Could not load tasks: ' + e.message, 'err'); return; }

  // Exclude tasks already added as lines in this edit session
  const addedIds = new Set((_editLines||[]).filter(l=>l&&l.task_id).map(l=>l.task_id));
  tasks = (tasks||[]).filter(t => !addedIds.has(t.id));

  if (!tasks.length) { toast('No completed, uninvoiced tasks for this customer'); return; }
  _taskPickData = tasks;

  document.getElementById('task-pick-modal')?.remove();
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'task-pick-modal';
  bd.innerHTML = `<div class="modal-box modal-sm" style="display:flex;flex-direction:column;max-height:80vh">
    <div class="modal-hdr">
      <span>Add Completed Tasks</span>
      <button class="det-close" onclick="document.getElementById('task-pick-modal').remove()">✕</button>
    </div>
    <div class="modal-body" style="overflow-y:auto;padding:0">
      <table class="inv-list-table" style="width:100%">
        <thead><tr>
          <th style="width:36px;padding-left:16px">
            <input type="checkbox" id="task-pick-all"
              onchange="document.querySelectorAll('.task-pick-cb').forEach(c=>c.checked=this.checked)">
          </th>
          <th>Task</th><th class="th-r">Qty</th><th class="th-r">Rate</th><th class="th-r">Total</th>
        </tr></thead>
        <tbody>
          ${tasks.map(t => {
            const total = (t.qty||1) * (t.unit_price||0);
            return `<tr>
              <td style="padding-left:16px"><input type="checkbox" class="task-pick-cb" value="${t.id}"></td>
              <td>${esc(t.title)}${t.description ? `<br><span class="ink3" style="font-size:11px">${esc(t.description)}</span>` : ''}</td>
              <td class="inv-amt">${t.qty||1}</td>
              <td class="inv-amt">${fmt(t.unit_price||0)}</td>
              <td class="inv-amt">${fmt(total)}</td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>
    <div class="modal-foot">
      <button class="btn btn-primary" onclick="invAddTasksConfirm()">Add Selected</button>
      <button class="btn btn-outline" onclick="document.getElementById('task-pick-modal').remove()">Cancel</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

function invAddTasksConfirm() {
  const checked = [...document.querySelectorAll('.task-pick-cb:checked')].map(c => parseInt(c.value));
  if (!checked.length) { toast('Select at least one task', 'err'); return; }

  const defTax = _invGSTReg ? 'GST' : 'INP';
  checked.forEach(tid => {
    const task = _taskPickData.find(t => t.id === tid);
    if (!task) return;
    _editLines.push({
      description: task.title,
      quantity:    task.qty || 1,
      unit_price:  task.unit_price || 0,
      tax_code:    defTax,
      account_id:  null,
      item_id:     null,
      line_type:   'item',
      task_id:     task.id,
    });
  });

  document.getElementById('task-pick-modal').remove();
  _invRenderAllLines();
  toast(`${checked.length} task${checked.length > 1 ? 's' : ''} added`);
}

function _wireInvLineTypeahead(i) {
  const inp = document.getElementById(`edt-desc-${i}`);
  if (!inp || inp.dataset.taWired) return;
  inp.dataset.taWired = '1';
  _attachTypeahead(inp, item => {
    _editLines[i].description = item.description || item.name;
    _editLines[i].unit_price  = item.unit_price || 0;
    _editLines[i].tax_code    = item.tax_code || 'GST';
    _editLines[i].account_id  = item.account_id || null;
    _editLines[i].item_id     = item.id;
    // Push values back to DOM
    const row = document.getElementById(`edt-line-${i}`);
    if (row) {
      const inputs = row.querySelectorAll('input[type="number"]');
      if (inputs[1]) inputs[1].value = item.unit_price || 0;
      const taxSel = row.querySelector('.edt-line-row select');
      if (taxSel) taxSel.value = item.tax_code || 'GST';
      const acctSel = document.getElementById(`edt-acct-${i}`);
      if (acctSel && item.account_id) acctSel.value = item.account_id;
    }
    editLineSet(i, 'unit_price', item.unit_price || 0);
    _checkStock(item.id, _editLines[i].quantity || 1, `edt-stock-${i}`);
  });
}

function _editLineHtml(i, l) {
  const isComment = l.line_type === 'comment';
  const toggleBtn = `<button class="edt-type-btn${isComment?' is-comment':''}" title="${isComment?'Switch to item line':'Switch to comment line'}" onclick="editToggleLineType(${i})">${isComment?'T':'≡'}</button>`;
  const _dndAttrs = `draggable="true" ondragstart="invLineDragStart(event,${i})" ondragover="invLineDragOver(event,${i})" ondrop="invLineDrop(event,${i})" ondragend="invLineDragEnd(event)"`;
  if (isComment) {
    return `<div class="edt-line-wrap" id="edt-line-${i}" ${_dndAttrs}>
    <div class="edt-line-row edt-comment-row">
      <span class="edt-drag-handle" title="Drag to reorder">⠿</span>
      ${toggleBtn}
      <textarea class="edt-inp edt-comment-ta" id="edt-desc-${i}"
        placeholder="Comment or heading…"
        oninput="editLineSet(${i},'description',this.value);_invTaResize(this)">${esc(l.description)}</textarea>
      <button class="edt-rm-btn" onclick="editRemoveLine(${i})" title="Remove">✕</button>
    </div>
  </div>`;
  }
  const q=l.quantity||1, p=l.unit_price||0;
  const rate=(l.tax_code==='GST'||l.tax_code==='CAP')?0.1:0;
  const gst=Math.round(q*p*rate*100)/100, total=q*p+gst;
  const acctOpts=_editAccts.map(a=>`<option value="${a.id}"${a.id===l.account_id?' selected':''}>${esc((a.code?a.code+' ':'')+a.name)}</option>`).join('');
  return `<div class="edt-line-wrap" id="edt-line-${i}" ${_dndAttrs}>
    <div class="edt-line-row">
      <span class="edt-drag-handle" title="Drag to reorder">⠿</span>
      ${toggleBtn}
      <input class="edt-inp" type="text" placeholder="Description or search catalogue…"
        id="edt-desc-${i}" value="${esc(l.description)}" oninput="editLineSet(${i},'description',this.value)">
      <input class="edt-inp" type="number" min="0" step="any" value="${q}"
        oninput="editLineSet(${i},'quantity',+this.value);_checkStock(_editLines[${i}]&&_editLines[${i}].item_id,+this.value,'edt-stock-${i}')">
      <input class="edt-inp" type="number" min="0" step="0.01" value="${p}"
        oninput="editLineSet(${i},'unit_price',+this.value)">
      <select class="edt-sel" onchange="editLineSet(${i},'tax_code',this.value)">
        ${['GST','FRE','INP','N-T','CAP'].map(t=>`<option${l.tax_code===t?' selected':''}>${t}</option>`).join('')}
      </select>
      <div class="edt-calc" id="edt-gst-${i}">${fmt(gst)}</div>
      <div class="edt-calc edt-calc-total" id="edt-tot-${i}">${fmt(total)}</div>
      <button class="edt-rm-btn" onclick="editRemoveLine(${i})" title="Remove">✕</button>
    </div>
    <div class="edt-line-acct">
      <span class="edt-acct-lbl">Account</span>
      <select class="edt-sel edt-acct-sel" id="edt-acct-${i}" onchange="editLineSet(${i},'account_id',this.value?+this.value:null)">
        <option value="">— default (Sales) —</option>${acctOpts}
      </select>
    </div>
    <div class="ta-stock-warn ta-stock-warn-row" id="edt-stock-${i}"></div>
  </div>`;
}

let _invDragSrc = null;
function invLineDragStart(e, i) {
  _invDragSrc = i;
  e.dataTransfer.effectAllowed = 'move';
  e.dataTransfer.setData('text/plain', String(i));
  setTimeout(() => { document.getElementById(`edt-line-${i}`)?.classList.add('is-dragging'); }, 0);
}
function invLineDragOver(e, i) {
  if (_invDragSrc === null || _invDragSrc === i) return;
  e.preventDefault();
  document.querySelectorAll('#edt-lines-body .edt-line-wrap').forEach(el => el.classList.remove('drag-over-top'));
  document.getElementById(`edt-line-${i}`)?.classList.add('drag-over-top');
}
function invLineDrop(e, i) {
  e.preventDefault();
  if (_invDragSrc === null || _invDragSrc === i) return;
  const active = _editLines.map((l, idx) => ({l, idx})).filter(x => x.l !== null);
  const srcPos = active.findIndex(x => x.idx === _invDragSrc);
  const dstPos = active.findIndex(x => x.idx === i);
  if (srcPos < 0 || dstPos < 0) return;
  const [moved] = active.splice(srcPos, 1);
  active.splice(dstPos, 0, moved);
  _editLines = active.map(x => x.l);
  _invDragSrc = null;
  _invRenderAllLines();
}
function invLineDragEnd(e) {
  _invDragSrc = null;
  document.querySelectorAll('#edt-lines-body .edt-line-wrap').forEach(el => {
    el.classList.remove('is-dragging', 'drag-over-top');
  });
}
function _invRenderAllLines() {
  const body = document.getElementById('edt-lines-body');
  if (!body) return;
  body.innerHTML = _editLines.map((l, i) => _editLineHtml(i, l)).join('');
  _editLines.forEach((l, i) => { if (l && l.line_type !== 'comment') _wireInvLineTypeahead(i); });
  _editRefreshTotals();
}

function editLineSet(i, field, val) {
  _editLines[i][field] = val;
  const l = _editLines[i];
  if (l.line_type === 'comment') { _editRefreshTotals(); return; }
  const q=l.quantity||0, p=l.unit_price||0;
  const rate=(l.tax_code==='GST'||l.tax_code==='CAP')?0.1:0;
  const gst=Math.round(q*p*rate*100)/100, total=q*p+gst;
  const gstEl=document.getElementById(`edt-gst-${i}`);
  const totEl=document.getElementById(`edt-tot-${i}`);
  if(gstEl) gstEl.textContent=fmt(gst);
  if(totEl) totEl.textContent=fmt(total);
  _editRefreshTotals();
}

function editToggleLineType(i) {
  const l = _editLines[i];
  l.line_type = (l.line_type === 'comment') ? 'item' : 'comment';
  if (l.line_type === 'comment') {
    l.quantity = 0; l.unit_price = 0; l.account_id = null; l.item_id = null;
  } else {
    l.quantity = 1; l.unit_price = 0; l.tax_code = _invGSTReg ? 'GST' : 'INP';
  }
  const wrap = document.getElementById(`edt-line-${i}`);
  if (wrap) {
    const tmp = document.createElement('div');
    tmp.innerHTML = _editLineHtml(i, l);
    wrap.replaceWith(tmp.firstElementChild);
    if (l.line_type === 'item') _wireInvLineTypeahead(i);
    else setTimeout(()=>{ const ta=document.getElementById(`edt-desc-${i}`); if(ta){ta.focus();_invTaResize(ta);} }, 0);
  }
  _editRefreshTotals();
}

function _invTaResize(el) {
  el.style.height = 'auto';
  el.style.height = el.scrollHeight + 'px';
}

function editAddLine() {
  const i = _editLines.length;
  _editLines.push({description:'',quantity:1,unit_price:0,tax_code:_invGSTReg?'GST':'INP',account_id:null,item_id:null,line_type:'item'});
  const row = document.createElement('div');
  row.innerHTML = _editLineHtml(i, _editLines[i]);
  document.getElementById('edt-lines-body').appendChild(row.firstElementChild);
  _editRefreshTotals();
  _wireInvLineTypeahead(i);
  const el = document.getElementById(`edt-desc-${i}`);
  if (el) el.focus();
}

function editRemoveLine(i) {
  _editLines[i] = null;
  const el = document.getElementById(`edt-line-${i}`);
  if (el) el.remove();
  _editRefreshTotals();
}

function _editTotals() {
  let rawSub=0, rawGst=0;
  (_editLines||[]).forEach(l=>{
    if(!l || l.line_type==='comment') return;
    const q=l.quantity||0, p=l.unit_price||0;
    const rate=(l.tax_code==='GST'||l.tax_code==='CAP')?0.1:0;
    rawGst += Math.round(q*p*rate*100)/100;
    rawSub += q*p;
  });
  rawSub = Math.round(rawSub*100)/100;
  rawGst = Math.round(rawGst*100)/100;

  const discVal = parseFloat(document.getElementById('edt-disc-val')?.value||0)||0;
  let discAmt = 0;
  if (discVal > 0 && rawSub > 0) {
    discAmt = _discType==='percent'
      ? Math.round(rawSub*discVal/100*100)/100
      : Math.min(Math.round(discVal*100)/100, rawSub);
    const ratio = (rawSub - discAmt) / rawSub;
    const sub = Math.round((rawSub - discAmt)*100)/100;
    const gst = Math.round(rawGst*ratio*100)/100;
    return {sub, gst, total:Math.round((sub+gst)*100)/100, discAmt, rawSub};
  }
  return {sub:rawSub, gst:rawGst, total:Math.round((rawSub+rawGst)*100)/100, discAmt:0, rawSub};
}

function _invToggleDiscType() {
  _discType = _discType==='percent' ? 'amount' : 'percent';
  const btn = document.getElementById('edt-disc-toggle');
  if (btn) btn.textContent = _discType==='percent' ? '%' : '$';
  _editRefreshTotals();
}

function _editRefreshTotals() {
  const {sub, gst, total, discAmt, rawSub} = _editTotals();
  const el = document.getElementById('edt-totals');
  if (!el) return;
  const discLine = discAmt > 0
    ? `<span><span>Discount${_discType==='percent'?' ('+parseFloat(document.getElementById('edt-disc-val')?.value||0).toFixed(1)+'%)':''}</span><b>-${fmt(discAmt)}</b></span>`
    : '';
  el.innerHTML = `
    <span><span>Subtotal (ex GST)</span><b>${fmt(rawSub)}</b></span>
    ${discLine}
    <span><span>GST (10%)</span><b>${fmt(gst)}</b></span>
    <span class="grand"><span>Total</span><b>${fmt(total)}</b></span>`;
}

async function _invNewContact() {
  const c = await quickNewContact('Customer');
  if (!c) return;
  if (_editContacts) _editContacts.push(c);
  const sel = document.getElementById('edt-contact');
  if (sel) sel.appendChild(new Option(c.name, c.id, true, true));
}

function invContactChanged() {
  const contactId = parseInt(document.getElementById('edt-contact').value);
  const contact   = (_editContacts||[]).find(c=>c.id===contactId);
  if (!contact) return;
  const terms   = contact.payment_terms || 30;
  const invDate = document.getElementById('edt-date').value || isoToday();
  document.getElementById('edt-due').value = isoDateAddDays(invDate, terms);
}

async function invEditSave() {
  const contactId = parseInt(document.getElementById('edt-contact').value);
  const contact   = (_editContacts||[]).find(c=>c.id===contactId);
  const invDate   = document.getElementById('edt-date').value;
  const dueDate   = document.getElementById('edt-due').value;
  const status    = document.getElementById('edt-status').value;

  if (!contactId)  { toast('Select a customer','err'); return; }
  if (!invDate)    { toast('Enter an invoice date','err'); return; }
  if (!dueDate)    { toast('Enter a due date','err'); return; }

  const lines = (_editLines||[]).filter(l=>l&&l.description.trim());
  if (!lines.length) { toast('Add at least one line item','err'); return; }

  const taskIds = lines.filter(l => l.task_id).map(l => l.task_id);

  const payload = {
    id:                   _editData.invoice.id,
    opp_id:               _editData.invoice.opp_id || null,
    contact_id:           contactId,
    contact_name:         contact ? contact.name : '',
    invoice_date:         invDate,
    due_date:             dueDate,
    status,
    notes:                document.getElementById('edt-notes').value,
    payment_instructions: document.getElementById('edt-payment').value,
    internal_comments:    document.getElementById('edt-comments').value,
    job_id:               parseInt(document.getElementById('edt-job')?.value||0)||null,
    task_ids:             taskIds,
    discount_type:        _discType,
    discount_value:       parseFloat(document.getElementById('edt-disc-val')?.value||0)||0,
    lines: lines.map(l=>({
      description: l.description,
      quantity:    l.line_type==='comment' ? 0 : l.quantity,
      unit_price:  l.line_type==='comment' ? 0 : l.unit_price,
      tax_code:    l.tax_code||'GST',
      account_id:  l.account_id||null,
      item_id:     l.item_id||null,
      line_type:   l.line_type||'item',
    })),
  };

  const btn = document.querySelector('.det-foot .btn-primary');
  if (btn) { btn.disabled=true; btn.textContent='Saving…'; }

  try {
    let r, j;
    if (payload.id) {
      r = await fetch(`/api/invoices/${payload.id}`, {
        method:'PUT', headers:{'Content-Type':'application/json'},
        credentials:'include', body:JSON.stringify(payload),
      });
      j = await r.json();
      if (!j.ok) {
        if (j.oversell) { _invHandleOversell(j.items, payload, btn); return; }
        throw new Error(j.error);
      }
      toast('Invoice saved');
      _editData = null; _editLines = [];
      await _invRefresh(payload.id);
      invOpen(payload.id);
    } else {
      r = await fetch('/api/invoices', {
        method:'POST', headers:{'Content-Type':'application/json'},
        credentials:'include', body:JSON.stringify(payload),
      });
      j = await r.json();
      if (!j.ok) {
        if (j.oversell) { _invHandleOversell(j.items, payload, btn); return; }
        throw new Error(j.error);
      }
      toast('Invoice created');
      _editData = null; _editLines = [];
      _invAll = (await apiFetch('/api/invoices')) || []; renderInvoicesPage();
      invOpen(j.data.id);
    }
  } catch(e) {
    toast(e.message,'err');
    if (btn) { btn.disabled=false; btn.textContent='Save Invoice'; }
  }
}

function _invHandleOversell(items, payload, btn) {
  if (btn) { btn.disabled=false; btn.textContent='Save Invoice'; }
  const rows = items.map(it =>
    `<tr>
       <td>${esc(it.item_code||'')}</td>
       <td>${esc(it.item_name)}</td>
       <td style="text-align:right">${it.on_hand}</td>
       <td style="text-align:right">${it.requested}</td>
       <td style="text-align:right;color:var(--red);font-weight:600">${it.shortfall}</td>
     </tr>`
  ).join('');
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:min(600px,96vw)">
    <div class="modal-hdr"><span class="modal-title">Insufficient Stock</span></div>
    <div class="modal-body">
      <p style="margin:0 0 12px;color:var(--ink2)">The following items have insufficient stock. You can create backorders for the shortfall — the invoice will be saved and the shortfall tracked until stock arrives.</p>
      <table class="inv-list-table" style="width:100%">
        <thead><tr><th>Code</th><th>Item</th><th style="text-align:right">On Hand</th><th style="text-align:right">Requested</th><th style="text-align:right">Shortfall</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
    <div class="modal-foot">
      <button class="btn btn-outline" id="inv-os-cancel">Cancel</button>
      <button class="btn btn-primary" id="inv-os-backorder">Create Backorders &amp; Save</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  bd.querySelector('#inv-os-cancel').onclick = () => bd.remove();
  bd.querySelector('#inv-os-backorder').onclick = async () => {
    bd.remove();
    const backorderPayload = Object.assign({}, payload, {
      allow_backorder: true,
      backorder_items: items.map(it => ({
        item_id:   it.item_id,
        item_code: it.item_code || '',
        item_name: it.item_name,
        qty:       it.shortfall,
      })),
    });
    const url = payload.id ? `/api/invoices/${payload.id}` : '/api/invoices';
    const method = payload.id ? 'PUT' : 'POST';
    if (btn) { btn.disabled=true; btn.textContent='Saving…'; }
    try {
      const r2 = await fetch(url, {method, headers:{'Content-Type':'application/json'}, credentials:'include', body:JSON.stringify(backorderPayload)});
      const j2 = await r2.json();
      if (!j2.ok) throw new Error(j2.error);
      toast('Invoice saved — backorders created for shortfall');
      _editData = null; _editLines = [];
      if (payload.id) {
        await _invRefresh(payload.id); invOpen(payload.id);
      } else {
        _invAll = (await apiFetch('/api/invoices')) || []; renderInvoicesPage();
        invOpen(j2.data.id);
      }
    } catch(e) {
      toast(e.message, 'err');
      if (btn) { btn.disabled=false; btn.textContent='Save Invoice'; }
    }
  };
}


let _pmId=null;
function payModalOpen(inv){
  _pmId=inv.id;const bal=(inv.total||0)-(inv.amount_paid||0);
  document.getElementById('pm-amount').value=bal.toFixed(2);
  document.getElementById('pm-date').value=isoToday();
  document.getElementById('pm-method').value='EFT';
  document.getElementById('pm-ref').value='';
  document.getElementById('pm-account').innerHTML=_bankAccts.length
    ?_bankAccts.map(a=>`<option value="${a.id}">${esc((a.code||'')+' '+a.name)}</option>`).join('')
    :'<option value="">— No bank accounts —</option>';
  document.getElementById('pay-modal').classList.add('open');
}
function payModalClose(){document.getElementById('pay-modal').classList.remove('open');_pmId=null;}
async function paySave(){
  const amount=parseFloat(document.getElementById('pm-amount').value);
  if(!amount||amount<=0){toast('Enter a valid amount','err');return;}
  const btn=document.getElementById('pm-save');btn.disabled=true;btn.textContent='Saving\u2026';
  try{
    const r=await fetch(`/api/invoices/${_pmId}/payment`,{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',
      body:JSON.stringify({amount,payment_date:document.getElementById('pm-date').value,method:document.getElementById('pm-method').value,
        reference:document.getElementById('pm-ref').value,account_id:parseInt(document.getElementById('pm-account').value)||null})});
    const j=await r.json();if(!j.ok)throw new Error(j.error);
    toast('Payment recorded');payModalClose();await _invRefresh(_pmId);
  }catch(e){toast(e.message,'err');}
  finally{btn.disabled=false;btn.textContent='Save Payment';}
}

// ── Pay via Terminal ─────────────────────────────────────────────────────

async function _invTerminalPay(inv) {
  const bal = Math.round(((inv.total || 0) - (inv.amount_paid || 0)) * 100) / 100;
  if (bal <= 0.005) { toast('No outstanding balance', 'err'); return; }

  let posSettings;
  try { posSettings = await apiFetch('/api/pos/settings'); }
  catch(e) { toast('Could not load terminal settings: ' + e.message, 'err'); return; }

  const provider = posSettings?.provider || '';
  if (!provider) { toast('No payment terminal configured — set up POS settings first', 'err'); return; }
  const cardAccountId = posSettings?.card_account_id || null;
  if (!cardAccountId) { toast('POS card account not configured — go to POS Settings and set the Card Account', 'err'); return; }

  const ref = `INV-${inv.invoice_number || inv.id}-${Date.now()}`;
  _invTerminalOpenModal(inv, bal);

  let checkoutId, chargeProvider;
  try {
    const r = await fetch('/api/pos/terminal/charge', {
      method: 'POST', headers: {'Content-Type':'application/json'}, credentials: 'include',
      body: JSON.stringify({ amount: bal, reference: ref }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Terminal error');
    checkoutId = r.data.checkout_id;
    chargeProvider = r.data.provider;
  } catch(e) { _invTerminalSetError(e.message); return; }

  _invTerminalSetWaiting('Waiting for customer to tap or insert card…');
  _invTerminalStartPoll(checkoutId, chargeProvider, bal, inv, cardAccountId, ref);
}

function _invTerminalOpenModal(inv, bal) {
  document.getElementById('inv-terminal-modal')?.remove();
  const num = esc(inv.invoice_number || ('#' + inv.id));
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.id = 'inv-terminal-modal'; bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:min(400px,94vw);text-align:center">
    <div class="modal-hdr" style="text-align:left"><span style="font-weight:600">Pay via Terminal &mdash; ${num}</span></div>
    <div class="modal-body" style="padding:20px 0 8px" id="inv-terminal-body">
      <div class="pos-terminal-waiting">
        <div class="pos-terminal-spinner"></div>
        <div class="pos-terminal-msg" id="inv-terminal-msg">Connecting to terminal…</div>
        <div class="pos-terminal-sub">Amount: $${bal.toFixed(2)}</div>
      </div>
    </div>
    <div class="modal-foot" style="justify-content:center">
      <button class="btn btn-outline" id="inv-terminal-cancel-btn" onclick="_invTerminalCancel()">Cancel</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

function _invTerminalSetWaiting(msg) {
  const el = document.getElementById('inv-terminal-msg');
  if (el) el.textContent = msg;
}

function _invTerminalSetError(msg) {
  clearInterval(_invTerminalPollTimer); _invTerminalPollTimer = null;
  const body = document.getElementById('inv-terminal-body');
  if (body) body.innerHTML = `<div class="pos-terminal-error">${esc(msg)}</div>`;
  const btn = document.getElementById('inv-terminal-cancel-btn');
  if (btn) btn.textContent = 'Close';
}

function _invTerminalCancel() {
  clearInterval(_invTerminalPollTimer); _invTerminalPollTimer = null;
  document.getElementById('inv-terminal-modal')?.remove();
}

function _invTerminalStartPoll(checkoutId, provider, bal, inv, cardAccountId, ref) {
  let count = 0;
  clearInterval(_invTerminalPollTimer);
  _invTerminalPollTimer = setInterval(async () => {
    count++;
    if (count > 90) {
      clearInterval(_invTerminalPollTimer); _invTerminalPollTimer = null;
      _invTerminalSetError('Terminal timeout — please retry');
      return;
    }
    try {
      const res = await apiFetch(`/api/pos/terminal/charge/${checkoutId}?provider=${encodeURIComponent(provider)}`);
      if (!res) return;
      if (res.status === 'completed') {
        clearInterval(_invTerminalPollTimer); _invTerminalPollTimer = null;
        await _invTerminalRecordPayment(inv, bal, cardAccountId, ref, checkoutId);
      } else if (res.status === 'declined' || res.status === 'error') {
        clearInterval(_invTerminalPollTimer); _invTerminalPollTimer = null;
        _invTerminalSetError(res.message || 'Payment declined by terminal');
      }
    } catch(_) {}
  }, 2000);
}

async function _invTerminalRecordPayment(inv, bal, cardAccountId, ref) {
  const body = document.getElementById('inv-terminal-body');
  if (body) body.innerHTML = `<div class="pos-terminal-waiting">
    <div class="pos-terminal-spinner"></div>
    <div class="pos-terminal-msg">Recording payment…</div>
  </div>`;
  try {
    const r = await fetch(`/api/invoices/${inv.id}/payment`, {
      method: 'POST', headers: {'Content-Type':'application/json'}, credentials: 'include',
      body: JSON.stringify({ amount: bal, payment_date: isoToday(), account_id: cardAccountId, reference: ref }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Payment recording failed');
    document.getElementById('inv-terminal-modal')?.remove();
    toast('Card payment recorded successfully');
    await _invRefresh(inv.id);
  } catch(e) {
    _invTerminalSetError('Card charged but payment recording failed: ' + e.message + ' — please use Record Payment manually to reconcile.');
  }
}

// ── Credit note email ────────────────────────────────────────────────────

async function invCNEmailOpen(inv) {
  const num = inv.invoice_number || ('#' + inv.id);
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:min(560px,96vw)">
    <div class="modal-title">Email Credit Note ${esc(num)}</div>
    <div class="modal-field"><label class="modal-lbl">To *</label>
      <input class="modal-inp" type="email" id="cne-to" placeholder="recipient@example.com"></div>
    <div class="modal-field"><label class="modal-lbl">Subject</label>
      <input class="modal-inp" type="text" id="cne-subj" value="${esc('Credit Note ' + num)}"></div>
    <div class="modal-field"><label class="modal-lbl">Message</label>
      <textarea class="modal-inp" id="cne-body" rows="5" style="resize:vertical;min-height:90px"></textarea></div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary btn-sm" id="cne-send-btn" onclick="_invDoCNEmail(${inv.id})">📧 Send</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  try {
    const contact = await apiFetch(`/api/contacts/${inv.contact_id}`);
    if (contact?.email) document.getElementById('cne-to').value = contact.email;
    const bodyEl = document.getElementById('cne-body');
    if (bodyEl) bodyEl.value = `Please find attached credit note ${num} for ${fmt(inv.total)}.\n\nThis credit has been applied to your account.\n\nThank you.`;
  } catch(e){}
}

async function _invDoCNEmail(id) {
  const to = (document.getElementById('cne-to')?.value || '').trim();
  if (!to) { toast('Recipient email is required', 'err'); return; }
  const btn = document.getElementById('cne-send-btn');
  btn.disabled = true; btn.textContent = 'Sending…';
  try {
    const r = await fetch(`/api/invoices/${id}/email`, {method:'POST', credentials:'include',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({to, subject:document.getElementById('cne-subj')?.value||'',
        body:document.getElementById('cne-body')?.value||''})});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Send failed');
    btn.closest('.modal-bd')?.remove();
    toast('Credit note emailed');
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = '📧 Send';
  }
}

// ── Credit note ──────────────────────────────────────────────────────────

let _cnInvId=null, _cnOutstanding=0, _cnSrcLines=[];

async function invCreditNoteOpen(inv, sourceLines) {
  _cnInvId = inv.id;
  _cnSrcLines = (sourceLines||[]).filter(l=>(l.line_type||'item')!=='comment');
  const outstanding = Math.round(((inv.total||0)-(inv.amount_paid||0))*100)/100;
  // For paid invoices, cap is invoice total (unapplied credit); otherwise cap is outstanding
  _cnOutstanding = outstanding > 0.005 ? outstanding : (inv.total||0);
  const num = inv.invoice_number||('#'+inv.id);
  const today = isoToday();
  const linesHtml = _cnSrcLines.map((l,i)=>{
    const qty=parseFloat(l.quantity)||0, price=parseFloat(l.unit_price)||0;
    const rate=(l.tax_code==='GST'||l.tax_code==='CAP')?0.1:0;
    const total=Math.round((qty*price*(1+rate))*100)/100;
    return `<tr>
      <td style="padding:4px 6px">${esc(l.description)}</td>
      <td style="padding:4px 4px"><input class="cn-qty-inp edt-inp" data-i="${i}" type="number" min="0" step="0.01" value="${qty}" oninput="cnUpdateTotals()" style="width:72px;padding:4px 6px"></td>
      <td style="padding:4px 4px"><input class="cn-price-inp edt-inp" data-i="${i}" type="number" min="0" step="0.01" value="${price}" oninput="cnUpdateTotals()" style="width:90px;padding:4px 6px"></td>
      <td style="padding:4px 6px;color:var(--ink3);font-size:12px">${esc(l.tax_code||'GST')}</td>
      <td class="td-r-mono" id="cn-lt-${i}" style="padding:4px 6px">${fmt(total)}</td>
    </tr>`;
  }).join('');
  const bd=document.createElement('div');
  bd.className='modal-bd'; bd.style.display='flex';
  bd.innerHTML=`<div class="modal-box" style="width:min(700px,96vw);display:flex;flex-direction:column;max-height:90vh">
    <div class="modal-hdr"><span class="modal-title">Issue Credit Note — ${esc(num)}</span></div>
    <div class="modal-body" style="overflow-y:auto;flex:1;padding:16px 20px 8px">
      <div class="cn-src-banner">
        <span>Customer: <b>${esc(inv.contact_name||'—')}</b></span>
        <span>${outstanding>0.005?'Outstanding':'Invoice total'}: <b class="mono">${fmt(_cnOutstanding)}</b></span>
        ${outstanding<=0.005?'<span style="color:var(--amber);font-size:12px">Invoice is paid — credit will be unapplied until applied to a future invoice.</span>':''}
      </div>
      <div class="edt-row" style="margin:12px 0 8px">
        <div class="edt-field">
          <label class="edt-lbl">Credit Note Date *</label>
          <input class="edt-inp" type="date" id="cn-date" value="${today}">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Reason / Memo *</label>
          <input class="edt-inp" type="text" id="cn-memo" placeholder="e.g. Returned goods — incorrect item shipped">
        </div>
      </div>
      <table class="det-lines" style="margin-top:4px">
        <thead><tr>
          <th>Description</th>
          <th style="width:84px">Qty</th>
          <th style="width:102px">Unit Price</th>
          <th style="width:50px">Tax</th>
          <th class="th-r" style="width:100px">Total</th>
        </tr></thead>
        <tbody>${linesHtml||'<tr><td colspan="5" class="tbl-empty-sm">No invoice lines</td></tr>'}</tbody>
      </table>
      <div class="det-totals" id="cn-totals" style="margin-top:8px"></div>
      <div id="cn-warning" style="display:none;color:var(--red);font-size:13px;margin-top:6px;font-weight:500"></div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary btn-sm" id="cn-submit-btn" onclick="_invDoCreditNote()">Issue Credit Note</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  cnUpdateTotals();
}

function cnUpdateTotals() {
  let sub=0, gst=0;
  _cnSrcLines.forEach((l,i)=>{
    const qty=parseFloat(document.querySelector(`.cn-qty-inp[data-i="${i}"]`)?.value||0)||0;
    const price=parseFloat(document.querySelector(`.cn-price-inp[data-i="${i}"]`)?.value||0)||0;
    const rate=(l.tax_code==='GST'||l.tax_code==='CAP')?0.1:0;
    const lineGst=Math.round(qty*price*rate*100)/100;
    const lineTotal=Math.round((qty*price+lineGst)*100)/100;
    sub+=qty*price; gst+=lineGst;
    const ltEl=document.getElementById(`cn-lt-${i}`);
    if(ltEl) ltEl.textContent=fmt(lineTotal);
  });
  const total=Math.round((sub+gst)*100)/100;
  const totEl=document.getElementById('cn-totals');
  if(totEl) totEl.innerHTML=`
    <div class="det-tot-row"><span>Subtotal (ex GST)</span><span>${fmt(sub)}</span></div>
    <div class="det-tot-row"><span>GST (10%)</span><span>${fmt(gst)}</span></div>
    <div class="det-tot-row grand"><span>Credit Note Total</span><span>${fmt(total)}</span></div>`;
  const warn=document.getElementById('cn-warning');
  if(warn) {
    if(total>_cnOutstanding+0.005) {
      warn.textContent=`Total (${fmt(total)}) exceeds outstanding balance (${fmt(_cnOutstanding)})`;
      warn.style.display='';
    } else { warn.style.display='none'; }
  }
}

async function _invDoCreditNote() {
  const noteDate=(document.getElementById('cn-date')?.value||'').trim();
  const memo=(document.getElementById('cn-memo')?.value||'').trim();
  if(!noteDate){toast('Credit note date is required','err');return;}
  if(!memo){toast('Reason / memo is required','err');return;}
  const lines=_cnSrcLines.map((l,i)=>({
    description:l.description,
    quantity:parseFloat(document.querySelector(`.cn-qty-inp[data-i="${i}"]`)?.value||0)||0,
    unit_price:parseFloat(document.querySelector(`.cn-price-inp[data-i="${i}"]`)?.value||0)||0,
    tax_code:l.tax_code||'GST', account_id:l.account_id||null, line_type:'item',
  })).filter(l=>l.quantity>0&&l.unit_price>0);
  if(!lines.length){toast('No credit lines — set at least one qty and price','err');return;}
  const total=lines.reduce((s,l)=>{const r=(l.tax_code==='GST'||l.tax_code==='CAP')?0.1:0;return s+Math.round(l.quantity*l.unit_price*(1+r)*100)/100;},0);
  if(total>_cnOutstanding+0.005){toast(`Total exceeds outstanding balance (${fmt(_cnOutstanding)})`,'err');return;}
  const btn=document.getElementById('cn-submit-btn');
  btn.disabled=true; btn.textContent='Issuing…';
  try {
    const r=await fetch(`/api/invoices/${_cnInvId}/credit-note`,{method:'POST',credentials:'include',
      headers:{'Content-Type':'application/json'},body:JSON.stringify({date:noteDate,memo,lines})});
    const j=await r.json();
    if(!j.ok) throw new Error(j.error||'Failed');
    btn.closest('.modal-bd')?.remove();
    toast('Credit note issued');
    _invAll=(await apiFetch('/api/invoices'))||[];
    renderInvoicesPage();
    invOpen(j.data.id);
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent='Issue Credit Note';
  }
}

// ── Apply unapplied credit note to an invoice ─────────────────────────────

async function invApplyCreditOpen(inv) {
  const bd=document.createElement('div');
  bd.className='modal-bd'; bd.style.display='flex';
  bd.innerHTML=`<div class="modal-box" style="width:min(540px,96vw)">
    <div class="modal-title">Apply Customer Credit</div>
    <div id="acr-body" style="padding:4px 0 8px"><div style="color:var(--ink3);font-size:13px">Loading available credits…</div></div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary btn-sm" id="acr-btn" onclick="_invDoApplyCredit(${inv.id})" disabled>Apply</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  const outstanding=Math.round(((inv.total||0)-(inv.amount_paid||0))*100)/100;
  try {
    const [credits, prepayments]=await Promise.all([
      apiFetch(`/api/contacts/${inv.contact_id}/available-credits`),
      apiFetch(`/api/contacts/${inv.contact_id}/unallocated-payments`),
    ]);
    const wrap=document.getElementById('acr-body');
    const hasCN=(credits&&credits.length>0);
    const hasPP=(prepayments&&prepayments.length>0);
    if(!hasCN&&!hasPP){
      wrap.innerHTML='<div style="color:var(--ink3);font-size:13px;padding:8px 0">No available credits or prepayments for this customer.</div>';
      return;
    }
    let rows='';
    let idx=0;
    if(hasCN){
      rows+=`<tr><td colspan="5" style="font-size:11px;font-weight:600;color:var(--ink3);padding:6px 4px 2px;text-transform:uppercase;letter-spacing:.5px">Credit Notes</td></tr>`;
      credits.forEach(cn=>{
        rows+=`<tr style="cursor:pointer" onclick="acrSelect(${idx})">
          <td><input type="radio" name="acr-item" id="acr-r${idx}" value="${cn.id}" data-type="cn" data-remaining="${cn.remaining}" onchange="acrSelect(${idx})"></td>
          <td><label for="acr-r${idx}" style="cursor:pointer">${esc(cn.invoice_number)}</label></td>
          <td class="mono" style="color:var(--ink2)">${fmtDate(cn.invoice_date)}</td>
          <td style="font-size:11px;color:var(--ink3)">Credit Note</td>
          <td class="td-r-mono" style="color:var(--green)">${fmt(cn.remaining)}</td>
        </tr>`;
        idx++;
      });
    }
    if(hasPP){
      rows+=`<tr><td colspan="5" style="font-size:11px;font-weight:600;color:var(--ink3);padding:6px 4px 2px;text-transform:uppercase;letter-spacing:.5px">Prepayments / Overpayments</td></tr>`;
      prepayments.forEach(p=>{
        const lbl=p.reference||p.description||`Receipt #${p.id}`;
        rows+=`<tr style="cursor:pointer" onclick="acrSelect(${idx})">
          <td><input type="radio" name="acr-item" id="acr-r${idx}" value="${p.id}" data-type="pmt" data-remaining="${p.unallocated}" onchange="acrSelect(${idx})"></td>
          <td><label for="acr-r${idx}" style="cursor:pointer">${esc(lbl)}</label></td>
          <td class="mono" style="color:var(--ink2)">${fmtDate(p.payment_date)}</td>
          <td style="font-size:11px;color:var(--ink3)">Prepayment</td>
          <td class="td-r-mono" style="color:var(--green)">${fmt(p.unallocated)}</td>
        </tr>`;
        idx++;
      });
    }
    wrap.innerHTML=`
      <div style="font-size:13px;color:var(--ink2);margin-bottom:10px">Select a credit to apply toward this invoice (outstanding: <b class="mono">${fmt(outstanding)}</b>).</div>
      <table class="det-lines" style="margin-bottom:10px">
        <thead><tr><th></th><th>Reference</th><th>Date</th><th>Type</th><th class="th-r">Available</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="edt-field" style="margin-top:4px">
        <label class="edt-lbl">Amount to Apply</label>
        <input class="edt-inp" type="number" id="acr-amount" min="0.01" step="0.01" value="" style="width:140px">
      </div>`;
  } catch(e) {
    document.getElementById('acr-body').innerHTML=`<div class="state-error">${esc(e.message)}</div>`;
  }
}

function acrSelect(i) {
  const radio=document.getElementById(`acr-r${i}`);
  if(!radio) return;
  radio.checked=true;
  const remaining=parseFloat(radio.dataset.remaining||0);
  const amtInp=document.getElementById('acr-amount');
  if(amtInp) {
    const invOutstanding=parseFloat(amtInp.closest('.modal-box')?.querySelector('.mono')?.textContent?.replace(/[^0-9.]/g,'')||0)||remaining;
    amtInp.value=Math.min(remaining,invOutstanding).toFixed(2);
  }
  const btn=document.getElementById('acr-btn');
  if(btn) btn.disabled=false;
}

async function _invDoApplyCredit(invoiceId) {
  const radio=document.querySelector('input[name="acr-item"]:checked');
  if(!radio){toast('Select a credit or prepayment','err');return;}
  const itemType=radio.dataset.type;
  const itemId=parseInt(radio.value);
  const amount=parseFloat(document.getElementById('acr-amount')?.value||0);
  if(!amount||amount<=0){toast('Enter an amount to apply','err');return;}
  const btn=document.getElementById('acr-btn');
  btn.disabled=true; btn.textContent='Applying…';
  try {
    let r, endpoint, body;
    if(itemType==='cn'){
      endpoint=`/api/invoices/${invoiceId}/apply-credit`;
      body={cn_id:itemId,amount};
    } else {
      endpoint=`/api/invoices/${invoiceId}/apply-prepayment`;
      body={payment_id:itemId,amount};
    }
    r=await fetch(endpoint,{method:'POST',credentials:'include',
      headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const j=await r.json();
    if(!j.ok) throw new Error(j.error||'Failed');
    btn.closest('.modal-bd')?.remove();
    toast(`${fmt(j.data.applied)} credit applied`);
    _invAll=(await apiFetch('/api/invoices'))||[];
    renderInvoicesPage();
    invOpen(invoiceId);
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent='Apply';
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// BILLS PAGE
// ═══════════════════════════════════════════════════════════════════════════
let _billAll=[],_billFilter='All',_billSearch='',_billSort={col:'bill_date',dir:-1},_billSelected=null;
const BILL_STATS=['All','Draft','Approved','Partial','Overdue','Paid','Void'];
const BILL_BADGE={Paid:'badge-paid',Draft:'badge-draft',Approved:'badge-pending',Partial:'badge-partial',Overdue:'badge-overdue',Void:'badge-draft'};

function _billEffSt(b) {
  if(['Paid','Void','Draft'].includes(b.status)) return b.status;
  const td=isoToday();
  if(b.due_date&&b.due_date<td) return 'Overdue';
  return b.status;
}


// ── Shared Attachments Panel ──────────────────────────────────────────────────
// Used by invoices, bills, and payments detail panes.
// _attLoadedFor tracks {type, id} to avoid re-fetching on re-render.
let _attLoadedFor = null;

function _attFmtSize(n) {
  if (!n) return '0 B';
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n/1024).toFixed(1) + ' KB';
  return (n/1048576).toFixed(1) + ' MB';
}

function _attIcon(mime) {
  if (!mime) return '📄';
  if (mime.startsWith('image/')) return '🖼';
  if (mime === 'application/pdf') return '📋';
  if (mime.includes('spreadsheet') || mime.includes('excel') || mime.endsWith('.xlsx')) return '📊';
  if (mime.includes('word') || mime.endsWith('.docx')) return '📝';
  return '📄';
}

function _attRenderPane(paneId, sourceType, sourceId, rows) {
  const pane = document.getElementById(paneId);
  if (!pane) return;
  if (!rows || !rows.length) {
    pane.innerHTML = `
      <div style="margin-bottom:10px">
        <button class="btn btn-outline btn-sm" onclick="_attUpload('${sourceType}',${sourceId},'${paneId}')">📎 Attach File</button>
      </div>
      <div class="det-empty">No attachments yet — attach receipts, photos, or documents.</div>`;
    return;
  }
  const rowsHtml = rows.map(a => `
    <div class="att-row" data-id="${a.id}">
      <span class="att-icon">${_attIcon(a.mime_type)}</span>
      <div class="att-info">
        <div class="att-filename">${esc(a.filename)}</div>
        <div class="att-meta">${_attFmtSize(a.file_size)}${a.description ? '  •  ' + esc(a.description) : ''}</div>
      </div>
      <div class="att-btns">
        <a class="btn btn-outline btn-sm" href="/api/attachments/${a.id}/download" download="${esc(a.filename)}">⬇ Download</a>
        <button class="btn btn-danger btn-sm" onclick="_attDelete(${a.id},'${sourceType}',${sourceId},'${paneId}')">✕</button>
      </div>
    </div>`).join('');
  pane.innerHTML = `
    <div style="margin-bottom:10px">
      <button class="btn btn-outline btn-sm" onclick="_attUpload('${sourceType}',${sourceId},'${paneId}')">📎 Attach File</button>
      <span class="count-pill" style="margin-left:8px">${rows.length} attachment${rows.length!==1?'s':''}</span>
    </div>
    <div class="att-list">${rowsHtml}</div>`;
}

async function _attLoad(paneId, sourceType, sourceId) {
  const pane = document.getElementById(paneId);
  if (!pane) return;
  pane.innerHTML = '<div class="state-loading det-loading-pad">Loading…</div>';
  try {
    const rows = await apiFetch(`/api/attachments/${sourceType}/${sourceId}`);
    _attLoadedFor = {type: sourceType, id: sourceId};
    _attRenderPane(paneId, sourceType, sourceId, rows || []);
  } catch(e) {
    pane.innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
  }
}

function _attUpload(sourceType, sourceId, paneId) {
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = '.pdf,.png,.jpg,.jpeg,.gif,.bmp,.webp,.doc,.docx,.xls,.xlsx,.csv,.txt,.zip,.eml';
  inp.onchange = async () => {
    const file = inp.files[0];
    if (!file) return;
    if (file.size > 20 * 1024 * 1024) { toast('File exceeds 20 MB limit', true); return; }
    const desc = (window.prompt(`Description for "${file.name}" (optional):`) || '').trim();
    const fd = new FormData();
    fd.append('file', file);
    fd.append('description', desc);
    try {
      const r = await fetch(`/api/attachments/${sourceType}/${sourceId}`, {
        method: 'POST', credentials: 'include', body: fd });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Upload failed');
      _attRenderPane(paneId, sourceType, sourceId, j.data || []);
      toast('Attachment saved');
    } catch(e) { toast(e.message, true); }
  };
  inp.click();
}

async function _attDelete(attId, sourceType, sourceId, paneId) {
  if (!await confirmDlg('Delete this attachment? This cannot be undone.')) return;
  try {
    const r = await fetch(`/api/attachments/${attId}`, {method:'DELETE', credentials:'include'});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Delete failed');
    toast('Attachment deleted');
    await _attLoad(paneId, sourceType, sourceId);
  } catch(e) { toast(e.message, true); }
}

// ─── Recurring templates ───────────────────────────────────────────────────────

async function _invFromTemplate() {
  let templates;
  try {
    const all = await apiFetch('/api/recurring');
    templates = (all || []).filter(t => t.template_type === 'Invoice' && t.is_active && t.contact_id);
  } catch(e) { toast(e.message, 'err'); return; }

  if (!templates.length) {
    toast('No Invoice templates found — create one in the Recurring module.', 'err'); return;
  }

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="min-width:500px;max-width:640px">
    <div class="modal-hdr"><strong>From Template</strong></div>
    <div class="modal-body" style="overflow-y:auto;max-height:60vh;padding:0">
      <table class="inv-list-table">
        <thead><tr><th>Template</th><th>Customer</th><th>Frequency</th><th class="th-r">Total (inc GST)</th></tr></thead>
        <tbody>
          ${templates.map(t => {
            const lines = JSON.parse(t.lines_json || '[]');
            let total;
            if (lines.length) {
              total = lines.reduce((s, l) => {
                const ex = (parseFloat(l.quantity)||1) * (parseFloat(l.unit_price)||0);
                return s + ex + ((l.tax_code==='GST'||l.tax_code==='CAP') ? ex*0.1 : 0);
              }, 0);
            } else {
              const ex = parseFloat(t.amount) || 0;
              total = ex + (t.tax_code==='GST' ? ex*0.1 : 0);
            }
            return `<tr class="inv-row" style="cursor:pointer" onclick="_invApplyTemplate(${t.id},this.closest('.modal-bd'))">
              <td>${esc(t.name)}</td><td>${esc(t.contact_name||'—')}</td>
              <td>${esc(t.frequency)}</td><td class="td-r-mono">${fmt(Math.round(total*100)/100)}</td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>
    <div class="modal-foot">
      <button class="btn btn-outline" onclick="this.closest('.modal-bd').remove()">Cancel</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  bd.addEventListener('click', e => { if (e.target === bd) bd.remove(); });
}

async function _invApplyTemplate(tid, modalEl) {
  if (modalEl) modalEl.remove();
  let t;
  try { t = await apiFetch(`/api/recurring/${tid}`); }
  catch(e) { toast(e.message, 'err'); return; }

  const rawLines = JSON.parse(t.lines_json || '[]');
  const lines = rawLines.length
    ? rawLines.map(l => ({description:l.description||'',quantity:parseFloat(l.quantity)||1,
        unit_price:parseFloat(l.unit_price)||0,tax_code:l.tax_code||'GST',
        account_id:l.account_id||null,line_type:'item'}))
    : [{description:t.description||t.name||'',quantity:1,unit_price:parseFloat(t.amount)||0,
        tax_code:t.tax_code||'GST',account_id:t.account_id||null,line_type:'item'}];

  const data = {
    invoice: {id:null,contact_id:t.contact_id||null,invoice_date:isoToday(),due_date:isoAddDays(30),
      status:'Draft',invoice_number:'',notes:t.description||'',
      payment_instructions:'',internal_comments:'',subtotal:0,gst_total:0,total:0,amount_paid:0},
    lines,
  };
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = 'New Invoice';
  document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading…</div>';
  document.getElementById('det-foot').innerHTML = '';
  await invEditOpen(data);
}

async function _invSaveAsTemplate() {
  const contactId = parseInt(document.getElementById('edt-contact')?.value || 0) || null;
  const contactName = document.getElementById('edt-contact')?.selectedOptions[0]?.text || '';
  const firstDesc = (_editLines||[]).find(l => l && l.description)?.description || '';
  const defName = [contactName, firstDesc].filter(Boolean).join(' — ') || 'New Template';

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="min-width:360px">
    <div class="modal-hdr"><strong>Save as Recurring Template</strong></div>
    <div class="modal-body" style="padding:18px 20px;display:flex;flex-direction:column;gap:14px">
      <label class="fld-lbl">Template name *
        <input type="text" id="sat-name" class="fld" value="${esc(defName)}">
      </label>
      <label class="fld-lbl">Frequency
        <select id="sat-freq" class="fld">
          ${['Weekly','Fortnightly','Monthly','Quarterly','Annual'].map(f=>`<option ${f==='Monthly'?'selected':''}>${f}</option>`).join('')}
        </select>
      </label>
      <label class="fld-lbl">Next due date
        <input type="date" id="sat-due" class="fld" value="${isoToday()}">
      </label>
    </div>
    <div class="modal-foot" style="gap:8px">
      <button class="btn btn-outline" id="sat-cancel">Cancel</button>
      <button class="btn btn-primary" id="sat-ok">Save Template</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  document.getElementById('sat-cancel').onclick = () => bd.remove();
  bd.addEventListener('click', e => { if (e.target === bd) bd.remove(); });

  document.getElementById('sat-ok').onclick = async () => {
    const name = document.getElementById('sat-name').value.trim();
    const due  = document.getElementById('sat-due').value;
    if (!name || !due) { toast('Name and due date are required', 'err'); return; }
    bd.remove();
    const linesJson = JSON.stringify((_editLines||[])
      .filter(l => l && l.line_type !== 'comment' && l.description)
      .map(l => ({description:l.description,quantity:l.quantity,unit_price:l.unit_price,
        tax_code:l.tax_code||'GST',account_id:l.account_id||null})));
    const payload = {
      name, template_type:'Invoice',
      frequency: document.getElementById('sat-freq').value,
      next_due: due, is_active: 1, contact_id: contactId,
      description: document.getElementById('edt-notes')?.value.trim() || '',
      lines_json: linesJson,
    };
    try {
      const r = await fetch('/api/recurring',{method:'POST',credentials:'include',
        headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Failed');
      toast('Template saved');
    } catch(e) { toast(e.message, 'err'); }
  };
}
