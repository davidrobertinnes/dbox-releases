// ═══════════════════════════════════════════════════════════════════════════
// INVOICES PAGE
// ═══════════════════════════════════════════════════════════════════════════
let _invAll=[],_invFilter='Due',_invSearch='',_invSort={col:'invoice_date',dir:-1},_invSelected=null,_bankAccts=[];
let _invGSTReg = null; // null = not yet loaded; true/false from company.gst_registered
const INV_STATS=['Due','Draft','Overdue','Paid','Void','All'];
const INV_BADGE={Paid:'badge-paid',Draft:'badge-draft',Sent:'badge-pending',Partial:'badge-partial',Overdue:'badge-overdue',Void:'badge-draft'};

function _effSt(inv) {
  if(['Paid','Void','Draft'].includes(inv.status)) return inv.status;
  const td=isoToday();
  if(inv.due_date&&inv.due_date<td) return 'Overdue';
  return inv.status;
}

async function pageInvoices() {
  if (_invGSTReg === null) {
    try { const me = await apiFetch('/api/me'); _invGSTReg = me ? me.gst_registered !== 0 : true; }
    catch(e) { _invGSTReg = true; }
  }
  try {
    const [invs,accts]=await Promise.all([apiFetch('/api/invoices'),apiFetch('/api/accounts')]);
    _invAll=invs||[]; _bankAccts=(accts||[]).filter(a=>a.is_bank);
    renderInvoicesPage();
  } catch(e){
    document.getElementById('module-content').innerHTML=`<div class="state-error">Failed to load invoices: ${esc(e.message)}</div>`;
  }
}

function _invFiltered() {
  const q=_invSearch.toLowerCase();
  return _invAll.filter(inv=>{
    if(_invFilter==='Due'){if(!['Sent','Partial','Overdue'].includes(_effSt(inv))) return false;}
    else if(_invFilter!=='All'&&_effSt(inv)!==_invFilter) return false;
    if(q&&![inv.invoice_number,inv.contact_name,inv.status].some(v=>(v||'').toLowerCase().includes(q))) return false;
    return true;
  }).sort((a,b)=>{
    const col=_invSort.col,av=a[col]??'',bv=b[col]??'';
    return(typeof av==='number'?(av-bv):String(av).localeCompare(String(bv)))*_invSort.dir;
  });
}

function renderInvoicesPage(restoreFocus) {
  const rows=_invFiltered();
  const counts=Object.fromEntries(INV_STATS.map(s=>[s,0]));
  counts['All']=_invAll.length;
  _invAll.forEach(inv=>{const s=_effSt(inv);if(s in counts)counts[s]++;if(['Sent','Partial','Overdue'].includes(s))counts['Due']++;});
  const mc=document.getElementById('module-content');
  mc.innerHTML=`
    <div class="inv-toolbar">
      <input class="inv-search" id="inv-q" placeholder="Search number, customer\u2026" value="${esc(_invSearch)}">
      <div class="inv-filter-group">
        ${INV_STATS.map(s=>`<button class="filter-btn${_invFilter===s?' active':''}" onclick="invFilter('${s}')">
          ${s}${counts[s]?` <span class="filter-count">(${counts[s]})</span>`:''}</button>`).join('')}
      </div>
      <button class="btn btn-primary" onclick="invNew()">+ New Invoice</button>
    </div>
    <div class="inv-list-panel"><div class="tbl-scroll">
      <table class="inv-list-table"><thead><tr>
        ${invTh('invoice_number','#')}${invTh('contact_name','Customer')}
        ${invTh('invoice_date','Date')}${invTh('due_date','Due')}
        ${invTh('total','Total','r')}${invTh('amount_paid','Paid','r')}
        <th>Balance</th>${invTh('status','Status')}
      </tr></thead><tbody>
        ${rows.length?rows.map(invRow).join(''):`<tr class="tbl-empty-row"><td colspan="8">No invoices match your filter</td></tr>`}
      </tbody></table>
    </div></div>
    <div class="mt-8"><span class="count-pill">${rows.length} of ${_invAll.length} invoice${_invAll.length!==1?'s':''}</span></div>`;
  const q=document.getElementById('inv-q');
  if(q){
    q.addEventListener('input',e=>{_invSearch=e.target.value;renderInvoicesPage(true);});
    if(restoreFocus){q.focus();q.setSelectionRange(q.value.length,q.value.length);}
  }
}

function invTh(col,label,align) {
  const sortCls=_invSort.col===col?(_invSort.dir>0?'sort-asc':'sort-desc'):'';
  const cls=[sortCls,align==='r'?'th-r':''].filter(Boolean).join(' ');
  return `<th class="${cls}" onclick="invSort('${col}')">${label}</th>`;
}

function invRow(inv) {
  const bal=(inv.total||0)-(inv.amount_paid||0),eff=_effSt(inv);
  const rc=eff==='Void'?'is-void':eff==='Paid'?'is-paid':eff==='Overdue'?'is-overdue':'';
  return `<tr class="inv-row ${rc}" onclick="invOpen(${inv.id})">
    <td><span class="inv-mono">${esc(inv.invoice_number||'#'+inv.id)}</span></td>
    <td><span class="inv-contact">${esc(inv.contact_name||'\u2014')}</span></td>
    <td><span class="inv-mono">${fmtDate(inv.invoice_date)}</span></td>
    <td><span class="inv-mono">${fmtDate(inv.due_date)}${eff==='Overdue'?' <span class="overdue-tag">OVERDUE</span>':''}</span></td>
    <td class="inv-amt">${fmt(inv.total)}</td>
    <td class="inv-amt inv-amt-paid">${(inv.amount_paid||0)>0?fmt(inv.amount_paid):'\u2014'}</td>
    <td class="inv-amt ${bal>0.005?'inv-amt-amber':'inv-amt-green'}">${fmt(bal)}</td>
    <td><span class="badge ${INV_BADGE[eff]||'badge-draft'}">${eff}</span></td>
  </tr>`;
}

function invSort(col){_invSort={col,dir:_invSort.col===col?_invSort.dir*-1:1};renderInvoicesPage();}
function invFilter(f){_invFilter=f;renderInvoicesPage();}
async function invNew(opts={}){
  const td=isoToday();
  const due=isoAddDays(30);
  let defPmt='';
  try{const co=await apiFetch('/api/company');defPmt=co.default_payment_instructions||'';}catch(e){}
  const blank={invoice:{id:null,contact_id:opts.contact_id||null,opp_id:opts.opp_id||null,invoice_date:td,due_date:due,status:'Draft',
    invoice_number:'',notes:'',payment_instructions:defPmt,internal_comments:'',subtotal:0,gst_total:0,total:0,amount_paid:0},lines:[]};
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent='New Invoice';
  document.getElementById('det-body').innerHTML='<div class="state-loading">Loading\u2026</div>';
  document.getElementById('det-foot').innerHTML='';
  await invEditOpen(blank);
}

async function invOpen(id) {
  _invSelected=id;
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-body').innerHTML='<div class="state-loading">Loading\u2026</div>';
  document.getElementById('det-foot').innerHTML='';
  document.getElementById('det-title').textContent='Invoice';
  try{const data=await apiFetch(`/api/invoices/${id}`);renderInvDetail(data);}
  catch(e){document.getElementById('det-body').innerHTML=`<div class="state-error">${esc(e.message)}</div>`;}
}

function renderInvDetail(data) {
  const inv=data.invoice,lines=data.lines||[],bal=(inv.total||0)-(inv.amount_paid||0),eff=_effSt(inv);
  document.getElementById('det-title').textContent=`Invoice ${inv.invoice_number||'#'+inv.id}`;
  const TABS=[['lines','\uD83D\uDCCB Lines'],['notes','\uD83D\uDCDD Notes'],['payment','\uD83C\uDFE6 Payment'],['comments','\uD83D\uDD12 Comments'],['attachments','\uD83D\uDCCE Attachments'],['activity','\uD83D\uDCEC Activity']];
  document.getElementById('det-body').innerHTML=`
    <div class="det-meta">
      <div><div class="det-lbl">Customer</div><div class="det-val">${esc(inv.contact_name||'\u2014')}</div></div>
      <div><div class="det-lbl">Status</div><div class="det-val"><span class="badge ${INV_BADGE[eff]||'badge-draft'}">${eff}</span></div></div>
      <div><div class="det-lbl">Invoice Date</div><div class="det-val mono">${fmtDate(inv.invoice_date)}</div></div>
      <div><div class="det-lbl">Due Date</div><div class="det-val mono">${fmtDate(inv.due_date)}${eff==='Overdue'?' <span class="overdue-tag overdue-tag-lg">OVERDUE</span>':''}</div></div>
      <div><div class="det-lbl">Total</div><div class="det-val mono det-val-lg det-val-accent">${fmt(inv.total)}</div></div>
      <div><div class="det-lbl">Balance</div><div class="det-val mono det-val-lg ${bal>0.005?'det-val-bal-amber':'det-val-bal-green'}">${fmt(bal)}</div></div>
    </div>
    <div class="det-tabs">${TABS.map(([k,l],i)=>`<div class="det-tab${i===0?' active':''}" data-tab="${k}" onclick="invTab('${k}')">${l}</div>`).join('')}</div>
    <div class="det-pane active" id="invt-lines">
      <table class="det-lines"><thead><tr><th>Description</th><th>Qty</th>
        <th class="th-r">Unit</th><th class="th-r">GST</th><th class="th-r">Total</th>
      </tr></thead><tbody>${lines.length?lines.map(l=>{
        if (l.line_type==='comment') {
          return `<tr class="inv-comment-row"><td colspan="5">${esc(l.description)}</td></tr>`;
        }
        const q=parseFloat(l.quantity)||0,p=parseFloat(l.unit_price)||0;
        const rate=(l.tax_code==='GST'||l.tax_code==='CAP')?0.1:0,gst=Math.round(q*p*rate*100)/100;
        return `<tr><td>${esc(l.description)}<span class="line-tax-code">${l.tax_code||'GST'}</span>${l.account_name?`<span class="line-acct-name">${esc(l.account_name)}</span>`:''}</td>
          <td class="td-c-mono">${q}</td>
          <td class="td-r-mono">${fmt(p)}</td>
          <td class="td-r-mono">${fmt(gst)}</td>
          <td class="td-r-mono-bold">${fmt(q*p+gst)}</td></tr>`;
      }).join(''):`<tr class="tbl-empty-sm"><td colspan="5">No line items</td></tr>`}
      </tbody></table>
      <div class="det-totals">
        <div class="det-tot-row"><span>Subtotal (ex GST)</span><span>${fmt(inv.subtotal)}</span></div>
        <div class="det-tot-row"><span>GST (10%)</span><span>${fmt(inv.gst_total)}</span></div>
        ${(inv.amount_paid||0)>0?`<div class="det-tot-row paid"><span>Paid</span><span>${fmt(inv.amount_paid)}</span></div>`:''}
        <div class="det-tot-row grand"><span>Total</span><span>${fmt(inv.total)}</span></div>
      </div>
    </div>
    <div class="det-pane" id="invt-notes">${inv.notes?`<div class="det-note">${esc(inv.notes)}</div>`:`<div class="det-empty">No customer notes.</div>`}</div>
    <div class="det-pane" id="invt-payment">${inv.payment_instructions?`<div class="det-note">${esc(inv.payment_instructions)}</div>`:`<div class="det-empty">No payment instructions.</div>`}</div>
    <div class="det-pane" id="invt-comments">${inv.internal_comments?`<div class="det-note">${esc(inv.internal_comments)}</div>`:`<div class="det-empty">No internal comments.</div>`}</div>
    <div class="det-pane" id="invt-attachments"><div class="det-empty det-loading-pad">Loading…</div></div>
    <div class="det-pane" id="invt-activity"><div class="det-empty det-loading-pad">Loading…</div></div>`;

  const foot=document.getElementById('det-foot'); foot.innerHTML='';
  const addBtn=(label,cls,fn)=>{const b=document.createElement('button');b.className=`btn ${cls}`;b.textContent=label;b.onclick=fn;foot.appendChild(b);};
  if(['Draft','Sent'].includes(inv.status))                addBtn('\u270F\uFE0F Edit','btn-outline',()=>invEditOpen(data));
  if(inv.status!=='Void'&&inv.status!=='Paid'&&bal>0.005) addBtn('\ud83d\uDCB0 Record Payment','btn-green',()=>payModalOpen(inv));
  if(inv.status==='Draft')                                 addBtn('\u2709 Mark Sent','btn-outline',()=>invMarkSent(inv.id));
  if(!['Void','Paid'].includes(inv.status))                addBtn('Void','btn-danger',()=>invVoid(inv.id));
  addBtn('\ud83d\udce7 Email','btn-outline',()=>invEmailOpen(inv));
  if(eff==='Overdue') addBtn('\u26A0 Overdue Notice','btn-amber',()=>invOverdueOpen(inv));
  if(eff==='Overdue'||inv.overdue_suppress) {
    const suppressLabel = inv.overdue_suppress ? '\u2713 Show stamp' : '\ud83d\uDEAB Suppress stamp';
    addBtn(suppressLabel,'btn-outline',()=>invToggleSuppress(inv));
  }
  addBtn('\u2399 Download PDF','btn-outline',()=>window.open(`/api/invoices/${inv.id}/pdf`));
  addBtn('+ New Invoice','btn-outline',invNew);
}

function invTab(key){
  document.querySelectorAll('.det-tab').forEach(t=>t.classList.toggle('active',t.dataset.tab===key));
  document.querySelectorAll('.det-pane').forEach(p=>p.classList.toggle('active',p.id===`invt-${key}`));
  if(key==='attachments'&&_invSelected&&(!_attLoadedFor||_attLoadedFor.type!=='invoice'||_attLoadedFor.id!==_invSelected)){
    _attLoad('invt-attachments','invoice',_invSelected);
  }
  if(key==='activity'&&_invSelected) _invLoadActivity(_invSelected);
}

async function _invLoadActivity(id) {
  const el=document.getElementById('invt-activity');
  if(!el) return;
  try {
    const rows=await apiFetch(`/api/invoices/${id}/activity`);
    if(!rows||!rows.length){el.innerHTML='<div class="det-empty">No activity yet — emails sent will appear here.</div>';return;}
    el.innerHTML=`<div class="inv-activity">${rows.map(r=>`
      <div class="inv-act-row">
        <span class="inv-act-date">${fmtDate(r.logged_at?.slice(0,10)||r.comm_date)}</span>
        <span class="inv-act-type">${esc(r.comm_type||'Email')}</span>
        <span class="inv-act-txt">${esc(r.subject||'(no subject)')}</span>
      </div>`).join('')}</div>`;
  } catch(e){el.innerHTML=`<div class="state-error">${esc(e.message)}</div>`;}
}
function detClose(){document.getElementById('det-overlay').classList.remove('open');document.getElementById('det-panel').classList.remove('open');_invSelected=null;_billSelected=null;_conSelected=null;_acctSelected=null;_pmtSelected=null;_recSelected=null;_crmSelected=null;if(typeof _qSelected!=="undefined")_qSelected=null;}

async function invMarkSent(id){
  try{const r=await fetch(`/api/invoices/${id}/mark-sent`,{method:'POST',credentials:'include'});const j=await r.json();if(!j.ok)throw new Error(j.error);toast('Marked as Sent');await _invRefresh(id);}
  catch(e){toast(e.message,'err');}
}
async function invVoid(id){
  if(!await confirmDlg('Void this invoice? This reverses the journal entries and cannot be undone.')) return;
  try{const r=await fetch(`/api/invoices/${id}/void`,{method:'POST',credentials:'include'});const j=await r.json();if(!j.ok)throw new Error(j.error);toast('Invoice voided');detClose();_invAll=(await apiFetch('/api/invoices'))||[];renderInvoicesPage();}
  catch(e){toast(e.message,'err');}
}
async function _invRefresh(id){
  _invAll=(await apiFetch('/api/invoices'))||[];renderInvoicesPage();
  if(_invSelected===id){try{renderInvDetail(await apiFetch(`/api/invoices/${id}`));}catch(e){}}
}

async function invEmailOpen(inv) {
  const num=inv.invoice_number||('#'+inv.id);
  const bd=document.createElement('div');
  bd.className='modal-bd'; bd.style.display='flex';
  bd.innerHTML=`<div class="modal-box" style="width:min(560px,96vw)">
    <div class="modal-title">Email Invoice ${esc(num)}</div>
    <div class="modal-field"><label class="modal-lbl">To *</label>
      <input class="modal-inp" type="email" id="eml-to" placeholder="recipient@example.com"></div>
    <div class="modal-field"><label class="modal-lbl">Subject</label>
      <input class="modal-inp" type="text" id="eml-subj" value="${esc('Invoice '+num)}"></div>
    <div class="modal-field"><label class="modal-lbl">Message</label>
      <textarea class="modal-inp" id="eml-body" rows="5" style="resize:vertical;min-height:90px"></textarea></div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary btn-sm" id="eml-send-btn" onclick="_invDoEmail(${inv.id})">📧 Send</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  try {
    const [contact, settings]=await Promise.all([
      apiFetch(`/api/contacts/${inv.contact_id}`),
      apiFetch('/api/settings/email'),
    ]);
    if(contact?.email) document.getElementById('eml-to').value=contact.email;
    const sub=(settings?.invoice_subject||'Invoice {invoice_number} from {company_name}')
      .replace('{invoice_number}',num).replace('{customer}',inv.contact_name||'');
    const bdy=(settings?.invoice_body||`Please find attached invoice ${num}.\n\nThank you.`)
      .replace('{invoice_number}',num).replace('{total}',fmt(inv.total))
      .replace('{due_date}',inv.due_date||'').replace('{customer}',inv.contact_name||'');
    const subjEl=document.getElementById('eml-subj');
    const bodyEl=document.getElementById('eml-body');
    if(subjEl) subjEl.value=sub;
    if(bodyEl) bodyEl.value=bdy;
  } catch(e){}
}

async function _invDoEmail(id) {
  const to=(document.getElementById('eml-to')?.value||'').trim();
  if(!to){toast('Recipient email is required','err');return;}
  const btn=document.getElementById('eml-send-btn');
  btn.disabled=true; btn.textContent='Sending…';
  try {
    const r=await fetch(`/api/invoices/${id}/email`,{method:'POST',credentials:'include',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({to,subject:document.getElementById('eml-subj')?.value||'',
        body:document.getElementById('eml-body')?.value||''})});
    const j=await r.json();
    if(!j.ok) throw new Error(j.error||'Send failed');
    btn.closest('.modal-bd')?.remove();
    toast('Invoice emailed');
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent='📧 Send';
  }
}

async function invOverdueOpen(inv) {
  const num=inv.invoice_number||('#'+inv.id);
  const bd=document.createElement('div');
  bd.className='modal-bd'; bd.style.display='flex';
  bd.innerHTML=`<div class="modal-box" style="width:min(560px,96vw)">
    <div class="modal-title">⚠ Overdue Notice — ${esc(num)}</div>
    <div class="modal-field"><label class="modal-lbl">To *</label>
      <input class="modal-inp" type="email" id="od-to" placeholder="recipient@example.com"></div>
    <div class="modal-field"><label class="modal-lbl">Subject</label>
      <input class="modal-inp" type="text" id="od-subj"></div>
    <div class="modal-field"><label class="modal-lbl">Message</label>
      <textarea class="modal-inp" id="od-body" rows="6" style="resize:vertical;min-height:100px"></textarea></div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-amber btn-sm" id="od-send-btn" onclick="_invDoOverdue(${inv.id})">⚠ Send Notice</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  try {
    const [contact, settings]=await Promise.all([
      apiFetch(`/api/contacts/${inv.contact_id}`),
      apiFetch('/api/settings/email'),
    ]);
    if(contact?.email) document.getElementById('od-to').value=contact.email;
    const today=isoToday(),due=inv.due_date||today;
    const days=Math.max(0,Math.round((new Date(today)-new Date(due))/(1000*86400)));
    const sub=(settings?.overdue_subject||'Overdue invoice {invoice_number} — {company_name}')
      .replace('{invoice_number}',num).replace('{company_name}','');
    const bdy=(settings?.overdue_body||`Dear ${inv.contact_name||''},\n\nThis is a reminder that invoice ${num} for ${fmt(inv.total)} was due on ${inv.due_date||''} and remains unpaid.\n\nPlease arrange payment at your earliest convenience.`)
      .replace('{invoice_number}',num).replace('{customer}',inv.contact_name||'')
      .replace('{total}',fmt(inv.total)).replace('{due_date}',inv.due_date||'')
      .replace('{days_overdue}',String(days));
    const subjEl=document.getElementById('od-subj');
    const bodyEl=document.getElementById('od-body');
    if(subjEl) subjEl.value=sub;
    if(bodyEl) bodyEl.value=bdy;
  } catch(e){}
}

async function _invDoOverdue(id) {
  const to=(document.getElementById('od-to')?.value||'').trim();
  if(!to){toast('Recipient email is required','err');return;}
  const btn=document.getElementById('od-send-btn');
  btn.disabled=true; btn.textContent='Sending…';
  try {
    const r=await fetch(`/api/invoices/${id}/overdue-notice`,{method:'POST',credentials:'include',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({to,subject:document.getElementById('od-subj')?.value||'',
        body:document.getElementById('od-body')?.value||''})});
    const j=await r.json();
    if(!j.ok) throw new Error(j.error||'Send failed');
    btn.closest('.modal-bd')?.remove();
    toast('Overdue notice sent');
    await _invRefresh(id);
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent='⚠ Send Notice';
  }
}

async function invToggleSuppress(inv) {
  const newSuppress = inv.overdue_suppress ? 0 : 1;
  const label = newSuppress ? 'suppress' : 'restore';
  if(!await confirmDlg(`This will ${label} the OVERDUE stamp on the PDF for this invoice. Continue?`)) return;
  try {
    const r=await fetch(`/api/invoices/${inv.id}/suppress-stamp`,{method:'POST',credentials:'include',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({suppress:newSuppress})});
    const j=await r.json();
    if(!j.ok) throw new Error(j.error);
    toast(newSuppress ? 'OVERDUE stamp suppressed' : 'OVERDUE stamp restored');
    await _invRefresh(inv.id);
  } catch(e){toast(e.message,'err');}
}

// ── Invoice inline editor ─────────────────────────────────────────────────
let _editData = null;      // {invoice, lines} currently being edited
let _editLines = [];       // [{desc,qty,price,tax,gst,total,account_id}, ...]
let _editAccts = [];       // income/revenue accounts for the line account picker
let _editContacts = null;  // contact list cache (shared across edit sessions)

async function invEditOpen(data) {
  _editData  = data;
  const _defTax = _invGSTReg ? 'GST' : 'INP';
  _editLines = (data.lines||[]).map(l=>({
    description: l.description||'', quantity: parseFloat(l.quantity)||1,
    unit_price:  parseFloat(l.unit_price)||0, tax_code: l.tax_code||_defTax,
    account_id:  l.account_id||null, item_id: l.item_id||null,
    line_type:   l.line_type||'item',
  }));
  if (_editLines.length===0) _editLines.push({description:'',quantity:1,unit_price:0,tax_code:_defTax,account_id:null,line_type:'item'});

  // Fetch contacts + accounts if not already loaded
  try {
    const [contacts, accts] = await Promise.all([
      _editContacts ? Promise.resolve(_editContacts) : apiFetch('/api/contacts'),
      _editAccts.length  ? Promise.resolve(_editAccts)   : apiFetch('/api/accounts'),
    ]);
    _editContacts = contacts||[];
    _editAccts    = (accts||[]).filter(a=>['Revenue','Income','Other Income'].includes(a.account_type));
    if (_editAccts.length===0) _editAccts = (accts||[]).filter(a=>a.account_type);
  } catch(e) { toast('Could not load contacts/accounts: '+e.message,'err'); return; }

  invEditRender();
}

function invEditRender() {
  const inv = _editData.invoice;

  // Contact options
  const custOpts = (_editContacts||[])
    .filter(c=>c.contact_type==='Customer'||c.contact_type==='Both'||!c.contact_type)
    .map(c=>`<option value="${c.id}" ${c.id===inv.contact_id?'selected':''}>${esc(c.name)}</option>`)
    .join('');

  // Line rows HTML
  const linesHtml = _editLines.map((l,i)=>_editLineHtml(i,l)).join('');

  // Totals preview
  const {sub,gst,total} = _editTotals();

  document.getElementById('det-body').innerHTML = `
    <div class="edt-section">
      <div class="edt-row">
        <div class="edt-field">
          <label class="edt-lbl">Customer *</label>
          <select class="edt-sel" id="edt-contact" onchange="invContactChanged()">${custOpts}</select>
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Status</label>
          <select class="edt-sel" id="edt-status">
            <option ${inv.status==='Draft'?'selected':''}>Draft</option>
            <option ${inv.status==='Sent'?'selected':''}>Sent</option>
          </select>
        </div>
      </div>
      <div class="edt-row">
        <div class="edt-field">
          <label class="edt-lbl">Invoice Date *</label>
          <input class="edt-inp" type="date" id="edt-date" value="${inv.invoice_date||''}">
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Due Date *</label>
          <input class="edt-inp" type="date" id="edt-due" value="${inv.due_date||''}">
        </div>
      </div>
    </div>

    <div class="edt-divider"></div>

    <div class="edt-section">
      <div class="edt-lines-hdr">
        <span></span><span>Description</span><span>Qty</span><span>Unit Price</span>
        <span>Tax</span><span class="span-r">GST</span>
        <span class="span-r">Total</span><span></span>
      </div>
      <div id="edt-lines-body">${linesHtml}</div>
      <button class="btn btn-outline edt-add-btn" onclick="editAddLine()">+ Add Line</button>
      <div class="edt-totals-preview" id="edt-totals">
        <span><span>Subtotal (ex GST)</span><b>${fmt(sub)}</b></span>
        <span><span>GST (10%)</span><b>${fmt(gst)}</b></span>
        <span class="grand"><span>Total</span><b>${fmt(total)}</b></span>
      </div>
    </div>

    <div class="edt-divider"></div>

    <div class="edt-section">
      <div class="edt-field edt-field-mb">
        <label class="edt-lbl">Customer Notes (printed on invoice)</label>
        <textarea class="edt-ta" id="edt-notes">${esc(inv.notes||'')}</textarea>
      </div>
      <div class="edt-field edt-field-mb">
        <label class="edt-lbl">Payment Instructions (printed on invoice)</label>
        <textarea class="edt-ta" id="edt-payment">${esc(inv.payment_instructions||'')}</textarea>
      </div>
      <div class="edt-field">
        <label class="edt-lbl">Internal Comments (not printed)</label>
        <textarea class="edt-ta" id="edt-comments">${esc(inv.internal_comments||'')}</textarea>
      </div>
    </div>

    <div class="edt-divider"></div>

    <div class="edt-section">
      <div class="edt-lbl" style="margin-bottom:8px">📎 Attachments</div>
      ${inv.id
        ? `<div id="edt-att-pane"></div>`
        : `<div class="det-empty" style="font-size:12px">Save the invoice first, then open it to add attachments.</div>`
      }
    </div>`;

  // Load attachments pane for existing invoices
  if (inv.id) {
    // Use setTimeout so the DOM is ready before we try to populate the pane
    setTimeout(() => _attLoad('edt-att-pane', 'invoice', inv.id), 0);
  }

  // Swap footer buttons
  const foot = document.getElementById('det-foot');
  foot.innerHTML = '';
  const mk = (label,cls,fn)=>{const b=document.createElement('button');b.className=`btn ${cls}`;b.textContent=label;b.onclick=fn;foot.appendChild(b);};
  mk('Save Invoice','btn-primary',invEditSave);
  mk('Cancel','btn-outline',()=>{
    if (_editData && _editData.invoice && _editData.invoice.id) invOpen(_editData.invoice.id);
    else detClose();
  });

  // Wire typeaheads on item lines; auto-size any comment textareas
  _editLines.forEach((l,i) => {
    if (!l || l.line_type === 'comment') {
      setTimeout(()=>{ const ta=document.getElementById(`edt-desc-${i}`); if(ta) _invTaResize(ta); }, 0);
    } else {
      _wireInvLineTypeahead(i);
    }
  });
}

function _wireInvLineTypeahead(i) {
  const inp = document.getElementById(`edt-desc-${i}`);
  if (!inp || inp.dataset.taWired) return;
  inp.dataset.taWired = '1';
  _attachTypeahead(inp, item => {
    _editLines[i].description = item.description || item.name;
    _editLines[i].unit_price  = item.unit_price || 0;
    _editLines[i].tax_code    = item.tax_code || 'GST';
    _editLines[i].account_id  = item.account_id || null;
    _editLines[i].item_id     = item.id;
    // Push values back to DOM
    const row = document.getElementById(`edt-line-${i}`);
    if (row) {
      const inputs = row.querySelectorAll('input[type="number"]');
      if (inputs[1]) inputs[1].value = item.unit_price || 0;
      const taxSel = row.querySelector('.edt-line-row select');
      if (taxSel) taxSel.value = item.tax_code || 'GST';
      const acctSel = document.getElementById(`edt-acct-${i}`);
      if (acctSel && item.account_id) acctSel.value = item.account_id;
    }
    editLineSet(i, 'unit_price', item.unit_price || 0);
    _checkStock(item.id, _editLines[i].quantity || 1, `edt-stock-${i}`);
  });
}

function _editLineHtml(i, l) {
  const isComment = l.line_type === 'comment';
  const toggleBtn = `<button class="edt-type-btn${isComment?' is-comment':''}" title="${isComment?'Switch to item line':'Switch to comment line'}" onclick="editToggleLineType(${i})">${isComment?'T':'≡'}</button>`;
  if (isComment) {
    return `<div class="edt-line-wrap" id="edt-line-${i}">
    <div class="edt-line-row edt-comment-row">
      ${toggleBtn}
      <textarea class="edt-inp edt-comment-ta" id="edt-desc-${i}"
        placeholder="Comment or heading…"
        oninput="editLineSet(${i},'description',this.value);_invTaResize(this)">${esc(l.description)}</textarea>
      <button class="edt-rm-btn" onclick="editRemoveLine(${i})" title="Remove">✕</button>
    </div>
  </div>`;
  }
  const q=l.quantity||1, p=l.unit_price||0;
  const rate=(l.tax_code==='GST'||l.tax_code==='CAP')?0.1:0;
  const gst=Math.round(q*p*rate*100)/100, total=q*p+gst;
  const acctOpts=_editAccts.map(a=>`<option value="${a.id}"${a.id===l.account_id?' selected':''}>${esc((a.code?a.code+' ':'')+a.name)}</option>`).join('');
  return `<div class="edt-line-wrap" id="edt-line-${i}">
    <div class="edt-line-row">
      ${toggleBtn}
      <input class="edt-inp" type="text" placeholder="Description or search catalogue…"
        id="edt-desc-${i}" value="${esc(l.description)}" oninput="editLineSet(${i},'description',this.value)">
      <input class="edt-inp" type="number" min="0" step="any" value="${q}"
        oninput="editLineSet(${i},'quantity',+this.value);_checkStock(_editLines[${i}]&&_editLines[${i}].item_id,+this.value,'edt-stock-${i}')">
      <input class="edt-inp" type="number" min="0" step="0.01" value="${p}"
        oninput="editLineSet(${i},'unit_price',+this.value)">
      <select class="edt-sel" onchange="editLineSet(${i},'tax_code',this.value)">
        ${['GST','FRE','INP','N-T','CAP'].map(t=>`<option${l.tax_code===t?' selected':''}>${t}</option>`).join('')}
      </select>
      <div class="edt-calc" id="edt-gst-${i}">${fmt(gst)}</div>
      <div class="edt-calc edt-calc-total" id="edt-tot-${i}">${fmt(total)}</div>
      <button class="edt-rm-btn" onclick="editRemoveLine(${i})" title="Remove">✕</button>
    </div>
    <div class="edt-line-acct">
      <span class="edt-acct-lbl">Account</span>
      <select class="edt-sel edt-acct-sel" id="edt-acct-${i}" onchange="editLineSet(${i},'account_id',this.value?+this.value:null)">
        <option value="">— default (Sales) —</option>${acctOpts}
      </select>
    </div>
    <div class="ta-stock-warn ta-stock-warn-row" id="edt-stock-${i}"></div>
  </div>`;
}

function editLineSet(i, field, val) {
  _editLines[i][field] = val;
  const l = _editLines[i];
  if (l.line_type === 'comment') { _editRefreshTotals(); return; }
  const q=l.quantity||0, p=l.unit_price||0;
  const rate=(l.tax_code==='GST'||l.tax_code==='CAP')?0.1:0;
  const gst=Math.round(q*p*rate*100)/100, total=q*p+gst;
  const gstEl=document.getElementById(`edt-gst-${i}`);
  const totEl=document.getElementById(`edt-tot-${i}`);
  if(gstEl) gstEl.textContent=fmt(gst);
  if(totEl) totEl.textContent=fmt(total);
  _editRefreshTotals();
}

function editToggleLineType(i) {
  const l = _editLines[i];
  l.line_type = (l.line_type === 'comment') ? 'item' : 'comment';
  if (l.line_type === 'comment') {
    l.quantity = 0; l.unit_price = 0; l.account_id = null; l.item_id = null;
  } else {
    l.quantity = 1; l.unit_price = 0; l.tax_code = _invGSTReg ? 'GST' : 'INP';
  }
  const wrap = document.getElementById(`edt-line-${i}`);
  if (wrap) {
    const tmp = document.createElement('div');
    tmp.innerHTML = _editLineHtml(i, l);
    wrap.replaceWith(tmp.firstElementChild);
    if (l.line_type === 'item') _wireInvLineTypeahead(i);
    else setTimeout(()=>{ const ta=document.getElementById(`edt-desc-${i}`); if(ta){ta.focus();_invTaResize(ta);} }, 0);
  }
  _editRefreshTotals();
}

function _invTaResize(el) {
  el.style.height = 'auto';
  el.style.height = el.scrollHeight + 'px';
}

function editAddLine() {
  const i = _editLines.length;
  _editLines.push({description:'',quantity:1,unit_price:0,tax_code:_invGSTReg?'GST':'INP',account_id:null,item_id:null,line_type:'item'});
  const row = document.createElement('div');
  row.innerHTML = _editLineHtml(i, _editLines[i]);
  document.getElementById('edt-lines-body').appendChild(row.firstElementChild);
  _editRefreshTotals();
  _wireInvLineTypeahead(i);
  const el = document.getElementById(`edt-desc-${i}`);
  if (el) el.focus();
}

function editRemoveLine(i) {
  _editLines[i] = null;
  const el = document.getElementById(`edt-line-${i}`);
  if (el) el.remove();
  _editRefreshTotals();
}

function _editTotals() {
  let sub=0, gst=0;
  (_editLines||[]).forEach(l=>{
    if(!l || l.line_type==='comment') return;
    const q=l.quantity||0, p=l.unit_price||0;
    const rate=(l.tax_code==='GST'||l.tax_code==='CAP')?0.1:0;
    gst += Math.round(q*p*rate*100)/100;
    sub += q*p;
  });
  return {sub:Math.round(sub*100)/100, gst:Math.round(gst*100)/100, total:Math.round((sub+gst)*100)/100};
}

function _editRefreshTotals() {
  const {sub,gst,total} = _editTotals();
  const el = document.getElementById('edt-totals');
  if (el) el.innerHTML = `
    <span><span>Subtotal (ex GST)</span><b>${fmt(sub)}</b></span>
    <span><span>GST (10%)</span><b>${fmt(gst)}</b></span>
    <span class="grand"><span>Total</span><b>${fmt(total)}</b></span>`;
}

function invContactChanged() {
  const contactId = parseInt(document.getElementById('edt-contact').value);
  const contact   = (_editContacts||[]).find(c=>c.id===contactId);
  if (!contact) return;
  const terms   = contact.payment_terms || 30;
  const invDate = document.getElementById('edt-date').value || isoToday();
  document.getElementById('edt-due').value = isoDateAddDays(invDate, terms);
}

async function invEditSave() {
  const contactId = parseInt(document.getElementById('edt-contact').value);
  const contact   = (_editContacts||[]).find(c=>c.id===contactId);
  const invDate   = document.getElementById('edt-date').value;
  const dueDate   = document.getElementById('edt-due').value;
  const status    = document.getElementById('edt-status').value;

  if (!contactId)  { toast('Select a customer','err'); return; }
  if (!invDate)    { toast('Enter an invoice date','err'); return; }
  if (!dueDate)    { toast('Enter a due date','err'); return; }

  const lines = (_editLines||[]).filter(l=>l&&l.description.trim());
  if (!lines.length) { toast('Add at least one line item','err'); return; }

  const payload = {
    id:                   _editData.invoice.id,
    opp_id:               _editData.invoice.opp_id || null,
    contact_id:           contactId,
    contact_name:         contact ? contact.name : '',
    invoice_date:         invDate,
    due_date:             dueDate,
    status,
    notes:                document.getElementById('edt-notes').value,
    payment_instructions: document.getElementById('edt-payment').value,
    internal_comments:    document.getElementById('edt-comments').value,
    lines: lines.map(l=>({
      description: l.description,
      quantity:    l.line_type==='comment' ? 0 : l.quantity,
      unit_price:  l.line_type==='comment' ? 0 : l.unit_price,
      tax_code:    l.tax_code||'GST',
      account_id:  l.account_id||null,
      item_id:     l.item_id||null,
      line_type:   l.line_type||'item',
    })),
  };

  const btn = document.querySelector('.det-foot .btn-primary');
  if (btn) { btn.disabled=true; btn.textContent='Saving…'; }

  try {
    let r, j;
    if (payload.id) {
      r = await fetch(`/api/invoices/${payload.id}`, {
        method:'PUT', headers:{'Content-Type':'application/json'},
        credentials:'include', body:JSON.stringify(payload),
      });
      j = await r.json();
      if (!j.ok) throw new Error(j.error);
      toast('Invoice saved');
      _editData = null; _editLines = [];
      await _invRefresh(payload.id);
      invOpen(payload.id);
    } else {
      r = await fetch('/api/invoices', {
        method:'POST', headers:{'Content-Type':'application/json'},
        credentials:'include', body:JSON.stringify(payload),
      });
      j = await r.json();
      if (!j.ok) throw new Error(j.error);
      toast('Invoice created');
      _editData = null; _editLines = [];
      _invAll = (await apiFetch('/api/invoices')) || []; renderInvoicesPage();
      invOpen(j.data.id);
    }
  } catch(e) {
    toast(e.message,'err');
    if (btn) { btn.disabled=false; btn.textContent='Save Invoice'; }
  }
}


let _pmId=null;
function payModalOpen(inv){
  _pmId=inv.id;const bal=(inv.total||0)-(inv.amount_paid||0);
  document.getElementById('pm-amount').value=bal.toFixed(2);
  document.getElementById('pm-date').value=isoToday();
  document.getElementById('pm-method').value='EFT';
  document.getElementById('pm-ref').value='';
  document.getElementById('pm-account').innerHTML=_bankAccts.length
    ?_bankAccts.map(a=>`<option value="${a.id}">${esc((a.code||'')+' '+a.name)}</option>`).join('')
    :'<option value="">— No bank accounts —</option>';
  document.getElementById('pay-modal').classList.add('open');
}
function payModalClose(){document.getElementById('pay-modal').classList.remove('open');_pmId=null;}
async function paySave(){
  const amount=parseFloat(document.getElementById('pm-amount').value);
  if(!amount||amount<=0){toast('Enter a valid amount','err');return;}
  const btn=document.getElementById('pm-save');btn.disabled=true;btn.textContent='Saving\u2026';
  try{
    const r=await fetch(`/api/invoices/${_pmId}/payment`,{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',
      body:JSON.stringify({amount,payment_date:document.getElementById('pm-date').value,method:document.getElementById('pm-method').value,
        reference:document.getElementById('pm-ref').value,account_id:parseInt(document.getElementById('pm-account').value)||null})});
    const j=await r.json();if(!j.ok)throw new Error(j.error);
    toast('Payment recorded');payModalClose();await _invRefresh(_pmId);
  }catch(e){toast(e.message,'err');}
  finally{btn.disabled=false;btn.textContent='Save Payment';}
}

// ═══════════════════════════════════════════════════════════════════════════
// BILLS PAGE
// ═══════════════════════════════════════════════════════════════════════════
let _billAll=[],_billFilter='All',_billSearch='',_billSort={col:'bill_date',dir:-1},_billSelected=null;
const BILL_STATS=['All','Draft','Approved','Partial','Overdue','Paid','Void'];
const BILL_BADGE={Paid:'badge-paid',Draft:'badge-draft',Approved:'badge-pending',Partial:'badge-partial',Overdue:'badge-overdue',Void:'badge-draft'};

function _billEffSt(b) {
  if(['Paid','Void','Draft'].includes(b.status)) return b.status;
  const td=isoToday();
  if(b.due_date&&b.due_date<td) return 'Overdue';
  return b.status;
}


// ── Shared Attachments Panel ──────────────────────────────────────────────────
// Used by invoices, bills, and payments detail panes.
// _attLoadedFor tracks {type, id} to avoid re-fetching on re-render.
let _attLoadedFor = null;

function _attFmtSize(n) {
  if (!n) return '0 B';
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n/1024).toFixed(1) + ' KB';
  return (n/1048576).toFixed(1) + ' MB';
}

function _attIcon(mime) {
  if (!mime) return '📄';
  if (mime.startsWith('image/')) return '🖼';
  if (mime === 'application/pdf') return '📋';
  if (mime.includes('spreadsheet') || mime.includes('excel') || mime.endsWith('.xlsx')) return '📊';
  if (mime.includes('word') || mime.endsWith('.docx')) return '📝';
  return '📄';
}

function _attRenderPane(paneId, sourceType, sourceId, rows) {
  const pane = document.getElementById(paneId);
  if (!pane) return;
  if (!rows || !rows.length) {
    pane.innerHTML = `
      <div style="margin-bottom:10px">
        <button class="btn btn-outline btn-sm" onclick="_attUpload('${sourceType}',${sourceId},'${paneId}')">📎 Attach File</button>
      </div>
      <div class="det-empty">No attachments yet — attach receipts, photos, or documents.</div>`;
    return;
  }
  const rowsHtml = rows.map(a => `
    <div class="att-row" data-id="${a.id}">
      <span class="att-icon">${_attIcon(a.mime_type)}</span>
      <div class="att-info">
        <div class="att-filename">${esc(a.filename)}</div>
        <div class="att-meta">${_attFmtSize(a.file_size)}${a.description ? '  •  ' + esc(a.description) : ''}</div>
      </div>
      <div class="att-btns">
        <a class="btn btn-outline btn-sm" href="/api/attachments/${a.id}/download" download="${esc(a.filename)}">⬇ Download</a>
        <button class="btn btn-danger btn-sm" onclick="_attDelete(${a.id},'${sourceType}',${sourceId},'${paneId}')">✕</button>
      </div>
    </div>`).join('');
  pane.innerHTML = `
    <div style="margin-bottom:10px">
      <button class="btn btn-outline btn-sm" onclick="_attUpload('${sourceType}',${sourceId},'${paneId}')">📎 Attach File</button>
      <span class="count-pill" style="margin-left:8px">${rows.length} attachment${rows.length!==1?'s':''}</span>
    </div>
    <div class="att-list">${rowsHtml}</div>`;
}

async function _attLoad(paneId, sourceType, sourceId) {
  const pane = document.getElementById(paneId);
  if (!pane) return;
  pane.innerHTML = '<div class="state-loading det-loading-pad">Loading…</div>';
  try {
    const rows = await apiFetch(`/api/attachments/${sourceType}/${sourceId}`);
    _attLoadedFor = {type: sourceType, id: sourceId};
    _attRenderPane(paneId, sourceType, sourceId, rows || []);
  } catch(e) {
    pane.innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
  }
}

function _attUpload(sourceType, sourceId, paneId) {
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = '.pdf,.png,.jpg,.jpeg,.gif,.bmp,.webp,.doc,.docx,.xls,.xlsx,.csv,.txt,.zip,.eml';
  inp.onchange = async () => {
    const file = inp.files[0];
    if (!file) return;
    if (file.size > 20 * 1024 * 1024) { toast('File exceeds 20 MB limit', true); return; }
    const desc = (window.prompt(`Description for "${file.name}" (optional):`) || '').trim();
    const fd = new FormData();
    fd.append('file', file);
    fd.append('description', desc);
    try {
      const r = await fetch(`/api/attachments/${sourceType}/${sourceId}`, {
        method: 'POST', credentials: 'include', body: fd });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Upload failed');
      _attRenderPane(paneId, sourceType, sourceId, j.data || []);
      toast('Attachment saved');
    } catch(e) { toast(e.message, true); }
  };
  inp.click();
}

async function _attDelete(attId, sourceType, sourceId, paneId) {
  if (!await confirmDlg('Delete this attachment? This cannot be undone.')) return;
  try {
    const r = await fetch(`/api/attachments/${attId}`, {method:'DELETE', credentials:'include'});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Delete failed');
    toast('Attachment deleted');
    await _attLoad(paneId, sourceType, sourceId);
  } catch(e) { toast(e.message, true); }
}
