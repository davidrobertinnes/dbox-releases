// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.

// ═══════════════════════════════════════════════════════════════════════════
// wizard.js  —  Company setup wizard
//
// Triggered automatically on first run (company row absent) and available
// from Settings → Setup Wizard to configure a new company file.
//
// Namespace prefix: _sw  (avoids collision with budget.js _wiz* globals)
// Entry point:      pageWizard()
// ═══════════════════════════════════════════════════════════════════════════

var _swStep = 1;
var _swData = {};

async function pageWizard() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading…</div>';

  try {
    const company = await apiFetch('/api/company');
    if (company) _swData = { ...company };
  } catch(e) { _swData = {}; }

  _swStep = 1;
  mod.innerHTML = _swShell();
  _swRender();
}

function _swShell() {
  return `<div class="wiz-wrap">
    <div class="wiz-card">
      <div class="wiz-progress" id="wiz-progress"></div>
      <div class="wiz-body" id="wiz-body"></div>
      <div class="wiz-foot" id="wiz-foot"></div>
    </div>
  </div>`;
}

function _swRender() {
  _swProgress();
  [null, _swS1, _swS2, _swS3, _swS4, _swDone][_swStep]();
}

function _swProgress() {
  const labels = ['', 'Company', 'Identity', 'Address', 'Tax & FY'];
  document.getElementById('wiz-progress').innerHTML =
    `<div class="wiz-steps">` +
    [1,2,3,4].map(i =>
      `<div class="wiz-step-wrap">
        <div class="wiz-step-dot ${i < _swStep ? 'done' : i === _swStep ? 'active' : ''}">${i < _swStep ? '✓' : i}</div>
        <div class="wiz-step-lbl ${i === _swStep ? 'active' : ''}">${labels[i]}</div>
      </div>
      ${i < 4 ? `<div class="wiz-step-line ${i < _swStep ? 'done' : ''}"></div>` : ''}`
    ).join('') +
    `</div>`;
}

function _swS1() {
  const name = (_swData.name && _swData.name !== 'dbox') ? _swData.name : '';
  document.getElementById('wiz-body').innerHTML = `
    <div class="wiz-heading">Welcome to dbox</div>
    <div class="wiz-sub">Let's get your company file set up. This takes about 2 minutes.</div>
    <div class="wiz-field">
      <label class="wiz-lbl">Company Name <span class="wiz-req">*</span></label>
      <input class="wiz-inp" id="wiz-name" type="text" placeholder="e.g. Smith Plumbing" value="${esc(name)}" autocomplete="organization">
    </div>`;
  document.getElementById('wiz-foot').innerHTML = `
    <div class="wiz-foot-right">
      <button class="btn btn-primary" onclick="_swNext()">Next &rarr;</button>
    </div>`;
  setTimeout(() => document.getElementById('wiz-name')?.focus(), 40);
}

function _swS2() {
  document.getElementById('wiz-body').innerHTML = `
    <div class="wiz-heading">Business Identity</div>
    <div class="wiz-sub">Your ABN appears on invoices and is required for GST reporting.</div>
    <div class="wiz-grid-2">
      <div class="wiz-field">
        <label class="wiz-lbl">ABN</label>
        <input class="wiz-inp" id="wiz-abn" type="text" placeholder="00 000 000 000" value="${esc(_swData.abn||'')}">
      </div>
      <div class="wiz-field">
        <label class="wiz-lbl">ACN</label>
        <input class="wiz-inp" id="wiz-acn" type="text" placeholder="000 000 000" value="${esc(_swData.acn||'')}">
      </div>
      <div class="wiz-field">
        <label class="wiz-lbl">Phone</label>
        <input class="wiz-inp" id="wiz-phone" type="text" placeholder="(02) 0000 0000" value="${esc(_swData.phone||'')}">
      </div>
      <div class="wiz-field">
        <label class="wiz-lbl">Email</label>
        <input class="wiz-inp" id="wiz-email" type="email" placeholder="accounts@example.com.au" value="${esc(_swData.email||'')}">
      </div>
    </div>
    <div class="wiz-field" style="margin-top:2px">
      <label class="wiz-lbl">Website</label>
      <input class="wiz-inp" id="wiz-website" type="text" placeholder="www.example.com.au" value="${esc(_swData.website||'')}">
    </div>`;
  document.getElementById('wiz-foot').innerHTML = `
    <div class="wiz-foot-split">
      <button class="btn btn-outline" onclick="_swBack()">&larr; Back</button>
      <button class="btn btn-primary" onclick="_swNext()">Next &rarr;</button>
    </div>`;
}

function _swS3() {
  const AU_STATES = ['','NSW','VIC','QLD','WA','SA','TAS','ACT','NT'];
  document.getElementById('wiz-body').innerHTML = `
    <div class="wiz-heading">Business Address</div>
    <div class="wiz-sub">Used on invoices and statements.</div>
    <div class="wiz-field">
      <label class="wiz-lbl">Street Address</label>
      <input class="wiz-inp" id="wiz-address" type="text" placeholder="123 Main Street" value="${esc(_swData.address||'')}">
    </div>
    <div class="wiz-grid-3" style="margin-top:8px">
      <div class="wiz-field">
        <label class="wiz-lbl">City / Suburb</label>
        <input class="wiz-inp" id="wiz-city" type="text" placeholder="Sydney" value="${esc(_swData.city||'')}">
      </div>
      <div class="wiz-field">
        <label class="wiz-lbl">State</label>
        <select class="wiz-inp" id="wiz-state">
          ${AU_STATES.map(s => `<option value="${s}" ${(_swData.state||'') === s ? 'selected':''}>${s||'—'}</option>`).join('')}
        </select>
      </div>
      <div class="wiz-field">
        <label class="wiz-lbl">Postcode</label>
        <input class="wiz-inp" id="wiz-postcode" type="text" placeholder="2000" maxlength="4" value="${esc(_swData.postcode||'')}">
      </div>
    </div>`;
  document.getElementById('wiz-foot').innerHTML = `
    <div class="wiz-foot-split">
      <button class="btn btn-outline" onclick="_swBack()">&larr; Back</button>
      <button class="btn btn-primary" onclick="_swNext()">Next &rarr;</button>
    </div>`;
}

function _swS4() {
  const fyMonth = _swData.fy_start_month || 7;
  const months = ['January','February','March','April','May','June',
                  'July','August','September','October','November','December'];
  const gstChecked = _swData.gst_registered !== 0;
  document.getElementById('wiz-body').innerHTML = `
    <div class="wiz-heading">Tax &amp; Financial Year</div>
    <div class="wiz-sub">These settings affect GST reporting and your financial year date range.</div>
    <div class="wiz-check-row">
      <input type="checkbox" id="wiz-gst" ${gstChecked ? 'checked' : ''}>
      <label for="wiz-gst" class="wiz-check-lbl">Registered for GST</label>
    </div>
    <div class="wiz-hint">Required for businesses with annual turnover over $75,000.</div>
    <div class="wiz-field" style="margin-top:20px">
      <label class="wiz-lbl">Financial Year Start Month</label>
      <select class="wiz-inp wiz-inp-half" id="wiz-fy">
        ${months.map((m, i) => `<option value="${i+1}" ${fyMonth === i+1 ? 'selected':''}>${m}</option>`).join('')}
      </select>
      <div class="wiz-hint" style="margin-top:4px">Standard Australian financial year starts in July.</div>
    </div>`;
  document.getElementById('wiz-foot').innerHTML = `
    <div class="wiz-foot-split">
      <button class="btn btn-outline" onclick="_swBack()">&larr; Back</button>
      <button class="btn btn-primary" id="sw-finish-btn" onclick="_swNext()">Finish &rarr;</button>
    </div>`;
}

function _swDone() {
  const name = _swData.name || 'Your company';
  document.getElementById('wiz-progress').innerHTML = '';
  document.getElementById('wiz-body').innerHTML = `
    <div class="wiz-done">
      <div class="wiz-done-tick">✓</div>
      <div class="wiz-heading" style="margin-top:16px">${esc(name)} is ready</div>
      <div class="wiz-sub">Your company file is set up. Here are some suggested next steps.</div>
      <div class="wiz-next-steps">
        <div class="wiz-next-item" onclick="navigate('contacts')">
          <span class="wiz-next-icon">👥</span>
          <div>
            <div class="wiz-next-title">Add your first contact</div>
            <div class="wiz-next-desc">Customers and suppliers for invoices and bills</div>
          </div>
        </div>
        <div class="wiz-next-item" onclick="navigate('invoices')">
          <span class="wiz-next-icon">📄</span>
          <div>
            <div class="wiz-next-title">Create your first invoice</div>
            <div class="wiz-next-desc">Send a tax invoice to a customer</div>
          </div>
        </div>
        <div class="wiz-next-item" onclick="navigate('bankrec')">
          <span class="wiz-next-icon">🏦</span>
          <div>
            <div class="wiz-next-title">Set up bank reconciliation</div>
            <div class="wiz-next-desc">Connect your bank account and reconcile transactions</div>
          </div>
        </div>
        <div class="wiz-next-item" onclick="_swGoOpening()">
          <span class="wiz-next-icon">🧮</span>
          <div>
            <div class="wiz-next-title">Enter opening balances</div>
            <div class="wiz-next-desc">Bring in balances from your previous system</div>
          </div>
        </div>
      </div>
    </div>`;
  document.getElementById('wiz-foot').innerHTML = `
    <div class="wiz-foot-right">
      <button class="btn btn-primary" onclick="navigate('dashboard')">Go to Dashboard</button>
    </div>`;
}

function _swGoOpening() {
  navigate('settings');
  setTimeout(() => { if (typeof _setNav === 'function') _setNav('opening'); }, 120);
}

function _swCollect(step) {
  if (step === 1) {
    const name = document.getElementById('wiz-name')?.value.trim() || '';
    if (!name) { toast('Company name is required', 'err'); return false; }
    _swData.name = name;
  } else if (step === 2) {
    _swData.abn     = document.getElementById('wiz-abn')?.value.trim()    || '';
    _swData.acn     = document.getElementById('wiz-acn')?.value.trim()    || '';
    _swData.phone   = document.getElementById('wiz-phone')?.value.trim()  || '';
    _swData.email   = document.getElementById('wiz-email')?.value.trim()  || '';
    _swData.website = document.getElementById('wiz-website')?.value.trim()|| '';
  } else if (step === 3) {
    _swData.address  = document.getElementById('wiz-address')?.value.trim()  || '';
    _swData.city     = document.getElementById('wiz-city')?.value.trim()     || '';
    _swData.state    = document.getElementById('wiz-state')?.value           || '';
    _swData.postcode = document.getElementById('wiz-postcode')?.value.trim() || '';
  } else if (step === 4) {
    _swData.gst_registered = document.getElementById('wiz-gst')?.checked ? 1 : 0;
    _swData.fy_start_month = parseInt(document.getElementById('wiz-fy')?.value || '7');
  }
  return true;
}

async function _swNext() {
  if (!_swCollect(_swStep)) return;

  if (_swStep === 4) {
    const btn = document.getElementById('sw-finish-btn');
    if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
    try {
      const r = await fetch('/api/company', {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(_swData),
      });
      const j = await r.json();
      if (!j.ok) {
        toast(j.error || 'Save failed', 'err');
        if (btn) { btn.disabled = false; btn.innerHTML = 'Finish &rarr;'; }
        return;
      }
      const cn = document.getElementById('company-name');
      if (cn) cn.textContent = _swData.name || '';
    } catch(e) {
      toast('Save failed — check connection', 'err');
      if (btn) { btn.disabled = false; btn.innerHTML = 'Finish &rarr;'; }
      return;
    }
    _swStep = 5;
    _swRender();
    return;
  }

  _swStep++;
  _swRender();
}

function _swBack() {
  _swCollect(_swStep);
  _swStep--;
  _swRender();
}
