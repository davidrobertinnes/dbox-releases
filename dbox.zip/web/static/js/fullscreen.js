// Full screen for the sign-in page and Full Dogbox on a tablet or other device.
// (POS has its own copy in tablet.js, remembered separately.)
// Over http:// on the local network, Android Chrome won't install the page as an app,
// so it opens with the address bar. The Full screen button hides the browser's bars.
// Browsers only allow full screen after a tap, and leaving a page (signing in, a reload)
// ends it, so once it's been turned on the next tap anywhere puts it back. Exit full
// screen turns that off. Not shown on the computer running Dogbox, when installed as an
// app, or where the browser can't do it (e.g. iPhone).
const _DBOX_FS_KEY = 'dbox_fullscreen';

function _dboxFsEl() { return document.fullscreenElement || document.webkitFullscreenElement || null; }
function _dboxFsSupported() {
  const el = document.documentElement;
  const mainPc = ['127.0.0.1', 'localhost', '[::1]'].includes(location.hostname);
  // Not "display-mode: fullscreen", which also matches while the page is full screen
  const installed = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  return !!(el.requestFullscreen || el.webkitRequestFullscreen) && !installed && !mainPc;
}
function _dboxFsEnter() {
  const el = document.documentElement;
  const p = el.requestFullscreen ? el.requestFullscreen({ navigationUI: 'hide' }) : el.webkitRequestFullscreen();
  if (p && p.catch) p.catch(() => {});
}
function _dboxFsExit() {
  const p = document.exitFullscreen ? document.exitFullscreen() : document.webkitExitFullscreen?.();
  if (p && p.catch) p.catch(() => {});
}
function _dboxFsToggle() {
  if (_dboxFsEl()) { localStorage.setItem(_DBOX_FS_KEY, '0'); _dboxFsExit(); }
  else { localStorage.setItem(_DBOX_FS_KEY, '1'); _dboxFsEnter(); }
}

// Buttons: any element with class "dbox-fs-btn". Shown only where it works; the
// title (and a data-on / data-off label, if given) follows the current state.
function _dboxFsRefresh() {
  const ok = _dboxFsSupported(), on = !!_dboxFsEl();
  document.querySelectorAll('.dbox-fs-btn').forEach(b => {
    b.style.display = ok ? '' : 'none';
    b.title = on ? 'Exit full screen' : 'Full screen (hide the browser bars)';
    const lbl = on ? b.dataset.on : b.dataset.off;
    if (lbl) b.textContent = lbl;
    b.classList.toggle('dbox-fs-on', on);
  });
  _dboxFsNote(ok && !on && localStorage.getItem(_DBOX_FS_KEY) === '1');
}

// "Tap anywhere to return to full screen": shown while full screen is turned on but
// the browser has left it (after signing in or a reload), until the next tap.
function _dboxFsNote(show) {
  let n = document.getElementById('dbox-fs-note');
  if (!show) { if (n) n.remove(); return; }
  if (n || !document.body) return;
  n = document.createElement('div');
  n.id = 'dbox-fs-note';
  n.textContent = '⛶ Tap anywhere to return to full screen';
  n.style.cssText = 'position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:100000;' +
    'background:var(--ink,#1A2E45);color:#fff;padding:9px 16px;border-radius:20px;' +
    'font:500 14px "Instrument Sans",sans-serif;box-shadow:0 4px 14px rgba(0,0,0,.25);' +
    'opacity:.92;pointer-events:none;white-space:nowrap';
  document.body.appendChild(n);
}
['fullscreenchange', 'webkitfullscreenchange'].forEach(ev => document.addEventListener(ev, _dboxFsRefresh));
document.addEventListener('DOMContentLoaded', _dboxFsRefresh);

document.addEventListener('click', e => {
  if (localStorage.getItem(_DBOX_FS_KEY) !== '1' || _dboxFsEl() || !_dboxFsSupported()) return;
  if (e.target.closest && e.target.closest('.dbox-fs-btn')) return;
  _dboxFsEnter();
}, { capture: true });
