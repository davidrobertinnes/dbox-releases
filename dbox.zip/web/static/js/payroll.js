// ═══════════════════════════════════════════════════════════════════════════
// PAYROLL MODULE  —  Stage 5e  (write operations)
//   • Employee list — filter by type/status, search, sort, detail slide-over
//   • Employee create / edit form (all fields)
//   • Pay run list  — filter by FY/period, search, sort, detail slide-over
// ═══════════════════════════════════════════════════════════════════════════

// ── Payroll mutation helpers (POST/PUT/DELETE — unwraps ok/data envelope) ────
async function _pMut(method, path, body) {
  const r = await fetch(path, {
    method, credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body ?? {}),
  });
  let j;
  try { j = await r.json(); } catch(_) {
    throw new Error(`Server error (HTTP ${r.status})`);
  }
  if (!j.ok) throw new Error(j.error || `HTTP ${r.status}`);
  return j.data;
}
const _pPost = (p, b) => _pMut('POST',   p, b);
const _pPut  = (p, b) => _pMut('PUT',    p, b);
const _pDel  = p      => _pMut('DELETE', p);


// ═══════════════════════════════════════════════════════════════════════════
// SHARED PANEL HELPERS
// ═══════════════════════════════════════════════════════════════════════════

function _prPanelOpen(title) {
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = title;
  document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading…</div>';
  document.getElementById('det-foot').innerHTML = '';
}

function _prPanelError(msg) {
  document.getElementById('det-body').innerHTML =
    `<div class="state-error">${esc(msg)}</div>`;
}

// Shared detail-panel field renderer — (label, val, mono=false)
// For raw HTML values use fieldRaw(label, html).
const field    = (label, val, mono) =>
  `<div><div class="det-lbl">${label}</div>
   <div class="det-val${mono ? ' mono' : ''}">${esc(val ?? '—')}</div></div>`;
const fieldRaw = (label, html) =>
  `<div><div class="det-lbl">${label}</div>
   <div class="det-val">${html ?? '—'}</div></div>`;


// ═══════════════════════════════════════════════════════════════════════════
// PAYROLL PAGE — top-level entry point called by navigate('payroll')
// ═══════════════════════════════════════════════════════════════════════════

let _prView = 'employees';   // 'employees' | 'pay_runs' | 'leave' | 'stp' | 'super' | 'awards' | 'payg_rates' | 'payment_summaries'

async function pagePayroll() {
  const mc = document.getElementById('module-content');
  mc.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    if      (_prView === 'pay_runs') await _prLoadPayRuns();
    else if (_prView === 'leave')    await _prLoadLeave();
    else if (_prView === 'stp')      await _prLoadStp();
    else if (_prView === 'super')    await _prLoadSuper();
    else if (_prView === 'awards')   await _prLoadAwards();
    else if (_prView === 'payg_rates') await _prLoadPaygRates();
    else if (_prView === 'payment_summaries') await _prLoadPaymentSummaries();
    else                             await _prLoadEmployees();
  } catch (e) {
    mc.innerHTML = `<div class="state-error">Failed to load payroll: ${esc(e.message)}</div>`;
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// ── EMPLOYEES ───────────────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════

let _empAll    = [];
let _empFilter = 'All';           // employment type or 'Active' / 'Inactive' / 'All'
let _empSearch = '';
let _empSortState = { col: 'last_name', dir: 1 };

const EMP_TYPE_FILTERS = ['All', 'Full-time', 'Part-time', 'Casual', 'Inactive'];

async function _prLoadEmployees() {
  _prView = 'employees';
  // Fetch all employees (server returns active_only=True by default;
  // we pass ?all=1 to get inactive too so the Inactive filter pill works).
  _empAll = await apiFetch('/api/payroll/employees?all=1')
    .catch(() => apiFetch('/api/payroll/employees'));
  _empAll = _empAll || [];
  _renderEmployeesPage();
}

function _empFiltered() {
  const q = _empSearch.toLowerCase();
  return _empAll.filter(e => {
    if (_empFilter === 'Inactive') {
      if (e.is_active) return false;
    } else if (_empFilter !== 'All') {
      if (!e.is_active) return false;
      if (e.employment_type !== _empFilter) return false;
    } else {
      if (!e.is_active) return false;  // 'All' still shows only active
    }
    if (q && ![ e.first_name, e.last_name, e.employee_number,
                e.position_title, e.department, e.employment_type ]
              .some(v => (v || '').toLowerCase().includes(q))) return false;
    return true;
  }).sort((a, b) => {
    const col = _empSortState.col;
    const av = a[col] ?? '', bv = b[col] ?? '';
    return (typeof av === 'number' ? (av - bv) : String(av).localeCompare(String(bv)))
           * _empSortState.dir;
  });
}

function _renderEmployeesPage(restoreFocus) {
  const rows   = _empFiltered();
  const active = _empAll.filter(e => e.is_active).length;
  const mc     = document.getElementById('module-content');

  // Counts per filter pill
  const typeCounts = {};
  EMP_TYPE_FILTERS.forEach(f => { typeCounts[f] = 0; });
  typeCounts['All'] = _empAll.filter(e => e.is_active).length;
  typeCounts['Inactive'] = _empAll.filter(e => !e.is_active).length;
  _empAll.filter(e => e.is_active).forEach(e => {
    if (e.employment_type in typeCounts) typeCounts[e.employment_type]++;
  });

  mc.innerHTML = `
    <div class="inv-toolbar">
      <input class="inv-search" id="emp-q" placeholder="Search name, number, title…"
             value="${esc(_empSearch)}">
      <div class="inv-filter-group">
        ${EMP_TYPE_FILTERS.map(f => `
          <button class="filter-btn${_empFilter === f ? ' active' : ''}"
                  onclick="_empSetFilter('${f}')">
            ${f}${typeCounts[f] ? ` <span class="pr-pill-count">(${typeCounts[f]})</span>` : ''}
          </button>`).join('')}
      </div>
      <div class="pr-toolbar-actions">
        <button class="btn btn-primary" onclick="_empFormOpen(null)">+ New Employee</button>
        <button class="btn btn-outline" onclick="_prLoadPayRuns()" title="Switch to Pay Runs">
          ₿ Pay Runs
        </button>
        <button class="btn btn-outline" onclick="_prLoadLeave()" title="Leave Management">
          🌿 Leave
        </button>
        <button class="btn btn-outline" onclick="_prLoadAwards()" title="Awards &amp; Agreements">
          📋 Awards
        </button>
        <button class="btn btn-outline" onclick="_prLoadPaygRates()" title="PAYG Tax Rates">
          🧮 PAYG Rates
        </button>
        <button class="btn btn-outline" onclick="_prLoadPaymentSummaries()" title="PAYG Payment Summaries">
          📄 Summaries
        </button>
      </div>
    </div>

    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        ${_empTh('employee_number', '#')}
        ${_empTh('last_name', 'Name')}
        ${_empTh('employment_type', 'Type')}
        ${_empTh('position_title', 'Position')}
        ${_empTh('department', 'Dept')}
        ${_empTh('pay_frequency', 'Frequency')}
        ${_empTh('annual_salary', 'Salary / Rate', 'r')}
        <th>Status</th>
      </tr></thead><tbody>
        ${rows.length
          ? rows.map(_empRow).join('')
          : `<tr><td colspan="8" class="tbl-empty-row">
               No employees match your filter</td></tr>`}
      </tbody></table>
    </div></div>
    <div class="mt-8">
      <span class="count-pill">${rows.length} of ${active} active employee${active !== 1 ? 's' : ''}</span>
    </div>`;

  const q = document.getElementById('emp-q');
  if(q){
    q.addEventListener('input', e => { _empSearch = e.target.value; _renderEmployeesPage(true); });
    if(restoreFocus){q.focus();q.setSelectionRange(q.value.length,q.value.length);}
  }
}

function _empTh(col, label, align) {
  const cls = _empSortState.col === col ? (_empSortState.dir > 0 ? 'sort-asc' : 'sort-desc') : '';
  const ra  = align === 'r' ? ' col-r' : '';
  return `<th class="${cls}${ra}" onclick="_empSort('${col}')">${label}</th>`;
}

function _empResolvedRate(e) {
  // Apply pay_rate_modifier to hourly_rate if present, matching desktop logic.
  if (!e.hourly_rate) return null;
  const base = parseFloat(e.hourly_rate);
  const mod  = parseFloat(e.pay_rate_modifier) || 0;
  if (mod === 0) return base;
  return e.pay_rate_modifier_type === '$' ? base + mod : base * (1 + mod / 100);
}

function _empRow(e) {
  const name     = `${e.last_name}, ${e.first_name}`;
  const resolved = _empResolvedRate(e);
  const rate  = e.annual_salary
    ? fmt(e.annual_salary) + ' <span class="pr-sub">p.a.</span>'
    : resolved != null
    ? fmt(resolved) + ' <span class="pr-sub">/hr</span>'
    : '—';
  const badge = e.is_active
    ? `<span class="badge badge-paid">${e.employment_type || 'Active'}</span>`
    : `<span class="badge badge-draft">Inactive</span>`;
  return `<tr class="inv-row" onclick="_empOpen(${e.id})">
    <td><span class="inv-mono">${esc(e.employee_number || '#' + e.id)}</span></td>
    <td><span class="inv-contact">${esc(name)}</span></td>
    <td>${esc(e.employment_type || '—')}</td>
    <td>${esc(e.position_title || '—')}</td>
    <td>${esc(e.department || '—')}</td>
    <td><span class="inv-mono">${esc(e.pay_frequency || '—')}</span></td>
    <td class="inv-amt">${rate}</td>
    <td>${badge}</td>
  </tr>`;
}

function _empSort(col) {
  _empSortState = { col, dir: _empSortState.col === col ? _empSortState.dir * -1 : 1 };
  _renderEmployeesPage();
}

function _empSetFilter(f) {
  _empFilter = f;
  _renderEmployeesPage();
}

// ── Employee detail slide-over ────────────────────────────────────────────────

async function _empOpen(id) {
  _prPanelOpen('Employee');
  try {
    const emp = await apiFetch(`/api/payroll/employees/${id}`);
    if (!emp) throw new Error('Employee not found');
    _renderEmpDetail(emp);
  } catch (err) {
    _prPanelError(err.message);
  }
}

function _renderEmpDetail(e) {
  const name = `${e.first_name} ${e.last_name}`;
  document.getElementById('det-title').textContent = name;

  const yesno = v => v ? 'Yes' : 'No';

  const rate = e.annual_salary
    ? `${fmt(e.annual_salary)} p.a.`
    : e.hourly_rate
    ? `${fmt(e.hourly_rate)} / hr`
    : '—';

  document.getElementById('det-body').innerHTML = `
    <div class="det-meta">
      ${field('Employee #',     e.employee_number)}
      ${field('Employment Type', e.employment_type)}
      ${field('Status',          e.is_active ? 'Active' : 'Inactive')}
      ${field('Pay Frequency',   e.pay_frequency)}
    </div>

    <div class="det-section-title">Personal</div>
    <div class="det-meta">
      ${field('First Name',   e.first_name)}
      ${field('Last Name',    e.last_name)}
      ${field('Date of Birth', e.date_of_birth, true)}
      ${field('Gender',        e.gender)}
    </div>
    <div class="det-meta det-meta-mt">
      ${field('Email',   e.email)}
      ${field('Phone',   e.phone)}
      ${field('Address', [e.address, e.city, e.state, e.postcode].filter(Boolean).join(', '))}
    </div>

    <div class="det-section-title">Employment</div>
    <div class="det-meta">
      ${field('Position',     e.position_title)}
      ${field('Department',   e.department)}
      ${field('Start Date',   e.start_date,        true)}
      ${field('End Date',     e.termination_date || 'Current', true)}
    </div>

    <div class="det-section-title">Pay</div>
    <div class="det-meta">
      ${field('Rate',            rate)}
      ${field('Hours / Week',    e.hours_per_week != null ? e.hours_per_week + ' hrs' : '—')}
      ${field('Tax-Free Threshold', yesno(e.has_tax_free_threshold))}
      ${field('TFN Quoted',      yesno(e.tfn_quoted))}
      ${field('Study Loan',      yesno(e.study_loan))}
      ${field('Senior Offset',   yesno(e.senior_offset))}
    </div>
    ${(e.additional_withholding || e.salary_sacrifice_amount || e.voluntary_super_amount) ? `
    <div class="det-meta det-meta-mt">
      ${e.additional_withholding  ? field('Additional Withholding', fmt(e.additional_withholding) + ' / period', true) : ''}
      ${e.salary_sacrifice_amount ? field('Salary Sacrifice',       fmt(e.salary_sacrifice_amount) + ' / period', true) : ''}
      ${e.voluntary_super_amount  ? field('Voluntary Super',        fmt(e.voluntary_super_amount) + ' / period', true) : ''}
    </div>` : ''}

    <div class="det-section-title">Award / Agreement</div>
    <div class="det-meta" id="emp-det-award">
      ${e.award_id
        ? `<div><div class="det-lbl">Award / Agreement</div>
             <div class="det-val" id="emp-det-award-name">Loading…</div></div>
           <div><div class="det-lbl">Classification</div>
             <div class="det-val" id="emp-det-cls-name">Loading…</div></div>
           <div><div class="det-lbl">Pay Point</div>
             <div class="det-val mono">${esc(e.pay_point != null ? String(e.pay_point) : '—')}</div></div>
           <div><div class="det-lbl">Rate Modifier</div>
             <div class="det-val mono">${e.pay_rate_modifier != null
               ? `${e.pay_rate_modifier}${e.pay_rate_modifier_type || '%'}`
               : '—'}</div></div>`
        : `<div class="pr-no-award-note">No award or agreement linked.</div>`
      }
    </div>

    <div class="det-section-title">Superannuation</div>
    <div class="det-meta">
      ${field('Fund Name',      e.super_fund_name)}
      ${field('Fund ABN',       e.super_fund_abn, true)}
      ${field('Fund USI',       e.super_fund_usi, true)}
      ${field('Member Number',  e.super_member_number, true)}
      ${field('Rate Override',  e.super_rate_override != null ? (e.super_rate_override * 100).toFixed(2) + '%' : 'Standard SG')}
    </div>

    <div class="det-section-title">Bank</div>
    <div class="det-meta">
      ${field('Bank Name',    e.bank_name)}
      ${field('BSB',          e.bank_bsb, true)}
      ${field('Account No.',  e.bank_account, true)}
    </div>

    <div class="det-section-title">YTD Totals</div>
    <div class="det-meta">
      ${field('Gross',       fmt(e.ytd_gross || 0), true)}
      ${field('Tax',         fmt(e.ytd_tax   || 0), true)}
      ${field('Super',       fmt(e.ytd_super || 0), true)}
      ${field('Allowances',  fmt(e.ytd_allowances || 0), true)}
    </div>

    ${!e.contact_id ? `
    <div class="pr-aba-warn">
      <span>⚠ No linked contact record — ABA payments won't be available.</span>
      <button class="btn btn-outline btn-sm pr-aba-warn-btn"
              onclick="_empLinkContact(${e.id},'${esc(e.first_name)} ${esc(e.last_name)}')">
        Link / Create Contact
      </button>
    </div>` : ''}

    <div class="det-section-title pr-section-title-gap">Recent Payslips</div>
    <div id="emp-det-payslips"><div class="pr-loading-note">Loading…</div></div>`;

  document.getElementById('det-foot').innerHTML =
    `<button class="btn btn-outline" onclick="detClose()">Close</button>
     <button class="btn btn-primary pr-det-foot-edit" onclick="_empFormOpen(${e.id})">Edit</button>`;

  // Async: resolve award / classification names
  if (e.award_id) _empDetailLoadAward(e);
  // Async: load payslip history
  _empDetailLoadPayslips(e.id);
}

// ── Resolve award + classification names for read-only detail view ─────────────

async function _empDetailLoadAward(e) {
  const awardNameEl = document.getElementById('emp-det-award-name');
  const clsNameEl   = document.getElementById('emp-det-cls-name');
  if (!awardNameEl) return;

  try {
    // Reuse cached award list if already loaded (e.g. form was opened earlier)
    let awards = _empAwardData.length ? _empAwardData : await apiFetch('/api/payroll/awards');
    const award = (awards || []).find(a => a.id === e.award_id);
    if (awardNameEl) awardNameEl.textContent =
      award ? (award.name + (award.instrument_type ? ` (${award.instrument_type})` : '')) : `ID ${e.award_id}`;

    if (e.classification_id) {
      const clsData = await apiFetch(`/api/payroll/awards/${e.award_id}/classifications`);
      const cls = (clsData || []).find(c => c.id === e.classification_id);
      if (clsNameEl) clsNameEl.textContent = cls
        ? ((cls.code ? `${cls.code} — ` : '') + cls.name +
           (cls.hourly_rate ? `  ($${parseFloat(cls.hourly_rate).toFixed(4)}/hr @ pay point ${e.pay_point || 1})` : ''))
        : `ID ${e.classification_id}`;
    } else {
      if (clsNameEl) clsNameEl.textContent = '—';
    }
  } catch (_) {
    if (awardNameEl) awardNameEl.textContent = `ID ${e.award_id}`;
    if (clsNameEl)   clsNameEl.textContent   = e.classification_id ? `ID ${e.classification_id}` : '—';
  }
}

// ── Payslip history for employee detail slide-over  (Stage 5R) ───────────────

async function _empDetailLoadPayslips(empId) {
  const container = document.getElementById('emp-det-payslips');
  if (!container) return;
  try {
    const slips = await apiFetch(`/api/payroll/employees/${empId}/payslips?limit=20`);
    if (!slips || !slips.length) {
      container.innerHTML = `<div class="pr-loading-note">No payslips on record.</div>`;
      return;
    }
    container.innerHTML = `
      <div class="tbl-overflow-x">
        <table class="inv-list-table pr-slip-tbl">
          <thead><tr>
            <th>Run #</th>
            <th>Payment Date</th>
            <th class="th-r">Gross</th>
            <th class="th-r">PAYG Tax</th>
            <th class="th-r">Net Pay</th>
            <th class="th-r">Super</th>
            <th>Run Status</th>
            <th class="td-c-mono">PDF</th>
          </tr></thead>
          <tbody>
            ${slips.map((s, i) => `
              <tr class="${i % 2 ? 'alt' : ''}">
                <td class="inv-mono">${esc(s.run_number || '#' + s.pay_run_id)}</td>
                <td class="inv-mono">${esc(s.payment_date || '—')}</td>
                <td class="inv-amt">${fmt(s.gross_pay || 0)}</td>
                <td class="inv-amt col-red">${fmt(s.payg_tax || 0)}</td>
                <td class="inv-amt col-green pr-net-bold">${fmt(s.net_pay || 0)}</td>
                <td class="inv-amt col-amber">${fmt(s.super_amount || 0)}</td>
                <td><span class="badge ${s.run_status === 'Finalised' || s.run_status === 'STP_Lodged' ? 'badge-paid' : 'badge-draft'}">${esc(s.run_status || '—')}</span></td>
                <td class="td-c-mono">
                  <button class="btn btn-xs btn-outline" title="Download payslip PDF"
                          onclick="_payslipDownloadPdf(${s.pay_run_id},${s.id})">⬇</button>
                </td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>`;
  } catch (err) {
    if (container) container.innerHTML = `<div class="pr-loading-note">Could not load payslips.</div>`;
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// ── EMPLOYEE CREATE / EDIT FORM ─────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════

async function _empFormOpen(id) {
  _prPanelOpen(id ? 'Edit Employee' : 'New Employee');
  try {
    let emp = {};
    if (id) {
      emp = await apiFetch(`/api/payroll/employees/${id}`);
      _empPriorTfn = emp.tfn || null;   // capture before user can edit
      // Resolve contact name for display in the picker
      if (emp.contact_id) {
        try {
          const con = await apiFetch(`/api/contacts/${emp.contact_id}`);
          emp._contact_name = con.name || '';
        } catch(_) {}
      }
    } else {
      _empPriorTfn = null;  // new employee — no prior TFN
      const res = await apiFetch('/api/payroll/next-employee-number').catch(() => ({}));
      emp = { employee_number: res.number || '', is_active: 1,
              employment_type: 'Full-time', pay_frequency: 'Fortnightly',
              hours_per_week: 38, tfn_quoted: 1, has_tax_free_threshold: 1,
              study_loan: 0, senior_offset: 0 };
    }
    _renderEmpForm(emp);
    if (id && (emp.first_name || emp.last_name)) {
      document.getElementById('det-title').textContent =
        [emp.first_name, emp.last_name].filter(Boolean).join(' ');
    }
  } catch (err) {
    _prPanelError(err.message);
  }
}

function _empFormField(id, label, value, type, opts) {
  type = type || 'text';
  opts = opts || {};
  const val  = value != null ? esc(String(value)) : '';
  const req  = opts.required ? ' required' : '';
  const mono = opts.mono ? ' pr-form-mono' : '';
  if (opts.select) {
    const options = opts.select.map(o =>
      `<option value="${esc(o)}"${o === value ? ' selected' : ''}>${esc(o)}</option>`
    ).join('');
    return `<div class="form-field">
      <label class="form-lbl" for="${id}">${label}</label>
      <select class="form-input" id="${id}" name="${id}"${req}><option value=""></option>${options}</select>
    </div>`;
  }
  if (opts.checkbox) {
    const chk = value ? ' checked' : '';
    return `<div class="form-field form-field-check">
      <input type="checkbox" id="${id}" name="${id}"${chk}>
      <label class="form-lbl" for="${id}">${label}</label>
    </div>`;
  }
  return `<div class="form-field">
    <label class="form-lbl" for="${id}">${label}</label>
    <input class="form-input${mono}" type="${type}" id="${id}" name="${id}"
           value="${val}"${req}>
  </div>`;
}

function _renderEmpForm(e) {
  const f = _empFormField;
  document.getElementById('det-body').innerHTML = `
    <form id="emp-form" onsubmit="return false">

      <div class="det-section-title">Personal</div>
      <div class="form-grid">
        ${f('first_name',    'First Name',    e.first_name,    'text',  {required:true})}
        ${f('last_name',     'Last Name',     e.last_name,     'text',  {required:true})}
        ${f('date_of_birth', 'Date of Birth', e.date_of_birth, 'date')}
        ${f('gender',        'Gender',        e.gender,        'text',  {select:['Male','Female','Non-binary','Prefer not to say']})}
        ${f('email',         'Email',         e.email,         'email')}
        ${f('phone',         'Phone',         e.phone,         'tel')}
      </div>
      <div class="form-grid form-grid-1">
        ${f('address', 'Street Address', e.address)}
      </div>
      <div class="form-grid">
        ${f('city',     'City / Suburb', e.city)}
        ${f('state',    'State',         e.state,    'text', {select:['ACT','NSW','NT','QLD','SA','TAS','VIC','WA']})}
        ${f('postcode', 'Postcode',      e.postcode)}
      </div>

      <div class="det-section-title pr-section-title-gap">Employment</div>
      <div class="form-grid form-grid-1 pr-form-mb">
        <div class="form-field">
          <label class="form-lbl">Linked Contact</label>
          <div class="pr-contact-row">
            <input class="form-input pr-contact-inp" id="emp-contact-search" placeholder="Search contacts…"
                   autocomplete="off"
                   value="${esc(e._contact_name || '')}"
                   oninput="_empContactSearch(this.value)">
            <input type="hidden" id="emp-contact-id" value="${e.contact_id || ''}">
            ${e.contact_id ? `<button type="button" class="btn btn-outline btn-sm pr-contact-clear" onclick="_empContactClear()">✕</button>` : ''}
          </div>
          <div id="emp-contact-drop" class="pr-contact-drop" style="display:none"></div>
          <div class="pr-contact-hint">
            Optional — links this employee to a contact record for ABA payments.
            <a href="#" onclick="_empContactCreateNew(event)" class="lnk-accent">Create new contact</a>
          </div>
        </div>
      </div>
      <div class="form-grid">
        ${f('employee_number', 'Employee Number', e.employee_number, 'text',   {required:true, mono:true})}
        ${f('employment_type', 'Employment Type', e.employment_type, 'text',   {required:true, select:['Full-time','Part-time','Casual']})}
        ${f('pay_frequency',   'Pay Frequency',   e.pay_frequency,   'text',   {required:true, select:['Weekly','Fortnightly','Monthly']})}
        ${f('hours_per_week',  'Hours / Week',    e.hours_per_week,  'number')}
        ${f('position_title',  'Position Title',  e.position_title)}
        ${f('department',      'Department',      e.department)}
        ${f('start_date',      'Start Date *',    e.start_date,      'date',  {required:true})}
        ${f('termination_date','End Date',        e.termination_date,'date')}
      </div>
      <div class="form-grid form-grid-check pr-form-check-mt">
        ${f('is_active', 'Active', e.is_active, 'checkbox', {checkbox:true})}
      </div>

      <div class="det-section-title pr-section-title-gap">Award / Agreement</div>
      <div class="form-grid form-grid-1 pr-form-mb-sm">
        <div class="form-field">
          <label class="form-lbl">Award / Agreement</label>
          <select class="form-input" id="emp-award-sel" name="award_id"
                  onchange="_empAwardChange(this.value)">
            <option value="">— None —</option>
          </select>
        </div>
      </div>
      <div class="form-grid pr-cls-row" id="emp-cls-row" style="display:none">
        <div class="form-field">
          <label class="form-lbl">Classification</label>
          <select class="form-input" id="emp-cls-sel" name="classification_id"
                  onchange="_empClsChange(this.value)">
            <option value="">— Select classification —</option>
          </select>
        </div>
        <div class="form-field">
          <label class="form-lbl">Pay Point</label>
          <input class="form-input pr-pay-point-inp" type="number" id="emp-pay-point" name="pay_point"
                 min="1" max="20" step="1" value="${e.pay_point || 1}"
                 oninput="_empPayPointChange(this.value)">
        </div>
      </div>
      <div class="form-grid pr-cls-row" id="emp-mod-row" style="display:none">
        <div class="form-field">
          <label class="form-lbl">Rate Modifier</label>
          <div class="pr-contact-row">
            <input class="form-input pr-mod-val-inp" type="number" id="emp-mod-val" name="pay_rate_modifier"
                   step="0.01" value="${e.pay_rate_modifier || ''}"
                   placeholder="0"
                   oninput="_empModChange()">
            <select class="form-input pr-mod-type-sel" id="emp-mod-type" name="pay_rate_modifier_type"
                    onchange="_empModChange()">
              <option value="%" ${(e.pay_rate_modifier_type||'%')==='%'?'selected':''}>%</option>
              <option value="$" ${e.pay_rate_modifier_type==='$'?'selected':''}>$</option>
            </select>
          </div>
        </div>
        <div class="form-field pr-rate-hint-field">
          <span id="emp-award-rate-hint" class="pr-rate-hint"></span>
        </div>
      </div>

      <div class="det-section-title pr-section-title-gap">Pay &amp; Tax</div>
      <div class="form-grid">
        ${f('annual_salary', 'Annual Salary',   e.annual_salary, 'number')}
        ${f('hourly_rate',   'Hourly Rate',     e.hourly_rate,   'number')}
        ${f('tfn',           'TFN',             e.tfn,           'text',  {mono:true})}
      </div>
      <div class="form-grid form-grid-check">
        ${f('tfn_quoted',            'TFN Quoted',                    e.tfn_quoted,             'checkbox', {checkbox:true})}
        ${f('has_tax_free_threshold','Tax-Free Threshold',            e.has_tax_free_threshold, 'checkbox', {checkbox:true})}
        ${f('study_loan',            'HELP / Study Loan',             e.study_loan,             'checkbox', {checkbox:true})}
        ${f('senior_offset',         'Senior &amp; Pensioner Offset', e.senior_offset,          'checkbox', {checkbox:true})}
      </div>
      <div class="form-grid pr-form-mt-sm">
        ${f('salary_sacrifice_amount', 'Salary Sacrifice / period',    e.salary_sacrifice_amount, 'number')}
        ${f('additional_withholding',  'Additional Withholding / period', e.additional_withholding,'number')}
        ${f('voluntary_super_amount',  'Voluntary Super / period',     e.voluntary_super_amount,  'number')}
      </div>

      <div class="det-section-title pr-section-title-gap">Superannuation</div>
      <div class="form-grid">
        ${f('super_fund_name',    'Fund Name',      e.super_fund_name)}
        ${f('super_fund_abn',     'Fund ABN',       e.super_fund_abn,     'text', {mono:true})}
        ${f('super_fund_usi',     'Fund USI',       e.super_fund_usi,     'text', {mono:true})}
        ${f('super_member_number','Member Number',  e.super_member_number,'text', {mono:true})}
        ${f('super_rate_override','Rate Override (e.g. 0.12)', e.super_rate_override, 'number')}
      </div>

      <div class="det-section-title pr-section-title-gap">Bank</div>
      <div class="form-grid">
        ${f('bank_name',    'Bank Name',   e.bank_name)}
        ${f('bank_bsb',     'BSB',         e.bank_bsb,     'text', {mono:true})}
        ${f('bank_account', 'Account No.', e.bank_account, 'text', {mono:true})}
      </div>

    </form>`;

  const isNew = !e.id;
  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-outline" onclick="${isNew ? 'detClose()' : `_empOpen(${e.id})`}">Cancel</button>
    <div id="emp-form-err" class="pr-form-err"></div>
    <button class="btn btn-primary" onclick="_empFormSave(${e.id || 'null'})">
      ${isNew ? 'Create Employee' : 'Save Changes'}
    </button>`;

  // Populate award dropdown then restore saved selection
  _empAwardInit(e);
}

// ── Award / Classification helpers ───────────────────────────────────────────

let _empAwardData   = [];   // [{id, name, instrument_type}]
let _empClsData     = [];   // [{id, name, code, hourly_rate}] for selected award
let _empAwardEmpRef = null; // employee data during form init
let _empPriorTfn    = null; // TFN value at time form was opened — used to detect changes

async function _empAwardInit(e) {
  _empAwardEmpRef = e;
  try {
    _empAwardData = await apiFetch('/api/payroll/awards');
  } catch(_) { _empAwardData = []; }
  const sel = document.getElementById('emp-award-sel');
  if (!sel) return;
  _empAwardData.forEach(a => {
    const opt = document.createElement('option');
    opt.value = a.id;
    opt.textContent = a.name + (a.instrument_type ? ` (${a.instrument_type})` : '');
    if (e.award_id && a.id === e.award_id) opt.selected = true;
    sel.appendChild(opt);
  });
  if (e.award_id) {
    await _empAwardLoad(e.award_id, e.classification_id);
  }
}

async function _empAwardChange(awardId) {
  const clsRow = document.getElementById('emp-cls-row');
  const modRow = document.getElementById('emp-mod-row');
  const clsSel = document.getElementById('emp-cls-sel');
  document.getElementById('emp-award-rate-hint').textContent = '';
  if (!awardId) {
    clsRow.style.display = 'none';
    modRow.style.display = 'none';
    return;
  }
  // Clear classification select while loading
  clsSel.innerHTML = '<option value="">Loading…</option>';
  clsRow.style.display = '';
  modRow.style.display = '';
  await _empAwardLoad(awardId, null);
}

async function _empAwardLoad(awardId, selectedClsId) {
  const clsSel = document.getElementById('emp-cls-sel');
  const clsRow = document.getElementById('emp-cls-row');
  const modRow = document.getElementById('emp-mod-row');
  try {
    _empClsData = await apiFetch(`/api/payroll/awards/${awardId}/classifications`);
  } catch(_) { _empClsData = []; }
  clsSel.innerHTML = '<option value="">— Select classification —</option>';
  _empClsData.forEach(c => {
    const opt = document.createElement('option');
    opt.value = c.id;
    const rateHint = c.hourly_rate ? ` — $${parseFloat(c.hourly_rate).toFixed(4)}/hr` : '';
    opt.textContent = (c.code ? `${c.code} ` : '') + c.name + rateHint;
    if (selectedClsId && c.id === selectedClsId) opt.selected = true;
    clsSel.appendChild(opt);
  });
  clsRow.style.display = '';
  modRow.style.display = '';
  if (selectedClsId) _empClsChange(selectedClsId);
}

function _empClsChange(clsId) {
  _empUpdateRateHint();
}

function _empPayPointChange(val) {
  _empUpdateRateHint();
}

function _empModChange() {
  _empUpdateRateHint();
}

function _empUpdateRateHint() {
  const clsSel  = document.getElementById('emp-cls-sel');
  const ppInput = document.getElementById('emp-pay-point');
  const modVal  = document.getElementById('emp-mod-val');
  const modType = document.getElementById('emp-mod-type');
  const hint    = document.getElementById('emp-award-rate-hint');
  if (!clsSel || !hint) return;
  const clsId = parseInt(clsSel.value);
  if (!clsId) { hint.textContent = ''; return; }
  const cls = _empClsData.find(c => c.id === clsId);
  if (!cls || !cls.hourly_rate) { hint.textContent = ''; return; }
  const base = parseFloat(cls.hourly_rate);
  const mod  = parseFloat(modVal?.value || 0) || 0;
  const type = modType?.value || '%';
  let final = base;
  if (mod !== 0) {
    final = type === '%' ? base * (1 + mod / 100) : base + mod;
  }
  hint.textContent = mod !== 0
    ? `Award base: $${base.toFixed(4)}/hr  →  $${final.toFixed(4)}/hr`
    : `Award rate: $${base.toFixed(4)}/hr`;
  // Auto-fill hourly_rate if currently blank
  const hrInput = document.getElementById('hourly_rate');
  if (hrInput && !hrInput.value) {
    hrInput.value = final.toFixed(4);
  }
}

async function _empFormSave(id) {
  const form  = document.getElementById('emp-form');
  const errEl = document.getElementById('emp-form-err');
  errEl.textContent = '';

  const data = {};
  if (id) data.id = id;

  form.querySelectorAll('input,select').forEach(el => {
    const k = el.name;
    if (!k) return;
    if (el.type === 'checkbox') {
      data[k] = el.checked ? 1 : 0;
    } else if (el.type === 'number') {
      data[k] = el.value !== '' ? parseFloat(el.value) : null;
    } else {
      data[k] = el.value !== '' ? el.value : null;
    }
  });

  // contact_id from the hidden picker input (not a named form field)
  const contactSel = document.getElementById('emp-contact-id');
  data.contact_id = contactSel?.value ? parseInt(contactSel.value) : null;

  // Basic validation
  if (!data.first_name || !data.last_name) {
    errEl.textContent = 'First and last name are required.'; return;
  }
  if (!data.employee_number) {
    errEl.textContent = 'Employee number is required.'; return;
  }
  if (!data.start_date) {
    errEl.textContent = 'Start date is required.'; return;
  }
  if (!data.employment_type || !data.pay_frequency) {
    errEl.textContent = 'Employment type and pay frequency are required.'; return;
  }
  if (!data.annual_salary && !data.hourly_rate && !data.classification_id) {
  errEl.textContent = 'Enter an annual salary, hourly rate, or select an award classification.'; return;
  }

  const saveBtn = document.querySelector('#det-foot .btn-primary');
  saveBtn.disabled = true;
  saveBtn.textContent = 'Saving…';

  // ── TFN privacy warning ────────────────────────────────────────────────────
  // Fire when: new employee with TFN entered, OR edit where TFN has changed.
  const tfnIsNew     = !id && data.tfn;
  const tfnChanged   = id && data.tfn && data.tfn !== _empPriorTfn;
  if (tfnIsNew || tfnChanged) {
    // Re-enable the button while the user reads the warning
    saveBtn.disabled = false;
    saveBtn.textContent = id ? 'Save Changes' : 'Create Employee';

    const bd = document.createElement('div');
    bd.className = 'modal-bd';
    bd.style.display = 'flex';
    bd.innerHTML = `
      <div class="modal-box modal-sm">
        <div class="modal-hdr"><span>⚠ TFN Privacy Notice</span></div>
        <div class="modal-body">
          <p class="pr-modal-hint">The Tax File Number (TFN) entered will be stored in the
          <strong>company database file (.dbox)</strong>. It is not encrypted.</p>
          <p class="pr-modal-hint">Keep the database file secure and limit access to
          authorised personnel only. TFNs are sensitive personal information protected
          under the <em>Privacy Act 1988</em>.</p>
          <p>Proceed only if you are authorised to collect and store
          this employee's TFN.</p>
        </div>
        <div class="modal-foot">
          <button class="btn btn-outline btn-sm" id="tfn-warn-cancel">Cancel</button>
          <button class="btn btn-primary btn-sm" id="tfn-warn-ok">I Understand — Save</button>
        </div>
      </div>`;
    document.body.appendChild(bd);

    document.getElementById('tfn-warn-cancel').onclick = () => bd.remove();
    document.getElementById('tfn-warn-ok').onclick = () => {
      bd.remove();
      saveBtn.disabled = true;
      saveBtn.textContent = 'Saving…';
      _empDoSave(id, data, saveBtn, errEl);
    };
    return;  // wait for user to confirm or cancel
  }
  // No TFN warning needed — save immediately
  _empDoSave(id, data, saveBtn, errEl);
}

async function _empDoSave(id, data, saveBtn, errEl) {
  try {
    // Auto-create or link a contact when creating a new employee with no contact linked.
    // Check for existing contacts with a matching name first — warn before creating a duplicate.
    if (!id && !data.contact_id) {
      const empName = [data.first_name, data.last_name].filter(Boolean).join(' ');

      // Wrap the contact decision in a promise so save waits for user choice.
      // Resolves true to continue, false if user cancelled.
      const proceed = await new Promise(resolve => {
        _empDupContactCheck(
          empName,
          // onUsePick: user chose an existing contact
          (contactId, _contactName) => {
            data.contact_id = contactId;
            resolve(true);
          },
          // onCreateNew: user wants a fresh contact (or no duplicates found)
          async () => {
            try {
              const conPayload = {
                name: empName || 'New Employee',
                contact_type: 'Customer',
                email:             data.email        || '',
                phone:             data.phone        || '',
                address:           data.address      || '',
                city:              data.city         || '',
                state:             data.state        || '',
                postcode:          data.postcode     || '',
                bsb:               data.bank_bsb     || '',
                account_number:    data.bank_account || '',
                bank_account_name: data.bank_name    || '',
                payment_terms: 0,
                default_tax_code: 'N-T',
                is_active: 1,
              };
              const r = await fetch('/api/contacts', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify(conPayload),
              });
              const j = await r.json();
              if (j.ok && j.data?.id) {
                data.contact_id = j.data.id;
                _empContactCache = null;
              }
            } catch(_) { /* best-effort; don't block employee save */ }
            resolve(true);
          },
          // onCancel: user dismissed the modal without choosing
          () => resolve(false)
        );
      });

      if (!proceed) {
        saveBtn.disabled = false;
        saveBtn.textContent = 'Create Employee';
        return;
      }
    }

    const url = id ? `/api/payroll/employees/${id}` : '/api/payroll/employees';
    const emp = await _pMut('POST', url, data);

    // Refresh employee list in background, then show updated detail
    _empAll = await apiFetch('/api/payroll/employees?all=1')
                .catch(() => apiFetch('/api/payroll/employees'));
    _empAll = _empAll || [];
    _renderEmployeesPage();
    _empOpen(emp.id);
  } catch (e) {
    errEl.textContent = e.message || 'Save failed.';
    saveBtn.disabled = false;
    saveBtn.textContent = id ? 'Save Changes' : 'Create Employee';
  }
}


// ── Contact picker helpers ────────────────────────────────────────────────────

// Duplicate-contact guard.
// Searches the contact cache for any contact whose name closely matches `name`.
// If matches are found, shows a modal offering "Use existing" or "Create new".
// Calls onUsePick(contactId, contactName) or onCreateNew() depending on choice.
// If no matches, calls onCreateNew() immediately without showing the modal.
// onCancel is optional — called if user dismisses without choosing.
async function _empDupContactCheck(name, onUsePick, onCreateNew, onCancel) {
  // Ensure cache is populated
  if (!_empContactCache) {
    try { _empContactCache = await apiFetch('/api/contacts') || []; }
    catch(_) { _empContactCache = []; }
  }
  const q = (name || '').trim().toLowerCase();
  const matches = q
    ? _empContactCache.filter(c => (c.name || '').toLowerCase().includes(q) || q.includes((c.name || '').toLowerCase()))
    : [];

  if (!matches.length) {
    onCreateNew();
    return;
  }

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box modal-sm">
      <div class="modal-hdr"><span>⚠ Possible Duplicate Contact</span></div>
      <div class="modal-body">
        <p class="pr-modal-hint">A contact with a similar name already exists.
        Would you like to link to an existing contact, or create a new one?</p>
        <table class="inv-list-table tbl-mb">
          <thead><tr><th>Name</th><th>Type</th><th>Email</th><th></th></tr></thead>
          <tbody>
            ${matches.slice(0, 6).map(c => `
              <tr class="inv-row">
                <td><span class="inv-contact">${esc(c.name)}</span></td>
                <td><span class="inv-mono">${esc(c.contact_type || '')}</span></td>
                <td class="col-ink3 td-sm">${esc(c.email || '—')}</td>
                <td><button class="btn btn-success btn-sm emp-dup-use"
                    data-id="${c.id}" data-name="${esc(c.name)}">Use this</button></td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" id="emp-dup-cancel">Cancel</button>
        <button class="btn btn-primary btn-sm" id="emp-dup-new">Create New Contact</button>
      </div>
    </div>`;
  document.body.appendChild(bd);

  bd.querySelectorAll('.emp-dup-use').forEach(btn => {
    btn.addEventListener('click', () => {
      bd.remove();
      onUsePick(parseInt(btn.dataset.id), btn.dataset.name);
    });
  });
  document.getElementById('emp-dup-new').onclick = () => { bd.remove(); onCreateNew(); };
  document.getElementById('emp-dup-cancel').onclick = () => {
    bd.remove();
    if (onCancel) onCancel();
  };
}

// For existing employees with no contact — create one and link it in one click.
async function _empLinkContact(empId, empName) {
  // Fetch employee details once upfront for use in both paths
  let emp = null;
  try { emp = await apiFetch(`/api/payroll/employees/${empId}`); } catch(_) {}

  async function _doCreate() {
    try {
      const r = await fetch('/api/contacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          name: empName,
          contact_type: 'Customer',
          email:             emp?.email       || '',
          phone:             emp?.phone       || '',
          address:           emp?.address     || '',
          city:              emp?.city        || '',
          state:             emp?.state       || '',
          postcode:          emp?.postcode    || '',
          bsb:               emp?.bank_bsb    || '',
          account_number:    emp?.bank_account || '',
          bank_account_name: emp?.bank_name   || '',
          payment_terms: 0,
          default_tax_code: 'N-T',
          is_active: 1,
        }),
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Failed to create contact');
      _empContactCache = null;  // invalidate cache
      await _doLink(j.data.id, empName);
    } catch (e) {
      toast(e.message || 'Could not create contact', 'err');
    }
  }

  async function _doLink(contactId, contactName) {
    try {
      await _pMut('POST', `/api/payroll/employees/${empId}`, { id: empId, contact_id: contactId });
      toast(`Contact "${contactName}" linked`);
      _empOpen(empId);
    } catch (e) {
      toast(e.message || 'Could not link contact', 'err');
    }
  }

  _empDupContactCheck(empName, _doLink, _doCreate);
}
let _empContactCache = null;   // contacts array, fetched once and cached
let _empContactHits  = [];     // current dropdown results, indexed for safe onclick

async function _empContactSearch(q) {
  const drop = document.getElementById('emp-contact-drop');
  if (!drop) return;
  if (!q.trim()) { drop.style.display = 'none'; _empContactHits = []; return; }

  // Fetch contact list once per form session
  if (!_empContactCache) {
    try { _empContactCache = await apiFetch('/api/contacts') || []; }
    catch(_) { _empContactCache = []; }
  }

  _empContactHits = _empContactCache
    .filter(c => (c.name || '').toLowerCase().includes(q.toLowerCase()))
    .slice(0, 8);

  if (!_empContactHits.length) {
    drop.style.display = 'none'; return;
  }

  drop.style.display = 'block';
  drop.innerHTML = `<div class="pr-con-drop-menu">
    ${_empContactHits.map((c, i) => `
      <div class="emp-con-opt" data-idx="${i}">
        ${esc(c.name)}
        <span class="pr-sub-ml">${esc(c.contact_type||'')}</span>
      </div>`).join('')}
    <div class="emp-con-opt-new">
      + Create new contact "${esc(q)}"
    </div>
  </div>`;

  // Attach click handlers safely (no inline JS with user data)
  drop.querySelectorAll('.emp-con-opt').forEach(el => {
    el.addEventListener('mousedown', ev => {
      ev.preventDefault();
      const hit = _empContactHits[parseInt(el.dataset.idx)];
      if (hit) _empContactPick(hit.id, hit.name);
    });
  });
  drop.querySelector('.emp-con-opt-new')?.addEventListener('mousedown', ev => {
    ev.preventDefault();
    _empContactCreateNew(null, document.getElementById('emp-contact-search')?.value || '');
  });
}

function _empContactPick(id, name) {
  const hiddenEl = document.getElementById('emp-contact-id');
  const searchEl = document.getElementById('emp-contact-search');
  const drop     = document.getElementById('emp-contact-drop');
  if (hiddenEl) hiddenEl.value = id;
  if (searchEl) searchEl.value = name;
  if (drop)     drop.style.display = 'none';
  _empContactHits = [];
}

function _empContactClear() {
  const hiddenEl = document.getElementById('emp-contact-id');
  const searchEl = document.getElementById('emp-contact-search');
  const drop     = document.getElementById('emp-contact-drop');
  if (hiddenEl) hiddenEl.value = '';
  if (searchEl) searchEl.value = '';
  if (drop)     drop.style.display = 'none';
  _empContactHits = [];
}

async function _empContactCreateNew(evt, prefillName) {
  if (evt) evt.preventDefault();
  const first = document.getElementById('first_name')?.value || '';
  const last  = document.getElementById('last_name')?.value  || '';
  const name  = prefillName || [first, last].filter(Boolean).join(' ');

  // Check for an existing contact before silently creating a duplicate.
  _empDupContactCheck(
    name,
    // onUsePick: wire the existing contact into the picker
    (contactId, contactName) => {
      _empContactCache = null;
      _empContactPick(contactId, contactName);
      toast(`Linked to existing contact "${contactName}"`);
    },
    // onCreateNew: no match or user insisted — create fresh
    async () => {
      try {
        const r = await fetch('/api/contacts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({
            name: name || 'New Employee',
            contact_type: 'Customer',
            payment_terms: 0,
            default_tax_code: 'N-T',
            is_active: 1,
          }),
        });
        const j = await r.json();
        if (!j.ok) throw new Error(j.error || 'Failed');
        _empContactCache = null;
        _empContactPick(j.data.id, j.data.name || name);
        toast(`Contact "${j.data.name || name}" created`);
      } catch (e) {
        toast(e.message || 'Could not create contact', 'err');
      }
    }
    // no onCancel needed — picker just stays as-is
  );
}


// ═══════════════════════════════════════════════════════════════════════════
// ── PAY RUNS ────────────────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════

let _prAll    = [];
let _prFilter = 'All';    // 'All' | FY string like 'FY2025-26' | 'Draft' | 'Finalised'
let _prSearch = '';
let _prSort   = { col: 'payment_date', dir: -1 };

async function _prLoadPayRuns() {
  _prView = 'pay_runs';
  _prAll  = (await apiFetch('/api/payroll/pay-runs')) || [];
  _renderPayRunsPage();
}

// Derive FY label from a date string (YYYY-MM-DD).
function _runFY(dateStr) {
  if (!dateStr) return '—';
  const [y, m] = dateStr.split('-').map(Number);
  const fy = m >= 7 ? y : y - 1;
  return `FY${fy}-${String(fy + 1).slice(2)}`;
}

// Unique FY values present in the data, sorted descending.
function _prFYs() {
  const set = new Set(_prAll.map(r => _runFY(r.payment_date)).filter(v => v !== '—'));
  return [...set].sort().reverse();
}

function _prFiltered() {
  const q = _prSearch.toLowerCase();
  return _prAll.filter(r => {
    if (_prFilter !== 'All') {
      if (_prFilter === 'Draft' || _prFilter === 'Finalised' || _prFilter === 'Void' || _prFilter === 'STP_Lodged') {
        if (r.status !== _prFilter) return false;
      } else {
        // FY filter
        if (_runFY(r.payment_date) !== _prFilter) return false;
      }
    }
    if (q && ![ r.run_number, r.status, r.frequency,
                r.pay_period_start, r.pay_period_end ]
              .some(v => (v || '').toLowerCase().includes(q))) return false;
    return true;
  }).sort((a, b) => {
    const col = _prSort.col;
    const av = a[col] ?? '', bv = b[col] ?? '';
    return (typeof av === 'number' ? (av - bv) : String(av).localeCompare(String(bv)))
           * _prSort.dir;
  });
}

function _renderPayRunsPage(restoreFocus) {
  const rows = _prFiltered();
  const mc   = document.getElementById('module-content');

  const fys   = _prFYs();
  const pills = ['All', 'Draft', 'Finalised', 'STP_Lodged', 'Void', ...fys];

  // Summary counts
  const counts = { All: _prAll.length, Draft: 0, Finalised: 0, STP_Lodged: 0, Void: 0 };
  fys.forEach(fy => { counts[fy] = 0; });
  _prAll.forEach(r => {
    if (r.status in counts) counts[r.status]++;
    const fy = _runFY(r.payment_date);
    if (fy in counts) counts[fy]++;
  });

  // KPI totals from filtered rows
  const totGross = rows.reduce((s, r) => s + (r.total_gross || 0), 0);
  const totTax   = rows.reduce((s, r) => s + (r.total_tax   || 0), 0);
  const totNet   = rows.reduce((s, r) => s + (r.total_net   || 0), 0);
  const totSuper = rows.reduce((s, r) => s + (r.total_super || 0), 0);

  mc.innerHTML = `
    <div class="inv-toolbar">
      <input class="inv-search" id="pr-q" placeholder="Search run #, period…"
             value="${esc(_prSearch)}">
      <div class="inv-filter-group">
        ${pills.map(p => {
          const label = p === 'STP_Lodged' ? 'STP Lodged' : p;
          return `
          <button class="filter-btn${_prFilter === p ? ' active' : ''}"
                  onclick="_prSetFilter('${p}')">
            ${label}${counts[p] != null ? ` <span class="pr-pill-count">(${counts[p]})</span>` : ''}
          </button>`;
        }).join('')}
      </div>
      <div class="pr-toolbar-actions">
        <button class="btn btn-outline" onclick="_prLoadEmployees()" title="Switch to Employees">
          👤 Employees
        </button>
        <button class="btn btn-outline" onclick="_prLoadStp()" title="STP Submissions">
          📋 STP
        </button>
        <button class="btn btn-outline" onclick="_prLoadSuper()" title="Super Payment Batches">
          💰 Super
        </button>
        <button class="btn btn-outline" onclick="_abaOpen()" title="Export ABA bank file">
          ⬇ ABA File
        </button>
        <button class="btn btn-primary" onclick="_prNewOpen()">+ New Pay Run</button>
      </div>
    </div>

    ${rows.length ? `
    <div class="kpi-row cols-4">
      <div class="kpi-card">
        <div class="kpi-label">Gross Pay</div>
        <div class="kpi-value col-accent">${fmt(totGross)}</div>
        <div class="kpi-sub">${rows.length} run${rows.length !== 1 ? 's' : ''} shown</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">PAYG Tax</div>
        <div class="kpi-value col-red">${fmt(totTax)}</div>
        <div class="kpi-sub">${((totTax / (totGross || 1)) * 100).toFixed(1)}% effective rate</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Net Pay</div>
        <div class="kpi-value col-green">${fmt(totNet)}</div>
        <div class="kpi-sub">After tax &amp; sacrifices</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Superannuation</div>
        <div class="kpi-value col-amber">${fmt(totSuper)}</div>
        <div class="kpi-sub">SGC + voluntary</div>
      </div>
    </div>` : ''}

    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        ${_prTh('run_number',     '#')}
        ${_prTh('pay_period_start', 'Period')}
        ${_prTh('payment_date',   'Payment Date')}
        ${_prTh('frequency',      'Frequency')}
        ${_prTh('employee_count', 'Employees', 'r')}
        ${_prTh('total_gross',    'Gross', 'r')}
        ${_prTh('total_tax',      'PAYG Tax', 'r')}
        ${_prTh('total_net',      'Net Pay', 'r')}
        ${_prTh('total_super',    'Super', 'r')}
        <th>Status</th>
      </tr></thead><tbody>
        ${rows.length
          ? rows.map(_prRow).join('')
          : `<tr><td colspan="10" class="tbl-empty-cell">No pay runs match your filter</td></tr>`}
      </tbody></table>
    </div></div>
    <div class="mt-8">
      <span class="count-pill">${rows.length} of ${_prAll.length} pay run${_prAll.length !== 1 ? 's' : ''}</span>
    </div>`;

  const q = document.getElementById('pr-q');
  if(q){
    q.addEventListener('input', e => { _prSearch = e.target.value; _renderPayRunsPage(true); });
    if(restoreFocus){q.focus();q.setSelectionRange(q.value.length,q.value.length);}
  }
}

function _prTh(col, label, align) {
  const cls = _prSort.col === col ? (_prSort.dir > 0 ? 'sort-asc' : 'sort-desc') : '';
  const ra  = align === 'r' ? ' col-r' : '';
  return `<th class="${cls}${ra}" onclick="_prSortBy('${col}')">${label}</th>`;
}

function _prRow(r) {
  const badge = r.status === 'Finalised'
    ? `<span class="badge badge-paid">Finalised</span>`
    : r.status === 'STP_Lodged'
    ? `<span class="badge badge-sent">STP Lodged</span>`
    : r.status === 'Void'
    ? `<span class="badge badge-void">Void</span>`
    : `<span class="badge badge-draft">Draft</span>`;
  const period = r.pay_period_start && r.pay_period_end
    ? `${fmtDate(r.pay_period_start)} – ${fmtDate(r.pay_period_end)}`
    : fmtDate(r.pay_period_start) || '—';
  return `<tr class="inv-row" onclick="_prOpen(${r.id})">
    <td><span class="inv-mono">${esc(r.run_number || '#' + r.id)}</span></td>
    <td><span class="inv-mono">${esc(period)}</span></td>
    <td><span class="inv-mono">${fmtDate(r.payment_date)}</span></td>
    <td>${esc(r.frequency || '—')}</td>
    <td class="inv-amt">${r.employee_count || 0}</td>
    <td class="inv-amt">${fmt(r.total_gross)}</td>
    <td class="inv-amt col-red">${fmt(r.total_tax)}</td>
    <td class="inv-amt col-green">${fmt(r.total_net)}</td>
    <td class="inv-amt col-amber">${fmt(r.total_super)}</td>
    <td>${badge}</td>
  </tr>`;
}

function _prSortBy(col) {
  _prSort = { col, dir: _prSort.col === col ? _prSort.dir * -1 : 1 };
  _renderPayRunsPage();
}

function _prSetFilter(f) {
  _prFilter = f;
  _renderPayRunsPage();
}

// ── Pay run detail slide-over ─────────────────────────────────────────────────

async function _prOpen(id) {
  _prPanelOpen('Pay Run');
  try {
    const data = await apiFetch(`/api/payroll/pay-runs/${id}`);
    _renderPayRunDetail(data);
  } catch (err) {
    _prPanelError(err.message);
  }
}

function _renderPayRunDetail(data) {
  const run   = data.run   || {};
  const slips = data.slips || [];

  const badge = run.status === 'Finalised'
    ? `<span class="badge badge-paid">Finalised</span>`
    : run.status === 'STP_Lodged'
    ? `<span class="badge badge-sent">STP Lodged</span>`
    : run.status === 'Void'
    ? `<span class="badge badge-void">Void</span>`
    : `<span class="badge badge-draft">Draft</span>`;

  const period = run.pay_period_start && run.pay_period_end
    ? `${fmtDate(run.pay_period_start)} – ${fmtDate(run.pay_period_end)}`
    : fmtDate(run.pay_period_start) || '—';

  // Aggregate totals from payslips (more reliable than run-level fields)
  const gross = slips.reduce((s, p) => s + (p.gross_pay    || 0), 0);
  const tax   = slips.reduce((s, p) => s + (p.payg_tax     || 0), 0);
  const net   = slips.reduce((s, p) => s + (p.net_pay      || 0), 0);
  const super_ = slips.reduce((s, p) => s + (p.super_amount || 0), 0);

  document.getElementById('det-title').textContent =
    `Pay Run ${run.run_number || '#' + run.id}`;

  document.getElementById('det-body').innerHTML = `
    <div class="det-meta">
      <div><div class="det-lbl">Period</div>
           <div class="det-val mono">${esc(period)}</div></div>
      <div><div class="det-lbl">Payment Date</div>
           <div class="det-val mono">${fmtDate(run.payment_date)}</div></div>
      <div><div class="det-lbl">Frequency</div>
           <div class="det-val">${esc(run.frequency || '—')}</div></div>
      <div><div class="det-lbl">Status</div>
           <div class="det-val">${badge}</div></div>
    </div>

    <div class="det-totals det-totals-mv">
      <div class="det-tot-row"><span>Gross Pay</span>
        <span class="col-accent">${fmt(gross)}</span></div>
      <div class="det-tot-row"><span>PAYG Withholding</span>
        <span class="col-red">${fmt(tax)}</span></div>
      <div class="det-tot-row"><span>Net Pay</span>
        <span class="col-green">${fmt(net)}</span></div>
      <div class="det-tot-row grand"><span>Superannuation</span>
        <span class="col-amber">${fmt(super_)}</span></div>
    </div>

    <div class="det-section-title">Payslip Breakdown
      <span class="pr-slip-count-note">
        ${slips.length} employee${slips.length !== 1 ? 's' : ''}
      </span>
    </div>

    ${slips.length ? `
    <div class="pr-slip-scroll">
      <table class="det-lines pr-slip-table">
        <thead><tr>
          <th>Employee</th>
          <th class="th-r">Gross</th>
          <th class="th-r">Ordinary</th>
          <th class="th-r">Overtime</th>
          <th class="th-r">Leave</th>
          <th class="th-r">Allowances</th>
          <th class="th-r">PAYG Tax</th>
          <th class="th-r">Super</th>
          <th class="th-r">Net Pay</th>
          <th class="td-c-mono">PDF</th>
        </tr></thead>
        <tbody>
          ${slips.map(p => {
            const empName = p.first_name
              ? `${p.first_name} ${p.last_name}`
              : `Employee #${p.employee_id}`;
            const empNo = p.employee_number ? ` <span class="pr-emp-num-tag">#${p.employee_number}</span>` : '';
            return `<tr>
              <td>${esc(empName)}${empNo}
                ${p.leave_type ? `<div class="pr-slip-leave-tag">${esc(p.leave_type)}</div>` : ''}
              </td>
              <td class="inv-amt pr-slip-gross">${fmt(p.gross_pay)}</td>
              <td class="inv-amt">${fmt(p.ordinary_gross)}</td>
              <td class="inv-amt">${(p.overtime_gross || 0) > 0 ? fmt(p.overtime_gross) : '—'}</td>
              <td class="inv-amt">${(p.leave_gross || 0) > 0 ? fmt(p.leave_gross) : '—'}</td>
              <td class="inv-amt">${(p.allowances || 0) > 0 ? fmt(p.allowances) : '—'}</td>
              <td class="inv-amt pr-slip-tax">${fmt(p.payg_tax)}</td>
              <td class="inv-amt pr-slip-super">${fmt(p.super_amount)}</td>
              <td class="inv-amt pr-slip-net">${fmt(p.net_pay)}</td>
              <td class="td-c-mono">
                <button class="btn btn-xs btn-outline" title="Download payslip PDF"
                        onclick="event.stopPropagation();_payslipDownloadPdf(${run.id},${p.id})">⬇ PDF</button>
              </td>
            </tr>`;
          }).join('')}
          <tr class="pr-slip-total-row">
            <td>Total</td>
            <td class="inv-amt pr-slip-gross">${fmt(gross)}</td>
            <td class="inv-amt">${fmt(slips.reduce((s,p)=>s+(p.ordinary_gross||0),0))}</td>
            <td class="inv-amt">${fmt(slips.reduce((s,p)=>s+(p.overtime_gross||0),0))}</td>
            <td class="inv-amt">${fmt(slips.reduce((s,p)=>s+(p.leave_gross||0),0))}</td>
            <td class="inv-amt">${fmt(slips.reduce((s,p)=>s+(p.allowances||0),0))}</td>
            <td class="inv-amt pr-slip-tax">${fmt(tax)}</td>
            <td class="inv-amt pr-slip-super">${fmt(super_)}</td>
            <td class="inv-amt pr-slip-net">${fmt(net)}</td>
            <td></td>
          </tr>
        </tbody>
      </table>
    </div>` : `<div class="det-empty">No payslips in this run.</div>`}

    ${run.notes ? `
    <div class="det-section-title pr-section-title-gap">Notes</div>
    <div class="det-note">${esc(run.notes)}</div>` : ''}`;

  const isDraft     = run.status === 'Draft';
  const isFinalised = run.status === 'Finalised';
  const isStpLodged = run.status === 'STP_Lodged';
  document.getElementById('det-foot').innerHTML =
    `<button class="btn btn-outline" onclick="detClose()">Close</button>
     <div class="pr-det-foot-spacer"></div>
     ${isDraft ? `
       <button class="btn btn-outline" onclick="_prRunReport(${run.id})">📊 Run Report</button>
       <button class="btn btn-outline"
               onclick="_prEditDraft(${run.id})">✏ Edit Draft</button>
       <button class="btn btn-outline pr-btn-danger"
               onclick="_prDeleteRun(${run.id}, '${esc(run.run_number)}')">Delete Draft</button>
       <button class="btn btn-primary" onclick="_prFinalise(${run.id})">Finalise Pay Run</button>
     ` : ''}
     ${isFinalised ? `
       <button class="btn btn-outline" onclick="_prRunReport(${run.id})">📊 Run Report</button>
       <button class="btn btn-outline"
               data-run-id="${run.id}"
               onclick="_payslipDownloadAll(this)">
         ⬇ All Payslips
       </button>
       <button class="btn btn-outline" onclick="_stpLodge(${run.id}, '${esc(run.run_number)}')">
         📋 Lodge STP
       </button>
       <button class="btn btn-outline" onclick="_abaDownload(${run.id}, '${esc(run.pay_period_end || run.run_number)}')">
         ⬇ ABA File
       </button>
       <button class="btn btn-outline pr-btn-danger"
               onclick="_prVoid(${run.id}, '${esc(run.run_number)}')">
         ✕ Void Run
       </button>
     ` : ''}
     ${isStpLodged ? `
       <button class="btn btn-outline" onclick="_prRunReport(${run.id})">📊 Run Report</button>
       <button class="btn btn-outline pr-btn-green"
               onclick="_prLoadStp()">
         ✓ STP Lodged — View Submissions
       </button>
       <button class="btn btn-outline"
               data-run-id="${run.id}"
               onclick="_payslipDownloadAll(this)">
         ⬇ All Payslips
       </button>
       <button class="btn btn-outline" onclick="_abaDownload(${run.id}, '${esc(run.pay_period_end || run.run_number)}')">
         ⬇ ABA File
       </button>
     ` : ''}`;
}


// ═══════════════════════════════════════════════════════════════════════════
// ── PAYSLIP PDF DOWNLOAD  ────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════

function _payslipDownloadPdf(runId, slipId) {
  window.open(`/api/payroll/pay-runs/${runId}/payslips/${slipId}/pdf`, '_blank');
}

function _payslipDownloadAll(btn) {
  const runId = btn.dataset.runId;
  window.open(`/api/payroll/pay-runs/${runId}/payslips/pdf`, '_blank');
}

function _prRunReport(runId) {
  window.open(`/api/payroll/pay-runs/${runId}/report`, '_blank');
}


// ═══════════════════════════════════════════════════════════════════════════
// ── PAY RUN — FINALISE / DELETE  ────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════

async function _prFinalise(runId) {
  const confirmed = confirm(
    'Finalise this pay run?\n\n' +
    'This will:\n' +
    '  • Update all employee YTD figures\n' +
    '  • Post journal entries to the General Ledger\n' +
    '  • Lock the run — it cannot be edited or deleted\n\n' +
    'This action cannot be undone.'
  );
  if (!confirmed) return;

  const btn = document.querySelector('#det-foot .btn-primary');
  if (btn) { btn.disabled = true; btn.textContent = 'Finalising…'; }

  try {
    const data = await _pMut('POST', `/api/payroll/pay-runs/${runId}/finalise`);
    toast('Pay run finalised and posted to General Ledger');
    // Reload list + reopen detail with updated status
    _prAll = (await apiFetch('/api/payroll/pay-runs')) || [];
    _renderPayRunsPage();
    _renderPayRunDetail(data);
    // Offer STP lodgement immediately after finalisation
    const run = data.run || {};
    if (confirm(
      `Pay run ${run.run_number || ''} finalised.\n\n` +
      `Generate STP Phase 2 submission now?\n\n` +
      `You can also do this later from the 📋 STP button in the Pay Runs toolbar.`
    )) {
      await _stpLodge(runId, run.run_number || '');
    }
  } catch (e) {
    toast(e.message || 'Finalise failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Finalise Pay Run'; }
  }
}

async function _prDeleteRun(runId, runNumber) {
  const confirmed = confirm(`Delete draft pay run ${runNumber}?\n\nAll payslips in this run will be removed. This cannot be undone.`);
  if (!confirmed) return;
  try {
    await _pMut('DELETE', `/api/payroll/pay-runs/${runId}`);
    toast(`Pay run ${runNumber} deleted`);
    detClose();
    _prAll = (await apiFetch('/api/payroll/pay-runs')) || [];
    _renderPayRunsPage();
  } catch (e) {
    toast(e.message || 'Delete failed', 'err');
  }
}


async function _prVoid(runId, runNumber) {
  const first = confirm(
    `Void pay run ${runNumber}?\n\n` +
    `This will:\n` +
    `  • Reverse all YTD accumulator changes from this run\n` +
    `  • Post reversal journal entries to the GL\n` +
    `  • Mark all payslips as Void\n` +
    `  • Set run status to Void\n\n` +
    `This action cannot be undone.`
  );
  if (!first) return;
  const second = confirm(
    `CONFIRM VOID\n\nAre you sure you want to void pay run ${runNumber}?\n\nThis is irreversible.`
  );
  if (!second) return;
  try {
    await _pMut('POST', `/api/payroll/pay-runs/${runId}/void`);
    toast(`Pay run ${runNumber} voided`);
    detClose();
    _prAll = (await apiFetch('/api/payroll/pay-runs')) || [];
    _renderPayRunsPage();
  } catch (e) {
    toast(e.message || 'Void failed', 'err');
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// ── NEW PAY RUN — WIZARD  ────────────────────────────────────────────────────
//
//  Step 1: Setup   — frequency, period dates, payment date, employee selection
//  Step 2: Preview — calculated payslips, per-employee Adjust panel
//  Step 3: (auto)  — on Create Draft, closes wizard and opens pay run detail
//
// State lives in _prWiz so it survives re-renders within a session.
// ═══════════════════════════════════════════════════════════════════════════

let _prWiz = null;   // wizard state object, null when wizard is closed
let _prMeta = null;  // cached { leave_types, allowance_types, pay_frequencies }

async function _prEditDraft(runId) {
  if (!_prMeta) {
    try { _prMeta = await apiFetch('/api/payroll/meta'); }
    catch(_) { _prMeta = { leave_types: [], allowance_types: [], pay_frequencies: ['Weekly','Fortnightly','Monthly'] }; }
  }

  let data;
  try { data = await apiFetch(`/api/payroll/pay-runs/${runId}`); }
  catch (e) { toast('Could not load draft: ' + e.message, 'err'); return; }

  const run   = data.run   || {};
  // Normalise slips: detail endpoint uses first_name/last_name,
  // but _prPreviewRow expects employee_name and employee_number.
  const slips = (data.slips || []).map(p => ({
    ...p,
    employee_name:   p.employee_name   || [p.first_name, p.last_name].filter(Boolean).join(' ') || `Employee #${p.employee_id}`,
    employee_number: p.employee_number || '',
  }));

  const adjustments = {};
  for (const p of slips) {
    const key = String(p.employee_id);
    const adj = {};
    if (p.ordinary_hours   != null && p.ordinary_hours   > 0) adj.ordinary_hours   = p.ordinary_hours;
    if (p.overtime_hours   != null && p.overtime_hours   > 0) adj.overtime_hours   = p.overtime_hours;
    if (p.leave_hours      != null && p.leave_hours      > 0) adj.leave_hours      = p.leave_hours;
    if (p.leave_type)                                          adj.leave_type       = p.leave_type;
    if (p.salary_sacrifice != null && p.salary_sacrifice > 0) adj.salary_sacrifice = p.salary_sacrifice;
    adj.allowances = [];
    const hasContent = Object.keys(adj).some(k => k !== 'allowances');
    if (hasContent) adjustments[key] = adj;
  }

  const gross  = slips.reduce((s, p) => s + (p.gross_pay    || 0), 0);
  const tax    = slips.reduce((s, p) => s + (p.payg_tax     || 0), 0);
  const net    = slips.reduce((s, p) => s + (p.net_pay      || 0), 0);
  const super_ = slips.reduce((s, p) => s + (p.super_amount || 0), 0);

  _prWiz = {
    step:           2,
    editing_run_id: runId,
    editing_run_number: run.run_number || String(runId),
    frequency:    run.frequency        || 'Fortnightly',
    period_start: run.pay_period_start || '',
    period_end:   run.pay_period_end   || '',
    payment_date: run.payment_date     || '',
    emp_ids:      new Set(slips.map(p => p.employee_id)),
    emp_all:      (_empAll && _empAll.length)
                    ? _empAll
                    : await apiFetch('/api/payroll/employees').catch(() => []),
    adjustments,
    preview: {
      slips,
      totals: { gross, tax, net, super: super_ },
      errors: [],
    },
    preview_busy: false,
    save_busy:    false,
  };

  _prRenderWizard();
}

async function _prNewOpen() {
  // Fetch metadata once
  if (!_prMeta) {
    try { _prMeta = await apiFetch('/api/payroll/meta'); }
    catch(_) { _prMeta = { leave_types: [], allowance_types: [], pay_frequencies: ['Weekly','Fortnightly','Monthly'] }; }
  }

  // Initialise wizard state
  const today = new Date();
  const pad   = n => String(n).padStart(2, '0');
  const iso   = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;

  // Default: fortnightly ending yesterday, payment today
  const periodEnd   = new Date(today); periodEnd.setDate(today.getDate() - 1);
  const periodStart = new Date(periodEnd); periodStart.setDate(periodEnd.getDate() - 13);

  _prWiz = {
    step:         1,
    frequency:    'Fortnightly',
    period_start: iso(periodStart),
    period_end:   iso(periodEnd),
    payment_date: iso(today),
    // employee selection: null = all active, otherwise Set of ids
    emp_ids:      null,   // null means "all active"
    emp_all:      null,   // will be populated from _empAll or fetched
    adjustments:  {},     // keyed by employee_id (string)
    preview:      null,   // { slips, totals, errors }
    preview_busy: false,
    save_busy:    false,
  };

  // Reuse employee list if already loaded, otherwise fetch
  _prWiz.emp_all = (_empAll && _empAll.length)
    ? _empAll.filter(e => e.is_active)
    : await apiFetch('/api/payroll/employees').then(r => (r||[]).filter(e=>e.is_active)).catch(()=>[]);

  _prRenderWizard();
}

function _prWizClose() {
  _prWiz = null;
  // Remove wizard overlay
  const el = document.getElementById('pr-wizard-overlay');
  if (el) el.remove();
}

// ── Render the full wizard modal ─────────────────────────────────────────────

function _prRenderWizard() {
  const w = _prWiz;
  if (!w) return;

  // Remove old if present
  let old = document.getElementById('pr-wizard-overlay');
  if (old) old.remove();

  const overlay = document.createElement('div');
  overlay.id = 'pr-wizard-overlay';
  overlay.className = 'pr-wiz-overlay';
  overlay.innerHTML = `
    <div class="pr-wiz-modal">
      <div class="pr-wiz-header">
        <div class="pr-wiz-hdr-inner">
          <span class="pr-wiz-title">${w.editing_run_id ? 'Edit Draft Pay Run' : 'New Pay Run'}</span>
          <div class="pr-wiz-steps">
            ${[['1','Setup'],['2','Preview & Adjust']].map(([n, lbl]) => `
              <div class="pr-wiz-step ${w.step == n ? 'active' : w.step > n ? 'done' : ''}">
                <span class="pr-wiz-step-num">${w.step > n ? '✓' : n}</span>
                <span class="pr-wiz-step-lbl">${lbl}</span>
              </div>`).join('<div class="pr-wiz-step-connector"></div>')}
          </div>
        </div>
        <button class="pr-wiz-close" onclick="_prWizClose()">✕</button>
      </div>
      <div class="pr-wiz-body" id="pr-wiz-body">
        ${w.step === 1 ? _prWizStep1Html() : _prWizStep2Html()}
      </div>
      <div class="pr-wiz-footer" id="pr-wiz-footer">
        ${_prWizFooterHtml()}
      </div>
    </div>`;

  document.body.appendChild(overlay);
  if (_prWiz.step === 1) _prWizBindStep1();
}

function _prWizRefreshBody() {
  const body = document.getElementById('pr-wiz-body');
  const foot = document.getElementById('pr-wiz-footer');
  if (!body || !foot) return;
  body.innerHTML = _prWiz.step === 1 ? _prWizStep1Html() : _prWizStep2Html();
  foot.innerHTML = _prWizFooterHtml();
  if (_prWiz.step === 1) _prWizBindStep1();
}

// ── Step 1: Setup ─────────────────────────────────────────────────────────────

function _prWizStep1Html() {
  const w   = _prWiz;
  const emps = w.emp_all || [];
  const allSelected = w.emp_ids === null;

  return `
    <div class="pr-wiz-section-title">Pay Period</div>
    <div class="form-grid">
      <div class="form-field">
        <label class="form-lbl">Frequency</label>
        <select class="form-input" id="wiz-frequency">
          ${(_prMeta?.pay_frequencies || ['Weekly','Fortnightly','Monthly'])
            .map(f => `<option${f===w.frequency?' selected':''}>${f}</option>`).join('')}
        </select>
      </div>
      <div class="form-field">
        <label class="form-lbl">Payment Date *</label>
        <input class="form-input" type="date" id="wiz-payment-date" value="${w.payment_date}">
      </div>
      <div class="form-field">
        <label class="form-lbl">Period Start *</label>
        <input class="form-input" type="date" id="wiz-period-start" value="${w.period_start}">
      </div>
      <div class="form-field">
        <label class="form-lbl">Period End *</label>
        <input class="form-input" type="date" id="wiz-period-end" value="${w.period_end}">
      </div>
    </div>
    <div id="wiz-date-err" class="wiz-date-err"></div>

    <div id="wiz-emp-section">${_prWizEmpSectionHtml()}</div>`;
}

// Renders the Employees section of wizard step 1, filtered to the current frequency.
function _prWizEmpSectionHtml() {
  const w = _prWiz;
  const allSelected = w.emp_ids === null;
  // Filter to employees whose pay_frequency matches the run frequency.
  const emps = (w.emp_all || []).filter(e => _prWizFreqMatch(w.frequency, e.pay_frequency));
  const hiddenCount = (w.emp_all || []).length - emps.length;

  return `
    <div class="pr-wiz-section-title wiz-section-title-top">Employees</div>
    ${hiddenCount > 0 ? `<div class="wiz-freq-note">${hiddenCount} employee${hiddenCount!==1?'s':''} hidden — frequency doesn't match ${w.frequency}</div>` : ''}
    <div class="wiz-all-emp-wrap">
      <label class="wiz-all-emp-lbl">
        <input type="checkbox" id="wiz-all-emp" ${allSelected?'checked':''}
               class="wiz-all-emp-cb">
        Include all matching employees (${emps.length})
      </label>
    </div>
    <div id="wiz-emp-list" style="${allSelected?'opacity:.45;pointer-events:none':''}">
      <div class="wiz-emp-grid">
        ${emps.map(e => {
          const checked = allSelected || (w.emp_ids && w.emp_ids.has(e.id));
          const missingBank = !e.bank_bsb || !e.bank_account;
          return `<label class="wiz-emp-row${missingBank ? ' wiz-emp-row--warn' : ''}">
            <input type="checkbox" class="wiz-emp-cb" data-id="${e.id}"
                   ${checked?'checked':''}>
            <span class="wiz-emp-name">${esc(e.first_name+' '+e.last_name)}</span>
            <span class="wiz-emp-num">${esc(e.employee_number||'')}</span>
            ${missingBank ? `<span class="wiz-emp-bank-warn" title="Missing BSB or Account No — ABA file will fail for this employee">⚠ No bank details <a class="wiz-emp-fix-link" onclick="event.preventDefault();event.stopPropagation();_prWizFixEmpBank(${e.id})">Fix →</a></span>` : ''}
          </label>`;
        }).join('')}
        ${emps.length === 0 ? `<div class="wiz-emp-empty">No active employees match this frequency</div>` : ''}
      </div>
      ${emps.length > 0 ? `
      <div class="wiz-emp-actions">
        <button class="btn btn-outline pr-allow-add"
                onclick="_prWizSelectAll(true)">Select All</button>
        <button class="btn btn-outline pr-allow-add"
                onclick="_prWizSelectAll(false)">Clear All</button>
      </div>` : ''}
    </div>`;
}

function _prWizBindStep1() {
  const w = _prWiz;

  // Frequency change → auto-recalculate period dates + re-filter employee list
  const freqEl = document.getElementById('wiz-frequency');
  if (freqEl) freqEl.addEventListener('change', () => {
    w.frequency = freqEl.value;
    _prWizAutoFillDates();
    const startEl = document.getElementById('wiz-period-start');
    const endEl   = document.getElementById('wiz-period-end');
    if (startEl) startEl.value = w.period_start;
    if (endEl)   endEl.value   = w.period_end;
    // Re-render the employee section with the new frequency filter, then rebind
    const sec = document.getElementById('wiz-emp-section');
    if (sec) {
      sec.innerHTML = _prWizEmpSectionHtml();
      _prWizBindEmpSection();
    }
  });

  // Date field changes
  ['wiz-period-start','wiz-period-end','wiz-payment-date'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', () => {
      if (id === 'wiz-period-start') w.period_start = el.value;
      if (id === 'wiz-period-end')   w.period_end   = el.value;
      if (id === 'wiz-payment-date') w.payment_date = el.value;
      _prWizValidateDates();
    });
  });

  _prWizBindEmpSection();
}

// Binds the all-employees checkbox and individual checkboxes.
// Called on initial step-1 render and after a frequency-change re-render.
function _prWizBindEmpSection() {
  const w = _prWiz;

  // All-employees checkbox
  const allCb = document.getElementById('wiz-all-emp');
  const empList = document.getElementById('wiz-emp-list');
  if (allCb) allCb.addEventListener('change', () => {
    if (allCb.checked) {
      w.emp_ids = null;
      if (empList) { empList.style.opacity = '.45'; empList.style.pointerEvents = 'none'; }
    } else {
      // Start with all frequency-matching employees checked
      const visibleIds = [...document.querySelectorAll('.wiz-emp-cb')]
        .map(cb => parseInt(cb.dataset.id));
      w.emp_ids = new Set(visibleIds);
      if (empList) { empList.style.opacity = ''; empList.style.pointerEvents = ''; }
      _prWizSyncEmpCheckboxes();
    }
  });

  // Individual employee checkboxes
  document.querySelectorAll('.wiz-emp-cb').forEach(cb => {
    cb.addEventListener('change', () => {
      if (w.emp_ids === null) return;  // all-mode, shouldn't happen
      const id = parseInt(cb.dataset.id);
      if (cb.checked) w.emp_ids.add(id);
      else            w.emp_ids.delete(id);
    });
  });
}

// Opens the employee edit form from within the wizard.
// After the panel closes, refreshes w.emp_all and re-renders the step 1 employee section.
async function _prWizFixEmpBank(empId) {
  await _empFormOpen(empId);
  // Watch for the panel closing (overlay losing 'open') then refresh wizard employee list
  const overlay = document.getElementById('det-overlay');
  if (!overlay) return;
  const observer = new MutationObserver(() => {
    if (!overlay.classList.contains('open')) {
      observer.disconnect();
      apiFetch('/api/payroll/employees').then(emps => {
        _prWiz.emp_all = emps || [];
        const sec = document.getElementById('wiz-emp-section');
        if (sec) {
          sec.innerHTML = _prWizEmpSectionHtml();
          _prWizBindEmpSection();
        }
      }).catch(() => {});
    }
  });
  observer.observe(overlay, { attributes: true, attributeFilter: ['class'] });
}

function _prWizSelectAll(checked) {
  const w = _prWiz;
  document.querySelectorAll('.wiz-emp-cb').forEach(cb => {
    cb.checked = checked;
    const id = parseInt(cb.dataset.id);
    if (checked) {
      if (!w.emp_ids) w.emp_ids = new Set();
      w.emp_ids.add(id);
    } else {
      if (w.emp_ids) w.emp_ids.delete(id);
    }
  });
  // If "all" checkbox is present, uncheck it since we're in manual mode
  const allCb = document.getElementById('wiz-all-emp');
  if (allCb) allCb.checked = false;
  w.emp_ids = new Set(
    [...document.querySelectorAll('.wiz-emp-cb')]
      .filter(cb => cb.checked)
      .map(cb => parseInt(cb.dataset.id))
  );
}

function _prWizSyncEmpCheckboxes() {
  const w = _prWiz;
  document.querySelectorAll('.wiz-emp-cb').forEach(cb => {
    cb.checked = w.emp_ids ? w.emp_ids.has(parseInt(cb.dataset.id)) : true;
  });
}

function _prWizAutoFillDates() {
  const w     = _prWiz;
  const today = new Date();
  const pad   = n => String(n).padStart(2,'0');
  const iso   = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
  const days  = { Weekly: 6, Fortnightly: 13, Monthly: null }[w.frequency] || 13;

  if (w.frequency === 'Monthly') {
    // Last complete calendar month
    const first = new Date(today.getFullYear(), today.getMonth() - 1, 1);
    const last  = new Date(today.getFullYear(), today.getMonth(), 0);
    w.period_start = iso(first);
    w.period_end   = iso(last);
  } else {
    const end   = new Date(today); end.setDate(today.getDate() - 1);
    const start = new Date(end);   start.setDate(end.getDate() - days);
    w.period_start = iso(start);
    w.period_end   = iso(end);
  }
  w.payment_date = iso(today);
}

// Returns true if an employee's pay_frequency is compatible with the run frequency.
// Frequency matching rules:
//   Weekly      → Weekly only
//   Fortnightly → Fortnightly + Weekly
//   Monthly     → Monthly only
function _prWizFreqMatch(runFreq, empFreq) {
  if (!empFreq) return true;                          // unset → always include
  if (runFreq === 'Fortnightly') return empFreq === 'Fortnightly' || empFreq === 'Weekly';
  return empFreq === runFreq;                         // Weekly→Weekly, Monthly→Monthly
}

function _prWizValidateDates() {
  const w    = _prWiz;
  const errEl = document.getElementById('wiz-date-err');
  if (!errEl) return true;
  if (!w.period_start || !w.period_end || !w.payment_date) {
    errEl.textContent = 'All dates are required.'; return false;
  }
  if (w.period_end < w.period_start) {
    errEl.textContent = 'Period end must be on or after period start.'; return false;
  }
  errEl.textContent = '';
  return true;
}

// ── Step 2: Preview & Adjust ──────────────────────────────────────────────────

function _prWizStep2Html() {
  const w = _prWiz;
  const p = w.preview;

  if (w.preview_busy) {
    return `<div class="state-loading pr-wiz-state-pad">Calculating payslips…</div>`;
  }
  if (!p) {
    return `<div class="state-error pr-wiz-state-pad">No preview data. Go back to Step 1.</div>`;
  }

  const period = `${fmtDate(w.period_start)} – ${fmtDate(w.period_end)}`;
  const { slips, totals, errors } = p;

  // Find included employees missing bank details
  const empMap = Object.fromEntries((w.emp_all || []).map(e => [e.id, e]));
  const missingBankEmps = slips
    .map(s => empMap[s.employee_id])
    .filter(e => e && (!e.bank_bsb || !e.bank_account));

  return `
    <div class="pr-wiz-info-bar">
      <span class="pr-wiz-info-period">${period} · ${w.frequency}</span>
      <span class="pr-wiz-info-meta">Payment: ${fmtDate(w.payment_date)}</span>
      <span class="pr-wiz-info-count">${slips.length} employee${slips.length!==1?'s':''}</span>
    </div>

    ${errors.length ? `
    <div class="pr-wiz-errors">
      <strong>Calculation errors (these employees will be excluded):</strong>
      ${errors.map(e=>`<div>• ${esc(e.employee_name)}: ${esc(e.error)}</div>`).join('')}
    </div>` : ''}

    ${missingBankEmps.length ? `
    <div class="pr-wiz-bank-warn">
      <strong>⚠ Missing bank details — ABA file will not include these employees:</strong>
      ${missingBankEmps.map(e => {
        const missing = [!e.bank_bsb && 'BSB', !e.bank_account && 'Account No.'].filter(Boolean).join(', ');
        return `<div>• ${esc(e.first_name + ' ' + e.last_name)} — missing ${missing}.
          Go back to Step 1 to uncheck, or <a class="wiz-emp-fix-link" onclick="_prWizFixEmpBank(${e.id})">Fix →</a> to edit their record.</div>`;
      }).join('')}
    </div>` : ''}

    <div class="pr-preview-kpi">
      ${[
        ['Gross Pay',      fmt(totals.gross), 'var(--accent)'],
        ['PAYG Tax',       fmt(totals.tax),   'var(--red)'],
        ['Net Pay',        fmt(totals.net),   'var(--green)'],
        ['Superannuation', fmt(totals.super), 'var(--amber)'],
      ].map(([lbl,val,col])=>`
        <div class="pr-preview-kpi-card">
          <div class="kpi-label">${lbl}</div>
          <div class="kpi-value" style="color:${col}">${val}</div>
        </div>`).join('')}
    </div>

    <div class="tbl-overflow-x pr-wiz-tbl-wrap">
      <table class="inv-list-table pr-wiz-tbl">
        <thead><tr>
          <th>Employee</th>
          <th class="th-r">Gross</th>
          <th class="th-r">PAYG Tax</th>
          <th class="th-r">Super</th>
          <th class="th-r">Net Pay</th>
          <th class="pr-wiz-adj-th"></th>
        </tr></thead>
        <tbody id="pr-preview-body">
          ${slips.map((s, i) => _prPreviewRow(s, i)).join('')}
        </tbody>
      </table>
    </div>`;
}

function _prPreviewRow(s, i) {
  const w   = _prWiz;
  const adj = w.adjustments[String(s.employee_id)] || {};
  const hasAdj = adj._expanded;

  const empObj    = (w.emp_all || []).find(e => e.id === s.employee_id);
  const missingBank = empObj && (!empObj.bank_bsb || !empObj.bank_account);

  const leaveTypes    = _prMeta?.leave_types    || [];
  const allowTypes    = _prMeta?.allowance_types || [];
  const allowances    = adj.allowances || [];

  return `
    <tr class="inv-row pr-preview-row">
      <td>
        <span class="pr-adj-name">${esc(s.employee_name)}</span>
        ${missingBank ? `<span class="wiz-emp-bank-warn" title="Missing BSB or Account No — excluded from ABA file">⚠ No bank</span>` : ''}
        ${s.employee_number ? `<span class="pr-adj-mono-tag">#${esc(s.employee_number)}</span>` : ''}
        ${s.leave_type ? `<div class="pr-adj-sub">${esc(s.leave_type)}: ${s.leave_hours}h</div>` : ''}
        ${(s.overtime_hours||0) > 0 ? `<div class="pr-adj-sub">OT: ${s.overtime_hours}h</div>` : ''}
        ${allowances.length ? `<div class="pr-adj-sub">${allowances.length} allowance${allowances.length>1?'s':''}</div>` : ''}
      </td>
      <td class="inv-amt pr-slip-gross">${fmt(s.gross_pay)}</td>
      <td class="inv-amt pr-slip-tax">${fmt(s.payg_tax)}</td>
      <td class="inv-amt pr-slip-super">${fmt(s.super_amount)}</td>
      <td class="inv-amt pr-slip-net">${fmt(s.net_pay)}</td>
      <td class="td-c-mono">
        <button class="btn btn-outline pr-adj-btn"
                onclick="_prToggleAdj(${s.employee_id})">
          ${hasAdj ? '▲' : '⚙ Adjust'}
        </button>
      </td>
    </tr>
    ${hasAdj ? `
    <tr id="pr-adj-${s.employee_id}" class="pr-adj-row">
      <td colspan="6" class="pr-adj-td">
        <div class="pr-adj-panel">
          <div class="form-grid">
            <div class="form-field">
              <label class="form-lbl">Ordinary Hours</label>
              <input class="form-input" type="number" min="0" step="0.5"
                     id="adj-oh-${s.employee_id}"
                     value="${adj.ordinary_hours != null ? adj.ordinary_hours : ''}"
                     placeholder="${s.ordinary_hours?.toFixed(2) || 'auto'}"
                     oninput="_prAdjField(${s.employee_id},'ordinary_hours',this.value)">
              <span class="pr-adj-hint">Leave blank for standard hours</span>
            </div>
            <div class="form-field">
              <label class="form-lbl">Overtime Hours (×1.5)</label>
              <input class="form-input" type="number" min="0" step="0.5"
                     id="adj-ot-${s.employee_id}"
                     value="${adj.overtime_hours || ''}"
                     oninput="_prAdjField(${s.employee_id},'overtime_hours',this.value)">
            </div>
          </div>
          <div class="form-grid">
            <div class="form-field">
              <label class="form-lbl">Leave Type</label>
              <select class="form-input" id="adj-lt-${s.employee_id}"
                      onchange="_prAdjField(${s.employee_id},'leave_type',this.value)">
                <option value="">— None —</option>
                ${leaveTypes.map(lt=>`<option${(adj.leave_type===lt)?' selected':''}>${lt}</option>`).join('')}
              </select>
            </div>
            <div class="form-field">
              <label class="form-lbl">Leave Hours</label>
              <input class="form-input" type="number" min="0" step="0.5"
                     id="adj-lh-${s.employee_id}"
                     value="${adj.leave_hours || ''}"
                     oninput="_prAdjField(${s.employee_id},'leave_hours',this.value)">
            </div>
          </div>
          <div class="form-field pr-adj-ss-field">
            <label class="form-lbl">Salary Sacrifice Override ($/period)</label>
            <input class="form-input pr-adj-ss-inp" type="number" min="0" step="0.01"
                   id="adj-ss-${s.employee_id}"
                   value="${adj.salary_sacrifice != null ? adj.salary_sacrifice : ''}"
                   placeholder="Employee default"
                   oninput="_prAdjField(${s.employee_id},'salary_sacrifice',this.value)">
          </div>

          <div class="pr-wiz-section-title pr-adj-section">Allowances</div>
          <div id="adj-allow-list-${s.employee_id}">
            ${allowances.map((a, ai) => `
              <div class="pr-allow-row" id="adj-allow-row-${s.employee_id}-${ai}">
                <select class="form-input pr-allow-sel"
                        onchange="_prAdjAllowType(${s.employee_id},${ai},this.value)">
                  ${allowTypes.map(t=>`<option${a.type===t?' selected':''}>${t}</option>`).join('')}
                </select>
                <input class="form-input pr-allow-amt" type="number" min="0" step="0.01"
                       value="${a.amount || ''}" placeholder="Amount"
                       oninput="_prAdjAllowAmt(${s.employee_id},${ai},this.value)">
                <button class="btn btn-outline pr-allow-rm"
                        onclick="_prAdjAllowRemove(${s.employee_id},${ai})">✕</button>
              </div>`).join('')}
          </div>
          <button class="btn btn-outline pr-allow-add"
                  onclick="_prAdjAllowAdd(${s.employee_id})">+ Add Allowance</button>

          <div class="pr-adj-footer">
            <button class="btn btn-outline btn-sm"
                    onclick="_prAdjReset(${s.employee_id})">Reset to Defaults</button>
            <button class="btn btn-primary btn-sm"
                    onclick="_prAdjRecalc(${s.employee_id})">Recalculate</button>
          </div>
        </div>
      </td>
    </tr>` : ''}`;
}

// ── Adjust panel interactions ─────────────────────────────────────────────────

function _prToggleAdj(empId) {
  const w   = _prWiz;
  const key = String(empId);
  if (!w.adjustments[key]) w.adjustments[key] = {};
  w.adjustments[key]._expanded = !w.adjustments[key]._expanded;
  // Re-render just the preview body rather than the whole modal
  _prRefreshPreviewBody();
}

function _prAdjField(empId, field, value) {
  const w   = _prWiz;
  const key = String(empId);
  if (!w.adjustments[key]) w.adjustments[key] = {};
  if (value === '' || value == null) {
    delete w.adjustments[key][field];
  } else {
    const num = ['ordinary_hours','overtime_hours','leave_hours','salary_sacrifice'].includes(field);
    w.adjustments[key][field] = num ? parseFloat(value) : value;
  }
}

function _prAdjAllowAdd(empId) {
  const w   = _prWiz;
  const key = String(empId);
  if (!w.adjustments[key]) w.adjustments[key] = {};
  if (!w.adjustments[key].allowances) w.adjustments[key].allowances = [];
  const defaultType = (_prMeta?.allowance_types || ['Tool Allowance'])[0];
  w.adjustments[key].allowances.push({ type: defaultType, amount: 0 });
  w.adjustments[key]._expanded = true;
  _prRefreshPreviewBody();
}

function _prAdjAllowRemove(empId, idx) {
  const key = String(empId);
  if (_prWiz.adjustments[key]?.allowances) {
    _prWiz.adjustments[key].allowances.splice(idx, 1);
  }
  _prRefreshPreviewBody();
}

function _prAdjAllowType(empId, idx, value) {
  const key = String(empId);
  if (_prWiz.adjustments[key]?.allowances?.[idx] != null) {
    _prWiz.adjustments[key].allowances[idx].type = value;
  }
}

function _prAdjAllowAmt(empId, idx, value) {
  const key = String(empId);
  if (_prWiz.adjustments[key]?.allowances?.[idx] != null) {
    _prWiz.adjustments[key].allowances[idx].amount = parseFloat(value) || 0;
  }
}

function _prAdjReset(empId) {
  const key = String(empId);
  const expanded = _prWiz.adjustments[key]?._expanded;
  _prWiz.adjustments[key] = { _expanded: expanded };
  _prRefreshPreviewBody();
}

async function _prAdjRecalc(empId) {
  // Recalculate a single employee without re-fetching others
  const w   = _prWiz;
  const key = String(empId);
  const adj = w.adjustments[key] || {};

  const btn = document.querySelector(`#pr-adj-${empId} .btn-primary`);
  if (btn) { btn.disabled = true; btn.textContent = 'Calculating…'; }

  try {
    const res = await _pPost('/api/payroll/pay-runs/preview', {
      period_start:  w.period_start,
      period_end:    w.period_end,
      payment_date:  w.payment_date,
      frequency:     w.frequency,
      employee_ids:  [empId],
      adjustments:   { [key]: adj },
    });

    if (res.slips && res.slips.length) {
      // Replace this slip in the preview
      const idx = (w.preview.slips || []).findIndex(s => s.employee_id === empId);
      if (idx >= 0) {
        w.preview.slips[idx] = res.slips[0];
      } else {
        w.preview.slips.push(res.slips[0]);
      }
      // Recalculate totals
      const slips = w.preview.slips;
      w.preview.totals = {
        gross: slips.reduce((s,x)=>s+(x.gross_pay||0),0),
        tax:   slips.reduce((s,x)=>s+(x.payg_tax||0),0),
        net:   slips.reduce((s,x)=>s+(x.net_pay||0),0),
        super: slips.reduce((s,x)=>s+(x.super_amount||0),0),
      };
    }
    _prRefreshPreviewBody();
    // Update KPI strip
    const kpiEl = document.querySelector('.pr-preview-kpi');
    if (kpiEl) {
      const t = w.preview.totals;
      kpiEl.querySelectorAll('.kpi-value').forEach((el, i) => {
        el.textContent = [fmt(t.gross), fmt(t.tax), fmt(t.net), fmt(t.super)][i];
      });
    }
  } catch (e) {
    toast(e.message || 'Recalculation failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Recalculate'; }
  }
}

function _prRefreshPreviewBody() {
  const tbody = document.getElementById('pr-preview-body');
  if (!tbody || !_prWiz?.preview?.slips) return;
  tbody.innerHTML = _prWiz.preview.slips.map((s, i) => _prPreviewRow(s, i)).join('');
}

// ── Footer buttons ────────────────────────────────────────────────────────────

function _prWizFooterHtml() {
  const w = _prWiz;
  if (w.step === 1) {
    return `
      <button class="btn btn-outline" onclick="_prWizClose()">Cancel</button>
      <div class="flex-spacer"></div>
      <button class="btn btn-primary" onclick="_prWizGoPreview()">Preview →</button>`;
  }
  // Step 2
  return `
    <button class="btn btn-outline" onclick="_prWizBack()">← Back</button>
    <div class="flex-spacer"></div>
    <span id="pr-wiz-save-err" class="pr-wiz-save-err"></span>
    <button class="btn btn-primary" id="pr-wiz-create-btn"
            onclick="_prWizCreateDraft()" ${w.save_busy?'disabled':''}>
      ${w.save_busy ? 'Saving…' : (w.editing_run_id ? 'Save Changes' : 'Create Draft Pay Run')}
    </button>`;
}

// ── Step navigation ───────────────────────────────────────────────────────────

async function _prWizGoPreview() {
  const w = _prWiz;

  // Read current step-1 field values back into state
  const freqEl  = document.getElementById('wiz-frequency');
  const psEl    = document.getElementById('wiz-period-start');
  const peEl    = document.getElementById('wiz-period-end');
  const pdEl    = document.getElementById('wiz-payment-date');
  if (freqEl) w.frequency     = freqEl.value;
  if (psEl)   w.period_start  = psEl.value;
  if (peEl)   w.period_end    = peEl.value;
  if (pdEl)   w.payment_date  = pdEl.value;

  // Sync individual emp checkboxes if in manual mode
  if (w.emp_ids !== null) {
    w.emp_ids = new Set(
      [...document.querySelectorAll('.wiz-emp-cb')]
        .filter(cb => cb.checked)
        .map(cb => parseInt(cb.dataset.id))
    );
  }

  if (!_prWizValidateDates()) return;

  // Resolve the actual IDs to send: in all-mode use all frequency-matching employees.
  // Commit back into w.emp_ids so the create-draft payload uses the same list.
  if (w.emp_ids === null) {
    w.emp_ids = new Set(
      (w.emp_all || [])
        .filter(e => _prWizFreqMatch(w.frequency, e.pay_frequency))
        .map(e => e.id)
    );
  }

  const empCount = w.emp_ids.size;
  if (empCount === 0) {
    document.getElementById('wiz-date-err').textContent = 'Select at least one employee.';
    return;
  }

  // Move to step 2 and show loading
  w.step = 2;
  w.preview_busy = true;
  w.preview = null;
  _prWizRefreshBody();
  document.getElementById('pr-wiz-footer').innerHTML = _prWizFooterHtml();

  try {
    const payload = {
      period_start:  w.period_start,
      period_end:    w.period_end,
      payment_date:  w.payment_date,
      frequency:     w.frequency,
      employee_ids:  [...w.emp_ids],
      adjustments:   _prWizCleanAdjustments(),
    };
    w.preview = await _pPost('/api/payroll/pay-runs/preview', payload);
  } catch (e) {
    w.preview = { slips: [], totals: { gross:0, tax:0, net:0, super:0 }, errors: [{ employee_name: 'All', error: e.message }] };
  }

  w.preview_busy = false;
  _prWizRefreshBody();
  document.getElementById('pr-wiz-footer').innerHTML = _prWizFooterHtml();

  // Show leave reminder if any Approved leave requests overlap this pay period
  _prWizLeaveReminder();
}

function _prWizBack() {
  _prWiz.step = 1;
  _prWizRefreshBody();
}

async function _prWizLeaveReminder() {
  const w = _prWiz;
  if (!w || !w.period_start || !w.period_end) return;

  let requests;
  try {
    requests = await apiFetch('/api/leave/requests');
  } catch (_) { return; }

  // Filter: Approved status, leave overlaps the pay period
  const ps = w.period_start;
  const pe = w.period_end;
  const overlapping = (requests || []).filter(r =>
    r.status === 'Approved' &&
    r.start_date && r.end_date &&
    r.start_date <= pe && r.end_date >= ps
  );
  if (!overlapping.length) return;

  const rows = overlapping.map(r => `
    <tr>
      <td class="pr-leave-td">${esc(r.employee_name)}</td>
      <td class="pr-leave-td">${esc(r.type_name || '\u2014')}</td>
      <td class="pr-leave-td inv-mono">${fmtDate(r.start_date)} \u2013 ${fmtDate(r.end_date)}</td>
      <td class="pr-leave-td col-r inv-mono">${r.hours_requested != null ? Number(r.hours_requested).toFixed(2) + 'h' : '\u2014'}</td>
    </tr>`).join('');

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box modal-md modal-tall">
      <div class="modal-hdr">
        <span>\u26a0 Approved Leave Overlaps This Pay Period</span>
      </div>
      <div class="modal-body">
        <p class="pr-modal-hint">
          The following approved leave requests overlap the pay period
          <strong>${fmtDate(ps)} \u2013 ${fmtDate(pe)}</strong>.
          Leave is not automatically included in pay runs \u2014 review and include
          leave hours manually in the per-employee adjustment panel if required.
        </p>
        <div class="tbl-overflow-x">
          <table class="inv-list-table">
            <thead><tr>
              <th>Employee</th><th>Leave Type</th><th>Dates</th><th class="th-r">Hours</th>
            </tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-primary btn-sm" onclick="this.closest('.modal-bd').remove()">OK, I'll Check</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
}

async function _prWizCreateDraft() {
  const w = _prWiz;
  w.save_busy = true;
  const errEl = document.getElementById('pr-wiz-save-err');
  if (errEl) errEl.textContent = '';
  const btn = document.getElementById('pr-wiz-create-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }

  try {
    if (w.editing_run_id) {
      await _pMut('DELETE', `/api/payroll/pay-runs/${w.editing_run_id}`);
    }

    const payload = {
      period_start:  w.period_start,
      period_end:    w.period_end,
      payment_date:  w.payment_date,
      frequency:     w.frequency,
      employee_ids:  w.emp_ids ? [...w.emp_ids] : [],
      adjustments:   _prWizCleanAdjustments(),
    };
    const result = await _pPost('/api/payroll/pay-runs', payload);
    toast(`Pay run ${result.run_number} ${w.editing_run_id ? 'updated' : 'created'}`);

    _prWizClose();

    // Reload list then open the new run
    _prAll = (await apiFetch('/api/payroll/pay-runs')) || [];
    _renderPayRunsPage();
    _prOpen(result.id);

  } catch (e) {
    w.save_busy = false;
    if (errEl) errEl.textContent = e.message || 'Could not save pay run.';
    if (btn) { btn.disabled = false; btn.textContent = w.editing_run_id ? 'Save Changes' : 'Create Draft Pay Run'; }
  }
}

// Strip the internal _expanded key before sending to server
function _prWizCleanAdjustments() {
  const out = {};
  for (const [key, adj] of Object.entries(_prWiz.adjustments || {})) {
    const { _expanded, ...clean } = adj;
    // Only include if there's something meaningful
    const hasContent = Object.keys(clean).some(k =>
      clean[k] != null && !(Array.isArray(clean[k]) && clean[k].length === 0)
    );
    if (hasContent) out[key] = clean;
  }
  return out;
}


// ═══════════════════════════════════════════════════════════════════════════
// ── STP SUBMISSIONS VIEWER  (Stage 5g)  ─────────────────────────────────────
//
//  • List all STP submissions with status badges, run number, FY, timestamps
//  • Lodge STP button on Finalised pay run detail — prompts ABN, calls
//    POST /api/payroll/pay-runs/<id>/lodge-stp, records in stp_submissions
//  • Download XML button — opens /api/payroll/stp-submissions/<id>/xml
//  • Mark Lodged / Update Status inline on each row
//
// State: _stpAll (cached list), _stpFilter (status pill)
// ═══════════════════════════════════════════════════════════════════════════

let _stpAll    = [];
let _stpFilter = 'All';

const STP_STATUS_FILTERS = ['All', 'Pending', 'Submitted', 'Lodged', 'Rejected'];

async function _prLoadStp() {
  _prView = 'stp';
  _stpAll = (await apiFetch('/api/payroll/stp-submissions')) || [];
  _renderStpPage();
}

function _stpFiltered() {
  if (_stpFilter === 'All') return _stpAll;
  return _stpAll.filter(s => (s.status || 'Pending') === _stpFilter);
}

function _renderStpPage() {
  const rows = _stpFiltered();
  const mc   = document.getElementById('module-content');

  const counts = {};
  STP_STATUS_FILTERS.forEach(f => counts[f] = 0);
  counts['All'] = _stpAll.length;
  _stpAll.forEach(s => {
    const st = s.status || 'Pending';
    if (st in counts) counts[st]++;
  });

  mc.innerHTML = `
    <div class="inv-toolbar">
      <div class="inv-filter-group">
        ${STP_STATUS_FILTERS.map(f => `
          <button class="filter-btn${_stpFilter === f ? ' active' : ''}"
                  onclick="_stpSetFilter('${f}')">
            ${f}${counts[f] ? ` <span class="pr-filter-count">(${counts[f]})</span>` : ''}
          </button>`).join('')}
      </div>
      <div class="pr-toolbar-actions">
        <button class="btn btn-primary" onclick="_stpFinalise()" title="Lodge end-of-year Finalisation declaration">
          🏁 Finalisation
        </button>
        <button class="btn btn-outline" onclick="_prLoadPayRuns()" title="Back to Pay Runs">
          ← Pay Runs
        </button>
      </div>
    </div>

    <div class="stp-notice">
      <strong>Important:</strong> dbox generates compliant STP Phase 2 XML payloads but is
      not a registered ATO lodgement channel. Download the XML and lodge via your
      registered tax agent, BAS agent, or the ATO Business Portal.
    </div>

    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        <th>Run #</th>
        <th>FY</th>
        <th>Type</th>
        <th>Generated</th>
        <th>Status</th>
        <th>Note</th>
        <th class="th-r">Actions</th>
      </tr></thead><tbody>
        ${rows.length
          ? rows.map(_stpRow).join('')
          : `<tr><td colspan="7" class="pr-tbl-empty">No STP submissions yet</td></tr>`}
      </tbody></table>
    </div></div>
    <div class="mt-8">
      <span class="count-pill">${rows.length} submission${rows.length !== 1 ? 's' : ''}</span>
    </div>`;
}

function _stpRow(s) {
  const status = s.status || 'Pending';
  const badgeCls = status === 'Lodged'   ? 'badge-paid'
                 : status === 'Rejected' ? 'badge-overdue'
                 : status === 'Submitted'? 'badge-sent'
                 : 'badge-draft';  // Pending / other

  const note = (s.message || '').split('\n')[0]; // first line only

  return `<tr>
    <td class="mono">${esc(s.run_number || '—')}</td>
    <td class="mono">${esc(s.fy_year || '—')}</td>
    <td>${esc(s.submission_type || 'Update')}</td>
    <td class="inv-mono">${esc((s.submitted_at || '').replace('T', ' ').slice(0,16))}</td>
    <td><span class="badge ${badgeCls}">${esc(status)}</span></td>
    <td class="pr-note-td" title="${esc(s.message || '')}">${esc(note)}</td>
    <td class="pr-act-td">
      ${s.payload_xml
        ? `<button class="btn btn-outline pr-btn-row"
                   onclick="_stpViewXml(${s.id})">👁 View XML</button>
           <button class="btn btn-outline pr-btn-row"
                   onclick="_stpDownloadXml(${s.id})">⬇ XML</button>`
        : ''}
      ${status !== 'Lodged'
        ? `<button class="btn btn-outline pr-btn-row"
                   onclick="_stpMarkLodged(${s.id})">✓ Mark Lodged</button>`
        : ''}
      <button class="btn btn-outline pr-btn-row"
              onclick="_stpUpdateStatus(${s.id}, '${esc(status)}')">✎ Status</button>
    </td>
  </tr>`;
}

function _stpSetFilter(f) {
  _stpFilter = f;
  _renderStpPage();
}

// ── Download XML ─────────────────────────────────────────────────────────────

function _stpDownloadXml(subId) {
  window.open(`/api/payroll/stp-submissions/${subId}/xml`, '_blank');
}

// ── Mark Lodged ───────────────────────────────────────────────────────────────

async function _stpMarkLodged(subId) {
  if (!confirm('Mark this submission as Lodged?\n\nThis confirms you have provided the XML to your tax agent or STP filing service.')) return;
  try {
    await _pPost(`/api/payroll/stp-submissions/${subId}/mark-lodged`);
    toast('Submission marked as Lodged');
    _stpFilter = 'All';
    _stpAll = (await apiFetch('/api/payroll/stp-submissions')) || [];
    _renderStpPage();
  } catch (e) {
    toast(e.message || 'Could not update status', 'err');
  }
}

// ── Update Status ─────────────────────────────────────────────────────────────

function _stpUpdateStatus(subId, currentStatus) {
  const statuses = ['Pending', 'Submitted', 'Lodged', 'Rejected'];
  const opts = statuses.map(s =>
    `<option value="${s}"${s === currentStatus ? ' selected' : ''}>${s}</option>`
  ).join('');

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box modal-xs">
      <div class="modal-hdr"><span>Update STP Status</span></div>
      <div class="modal-body">
        <div class="edt-field" style="margin-bottom:14px">
          <label class="edt-lbl">Status</label>
          <select class="edt-sel" id="stp-upd-status">${opts}</select>
        </div>
        <div class="edt-field">
          <label class="edt-lbl">Note</label>
          <textarea class="edt-ta" id="stp-upd-note" rows="3"
                    placeholder="Optional — e.g. lodgement reference, agent name…"></textarea>
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="_stpUpdateStatusSave(${subId})">Save</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
}

async function _stpUpdateStatusSave(subId) {
  const status = document.getElementById('stp-upd-status').value;
  const note   = document.getElementById('stp-upd-note').value.trim();
  const bd     = document.getElementById('stp-upd-status').closest('.modal-bd');
  try {
    await fetch(`/api/payroll/stp-submissions/${subId}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, note }),
    }).then(async r => {
      const d = await r.json();
      if (!d.ok) throw new Error(d.error || 'Save failed');
    });
    bd.remove();
    toast('Status updated');
    _stpFilter = 'All';
    _stpAll = (await apiFetch('/api/payroll/stp-submissions')) || [];
    _renderStpPage();
  } catch (e) {
    toast(e.message || 'Could not update status', 'err');
  }
}

// ── View XML ──────────────────────────────────────────────────────────────────

async function _stpViewXml(subId) {
  // Open modal immediately with loading state, then load XML
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = `stp-xml-modal-${subId}`;
  bd.innerHTML = `
    <div class="modal-box stp-xml-box">
      <div class="modal-hdr">
        <span>STP XML Payload — Submission #${subId}</span>
      </div>
      <div class="modal-body modal-body-flex">
        <div class="state-loading" id="stp-xml-body-${subId}">Loading…</div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" id="stp-xml-copy-${subId}" style="display:none"
                onclick="_stpCopyXml(${subId})">📋 Copy</button>
        <button class="btn btn-outline btn-sm"
                onclick="_stpDownloadXml(${subId})">⬇ Download</button>
        <button class="btn btn-outline btn-sm"
                onclick="this.closest('.modal-bd').remove()">Close</button>
      </div>
    </div>`;
  document.body.appendChild(bd);

  try {
    const resp = await fetch(`/api/payroll/stp-submissions/${subId}/xml`);
    if (!resp.ok) throw new Error(`Server error ${resp.status}`);
    const xml = await resp.text();

    // Pretty-print: indent XML for readability
    const pretty = _stpFormatXml(xml);

    const bodyEl = document.getElementById(`stp-xml-body-${subId}`);
    if (!bodyEl) return; // modal closed while loading
    bodyEl.outerHTML = `<pre class="stp-xml-pre" id="stp-xml-content-${subId}">${esc(pretty)}</pre>`;
    const copyBtn = document.getElementById(`stp-xml-copy-${subId}`);
    if (copyBtn) copyBtn.style.display = '';
  } catch (e) {
    const bodyEl = document.getElementById(`stp-xml-body-${subId}`);
    if (bodyEl) bodyEl.outerHTML = `<div class="state-error">Failed to load XML: ${esc(e.message)}</div>`;
  }
}

function _stpFormatXml(xml) {
  // Simple indenter — not a full parser, but handles standard STP XML cleanly
  let indent = 0;
  return xml
    .replace(/>\s*</g, '><')  // normalise whitespace between tags
    .replace(/(<[^/][^>]*[^/]>|<[^/][^>]*[^/]$)/g, m => {
      // Opening tag that isn't self-closing
      if (m.match(/^<[^?!][^>]*[^/]>$/) && !m.match(/^<[^>]+\/>$/)) {
        return '\n' + '  '.repeat(indent++) + m;
      }
      return m;
    })
    .replace(/(<\/[^>]+>)/g, m => '\n' + '  '.repeat(--indent < 0 ? (indent = 0) : indent) + m)
    .replace(/(<[^>]+\/>)/g, m => '\n' + '  '.repeat(indent) + m)
    .trim();
}

async function _stpCopyXml(subId) {
  const el = document.getElementById(`stp-xml-content-${subId}`);
  if (!el) return;
  try {
    await navigator.clipboard.writeText(el.textContent);
    toast('XML copied to clipboard');
  } catch {
    toast('Copy failed — select text manually', 'err');
  }
}

// ── STP Finalisation declaration  ────────────────────────────────────────────
//
//  End-of-year declaration (submission_type = 'Finalisation').
//  Not tied to a specific pay run — uses YTD totals from the most recent
//  finalised run. Called from the 🏁 Finalisation button in the STP toolbar.

async function _stpFinalise() {
  // Pre-fill ABN from company settings
  let defaultAbn = '';
  try {
    const co = await apiFetch('/api/company');
    defaultAbn = (co.abn || '').replace(/\s/g, '');
  } catch (_) {}

  const abn = prompt(
    'STP Finalisation Declaration\n\n' +
    'This generates a Finalisation event for the current financial year.\n' +
    'It confirms to the ATO that the YTD figures reported are final.\n\n' +
    'Enter your company ABN (11 digits, no spaces):',
    defaultAbn
  );
  if (abn === null) return;  // cancelled

  const cleanAbn = abn.replace(/\s/g, '') || defaultAbn;
  if (!cleanAbn || !/^\d{11}$/.test(cleanAbn)) {
    toast('Invalid ABN — must be 11 digits', 'err');
    return;
  }

  if (!confirm(
    'Generate STP Finalisation declaration?\n\n' +
    'This creates a Finalisation XML payload using end-of-year YTD totals.\n' +
    'You will need to provide the XML to your registered tax agent or\n' +
    'STP filing service to complete the end-of-year lodgement.\n\n' +
    'Proceed?'
  )) return;

  try {
    const result = await _pPost('/api/payroll/stp-finalisation', { abn: cleanAbn });
    toast(`Finalisation declaration generated — Submission #${result.submission_id}`);
    _stpAll = (await apiFetch('/api/payroll/stp-submissions')) || [];
    _renderStpPage();
  } catch (e) {
    toast(e.message || 'Finalisation failed', 'err');
  }
}


async function _stpLodge(runId, runNumber) {
  // Fetch company ABN for pre-fill
  let defaultAbn = '';
  try {
    const co = await apiFetch('/api/company');
    defaultAbn = (co.abn || '').replace(/\s/g, '');
  } catch (_) {}

  const abn = prompt(
    `Generate STP Phase 2 XML for Pay Run ${runNumber}?\n\n` +
    `Enter your company ABN (11 digits, no spaces):\n` +
    `(Leave blank to use company ABN from settings)`,
    defaultAbn
  );
  if (abn === null) return;  // cancelled

  const cleanAbn = abn.replace(/\s/g, '') || defaultAbn;
  if (!cleanAbn || !/^\d{11}$/.test(cleanAbn)) {
    toast('Invalid ABN — must be 11 digits', 'err');
    return;
  }

  try {
    const result = await _pPost(`/api/payroll/pay-runs/${runId}/lodge-stp`, { abn: cleanAbn });
    toast(`STP XML generated — Submission #${result.submission_id}`);
    // Reload pay run detail to update footer (run status → STP_Lodged)
    const data = await apiFetch(`/api/payroll/pay-runs/${runId}`);
    _renderPayRunDetail(data);
    // Offer to view STP submissions list
    if (confirm('STP XML generated successfully.\n\nWould you like to view the Submissions list to download the XML?')) {
      detClose();
      await _prLoadStp();
    }
  } catch (e) {
    toast(e.message || 'STP generation failed', 'err');
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// SUPER PAYMENT BATCH VIEWER  (Stage 5k-b)
//   • Lists all super payment batches (Draft / Paid), newest first
//   • Accruals summary bar showing unremitted totals from finalised runs
//   • Click batch row → slide-over with per-employee lines
// ═══════════════════════════════════════════════════════════════════════════

let _superAll        = [];
let _superAccruals   = [];
let _superFilter     = 'All';
let _superDetailPmt  = null;
let _superDetailLines = [];

const SUPER_STATUS_FILTERS = ['All', 'Draft', 'Paid'];

async function _prLoadSuper() {
  _prView = 'super';
  const mc = document.getElementById('module-content');
  mc.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    [_superAll, _superAccruals] = await Promise.all([
      apiFetch('/api/payroll/super-payments').catch(() => []),
      apiFetch('/api/payroll/super-accruals').catch(() => []),
    ]);
    _superAll      = _superAll      || [];
    _superAccruals = _superAccruals || [];
    _renderSuperList();
  } catch (e) {
    mc.innerHTML = `<div class="state-error">Failed to load super payments: ${esc(e.message)}</div>`;
  }
}

function _superFiltered() {
  if (_superFilter === 'All') return _superAll;
  return _superAll.filter(b => (b.status || 'Draft') === _superFilter);
}

function _renderSuperList() {
  const rows = _superFiltered();
  const mc   = document.getElementById('module-content');

  // Pill counts
  const counts = { All: _superAll.length, Draft: 0, Paid: 0 };
  _superAll.forEach(b => {
    const st = b.status || 'Draft';
    if (st in counts) counts[st]++;
  });

  // Accruals totals
  const accSgc  = _superAccruals.reduce((s, a) => s + (a.sgc_total || 0), 0);
  const accSal  = _superAccruals.reduce((s, a) => s + (a.salary_sacrifice_total || 0), 0);
  const accTot  = accSgc + accSal;
  const accN    = _superAccruals.length;

  const accrualBar = accN > 0
    ? `<div class="stp-notice stp-notice--amber">
        <strong>Unremitted accruals from finalised pay runs:</strong>
        ${accN} employee${accN !== 1 ? 's' : ''}
        &nbsp;·&nbsp; SGC: ${fmt(accSgc)}
        &nbsp;·&nbsp; Salary Sacrifice: ${fmt(accSal)}
        &nbsp;·&nbsp; <strong>Total pending: ${fmt(accTot)}</strong>
       </div>`
    : `<div class="stp-notice stp-notice--success">
        <strong>All super accruals have been remitted.</strong> No unremitted amounts from finalised pay runs.
       </div>`;

  mc.innerHTML = `
    <div class="inv-toolbar">
      <div class="inv-filter-group">
        ${SUPER_STATUS_FILTERS.map(f => `
          <button class="filter-btn${_superFilter === f ? ' active' : ''}"
                  onclick="_superSetFilter('${f}')">
            ${f}${counts[f] ? ` <span class="pr-filter-count">(${counts[f]})</span>` : ''}
          </button>`).join('')}
      </div>
      <div class="pr-toolbar-actions">
        <button class="btn btn-outline" onclick="_prLoadPayRuns()" title="Back to Pay Runs">
          ← Pay Runs
        </button>
        <button class="btn btn-primary" onclick="_superNewBatch()" title="Create super payment batch from accruals">
          + New Batch
        </button>
      </div>
    </div>

    ${accrualBar}

    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        <th>Batch #</th>
        <th>Quarter</th>
        <th>Payment Date</th>
        <th>Due Date</th>
        <th>Method</th>
        <th class="th-r">SGC</th>
        <th class="th-r">Sal. Sacrifice</th>
        <th class="th-r">Voluntary</th>
        <th class="th-r">Total</th>
        <th>Status</th>
      </tr></thead><tbody>
        ${rows.length
          ? rows.map(_superRow).join('')
          : `<tr><td colspan="10" class="pr-tbl-empty">No super payment batches yet</td></tr>`}
      </tbody></table>
    </div></div>
    <div class="mt-8">
      <span class="count-pill">${rows.length} batch${rows.length !== 1 ? 'es' : ''}</span>
    </div>`;
}

function _superRow(b) {
  const status = b.status || 'Draft';
  const badgeCls = status === 'Paid' ? 'badge-paid' : 'badge-draft';
  const overdue = status !== 'Paid' && b.due_date && b.due_date < isoToday();
  return `
    <tr class="inv-row" onclick="_superDetail(${b.id})">
      <td class="inv-mono">${esc(b.payment_number)}</td>
      <td>${esc(b.quarter || '—')}</td>
      <td>${esc(b.payment_date || '—')}</td>
      <td>${overdue
        ? `<span class="badge badge-overdue">${esc(b.due_date || '—')} ⚠</span>`
        : esc(b.due_date || '—')}</td>
      <td>${esc(b.payment_method || 'SuperStream')}</td>
      <td class="inv-amt col-amber">${fmt(b.total_sgc || 0)}</td>
      <td class="inv-amt col-amber">${fmt(b.total_salary_sacrifice || 0)}</td>
      <td class="inv-amt">${fmt(b.total_voluntary || 0)}</td>
      <td class="inv-amt col-amber pr-slip-net">${fmt(b.total_amount || 0)}</td>
      <td><span class="badge ${badgeCls}">${status}</span></td>
    </tr>`;
}

function _superSetFilter(f) {
  _superFilter = f;
  _renderSuperList();
}

// ── New Batch dialog ──────────────────────────────────────────────────────────

function _superNewBatch() {
  if (!_superAccruals.length) {
    alert('No unremitted super accruals found.\n\nFinalise one or more pay runs first.');
    return;
  }

  const today = isoToday();

  // Build per-employee rows from accruals
  const rowsHtml = _superAccruals.map((a, i) => {
    const name   = esc((a.last_name || '') + ', ' + (a.first_name || ''));
    const empNum = esc(a.employee_number || '');
    const fund   = esc(a.super_fund_name || '—');
    const member = esc(a.super_member_number || '—');
    const total  = (a.sgc_total || 0) + (a.salary_sacrifice_total || 0);
    return `
      <tr class="${i % 2 ? 'alt' : ''}">
        <td class="snb-emp-cell">
          <label class="snb-emp-label">
            <input type="checkbox" class="snb-line-chk snb-chk" data-idx="${i}" checked>
            <span>${name}<span class="snb-emp-num">${empNum}</span></span>
          </label>
        </td>
        <td class="snb-cell">${fund}</td>
        <td class="snb-cell-mono">${member}</td>
        <td class="pr-super-amt">${fmt(a.sgc_total || 0)}</td>
        <td class="pr-super-amt">${fmt(a.salary_sacrifice_total || 0)}</td>
        <td class="snb-vol-cell"><input type="number" class="snb-vol snb-inp-vol" data-idx="${i}" value="0" step="0.01" min="0"></td>
        <td class="pr-super-amt-bold">${fmt(total)}</td>
      </tr>`;
  }).join('');

  // Create or reuse modal
  let modal = document.getElementById('snb-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id        = 'snb-modal';
    modal.className = 'modal-bd';
    modal.addEventListener('click', e => { if (e.target === modal) _superNewBatchClose(); });
    document.body.appendChild(modal);
  }

  modal.innerHTML = `
    <div class="modal-box modal-lg">
      <div class="modal-title">💰 New Super Payment Batch</div>

      <div class="form-grid" style="margin-bottom:16px">
        <div class="modal-field">
          <label class="modal-lbl">Payment Date <span class="col-red">*</span></label>
          <input class="modal-inp" id="snb-date" type="date" value="${today}">
        </div>
        <div class="modal-field">
          <label class="modal-lbl">Payment Method</label>
          <select class="modal-sel" id="snb-method">
            <option value="SuperStream" selected>SuperStream</option>
            <option value="Cheque">Cheque</option>
            <option value="EFT">EFT</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <div class="modal-field">
          <label class="modal-lbl">Reference</label>
          <input class="modal-inp" id="snb-reference" type="text" placeholder="Optional reference">
        </div>
        <div class="modal-field">
          <label class="modal-lbl">Notes</label>
          <input class="modal-inp" id="snb-notes" type="text" placeholder="Optional notes">
        </div>
      </div>

      <div class="snb-sec-lbl">
        Employees to include
        <span class="snb-sec-hint">— uncheck to exclude an employee from this batch</span>
      </div>

      <div class="snb-scroll">
        <table class="inv-list-table snb-table">
          <thead><tr>
            <th style="width:220px">Employee</th>
            <th>Fund</th>
            <th>Member #</th>
            <th class="th-r">SGC</th>
            <th class="th-r">Sal. Sacrifice</th>
            <th class="th-r">Voluntary</th>
            <th class="th-r">Total</th>
          </tr></thead>
          <tbody id="snb-lines">${rowsHtml}</tbody>
        </table>
      </div>

      <div id="snb-totals" class="snb-totals"></div>

      <div id="snb-err" class="snb-err"></div>

      <div class="modal-acts">
        <button class="btn btn-outline" onclick="_superNewBatchClose()">Cancel</button>
        <button class="btn btn-primary" id="snb-create-btn" onclick="_superNewBatchCreate()">
          Create Batch
        </button>
      </div>
    </div>`;

  modal.classList.add('open');
  _superNewBatchUpdateTotals();

  // Live totals as checkboxes or voluntary inputs change
  modal.querySelectorAll('.snb-line-chk').forEach(chk => {
    chk.addEventListener('change', _superNewBatchUpdateTotals);
  });
  modal.querySelectorAll('.snb-vol').forEach(inp => {
    inp.addEventListener('input', _superNewBatchUpdateTotals);
  });
}

function _superNewBatchUpdateTotals() {
  const totalsEl = document.getElementById('snb-totals');
  if (!totalsEl) return;
  let sgc = 0, sal = 0, vol = 0, n = 0;
  document.querySelectorAll('.snb-line-chk').forEach(chk => {
    if (!chk.checked) return;
    const i = parseInt(chk.dataset.idx, 10);
    const a = _superAccruals[i];
    if (!a) return;
    sgc += a.sgc_total || 0;
    sal += a.salary_sacrifice_total || 0;
    vol += parseFloat(document.querySelector(`.snb-vol[data-idx="${i}"]`)?.value) || 0;
    n++;
  });
  totalsEl.innerHTML = n === 0
    ? `<span class="col-red">No employees selected</span>`
    : `${n} employee${n !== 1 ? 's' : ''} &nbsp;·&nbsp;
       SGC: ${fmt(sgc)} &nbsp;·&nbsp;
       Sal. Sacrifice: ${fmt(sal)} &nbsp;·&nbsp;
       ${vol > 0 ? `Voluntary: ${fmt(vol)} &nbsp;·&nbsp; ` : ''}<strong>Total: ${fmt(sgc + sal + vol)}</strong>`;
}

function _superNewBatchClose() {
  const m = document.getElementById('snb-modal');
  if (m) m.classList.remove('open');
}

async function _superNewBatchCreate() {
  const btn     = document.getElementById('snb-create-btn');
  const errEl   = document.getElementById('snb-err');
  const dateVal = (document.getElementById('snb-date')?.value || '').trim();
  const method  = document.getElementById('snb-method')?.value || 'SuperStream';
  const ref     = (document.getElementById('snb-reference')?.value || '').trim();
  const notes   = (document.getElementById('snb-notes')?.value || '').trim();

  // Validate
  if (!dateVal) {
    errEl.textContent = 'Payment date is required.';
    errEl.style.display = '';
    return;
  }

  // Collect selected lines from _superAccruals
  const lines = [];
  document.querySelectorAll('.snb-line-chk').forEach(chk => {
    if (!chk.checked) return;
    const i = parseInt(chk.dataset.idx, 10);
    const a = _superAccruals[i];
    if (!a) return;
    lines.push({
      employee_id:       a.employee_id,
      fund_name:         a.super_fund_name,
      fund_abn:          a.super_fund_abn,
      fund_usi:          a.super_fund_usi,
      member_number:     a.super_member_number,
      sgc_amount:        a.sgc_total        || 0,
      salary_sacrifice:  a.salary_sacrifice_total || 0,
      voluntary_amount:  parseFloat(document.querySelector(`.snb-vol[data-idx="${i}"]`)?.value) || 0,
      period_start:      a.period_start,
      period_end:        a.period_end,
      pay_run_ids:       (a.pay_run_ids || '').toString().split(',').map(Number).filter(Boolean),
    });
  });

  if (!lines.length) {
    errEl.textContent = 'Select at least one employee to include in the batch.';
    errEl.style.display = '';
    return;
  }

  errEl.style.display = 'none';
  btn.disabled = true;
  btn.textContent = 'Creating…';

  try {
    await _pPost('/api/payroll/super-payments', {
      payment_date:   dateVal,
      payment_method: method,
      reference:      ref  || null,
      notes:          notes || null,
      lines,
    });
    _superNewBatchClose();
    await _prLoadSuper();   // refresh list + accruals
  } catch (e) {
    errEl.textContent = e.message || 'Failed to create batch.';
    errEl.style.display = '';
    btn.disabled = false;
    btn.textContent = 'Create Batch';
  }
}

// ── Mark batch as Paid (finalise) ─────────────────────────────────────────────

async function _superMarkPaid(paymentId) {
  if (!confirm('Mark this super batch as Paid and post the GL journal?\n\nThis cannot be undone.')) return;
  try {
    const { payment: pmt, lines } = await _pPost(
      `/api/payroll/super-payments/${paymentId}/finalise`, {}
    );
    _renderSuperDetail(pmt, lines);   // refresh slide-over in place
    // Refresh list + accruals silently so status badge and banner both update
    Promise.all([
      apiFetch('/api/payroll/super-payments'),
      apiFetch('/api/payroll/super-accruals'),
    ]).then(([payments, accruals]) => {
      _superAll      = payments || [];
      _superAccruals = accruals || [];
      _renderSuperList();
    }).catch(() => {});
  } catch (e) {
    alert('Failed to mark as Paid: ' + e.message);
  }
}

async function _superDetail(paymentId) {
  _prPanelOpen('Super Payment Batch');
  try {
    const { payment: pmt, lines } = await apiFetch(`/api/payroll/super-payments/${paymentId}`);
    _renderSuperDetail(pmt, lines);
  } catch (e) {
    _prPanelError(e.message);
  }
}

function _renderSuperDetail(pmt, lines) {
  _superDetailPmt   = pmt;
  _superDetailLines = lines;
  const status   = pmt.status || 'Draft';
  const badgeCls = status === 'Paid' ? 'badge-paid' : 'badge-draft';
  const overdue  = status !== 'Paid' && pmt.due_date && pmt.due_date < isoToday();

  const linesHtml = lines.length ? `
    <table class="inv-list-table pr-lines-sm"><thead><tr>
      <th>Employee</th>
      <th>Fund</th>
      <th>Fund ABN</th>
      <th>Member #</th>
      <th>Period</th>
      <th class="th-r">SGC</th>
      <th class="th-r">Sal. Sacrifice</th>
      <th class="th-r">Voluntary</th>
      <th class="th-r">Total</th>
    </tr></thead><tbody>
      ${lines.map((l, i) => `
        <tr class="${i % 2 ? 'alt' : ''}">
          <td>${esc(l.last_name + ', ' + l.first_name)}<span class="snb-emp-num">${esc(l.employee_number || '')}</span></td>
          <td class="td-sm">${esc(l.fund_name || '—')}</td>
          <td class="inv-mono">${esc(l.fund_abn || '—')}</td>
          <td class="inv-mono">${esc(l.member_number || '—')}</td>
          <td class="inv-mono">${esc(l.period_start || '—')} – ${esc(l.period_end || '—')}</td>
          <td class="inv-amt col-amber">${fmt(l.sgc_amount || 0)}</td>
          <td class="inv-amt col-amber">${fmt(l.salary_sacrifice || 0)}</td>
          <td class="inv-amt">${fmt(l.voluntary_amount || 0)}</td>
          <td class="inv-amt pr-slip-net">${fmt(l.total_amount || 0)}</td>
        </tr>`).join('')}
    </tbody></table>` : '<p class="pr-no-lines-note">No lines on this batch.</p>';

  const jRef = pmt.journal_id ? `Journal #${pmt.journal_id}` : 'No journal posted';

  document.getElementById('det-body').innerHTML = `
    <div class="det-section">
      <div class="det-section-title">Batch Details</div>
      <div class="det-fields-grid">
        ${field('Batch #',       pmt.payment_number, true)}
        ${field('Quarter',       pmt.quarter || '—')}
        ${field('Payment Date',  pmt.payment_date || '—')}
        ${field('Due Date',      (pmt.due_date || '—') + (overdue ? ' ⚠ OVERDUE' : ''))}
        ${field('Method',        pmt.payment_method || 'SuperStream')}
        ${field('Reference',     pmt.reference || '—')}
        ${fieldRaw('Status',     `<span class="badge ${badgeCls}">${status}</span>`)}
        ${field('GL Journal',    jRef)}
      </div>
    </div>
    <div class="det-section">
      <div class="det-section-title">Totals</div>
      <div class="det-tot-row"><span>SGC</span><span class="pr-tot-amber">${fmt(pmt.total_sgc || 0)}</span></div>
      <div class="det-tot-row"><span>Salary Sacrifice</span><span class="pr-tot-amber">${fmt(pmt.total_salary_sacrifice || 0)}</span></div>
      <div class="det-tot-row"><span>Voluntary</span><span>${fmt(pmt.total_voluntary || 0)}</span></div>
      <div class="det-tot-row grand"><span>Total</span><span class="pr-tot-amber">${fmt(pmt.total_amount || 0)}</span></div>
    </div>
    <div class="det-section">
      <div class="det-section-title">Payment Lines — ${lines.length} employee${lines.length !== 1 ? 's' : ''}</div>
      <div class="pr-det-scroll">${linesHtml}</div>
    </div>
    ${pmt.notes ? `<div class="det-section"><div class="det-section-title">Notes</div><p class="pr-det-note-p">${esc(pmt.notes)}</p></div>` : ''}`;

  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-outline" onclick="detClose()">Close</button>
    <div class="pr-det-foot-spacer"></div>
    ${status === 'Draft' ? `
      <button class="btn btn-outline btn-amber-outline"
              onclick="_superMarkPaid(${pmt.id})">✓ Mark as Paid</button>` : ''}
    <button class="btn btn-outline"
            onclick="window.open('/api/payroll/super-payments/${pmt.id}/remittance-pdf','_blank')"
            title="Download remittance advice PDF">⬇ Remittance PDF</button>
    <button class="btn btn-outline" onclick="_superExportCsv()"
            title="Export batch lines as CSV">⬇ CSV</button>`;
}


function _superExportCsv() {
  const pmt   = _superDetailPmt;
  const lines = _superDetailLines;
  if (!pmt || !lines.length) return;
  const headers = ['Employee', 'Employee #', 'Fund', 'Fund ABN', 'USI', 'Member #',
                   'Period Start', 'Period End', 'SGC', 'Salary Sacrifice', 'Voluntary', 'Total'];
  const rows = lines.map(l => [
    `${l.last_name || ''}, ${l.first_name || ''}`,
    l.employee_number || '',
    l.fund_name       || '',
    l.fund_abn        || '',
    l.fund_usi        || '',
    l.member_number   || '',
    l.period_start    || '',
    l.period_end      || '',
    l.sgc_amount      || 0,
    l.salary_sacrifice || 0,
    l.voluntary_amount || 0,
    l.total_amount    || 0,
  ]);
  const csv  = [headers, ...rows]
    .map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = `super_batch_${pmt.payment_number}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// ═══════════════════════════════════════════════════════════════════════════
// ── LEAVE MANAGEMENT  (Stages 5L + P1) ──────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════
//
// Five tabs matching the desktop LeavePanel:
//   Requests | Balances | Leave Types | Medical Certs | Public Holidays
//
// Navigation: _prLoadLeave() renders the tab bar + active tab content.
// _lvTab tracks the active tab; tab switches call _lvShowTab(key).
// ─────────────────────────────────────────────────────────────────────────────

let _lvTab        = 'requests';   // active tab key

// ── Requests state ──────────────────────────────────────────────────────────
let _lvRequests   = [];
let _lvSearch     = '';
let _lvStatus     = 'All';
let _lvEmpId      = null;
let _lvEmpName    = '';
let _lvLeaveTypes = [];
let _lvFormData   = {};
let _lvEmployees  = [];

const LV_STATUSES = ['All', 'Pending', 'Approved', 'Declined', 'Cancelled'];

// ── Balances state ──────────────────────────────────────────────────────────
let _lvBalEmpId   = undefined;
let _lvBalEmpName = '';
let _lvBalances   = [];
let _lvAllEmps    = [];

// ── Leave Types state ────────────────────────────────────────────────────────
let _lvTypes      = [];

// ── Medical Certs state ──────────────────────────────────────────────────────
let _lvCerts      = [];
let _lvCertEmpId  = null;
let _lvCertPractitioner = null;

// ── Public Holidays state ────────────────────────────────────────────────────
let _lvHols       = [];
let _lvHolState   = 'All';
let _lvHolYear    = String(new Date().getFullYear());

const LV_STATES = ['NAT','NSW','VIC','QLD','SA','WA','TAS','NT','ACT'];

// ─────────────────────────────────────────────────────────────────────────────
// Entry point
// ─────────────────────────────────────────────────────────────────────────────

async function _prLoadLeave() {
  _prView = 'leave';
  const mc = document.getElementById('module-content');
  mc.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    [_lvRequests, _lvLeaveTypes] = await Promise.all([
      apiFetch('/api/leave/requests'),
      apiFetch('/api/leave/types'),
    ]);
    _lvRenderShell();
    await _lvShowTab(_lvTab, true);
  } catch (e) {
    mc.innerHTML = `<div class="state-error">Failed to load leave: ${esc(e.message)}</div>`;
  }
}

// Render the page shell: header + tab bar + content area
function _lvRenderShell() {
  const mc = document.getElementById('module-content');
  mc.innerHTML = `
    <div class="lv-header">
      <span class="lv-title">Leave Management</span>
      <button class="btn btn-outline btn-sm" onclick="_prLoadEmployees()">← Employees</button>
    </div>
    <div class="lv-tab-bar" id="lv-tab-bar">
      ${[
        ['requests', '📋 Requests'],
        ['balances', '📊 Balances'],
        ['types',    '⚙ Leave Types'],
        ['certs',    '🏥 Medical Certs'],
        ['holidays', '🗓 Public Holidays'],
      ].map(([key, label]) =>
        `<button class="lv-tab${_lvTab === key ? ' active' : ''}"
                 onclick="_lvShowTab('${key}')">${label}</button>`
      ).join('')}
    </div>
    <div id="lv-content"></div>`;
}

async function _lvShowTab(key, skipShellRebuild) {
  _lvTab = key;
  // Update tab active state without re-rendering shell
  document.querySelectorAll('.lv-tab').forEach(b =>
    b.classList.toggle('active', b.textContent.trim() === _lvTabLabel(key) ||
      b.getAttribute('onclick') === `_lvShowTab('${key}')`));

  const lc = document.getElementById('lv-content');
  if (!lc) return;
  lc.innerHTML = '<div class="state-loading">Loading…</div>';

  try {
    if (key === 'requests') {
      if (!_lvEmployees.length)
        _lvEmployees = await apiFetch('/api/payroll/employees?all=0').catch(() => []);
      _renderLeavePage();
    } else if (key === 'balances') {
      if (!_lvAllEmps.length)
        _lvAllEmps = await apiFetch('/api/payroll/employees?all=0').catch(() => []);
      if (_lvBalEmpId === undefined && _lvAllEmps.length) {
        _lvBalEmpId   = _lvAllEmps[0].id;
        _lvBalEmpName = _lvAllEmps[0].first_name + ' ' + _lvAllEmps[0].last_name;
      }
      if (_lvBalEmpId)
        _lvBalances = await apiFetch(`/api/leave/balances?employee_id=${_lvBalEmpId}`);
      _renderBalancesPage();
    } else if (key === 'types') {
      _lvTypes = await apiFetch('/api/leave/types?active_only=0');
      _renderTypesPage();
    } else if (key === 'certs') {
      _lvCerts = await apiFetch('/api/leave/certs' + (_lvCertEmpId ? `?employee_id=${_lvCertEmpId}` : ''));
      if (!_lvAllEmps.length)
        _lvAllEmps = await apiFetch('/api/payroll/employees?all=0').catch(() => []);
      _renderCertsPage();
    } else if (key === 'holidays') {
      await _lvHolLoad();
    }
  } catch (e) {
    if (lc) lc.innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`;
  }
}

function _lvTabLabel(key) {
  return { requests:'📋 Requests', balances:'📊 Balances',
           types:'⚙ Leave Types', certs:'🏥 Medical Certs',
           holidays:'🗓 Public Holidays' }[key] || key;
}


// ─────────────────────────────────────────────────────────────────────────────
// TAB 1: REQUESTS
// ─────────────────────────────────────────────────────────────────────────────

function _lvFiltered() {
  const q = _lvSearch.toLowerCase();
  return _lvRequests.filter(r => {
    if (_lvStatus !== 'All' && r.status !== _lvStatus) return false;
    if (_lvEmpId && r.employee_id !== _lvEmpId) return false;
    if (q && ![r.employee_name, r.type_name, r.reason, r.employee_number]
              .some(v => (v || '').toLowerCase().includes(q))) return false;
    return true;
  }).sort((a, b) => a.start_date < b.start_date ? 1 : -1);
}

function _renderLeavePage() {
  const lc = document.getElementById('lv-content');
  const filtered = _lvFiltered();

  const statusCounts = {};
  LV_STATUSES.forEach(s => { statusCounts[s] = 0; });
  statusCounts['All'] = _lvRequests.length;
  _lvRequests.forEach(r => { if (r.status in statusCounts) statusCounts[r.status]++; });

  const empFilterOpts = `<option value="">All employees</option>` +
    _lvEmployees.map(e =>
      `<option value="${e.id}" ${e.id == _lvEmpId ? 'selected' : ''}>${esc(e.last_name + ', ' + e.first_name)}</option>`
    ).join('');

  lc.innerHTML = `
    <div class="inv-toolbar lv-req-toolbar">
      <select class="form-input lv-req-emp-sel" id="lv-emp-filter"
              onchange="_lvSetEmpFilter(this.value)">${empFilterOpts}</select>
      <input class="inv-search" id="lv-q" placeholder="Search leave type, reason…"
             value="${esc(_lvSearch)}">
      <div class="inv-filter-group">
        ${LV_STATUSES.map(s => `
          <button class="filter-btn${_lvStatus === s ? ' active' : ''}" onclick="_lvSetStatus('${s}')">
            ${s}${statusCounts[s] ? ` <span class="filter-count">(${statusCounts[s]})</span>` : ''}
          </button>`).join('')}
      </div>
      <div class="lv-req-actions">
        <button class="btn btn-primary" onclick="_lvFormOpen(null)">+ New Request</button>
      </div>
    </div>

    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        <th>Employee</th>
        <th>Leave Type</th>
        <th>From</th>
        <th>To</th>
        <th class="th-r">Hours</th>
        <th>Status</th>
        <th>Reason</th>
        <th class="th-r">Actions</th>
      </tr></thead><tbody>
        ${filtered.length ? filtered.map(_lvRow).join('') :
          `<tr><td colspan="8" class="tbl-empty-row">No leave requests found.</td></tr>`}
      </tbody></table>
    </div>
    <div class="mt-8"><span class="count-pill">${filtered.length} request${filtered.length !== 1 ? 's' : ''}</span></div>
    </div>`;

  const q = document.getElementById('lv-q');
  if (q) q.addEventListener('input', e => {
    _lvSearch = e.target.value;
    _renderLeavePage();
    const qNew = document.getElementById('lv-q');
    if (qNew) { qNew.focus(); qNew.setSelectionRange(_lvSearch.length, _lvSearch.length); }
  });
}

const LV_STATUS_DOT = {
  'Pending':   'var(--amber)',
  'Approved':  'var(--green)',
  'Declined':  'var(--red)',
  'Cancelled': 'var(--ink3)',
  'Taken':     '#4299e1',
};

function _lvRow(r) {
  const dotColour   = r.colour || '#888';
  const statusDot   = LV_STATUS_DOT[r.status] || 'var(--ink3)';
  const statusCls = {
    'Pending':   'badge-pending',
    'Approved':  'badge-paid',
    'Declined':  'badge-overdue',
    'Cancelled': 'badge-draft',
    'Taken':     'badge-sent',
  }[r.status] || 'badge-draft';

  const canApprove = r.status === 'Pending';
  const canDecline = r.status === 'Pending';
  const canCancel  = r.status === 'Pending' || r.status === 'Approved';

  return `
    <tr class="inv-row" onclick="_lvDetail(${r.id})">
      <td>
        <span class="inv-contact">${esc(r.employee_name)}</span>
        <span class="inv-mono lv-emp-num">${esc(r.employee_number || '')}</span>
      </td>
      <td>
        <span class="lv-type-cell">
          <span class="lv-type-dot" style="background:${dotColour}"></span>
          ${esc(r.type_name)}${r.paid ? '' : ' <span class="lv-unpaid-tag">(unpaid)</span>'}
        </span>
      </td>
      <td class="inv-mono">${esc(r.start_date || '—')}</td>
      <td class="inv-mono">${esc(r.end_date   || '—')}</td>
      <td class="inv-amt">${r.hours_requested != null ? Number(r.hours_requested).toFixed(2) : '—'}</td>
      <td><span class="lv-status-cell">
        <span class="lv-type-dot" style="background:${statusDot}"></span>
        <span class="badge ${statusCls}">${esc(r.status)}</span>
      </span></td>
      <td class="td-sm lv-reason-cell">${esc(r.reason || '—')}</td>
      <td class="lv-actions-cell" onclick="event.stopPropagation()">
        ${canApprove ? `<button class="btn btn-outline btn-sm lv-btn-approve" onclick="_lvApprove(${r.id})">✓ Approve</button> ` : ''}
        ${canDecline ? `<button class="btn btn-outline btn-sm lv-btn-decline" onclick="_lvDeclinePrompt(${r.id})">✗ Decline</button> ` : ''}
        ${canCancel  ? `<button class="btn btn-outline btn-sm" onclick="_lvCancelConfirm(${r.id})">Cancel</button>` : ''}
      </td>
    </tr>`;
}

function _lvSetStatus(s) { _lvStatus = s; _renderLeavePage(); }
function _lvSetEmpFilter(val) {
  _lvEmpId = val ? parseInt(val) : null;
  const emp = _lvEmployees.find(e => e.id === _lvEmpId);
  _lvEmpName = emp ? emp.first_name + ' ' + emp.last_name : '';
  _renderLeavePage();
}
function _lvClearEmpFilter() { _lvEmpId = null; _lvEmpName = ''; _renderLeavePage(); }

async function _lvApprove(id) {
  try {
    await _pPost(`/api/leave/requests/${id}/approve`, { approved_by: 'Web UI' });
    const idx = _lvRequests.findIndex(r => r.id === id);
    if (idx !== -1) _lvRequests[idx].status = 'Approved';
    _renderLeavePage();
    toast('Request approved');
  } catch (e) { toast('Failed: ' + e.message, 'error'); }
}

async function _lvDeclinePrompt(id) {
  const reason = prompt('Decline reason (optional):');
  if (reason === null) return; // cancelled
  try {
    await _pPost(`/api/leave/requests/${id}/decline`, { declined_by: 'Web UI', reason });
    const idx = _lvRequests.findIndex(r => r.id === id);
    if (idx !== -1) _lvRequests[idx].status = 'Declined';
    _renderLeavePage();
    toast('Request declined');
  } catch (e) { toast('Failed: ' + e.message, 'error'); }
}

async function _lvCancelConfirm(id) {
  if (!confirm('Cancel this leave request?')) return;
  try {
    await _pPost(`/api/leave/requests/${id}/cancel`, {});
    const idx = _lvRequests.findIndex(r => r.id === id);
    if (idx !== -1) _lvRequests[idx].status = 'Cancelled';
    _renderLeavePage();
    toast('Request cancelled');
  } catch (e) { toast('Failed: ' + e.message, 'error'); }
}

async function _lvDetail(id) {
  _prPanelOpen('Leave Request');
  try {
    const r = await apiFetch(`/api/leave/requests/${id}`);
    _renderLvDetail(r);
  } catch (e) { _prPanelError(e.message); }
}

function _renderLvDetail(r) {
  const statusDot = LV_STATUS_DOT[r.status] || 'var(--ink3)';
  const statusCls = {
    'Pending':   'badge-pending',
    'Approved':  'badge-paid',
    'Declined':  'badge-overdue',
    'Cancelled': 'badge-draft',
    'Taken':     'badge-sent',
  }[r.status] || 'badge-draft';

  document.getElementById('det-body').innerHTML = `
    <div class="det-section">
      <div class="det-section-title">Leave Details</div>
      <div class="det-fields-grid">
        ${field('Employee',   r.employee_name)}
        ${fieldRaw('Leave Type', `<span class="lv-type-cell">
          <span class="lv-type-dot" style="background:${r.colour || '#888'}"></span>
          ${esc(r.type_name)}</span>`)}
        ${fieldRaw('Status', `<span class="lv-status-cell"><span class="lv-type-dot" style="background:${statusDot}"></span><span class="badge ${statusCls}">${esc(r.status)}</span></span>`)}
        ${field('From',   r.start_date || '—')}
        ${field('To',     r.end_date   || '—')}
        ${field('Hours',  r.hours_requested != null ? Number(r.hours_requested).toFixed(2) + ' hrs' : '—')}
        ${r.return_date ? field('Return Date', r.return_date) : ''}
        ${r.reason      ? field('Reason', r.reason) : ''}
      </div>
    </div>
    ${r.status === 'Approved' || r.status === 'Declined' ? `
    <div class="det-section">
      <div class="det-section-title">${r.status === 'Approved' ? 'Approval' : 'Decline'} Info</div>
      <div class="det-fields-grid">
        ${field(r.status === 'Approved' ? 'Approved By' : 'Declined By', r.approved_by || '—')}
        ${field('Date', r.approved_at ? r.approved_at.slice(0,10) : '—')}
        ${r.decline_reason ? field('Reason', r.decline_reason) : ''}
      </div>
    </div>` : ''}
    ${r.notes ? `<div class="det-section"><div class="det-section-title">Notes</div>
      <p class="det-note">${esc(r.notes)}</p></div>` : ''}`;

  const canApprove = r.status === 'Pending';
  const canDecline = r.status === 'Pending';
  const canCancel  = r.status === 'Pending' || r.status === 'Approved';

  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-outline" onclick="_lvFormOpen(${r.id})">Edit</button>
    <button class="btn btn-outline" onclick="_lvCertFormOpen(null,${r.employee_id},${r.id})">+ Med. Cert</button>
    ${canApprove ? `<button class="btn btn-success" onclick="_lvApprove(${r.id});detClose()">✓ Approve</button>` : ''}
    ${canDecline ? `<button class="btn btn-danger"  onclick="_lvDeclinePrompt(${r.id});detClose()">✗ Decline</button>` : ''}
    ${canCancel  ? `<button class="btn btn-outline"  onclick="_lvCancelConfirm(${r.id});detClose()">Cancel Request</button>` : ''}
    <button class="btn btn-outline" onclick="detClose()">Close</button>`;
}

async function _lvFormOpen(id) {
  _prPanelOpen(id ? 'Edit Leave Request' : 'New Leave Request');
  try {
    if (!_lvEmployees.length)
      _lvEmployees = await apiFetch('/api/payroll/employees?all=0').catch(() => []);
    _lvFormData = id
      ? await apiFetch(`/api/leave/requests/${id}`)
      : { employee_id: _lvEmpId || '', status: 'Pending' };
    _renderLvForm();
  } catch (e) { _prPanelError(e.message); }
}

// Cache of employee hours_per_week keyed by employee id, populated on demand.
const _lvEmpHpwCache = {};

// Auto-calculate hours from date range and employee hours_per_week.
// Fetches employee detail on first use (hours_per_week not in list endpoint).
// Only fills hours if the field is currently empty (does not overwrite manual entry).
async function _lvCalcHours() {
  const start   = document.getElementById('lv-start')?.value;
  const end     = document.getElementById('lv-end')?.value;
  const hoursEl = document.getElementById('lv-hours');
  const empId   = document.getElementById('lv-emp')?.value;
  if (!start || !end || !hoursEl || !empId) return;
  if (hoursEl.value !== '') return;  // don't overwrite a manual entry

  // Get hours_per_week — cache to avoid repeated fetches.
  let hpw = _lvEmpHpwCache[empId];
  if (hpw === undefined) {
    try {
      const emp = await apiFetch(`/api/payroll/employees/${empId}`);
      hpw = emp?.hours_per_week ?? null;
    } catch(_) { hpw = null; }
    _lvEmpHpwCache[empId] = hpw;
  }
  if (!hpw || hpw <= 0) return;

  // Count weekdays between start and end inclusive.
  let weekdays = 0;
  const cur = new Date(start + 'T00:00:00');
  const fin = new Date(end   + 'T00:00:00');
  if (fin < cur) return;
  while (cur <= fin) {
    const d = cur.getDay();
    if (d !== 0 && d !== 6) weekdays++;
    cur.setDate(cur.getDate() + 1);
  }

  const total = Math.round(weekdays * (hpw / 5) * 4) / 4;  // round to nearest 0.25
  if (total > 0) hoursEl.value = total;
}

function _lvForceCalcHours() {
  const h = document.getElementById('lv-hours');
  if (h) h.value = '';
  _lvCalcHours();
}

function _renderLvForm() {
  const r = _lvFormData;
  const empOpts  = _lvEmployees.map(e =>
    `<option value="${e.id}" ${r.employee_id == e.id ? 'selected' : ''}>${esc(e.last_name + ', ' + e.first_name)} (${esc(e.employee_number || '')})</option>`).join('');
  const typeOpts = _lvLeaveTypes.map(lt =>
    `<option value="${lt.id}" ${r.leave_type_id == lt.id ? 'selected' : ''}>${esc(lt.name)}</option>`).join('');
  const statOpts = ['Pending','Approved','Declined','Cancelled','Taken'].map(s =>
    `<option value="${s}" ${r.status === s ? 'selected' : ''}>${s}</option>`).join('');

  document.getElementById('det-body').innerHTML = `
    <div class="det-section">
      <div class="form-grid">
        <div class="form-field form-field-full">
          <label class="form-lbl">Employee *</label>
          <select class="form-input" id="lv-emp" onchange="_lvCalcHours()">
            <option value="">— select —</option>${empOpts}
          </select>
        </div>
        <div class="form-field form-field-full">
          <label class="form-lbl">Leave Type *</label>
          <select class="form-input" id="lv-type"><option value="">— select —</option>${typeOpts}</select>
        </div>
        <div class="form-field">
          <label class="form-lbl">From Date *</label>
          <input class="form-input" type="date" id="lv-start" value="${esc(r.start_date || '')}"
                 onchange="_lvCalcHours()">
        </div>
        <div class="form-field">
          <label class="form-lbl">To Date *</label>
          <input class="form-input" type="date" id="lv-end" value="${esc(r.end_date || '')}"
                 onchange="_lvCalcHours()">
        </div>
        <div class="form-field">
          <label class="form-lbl">Hours Requested
            <button type="button" class="btn btn-outline btn-xs" style="margin-left:6px"
                    onclick="_lvForceCalcHours()" title="Recalculate from dates">Calc</button>
          </label>
          <input class="form-input" type="number" step="0.25" min="0" id="lv-hours"
                 value="${r.hours_requested != null ? r.hours_requested : ''}"
                 placeholder="Auto-calculated from dates"
                 title="Leave blank to auto-calculate from dates, or enter manually">
        </div>
        <div class="form-field">
          <label class="form-lbl">Return Date</label>
          <input class="form-input" type="date" id="lv-return" value="${esc(r.return_date || '')}">
        </div>
        <div class="form-field form-field-full">
          <label class="form-lbl">Status</label>
          <select class="form-input" id="lv-status">${statOpts}</select>
        </div>
        <div class="form-field form-field-full">
          <label class="form-lbl">Reason</label>
          <input class="form-input" type="text" id="lv-reason" value="${esc(r.reason || '')}" placeholder="Brief description">
        </div>
        <div class="form-field form-field-full">
          <label class="form-lbl">Notes</label>
          <textarea class="form-input edt-ta-resize" id="lv-notes" rows="3" placeholder="Internal notes…">${esc(r.notes || '')}</textarea>
        </div>
      </div>
    </div>`;

  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-primary" onclick="_lvFormSave(${r.id || 'null'})">Save</button>
    ${r.id ? `<button class="btn btn-outline" onclick="_lvCertFormOpen(null,${r.employee_id},${r.id})">+ Med. Cert</button>` : ''}
    <button class="btn btn-outline" onclick="detClose()">Cancel</button>`;

  // Trigger auto-calc on open in case employee + dates are already set (e.g. new
  // request with pre-filtered employee, or re-opening a draft with no hours yet).
  _lvCalcHours();
}

async function _lvFormSave(id) {
  const emp_id = document.getElementById('lv-emp').value;
  const lt_id  = document.getElementById('lv-type').value;
  const start  = document.getElementById('lv-start').value;
  const end    = document.getElementById('lv-end').value;
  if (!emp_id || !lt_id || !start || !end) {
    toast('Employee, leave type, from date and to date are required.', 'error'); return;
  }
  const basePayload = {
    employee_id:     parseInt(emp_id),
    leave_type_id:   parseInt(lt_id),
    start_date:      start,
    end_date:        end,
    return_date:     document.getElementById('lv-return').value || null,
    hours_requested: parseFloat(document.getElementById('lv-hours').value) || null,
    status:          document.getElementById('lv-status').value,
    reason:          document.getElementById('lv-reason').value.trim() || null,
    notes:           document.getElementById('lv-notes').value.trim() || null,
  };
  try {
    if (id) {
      await _pMut('PUT', `/api/leave/requests/${id}`, { id, ...basePayload });
    } else {
      const res = await _pPost('/api/leave/requests', basePayload);
      id = res?.id;
    }
    _lvRequests = await apiFetch('/api/leave/requests');
    detClose();
    _renderLeavePage();
    toast('Leave request saved');
  } catch (e) { toast('Save failed: ' + e.message, 'error'); }
}


// ─────────────────────────────────────────────────────────────────────────────
// TAB 2: BALANCES
// ─────────────────────────────────────────────────────────────────────────────

function _renderBalancesPage() {
  const lc = document.getElementById('lv-content');
  const empOptions = `<option value="" ${!_lvBalEmpId ? 'selected' : ''}>All employees</option>` +
    _lvAllEmps.map(e =>
      `<option value="${e.id}" ${e.id === _lvBalEmpId ? 'selected' : ''}>${esc(e.last_name + ', ' + e.first_name)} (${esc(e.employee_number || '')})</option>`
    ).join('');

  const cardTypes = ['ANN', 'LSL', 'SIC'];
  const cardBalances = _lvBalances.filter(b => cardTypes.includes(b.code));

  lc.innerHTML = `
    <div class="inv-toolbar">
      <label class="lv-bal-emp-label">Employee:</label>
      <select class="form-input lv-bal-emp-sel" id="bal-emp-sel" onchange="_lvBalEmpChanged(this.value)">
        ${empOptions}
      </select>
      ${_lvBalEmpId ? `
        <button class="btn btn-outline btn-sm" onclick="_lvHistoryOpen(${_lvBalEmpId})">📋 History</button>
        <button class="btn btn-primary btn-sm" onclick="_lvAdjustOpen(${_lvBalEmpId})">⚙ Adjust Balance</button>
      ` : ''}
      <div class="pr-toolbar-sep"></div>
      <button class="btn btn-outline btn-sm" onclick="_lvOutstandingPdf()">⬇ PDF</button>
      <button class="btn btn-outline btn-sm" onclick="_lvOutstandingCsv()">⬇ CSV</button>
    </div>

    ${_lvBalEmpId ? `
    <div class="lv-bal-cards">
      ${cardBalances.map(b => {
        const net   = (parseFloat(b.accrued_hours) + parseFloat(b.adjustment_hours || 0) - parseFloat(b.taken_hours)).toFixed(2);
        const weeks = (parseFloat(net) / 38).toFixed(2);
        return `
          <div class="lv-bal-card" style="border-left-color:${b.colour || '#888'}">
            <div class="lv-bal-card-type">${esc(b.type_name)}</div>
            <div class="lv-bal-card-hrs">${net} <span class="lv-bal-card-unit">hrs</span></div>
            <div class="lv-bal-card-weeks">${weeks} weeks</div>
            <div class="lv-bal-card-detail">
              <span>Accrued: ${parseFloat(b.accrued_hours).toFixed(2)}</span>
              <span>Taken: ${parseFloat(b.taken_hours).toFixed(2)}</span>
            </div>
          </div>`;
      }).join('')}
    </div>

    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        <th>Leave Type</th>
        <th class="th-r">Accrued (hrs)</th>
        <th class="th-r">Adjustments</th>
        <th class="th-r">Taken (hrs)</th>
        <th class="th-r">Balance (hrs)</th>
        <th class="th-r">Balance (weeks)</th>
        <th>As Of</th>
      </tr></thead><tbody>
        ${_lvBalances.map(b => {
          const net   = (parseFloat(b.accrued_hours) + parseFloat(b.adjustment_hours || 0) - parseFloat(b.taken_hours)).toFixed(2);
          const weeks = (parseFloat(net) / 38).toFixed(2);
          const adjVal = parseFloat(b.adjustment_hours || 0);
          return `
            <tr class="inv-row">
              <td>
                <span class="lv-type-cell">
                  <span class="lv-type-dot" style="background:${b.colour || '#888'}"></span>
                  ${esc(b.type_name)}
                </span>
              </td>
              <td class="inv-amt">${parseFloat(b.accrued_hours).toFixed(2)}</td>
              <td class="inv-amt ${adjVal >= 0 ? 'col-green' : 'col-red'}">${adjVal >= 0 ? '+' : ''}${adjVal.toFixed(2)}</td>
              <td class="inv-amt">${parseFloat(b.taken_hours).toFixed(2)}</td>
              <td class="inv-amt lv-bal-net">${net}</td>
              <td class="inv-amt col-ink3">${weeks}</td>
              <td class="inv-mono">${esc(b.as_of_date || '—')}</td>
            </tr>`;
        }).join('')}
      </tbody></table>
    </div></div>` : '<div class="det-empty">No employee selected.</div>'}`;
}

async function _lvBalEmpChanged(empId) {
  _lvBalEmpId = empId ? parseInt(empId) : null;
  const emp = _lvAllEmps.find(e => e.id === _lvBalEmpId);
  _lvBalEmpName = emp ? emp.first_name + ' ' + emp.last_name : '';
  try {
    _lvBalances = _lvBalEmpId ? await apiFetch(`/api/leave/balances?employee_id=${_lvBalEmpId}`) : [];
    _renderBalancesPage();
  } catch (e) { toast('Failed to load balances: ' + e.message, 'error'); }
}

// Legacy entry point: called from employee detail to jump to balances for a specific employee
async function _lvShowBalances(empId, empName) {
  if (empId) { _lvBalEmpId = empId; _lvBalEmpName = empName; }
  _lvTab = 'balances';
  await _prLoadLeave();
}

function _lvOutstandingPdf() {
  window.open('/api/leave/outstanding-leave/pdf', '_blank');
}

function _lvOutstandingCsv() {
  window.location.href = '/api/leave/outstanding-leave/csv';
}


// ── Adjust Leave Balance ──────────────────────────────────────────────────────

async function _lvAdjustOpen(empId) {
  // Fetch leave types for the dropdown
  let types = _lvLeaveTypes;
  if (!types || !types.length) {
    try { types = await apiFetch('/api/leave/types'); } catch (e) { types = []; }
  }

  const typeOpts = types.map(t =>
    `<option value="${t.id}">${esc(t.name)}</option>`).join('');

  const adjTypeOpts = ['manual', 'opening', 'adjustment'].map(v =>
    `<option value="${v}">${v.charAt(0).toUpperCase() + v.slice(1)}</option>`).join('');

  const empName = _lvAllEmps.find(e => e.id === empId);
  const nameStr = empName ? `${empName.first_name} ${empName.last_name}` : `Employee #${empId}`;

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.id = 'lv-adj-modal';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box modal-sm">
      <div class="modal-hdr">
        <span>Adjust Leave Balance — ${esc(nameStr)}</span>
      </div>
      <div class="modal-body">
        <p class="pr-modal-hint">
          Use this to set opening balances, correct errors, or record purchased leave.
          All adjustments are logged in the audit trail.
        </p>
        <div class="form-grid">
          <div class="form-field form-field-full">
            <label class="form-lbl">Leave Type *</label>
            <select class="form-input" id="lv-adj-type">
              <option value="">— select —</option>${typeOpts}
            </select>
          </div>
          <div class="form-field">
            <label class="form-lbl">Hours (+ or −) *</label>
            <input class="form-input" type="number" step="0.25" id="lv-adj-hours"
                   placeholder="e.g. 38 or -7.6">
          </div>
          <div class="form-field">
            <label class="form-lbl">Adjustment Type</label>
            <select class="form-input" id="lv-adj-accrual-type">${adjTypeOpts}</select>
          </div>
          <div class="form-field form-field-full">
            <label class="form-lbl">Notes</label>
            <input class="form-input" type="text" id="lv-adj-notes"
                   placeholder="e.g. Opening balance as at 1 July 2025">
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm"
                onclick="document.getElementById('lv-adj-modal').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" id="lv-adj-save-btn"
                onclick="_lvAdjustSave(${empId})">Post Adjustment</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
}

async function _lvAdjustSave(empId) {
  const typeId = document.getElementById('lv-adj-type').value;
  const hours  = document.getElementById('lv-adj-hours').value;
  const adjType = document.getElementById('lv-adj-accrual-type').value;
  const notes  = document.getElementById('lv-adj-notes').value.trim();

  if (!typeId) { toast('Select a leave type.', 'error'); return; }
  if (hours === '' || isNaN(parseFloat(hours))) {
    toast('Enter a valid number of hours.', 'error'); return;
  }

  const btn = document.getElementById('lv-adj-save-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }

  try {
    await _pPost(`/api/leave/balances/${empId}/adjust`, {
      leave_type_id: parseInt(typeId),
      hours:         parseFloat(hours),
      accrual_type:  adjType,
      notes,
    });
    document.getElementById('lv-adj-modal').remove();
    // Refresh balances display
    _lvBalances = await apiFetch(`/api/leave/balances?employee_id=${empId}`);
    _renderBalancesPage();
    toast(`Adjustment of ${parseFloat(hours) >= 0 ? '+' : ''}${parseFloat(hours).toFixed(2)} hrs posted.`);
  } catch (e) {
    if (btn) { btn.disabled = false; btn.textContent = 'Post Adjustment'; }
    toast('Save failed: ' + e.message, 'error');
  }
}


// ── Leave Accrual History ─────────────────────────────────────────────────────

async function _lvHistoryOpen(empId) {
  const empObj  = _lvAllEmps.find(e => e.id === empId);
  const nameStr = empObj ? `${empObj.first_name} ${empObj.last_name}` : `Employee #${empId}`;

  // Show modal immediately with loading state
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.id = 'lv-hist-modal';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box modal-lg modal-tall">
      <div class="modal-hdr">
        <span>Leave Accrual History — ${esc(nameStr)}</span>
      </div>
      <div class="modal-body" id="lv-hist-body">
        <div class="state-loading">Loading history…</div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm"
                onclick="document.getElementById('lv-hist-modal').remove()">Close</button>
      </div>
    </div>`;
  document.body.appendChild(bd);

  try {
    const rows = await apiFetch(`/api/leave/balances/${empId}/history`);
    const body = document.getElementById('lv-hist-body');
    if (!body) return;

    if (!rows.length) {
      body.innerHTML = '<div class="det-empty">No accrual history found.</div>';
      return;
    }

    body.innerHTML = `
      <table class="inv-list-table tbl-sm">
        <thead><tr>
          <th>Date</th>
          <th>Leave Type</th>
          <th class="th-r">Hours</th>
          <th>Category</th>
          <th>Reference</th>
          <th>Notes</th>
        </tr></thead>
        <tbody>
          ${rows.map((r, i) => {
            const hrs     = parseFloat(r.hours || 0);
            const hrsCol  = hrs >= 0 ? 'col-green' : 'col-red';
            const hrsStr  = (hrs >= 0 ? '+' : '') + hrs.toFixed(4);
            return `<tr class="inv-row${i % 2 ? ' row-alt' : ''}">
              <td class="inv-mono">${esc(r.accrual_date || '—')}</td>
              <td>${esc(r.type_name || '—')}</td>
              <td class="inv-amt ${hrsCol}">${hrsStr}</td>
              <td class="td-sm col-ink3">${esc(r.accrual_type || '—')}</td>
              <td class="td-sm col-ink3">${esc(r.reference   || '—')}</td>
              <td class="td-sm col-ink3">${esc((r.notes || '').substring(0, 50))}</td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
      <div class="mt-8"><span class="count-pill">${rows.length} record${rows.length !== 1 ? 's' : ''}</span></div>`;
  } catch (e) {
    const body = document.getElementById('lv-hist-body');
    if (body) body.innerHTML = `<div class="state-error">Failed to load: ${esc(e.message)}</div>`;
  }
}


// ─────────────────────────────────────────────────────────────────────────────
// TAB 3: LEAVE TYPES
// ─────────────────────────────────────────────────────────────────────────────

function _renderTypesPage() {
  const lc = document.getElementById('lv-content');
  lc.innerHTML = `
    <div class="inv-toolbar">
      <span class="lv-section-note">System types (ANN, LSL, SIC, etc.) cannot be deleted. Custom types can be added freely.</span>
      <button class="btn btn-primary" onclick="_lvTypeFormOpen(null)">+ Custom Type</button>
    </div>
    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        <th>Code</th>
        <th>Name</th>
        <th>Paid</th>
        <th>Accrual Method</th>
        <th class="th-r">Days/yr</th>
        <th>Evidence</th>
        <th>Active</th>
        <th>Notes</th>
        <th></th>
      </tr></thead><tbody>
        ${_lvTypes.length ? _lvTypes.map(_lvTypeRow).join('') :
          `<tr><td colspan="9" class="tbl-empty-row">No leave types found.</td></tr>`}
      </tbody></table>
    </div>
    <div class="mt-8"><span class="count-pill">${_lvTypes.length} type${_lvTypes.length !== 1 ? 's' : ''}</span></div>
    </div>`;
}

function _lvTypeRow(lt) {
  const activeCls = lt.is_active ? 'badge-paid' : 'badge-draft';
  return `
    <tr class="inv-row" onclick="_lvTypeFormOpen(${lt.id})">
      <td><span class="inv-mono lv-type-code col-accent">${esc(lt.code)}</span></td>
      <td><span class="inv-contact">${esc(lt.name)}</span>
          ${lt.is_system ? '<span class="badge badge-draft badge-sm-inline">system</span>' : ''}</td>
      <td>${lt.paid ? '<span class="col-green">Yes</span>' : '<span class="col-ink3">No</span>'}</td>
      <td class="td-sm col-ink3">${esc(lt.accrual_method || '—')}</td>
      <td class="inv-amt">${lt.accrual_days_per_year != null ? Number(lt.accrual_days_per_year).toFixed(1) : '—'}</td>
      <td class="td-sm">${lt.requires_evidence ? 'Yes' : '—'}</td>
      <td><span class="badge ${activeCls} badge-sm-inline">${lt.is_active ? 'Active' : 'Inactive'}</span></td>
      <td class="td-sm col-ink3">${esc((lt.notes || '').substring(0, 40))}</td>
      <td onclick="event.stopPropagation()">
        ${!lt.is_system ? `<button class="btn btn-outline btn-sm lv-btn-decline" onclick="_lvTypeDelete(${lt.id})">Delete</button>` : ''}
      </td>
    </tr>`;
}

async function _lvTypeFormOpen(id) {
  _prPanelOpen(id ? 'Edit Leave Type' : 'New Leave Type');
  try {
    const lt = id ? _lvTypes.find(t => t.id === id) || await apiFetch(`/api/leave/types/${id}`) : {};
    _renderLvTypeForm(lt);
  } catch (e) { _prPanelError(e.message); }
}

function _renderLvTypeForm(lt) {
  const isSystem = lt.is_system;
  const dis = isSystem ? 'disabled' : '';
  const METHODS = ['per_hour','fixed_date','manual','none'];

  document.getElementById('det-body').innerHTML = `
    <div class="det-section">
      ${isSystem ? `<div class="lv-system-notice">System leave type — code and accrual method cannot be changed.</div>` : ''}
      <div class="form-grid">
        <div class="form-field">
          <label class="form-lbl">Code *</label>
          <input class="form-input inp-uppercase" id="lt-code" value="${esc(lt.code || '')}" ${dis} placeholder="e.g. ANN">
        </div>
        <div class="form-field">
          <label class="form-lbl">Name *</label>
          <input class="form-input" id="lt-name" value="${esc(lt.name || '')}" placeholder="e.g. Annual Leave">
        </div>
        <div class="form-field form-field-check form-field-end">
          <input type="checkbox" id="lt-paid" ${lt.paid !== 0 ? 'checked' : ''}>
          <label class="form-lbl" for="lt-paid">Paid</label>
        </div>
        <div class="form-field form-field-check form-field-end">
          <input type="checkbox" id="lt-active" ${lt.is_active !== 0 ? 'checked' : ''}>
          <label class="form-lbl" for="lt-active">Active</label>
        </div>
        <div class="form-field form-field-full">
          <label class="form-lbl">Accrual Method</label>
          <select class="form-input" id="lt-method" ${dis}>
            ${METHODS.map(m => `<option value="${m}" ${lt.accrual_method === m ? 'selected' : ''}>${m}</option>`).join('')}
          </select>
        </div>
        <div class="form-field">
          <label class="form-lbl">Accrual Rate (hrs/hr) <span class="col-ink3 pr-hint-sm">per_hour only</span></label>
          <input class="form-input" type="number" step="0.0001" id="lt-rate" value="${lt.accrual_rate != null ? lt.accrual_rate : 0}" ${dis}>
        </div>
        <div class="form-field">
          <label class="form-lbl">Days per Year</label>
          <input class="form-input" type="number" step="0.5" id="lt-days" value="${lt.accrual_days_per_year != null ? lt.accrual_days_per_year : 0}">
        </div>
        <div class="form-field form-field-check">
          <input type="checkbox" id="lt-evid" ${lt.requires_evidence ? 'checked' : ''}>
          <label class="form-lbl" for="lt-evid">Requires Evidence</label>
        </div>
        <div class="form-field form-field-check">
          <input type="checkbox" id="lt-carry" ${lt.carryover !== 0 ? 'checked' : ''}>
          <label class="form-lbl" for="lt-carry">Carryover</label>
        </div>
        <div class="form-field">
          <label class="form-lbl">Colour (hex)</label>
          <input class="form-input" id="lt-colour" value="${esc(lt.colour || '#95a5a6')}" placeholder="#95a5a6">
        </div>
        <div class="form-field form-field-full">
          <label class="form-lbl">Notes</label>
          <textarea class="form-input edt-ta-resize" id="lt-notes" rows="2">${esc(lt.notes || '')}</textarea>
        </div>
      </div>
    </div>`;

  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-primary" onclick="_lvTypeSave(${lt.id || 'null'})">Save</button>
    <button class="btn btn-outline" onclick="detClose()">Cancel</button>`;
}

async function _lvTypeSave(id) {
  const code = document.getElementById('lt-code').value.trim().toUpperCase();
  const name = document.getElementById('lt-name').value.trim();
  if (!code || !name) { toast('Code and Name are required.', 'error'); return; }
  const rate = parseFloat(document.getElementById('lt-rate').value) || 0;
  const days = parseFloat(document.getElementById('lt-days').value) || 0;
  const payload = {
    id,
    code,
    name,
    paid:                  document.getElementById('lt-paid').checked   ? 1 : 0,
    accrual_method:        document.getElementById('lt-method').value,
    accrual_rate:          rate,
    accrual_days_per_year: days,
    requires_evidence:     document.getElementById('lt-evid').checked   ? 1 : 0,
    carryover:             document.getElementById('lt-carry').checked  ? 1 : 0,
    is_active:             document.getElementById('lt-active').checked ? 1 : 0,
    colour:                document.getElementById('lt-colour').value.trim(),
    notes:                 document.getElementById('lt-notes').value.trim(),
    stp_code:              code === 'ANN' ? 'A' : 'O',
    sort_order:            99,
    max_balance_weeks:     null,
  };
  try {
    if (id) {
      await _pMut('PUT', `/api/leave/types/${id}`, payload);
    } else {
      await _pPost('/api/leave/types', payload);
    }
    _lvTypes = await apiFetch('/api/leave/types?active_only=0');
    // Also refresh shared leave types list used by request form
    _lvLeaveTypes = await apiFetch('/api/leave/types');
    detClose();
    _renderTypesPage();
    toast('Leave type saved');
  } catch (e) { toast('Save failed: ' + e.message, 'error'); }
}

async function _lvTypeDelete(id) {
  if (!confirm('Delete this leave type? This cannot be undone.')) return;
  try {
    await _pMut('DELETE', `/api/leave/types/${id}`, {});
    _lvTypes = _lvTypes.filter(t => t.id !== id);
    _renderTypesPage();
    detClose();
    toast('Leave type deleted');
  } catch (e) { toast('Delete failed: ' + e.message, 'error'); }
}


// ─────────────────────────────────────────────────────────────────────────────
// TAB 4: MEDICAL CERTS
// ─────────────────────────────────────────────────────────────────────────────

function _renderCertsPage() {
  const lc = document.getElementById('lv-content');
  const empOpts = `<option value="">All employees</option>` +
    _lvAllEmps.map(e => `<option value="${e.id}" ${e.id == _lvCertEmpId ? 'selected' : ''}>${esc(e.last_name + ', ' + e.first_name)} (${esc(e.employee_number || '')})</option>`).join('');

  const practitioners = [...new Set(_lvCerts.map(c => c.practitioner).filter(Boolean))].sort();
  const practOpts = `<option value="">All practitioners</option>` +
    practitioners.map(p => `<option value="${esc(p)}" ${p === _lvCertPractitioner ? 'selected' : ''}>${esc(p)}</option>`).join('');

  const filtered = _lvCerts.filter(c =>
    !_lvCertPractitioner || (c.practitioner || '') === _lvCertPractitioner);

  lc.innerHTML = `
    <div class="inv-toolbar">
      <select class="form-input lv-cert-emp-sel" id="cert-emp" onchange="_lvCertEmpChanged(this.value)">${empOpts}</select>
      <select class="form-input lv-cert-emp-sel" id="cert-pract" onchange="_lvCertPractChanged(this.value)">${practOpts}</select>
      <button class="btn btn-primary" onclick="_lvCertFormOpen(null)">+ Add Certificate</button>
    </div>

    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        <th>Employee</th>
        <th>Cert Date</th>
        <th>Covers</th>
        <th>Practitioner</th>
        <th>Practice</th>
        <th>File</th>
        <th></th>
      </tr></thead><tbody>
        ${filtered.length ? filtered.map(_lvCertRow).join('') :
          `<tr><td colspan="7" class="tbl-empty-row">No medical certificates on file.</td></tr>`}
      </tbody></table>
    </div>
    <div class="mt-8"><span class="count-pill">${filtered.length} certificate${filtered.length !== 1 ? 's' : ''}</span></div>
    </div>`;

}

function _lvCertPractChanged(val) {
  _lvCertPractitioner = val || null;
  _renderCertsPage();
}

function _lvCertRow(c) {
  const covers = c.cert_from_date && c.cert_to_date
    ? `${esc(c.cert_from_date)} → ${esc(c.cert_to_date)}` : '—';
  return `
    <tr class="inv-row" onclick="_lvCertFormOpen(${c.id})">
      <td><span class="inv-contact">${esc(c.employee_name || '—')}</span></td>
      <td class="inv-mono">${esc(c.cert_date || '—')}</td>
      <td class="td-sm">${covers}</td>
      <td class="td-sm col-ink3">${esc(c.practitioner || '—')}</td>
      <td class="td-sm col-ink3">${esc(c.practice_name || '—')}</td>
      <td>${c.file_name ? `<span class="col-accent" title="${esc(c.file_name)}">📎</span>` : '—'}</td>
      <td onclick="event.stopPropagation()">
        <button class="btn btn-outline btn-sm lv-btn-decline" onclick="_lvCertDelete(${c.id})">Delete</button>
      </td>
    </tr>`;
}

async function _lvCertEmpChanged(val) {
  _lvCertEmpId = val ? parseInt(val) : null;
  _lvCertPractitioner = null;
  try {
    _lvCerts = await apiFetch('/api/leave/certs' + (_lvCertEmpId ? `?employee_id=${_lvCertEmpId}` : ''));
    _renderCertsPage();
  } catch (e) { toast('Failed: ' + e.message, 'error'); }
}

async function _lvCertFormOpen(id, preEmpId, preReqId) {
  _prPanelOpen(id ? 'Edit Medical Certificate' : 'New Medical Certificate');
  try {
    if (!_lvAllEmps.length)
      _lvAllEmps = await apiFetch('/api/payroll/employees?all=0').catch(() => []);
    const cert = id ? _lvCerts.find(c => c.id === id) || await apiFetch(`/api/leave/certs/${id}`) : {};
    if (preEmpId && !cert.employee_id) cert.employee_id = preEmpId;
    if (preReqId && !cert.leave_request_id) cert.leave_request_id = preReqId;
    // Load leave requests for the selected employee for the link dropdown
    let reqs = [];
    const empId = cert.employee_id || preEmpId;
    if (empId) reqs = await apiFetch(`/api/leave/requests?employee_id=${empId}`).catch(() => []);
    _renderLvCertForm(cert, reqs);
  } catch (e) { _prPanelError(e.message); }
}

function _renderLvCertForm(cert, reqs) {
  const today = isoToday();
  const empOpts = _lvAllEmps.map(e =>
    `<option value="${e.id}" ${e.id == cert.employee_id ? 'selected' : ''}>${esc(e.last_name + ', ' + e.first_name)} (${esc(e.employee_number || '')})</option>`).join('');
  const reqOpts = (reqs || []).map(r =>
    `<option value="${r.id}" ${r.id == cert.leave_request_id ? 'selected' : ''}>${esc(r.type_name)} ${esc(r.start_date)} – ${esc(r.end_date)} (${esc(r.status)})</option>`).join('');

  const fileWidget = cert.file_name
    ? `<div class="lv-cert-file">
         <span class="col-accent">📎 ${esc(cert.file_name)}</span>
         <button type="button" class="btn btn-outline btn-sm" onclick="window.open('/api/leave/certs/${cert.id}/file','_blank')">⬇ Download</button>
         <button type="button" class="btn btn-outline btn-sm lv-btn-decline" onclick="_lvCertFileRemove(${cert.id})">✕ Remove</button>
       </div>`
    : '';

  document.getElementById('det-body').innerHTML = `
    <div class="det-section">
      <div class="form-grid">
        <div class="form-field form-field-full">
          ${fileWidget}
          <label class="form-lbl">${cert.file_name ? 'Replace file' : 'Attach file'} <span class="form-optional">(PDF, image — max 10 MB)</span></label>
          <input type="file" class="form-input" id="cert-file" accept=".pdf,.png,.jpg,.jpeg,.gif,.bmp,.webp,.doc,.docx">
        </div>
        <div class="form-field form-field-full">
          <label class="form-lbl">Employee *</label>
          <select class="form-input" id="cert-emp-form">
            <option value="">— select —</option>${empOpts}
          </select>
        </div>
        <div class="form-field form-field-full">
          <label class="form-lbl">Leave Request (optional)</label>
          <select class="form-input" id="cert-req-link">
            <option value="">— none —</option>${reqOpts}
          </select>
        </div>
        <div class="form-field">
          <label class="form-lbl">Certificate Date</label>
          <input class="form-input" type="date" id="cert-date" value="${esc(cert.cert_date || today)}">
        </div>
        <div class="form-field">
          <label class="form-lbl">Practitioner</label>
          <input class="form-input" type="text" id="cert-practitioner" value="${esc(cert.practitioner || '')}">
        </div>
        <div class="form-field form-field-full">
          <label class="form-lbl">Practice Name</label>
          <input class="form-input" type="text" id="cert-practice" value="${esc(cert.practice_name || '')}">
        </div>
        <div class="form-field">
          <label class="form-lbl">Covers From</label>
          <input class="form-input" type="date" id="cert-from" value="${esc(cert.cert_from_date || today)}">
        </div>
        <div class="form-field">
          <label class="form-lbl">Covers To</label>
          <input class="form-input" type="date" id="cert-to" value="${esc(cert.cert_to_date || today)}">
        </div>
        <div class="form-field form-field-full">
          <label class="form-lbl">Notes / Condition</label>
          <textarea class="form-input edt-ta-resize" id="cert-notes" rows="2">${esc(cert.condition_notes || '')}</textarea>
        </div>
      </div>
    </div>`;

  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-primary" onclick="_lvCertSave(${cert.id || 'null'})">Save</button>
    <button class="btn btn-outline" onclick="detClose()">Cancel</button>`;
}

async function _lvCertSave(id) {
  const emp_id = document.getElementById('cert-emp-form').value;
  if (!emp_id) { toast('Select an employee.', 'error'); return; }
  const reqLink = document.getElementById('cert-req-link')?.value;
  const payload = {
    id,
    employee_id:      parseInt(emp_id),
    leave_request_id: reqLink ? parseInt(reqLink) : null,
    cert_date:        document.getElementById('cert-date').value,
    practitioner:     document.getElementById('cert-practitioner').value.trim() || null,
    practice_name:    document.getElementById('cert-practice').value.trim() || null,
    cert_from_date:   document.getElementById('cert-from').value,
    cert_to_date:     document.getElementById('cert-to').value,
    condition_notes:  document.getElementById('cert-notes').value.trim() || null,
  };

  const fileInput = document.getElementById('cert-file');
  if (fileInput && fileInput.files[0]) {
    const file = fileInput.files[0];
    if (file.size > 10 * 1024 * 1024) { toast('File exceeds 10 MB limit.', 'error'); return; }
    payload.file_data = await new Promise((res, rej) => {
      const reader = new FileReader();
      reader.onload  = e => res(e.target.result.split(',')[1]);
      reader.onerror = rej;
      reader.readAsDataURL(file);
    });
    payload.file_name = file.name;
    payload.mime_type = file.type || 'application/octet-stream';
  }

  try {
    if (id) {
      await _pMut('PUT', `/api/leave/certs/${id}`, payload);
    } else {
      await _pPost('/api/leave/certs', payload);
    }
    _lvCerts = await apiFetch('/api/leave/certs' + (_lvCertEmpId ? `?employee_id=${_lvCertEmpId}` : ''));
    detClose();
    _renderCertsPage();
    toast('Certificate saved');
  } catch (e) { toast('Save failed: ' + e.message, 'error'); }
}

async function _lvCertDelete(id) {
  if (!confirm('Delete this certificate record?')) return;
  try {
    await _pMut('DELETE', `/api/leave/certs/${id}`, {});
    _lvCerts = _lvCerts.filter(c => c.id !== id);
    _renderCertsPage();
    toast('Certificate deleted');
  } catch (e) { toast('Delete failed: ' + e.message, 'error'); }
}

async function _lvCertFileRemove(certId) {
  if (!confirm('Remove the attached file?')) return;
  try {
    const r = await fetch(`/api/leave/certs/${certId}/file`, {method: 'DELETE', credentials: 'include'});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Remove failed');
    const idx = _lvCerts.findIndex(c => c.id === certId);
    if (idx !== -1) { _lvCerts[idx].file_name = null; _lvCerts[idx].mime_type = null; }
    const cert = idx !== -1 ? _lvCerts[idx] : {};
    const reqs = cert.employee_id
      ? await apiFetch(`/api/leave/requests?employee_id=${cert.employee_id}`).catch(() => [])
      : [];
    _renderLvCertForm(cert, reqs);
    toast('File removed');
  } catch (e) { toast(e.message, 'error'); }
}


// ─────────────────────────────────────────────────────────────────────────────
// TAB 5: PUBLIC HOLIDAYS
// ─────────────────────────────────────────────────────────────────────────────

async function _lvHolLoad() {
  const params = new URLSearchParams();
  if (_lvHolState !== 'All') params.set('state', _lvHolState);
  if (_lvHolYear  !== 'All') { params.set('year_from', _lvHolYear); params.set('year_to', _lvHolYear); }
  _lvHols = await apiFetch('/api/leave/holidays?' + params.toString());
  _renderHolsPage();
}

function _renderHolsPage() {
  const lc = document.getElementById('lv-content');
  const curYr   = new Date().getFullYear();
  const yearOpts = ['All', ...Array.from({length:6}, (_,i) => String(curYr - 1 + i))];

  lc.innerHTML = `
    <div class="inv-toolbar lv-hol-toolbar">
      <div class="lv-hol-filters">
        <label class="lv-bal-emp-label">State:</label>
        <select class="form-input lv-hol-sel" id="hol-state" onchange="_lvHolStateChange(this.value)">
          ${['All', ...LV_STATES].map(s => `<option value="${s}" ${s === _lvHolState ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
        <label class="lv-bal-emp-label">Year:</label>
        <select class="form-input lv-hol-sel" id="hol-year" onchange="_lvHolYearChange(this.value)">
          ${yearOpts.map(y => `<option value="${y}" ${y === _lvHolYear ? 'selected' : ''}>${y}</option>`).join('')}
        </select>
      </div>
      <div class="lv-hol-actions">
        <button class="btn btn-outline btn-sm" onclick="_lvHolExportCsv()">⬇ Export CSV</button>
        <button class="btn btn-outline btn-sm" onclick="_lvHolImportOpen()">⬆ Import CSV</button>
        <button class="btn btn-primary" onclick="_lvHolFormOpen(null)">+ Add Holiday</button>
      </div>
    </div>

    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        <th>Date</th>
        <th>State</th>
        <th>Holiday Name</th>
        <th></th>
      </tr></thead><tbody>
        ${_lvHols.length ? _lvHols.map(_lvHolRow).join('') :
          `<tr><td colspan="4" class="tbl-empty-row">No public holidays found.</td></tr>`}
      </tbody></table>
    </div>
    <div class="mt-8"><span class="count-pill">${_lvHols.length} holiday${_lvHols.length !== 1 ? 's' : ''}</span></div>
    </div>`;
}

function _lvHolRow(h) {
  return `
    <tr class="inv-row" onclick="_lvHolFormOpen(${h.id})">
      <td class="inv-mono">${esc(h.holiday_date)}</td>
      <td><span class="badge badge-draft badge-sm-inline">${esc(h.state)}</span></td>
      <td><span class="inv-contact">${esc(h.name)}</span></td>
      <td onclick="event.stopPropagation()">
        <button class="btn btn-outline btn-sm lv-btn-decline" onclick="_lvHolDelete(${h.id})">Delete</button>
      </td>
    </tr>`;
}

async function _lvHolStateChange(val) { _lvHolState = val; await _lvHolLoad(); }
async function _lvHolYearChange(val)  { _lvHolYear  = val; await _lvHolLoad(); }

function _lvHolFormOpen(id) {
  const existing = id ? _lvHols.find(h => h.id === id) : null;
  _lvHolShowModal(existing);
}

function _lvHolShowModal(existing) {
  const today = isoToday();
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box modal-xs">
      <div class="modal-hdr"><span>${existing ? 'Edit' : 'Add'} Public Holiday</span></div>
      <div class="modal-body">
        <div class="form-grid form-grid-1">
          <div class="form-field">
            <label class="form-lbl">Date * <span class="col-ink3 pr-hint-sm">(YYYY-MM-DD)</span></label>
            <input class="form-input" type="date" id="hol-date" value="${esc(existing ? existing.holiday_date : today)}">
          </div>
          <div class="form-field">
            <label class="form-lbl">State *</label>
            <select class="form-input" id="hol-state-inp">
              ${LV_STATES.map(s => `<option value="${s}" ${existing && existing.state === s ? 'selected' : s === 'NAT' && !existing ? 'selected' : ''}>${s}</option>`).join('')}
            </select>
          </div>
          <div class="form-field">
            <label class="form-lbl">Name *</label>
            <input class="form-input" type="text" id="hol-name" value="${esc(existing ? existing.name : '')}" placeholder="e.g. Christmas Day">
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="_lvHolSave(${existing ? existing.id : 'null'}, this.closest('.modal-bd'))">Save</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
  setTimeout(() => document.getElementById('hol-name').focus(), 50);
}

async function _lvHolSave(id, bd) {
  const date  = document.getElementById('hol-date').value;
  const state = document.getElementById('hol-state-inp').value;
  const name  = document.getElementById('hol-name').value.trim();
  if (!date || !name) { toast('Date and Name are required.', 'error'); return; }
  const payload = { id, holiday_date: date, state, name };
  try {
    if (id) {
      await _pMut('PUT', `/api/leave/holidays/${id}`, payload);
    } else {
      await _pPost('/api/leave/holidays', payload);
    }
    bd.remove();
    await _lvHolLoad();
    toast('Holiday saved');
  } catch (e) { toast('Save failed: ' + e.message, 'error'); }
}

async function _lvHolDelete(id) {
  if (!confirm('Delete this public holiday?')) return;
  try {
    await _pMut('DELETE', `/api/leave/holidays/${id}`, {});
    await _lvHolLoad();
    toast('Holiday deleted');
  } catch (e) { toast('Delete failed: ' + e.message, 'error'); }
}

function _lvHolExportCsv() {
  const params = new URLSearchParams();
  if (_lvHolState !== 'All') params.set('state', _lvHolState);
  if (_lvHolYear  !== 'All') { params.set('year_from', _lvHolYear); params.set('year_to', _lvHolYear); }
  window.location.href = '/api/leave/holidays/export-csv?' + params.toString();
}

function _lvHolImportOpen() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box modal-md modal-tall">
      <div class="modal-hdr"><span>Import Public Holidays</span></div>
      <div class="modal-body">
        <p class="lv-import-note">Upload a CSV file with columns: <code>holiday_date</code> (YYYY-MM-DD), <code>state</code> (NAT/NSW/…), <code>name</code>.</p>
        <div class="form-grid form-grid-1">
          <div class="form-field">
            <label class="form-lbl">CSV File</label>
            <input class="form-input" type="file" id="hol-import-file" accept=".csv,.txt">
          </div>
          <div class="form-field form-field-check">
            <input type="checkbox" id="hol-overwrite">
            <label class="form-lbl" for="hol-overwrite">Overwrite duplicates (same date + state)</label>
          </div>
        </div>
        <div id="hol-import-preview"></div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-purple btn-sm" onclick="_lvHolPreviewCsv(this.closest('.modal-bd'))">Preview</button>
        <button class="btn btn-primary btn-sm" id="hol-import-confirm" style="display:none"
                onclick="_lvHolDoImport(this.closest('.modal-bd'))">✓ Import</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
}

async function _lvHolPreviewCsv(bd) {
  const fileEl = document.getElementById('hol-import-file');
  if (!fileEl.files.length) { toast('Select a CSV file first.', 'error'); return; }
  const text = await fileEl.files[0].text();
  const rows = _lvParseCsv(text);
  if (!rows.length) { toast('No valid rows found in file.', 'error'); return; }

  // Get existing keys for duplicate detection
  const allHols = await apiFetch('/api/leave/holidays').catch(() => []);
  const existing = new Set(allHols.map(h => h.holiday_date + '|' + h.state));

  const preview = document.getElementById('hol-import-preview');
  let newCount = 0, dupCount = 0;
  const rowsHtml = rows.map(r => {
    const isDup = existing.has(r.holiday_date + '|' + r.state);
    if (isDup) dupCount++; else newCount++;
    return `<tr class="${isDup ? 'lv-import-dup' : ''}">
      <td class="inv-mono">${esc(r.holiday_date)}</td>
      <td><span class="badge badge-draft badge-sm-inline">${esc(r.state)}</span></td>
      <td>${esc(r.name)}</td>
      <td class="td-sm">${isDup ? '<span class="col-amber">Duplicate</span>' : '<span class="col-green">New</span>'}</td>
    </tr>`;
  }).join('');

  preview.innerHTML = `
    <div class="lv-import-summary">${newCount} new · ${dupCount} duplicate${dupCount !== 1 ? 's' : ''}</div>
    <div class="tbl-overflow-x tbl-overflow-short">
      <table class="inv-list-table tbl-sm"><thead><tr>
        <th>Date</th><th>State</th><th>Name</th><th>Status</th>
      </tr></thead><tbody>${rowsHtml}</tbody></table>
    </div>`;

  // Store rows on the bd element for import step
  bd._importRows = rows;
  bd._importExisting = existing;
  document.getElementById('hol-import-confirm').style.display = '';
}

async function _lvHolDoImport(bd) {
  const overwrite = document.getElementById('hol-overwrite').checked;
  const rows = bd._importRows || [];
  const existing = bd._importExisting || new Set();
  const toImport = overwrite ? rows : rows.filter(r => !existing.has(r.holiday_date + '|' + r.state));
  if (!toImport.length) { toast('Nothing to import.', 'error'); return; }
  try {
    const res = await fetch('/api/leave/holidays/import-csv', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rows: toImport, overwrite }),
    });
    const j = await res.json();
    if (!j.ok) throw new Error(j.error || 'Import failed');
    bd.remove();
    await _lvHolLoad();
    toast(`Imported ${j.data.imported} holiday${j.data.imported !== 1 ? 's' : ''}${j.data.skipped ? `, skipped ${j.data.skipped} duplicate${j.data.skipped !== 1 ? 's' : ''}` : ''}`);
  } catch (e) { toast('Import failed: ' + e.message, 'error'); }
}

function _lvParseCsv(text) {
  const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n').filter(l => l.trim());
  if (!lines.length) return [];
  const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/^"|"$/g, ''));
  const dateIdx  = headers.findIndex(h => h === 'holiday_date' || h === 'date');
  const stateIdx = headers.findIndex(h => h === 'state');
  const nameIdx  = headers.findIndex(h => h === 'name' || h === 'holiday_name');
  if (dateIdx < 0 || nameIdx < 0) return [];

  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(',').map(c => c.trim().replace(/^"|"$/g, ''));
    const date  = cols[dateIdx]  || '';
    const state = (cols[stateIdx] || 'NAT').toUpperCase();
    const name  = cols[nameIdx]  || '';
    if (!date || !name || !/^\d{4}-\d{2}-\d{2}$/.test(date)) continue;
    if (!LV_STATES.includes(state)) continue;
    rows.push({ holiday_date: date, state, name });
  }
  return rows;
}

// ═══════════════════════════════════════════════════════════════════════════
// ABA FILE EXPORT  (Stage 5P)
//   • ⬇ ABA File toolbar button → dialog: pick pay run + process date
//   • ⬇ ABA File in pay run detail footer → pre-selects that run
//   • Validates employee bank details before download
//   • Settings panel: user ID, description (persisted in company record)
// ═══════════════════════════════════════════════════════════════════════════

let _abaSettings = null;   // cached { user_id, user_name, description, bsb, account_number }

async function _abaLoadSettings() {
  if (_abaSettings) return _abaSettings;
  try {
    const r = await fetch('/api/payroll/aba-settings');
    const j = await r.json();
    _abaSettings = j.data || {};
  } catch (e) {
    _abaSettings = {};
  }
  return _abaSettings;
}

// ── Open ABA dialog (no run pre-selected) ────────────────────────────────────
async function _abaOpen() {
  await _abaShowDialog(null, null);
}

// ── Open ABA dialog pre-loaded with a specific run ───────────────────────────
async function _abaDownload(runId, periodEnd) {
  await _abaShowDialog(runId, periodEnd);
}

// ── Core dialog builder ───────────────────────────────────────────────────────
async function _abaShowDialog(preRunId, prePeriodEnd) {
  const [settings, runsResp] = await Promise.all([
    _abaLoadSettings(),
    fetch('/api/payroll/pay-runs').then(r => r.json()),
  ]);

  const allRuns = (runsResp.data || []).filter(r =>
    r.status === 'Finalised' || r.status === 'STP_Lodged');

  if (!allRuns.length) {
    alert('No finalised pay runs to export.\n\nFinalise a pay run first.');
    return;
  }

  // Default process date: today
  const today = isoToday();

  // Build run options
  const runOptions = allRuns.map(r =>
    `<option value="${r.id}" ${r.id == preRunId ? 'selected' : ''}>
       ${esc(r.run_number)} — ${r.pay_period_end || ''} (${r.status})
     </option>`
  ).join('');

  // Show modal
  const modal = document.getElementById('aba-modal');
  if (!modal) {
    // Create modal if it doesn't exist yet
    const div = document.createElement('div');
    div.id = 'aba-modal';
    div.className = 'modal-bd';
    div.innerHTML = `
      <div class="modal-box modal-sm">
        <div class="modal-title">⬇ Export ABA Bank File</div>
        <div id="aba-modal-body"></div>
      </div>`;
    div.addEventListener('click', e => { if (e.target === div) _abaClose(); });
    document.body.appendChild(div);
  }

  document.getElementById('aba-modal-body').innerHTML = `
    <div class="modal-field">
      <label class="modal-lbl">Pay Run</label>
      <select class="modal-sel" id="aba-run-id">${runOptions}</select>
    </div>
    <div class="modal-field">
      <label class="modal-lbl">Process Date</label>
      <input class="modal-inp" id="aba-process-date" type="date"
             value="${prePeriodEnd || today}">
    </div>
    <div class="modal-field">
      <label class="modal-lbl">Description (on bank statement, max 12 chars)</label>
      <input class="modal-inp" id="aba-description" type="text" maxlength="12"
             value="${esc(settings.description || 'PAYROLL')}" placeholder="PAYROLL">
    </div>

    <details class="aba-settings-details" id="aba-settings-details">
      <summary class="aba-summary">⚙ Bank Settings</summary>
      <div class="aba-settings-body">
        <div class="aba-settings-info">
          Your bank account BSB and account number are set in
          <strong>Accounts</strong>. The fields below are ABA-specific.
        </div>
        <div class="modal-field">
          <label class="modal-lbl">Direct Entry User ID (6 digits, from your bank)</label>
          <input class="modal-inp" id="aba-user-id" type="text" maxlength="6"
                 value="${esc(settings.user_id || '')}" placeholder="999999">
        </div>
        <div class="aba-settings-foot">
          <button class="btn btn-outline btn-sm" onclick="_abaSaveSettings()">Save Settings</button>
        </div>
      </div>
    </details>

    ${settings.bsb ? `
      <div class="aba-info">
        Debiting from: <strong>${esc(settings.account_name || settings.user_name || '')}</strong>
        &nbsp;BSB ${esc(settings.bsb)}&nbsp; Acct ${esc(settings.account_number || '—')}
      </div>` : `
      <div class="aba-warn">
        ⚠ No bank account with a BSB found. Add your bank BSB + account number in
        <strong>Accounts</strong> before generating an ABA file.
      </div>`}

    <div class="modal-acts">
      <button class="btn btn-outline" onclick="_abaClose()">Cancel</button>
      <button class="btn btn-primary" id="aba-generate-btn"
              onclick="_abaGenerate()">Generate &amp; Download</button>
    </div>
  `;

  document.getElementById('aba-modal').classList.add('open');
}

function _abaClose() {
  const m = document.getElementById('aba-modal');
  if (m) m.classList.remove('open');
}

async function _abaSaveSettings() {
  const userId = (document.getElementById('aba-user-id')?.value || '').trim();
  const desc   = (document.getElementById('aba-description')?.value || 'PAYROLL').trim();
  try {
    const r = await fetch('/api/payroll/aba-settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: userId, description: desc }),
    });
    if (!r.ok) throw new Error(await r.text());
    _abaSettings = null;   // invalidate cache
    await _abaLoadSettings();
    // brief visual confirmation
    const btn = document.querySelector('#aba-settings-details button');
    if (btn) { btn.textContent = '✓ Saved'; setTimeout(() => { btn.textContent = 'Save Settings'; }, 1800); }
  } catch (e) {
    alert('Failed to save settings: ' + e.message);
  }
}

async function _abaGenerate() {
  const runId      = document.getElementById('aba-run-id')?.value;
  const processDate = document.getElementById('aba-process-date')?.value;
  const description = (document.getElementById('aba-description')?.value || 'PAYROLL').trim().slice(0, 12);

  if (!runId)       { alert('Please select a pay run.'); return; }
  if (!processDate) { alert('Please enter a process date.'); return; }

  const btn = document.getElementById('aba-generate-btn');
  const orig = btn.textContent;
  btn.disabled = true;
  btn.textContent = 'Generating…';

  try {
    const r = await fetch(`/api/payroll/pay-runs/${runId}/aba`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ process_date: processDate, description }),
    });

    if (!r.ok) {
      const j = await r.json().catch(() => ({}));
      const detail = j.error || j.message || `Server error ${r.status}`;
      throw new Error(detail);
    }

    // Trigger browser download
    const blob = await r.blob();
    const cd   = r.headers.get('Content-Disposition') || '';
    const fnMatch = cd.match(/filename="([^"]+)"/);
    const filename = fnMatch ? fnMatch[1] : `payroll_${processDate}.aba`;

    const url = URL.createObjectURL(blob);
    const a   = document.createElement('a');
    a.href     = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    _abaClose();

  } catch (e) {
    alert('ABA export failed:\n\n' + e.message +
          '\n\nCheck that all employees have BSB and Account Number set in Payroll → Employees.');
  } finally {
    btn.disabled    = false;
    btn.textContent = orig;
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// ── AWARDS MANAGEMENT (Stage 5M) ────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════

let _awAll     = [];    // all awards (active + inactive when showInactive)
let _awCurrent = null;  // selected award object
let _awTab     = 'classifications';  // 'classifications' | 'allowances' | 'penalties'
let _awMeta    = null;  // { instrument_types, allowance_types, penalty_types }
let _awShowInactive = false;

async function _prLoadAwards() {
  _prView = 'awards';
  const mc = document.getElementById('module-content');
  mc.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    [_awAll, _awMeta] = await Promise.all([
      apiFetch('/api/payroll/awards?active_only=0').catch(() => apiFetch('/api/payroll/awards')),
      apiFetch('/api/payroll/awards/meta').catch(() => null),
    ]);
    _awAll = _awAll || [];
    _renderAwardsPage();
  } catch (e) {
    mc.innerHTML = `<div class="state-error">Failed to load awards: ${esc(e.message)}</div>`;
  }
}

function _awFiltered() {
  return _awAll.filter(a => _awShowInactive || a.is_active);
}

function _renderAwardsPage() {
  const mc = document.getElementById('module-content');
  const awards = _awFiltered();

  mc.innerHTML = `
    <div class="inv-toolbar">
      <div class="aw-toolbar-lhs">
        📋 Awards &amp; Agreements
        <label class="aw-show-inactive-label">
          <input type="checkbox" ${_awShowInactive ? 'checked' : ''}
            onchange="_awShowInactive=this.checked;_renderAwardsPage();if(_awCurrent)_awLoadTab(_awTab)">
          Show inactive
        </label>
      </div>
      <div class="pr-toolbar-actions">
        <button class="btn btn-primary" onclick="_awFormOpen(null)">+ New Award</button>
        <button class="btn btn-outline" onclick="_prLoadEmployees()">← Employees</button>
      </div>
    </div>

    <div class="aw-layout">

      <!-- Left: award card list -->
      <div class="aw-list-col">
        ${awards.length === 0
          ? `<div class="aw-list-empty">
               <div class="aw-list-empty-icon">📋</div>
               <div class="aw-list-empty-title">No awards yet</div>
               <div class="aw-list-empty-sub">Add a Modern Award or Enterprise Agreement to get started.</div>
             </div>`
          : awards.map(a => `
            <div class="aw-card${_awCurrent && _awCurrent.id === a.id ? ' active' : ''}${!a.is_active ? ' inactive' : ''}"
                 onclick="_awSelect(${a.id})">
              <div class="aw-card-name">${esc(a.name)}</div>
              <div class="aw-card-meta">
                ${a.instrument_type ? `<span>${esc(a.instrument_type)}</span>` : ''}
                ${a.code ? `<span class="aw-card-code">${esc(a.code)}</span>` : ''}
                ${!a.is_active ? '<span class="aw-card-inactive-tag">Inactive</span>' : ''}
              </div>
              <div class="aw-card-emp-count">${a.employee_count || 0} employee${a.employee_count === 1 ? '' : 's'}</div>
            </div>`).join('')
        }
      </div>

      <!-- Right: award detail panel -->
      <div class="aw-detail-col">
        ${_awCurrent ? _renderAwardDetail() : `
          <div class="aw-detail-empty">
            <div class="aw-detail-empty-arrow">←</div>
            <div>Select an award to view detail</div>
          </div>`}
      </div>

    </div>`;
}

async function _awSelect(awardId) {
  try {
    _awCurrent = await apiFetch(`/api/payroll/awards/${awardId}`);
  } catch(e) {
    _awCurrent = _awAll.find(a => a.id === awardId) || null;
  }
  _renderAwardsPage();
  // Load tab data
  if (_awCurrent) _awLoadTab(_awTab);
}

function _renderAwardDetail() {
  const a = _awCurrent;
  return `
    <!-- Header -->
    <div class="aw-det-hdr">
      <div class="aw-det-hdr-info">
        <div class="aw-det-title">${esc(a.name)}</div>
        <div class="aw-det-subtitle">
          ${a.instrument_type ? `<span>${esc(a.instrument_type)}</span>` : ''}
          ${a.code ? `<span class="aw-det-subtitle-code">${esc(a.code)}</span>` : ''}
          ${a.industry ? `<span>Industry: ${esc(a.industry)}</span>` : ''}
          ${a.effective_date ? `<span>Effective: ${fmtDate(a.effective_date)}</span>` : ''}
          ${a.expiry_date ? `<span class="aw-det-expiry">Expires: ${fmtDate(a.expiry_date)}</span>` : ''}
        </div>
        ${a.notes ? `<div class="aw-det-notes">${esc(a.notes)}</div>` : ''}
      </div>
      <div class="aw-det-actions">
        <button class="btn btn-outline aw-det-btn"
          onclick="_awFormOpen(${a.id})">Edit</button>
        <button class="btn btn-outline aw-det-btn aw-det-btn-warn"
          onclick="_awWageIncreaseOpen()">📈 Wage Increase</button>
        <button class="btn btn-outline aw-det-btn aw-det-btn-danger"
          onclick="_awDelete(${a.id})">Delete</button>
      </div>
    </div>

    <!-- Tab bar -->
    <div class="aw-tabs">
      ${[['classifications','Classifications'],['allowances','Allowances'],['penalties','Penalties']].map(([k,l]) => `
        <button class="aw-tab${_awTab===k?' active':''}"
          onclick="_awTab='${k}';_awLoadTab('${k}')">${l}</button>`).join('')}
    </div>

    <!-- Tab content -->
    <div id="aw-tab-body" class="aw-tab-body">
      <div class="state-loading">Loading…</div>
    </div>`;
}

async function _awLoadTab(tab) {
  _awTab = tab;
  const body = document.getElementById('aw-tab-body');
  if (!body || !_awCurrent) return;
  body.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    if (tab === 'classifications') await _awLoadClassifications();
    else if (tab === 'allowances')  await _awLoadAllowances();
    else if (tab === 'penalties')   await _awLoadPenalties();
  } catch(e) {
    if (body) body.innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
  }
}

// ── Classifications tab ────────────────────────────────────────────────────────

async function _awLoadClassifications() {
  const body = document.getElementById('aw-tab-body');
  if (!body) return;
  const clss = await apiFetch(`/api/payroll/awards/${_awCurrent.id}/classifications`);

  body.innerHTML = `
    <div class="aw-tab-hdr">
      <span class="aw-tab-title">Classifications</span>
      <button class="btn btn-primary btn-sm" onclick="_awClsFormOpen(null)">+ Add Classification</button>
    </div>
    ${clss.length === 0
      ? `<div class="state-empty">No classifications yet.</div>`
      : `<div class="aw-cls-list">
          ${clss.map(c => `
            <div class="aw-cls-card">
              <div class="aw-cls-card-hdr">
                ${c.code ? `<span class="aw-cls-code">${esc(c.code)}</span>` : ''}
                <span class="aw-cls-name">${esc(c.name)}</span>
                ${c.hourly_rate != null
                  ? `<span class="aw-cls-rate">$${parseFloat(c.hourly_rate).toFixed(2)}/hr</span>`
                  : `<span class="aw-cls-no-rate">no rate</span>`}
                <button class="btn btn-outline btn-xs" onclick="_awClsFormOpen(${c.id})">Edit</button>
                <button class="btn btn-outline btn-xs" onclick="_awRatesOpen(${c.id}, '${esc(c.name)}')">Pay Rates</button>
                <button class="btn btn-outline btn-xs pr-btn-danger" onclick="_awClsDelete(${c.id})">×</button>
              </div>
              ${c.description ? `<div class="aw-cls-desc">${esc(c.description)}</div>` : ''}
            </div>`).join('')}
         </div>`}`;
}

// ── Classification form ────────────────────────────────────────────────────────

async function _awClsFormOpen(clsId) {
  let cls = { award_id: _awCurrent.id, sort_order: 0, is_active: 1 };
  if (clsId) {
    // fetch from classifications list (already loaded) or from server
    const existing = await apiFetch(`/api/payroll/awards/${_awCurrent.id}/classifications`)
      .then(list => list.find(c => c.id === clsId)).catch(() => null);
    if (existing) cls = existing;
  }
  const isNew = !clsId;

  const overlay = document.createElement('div');
  overlay.id = 'aw-cls-overlay';
  overlay.className = 'modal-bd';
  overlay.style.display = 'flex';
  overlay.innerHTML = `
    <div class="modal-box modal-sm modal-tall">
      <div class="modal-hdr"><span>${isNew ? 'Add Classification' : 'Edit Classification'}</span></div>
      <div class="modal-body">
        <div class="form-grid form-grid-1">
          <div class="form-field">
            <label class="form-lbl">Code <span class="col-ink3">(e.g. L1, Grade A)</span></label>
            <input id="awcls-code" class="form-input" value="${esc(cls.code||'')}">
          </div>
          <div class="form-field">
            <label class="form-lbl">Name <span class="col-red">*</span></label>
            <input id="awcls-name" class="form-input" value="${esc(cls.name||'')}">
          </div>
          <div class="form-field">
            <label class="form-lbl">Description / Duties</label>
            <textarea id="awcls-desc" class="form-input" rows="3">${esc(cls.description||'')}</textarea>
          </div>
          <div class="form-field">
            <label class="form-lbl">Minimum Qualifications</label>
            <input id="awcls-quals" class="form-input" value="${esc(cls.minimum_qualifications||'')}">
          </div>
          <div class="form-field">
            <label class="form-lbl">Sort Order</label>
            <input id="awcls-sort" class="form-input" type="number" value="${cls.sort_order||0}" style="width:80px">
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="_awClsSave(${clsId||'null'})">Save</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
}

async function _awClsSave(clsId) {
  const name = document.getElementById('awcls-name')?.value.trim();
  if (!name) { alert('Name is required.'); return; }
  const data = {
    award_id:               _awCurrent.id,
    code:                   document.getElementById('awcls-code')?.value.trim() || null,
    name,
    description:            document.getElementById('awcls-desc')?.value.trim() || null,
    minimum_qualifications: document.getElementById('awcls-quals')?.value.trim() || null,
    sort_order:             parseInt(document.getElementById('awcls-sort')?.value) || 0,
    is_active:              1,
  };
  try {
    if (clsId) {
      await _pPut(`/api/payroll/classifications/${clsId}`, data);
    } else {
      await _pPost(`/api/payroll/awards/${_awCurrent.id}/classifications`, data);
    }
    document.getElementById('aw-cls-overlay')?.remove();
    await _awLoadTab('classifications');

  } catch(e) {
    alert('Save failed: ' + e.message);
  }
}

async function _awClsDelete(clsId) {
  if (!confirm('Delete this classification? This cannot be undone.')) return;
  try {
    await _pDel(`/api/payroll/classifications/${clsId}`);
    await _awLoadTab('classifications');
  } catch(e) {
    alert('Delete failed: ' + e.message);
  }
}

// ── Pay Rates panel (slide-over inside modal) ─────────────────────────────────

async function _awRatesOpen(clsId, clsName) {
  const overlay = document.createElement('div');
  overlay.id = 'aw-rates-overlay';
  overlay.className = 'modal-bd';
  overlay.style.display = 'flex';
  overlay.innerHTML = `
    <div class="modal-box modal-lg modal-tall">
      <div class="modal-hdr">
        <span>Pay Rates \u2014 ${esc(clsName)}</span>
        <div class="aw-hdr-actions">
          <button class="btn btn-primary btn-sm" onclick="_awRateFormOpen(${clsId}, null)">+ Add Rate</button>
          <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Close</button>
        </div>
      </div>
      <div class="modal-body">
        <div id="aw-rates-body"><div class="state-loading">Loading\u2026</div></div>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  await _awRatesRefresh(clsId);
}

async function _awRatesRefresh(clsId) {
  const body = document.getElementById('aw-rates-body');
  if (!body) return;
  const rates = await apiFetch(`/api/payroll/classifications/${clsId}/pay-rates`).catch(() => []);

  body.innerHTML = rates.length === 0
    ? `<div class="state-empty">No pay rates yet. Add one above.</div>`
    : `<table class="inv-list-table tbl-sm">
        <thead><tr>
          <th>Pay Point</th><th>Effective</th><th>Hourly</th>
          <th>Weekly</th><th>Casual</th><th>OT ×1.5</th><th>OT ×2.0</th>
          <th>Source</th><th></th>
        </tr></thead>
        <tbody>
          ${rates.map(r => `<tr>
            <td class="col-c">${r.pay_point}</td>
            <td>${fmtDate(r.effective_date)}</td>
            <td class="inv-mono col-green">$${(r.hourly_rate||0).toFixed(4)}</td>
            <td class="inv-mono">${r.weekly_rate != null ? '$'+r.weekly_rate.toFixed(2) : '—'}</td>
            <td class="inv-mono">${r.casual_rate != null ? '$'+r.casual_rate.toFixed(4) : '—'}</td>
            <td class="inv-mono">${r.overtime_rate_1_5 != null ? '$'+r.overtime_rate_1_5.toFixed(4) : '—'}</td>
            <td class="inv-mono">${r.overtime_rate_2_0 != null ? '$'+r.overtime_rate_2_0.toFixed(4) : '—'}</td>
            <td style="max-width:140px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(r.source_note||'')}</td>
            <td class="col-nowrap">
              <button class="btn btn-outline btn-xs" onclick="_awRateFormOpen(${clsId}, ${r.id})">Edit</button>
              <button class="btn btn-outline btn-xs pr-btn-danger" onclick="_awRateDelete(${r.id},${clsId})">×</button>
            </td>
          </tr>`).join('')}
        </tbody>
       </table>`;
}

async function _awRateFormOpen(clsId, rateId) {
  let r = { classification_id: clsId, pay_point: 1, effective_date: isoToday() };
  if (rateId) {
    const rates = await apiFetch(`/api/payroll/classifications/${clsId}/pay-rates`).catch(() => []);
    const found = rates.find(x => x.id === rateId);
    if (found) r = found;
  }
  const isNew = !rateId;

  // Determine initial casual mode/value for edit
  let initCasMode = '%', initCasVal = 25;
  if (r.casual_rate && r.hourly_rate) {
    if (r.casual_rate > r.hourly_rate) {
      initCasMode = '$'; initCasVal = r.casual_rate;
    } else {
      initCasMode = '%';
      initCasVal = Math.round((r.casual_rate / r.hourly_rate - 1) * 10000) / 100;
    }
  }

  const modal = document.createElement('div');
  modal.id = 'aw-rate-form-overlay';
  modal.className = 'modal-bd';
  modal.style.display = 'flex';
  modal.innerHTML = `
    <div class="modal-box modal-sm modal-tall">
      <div class="modal-hdr"><span>${isNew ? 'Add Pay Rate' : 'Edit Pay Rate'}</span></div>
      <div class="modal-body">
        <div class="form-grid">
          <div class="form-field">
            <label class="form-lbl">Pay Point</label>
            <input id="awrt-pp" class="form-input" type="number" min="1" value="${r.pay_point||1}">
          </div>
          <div class="form-field">
            <label class="form-lbl">Effective Date <span class="col-red">*</span></label>
            <input id="awrt-effdate" class="form-input" type="date" value="${r.effective_date||''}">
          </div>
          <div class="form-field">
            <label class="form-lbl">Hourly Rate <span class="col-red">*</span></label>
            <input id="awrt-hourly" class="form-input" type="number" step="0.0001" value="${r.hourly_rate||''}">
          </div>
          <div class="form-field">
            <label class="form-lbl">Weekly Rate</label>
            <input id="awrt-weekly" class="form-input" type="number" step="0.01" value="${r.weekly_rate||''}">
          </div>
          <div class="form-field form-field-full">
            <label class="form-lbl">Casual Loading</label>
            <div class="aw-cas-row">
              <select id="awrt-cas-mode" class="form-input aw-cas-mode-sel">
                <option value="%" ${initCasMode==='%'?'selected':''}>%</option>
                <option value="$" ${initCasMode==='$'?'selected':''}>\$</option>
              </select>
              <input id="awrt-cas-val" class="form-input" type="number" step="0.01" value="${initCasVal}">
              <span id="awrt-cas-preview" class="aw-cas-preview"></span>
            </div>
          </div>
          <div class="form-field">
            <label class="form-lbl">OT \xd71.5</label>
            <input id="awrt-ot15" class="form-input" type="number" step="0.0001" value="${r.overtime_rate_1_5||''}">
          </div>
          <div class="form-field">
            <label class="form-lbl">OT \xd72.0</label>
            <input id="awrt-ot20" class="form-input" type="number" step="0.0001" value="${r.overtime_rate_2_0||''}">
          </div>
          <div class="form-field form-field-full">
            <label class="form-lbl">Source Note</label>
            <input id="awrt-source" class="form-input" placeholder="e.g. Annual Wage Review 2025" value="${esc(r.source_note||'')}">
          </div>
        </div>
        <p class="aw-rate-hint">💡 Leave OT fields blank to auto-calculate (\xd71.5, \xd72.0). Weekly auto-fills as \xd738.</p>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="_awRateSave(${clsId}, ${rateId||'null'})">Save</button>
      </div>
    </div>`;
  document.body.appendChild(modal);

  const _updCasPrev = () => {
    const h    = parseFloat(document.getElementById('awrt-hourly')?.value);
    const mode = document.getElementById('awrt-cas-mode')?.value;
    const val  = parseFloat(document.getElementById('awrt-cas-val')?.value);
    const el   = document.getElementById('awrt-cas-preview');
    if (el) {
      el.textContent = (h && !isNaN(val))
        ? `= $${(mode === '%' ? h * (1 + val / 100) : val).toFixed(4)}/hr`
        : '';
    }
  };

  document.getElementById('awrt-hourly')?.addEventListener('input', function() {
    const h = parseFloat(this.value);
    if (!h) return;
    const ot15El = document.getElementById('awrt-ot15');
    const ot20El = document.getElementById('awrt-ot20');
    const wkEl   = document.getElementById('awrt-weekly');
    if (!ot15El.value) ot15El.value = (h * 1.5).toFixed(4);
    if (!ot20El.value) ot20El.value = (h * 2.0).toFixed(4);
    if (!wkEl.value)   wkEl.value   = (h * 38).toFixed(2);
    _updCasPrev();
  });
  document.getElementById('awrt-cas-mode')?.addEventListener('change', _updCasPrev);
  document.getElementById('awrt-cas-val')?.addEventListener('input', _updCasPrev);
  if (r.hourly_rate) _updCasPrev();
}

async function _awRateSave(clsId, rateId) {
  const hourly = parseFloat(document.getElementById('awrt-hourly')?.value);
  const effDate = document.getElementById('awrt-effdate')?.value;
  if (!hourly || !effDate) { alert('Hourly rate and effective date are required.'); return; }
  const casMode = document.getElementById('awrt-cas-mode')?.value;
  const casVal  = parseFloat(document.getElementById('awrt-cas-val')?.value);
  const casualRate = (casMode && !isNaN(casVal) && casVal > 0)
    ? (casMode === '%' ? Math.round(hourly * (1 + casVal / 100) * 10000) / 10000 : casVal)
    : null;
  const data = {
    classification_id: clsId,
    pay_point:         parseInt(document.getElementById('awrt-pp')?.value) || 1,
    effective_date:    effDate,
    hourly_rate:       hourly,
    weekly_rate:       parseFloat(document.getElementById('awrt-weekly')?.value) || null,
    casual_rate:       casualRate,
    overtime_rate_1_5: parseFloat(document.getElementById('awrt-ot15')?.value) || null,
    overtime_rate_2_0: parseFloat(document.getElementById('awrt-ot20')?.value) || null,
    source_note:       document.getElementById('awrt-source')?.value.trim() || null,
  };
  try {
    if (rateId) {
      await _pPut(`/api/payroll/pay-rates/${rateId}`, data);
    } else {
      await _pPost(`/api/payroll/classifications/${clsId}/pay-rates`, data);
    }
    document.getElementById('aw-rate-form-overlay')?.remove();
    await _awRatesRefresh(clsId);
    // Also refresh the classifications tab in background to update hourly_rate hint
    _awLoadClassifications().catch(() => {});
  } catch(e) {
    alert('Save failed: ' + e.message);
  }
}

async function _awRateDelete(rateId, clsId) {
  if (!confirm('Delete this pay rate row?')) return;
  try {
    await _pDel(`/api/payroll/pay-rates/${rateId}`);
    await _awRatesRefresh(clsId);
  } catch(e) {
    alert('Delete failed: ' + e.message);
  }
}

// ── Allowances tab ─────────────────────────────────────────────────────────────

async function _awLoadAllowances() {
  const body = document.getElementById('aw-tab-body');
  if (!body) return;
  const rows = await apiFetch(`/api/payroll/awards/${_awCurrent.id}/allowances`);

  body.innerHTML = `
    <div class="aw-tab-hdr">
      <span class="aw-tab-title">Allowances</span>
      <button class="btn btn-primary btn-sm" onclick="_awAllowFormOpen(null)">+ Add Allowance</button>
    </div>
    ${rows.length === 0
      ? `<div class="state-empty">No allowances defined.</div>`
      : `<table class="inv-list-table tbl-sm">
          <thead><tr>
            <th>Type</th><th>Name</th><th>Basis</th><th>Amount</th>
            <th>Taxable</th><th>STP Code</th><th>Effective</th><th></th>
          </tr></thead>
          <tbody>
            ${rows.map(r => {
              const amt = r.calculation_basis === 'per_km'     ? `$${(r.rate_per_km||0).toFixed(4)}/km`
                        : r.calculation_basis === 'per_hour'   ? `$${(r.rate_per_hour||0).toFixed(4)}/hr`
                        : r.calculation_basis === 'percent_ordinary' ? `${r.percent_ordinary||0}%`
                        : r.amount != null                     ? `$${r.amount.toFixed(2)}`
                        : '—';
              return `<tr>
                <td>${esc(r.allowance_type||'')}</td>
                <td class="font-med">${esc(r.name)}</td>
                <td class="col-muted">${esc(r.calculation_basis||'fixed')}</td>
                <td class="inv-mono">${amt}</td>
                <td class="col-c">${r.taxable ? '✓' : '✗'}</td>
                <td class="col-mono-sm">${esc(r.stp_allowance_type||'')}</td>
                <td>${r.effective_date ? fmtDate(r.effective_date) : '—'}</td>
                <td class="col-nowrap">
                  <button class="btn btn-outline btn-xs" onclick="_awAllowFormOpen(${r.id})">Edit</button>
                  <button class="btn btn-outline btn-xs pr-btn-danger" onclick="_awAllowDelete(${r.id})">×</button>
                </td>
              </tr>`;}).join('')}
          </tbody>
         </table>`}`;
}

async function _awAllowFormOpen(allowId) {
  const meta = _awMeta || {};
  const allowanceTypes = meta.allowance_types || ['Meal allowance','Travel allowance','Other'];
  let r = { award_id: _awCurrent.id, calculation_basis: 'fixed', taxable: 1, stp_allowance_type: 'OD', is_active: 1 };
  if (allowId) {
    const rows = await apiFetch(`/api/payroll/awards/${_awCurrent.id}/allowances`).catch(() => []);
    const found = rows.find(x => x.id === allowId);
    if (found) r = found;
  }
  const isNew = !allowId;

  const overlay = document.createElement('div');
  overlay.id = 'aw-allow-overlay';
  overlay.className = 'modal-bd';
  overlay.style.display = 'flex';
  overlay.innerHTML = `
    <div class="modal-box modal-sm modal-tall">
      <div class="modal-hdr"><span>${isNew ? 'Add Allowance' : 'Edit Allowance'}</span></div>
      <div class="modal-body">
        <div class="form-grid">
          <div class="form-field">
            <label class="form-lbl">Type <span class="col-red">*</span></label>
            <select id="awal-type" class="form-input">
              ${allowanceTypes.map(t => `<option ${r.allowance_type===t?'selected':''}>${esc(t)}</option>`).join('')}
            </select>
          </div>
          <div class="form-field">
            <label class="form-lbl">Name <span class="col-red">*</span></label>
            <input id="awal-name" class="form-input" value="${esc(r.name||'')}">
          </div>
          <div class="form-field">
            <label class="form-lbl">Calculation Basis</label>
            <select id="awal-basis" class="form-input" onchange="_awAllowBasisChange()">
              ${['fixed','per_km','per_hour','percent_ordinary'].map(b =>
                `<option value="${b}" ${r.calculation_basis===b?'selected':''}>${b}</option>`).join('')}
            </select>
          </div>
          <div id="awal-amt-wrap" class="form-field">
            <label class="form-lbl" id="awal-amt-label">Amount ($)</label>
            <input id="awal-amount" class="form-input" type="number" step="0.0001" value="${r.amount??''}">
          </div>
          <div class="form-field form-field-full">
            <label class="form-lbl">Description</label>
            <textarea id="awal-desc" class="form-input" rows="2">${esc(r.description||'')}</textarea>
          </div>
          <div class="form-field">
            <label class="form-lbl">STP Allowance Type</label>
            <input id="awal-stp" class="form-input" value="${esc(r.stp_allowance_type||'OD')}"
              placeholder="OD, CD, RD, etc.">
          </div>
          <div class="form-field">
            <label class="form-lbl">Effective Date</label>
            <input id="awal-effdate" class="form-input" type="date" value="${r.effective_date||''}">
          </div>
          <div class="form-field form-field-check form-field-full">
            <input type="checkbox" id="awal-taxable" ${r.taxable?'checked':''}>
            <label for="awal-taxable" class="form-lbl">Taxable</label>
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="_awAllowSave(${allowId||'null'})">Save</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  _awAllowBasisChange();
}

function _awAllowBasisChange() {
  const basis = document.getElementById('awal-basis')?.value;
  const lbl   = document.getElementById('awal-amt-label');
  const inp   = document.getElementById('awal-amount');
  if (!lbl || !inp) return;
  const map = { fixed:'Amount ($)', per_km:'Rate per km ($)', per_hour:'Rate per hour ($)', percent_ordinary:'% of Ordinary Rate' };
  lbl.textContent = map[basis] || 'Amount';
}

async function _awAllowSave(allowId) {
  const name = document.getElementById('awal-name')?.value.trim();
  const type = document.getElementById('awal-type')?.value;
  if (!name || !type) { alert('Type and Name are required.'); return; }
  const basis = document.getElementById('awal-basis')?.value || 'fixed';
  const rawAmt = parseFloat(document.getElementById('awal-amount')?.value) || null;
  const data = {
    award_id:            _awCurrent.id,
    allowance_type:      type,
    name,
    description:         document.getElementById('awal-desc')?.value.trim() || null,
    calculation_basis:   basis,
    amount:              basis === 'fixed'            ? rawAmt : null,
    rate_per_km:         basis === 'per_km'           ? rawAmt : null,
    rate_per_hour:       basis === 'per_hour'         ? rawAmt : null,
    percent_ordinary:    basis === 'percent_ordinary' ? rawAmt : null,
    taxable:             document.getElementById('awal-taxable')?.checked ? 1 : 0,
    stp_allowance_type:  document.getElementById('awal-stp')?.value.trim() || 'OD',
    effective_date:      document.getElementById('awal-effdate')?.value || null,
    is_active:           1,
  };
  try {
    if (allowId) {
      await _pPut(`/api/payroll/allowances/${allowId}`, data);
    } else {
      await _pPost(`/api/payroll/awards/${_awCurrent.id}/allowances`, data);
    }
    document.getElementById('aw-allow-overlay')?.remove();
    await _awLoadTab('allowances');
  } catch(e) {
    alert('Save failed: ' + e.message);
  }
}

async function _awAllowDelete(allowId) {
  if (!confirm('Delete this allowance?')) return;
  try {
    await _pDel(`/api/payroll/allowances/${allowId}`);
    await _awLoadTab('allowances');
  } catch(e) {
    alert('Delete failed: ' + e.message);
  }
}

// ── Penalties tab ──────────────────────────────────────────────────────────────

async function _awLoadPenalties() {
  const body = document.getElementById('aw-tab-body');
  if (!body) return;
  const [rows, clss] = await Promise.all([
    apiFetch(`/api/payroll/awards/${_awCurrent.id}/penalties`),
    apiFetch(`/api/payroll/awards/${_awCurrent.id}/classifications`),
  ]);

  body.innerHTML = `
    <div class="aw-tab-hdr">
      <span class="aw-tab-title">Penalty Rates</span>
      <button class="btn btn-primary btn-sm" onclick="_awPenFormOpen(null)">+ Add Penalty</button>
    </div>
    ${rows.length === 0
      ? `<div class="state-empty">No penalty rates defined.</div>`
      : `<table class="inv-list-table tbl-sm">
          <thead><tr>
            <th>Penalty Type</th><th>Multiplier</th><th>Classification</th>
            <th>Description</th><th>Effective</th><th></th>
          </tr></thead>
          <tbody>
            ${rows.map(r => `<tr>
              <td class="font-med">${esc(r.penalty_type||'')}</td>
              <td class="inv-mono col-accent">×${r.multiplier}</td>
              <td>${r.classification_name ? esc(r.classification_name) : '<span class="col-faint">All</span>'}</td>
              <td class="col-muted">${esc(r.description||'')}</td>
              <td>${r.effective_date ? fmtDate(r.effective_date) : '—'}</td>
              <td class="col-nowrap">
                <button class="btn btn-outline btn-xs" onclick="_awPenFormOpen(${r.id})">Edit</button>
                <button class="btn btn-outline btn-xs pr-btn-danger" onclick="_awPenDelete(${r.id})">×</button>
              </td>
            </tr>`).join('')}
          </tbody>
         </table>`}`;
  // stash classifications for the penalty form
  window._awPenClsList = clss || [];
}

async function _awPenFormOpen(penId) {
  const meta = _awMeta || {};
  const penTypes = (meta.penalty_types || []).map(p => ({ code: p.code || p, label: p.label || p.code || p }));
  const clss = window._awPenClsList || [];
  let r = { award_id: _awCurrent.id, multiplier: 1.5, is_active: 1 };
  if (penId) {
    const rows = await apiFetch(`/api/payroll/awards/${_awCurrent.id}/penalties`).catch(() => []);
    const found = rows.find(x => x.id === penId);
    if (found) r = found;
  }
  const isNew = !penId;

  const overlay = document.createElement('div');
  overlay.id = 'aw-pen-overlay';
  overlay.className = 'modal-bd';
  overlay.style.display = 'flex';
  overlay.innerHTML = `
    <div class="modal-box modal-sm modal-tall">
      <div class="modal-hdr"><span>${isNew ? 'Add Penalty Rate' : 'Edit Penalty Rate'}</span></div>
      <div class="modal-body">
        <div class="form-grid">
          <div class="form-field">
            <label class="form-lbl">Penalty Type <span class="col-red">*</span></label>
            <select id="awpen-type" class="form-input">
              ${penTypes.length
                ? penTypes.map(p => `<option value="${esc(p.code)}" ${r.penalty_type===p.code?'selected':''}>${esc(p.label)}</option>`).join('')
                : `<option>Saturday</option><option>Sunday</option><option>PublicHoliday</option>
                   <option>Overtime_1_5</option><option>Overtime_2_0</option><option>CasualLoading</option>`}
            </select>
          </div>
          <div class="form-field">
            <label class="form-lbl">Multiplier <span class="col-red">*</span></label>
            <input id="awpen-mult" class="form-input" type="number" step="0.01" min="0.01" value="${r.multiplier||1.5}">
          </div>
          <div class="form-field form-field-full">
            <label class="form-lbl">Classification <span class="col-ink3">(leave blank = applies to all)</span></label>
            <select id="awpen-cls" class="form-input">
              <option value="">\u2014 All Classifications \u2014</option>
              ${clss.map(c => `<option value="${c.id}" ${r.classification_id===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}
            </select>
          </div>
          <div class="form-field form-field-full">
            <label class="form-lbl">Description</label>
            <input id="awpen-desc" class="form-input" value="${esc(r.description||'')}">
          </div>
          <div class="form-field">
            <label class="form-lbl">Effective Date</label>
            <input id="awpen-effdate" class="form-input" type="date" value="${r.effective_date||''}">
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="_awPenSave(${penId||'null'})">Save</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
}

async function _awPenSave(penId) {
  const penType   = document.getElementById('awpen-type')?.value;
  const mult      = parseFloat(document.getElementById('awpen-mult')?.value);
  if (!penType || !mult) { alert('Penalty type and multiplier are required.'); return; }
  const clsRaw    = document.getElementById('awpen-cls')?.value;
  const data = {
    award_id:          _awCurrent.id,
    penalty_type:      penType,
    multiplier:        mult,
    classification_id: clsRaw ? parseInt(clsRaw) : null,
    description:       document.getElementById('awpen-desc')?.value.trim() || null,
    effective_date:    document.getElementById('awpen-effdate')?.value || null,
    is_active:         1,
  };
  try {
    if (penId) {
      await _pPut(`/api/payroll/penalties/${penId}`, data);
    } else {
      await _pPost(`/api/payroll/awards/${_awCurrent.id}/penalties`, data);
    }
    document.getElementById('aw-pen-overlay')?.remove();
    await _awLoadTab('penalties');
  } catch(e) {
    alert('Save failed: ' + e.message);
  }
}

async function _awPenDelete(penId) {
  if (!confirm('Delete this penalty rate?')) return;
  try {
    await _pDel(`/api/payroll/penalties/${penId}`);
    await _awLoadTab('penalties');
  } catch(e) {
    alert('Delete failed: ' + e.message);
  }
}

// ── Award form (create / edit) ─────────────────────────────────────────────────

async function _awFormOpen(awardId) {
  const meta = _awMeta || {};
  const instrumentTypes = meta.instrument_types || ['Modern Award','Enterprise Agreement','Common Law Contract'];
  let a = { instrument_type: 'Modern Award', is_active: 1 };
  if (awardId) {
    a = await apiFetch(`/api/payroll/awards/${awardId}`).catch(() => a);
  }
  const isNew = !awardId;

  const overlay = document.createElement('div');
  overlay.id = 'aw-form-overlay';
  overlay.className = 'modal-bd';
  overlay.style.display = 'flex';
  overlay.innerHTML = `
    <div class="modal-box modal-md modal-tall">
      <div class="modal-hdr"><span>${isNew ? 'New Award / Agreement' : 'Edit Award'}</span></div>
      <div class="modal-body">
        <div class="form-grid">
          <div class="form-field form-field-full">
            <label class="form-lbl">Name <span class="col-red">*</span></label>
            <input id="awfrm-name" class="form-input" value="${esc(a.name||'')}"
              placeholder="e.g. Retail Industry Award 2020">
          </div>
          <div class="form-field">
            <label class="form-lbl">Instrument Type</label>
            <select id="awfrm-type" class="form-input">
              ${instrumentTypes.map(t => `<option ${a.instrument_type===t?'selected':''}>${esc(t)}</option>`).join('')}
            </select>
          </div>
          <div class="form-field">
            <label class="form-lbl">Code <span class="col-ink3">(e.g. MA000020)</span></label>
            <input id="awfrm-code" class="form-input" value="${esc(a.code||'')}">
          </div>
          <div class="form-field form-field-full">
            <label class="form-lbl">Industry / Sector</label>
            <input id="awfrm-industry" class="form-input" value="${esc(a.industry||'')}">
          </div>
          <div class="form-field">
            <label class="form-lbl">Effective Date</label>
            <input id="awfrm-effdate" class="form-input" type="date" value="${a.effective_date||''}">
          </div>
          <div class="form-field">
            <label class="form-lbl">Expiry Date</label>
            <input id="awfrm-expiry" class="form-input" type="date" value="${a.expiry_date||''}">
          </div>
          <div class="form-field">
            <label class="form-lbl">Nominal Expiry <span class="col-ink3">(EAs)</span></label>
            <input id="awfrm-nominal" class="form-input" type="date" value="${a.nominal_expiry||''}">
          </div>
          <div class="form-field">
            <label class="form-lbl">FWC Reference</label>
            <input id="awfrm-fwc" class="form-input" value="${esc(a.fwc_reference||'')}">
          </div>
          <div class="form-field">
            <label class="form-lbl">Employer Name <span class="col-ink3">(EAs)</span></label>
            <input id="awfrm-employer" class="form-input" value="${esc(a.employer_name||'')}">
          </div>
          <div class="form-field">
            <label class="form-lbl">Bargaining Agent</label>
            <input id="awfrm-agent" class="form-input" value="${esc(a.bargaining_agent||'')}">
          </div>
          <div class="form-field form-field-full">
            <label class="form-lbl">Notes</label>
            <textarea id="awfrm-notes" class="form-input" rows="3">${esc(a.notes||'')}</textarea>
          </div>
          <div class="form-field form-field-check">
            <input type="checkbox" id="awfrm-active" ${a.is_active ? 'checked' : ''}>
            <label for="awfrm-active" class="form-lbl">Active</label>
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="_awFormSave(${awardId||'null'})">Save</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
}

async function _awFormSave(awardId) {
  const name = document.getElementById('awfrm-name')?.value.trim();
  if (!name) { alert('Award name is required.'); return; }
  const data = {
    name,
    instrument_type:  document.getElementById('awfrm-type')?.value || 'Modern Award',
    code:             document.getElementById('awfrm-code')?.value.trim() || null,
    industry:         document.getElementById('awfrm-industry')?.value.trim() || null,
    effective_date:   document.getElementById('awfrm-effdate')?.value || null,
    expiry_date:      document.getElementById('awfrm-expiry')?.value || null,
    nominal_expiry:   document.getElementById('awfrm-nominal')?.value || null,
    fwc_reference:    document.getElementById('awfrm-fwc')?.value.trim() || null,
    employer_name:    document.getElementById('awfrm-employer')?.value.trim() || null,
    bargaining_agent: document.getElementById('awfrm-agent')?.value.trim() || null,
    notes:            document.getElementById('awfrm-notes')?.value.trim() || null,
    is_active:        document.getElementById('awfrm-active')?.checked ? 1 : 0,
  };
  try {
    let newId;
    if (awardId) {
      await _pPut(`/api/payroll/awards/${awardId}`, data);
      newId = awardId;
    } else {
      const res = await _pPost('/api/payroll/awards', data);
      newId = res.id;
    }
    document.getElementById('aw-form-overlay')?.remove();
    // Refresh and re-select the saved award
    [_awAll] = await Promise.all([
      apiFetch('/api/payroll/awards?active_only=0').catch(() => apiFetch('/api/payroll/awards')),
    ]);
    _awAll = _awAll || [];
    _awCurrent = null;
    _renderAwardsPage();
    if (newId) await _awSelect(newId);
  } catch(e) {
    alert('Save failed: ' + e.message);
  }
}

async function _awDelete(awardId) {
  const emp = await apiFetch(`/api/payroll/awards/${awardId}/employees`).catch(() => []);
  if (emp && emp.length > 0) {
    alert(`Cannot delete: ${emp.length} employee(s) are linked to this award.\nReassign them first.`);
    return;
  }
  if (!confirm('Deactivate this award? It will be hidden from the list (use "Show inactive" to restore).')) return;
  try {
    await _pDel(`/api/payroll/awards/${awardId}`);
    _awCurrent = null;
    await _prLoadAwards();
  } catch(e) {
    alert('Delete failed: ' + e.message);
  }
}

// ── Bulk Wage Increase dialog ──────────────────────────────────────────────────

function _awWageIncreaseOpen() {
  if (!_awCurrent) return;
  // Default effective date to 1 July this year (common Australian wage review date)
  const now   = new Date();
  const july1 = `${now.getMonth() >= 6 ? now.getFullYear() : now.getFullYear()}-07-01`;

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box modal-xs modal-tall">
      <div class="modal-hdr">
        <span>📈 Bulk Wage Increase</span>
      </div>
      <div class="modal-body">
        <p class="pr-hint-sm" style="margin:0 0 14px">
          Creates new pay rate rows for every classification in
          <strong>${esc(_awCurrent.name)}</strong> based on the most recent
          existing rate. Duplicate rows (same classification + pay point + date)
          are silently skipped.
        </p>
        <div class="form-grid form-grid-1">
          <div class="form-field">
            <label class="form-lbl">Effective Date *</label>
            <input id="awwi-date" class="form-input" type="date" value="${july1}">
          </div>
          <div class="form-field">
            <label class="form-lbl">Increase % *</label>
            <input id="awwi-pct" class="form-input" type="number" step="0.01" min="0.01"
                   placeholder="e.g. 3.75">
          </div>
          <div class="form-field">
            <label class="form-lbl">Source Note</label>
            <input id="awwi-note" class="form-input" placeholder="e.g. Annual Wage Review 2025–26">
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary btn-sm" id="awwi-apply-btn" onclick="_awWageIncreaseApply()">Apply Increase</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
}

async function _awWageIncreaseApply() {
  const effDate = document.getElementById('awwi-date')?.value;
  const pct     = parseFloat(document.getElementById('awwi-pct')?.value);
  const note    = document.getElementById('awwi-note')?.value.trim();
  if (!effDate || !pct || pct <= 0) {
    alert('Effective date and a positive increase % are required.'); return;
  }
  const btn = document.getElementById('awwi-apply-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Applying…'; }
  try {
    const res = await _pPost(`/api/payroll/awards/${_awCurrent.id}/wage-increase`, {
      effective_date:   effDate,
      increase_percent: pct,
      source_note:      note || `Annual Wage Review ${pct}% from ${effDate}`,
    });
    document.getElementById('awwi-apply-btn')?.closest('.modal-bd')?.remove();
    alert(`✓ Wage increase applied.\n${res.rows_created} new pay rate row(s) created.`);
    // Reload current tab to show new rates
    if (_awTab === 'classifications') await _awLoadTab('classifications');
  } catch(e) {
    alert('Failed: ' + e.message);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Apply Increase'; }
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  Stage 5N — PAYG Tax Rates Editor
//  Left panel: FY year list  |  Right panel: tabbed rate editor + test calc
// ══════════════════════════════════════════════════════════════════════════════

let _pgYears   = [];        // [{fy_year, label, notes, updated_at}, ...]
let _pgCurrent = null;      // full rate dict for selected year (null = none selected)
let _pgTab     = 'brackets'; // 'brackets' | 'medicare' | 'lito' | 'help' | 'sapto'
let _pgDirty   = false;     // unsaved changes flag

// ── Built-in 2024-25 defaults (mirrors payroll.py _BUILTIN_* constants) ──────
const _PG_DEFAULTS_2025 = {
  fy_year: 2025,
  label: '2024-25',
  notes: 'ATO Schedule 1 — Stage 3 tax cuts. NAT 1004 published 17 June 2024.',
  brackets: [
    [0, 0.00, 0.000],
    [18200, 0.00, 0.160],
    [45000, 4288.00, 0.300],
    [135000, 31288.00, 0.370],
    [190000, 51638.00, 0.450],
  ],
  brackets_no_thresh: [
    [0, 0.00, 0.160],
    [45000, 7200.00, 0.300],
    [135000, 34200.00, 0.370],
    [190000, 54550.00, 0.450],
  ],
  medicare: {
    full_rate: 0.020, full_start: 27222.0,
    shade_in_start: 21778.0, shade_in_rate: 0.100,
  },
  lito: [
    [37500, 700.0, 0.000],
    [45000, 700.0, 0.050],
    [66667, 325.0, 0.015],
    [999999, 0.0, 0.000],
  ],
  lito_no_thresh: [],
  help: [
    [0, 0.0000], [54435, 0.0100], [62851, 0.0200], [66621, 0.0250],
    [70619, 0.0300], [74856, 0.0350], [79347, 0.0400], [84108, 0.0450],
    [89155, 0.0500], [94504, 0.0550], [100175, 0.0600], [106186, 0.0650],
    [112557, 0.0700], [119310, 0.0750], [126468, 0.0800], [134057, 0.0850],
    [142101, 0.0900], [150627, 0.0950], [159664, 0.1000],
  ],
  help_method: 'whole',
  sapto: {
    single_max: 2230.0, single_shade_start: 32279.0,
    couple_max: 1602.0, couple_shade_start: 28974.0,
    shade_rate: 0.125,
  },
  no_tfn_rate: 0.47,
};

async function _prLoadPaygRates() {
  _prView = 'payg_rates';
  const mc = document.getElementById('module-content');
  mc.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    _pgYears = await apiFetch('/api/payroll/payg-rates');
    _pgYears = _pgYears || [];
    _renderPaygPage();
  } catch(e) {
    mc.innerHTML = `<div class="state-error">Failed to load PAYG rates: ${esc(e.message)}</div>`;
  }
}

function _renderPaygPage() {
  const mc = document.getElementById('module-content');
  mc.innerHTML = `
    <div class="inv-page">
      <div class="inv-toolbar">
        <h2 class="pg-toolbar-title">🧮 PAYG Tax Rates</h2>
        <div class="pg-toolbar-actions">
          <button class="btn btn-primary" onclick="_pgNewYear()">+ New FY</button>
          <button class="btn btn-outline" onclick="_prLoadEmployees()">← Employees</button>
        </div>
      </div>

      <div class="pg-page-layout">

        <!-- Left: FY year list -->
        <div class="pg-sidebar">
          ${_pgYears.length === 0
            ? `<div class="pg-sidebar-empty">
                 <div class="pg-sidebar-empty-icon">🧮</div>
                 <div class="pg-sidebar-empty-msg">No custom rates saved.<br>Using built-in ATO defaults.</div>
               </div>`
            : _pgYears.map(y => `
              <div onclick="_pgSelect(${y.fy_year})"
                   class="pg-year-card${_pgCurrent && _pgCurrent.fy_year === y.fy_year ? ' is-selected' : ''}">
                <div class="pg-year-label">FY ${esc(y.label || y.fy_year)}</div>
                <div class="pg-year-updated">
                  ${y.updated_at ? 'Updated ' + y.updated_at.slice(0,10) : ''}
                </div>
              </div>`).join('')
          }
          <button class="pg-load-defaults-btn" onclick="_pgLoadDefaults()">
            ⬇ Load 2024-25 defaults
          </button>
        </div>

        <!-- Right: detail panel -->
        <div class="pg-detail-panel">
          ${_pgCurrent ? _renderPaygDetail() : `
            <div class="pg-empty-panel">
              <div class="pg-empty-panel-arrow">←</div>
              <div class="pg-empty-panel-msg">Select a FY year to edit, or load defaults</div>
            </div>`}
        </div>

      </div>
    </div>`;
}

async function _pgSelect(fyYear) {
  try {
    _pgCurrent = await apiFetch(`/api/payroll/payg-rates/${fyYear}`);
  } catch(e) {
    _pgCurrent = _pgYears.find(y => y.fy_year === fyYear) || null;
  }
  _pgTab   = 'brackets';
  _pgDirty = false;
  _renderPaygPage();
}

function _pgLoadDefaults() {
  if (!_pgCurrent) {
    alert('Select a FY year first, then click Load Defaults.');
    return;
  }
  // Preserve the selected year — only load the rate values from built-in defaults
  const fyInt = _pgCurrent.fy_year;
  const prev  = fyInt - 1;
  _pgCurrent = Object.assign(
    JSON.parse(JSON.stringify(_PG_DEFAULTS_2025)),
    { fy_year: fyInt, label: `${prev}-${String(fyInt).slice(2)}` }
  );
  _pgTab   = 'brackets';
  _pgDirty = true;
  _renderPaygPage();
}

function _pgNewYear() {
  const fy = prompt('FY year (e.g. 2026 for FY 2025-26):');
  if (!fy || isNaN(parseInt(fy))) return;
  const fyInt = parseInt(fy);
  const prev  = fyInt - 1;
  _pgCurrent = {
    fy_year: fyInt,
    label: `${prev}-${String(fyInt).slice(2)}`,
    notes: '',
    brackets: [], brackets_no_thresh: [],
    medicare: { full_rate: 0.020, full_start: 27222.0, shade_in_start: 21778.0, shade_in_rate: 0.100 },
    lito: [], lito_no_thresh: [],
    help: [], help_method: 'whole',
    sapto: { single_max: 2230.0, single_shade_start: 32279.0, couple_max: 1602.0, couple_shade_start: 28974.0, shade_rate: 0.125 },
    no_tfn_rate: 0.47,
  };
  _pgTab   = 'brackets';
  _pgDirty = true;
  _renderPaygPage();
}

function _renderPaygDetail() {
  const r = _pgCurrent;
  const tabs = [
    { id: 'brackets', label: 'Income Tax' },
    { id: 'medicare', label: 'Medicare' },
    { id: 'lito',     label: 'LITO' },
    { id: 'help',     label: 'HELP/Study' },
    { id: 'sapto',    label: 'SAPTO' },
    { id: 'calc',     label: '🧮 Test Calc' },
  ];
  return `
    <!-- Header -->
    <div class="pg-detail-hdr">
      <div>
        <div class="pg-detail-title">FY ${esc(r.label || r.fy_year)}</div>
        <div class="pg-detail-notes">${esc(r.notes || '')}</div>
      </div>
      <div class="pg-detail-actions">
        ${_pgDirty ? `<span class="pg-unsaved">Unsaved changes</span>` : ''}
        <button class="btn btn-primary" onclick="_pgSave()">💾 Save</button>
        <button class="btn btn-outline pg-btn-delete"
                onclick="_pgDelete(${r.fy_year})">Delete</button>
      </div>
    </div>

    <!-- Tabs -->
    <div class="pg-tab-bar">
      ${tabs.map(t => `
        <button onclick="_pgSetTab('${t.id}')"
                class="pg-tab-btn${_pgTab===t.id?' is-active':''}">
          ${t.label}
        </button>`).join('')}
    </div>

    <!-- Tab content -->
    <div class="pg-tab-content" id="pg-tab-content">
      ${_renderPaygTabContent()}
    </div>`;
}

function _pgSetTab(tab) {
  // Flush edits from current tab before switching
  _pgFlushTab();
  _pgTab = tab;
  const el = document.getElementById('pg-tab-content');
  if (el) el.innerHTML = _renderPaygTabContent();
}

function _renderPaygTabContent() {
  const r = _pgCurrent;
  if (_pgTab === 'brackets') return _pgBracketsHtml(r);
  if (_pgTab === 'medicare') return _pgMedicareHtml(r);
  if (_pgTab === 'lito')     return _pgLitoHtml(r);
  if (_pgTab === 'help')     return _pgHelpHtml(r);
  if (_pgTab === 'sapto')    return _pgSaptoHtml(r);
  if (_pgTab === 'calc')     return _pgCalcHtml(r);
  return '';
}

// ── Tab renderers ─────────────────────────────────────────────────────────────

function _pgBracketsHtml(r) {
  const note = `<p class="pg-note">
    Income tax brackets (with tax-free threshold). Each row: <b>Income from ($)</b>,
    <b>Base tax ($)</b>, <b>Marginal rate</b>.</p>`;
  const noteNT = `<p class="pg-note-mt">
    Scale 4 — no tax-free threshold. Used when employee has not claimed threshold.</p>`;
  return note
    + _pgBracketTable('pg-brackets', r.brackets || [], ['Income from ($)', 'Base tax ($)', 'Marginal rate'])
    + `<div class="pg-section-title">No-threshold brackets</div>`
    + noteNT
    + _pgBracketTable('pg-brackets-nt', r.brackets_no_thresh || [], ['Income from ($)', 'Base tax ($)', 'Marginal rate'])
    + `<div class="pg-no-tfn-row">
         <label>No-TFN withholding rate:&nbsp;
           <input id="pg-no-tfn" type="number" step="0.01" min="0" max="1"
                  value="${r.no_tfn_rate ?? 0.47}"
                  class="pg-inp-sm">
         </label>
       </div>`;
}

function _pgBracketTable(id, rows, headers) {
  return `
    <table id="${id}" class="pg-bracket-tbl">
      <thead><tr>${headers.map(h => `<th class="pg-bracket-th">${h}</th>`).join('')}
        <th class="pg-bracket-th pg-bracket-th-del"></th></tr></thead>
      <tbody>
        ${rows.map((row, i) => `<tr>
          ${row.map((v, j) => `<td class="pg-bracket-td">
            <input type="number" step="any" value="${v}"
                   data-row="${i}" data-col="${j}"
                   class="pg-bracket-inp">
          </td>`).join('')}
          <td><button onclick="_pgRemoveRow('${id}',${i})"
                      class="pg-bracket-del">×</button></td>
        </tr>`).join('')}
      </tbody>
    </table>
    <button onclick="_pgAddRow('${id}')" class="pg-add-row-btn">+ Add row</button>`;
}

function _pgMedicareHtml(r) {
  const m = r.medicare || {};
  const f = (id, label, val) => `
    <div class="pg-field">
      <label class="pg-field-lbl">${label}</label>
      <input id="${id}" type="number" step="any" value="${val ?? ''}"
             class="pg-inp-wide">
    </div>`;
  return `<p class="pg-note pg-note--med">
    Medicare levy parameters. <b>Full rate</b> applies above <b>Full start</b>.
    Between shade-in start and full start, only the <b>shade-in rate</b> applies on the excess.</p>
    ${f('pg-med-full-rate',   'Full levy rate (e.g. 0.020 = 2%)',      m.full_rate)}
    ${f('pg-med-full-start',  'Full levy threshold ($)',                 m.full_start)}
    ${f('pg-med-shade-start', 'Shade-in start ($)',                     m.shade_in_start)}
    ${f('pg-med-shade-rate',  'Shade-in rate (e.g. 0.10 = 10%)',       m.shade_in_rate)}`;
}

function _pgLitoHtml(r) {
  const note = `<p class="pg-note">
    Low Income Tax Offset bands. Each row: <b>Income up to ($)</b>,
    <b>Max offset ($)</b>, <b>Reduction rate above previous ceiling</b>.</p>`;
  const noteNT = `<p class="pg-note-mt">
    LITO for no-threshold employees (usually empty — ATO Schedule 1 grants no LITO
    without the tax-free threshold).</p>`;
  return note
    + _pgBracketTable('pg-lito', r.lito || [], ['Income up to ($)', 'Max offset ($)', 'Reduction rate'])
    + `<div class="pg-section-title">No-threshold LITO</div>`
    + noteNT
    + _pgBracketTable('pg-lito-nt', r.lito_no_thresh || [], ['Income up to ($)', 'Max offset ($)', 'Reduction rate']);
}

function _pgHelpHtml(r) {
  const note = `<p class="pg-note">
    HELP / VSL / SSL repayment thresholds. Each row: <b>Income from ($)</b>, <b>Rate</b>.</p>`;
  const mSel = `<div class="pg-help-method-row">
    <label>Calculation method:&nbsp;
      <select id="pg-help-method" class="pg-sel-sm">
        <option value="whole"    ${(r.help_method||'whole')==='whole'    ? 'selected':''}>whole-income (2024-25 and earlier)</option>
        <option value="marginal" ${(r.help_method||'whole')==='marginal' ? 'selected':''}>marginal (2025-26+, Universities Accord)</option>
      </select>
    </label>
  </div>`;
  return note + mSel
    + _pgBracketTable('pg-help', r.help || [], ['Income from ($)', 'Rate']);
}

function _pgSaptoHtml(r) {
  const s = r.sapto || {};
  const f = (id, label, val) => `
    <div class="pg-field">
      <label class="pg-field-lbl">${label}</label>
      <input id="${id}" type="number" step="any" value="${val ?? ''}"
             class="pg-inp-wide">
    </div>`;
  return `<p class="pg-note">
    Senior Australians and Pensioners Tax Offset. Applies when the employee is a
    senior or pensioner. Shades out at <b>shade rate</b> per $1 over the threshold.</p>
    ${f('pg-sapto-single-max',   'Single — max offset ($)',            s.single_max)}
    ${f('pg-sapto-single-shade', 'Single — shade-in start ($)',        s.single_shade_start)}
    ${f('pg-sapto-couple-max',   'Couple — max offset ($)',            s.couple_max)}
    ${f('pg-sapto-couple-shade', 'Couple — shade-in start ($)',        s.couple_shade_start)}
    ${f('pg-sapto-shade-rate',   'Shade-out rate (e.g. 0.125 = 12.5%)', s.shade_rate)}`;
}

function _pgCalcHtml(r) {
  return `
    <div class="pg-calc-wrap">
      <p class="pg-note">
        Test withholding calculation using the rates for FY ${esc(r.label || r.fy_year)}.
        If these rates are saved in the DB they will be used; otherwise built-in defaults apply.</p>

      <div class="pg-calc-grid">
        <div>
          <label class="pg-calc-lbl">Period earnings ($)</label>
          <input id="pgc-gross" type="number" step="0.01" min="0" placeholder="e.g. 3000"
                 class="pg-inp-full">
        </div>
        <div>
          <label class="pg-calc-lbl">Frequency</label>
          <select id="pgc-freq" class="pg-sel-full">
            <option>Fortnightly</option><option>Weekly</option><option>Monthly</option>
          </select>
        </div>
      </div>

      <div class="pg-calc-checks">
        <label><input type="checkbox" id="pgc-threshold" checked>&nbsp;Tax-free threshold claimed</label>
        <label><input type="checkbox" id="pgc-tfn" checked>&nbsp;TFN provided</label>
        <label><input type="checkbox" id="pgc-help">&nbsp;HELP / study loan</label>
        <label><input type="checkbox" id="pgc-senior">&nbsp;Senior / pensioner</label>
        <label><input type="checkbox" id="pgc-couple">&nbsp;Senior couple</label>
        <label><input type="checkbox" id="pgc-foreign">&nbsp;Foreign resident</label>
      </div>

      <div class="pg-calc-medicare-row">
        <label>Medicare exemption:&nbsp;
          <select id="pgc-medicare" class="pg-sel-sm">
            <option value="none">None</option>
            <option value="full">Full exemption</option>
            <option value="half">Half exemption</option>
          </select>
        </label>
      </div>

      <button class="btn btn-primary" onclick="_pgRunCalc()">Calculate</button>

      <div id="pgc-result" class="mt-8"></div>
    </div>`;
}

// ── Table mutation helpers ────────────────────────────────────────────────────

function _pgAddRow(tableId) {
  _pgFlushTab();
  const key = _pgTableKey(tableId);
  if (!key) return;
  const cols = (_pgCurrent[key] && _pgCurrent[key][0]) ? _pgCurrent[key][0].length : 3;
  _pgCurrent[key].push(Array(cols).fill(0));
  _pgDirty = true;
  const el = document.getElementById('pg-tab-content');
  if (el) el.innerHTML = _renderPaygTabContent();
}

function _pgRemoveRow(tableId, rowIdx) {
  _pgFlushTab();
  const key = _pgTableKey(tableId);
  if (!key) return;
  _pgCurrent[key].splice(rowIdx, 1);
  _pgDirty = true;
  const el = document.getElementById('pg-tab-content');
  if (el) el.innerHTML = _renderPaygTabContent();
}

function _pgTableKey(tableId) {
  const map = {
    'pg-brackets':    'brackets',
    'pg-brackets-nt': 'brackets_no_thresh',
    'pg-lito':        'lito',
    'pg-lito-nt':     'lito_no_thresh',
    'pg-help':        'help',
  };
  return map[tableId] || null;
}

// Read current tab's input values back into _pgCurrent
function _pgFlushTab() {
  if (!_pgCurrent) return;
  const r = _pgCurrent;

  // Flush bracket tables (generic — reads data-row/data-col)
  ['pg-brackets', 'pg-brackets-nt', 'pg-lito', 'pg-lito-nt', 'pg-help'].forEach(tid => {
    const tbl = document.getElementById(tid);
    if (!tbl) return;
    const key = _pgTableKey(tid);
    if (!key) return;
    const inputs = tbl.querySelectorAll('input[data-row]');
    const rebuilt = [];
    inputs.forEach(inp => {
      const row = parseInt(inp.dataset.row);
      const col = parseInt(inp.dataset.col);
      if (!rebuilt[row]) rebuilt[row] = [];
      rebuilt[row][col] = parseFloat(inp.value) || 0;
    });
    if (rebuilt.length) r[key] = rebuilt;
  });

  // Medicare
  const mfr = document.getElementById('pg-med-full-rate');
  if (mfr) r.medicare = {
    full_rate:       parseFloat(document.getElementById('pg-med-full-rate')?.value)  || r.medicare?.full_rate,
    full_start:      parseFloat(document.getElementById('pg-med-full-start')?.value) || r.medicare?.full_start,
    shade_in_start:  parseFloat(document.getElementById('pg-med-shade-start')?.value)|| r.medicare?.shade_in_start,
    shade_in_rate:   parseFloat(document.getElementById('pg-med-shade-rate')?.value) || r.medicare?.shade_in_rate,
  };

  // LITO no-tfn rate
  const ntfn = document.getElementById('pg-no-tfn');
  if (ntfn) r.no_tfn_rate = parseFloat(ntfn.value) || r.no_tfn_rate;

  // HELP method
  const hm = document.getElementById('pg-help-method');
  if (hm) r.help_method = hm.value;

  // SAPTO
  const sm = document.getElementById('pg-sapto-single-max');
  if (sm) r.sapto = {
    single_max:          parseFloat(document.getElementById('pg-sapto-single-max')?.value)   || r.sapto?.single_max,
    single_shade_start:  parseFloat(document.getElementById('pg-sapto-single-shade')?.value) || r.sapto?.single_shade_start,
    couple_max:          parseFloat(document.getElementById('pg-sapto-couple-max')?.value)   || r.sapto?.couple_max,
    couple_shade_start:  parseFloat(document.getElementById('pg-sapto-couple-shade')?.value) || r.sapto?.couple_shade_start,
    shade_rate:          parseFloat(document.getElementById('pg-sapto-shade-rate')?.value)   || r.sapto?.shade_rate,
  };
}

// ── Save / Delete ─────────────────────────────────────────────────────────────

async function _pgSave() {
  if (!_pgCurrent) return;
  _pgFlushTab();
  try {
    await _pPost('/api/payroll/payg-rates', _pgCurrent);
    _pgDirty = false;
    _pgYears = await apiFetch('/api/payroll/payg-rates');
    // Reload the saved data so the UI reflects what's in the DB
    _pgCurrent = await apiFetch(`/api/payroll/payg-rates/${_pgCurrent.fy_year}`);
    _renderPaygPage();
  } catch(e) {
    alert('Save failed: ' + e.message);
  }
}

async function _pgDelete(fyYear) {
  if (!confirm(`Delete custom rates for FY ${fyYear}?\nThe built-in ATO defaults will be used instead.`)) return;
  try {
    await _pDel(`/api/payroll/payg-rates/${fyYear}`);
    _pgCurrent = null;
    _pgYears   = await apiFetch('/api/payroll/payg-rates');
    _pgDirty   = false;
    _renderPaygPage();
  } catch(e) {
    alert('Delete failed: ' + e.message);
  }
}

// ── Test calculator ───────────────────────────────────────────────────────────

async function _pgRunCalc() {
  const gross = parseFloat(document.getElementById('pgc-gross')?.value);
  if (!gross || gross <= 0) { alert('Enter a valid period earnings amount.'); return; }
  const payload = {
    gross_period:       gross,
    frequency:          document.getElementById('pgc-freq')?.value || 'Fortnightly',
    fy_year:            _pgCurrent?.fy_year || null,
    has_threshold:      document.getElementById('pgc-threshold')?.checked ?? true,
    has_tfn:            document.getElementById('pgc-tfn')?.checked ?? true,
    has_study_loan:     document.getElementById('pgc-help')?.checked ?? false,
    is_senior:          document.getElementById('pgc-senior')?.checked ?? false,
    senior_couple:      document.getElementById('pgc-couple')?.checked ?? false,
    is_foreign_resident:document.getElementById('pgc-foreign')?.checked ?? false,
    medicare_exemption: document.getElementById('pgc-medicare')?.value || 'none',
  };
  const btn = document.querySelector('[onclick="_pgRunCalc()"]');
  if (btn) { btn.disabled = true; btn.textContent = 'Calculating…'; }
  try {
    const res = await _pPost('/api/payroll/payg-rates/calculate', payload);
    document.getElementById('pgc-result').innerHTML = `
      <div class="pg-calc-result">
        <div class="pg-calc-result-grid">
          <div class="pg-calc-result-lbl">Period withholding</div>
          <div class="pg-calc-result-val--bold">−${fmt(res.withholding)}</div>
          <div class="pg-calc-result-lbl">Annual gross</div>
          <div class="pg-calc-result-val">${fmt(res.annual_gross)}</div>
          <div class="pg-calc-result-lbl">Annual withholding</div>
          <div class="pg-calc-result-val--red">${fmt(res.annual_wh)}</div>
          <div class="pg-calc-result-lbl">Effective rate</div>
          <div class="pg-calc-result-val">${res.effective_rate}%</div>
        </div>
      </div>`;
  } catch(e) {
    document.getElementById('pgc-result').innerHTML =
      `<div class="pg-calc-error">Error: ${esc(e.message)}</div>`;
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Calculate'; }
  }
}


// ═══════════════════════════════════════════════════════════════════════════
//  Stage 5O — PAYG Payment Summaries
// ═══════════════════════════════════════════════════════════════════════════

let _psAll    = [];   // full summary list for selected FY
let _psFyYear = null; // currently selected fy_year integer

async function _prLoadPaymentSummaries() {
  _prView = 'payment_summaries';
  const mc = document.getElementById('module-content');
  mc.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    // Default FY: current_fy() equivalent — use current year if past June, else prior year.
    if (!_psFyYear) {
      const now = new Date();
      _psFyYear = now.getMonth() >= 6 ? now.getFullYear() + 1 : now.getFullYear();
    }
    await _psRefresh();
  } catch (e) {
    mc.innerHTML = `<div class="state-error">Failed to load payment summaries: ${esc(e.message)}</div>`;
  }
}

async function _psRefresh() {
  _psAll = await apiFetch(`/api/payroll/payment-summaries?fy_year=${_psFyYear}`).catch(() => []);
  _psAll = _psAll || [];
  _renderPaymentSummariesPage();
}

function _renderPaymentSummariesPage() {
  const mc = document.getElementById('module-content');
  const fyLabel = `FY ${_psFyYear - 1}–${String(_psFyYear).slice(2)}`;

  // Build FY year options: current FY back 5 years
  const now = new Date();
  const latestFy = now.getMonth() >= 6 ? now.getFullYear() + 1 : now.getFullYear();
  const fyOptions = [];
  for (let y = latestFy; y >= latestFy - 5; y--) {
    fyOptions.push(y);
  }

  const fmt = v => '$' + Number(v || 0).toLocaleString('en-AU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  const rows = _psAll.map(s => `
    <tr>
      <td>${esc(s.employee_name)}</td>
      <td>${esc(s.employment_type || '—')}</td>
      <td class="inv-amt">${fmt(s.gross_wages)}</td>
      <td class="inv-amt col-red">${fmt(s.payg_withheld)}</td>
      <td class="inv-amt">${fmt(s.super_employer)}</td>
      <td class="inv-amt">${fmt(s.salary_sacrifice_super)}</td>
      <td class="inv-amt">${fmt(s.allowances_total)}</td>
      <td class="pr-act-td">
        <button class="btn btn-sm btn-outline"
                onclick="_psDownloadPdf(${s.employee_id}, ${esc(JSON.stringify(s.employee_name))})"
                title="Download PDF for ${esc(s.employee_name)}">
          ⬇ PDF
        </button>
      </td>
    </tr>`).join('');

  const emptyState = _psAll.length === 0 ? `
    <tr><td colspan="8" class="pr-tbl-empty-lg">
      No finalised pay runs found for ${fyLabel}.<br>
      <small>Finalise at least one pay run in this financial year to generate summaries.</small>
    </td></tr>` : '';

  const totalGross = _psAll.reduce((s, r) => s + (r.gross_wages || 0), 0);
  const totalPayg  = _psAll.reduce((s, r) => s + (r.payg_withheld || 0), 0);

  mc.innerHTML = `
    <div class="inv-toolbar">
      <div class="ps-toolbar-lhs">
        <strong class="ps-title">PAYG Payment Summaries</strong>
        <select id="ps-fy-sel" class="inv-search ps-fy-sel"
                onchange="_psFyYear=parseInt(this.value);_psRefresh()">
          ${fyOptions.map(y =>
            `<option value="${y}" ${y === _psFyYear ? 'selected' : ''}>
              FY ${y-1}–${String(y).slice(2)}
            </option>`).join('')}
        </select>
      </div>
      <div class="pr-toolbar-actions">
        ${_psAll.length ? `
        <button class="btn btn-primary" onclick="_psDownloadBulkPdf()" title="Download all summaries as one PDF">
          ⬇ Bulk PDF
        </button>` : ''}
        <button class="btn btn-danger" onclick="_psResetYTD()" title="Reset all employee YTD accumulators to zero">
          Reset YTD
        </button>
        <button class="btn btn-outline" onclick="_prLoadEmployees()">← Employees</button>
      </div>
    </div>

    <div class="ps-legal-notice">
      Payment summaries must be provided to employees by 14 July each year.
      STP Phase 2 lodgements may replace the requirement to issue paper summaries — confirm with the ATO.
    </div>

    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        <th>Employee</th>
        <th>Type</th>
        <th class="th-r">Gross Wages</th>
        <th class="th-r">PAYG Withheld</th>
        <th class="th-r">Employer Super</th>
        <th class="th-r">Rep. Super</th>
        <th class="th-r">Allowances</th>
        <th class="th-r">PDF</th>
      </tr></thead><tbody>
        ${rows || emptyState}
      </tbody></table>
    </div></div>

    ${_psAll.length ? `
    <div class="ps-totals-bar">
      ${_psAll.length} employee${_psAll.length !== 1 ? 's' : ''}
      &nbsp;•&nbsp; Total Gross: ${fmt(totalGross)}
      &nbsp;•&nbsp; Total PAYG Withheld: ${fmt(totalPayg)}
    </div>` : ''}
  `;
}

async function _psDownloadPdf(employeeId, employeeName) {
  try {
    const url = `/api/payroll/payment-summaries/pdf?fy_year=${_psFyYear}&employee_id=${employeeId}`;
    const resp = await fetch(url);
    if (!resp.ok) {
      const j = await resp.json().catch(() => ({}));
      throw new Error(j.error || `HTTP ${resp.status}`);
    }
    const blob = await resp.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    const fyLabel = `${_psFyYear - 1}-${String(_psFyYear).slice(2)}`;
    a.download = `PAYG_Summary_${(employeeName || 'employee').replace(/\s+/g, '_')}_FY${fyLabel}.pdf`;
    a.click();
    URL.revokeObjectURL(a.href);
  } catch (e) {
    alert('PDF error: ' + e.message);
  }
}

async function _psDownloadBulkPdf() {
  const btn = document.querySelector('button[onclick="_psDownloadBulkPdf()"]');
  if (btn) { btn.disabled = true; btn.textContent = 'Generating…'; }
  try {
    const url = `/api/payroll/payment-summaries/pdf?fy_year=${_psFyYear}`;
    const resp = await fetch(url);
    if (!resp.ok) {
      const j = await resp.json().catch(() => ({}));
      throw new Error(j.error || `HTTP ${resp.status}`);
    }
    const blob = await resp.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    const fyLabel = `${_psFyYear - 1}-${String(_psFyYear).slice(2)}`;
    a.download = `PAYG_Summaries_FY${fyLabel}.pdf`;
    a.click();
    URL.revokeObjectURL(a.href);
  } catch (e) {
    alert('PDF error: ' + e.message);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '⬇ Bulk PDF'; }
  }
}

async function _psResetYTD() {
  const fyLabel = `FY${_psFyYear - 1}/${_psFyYear}`;
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box modal-xs">
    <div class="modal-hdr">Reset YTD Accumulators</div>
    <div class="modal-body">
      <p>Reset all employee YTD totals to zero?</p>
      <p>Do this <strong>after</strong> downloading ${fyLabel} payment summaries,
         at the start of the new financial year (1 July).</p>
      <p class="col-red" style="font-weight:600">This cannot be undone.</p>
    </div>
    <div class="modal-foot">
      <button class="btn btn-danger" id="ps-ytd-confirm">Reset YTD</button>
      <button class="btn btn-outline" onclick="this.closest('.modal-bd').remove()">Cancel</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  bd.querySelector('#ps-ytd-confirm').onclick = async () => {
    try {
      const r = await fetch('/api/payroll/reset-ytd', { method: 'POST' });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || 'Reset failed');
      bd.remove();
      toast('YTD accumulators reset to zero.');
      await _psRefresh();
    } catch (e) {
      alert('Reset error: ' + e.message);
    }
  };
}
