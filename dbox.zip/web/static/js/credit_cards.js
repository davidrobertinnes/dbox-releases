// ═══════════════════════════════════════════════════════════════════════════
// CREDIT CARDS PAGE
// ═══════════════════════════════════════════════════════════════════════════
let _ccCards=[], _ccSelectedCard=null, _ccTxns=[], _ccDateFrom='', _ccDateTo='', _ccSearch='';

async function pageCreditCards() {
  try {
    _ccCards = await apiFetch('/api/credit-cards') || [];
    renderCCPage();
    if(_ccCards.length) {
      if(!_ccSelectedCard || !_ccCards.find(c=>c.id===_ccSelectedCard))
        _ccSelectedCard=_ccCards[0].id;
      await loadCCTxns();
    }
  } catch(e) {
    document.getElementById('module-content').innerHTML=`<div class="state-error">Failed to load credit cards: ${esc(e.message)}</div>`;
  }
}

function renderCCPage() {
  const mc=document.getElementById('module-content');
  if(!_ccCards.length) {
    mc.innerHTML=`<div class="empty-state" style="padding:60px 20px;text-align:center">
      <div style="font-size:36px;margin-bottom:12px">💳</div>
      <div style="font-size:16px;font-weight:600;margin-bottom:8px">No Credit Card Accounts</div>
      <div style="font-size:13px;color:var(--ink3);margin-bottom:20px">Add a credit card account in the Accounts module first (Type: Liability, Subtype: Credit Card)</div>
    </div>`;
    return;
  }

  const card=_ccCards.find(c=>c.id===_ccSelectedCard)||_ccCards[0];
  const balColor=card.balance>0.005?'var(--red)':'var(--green)';

  mc.innerHTML=`
    <div style="display:flex;gap:12px;margin-bottom:16px;flex-wrap:wrap;align-items:flex-start">
      <div style="flex:1;min-width:200px">
        <label style="font-size:11px;color:var(--ink3);display:block;margin-bottom:6px">Card Account</label>
        <select class="edt-sel" id="cc-card-sel" onchange="ccSelectCard(parseInt(this.value))" style="width:100%">
          ${_ccCards.map(c=>`<option value="${c.id}"${c.id===_ccSelectedCard?' selected':''}>${esc((c.code?c.code+' ':'')+c.name)}</option>`).join('')}
        </select>
      </div>
      <div style="background:var(--panel);border-radius:8px;padding:12px 20px;text-align:center;min-width:160px">
        <div style="font-size:10px;text-transform:uppercase;letter-spacing:.08em;color:var(--ink3);margin-bottom:4px">Balance Owing</div>
        <div style="font-size:24px;font-family:'DM Mono',monospace;font-weight:700;color:${balColor}">${fmt(card.balance)}</div>
      </div>
      <div style="display:flex;gap:6px;align-self:flex-end;flex-wrap:wrap">
        <button class="btn btn-primary" onclick="ccRecordCharge()">+ Record Charge</button>
        <button class="btn btn-outline" onclick="ccRecordPayment()">💸 Make Payment</button>
      </div>
    </div>

    <div class="inv-toolbar" style="margin-bottom:10px">
      <input class="inv-search" id="cc-q" placeholder="Search description, reference, type…" value="${esc(_ccSearch)}"
        oninput="_ccSearch=this.value;renderCCTxns(true)">
    </div>

    <div style="display:flex;gap:10px;align-items:center;margin-bottom:12px;flex-wrap:wrap">
      <label style="font-size:12px;color:var(--ink3)">From</label>
      <input class="edt-inp" id="cc-from" type="date" value="${_ccDateFrom}" style="width:140px;padding:5px 8px"
        onchange="_ccDateFrom=this.value">
      <label style="font-size:12px;color:var(--ink3)">To</label>
      <input class="edt-inp" id="cc-to" type="date" value="${_ccDateTo}" style="width:140px;padding:5px 8px"
        onchange="_ccDateTo=this.value">
      <button class="btn btn-outline btn-sm" onclick="loadCCTxns()">Filter</button>
      <button class="btn btn-outline btn-sm" onclick="ccClearFilter()">Clear</button>
    </div>

    <div class="inv-list-panel"><div style="overflow-x:auto">
      <table class="inv-list-table"><thead><tr>
        <th>Date</th><th>Jnl#</th><th>Type</th><th>Reference</th>
        <th>Description</th><th class="r">Charge</th><th class="r">Payment</th><th class="r">Running</th>
      </tr></thead><tbody id="cc-txn-body">
        <tr><td colspan="8" style="text-align:center;padding:24px;color:var(--ink3)">Loading\u2026</td></tr>
      </tbody></table>
    </div></div>
    <div style="margin-top:8px" id="cc-summary"></div>`;
}

async function ccSelectCard(id) {
  _ccSelectedCard=id;
  _ccSearch='';
  await pageCreditCards();
}

async function loadCCTxns() {
  if(!_ccSelectedCard) return;
  const from=_ccDateFrom, to=_ccDateTo;
  let url=`/api/credit-cards/${_ccSelectedCard}/transactions`;
  const params=[];
  if(from) params.push(`from=${from}`);
  if(to)   params.push(`to=${to}`);
  if(params.length) url+='?'+params.join('&');

  try {
    _ccTxns=await apiFetch(url)||[];
    renderCCTxns();
  } catch(e){ toast(e.message,'err'); }
}

function renderCCTxns(restoreFocus) {
  const tbody=document.getElementById('cc-txn-body');
  const summary=document.getElementById('cc-summary');
  if(!tbody) return;

  const q=_ccSearch.trim().toLowerCase();
  const txns=q ? _ccTxns.filter(tx=>
    (tx.line_desc||tx.journal_desc||'').toLowerCase().includes(q) ||
    (tx.reference||'').toLowerCase().includes(q) ||
    (tx.entry_type||'').toLowerCase().includes(q) ||
    (tx.contact_name||'').toLowerCase().includes(q) ||
    String(tx.journal_id||'').includes(q)
  ) : _ccTxns;

  if(restoreFocus){ const qi=document.getElementById('cc-q'); if(qi){qi.focus();qi.setSelectionRange(qi.value.length,qi.value.length);} }

  if(!txns.length){
    tbody.innerHTML=`<tr><td colspan="8" style="text-align:center;padding:36px;color:var(--ink3);font-family:'DM Mono',monospace;font-size:12px">${_ccTxns.length?'No transactions match your search':'No transactions found'}</td></tr>`;
    if(summary) summary.innerHTML=q?`<span class="count-pill">0 of ${_ccTxns.length} transaction${_ccTxns.length!==1?'s':''}</span>`:'';
    return;
  }

  let running=0, totalCharge=0, totalPayment=0;
  tbody.innerHTML=txns.map((tx,i)=>{
    const charge=tx.credit>0?tx.credit:0;
    const payment=tx.debit>0?tx.debit:0;
    running+=charge-payment;
    totalCharge+=charge; totalPayment+=payment;
    const desc=tx.line_desc||tx.journal_desc||'';
    const isPayment=payment>0;
    const runColor=running>0.005?'color:var(--red)':'color:var(--green)';
    const suppLine=tx.contact_name?`<div style="font-size:11px;color:var(--ink3);margin-top:1px">${esc(tx.contact_name)}</div>`:'';
    return `<tr class="inv-row" style="${isPayment?'color:var(--green)':''};cursor:pointer"
        onclick="ccOpenTxn(${i})">
      <td><span class="inv-mono">${fmtDate(tx.entry_date)}</span></td>
      <td><span class="inv-mono" style="color:var(--ink3)">${tx.journal_id}</span></td>
      <td><span style="font-size:11px;color:var(--ink3)">${esc(tx.entry_type||'—')}</span></td>
      <td><span class="inv-mono" style="font-size:11px">${esc(tx.reference||'—')}</span></td>
      <td>${esc(desc)}${suppLine}</td>
      <td style="text-align:right"><span class="inv-mono" style="color:var(--red)">${charge>0.005?fmt(charge):'—'}</span></td>
      <td style="text-align:right"><span class="inv-mono" style="color:var(--green)">${payment>0.005?fmt(payment):'—'}</span></td>
      <td style="text-align:right"><span class="inv-mono" style="${runColor}">${fmt(running)}</span></td>
    </tr>`;
  }).join('');

  if(summary) summary.innerHTML=`
    <span class="count-pill">${txns.length}${q?' of '+_ccTxns.length:''} transaction${_ccTxns.length!==1?'s':''}</span>
    <span style="margin-left:12px;font-size:12px;color:var(--ink3)">
      Charges: <span style="font-family:'DM Mono',monospace;color:var(--red)">${fmt(totalCharge)}</span>
      &nbsp;&nbsp;Payments: <span style="font-family:'DM Mono',monospace;color:var(--green)">${fmt(totalPayment)}</span>
      &nbsp;&nbsp;Net: <span style="font-family:'DM Mono',monospace">${fmt(totalCharge-totalPayment)}</span>
    </span>`;
}

function ccClearFilter() {
  _ccDateFrom=''; _ccDateTo='';
  const f=document.getElementById('cc-from'), t=document.getElementById('cc-to');
  if(f) f.value=''; if(t) t.value='';
  loadCCTxns();
}

// ── Record Charge form ───────────────────────────────────────────────────────

async function _ccNewContact() {
  const c = await quickNewContact('Supplier');
  if (!c) return;
  const sel = document.getElementById('chg-supplier');
  if (sel) sel.appendChild(new Option(c.name, c.id, true, true));
}

async function ccRecordCharge() {
  const [accounts, contacts] = await Promise.all([
    apiFetch('/api/accounts')||[],
    apiFetch('/api/contacts')||[],
  ]);
  const acctTypes = ['Expense','Asset','Equity'];
  const expAccts = (accounts||[]).filter(a=>acctTypes.includes(a.account_type));
  const expOpts = expAccts.map(a=>`<option value="${a.id}">${esc((a.code?a.code+' ':'')+a.name)}</option>`).join('');
  const suppOpts = (contacts||[])
    .filter(c=>c.contact_type==='Supplier'||c.contact_type==='Both'||!c.contact_type)
    .map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('');
  const cardOpts=_ccCards.map(c=>`<option value="${c.id}"${c.id===_ccSelectedCard?' selected':''}>${esc((c.code?c.code+' ':'')+c.name)}</option>`).join('');
  const today=isoToday();

  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent='Record CC Charge';
  document.getElementById('det-body').innerHTML=`<div style="padding:4px 0">
    <div class="edt-grid">
      <div class="edt-field edt-span"><label class="edt-lbl">Card *</label>
        <select class="edt-sel" id="chg-card">${cardOpts}</select></div>
      <div class="edt-field"><label class="edt-lbl">Date *</label>
        <input class="edt-inp" id="chg-date" type="date" value="${today}"></div>
      <div class="edt-field"><label class="edt-lbl">Amount inc. GST ($) *</label>
        <input class="edt-inp" id="chg-amount" type="number" step="0.01" min="0" placeholder="0.00" oninput="ccCalcGst()"></div>
      <div class="edt-field edt-span">
        <div class="lbl-line">
          <label class="edt-lbl">Supplier</label>
          <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();_ccNewContact()">+ New</a>
        </div>
        <select class="edt-sel" id="chg-supplier"><option value="">— None —</option>${suppOpts}</select></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Description *</label>
        <input class="edt-inp" id="chg-desc" placeholder="e.g. Office supplies — Staples"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Account *</label>
        <select class="edt-sel" id="chg-account"><option value="">— Select account —</option>${expOpts}</select></div>
      <div class="edt-field"><label class="edt-lbl">Tax Code</label>
        <select class="edt-sel" id="chg-tax" onchange="ccCalcGst()">
          ${['GST','INP','FRE','N-T'].map(tc=>`<option>${tc}</option>`).join('')}
        </select></div>
      <div class="edt-field"><label class="edt-lbl">GST Amount ($)</label>
        <input class="edt-inp" id="chg-gst" type="number" step="0.01" min="0" placeholder="0.00"></div>
      <div class="edt-field"><label class="edt-lbl">Reference</label>
        <input class="edt-inp" id="chg-ref" placeholder="Optional"></div>
    </div>
  </div>`;
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="chg-save-btn" onclick="saveCharge()">Save Charge</button>
    <button class="btn btn-outline" onclick="detClose()">Cancel</button>`;
  setTimeout(()=>document.getElementById('chg-amount')?.focus(),50);
}

function ccCalcGst() {
  const tax=document.getElementById('chg-tax')?.value;
  const amt=parseFloat(document.getElementById('chg-amount')?.value||0);
  const gstInp=document.getElementById('chg-gst');
  if(!gstInp) return;
  if(tax==='GST'&&amt>0) {
    // Amount entered is assumed GST-inclusive: GST = amount / 11
    gstInp.value=(amt/11).toFixed(2);
  } else {
    gstInp.value='0.00';
  }
}

async function saveCharge() {
  const cardId=parseInt(document.getElementById('chg-card')?.value||0);
  const date=document.getElementById('chg-date')?.value;
  const amount=parseFloat(document.getElementById('chg-amount')?.value||0);
  const desc=(document.getElementById('chg-desc')?.value||'').trim();
  const accountId=parseInt(document.getElementById('chg-account')?.value||0);
  if(!cardId||!date||!amount||!desc||!accountId){
    toast('Card, date, amount, description and account are required','err'); return;
  }
  const gst=parseFloat(document.getElementById('chg-gst')?.value||0);
  const btn=document.getElementById('chg-save-btn');
  btn.disabled=true; btn.textContent='Saving\u2026';
  try {
    const suppId=parseInt(document.getElementById('chg-supplier')?.value||0)||null;
    const r=await fetch('/api/credit-cards/charge',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',
      body:JSON.stringify({card_id:cardId,date,description:desc,
        amount:amount-(gst||0),  // net amount
        expense_account_id:accountId,
        contact_id:suppId,
        reference:document.getElementById('chg-ref')?.value.trim()||'',
        tax_code:document.getElementById('chg-tax')?.value||'GST',
        gst_amount:gst||0})});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
    const jid=j.journal_id||j.id||null;
    toast('Charge recorded');
    _ccCards=await apiFetch('/api/credit-cards')||[];
    renderCCPage();
    await loadCCTxns();
    // ── Show confirmation + attachments in slide-over ────────────────────────
    document.getElementById('det-title').textContent='Charge Recorded';
    document.getElementById('det-body').innerHTML=`
      <div style="padding:8px 0 16px">
        <div style="color:var(--green);font-weight:600;margin-bottom:16px">
          ✓ Charge recorded${jid?' (Jnl #'+jid+')':''}</div>
        ${jid?ccAttachmentsHtml('journal',jid):''}
      </div>`;
    if(jid) ccInitAttachments('journal',jid);
    document.getElementById('det-foot').innerHTML=
      `<button class="btn btn-outline" onclick="detClose()">Close</button>`;
  } catch(e){ toast(e.message,'err'); btn.disabled=false; btn.textContent='Save Charge'; }
}

// ── Record Payment form ───────────────────────────────────────────────────────

async function ccRecordPayment() {
  const accounts=await apiFetch('/api/accounts')||[];
  const bankAccts=accounts.filter(a=>a.is_bank&&!a.is_credit_card);
  const bankOpts=bankAccts.map(a=>`<option value="${a.id}">${esc((a.code?a.code+' ':'')+a.name)}</option>`).join('');
  const cardOpts=_ccCards.map(c=>`<option value="${c.id}"${c.id===_ccSelectedCard?' selected':''}>${esc((c.code?c.code+' ':'')+c.name)} — Owing: ${fmt(c.balance)}</option>`).join('');
  const today=isoToday();
  const card=_ccCards.find(c=>c.id===_ccSelectedCard);

  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent='Pay Credit Card';
  document.getElementById('det-body').innerHTML=`<div style="padding:4px 0">
    <div class="edt-grid">
      <div class="edt-field edt-span"><label class="edt-lbl">Card *</label>
        <select class="edt-sel" id="pcc-card">${cardOpts}</select></div>
      <div class="edt-field"><label class="edt-lbl">Date *</label>
        <input class="edt-inp" id="pcc-date" type="date" value="${today}"></div>
      <div class="edt-field"><label class="edt-lbl">Amount ($) *</label>
        <input class="edt-inp" id="pcc-amount" type="number" step="0.01" min="0"
          value="${card?.balance>0?card.balance.toFixed(2):''}"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">From Bank Account *</label>
        <select class="edt-sel" id="pcc-bank"><option value="">— Select bank account —</option>${bankOpts}</select></div>
      <div class="edt-field"><label class="edt-lbl">Reference</label>
        <input class="edt-inp" id="pcc-ref" placeholder="Optional"></div>
      <div class="edt-field"><label class="edt-lbl">Description</label>
        <input class="edt-inp" id="pcc-desc" value="Credit Card Payment"></div>
    </div>
  </div>`;
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="pcc-save-btn" onclick="saveCCPayment()">Save Payment</button>
    <button class="btn btn-outline" onclick="detClose()">Cancel</button>`;
  setTimeout(()=>document.getElementById('pcc-amount')?.focus(),50);
}

async function saveCCPayment() {
  const cardId=parseInt(document.getElementById('pcc-card')?.value||0);
  const date=document.getElementById('pcc-date')?.value;
  const amount=parseFloat(document.getElementById('pcc-amount')?.value||0);
  const bankId=parseInt(document.getElementById('pcc-bank')?.value||0);
  if(!cardId||!date||!amount||!bankId){
    toast('Card, date, amount and bank account are required','err'); return;
  }
  const btn=document.getElementById('pcc-save-btn');
  btn.disabled=true; btn.textContent='Saving\u2026';
  try {
    const r=await fetch('/api/credit-cards/payment',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',
      body:JSON.stringify({card_id:cardId,date,amount,bank_account_id:bankId,
        reference:document.getElementById('pcc-ref')?.value.trim()||'',
        description:document.getElementById('pcc-desc')?.value.trim()||'Credit Card Payment'})});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
    const jid=j.journal_id||j.id||null;
    toast('Payment recorded');
    _ccCards=await apiFetch('/api/credit-cards')||[];
    renderCCPage();
    await loadCCTxns();
    // ── Show confirmation + attachments in slide-over ────────────────────────
    document.getElementById('det-title').textContent='Payment Recorded';
    document.getElementById('det-body').innerHTML=`
      <div style="padding:8px 0 16px">
        <div style="color:var(--green);font-weight:600;margin-bottom:16px">
          ✓ Payment recorded${jid?' (Jnl #'+jid+')':''}</div>
        ${jid?ccAttachmentsHtml('journal',jid):''}
      </div>`;
    if(jid) ccInitAttachments('journal',jid);
    document.getElementById('det-foot').innerHTML=
      `<button class="btn btn-outline" onclick="detClose()">Close</button>`;
  } catch(e){ toast(e.message,'err'); btn.disabled=false; btn.textContent='Save Payment'; }
}


// ── Transaction detail (click row to open) ───────────────────────────────────

async function ccOpenTxn(idx) {
  const tx=_ccTxns[idx];
  if(!tx) return;
  const jid=tx.journal_id;
  const charge=tx.credit>0?tx.credit:0;
  const payment=tx.debit>0?tx.debit:0;
  const desc=tx.line_desc||tx.journal_desc||'';
  const isPayment=payment>0;
  const amtColor=isPayment?'var(--green)':'var(--red)';
  const amtLabel=isPayment?'Payment':'Charge';
  const amtVal=isPayment?payment:charge;

  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent=`${isPayment?'💸 CC Payment':'💳 CC Charge'}`;
  document.getElementById('det-body').innerHTML=`
    <div style="padding:4px 0">
      <div style="background:var(--surface2);border-radius:8px;padding:14px 18px;
                  margin-bottom:16px;text-align:center">
        <div style="font-size:10px;text-transform:uppercase;letter-spacing:.08em;
                    color:var(--ink3);margin-bottom:4px">${amtLabel}</div>
        <div style="font-size:28px;font-family:'DM Mono',monospace;font-weight:700;
                    color:${amtColor}">${fmt(amtVal)}</div>
      </div>
      <table style="width:100%;font-size:13px;border-collapse:collapse">
        ${[
          ['Date',        fmtDate(tx.entry_date)],
          ['Journal #',   jid],
          ['Type',        tx.entry_type||'—'],
          tx.contact_name ? ['Supplier', tx.contact_name] : null,
          ['Description', desc||'—'],
          ['Reference',   tx.reference||'—'],
        ].filter(Boolean).map(([k,v])=>`<tr>
          <td style="color:var(--ink3);padding:5px 0;width:110px;vertical-align:top">${k}</td>
          <td style="font-weight:500;padding:5px 0">${esc(String(v))}</td>
        </tr>`).join('')}
      </table>
      ${ccAttachmentsHtml('journal', jid)}
    </div>`;
  const isVoided = (tx.journal_desc||'').startsWith('[VOIDED]') || (tx.reference||'').startsWith('VOID-');
  const canVoid  = !isPayment && !isVoided;
  document.getElementById('det-foot').innerHTML=
    `${canVoid?`<button class="btn btn-outline" style="color:var(--red)" onclick="ccVoidCharge(${jid})">Void</button>`:''}
     <button class="btn btn-outline" onclick="detClose()">Close</button>`;
  await ccInitAttachments('journal', jid);
}

async function ccVoidCharge(journalId) {
  if (!await confirmDlg('Void this charge? A reversing journal entry will be posted.')) return;
  try {
    const r = await fetch(`/api/credit-cards/void/${journalId}`, {method:'POST', credentials:'include'});
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Void failed');
    toast('Charge voided');
    detClose();
    _ccCards = await apiFetch('/api/credit-cards') || [];
    renderCCPage();
    await loadCCTxns();
  } catch(e) { toast(e.message, 'err'); }
}



function ccAttachmentsHtml(srcType, srcId) {
  return `
    <div style="border-top:1px solid var(--border);padding-top:14px;margin-top:4px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
        <span style="font-size:11px;font-weight:600;text-transform:uppercase;
                     letter-spacing:.06em;color:var(--ink3)">Attachments</span>
        <label class="btn btn-outline btn-sm" style="cursor:pointer">
          + Attach File
          <input type="file" id="cc-att-input-${srcId}" multiple style="display:none"
            onchange="ccUploadFiles('${srcType}',${srcId},this)">
        </label>
      </div>
      <div class="att-list" id="cc-att-list-${srcId}">
        <div style="font-size:12px;color:var(--ink3);padding:8px 0">No attachments yet</div>
      </div>
    </div>`;
}

async function ccInitAttachments(srcType, srcId) {
  await ccRenderAttachments(srcType, srcId);
}

async function ccRenderAttachments(srcType, srcId) {
  const listEl=document.getElementById(`cc-att-list-${srcId}`);
  if(!listEl) return;
  try {
    const atts=await apiFetch(`/api/attachments/${srcType}/${srcId}`)||[];
    if(!atts.length){
      listEl.innerHTML=`<div style="font-size:12px;color:var(--ink3);padding:8px 0">No attachments yet</div>`;
      return;
    }
    listEl.innerHTML=atts.map(a=>{
      const icon=a.mime_type?.startsWith('image/')?'🖼':a.mime_type?.includes('pdf')?'📋':'📄';
      const kb=a.file_size?Math.round(a.file_size/1024)+'kb':'';
      return `<div class="att-row">
        <span class="att-icon">${icon}</span>
        <div class="att-info">
          <div class="att-filename">${esc(a.filename)}</div>
          <div class="att-meta">${[kb,a.description].filter(Boolean).join(' · ')}</div>
        </div>
        <div class="att-btns">
          <a class="btn btn-outline btn-sm" href="/api/attachments/${a.id}/download"
             target="_blank">Open</a>
          <button class="btn btn-outline btn-sm" style="color:var(--red)"
            onclick="ccDeleteAttachment(${a.id},'${srcType}',${srcId})">✕</button>
        </div>
      </div>`;
    }).join('');
  } catch(e){ listEl.innerHTML=`<div style="color:var(--red);font-size:12px">${esc(e.message)}</div>`; }
}

async function ccUploadFiles(srcType, srcId, input) {
  const files=Array.from(input.files);
  if(!files.length) return;
  for(const file of files){
    if(file.size>20*1024*1024){ toast(`${file.name} exceeds 20 MB limit`,'err'); continue; }
    const fd=new FormData();
    fd.append('file', file);
    fd.append('description','');
    try {
      const r=await fetch(`/api/attachments/${srcType}/${srcId}`,{method:'POST',credentials:'include',body:fd});
      const j=await r.json(); if(!j.ok) throw new Error(j.error||'Upload failed');
    } catch(e){ toast(e.message,'err'); }
  }
  input.value='';
  await ccRenderAttachments(srcType, srcId);
}

async function ccDeleteAttachment(attId, srcType, srcId) {
  if(!confirm('Delete this attachment?')) return;
  try {
    const r=await fetch(`/api/attachments/${attId}`,{method:'DELETE',credentials:'include'});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Delete failed');
    await ccRenderAttachments(srcType, srcId);
  } catch(e){ toast(e.message,'err'); }
}
