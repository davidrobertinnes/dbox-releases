// ═══════════════════════════════════════════════════════════════════════════
// ITEMS (ITEM CATALOGUE) PAGE
// ═══════════════════════════════════════════════════════════════════════════
let _itmAll=[], _itmFilter='All', _itmSearch='', _itmSort={col:'name',dir:1}, _itmSelected=null;
let _itmEditId=null, _itmAccounts=[];
const ITM_FILTERS=['All','Active','Inactive','Inventoried','Low Stock'];
const ITM_TAX_CODES=['GST','FRE','INP','N-T','CAP'];

let _itmPageTab = 'items';

// ── Promotions state ──────────────────────────────────────────────────────
let _promoAll=[], _promoFilter='All', _promoSearch='', _promoEditId=null;
const PROMO_FILTERS=['All','Active','Scheduled','Expired','Disabled'];

async function pageItems() {
  try {
    [_itmAll, _itmAccounts, _promoAll] = await Promise.all([
      apiFetch('/api/items/all').then(r=>r||[]),
      apiFetch('/api/accounts').then(r=>r||[]),
      apiFetch('/api/promotions').then(r=>r||[]),
    ]);
    _renderItmPage();
  } catch(e) {
    document.getElementById('module-content').innerHTML=`<div class="state-error">Failed to load items: ${esc(e.message)}</div>`;
  }
}

function _renderItmPage() {
  const mc = document.getElementById('module-content');
  mc.innerHTML = `
    <div class="inv-tabs" style="margin-bottom:14px">
      <div class="inv-tab${_itmPageTab==='items'?' active':''}" onclick="itmSwitchTab('items')">Items</div>
      <div class="inv-tab${_itmPageTab==='promotions'?' active':''}" onclick="itmSwitchTab('promotions')">Promotions</div>
    </div>
    <div id="itm-tab-body"></div>`;
  _renderItmTabBody();
}

window.itmSwitchTab = function(tab) {
  _itmPageTab = tab;
  document.querySelectorAll('#module-content .inv-tab').forEach(el =>
    el.classList.toggle('active', el.textContent.toLowerCase() === tab)
  );
  _renderItmTabBody();
};

function _itmFiltered() {
  const q=_itmSearch.toLowerCase();
  return _itmAll.filter(it=>{
    if(_itmFilter==='Active'   && !it.is_active)     return false;
    if(_itmFilter==='Inactive' &&  it.is_active)     return false;
    if(_itmFilter==='Inventoried' && !it.is_inventoried) return false;
    if(_itmFilter==='Low Stock' && !(it.is_inventoried && it.reorder_level > 0 && it.qty_on_hand <= it.reorder_level)) return false;
    if(q && ![it.item_code,it.name,it.description].some(v=>(v||'').toLowerCase().includes(q))) return false;
    return true;
  }).sort((a,b)=>{
    const col=_itmSort.col, av=a[col]??'', bv=b[col]??'';
    return(typeof av==='number'?(av-bv):String(av).localeCompare(String(bv)))*_itmSort.dir;
  });
}

function _renderItmTabBody() {
  if (_itmPageTab === 'items') renderItemsPage();
  else _promoRender();
}

function renderItemsPage(restoreFocus) {
  const rows=_itmFiltered();
  const counts={
    All: _itmAll.length,
    Active: _itmAll.filter(i=>i.is_active).length,
    Inactive: _itmAll.filter(i=>!i.is_active).length,
    Inventoried: _itmAll.filter(i=>i.is_inventoried).length,
    'Low Stock': _itmAll.filter(i=>i.is_inventoried && i.reorder_level > 0 && i.qty_on_hand <= i.reorder_level).length,
  };
  const mc=document.getElementById('itm-tab-body') || document.getElementById('module-content');
  mc.innerHTML=`
    <div class="inv-toolbar">
      <input class="inv-search" id="itm-q" placeholder="Search code, name, description\u2026" value="${esc(_itmSearch)}">
      <div class="inv-filter-group">
        ${ITM_FILTERS.map(f=>`<button class="filter-btn${_itmFilter===f?' active':''}" onclick="itmSetFilter('${f}')">
          ${f}${counts[f]?` <span class="filter-count">(${counts[f]})</span>`:''}</button>`).join('')}
      </div>
      <button class="btn btn-primary" onclick="itmNew()">+ New Item</button>
    </div>
    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        ${itmTh('item_code','Code')}
        ${itmTh('name','Name')}
        ${itmTh('description','Description')}
        ${itmTh('unit_price','Price','r')}
        ${itmTh('tax_code','Tax')}
        ${itmTh('account_name','Account')}
        ${itmTh('is_inventoried','Stock')}
        ${itmTh('is_active','Status')}
      </tr></thead><tbody>
        ${rows.length ? rows.map(itmRow).join('') : `<tr><td colspan="8" class="tbl-empty-row">No items match your filter</td></tr>`}
      </tbody></table>
    </div></div>
    <div class="list-count-row"><span class="count-pill">${rows.length} of ${_itmAll.length} item${_itmAll.length!==1?'s':''}</span></div>`;
  const q=document.getElementById('itm-q');
  if(q){
    q.addEventListener('input',e=>{_itmSearch=e.target.value;renderItemsPage(true);});
    if(restoreFocus){q.focus();q.setSelectionRange(q.value.length,q.value.length);}
  }
}

function itmTh(col,label,align) {
  const cls=_itmSort.col===col?(_itmSort.dir>0?'sort-asc':'sort-desc'):'';
  const st=align==='r'?' class="th-r"':'';
  return `<th class="${cls}"${st} onclick="itmSortBy('${col}')">${label}</th>`;
}

function itmRow(it) {
  const sel=_itmSelected===it.id;
  const price=it.unit_price!=null?`$${parseFloat(it.unit_price).toFixed(2)}`:'—';
  const stockBadge=it.is_inventoried
    ?`<span class="badge badge-blue">📦 Stock</span>`
    :`<span class="itm-sm-muted">—</span>`;
  const statusBadge=it.is_active
    ?`<span class="badge badge-green">Active</span>`
    :`<span class="badge badge-draft">Inactive</span>`;
  const accText=it.account_code&&it.account_name?`${it.account_code}  ${it.account_name}`:'—';
  return `<tr class="inv-row${sel?' is-selected':''}" onclick="itmOpen(${it.id})">
    <td><span class="inv-mono">${esc(it.item_code||'—')}</span></td>
    <td><span class="inv-contact">${esc(it.name)}</span></td>
    <td class="itm-desc-cell"><span class="itm-desc-text">${esc(it.description||'—')}</span></td>
    <td class="td-r-mono">${price}</td>
    <td><span class="inv-mono itm-sm-muted">${esc(it.tax_code||'—')}</span></td>
    <td><span class="itm-sm-muted">${esc(accText)}</span></td>
    <td>${stockBadge}</td>
    <td>${statusBadge}</td>
  </tr>`;
}

function itmSortBy(col){_itmSort={col,dir:_itmSort.col===col?_itmSort.dir*-1:1};renderItemsPage();}
function itmSetFilter(f){_itmFilter=f;renderItemsPage();}

async function itmOpen(id) {
  _itmSelected=id;
  renderItemsPage();
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent='Item';
  document.getElementById('det-body').innerHTML='<div class="state-loading">Loading\u2026</div>';
  document.getElementById('det-foot').innerHTML='';
  try {
    const it=await apiFetch(`/api/items/${id}`);
    renderItmDetail(it);
  } catch(e) {
    document.getElementById('det-body').innerHTML=`<div class="state-error">${esc(e.message)}</div>`;
  }
}

function _itmAccountName(id) {
  if(!id) return '—';
  const a=_itmAccounts.find(a=>a.id===id||a.id===parseInt(id));
  return a?`${a.code} ${a.name}`:'—';
}

function renderItmDetail(it) {
  document.getElementById('det-title').textContent=it.name;
  const price=it.unit_price!=null?`$${parseFloat(it.unit_price).toFixed(2)}`:'—';
  const cost=it.unit_cost!=null?`$${parseFloat(it.unit_cost).toFixed(2)}`:'—';
  document.getElementById('det-body').innerHTML=`
    <div class="con-badge-row">
      ${it.is_inventoried?'<span class="badge badge-blue">📦 Inventoried</span>':''}
      ${it.is_livestock?'<span class="badge badge-green">🐄 Livestock</span>':''}
      ${it.is_active?'<span class="badge badge-green">Active</span>':'<span class="badge badge-draft">Inactive</span>'}
    </div>
    ${it.item_code?`<div class="inv-detail-row"><span class="inv-detail-lbl">Code</span><span class="inv-mono">${esc(it.item_code)}</span></div>`:''}
    <div class="inv-detail-grid">
      <div class="inv-detail-row"><span class="inv-detail-lbl">Unit Price</span><span class="inv-mono">${price}</span></div>
      <div class="inv-detail-row"><span class="inv-detail-lbl">Tax Code</span><span class="inv-mono">${esc(it.tax_code||'—')}</span></div>
      ${it.description?`<div class="inv-detail-row itm-span-row"><span class="inv-detail-lbl">Description</span><span>${esc(it.description)}</span></div>`:''}
      <div class="inv-detail-row itm-span-row"><span class="inv-detail-lbl">Income Account</span><span class="inv-mono itm-acct-mono">${_itmAccountName(it.account_id)}</span></div>
    </div>
    ${it.is_inventoried?`
    <div class="con-bank-section">
      <div class="con-bank-lbl">Inventory Details</div>
      <div class="inv-detail-grid">
        <div class="inv-detail-row"><span class="inv-detail-lbl">Unit Cost</span><span class="inv-mono">${cost}</span></div>
        <div class="inv-detail-row"><span class="inv-detail-lbl">Stock on Hand</span><span class="inv-mono">${it.qty_on_hand!=null?parseFloat(it.qty_on_hand).toFixed(2):'—'}</span></div>
        <div class="inv-detail-row"><span class="inv-detail-lbl">Reorder Level</span><span class="inv-mono">${it.reorder_level!=null?it.reorder_level:'—'}</span></div>
        <div class="inv-detail-row"><span class="inv-detail-lbl">Reorder Qty</span><span class="inv-mono">${it.reorder_qty!=null?it.reorder_qty:'—'}</span></div>
        ${it.location?`<div class="inv-detail-row"><span class="inv-detail-lbl">Location</span><span>${esc(it.location)}</span></div>`:''}
        ${it.barcode?`<div class="inv-detail-row"><span class="inv-detail-lbl">Barcode</span><span class="inv-mono">${esc(it.barcode)}</span></div>`:''}
        <div class="inv-detail-row itm-span-row"><span class="inv-detail-lbl">COGS Account</span><span class="inv-mono itm-acct-mono">${_itmAccountName(it.cogs_account_id)}</span></div>
        <div class="inv-detail-row itm-span-row"><span class="inv-detail-lbl">Stock Account</span><span class="inv-mono itm-acct-mono">${_itmAccountName(it.stock_account_id)}</span></div>
      </div>
    </div>`:''}`;
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" onclick="itmEdit(${it.id})">✏ Edit</button>
    <button class="btn btn-danger" onclick="itmDelete(${it.id},'${esc(it.name)}')">Delete</button>
    <button class="btn btn-outline" onclick="detClose()">Close</button>`;
}

function itmNew() {
  _itmEditId=null;
  _showItmModal(null);
}

function itmEdit(id) {
  _itmEditId=id;
  apiFetch(`/api/items/${id}`).then(it=>_showItmModal(it)).catch(e=>toast(e.message,'err'));
}

function _itmAccountOptions(filterFn, selectedId) {
  const primary=_itmAccounts.filter(filterFn);
  const other=_itmAccounts.filter(a=>!filterFn(a)&&a.is_active);
  const opt=(a)=>`<option value="${a.id}"${a.id===selectedId||a.id===parseInt(selectedId)?' selected':''}>${esc(a.code+' '+a.name)}</option>`;
  let html=`<option value=""></option>`;
  if(primary.length){ html+=`<optgroup label="──────────────">${primary.map(opt).join('')}</optgroup>`; }
  if(other.length){   html+=`<optgroup label="── Other ──">${other.map(opt).join('')}</optgroup>`; }
  return html;
}

function _showItmModal(it) {
  const isNew=!it;
  const v=(f,fb='')=>esc(it?it[f]??fb:fb);
  const isInv=it&&it.is_inventoried;
  const isActive=it?it.is_active:true;

  const incomeAccOpts=_itmAccountOptions(a=>['Income','Revenue'].includes(a.account_type)&&a.is_active, it?.account_id);
  const cogsAccOpts  =_itmAccountOptions(a=>['COGS','Cost of Goods Sold','Expense'].includes(a.account_type)&&a.is_active, it?.cogs_account_id);
  const stockAccOpts =_itmAccountOptions(a=>['Asset','Current Asset'].includes(a.account_type)&&a.is_active, it?.stock_account_id);


  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent=isNew?'New Item':`Edit — ${it.name}`;
  document.getElementById('det-body').innerHTML=`<div class="edt-field-mb">
    <div class="edt-grid">
      <div class="edt-field"><label class="edt-lbl">Item Code</label><input class="edt-inp" id="if-code" value="${v('item_code')}"></div>
      <div class="edt-field"><label class="edt-lbl">Name *</label><input class="edt-inp" id="if-name" value="${v('name')}"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Description</label><input class="edt-inp" id="if-desc" value="${v('description')}"></div>
      <div class="edt-field"><label class="edt-lbl">Unit Price</label><input class="edt-inp" id="if-price" type="number" step="0.01" value="${it&&it.unit_price!=null?it.unit_price:''}"></div>
      <div class="edt-field"><label class="edt-lbl">Tax Code</label>
        <select class="edt-sel" id="if-tax">${ITM_TAX_CODES.map(t=>`<option${(it?.tax_code||'GST')===t?' selected':''}>${t}</option>`).join('')}</select></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Income Account</label>
        <select class="edt-sel" id="if-income-acc">${incomeAccOpts}</select></div>
      <div class="edt-field edt-span itm-chk-row">
        <input type="checkbox" id="if-active" ${isActive?'checked':''}> <label class="edt-lbl itm-chk-lbl" for="if-active">Active</label>
      </div>
    </div>

    <div class="con-bank-section">
      <div class="itm-inv-row">
        <input type="checkbox" id="if-inventoried" ${isInv?'checked':''} onchange="itmToggleInv()">
        <label class="edt-lbl itm-inv-lbl" for="if-inventoried">Track stock for this item</label>
      </div>
      <div id="itm-inv-fields" class="itm-inv-fields-block${isInv?' is-visible':''}">
        <div class="edt-grid">
          <div class="edt-field"><label class="edt-lbl">Unit Cost</label><input class="edt-inp" id="if-cost" type="number" step="0.01" value="${it&&it.unit_cost!=null?it.unit_cost:''}"></div>
          <div class="edt-field"><label class="edt-lbl">Reorder Level</label><input class="edt-inp" id="if-reorder-lvl" type="number" value="${v('reorder_level')}"></div>
          <div class="edt-field"><label class="edt-lbl">Reorder Qty</label><input class="edt-inp" id="if-reorder-qty" type="number" value="${v('reorder_qty')}"></div>
          <div class="edt-field"><label class="edt-lbl">Location</label><input class="edt-inp" id="if-location" value="${v('location')}"></div>
          <div class="edt-field"><label class="edt-lbl">Barcode</label><input class="edt-inp" id="if-barcode" value="${v('barcode')}"></div>
          <div class="edt-field edt-span"><label class="edt-lbl">COGS Account</label>
            <select class="edt-sel" id="if-cogs-acc">${cogsAccOpts}</select></div>
          <div class="edt-field edt-span"><label class="edt-lbl">Stock Account</label>
            <select class="edt-sel" id="if-stock-acc">${stockAccOpts}</select></div>
          <div class="edt-field edt-span itm-chk-row">
            <input type="checkbox" id="if-livestock" ${it?.is_livestock?'checked':''}> <label class="edt-lbl itm-chk-lbl" for="if-livestock">Livestock item (enables natural increase, deaths &amp; private use in Inventory)</label>
          </div>
        </div>
      </div>
    </div>
  </div>`;
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="itm-save-btn" onclick="saveItem()">Save</button>
    <button class="btn btn-outline" onclick="${_itmEditId?`itmOpen(${_itmEditId})`:'detClose()'}">Cancel</button>`;
  setTimeout(()=>{ const f=document.getElementById('if-name'); if(f) f.focus(); }, 50);
}

function itmToggleInv() {
  const cb=document.getElementById('if-inventoried');
  const fields=document.getElementById('itm-inv-fields');
  if(fields) fields.classList.toggle('is-visible', !!(cb&&cb.checked));
}

async function saveItem() {
  const name=(document.getElementById('if-name')?.value||'').trim();
  if(!name){toast('Name is required','err');return;}
  const btn=document.getElementById('itm-save-btn');
  btn.disabled=true; btn.textContent='Saving\u2026';
  const isInv=document.getElementById('if-inventoried')?.checked||false;
  const payload={
    name,
    item_code: document.getElementById('if-code')?.value.trim()||null,
    description: document.getElementById('if-desc')?.value.trim()||null,
    unit_price: parseFloat(document.getElementById('if-price')?.value)||null,
    tax_code: document.getElementById('if-tax')?.value||'GST',
    income_account_id: parseInt(document.getElementById('if-income-acc')?.value)||null,
    is_active: document.getElementById('if-active')?.checked?1:0,
    is_inventoried: isInv?1:0,
    is_livestock: isInv?(document.getElementById('if-livestock')?.checked?1:0):0,
    unit_cost: isInv?(parseFloat(document.getElementById('if-cost')?.value)||null):null,
    reorder_level: isInv?(parseFloat(document.getElementById('if-reorder-lvl')?.value)||null):null,
    reorder_qty: isInv?(parseFloat(document.getElementById('if-reorder-qty')?.value)||null):null,
    location: isInv?(document.getElementById('if-location')?.value.trim()||null):null,
    barcode: isInv?(document.getElementById('if-barcode')?.value.trim()||null):null,
    cogs_account_id: isInv?(parseInt(document.getElementById('if-cogs-acc')?.value)||null):null,
    stock_account_id: isInv?(parseInt(document.getElementById('if-stock-acc')?.value)||null):null,
  };
  try {
    let savedId=_itmEditId;
    if(_itmEditId) {
      const r=await fetch(`/api/items/${_itmEditId}`,{method:'PUT',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
    } else {
      const r=await fetch('/api/items',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
      savedId=j.data?.id;
    }
    toast('Item saved');
    [_itmAll]=await Promise.all([apiFetch('/api/items/all').then(r=>r||[])]);
    if(savedId){ _itmSelected=savedId; await itmOpen(savedId); }
    else { detClose(); renderItemsPage(); }
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent='Save';
  }
}

async function itmDelete(id, name) {
  if(!confirm(`Delete item "${name}"?\n\nThis won't affect existing invoices.`)) return;
  try {
    const r=await fetch(`/api/items/${id}`,{method:'DELETE',credentials:'include'});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Delete failed');
    toast('Item deleted');
    _itmSelected=null;
    detClose();
    _itmAll=await apiFetch('/api/items/all').then(r=>r||[]);
    renderItemsPage();
  } catch(e){ toast(e.message,'err'); }
}

// ═══════════════════════════════════════════════════════════════════════════
// PROMOTIONS TAB
// ═══════════════════════════════════════════════════════════════════════════

function _promoFiltered() {
  const q = _promoSearch.toLowerCase();
  return _promoAll.filter(p => {
    if (_promoFilter !== 'All' && p._status !== _promoFilter) return false;
    if (q && ![p.item_name, p.item_code, p.promo_name].some(v => (v||'').toLowerCase().includes(q))) return false;
    return true;
  });
}

function _promoRender() {
  const rows = _promoFiltered();
  const counts = {};
  PROMO_FILTERS.forEach(f => counts[f] = f === 'All' ? _promoAll.length : _promoAll.filter(p => p._status === f).length);
  const mc = document.getElementById('itm-tab-body') || document.getElementById('module-content');
  mc.innerHTML = `
    <div class="inv-toolbar">
      <input class="inv-search" id="promo-q" placeholder="Search item, promotion name…" value="${esc(_promoSearch)}">
      <div class="inv-filter-group">
        ${PROMO_FILTERS.map(f => `<button class="filter-btn${_promoFilter===f?' active':''}" onclick="_promoSetFilter('${f}')">
          ${f}${counts[f]?` <span class="filter-count">(${counts[f]})</span>`:''}</button>`).join('')}
      </div>
      <button class="btn btn-primary" onclick="_promoNew()">+ New Promotion</button>
    </div>
    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        <th>Item</th><th>Promotion</th>
        <th class="th-r">Promo Price</th><th class="th-r">Std Price</th><th class="th-r">Discount</th>
        <th>Start</th><th>End</th><th>Status</th>
      </tr></thead><tbody>
        ${rows.length ? rows.map(_promoRow).join('') : `<tr><td colspan="8" class="tbl-empty-row">No promotions match your filter</td></tr>`}
      </tbody></table>
    </div></div>
    <div class="list-count-row"><span class="count-pill">${rows.length} of ${_promoAll.length} promotion${_promoAll.length!==1?'s':''}</span></div>`;
  const q = document.getElementById('promo-q');
  if (q) q.addEventListener('input', e => { _promoSearch = e.target.value; _promoRender(); });
}

function _promoRow(p) {
  const cls = {Active:'badge-green', Scheduled:'badge-blue', Expired:'badge-draft', Disabled:'badge-draft'}[p._status] || 'badge-draft';
  const disc = p._discount_pct > 0 ? `<span class="col-green">-${p._discount_pct}%</span>` : '—';
  return `<tr class="inv-row" onclick="_promoOpen(${p.id})">
    <td><span class="inv-contact">${esc(p.item_name||'—')}</span>${p.item_code?` <span class="inv-mono itm-sm-muted">${esc(p.item_code)}</span>`:''}</td>
    <td>${esc(p.promo_name)}</td>
    <td class="td-r-mono">$${parseFloat(p.promo_price).toFixed(2)}</td>
    <td class="td-r-mono">${p.standard_price!=null?'$'+parseFloat(p.standard_price).toFixed(2):'—'}</td>
    <td class="th-r">${disc}</td>
    <td>${fmtDate(p.start_date)}</td>
    <td>${fmtDate(p.end_date)}</td>
    <td><span class="badge ${cls}">${p._status}</span></td>
  </tr>`;
}

window._promoSetFilter = function(f) { _promoFilter = f; _promoRender(); };

function _promoOpen(id) {
  const p = _promoAll.find(x => x.id === id);
  if (!p) return;
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = p.promo_name;
  const cls = {Active:'badge-green', Scheduled:'badge-blue', Expired:'badge-draft', Disabled:'badge-draft'}[p._status] || 'badge-draft';
  document.getElementById('det-body').innerHTML = `
    <div class="con-badge-row"><span class="badge ${cls}">${p._status}</span></div>
    <div class="inv-detail-row"><span class="inv-detail-lbl">Item</span><span>${esc(p.item_name||'—')}</span></div>
    <div class="inv-detail-row"><span class="inv-detail-lbl">Promo Price</span><span class="inv-mono">$${parseFloat(p.promo_price).toFixed(2)}</span></div>
    <div class="inv-detail-row"><span class="inv-detail-lbl">Standard Price</span><span class="inv-mono">${p.standard_price!=null?'$'+parseFloat(p.standard_price).toFixed(2):'—'}</span></div>
    ${p._discount_pct>0?`<div class="inv-detail-row"><span class="inv-detail-lbl">Discount</span><span class="col-green">-${p._discount_pct}%</span></div>`:''}
    <div class="inv-detail-row"><span class="inv-detail-lbl">Period</span><span>${fmtDate(p.start_date)} — ${fmtDate(p.end_date)}</span></div>
    ${p.notes?`<div class="inv-detail-row itm-span-row"><span class="inv-detail-lbl">Notes</span><span>${esc(p.notes)}</span></div>`:''}
    ${!p.is_active?'<div class="inv-detail-row"><span class="inv-detail-lbl">Enabled</span><span class="col-red">No (disabled)</span></div>':''}`;
  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-primary" onclick="_promoEdit(${p.id})">✏ Edit</button>
    <button class="btn btn-danger" onclick="_promoDelete(${p.id},'${esc(p.promo_name)}')">Delete</button>
    <button class="btn btn-outline" onclick="detClose()">Close</button>`;
}

function _promoNew(prefillItemId) {
  _promoEditId = null;
  _showPromoForm(null, prefillItemId);
}

function _promoEdit(id) {
  const p = _promoAll.find(x => x.id === id);
  if (p) { _promoEditId = id; _showPromoForm(p); }
}

function _showPromoForm(p, prefillItemId) {
  const isNew = !p;
  const v = (f, fb='') => esc(p ? p[f] ?? fb : fb);

  const itemOpts = _itmAll
    .filter(i => i.is_active)
    .sort((a, b) => (a.name||'').localeCompare(b.name||''))
    .map(i => {
      const sel = (p && p.item_id === i.id) || (prefillItemId && i.id === prefillItemId) ? ' selected' : '';
      return `<option value="${i.id}"${sel}>${esc(i.item_code?i.item_code+' — ':'')}${esc(i.name)}</option>`;
    }).join('');

  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent = isNew ? 'New Promotion' : `Edit — ${p.promo_name}`;
  document.getElementById('det-body').innerHTML = `<div class="edt-field-mb">
    <div class="edt-grid">
      <div class="edt-field edt-span"><label class="edt-lbl">Item *</label>
        <select class="edt-sel" id="pf-item"><option value=""></option>${itemOpts}</select></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Promotion Name *</label>
        <input class="edt-inp" id="pf-name" value="${v('promo_name')}" placeholder="e.g. Clearance Sale, Easter Promo"></div>
      <div class="edt-field"><label class="edt-lbl">Promo Price (ex-GST) *</label>
        <input class="edt-inp" id="pf-price" type="number" step="0.01" min="0" value="${p&&p.promo_price!=null?p.promo_price:''}"></div>
      <div class="edt-field"></div>
      <div class="edt-field"><label class="edt-lbl">Start Date *</label>
        <input class="edt-inp" id="pf-start" type="date" value="${v('start_date')}"></div>
      <div class="edt-field"><label class="edt-lbl">End Date *</label>
        <input class="edt-inp" id="pf-end" type="date" value="${v('end_date')}"></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Notes</label>
        <input class="edt-inp" id="pf-notes" value="${v('notes')}"></div>
      <div class="edt-field edt-span itm-chk-row">
        <input type="checkbox" id="pf-active" ${isNew||p.is_active?'checked':''}> <label class="edt-lbl itm-chk-lbl" for="pf-active">Active</label>
      </div>
    </div>
  </div>`;
  document.getElementById('det-foot').innerHTML = `
    <button class="btn btn-primary" id="promo-save-btn" onclick="_savePromo()">Save</button>
    <button class="btn btn-outline" onclick="${_promoEditId?`_promoOpen(${_promoEditId})`:'detClose()'}">Cancel</button>`;
  setTimeout(() => { const f = document.getElementById('pf-name'); if (f) f.focus(); }, 50);
}

async function _savePromo() {
  const itemId = parseInt(document.getElementById('pf-item')?.value);
  const name = (document.getElementById('pf-name')?.value||'').trim();
  const price = parseFloat(document.getElementById('pf-price')?.value);
  const start = document.getElementById('pf-start')?.value;
  const end = document.getElementById('pf-end')?.value;
  if (!itemId) { toast('Select an item', 'err'); return; }
  if (!name) { toast('Promotion name is required', 'err'); return; }
  if (isNaN(price) || price < 0) { toast('Enter a valid promo price', 'err'); return; }
  if (!start || !end) { toast('Start and end dates are required', 'err'); return; }
  if (end < start) { toast('End date must be on or after start date', 'err'); return; }
  const btn = document.getElementById('promo-save-btn');
  btn.disabled = true; btn.textContent = 'Saving…';
  const payload = {
    item_id: itemId, promo_name: name, promo_price: price,
    start_date: start, end_date: end,
    notes: document.getElementById('pf-notes')?.value.trim() || null,
    is_active: document.getElementById('pf-active')?.checked ? 1 : 0,
  };
  try {
    let savedId = _promoEditId;
    if (_promoEditId) {
      const r = await fetch(`/api/promotions/${_promoEditId}`, {method:'PUT', headers:{'Content-Type':'application/json'}, credentials:'include', body:JSON.stringify(payload)});
      const j = await r.json(); if (!j.ok) throw new Error(j.error||'Save failed');
    } else {
      const r = await fetch('/api/promotions', {method:'POST', headers:{'Content-Type':'application/json'}, credentials:'include', body:JSON.stringify(payload)});
      const j = await r.json(); if (!j.ok) throw new Error(j.error||'Save failed');
      savedId = j.data?.id;
    }
    toast('Promotion saved');
    _promoAll = await apiFetch('/api/promotions').then(r=>r||[]);
    if (savedId) { detClose(); _promoRender(); _promoOpen(savedId); }
    else { detClose(); _promoRender(); }
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = 'Save';
  }
}

async function _promoDelete(id, name) {
  if (!confirm(`Delete promotion "${name}"?`)) return;
  try {
    const r = await fetch(`/api/promotions/${id}`, {method:'DELETE', credentials:'include'});
    const j = await r.json(); if (!j.ok) throw new Error(j.error||'Delete failed');
    toast('Promotion deleted');
    detClose();
    _promoAll = await apiFetch('/api/promotions').then(r=>r||[]);
    _promoRender();
  } catch(e) { toast(e.message, 'err'); }
}
