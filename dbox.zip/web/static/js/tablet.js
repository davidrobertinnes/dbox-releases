// dbox Tablet PWA — table service UI
// All globals prefixed _T to avoid collisions

// ── Theme ─────────────────────────────────────────────────────────────────────
const _TTHEMES = {
  "Ocean Light":   { bg:"#EBF2FA",  surface:"#F7FAFD", surface2:"#F0F6FB", border:"#C8DCEE",              border2:"#a8c8e0", ink:"#1A2E45", ink2:"#3a5068", ink3:"#6B8BAA", accent:"#185FA5", accentDim:"rgba(24,95,165,0.10)",   green:"#3B6D11", greenDim:"rgba(59,109,17,0.10)",   red:"#A32D2D", redDim:"rgba(163,45,45,0.10)",  amber:"#8a5a00", amberDim:"rgba(138,90,0,0.10)",  header:"#FFFFFF", entryBg:"#FFFFFF", rowAlt:"#F0F6FB", shadow:"0 2px 8px rgba(24,95,165,0.08)",  shadowLg:"0 8px 24px rgba(24,95,165,0.13)" },
  "Dark":          { bg:"#0d0f14",  surface:"#13161e", surface2:"#1a1e28", border:"rgba(255,255,255,0.07)",border2:"rgba(255,255,255,0.14)", ink:"#f0f2f7", ink2:"#9ba3b8", ink3:"#5c6478", accent:"#e8b84b", accentDim:"rgba(232,184,75,0.15)",   green:"#4caf88", greenDim:"rgba(76,175,136,0.12)",  red:"#e05c5c", redDim:"rgba(224,92,92,0.12)",   amber:"#e8934b", amberDim:"rgba(232,147,75,0.12)", header:"#13161e", entryBg:"#1a1e28", rowAlt:"#1a1e28", shadow:"0 2px 8px rgba(0,0,0,0.3)",      shadowLg:"0 8px 24px rgba(0,0,0,0.4)" },
  "Midnight Blue": { bg:"#0f1729",  surface:"#162035", surface2:"#1c2940", border:"rgba(100,140,200,0.18)",border2:"rgba(100,140,200,0.3)",  ink:"#cdd8f0", ink2:"#8fa4cc", ink3:"#516080", accent:"#5b8dee", accentDim:"rgba(91,141,238,0.15)",   green:"#4caf88", greenDim:"rgba(76,175,136,0.12)",  red:"#e05c5c", redDim:"rgba(224,92,92,0.12)",   amber:"#e8b84b", amberDim:"rgba(232,184,75,0.12)", header:"#0f1729", entryBg:"#1c2940", rowAlt:"#162035", shadow:"0 2px 8px rgba(0,0,0,0.3)",      shadowLg:"0 8px 24px rgba(0,0,0,0.4)" },
  "Forest":        { bg:"#1a2318",  surface:"#21301e", surface2:"#283d24", border:"rgba(100,160,80,0.20)", border2:"rgba(100,160,80,0.32)",  ink:"#d4ead0", ink2:"#94bb88", ink3:"#587050", accent:"#6ab04c", accentDim:"rgba(106,176,76,0.15)",   green:"#4caf88", greenDim:"rgba(76,175,136,0.12)",  red:"#e05c5c", redDim:"rgba(224,92,92,0.12)",   amber:"#e8b84b", amberDim:"rgba(232,184,75,0.12)", header:"#1a2318", entryBg:"#283d24", rowAlt:"#21301e", shadow:"0 2px 8px rgba(0,0,0,0.3)",      shadowLg:"0 8px 24px rgba(0,0,0,0.4)" },
  "Warm Slate":    { bg:"#2d2a26",  surface:"#36322d", surface2:"#3a3630", border:"rgba(122,114,104,0.45)",border2:"rgba(122,114,104,0.65)", ink:"#f0ece6", ink2:"#c8bfb4", ink3:"#a89f94", accent:"#e8975a", accentDim:"rgba(232,151,90,0.15)",   green:"#7cb87d", greenDim:"rgba(124,184,125,0.12)", red:"#e05c5c", redDim:"rgba(224,92,92,0.12)",   amber:"#e8b84b", amberDim:"rgba(232,184,75,0.12)", header:"#231f1c", entryBg:"#423e38", rowAlt:"#3a3630", shadow:"0 2px 8px rgba(0,0,0,0.25)",     shadowLg:"0 8px 24px rgba(0,0,0,0.35)" },
  "Light":         { bg:"#f5f7fa",  surface:"#ffffff",  surface2:"#f8fafc", border:"#94a3b8",              border2:"#64748b",                ink:"#1e293b", ink2:"#334155", ink3:"#64748b", accent:"#2563eb", accentDim:"rgba(37,99,235,0.08)",    green:"#16a34a", greenDim:"rgba(22,163,74,0.10)",   red:"#dc2626", redDim:"rgba(220,38,38,0.10)",  amber:"#b45309", amberDim:"rgba(180,83,9,0.10)",  header:"#ffffff",  entryBg:"#ffffff",  rowAlt:"#f8fafc", shadow:"0 1px 4px rgba(0,0,0,0.08)",     shadowLg:"0 6px 20px rgba(0,0,0,0.12)" },
  "Purple Haze":   { bg:"#1a1428",  surface:"#221b35", surface2:"#261e3d", border:"rgba(102,85,160,0.35)", border2:"rgba(102,85,160,0.55)",  ink:"#ede9fe", ink2:"#c4b5fd", ink3:"#7c6aad", accent:"#a78bfa", accentDim:"rgba(167,139,250,0.15)",  green:"#34d399", greenDim:"rgba(52,211,153,0.12)",  red:"#f87171", redDim:"rgba(248,113,113,0.12)", amber:"#fbbf24", amberDim:"rgba(251,191,36,0.12)",header:"#120e1e", entryBg:"#2d2545", rowAlt:"#261e3d", shadow:"0 2px 8px rgba(0,0,0,0.3)",      shadowLg:"0 8px 24px rgba(0,0,0,0.4)" },
};

function _TApplyTheme() {
  const name = localStorage.getItem('dbox_theme') || 'Ocean Light';
  const t = _TTHEMES[name] || _TTHEMES['Ocean Light'];
  const r = document.documentElement.style;
  r.setProperty('--bg', t.bg);
  r.setProperty('--surface', t.surface);
  r.setProperty('--surface2', t.surface2);
  r.setProperty('--border', t.border);
  r.setProperty('--border2', t.border2);
  r.setProperty('--ink', t.ink);
  r.setProperty('--ink2', t.ink2);
  r.setProperty('--ink3', t.ink3);
  r.setProperty('--accent', t.accent);
  r.setProperty('--accent-dim', t.accentDim);
  r.setProperty('--green', t.green);
  r.setProperty('--green-dim', t.greenDim);
  r.setProperty('--red', t.red);
  r.setProperty('--red-dim', t.redDim);
  r.setProperty('--amber', t.amber);
  r.setProperty('--amber-dim', t.amberDim);
  r.setProperty('--header', t.header);
  r.setProperty('--entry-bg', t.entryBg);
  r.setProperty('--row-alt', t.rowAlt);
  r.setProperty('--shadow', t.shadow);
  r.setProperty('--shadow-lg', t.shadowLg);
}

// ── State ─────────────────────────────────────────────────────────────────────
let _TZones          = [];
let _TTables         = [];
let _TItems          = [];
let _TCurrentTabId   = null;
let _TCurrentTab     = null;
let _TZoneFilter     = 'all';
let _TItemSearch     = '';
let _TCatFilter      = null;
let _TViewMode       = 'floor'; // 'floor' | 'tab' | 'takeaway'
let _TPrevView       = 'floor';
let _TTakeawayTableId = null;
let _TTakeawayQueue  = [];
let _TRefreshTimer   = null;
let _TSettleMethod   = 'cash';

// ── Utilities ─────────────────────────────────────────────────────────────────
function _Tesc(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function _Tfmt(n) {
  if (n == null) return '—';
  const abs = Math.abs(n);
  const s = abs.toLocaleString('en-AU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return (n < 0 ? '-$' : '$') + s;
}

function _TElapsed(openedAt) {
  if (!openedAt) return '';
  const ms = Date.now() - new Date(openedAt).getTime();
  const mins = Math.floor(ms / 60000);
  if (mins < 60) return `${mins}m`;
  const hrs = Math.floor(mins / 60);
  return `${hrs}h ${mins % 60}m`;
}

function _TToast(msg, type = 'ok') {
  const t = document.createElement('div');
  t.className = `t-toast${type === 'err' ? ' err' : ''}`;
  t.textContent = msg;
  document.getElementById('t-toasts').appendChild(t);
  setTimeout(() => t.remove(), 3200);
}

function _TConfirm(msg) {
  return new Promise(resolve => {
    const bd = document.createElement('div');
    bd.className = 'modal-bd';
    bd.style.display = 'flex';
    bd.innerHTML = `<div class="modal-box" style="max-width:320px">
      <div class="modal-hdr">Confirm</div>
      <div class="modal-body" style="padding:16px 20px;font-size:15px;color:var(--ink2)">${_Tesc(msg)}</div>
      <div class="modal-foot">
        <button class="btn btn-outline" id="t-cfm-no">Cancel</button>
        <button class="btn" id="t-cfm-yes" style="background:var(--accent);color:#fff">Confirm</button>
      </div>
    </div>`;
    document.body.appendChild(bd);
    const cleanup = val => { bd.remove(); resolve(val); };
    bd.querySelector('#t-cfm-yes').onclick = () => cleanup(true);
    bd.querySelector('#t-cfm-no').onclick  = () => cleanup(false);
    bd.addEventListener('click', e => { if (e.target === bd) cleanup(false); });
  });
}

function _THandleExpiry() {
  window.location.href = '/tablet/login?reason=timeout';
}

// ── Fetch helpers ─────────────────────────────────────────────────────────────
async function _TFetch(path) {
  const res = await fetch(path, { credentials: 'include' });
  if (res.redirected || res.status === 401) { _THandleExpiry(); return null; }
  const j = await res.json();
  if (!j.ok) throw new Error(j.error || 'API error');
  return j.data;
}

function _TPost(path, body = {}) {
  return fetch(path, {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
}

function _TPatch(path, body = {}) {
  return fetch(path, {
    method: 'PATCH',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
}

function _TDelete(path) {
  return fetch(path, { method: 'DELETE', credentials: 'include' });
}

// ── Loading / error ───────────────────────────────────────────────────────────
function _TShowLoading(msg) {
  document.getElementById('t-app').innerHTML =
    `<div class="t-loading">${_Tesc(msg || 'Loading…')}</div>`;
}

function _TShowError(msg) {
  document.getElementById('t-app').innerHTML =
    `<div class="t-error">${_Tesc(msg)}</div>`;
}

// ── Init ──────────────────────────────────────────────────────────────────────
async function _TInit() {
  _TApplyTheme();
  _TShowLoading();
  try {
    const [tables, zones, items, twData, twQueue] = await Promise.all([
      _TFetch('/api/ts/tables'),
      _TFetch('/api/ts/zones'),
      _TFetch('/api/pos/items'),
      _TFetch('/api/ts/takeaway/table').catch(() => null),
      _TFetch('/api/ts/takeaway/queue').catch(() => []),
    ]);
    if (tables === null) return; // 401 handled
    _TTables          = tables || [];
    _TZones           = zones  || [];
    _TItems           = items  || [];
    _TTakeawayTableId = twData ? twData.table_id : null;
    _TTakeawayQueue   = twQueue || [];
    _TRenderFloor();
    _TStartRefresh();
  } catch (e) {
    _TShowError('Failed to load: ' + e.message);
  }
}

document.addEventListener('DOMContentLoaded', _TInit);

// ── Background refresh ────────────────────────────────────────────────────────
function _TStartRefresh() {
  _TClearRefresh();
  _TRefreshTimer = setInterval(_TRefreshBackground, 30000);
}

function _TClearRefresh() {
  if (_TRefreshTimer) { clearInterval(_TRefreshTimer); _TRefreshTimer = null; }
}

async function _TRefreshBackground() {
  if (_TViewMode === 'tab') return;
  try {
    const [tables, twQueue] = await Promise.all([
      _TFetch('/api/ts/tables'),
      _TFetch('/api/ts/takeaway/queue').catch(() => []),
    ]);
    if (tables === null) return;
    _TTables = tables;
    _TTakeawayQueue = twQueue || [];
    if (_TViewMode === 'floor') {
      _TRefreshFloorGrid();
    } else if (_TViewMode === 'takeaway') {
      const list = document.querySelector('.t-takeaway-list');
      if (list) list.innerHTML = _TTakeawayListHTML();
    }
  } catch (e) { /* silent */ }
}

// ── Sign out ──────────────────────────────────────────────────────────────────
async function _TSignOut() {
  try { await _TPost('/api/logout'); } catch (e) { /* ignore */ }
  window.location.href = '/tablet/login';
}

// ── Floor view ────────────────────────────────────────────────────────────────
function _TRenderFloor() {
  _TViewMode = 'floor';
  const twCount = _TTakeawayQueue.length;
  document.getElementById('t-app').innerHTML = `
    <div class="t-topbar">
      <div class="t-brand">d<span>box</span></div>
      <div class="t-zone-tabs" id="t-zone-tabs">
        <button class="t-zone-pill${_TZoneFilter === 'all' ? ' active' : ''}"
                data-zone="all" onclick="_TSetZone('all')">All</button>
        ${_TZones.map(z => `
          <button class="t-zone-pill${_TZoneFilter === String(z.id) ? ' active' : ''}"
                  data-zone="${z.id}" onclick="_TSetZone('${z.id}')">
            ${_Tesc(z.name)}
          </button>`).join('')}
      </div>
      <div class="t-topbar-actions">
        <button class="t-btn" onclick="_TGoTakeaway()">
          Takeaway${twCount ? ` <span class="t-badge">${twCount}</span>` : ''}
        </button>
        <button class="t-btn t-btn-ghost" onclick="_TSignOut()">Sign out</button>
      </div>
    </div>
    <div class="t-floor-grid" id="t-floor-grid">${_TFloorGridHTML()}</div>`;
}

function _TFloorGridHTML() {
  const filtered = _TZoneFilter === 'all'
    ? _TTables
    : _TTables.filter(t => String(t.zone_id) === _TZoneFilter);
  if (!filtered.length) return '<div class="t-empty">No tables</div>';
  return filtered.map(_TTableTileHTML).join('');
}

function _TTableTileHTML(t) {
  let cls = 't-table-tile';
  let statusLine = '';
  if (t.open_tab_status === 'Open') {
    cls += ' t-tile-open';
    statusLine = `<span class="t-tile-status">${_TElapsed(t.tab_opened_at)}</span>`;
  } else if (t.open_tab_status === 'Sent') {
    cls += ' t-tile-sent';
    statusLine = '<span class="t-tile-status">At register</span>';
  } else {
    cls += ' t-tile-free';
    statusLine = `<span class="t-tile-status">${t.seats || ''} seats</span>`;
  }
  const zoneLabel = t.zone_name ? `<span class="t-tile-zone">${_Tesc(t.zone_name)}</span>` : '';
  return `<div class="${cls}" onclick="_TOpenTable(${t.id},${t.open_tab_id || 'null'})">
    ${zoneLabel}
    <div class="t-tile-name">${_Tesc(t.name)}</div>
    ${statusLine}
  </div>`;
}

function _TSetZone(zoneId) {
  _TZoneFilter = String(zoneId);
  document.querySelectorAll('.t-zone-pill').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.zone === _TZoneFilter);
  });
  const grid = document.getElementById('t-floor-grid');
  if (grid) grid.innerHTML = _TFloorGridHTML();
}

function _TRefreshFloorGrid() {
  const grid = document.getElementById('t-floor-grid');
  if (grid) grid.innerHTML = _TFloorGridHTML();
  // Update takeaway badge
  const twBtn = document.querySelector('.t-topbar-actions .t-btn');
  if (twBtn) {
    const c = _TTakeawayQueue.length;
    twBtn.innerHTML = `Takeaway${c ? ` <span class="t-badge">${c}</span>` : ''}`;
  }
}

async function _TOpenTable(tableId, tabId) {
  if (tabId) {
    await _TRenderTab(tabId, 'floor');
  } else {
    const yes = await _TConfirm('Open a new tab for this table?');
    if (!yes) return;
    try {
      const r = await _TPost('/api/ts/tabs', { table_id: tableId });
      const j = await r.json();
      if (!j.ok) { _TToast(j.error || 'Failed to open tab', 'err'); return; }
      await _TRenderTab(j.data.id, 'floor');
    } catch (e) {
      _TToast('Error opening tab', 'err');
    }
  }
}

// ── Tab / order view ──────────────────────────────────────────────────────────
async function _TRenderTab(tabId, prevView) {
  _TClearRefresh();
  _TViewMode = 'tab';
  _TPrevView = prevView != null ? prevView : _TViewMode;
  _TCurrentTabId = tabId;
  _TItemSearch = '';
  _TCatFilter  = null;
  _TShowLoading();
  try {
    _TCurrentTab = await _TFetch(`/api/ts/tabs/${tabId}`);
    if (!_TCurrentTab) return;
    _TDrawTabView();
  } catch (e) {
    _TShowError('Failed to load tab: ' + e.message);
  }
}

function _TDrawTabView() {
  const tab = _TCurrentTab;
  const title = tab.is_takeaway
    ? (tab.label || 'Takeaway')
    : `${tab.zone_name ? tab.zone_name + ' — ' : ''}${tab.table_name}`;
  const isOpen = tab.status === 'Open';
  document.getElementById('t-app').innerHTML = `
    <div class="t-topbar">
      <button class="t-btn" onclick="_TBackToFloor()">← Back</button>
      <span class="t-panel-title">${_Tesc(title)}</span>
      <span class="t-tab-status t-status-${tab.status.toLowerCase()}">${tab.status}</span>
    </div>
    <div class="t-tab-shell">
      <div class="t-items-panel">
        <input class="t-search" id="t-search" type="search" placeholder="Search items…"
               oninput="_TSearchInput(this.value)" value="${_Tesc(_TItemSearch)}"
               autocomplete="off" autocorrect="off" spellcheck="false">
        <div class="t-cat-bar" id="t-cat-bar">${_TCatBarHTML()}</div>
        <div class="t-item-grid" id="t-item-grid">${_TItemGridHTML()}</div>
      </div>
      <div class="t-order-panel">
        <div class="t-order-hdr">
          <span class="t-order-title">Order</span>
          ${isOpen ? `<button class="t-btn t-btn-danger-sm" onclick="_TVoidTab()">Void</button>` : ''}
        </div>
        <div class="t-order-lines" id="t-order-lines">${_TOrderLinesHTML()}</div>
        <div class="t-order-foot" id="t-order-foot">${_TOrderFootHTML()}</div>
      </div>
    </div>`;
}

function _TCatBarHTML() {
  const cats = [...new Set(_TItems.map(i => i.pos_category).filter(Boolean))].sort();
  if (!cats.length) return '';
  return `<button class="t-cat-pill${!_TCatFilter ? ' active' : ''}" data-cat=""
                  onclick="_TSetCat(null)">All</button>` +
    cats.map(c => `<button class="t-cat-pill${_TCatFilter === c ? ' active' : ''}"
                           data-cat="${_Tesc(c)}" onclick="_TSetCat('${_Tesc(c)}')">${_Tesc(c)}</button>`).join('');
}

function _TItemGridHTML() {
  const isOpen = _TCurrentTab && _TCurrentTab.status === 'Open';
  let items = _TItems;
  if (_TItemSearch) {
    const q = _TItemSearch.toLowerCase();
    items = items.filter(i =>
      i.name.toLowerCase().includes(q) || (i.description || '').toLowerCase().includes(q)
    );
  }
  if (_TCatFilter) items = items.filter(i => i.pos_category === _TCatFilter);
  if (!items.length) return '<div class="t-empty">No items found</div>';
  return items.map(item => {
    const avail = item.is_available !== 0;
    const disabled = !isOpen || !avail;
    return `<div class="t-item-tile${disabled ? ' t-item-disabled' : ''}"
                 ${disabled ? '' : `onclick="_TPromptAdd(${item.id})"`}>
      <div class="t-item-name">${_Tesc(item.name)}</div>
      <div class="t-item-price">${_Tfmt(item.unit_price || 0)}</div>
      ${!avail ? '<div class="t-sold-out">Sold out</div>' : ''}
    </div>`;
  }).join('');
}

function _TOrderLinesHTML() {
  const items = _TCurrentTab ? _TCurrentTab.items : [];
  if (!items.length) return '<div class="t-empty-order">No items yet</div>';
  const isOpen = _TCurrentTab && _TCurrentTab.status === 'Open';
  return items.map(item => {
    const lineTotal = item.qty * item.unit_price * (item.tax_code === 'GST' ? 1.1 : 1.0);
    return `<div class="t-order-line">
      <div class="t-order-line-info">
        <div class="t-order-line-name">${_Tesc(item.description)}</div>
        ${item.note ? `<div class="t-order-line-note">${_Tesc(item.note)}</div>` : ''}
      </div>
      ${isOpen
        ? `<button class="t-qty-btn" onclick="_TQtyDelta(${item.id},-1)">−</button>
           <span class="t-qty">${item.qty}</span>
           <button class="t-qty-btn" onclick="_TQtyDelta(${item.id},1)">+</button>`
        : `<span class="t-qty-ro">×${item.qty}</span>`}
      <span class="t-line-total">${_Tfmt(lineTotal)}</span>
    </div>`;
  }).join('');
}

function _TOrderFootHTML() {
  const tab = _TCurrentTab;
  if (!tab) return '';
  const items = tab.items || [];
  let subtotal = 0, gst = 0;
  items.forEach(item => {
    const ex = item.qty * item.unit_price;
    gst      += item.tax_code === 'GST' ? ex * 0.1 : 0;
    subtotal += ex * (item.tax_code === 'GST' ? 1.1 : 1.0);
  });
  const isOpen   = tab.status === 'Open';
  const hasUnsent = items.some(i => !i.sent_to_kitchen);
  return `
    <div class="t-order-totals">
      <div class="t-total-row"><span>GST</span><span>${_Tfmt(gst)}</span></div>
      <div class="t-total-row t-total-main"><span>Total</span><span>${_Tfmt(subtotal)}</span></div>
    </div>
    <div class="t-order-actions">
      ${isOpen && items.length && hasUnsent
        ? `<button class="t-btn t-btn-outline" onclick="_TFireKitchen()">Fire Kitchen</button>` : ''}
      ${isOpen && items.length
        ? `<button class="t-btn t-btn-primary" onclick="_TOpenSettle()">Settle</button>` : ''}
      ${tab.status === 'Sent'
        ? `<button class="t-btn t-btn-primary" disabled>At Register</button>` : ''}
    </div>`;
}

function _TSearchInput(val) {
  _TItemSearch = val;
  const grid = document.getElementById('t-item-grid');
  if (grid) grid.innerHTML = _TItemGridHTML();
}

function _TSetCat(cat) {
  _TCatFilter = cat;
  const bar = document.getElementById('t-cat-bar');
  if (bar) bar.innerHTML = _TCatBarHTML();
  const grid = document.getElementById('t-item-grid');
  if (grid) grid.innerHTML = _TItemGridHTML();
}

async function _TRefreshTab() {
  if (!_TCurrentTabId) return;
  try {
    _TCurrentTab = await _TFetch(`/api/ts/tabs/${_TCurrentTabId}`);
    if (!_TCurrentTab) return;
    const lines = document.getElementById('t-order-lines');
    const foot  = document.getElementById('t-order-foot');
    if (lines) lines.innerHTML = _TOrderLinesHTML();
    if (foot)  foot.innerHTML  = _TOrderFootHTML();
  } catch (e) { /* silent */ }
}

// ── Add item ──────────────────────────────────────────────────────────────────
function _TPromptAdd(itemId) {
  const item = _TItems.find(i => i.id === itemId);
  if (!item) return;
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="max-width:340px">
    <div class="modal-hdr">${_Tesc(item.name)}</div>
    <div class="modal-body" style="padding:16px">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
        <button class="t-qty-btn" id="t-add-minus" style="font-size:22px">−</button>
        <input id="t-add-qty" type="number" min="0.5" step="0.5" value="1" inputmode="decimal"
               style="width:80px;text-align:center;font-size:22px;padding:8px;border:1.5px solid var(--border);border-radius:var(--radius);background:var(--entry-bg);color:var(--ink);outline:none">
        <button class="t-qty-btn" id="t-add-plus"  style="font-size:22px">+</button>
        <span style="margin-left:auto;font-weight:700;color:var(--ink);font-size:16px">${_Tfmt(item.unit_price || 0)}</span>
      </div>
      <input id="t-add-note" type="text" placeholder="Special request (optional)"
             autocomplete="off" autocorrect="off" spellcheck="false"
             style="width:100%;font-size:16px;padding:11px 14px;border:1.5px solid var(--border);border-radius:var(--radius);background:var(--entry-bg);color:var(--ink);outline:none">
    </div>
    <div class="modal-foot">
      <button class="btn btn-outline" id="t-add-cancel">Cancel</button>
      <button class="btn" id="t-add-confirm" style="background:var(--accent);color:#fff">Add to order</button>
    </div>
  </div>`;
  document.body.appendChild(bd);

  const qtyInput = bd.querySelector('#t-add-qty');
  bd.querySelector('#t-add-minus').onclick = () => {
    const v = parseFloat(qtyInput.value) || 1;
    if (v > 1) qtyInput.value = Math.round((v - 1) * 10) / 10;
  };
  bd.querySelector('#t-add-plus').onclick = () => {
    qtyInput.value = Math.round(((parseFloat(qtyInput.value) || 0) + 1) * 10) / 10;
  };
  bd.querySelector('#t-add-cancel').onclick = () => bd.remove();
  bd.querySelector('#t-add-confirm').onclick = async () => {
    const qty  = parseFloat(qtyInput.value) || 1;
    const note = bd.querySelector('#t-add-note').value.trim();
    bd.remove();
    await _TAddItem(item, qty, note);
  };
  bd.addEventListener('click', e => { if (e.target === bd) bd.remove(); });
  qtyInput.focus();
  qtyInput.select();
}

async function _TAddItem(item, qty, note) {
  const unitPriceEx = item.tax_code === 'GST'
    ? Math.round((item.unit_price / 1.1) * 1e8) / 1e8
    : (item.unit_price || 0);
  try {
    const r = await _TPost(`/api/ts/tabs/${_TCurrentTabId}/items`, {
      lines: [{
        item_id:    item.id,
        description: item.name,
        qty,
        unit_price: unitPriceEx,
        tax_code:   item.tax_code || 'GST',
        account_id: item.account_id || null,
        note:       note || null,
      }],
      fire_kitchen: false,
    });
    const j = await r.json();
    if (!j.ok) { _TToast(j.error || 'Failed to add item', 'err'); return; }
    await _TRefreshTab();
  } catch (e) {
    _TToast('Error adding item', 'err');
  }
}

// ── Qty adjustment ────────────────────────────────────────────────────────────
async function _TQtyDelta(tabItemId, delta) {
  const item = _TCurrentTab && _TCurrentTab.items.find(i => i.id === tabItemId);
  if (!item) return;
  const newQty = item.qty + delta;
  if (newQty <= 0) {
    const yes = await _TConfirm(`Remove "${item.description}" from the order?`);
    if (!yes) return;
    try {
      const r = await _TDelete(`/api/ts/tab-items/${tabItemId}`);
      const j = await r.json();
      if (!j.ok) { _TToast(j.error || 'Failed to remove', 'err'); return; }
      await _TRefreshTab();
    } catch (e) { _TToast('Error removing item', 'err'); }
    return;
  }
  try {
    const r = await _TPatch(`/api/ts/tab-items/${tabItemId}`, { qty: newQty });
    const j = await r.json();
    if (!j.ok) { _TToast(j.error || 'Failed to update', 'err'); return; }
    await _TRefreshTab();
  } catch (e) { _TToast('Error updating qty', 'err'); }
}

// ── Kitchen ───────────────────────────────────────────────────────────────────
async function _TFireKitchen() {
  try {
    const r = await _TPost(`/api/ts/tabs/${_TCurrentTabId}/fire-kitchen`);
    const j = await r.json();
    if (j.ok) {
      _TToast('Kitchen docket sent');
      await _TRefreshTab();
      return;
    }
    // Printer failed — offer manual confirm
    const yes = await _TConfirm('Could not reach kitchen printer. Mark as sent anyway?');
    if (!yes) return;
    const r2 = await _TPost(`/api/ts/tabs/${_TCurrentTabId}/confirm-kitchen`);
    const j2 = await r2.json();
    if (j2.ok) { _TToast('Kitchen confirmed manually'); await _TRefreshTab(); }
    else _TToast(j2.error || 'Failed to confirm', 'err');
  } catch (e) {
    _TToast('Error contacting kitchen', 'err');
  }
}

// ── Settlement ────────────────────────────────────────────────────────────────
function _TCalcTotal() {
  const items = (_TCurrentTab && _TCurrentTab.items) || [];
  let total = 0;
  items.forEach(i => { total += i.qty * i.unit_price * (i.tax_code === 'GST' ? 1.1 : 1.0); });
  return Math.round(total * 100) / 100;
}

function _TOpenSettle() {
  _TSettleMethod = 'cash';
  const total = _TCalcTotal();

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="max-width:400px;width:100%">
    <div class="modal-hdr">Settle — ${_Tfmt(total)}</div>
    <div class="modal-body" style="padding:16px">
      <div class="t-settle-tabs">
        <button class="t-settle-tab active" onclick="_TSetSettleTab(this,'cash')">Cash</button>
        <button class="t-settle-tab" onclick="_TSetSettleTab(this,'card')">Card</button>
        <button class="t-settle-tab" onclick="_TSetSettleTab(this,'account')">Account</button>
      </div>
      <div id="t-settle-body"></div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-outline" id="t-settle-cancel">Cancel</button>
      <button class="btn" id="t-settle-confirm" style="background:var(--green);color:#fff">Confirm payment</button>
    </div>
  </div>`;
  document.body.appendChild(bd);

  bd.querySelector('#t-settle-cancel').onclick = () => bd.remove();
  bd.addEventListener('click', e => { if (e.target === bd) bd.remove(); });

  const confirmBtn = bd.querySelector('#t-settle-confirm');
  confirmBtn.onclick = async () => {
    confirmBtn.disabled = true;
    confirmBtn.textContent = 'Processing…';
    let tendered = total;
    if (_TSettleMethod === 'cash') {
      const inp = bd.querySelector('#t-settle-tendered');
      tendered = parseFloat(inp ? inp.value : total) || total;
    }
    try {
      const r = await _TPost(`/api/ts/tabs/${_TCurrentTabId}/settle`, {
        tender:   _TSettleMethod,
        tendered: tendered,
      });
      const j = await r.json();
      if (!j.ok) {
        _TToast(j.error || 'Settlement failed', 'err');
        confirmBtn.disabled = false;
        confirmBtn.textContent = 'Confirm payment';
        return;
      }
      bd.remove();
      _TToast('Payment settled');
      await _TBackToFloor();
    } catch (e) {
      _TToast('Error processing payment', 'err');
      confirmBtn.disabled = false;
      confirmBtn.textContent = 'Confirm payment';
    }
  };

  // Render initial cash body
  _TRenderSettleCashBody(bd, total);
}

function _TSetSettleTab(el, method) {
  _TSettleMethod = method;
  el.closest('.t-settle-tabs').querySelectorAll('.t-settle-tab').forEach(b => {
    b.classList.toggle('active', b === el);
  });
  const bd    = el.closest('.modal-bd');
  const total = _TCalcTotal();
  if (method === 'cash') {
    _TRenderSettleCashBody(bd, total);
  } else if (method === 'card') {
    bd.querySelector('#t-settle-body').innerHTML = `
      <div style="margin-top:20px;text-align:center;padding:16px 0;color:var(--ink2);font-size:15px;line-height:1.5">
        Process <strong style="color:var(--ink)">${_Tfmt(total)}</strong> on your card terminal,<br>then tap <em>Confirm payment</em>.
      </div>`;
  } else {
    bd.querySelector('#t-settle-body').innerHTML = `
      <div style="margin-top:20px;text-align:center;padding:16px 0;color:var(--ink2);font-size:15px;line-height:1.5">
        This creates an account sale (invoice) for the customer.
      </div>`;
  }
}

function _TRenderSettleCashBody(bd, total) {
  bd.querySelector('#t-settle-body').innerHTML = `
    <div style="margin-top:20px">
      <label style="display:block;font-size:12px;font-weight:600;letter-spacing:0.8px;text-transform:uppercase;color:var(--ink3);margin-bottom:8px">Amount tendered</label>
      <input id="t-settle-tendered" type="number" inputmode="decimal" step="0.05"
             value="${total}"
             style="width:100%;font-size:28px;text-align:center;padding:14px;border:1.5px solid var(--border);border-radius:var(--radius);background:var(--entry-bg);color:var(--ink);outline:none;-webkit-appearance:none"
             oninput="_TUpdateChange(${total})">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-top:14px;font-size:18px;font-weight:700">
        <span style="color:var(--ink2)">Change</span>
        <span id="t-settle-change" style="color:var(--green)">${_Tfmt(0)}</span>
      </div>
    </div>`;
  const inp = bd.querySelector('#t-settle-tendered');
  if (inp) { inp.focus(); inp.select(); }
}

function _TUpdateChange(total) {
  const inp = document.getElementById('t-settle-tendered');
  const changeEl = document.getElementById('t-settle-change');
  if (!inp || !changeEl) return;
  const tendered = parseFloat(inp.value) || 0;
  changeEl.textContent = _Tfmt(Math.max(0, tendered - total));
}

// ── Void ──────────────────────────────────────────────────────────────────────
async function _TVoidTab() {
  const yes = await _TConfirm('Void this tab? This cannot be undone.');
  if (!yes) return;
  try {
    const r = await _TPost(`/api/ts/tabs/${_TCurrentTabId}/void`);
    const j = await r.json();
    if (!j.ok) { _TToast(j.error || 'Failed to void', 'err'); return; }
    _TToast('Tab voided');
    await _TBackToFloor();
  } catch (e) {
    _TToast('Error voiding tab', 'err');
  }
}

// ── Takeaway view ─────────────────────────────────────────────────────────────
async function _TGoTakeaway() {
  _TViewMode = 'takeaway';
  _TClearRefresh();
  _TShowLoading();
  try {
    _TTakeawayQueue = (await _TFetch('/api/ts/takeaway/queue')) || [];
    _TRenderTakeaway();
    _TStartRefresh();
  } catch (e) {
    _TShowError('Failed to load takeaway queue');
  }
}

function _TTakeawayListHTML() {
  if (!_TTakeawayQueue.length) {
    return '<div class="t-empty" style="padding:40px">No open takeaway orders</div>';
  }
  return _TTakeawayQueue.map(o => `
    <div class="t-tw-card" onclick="_TRenderTab(${o.id},'takeaway')">
      <div class="t-tw-label">${_Tesc(o.label || 'Order #' + o.id)}</div>
      <div class="t-tw-meta">
        <span class="t-tw-count">${o.item_count} item${o.item_count !== 1 ? 's' : ''}</span>
        <span class="t-tw-total">${_Tfmt(o.total)}</span>
        <span class="t-tw-status t-status-${o.status.toLowerCase()}">${o.status}</span>
      </div>
    </div>`).join('');
}

function _TRenderTakeaway() {
  _TViewMode = 'takeaway';
  document.getElementById('t-app').innerHTML = `
    <div class="t-topbar">
      <button class="t-btn" onclick="_TBackToFloor()">← Floor</button>
      <span class="t-panel-title">Takeaway Queue</span>
      <button class="t-btn t-btn-primary" onclick="_TNewTakeawayOrder()">+ New Order</button>
    </div>
    <div class="t-takeaway-list">${_TTakeawayListHTML()}</div>`;
}

function _TNewTakeawayOrder() {
  if (!_TTakeawayTableId) { _TToast('Takeaway not configured', 'err'); return; }
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="max-width:340px">
    <div class="modal-hdr">New Takeaway Order</div>
    <div class="modal-body" style="padding:16px">
      <label style="display:block;font-size:12px;font-weight:600;letter-spacing:0.8px;text-transform:uppercase;color:var(--ink3);margin-bottom:8px">Customer name or order label</label>
      <input id="t-tw-label" type="text" placeholder="e.g. John or #42"
             autocomplete="off" autocorrect="off" spellcheck="false"
             style="width:100%;font-size:16px;padding:11px 14px;border:1.5px solid var(--border);border-radius:var(--radius);background:var(--entry-bg);color:var(--ink);outline:none">
    </div>
    <div class="modal-foot">
      <button class="btn btn-outline" id="t-tw-cancel">Cancel</button>
      <button class="btn" id="t-tw-create" style="background:var(--accent);color:#fff">Create order</button>
    </div>
  </div>`;
  document.body.appendChild(bd);

  const labelInput = bd.querySelector('#t-tw-label');
  labelInput.focus();

  const create = async () => {
    const label = labelInput.value.trim();
    bd.remove();
    try {
      const r = await _TPost('/api/ts/tabs', { table_id: _TTakeawayTableId, label });
      const j = await r.json();
      if (!j.ok) { _TToast(j.error || 'Failed to create order', 'err'); return; }
      await _TRenderTab(j.data.id, 'takeaway');
    } catch (e) {
      _TToast('Error creating order', 'err');
    }
  };

  bd.querySelector('#t-tw-cancel').onclick = () => bd.remove();
  bd.querySelector('#t-tw-create').onclick  = create;
  labelInput.addEventListener('keydown', e => { if (e.key === 'Enter') create(); });
  bd.addEventListener('click', e => { if (e.target === bd) bd.remove(); });
}

// ── Navigation ────────────────────────────────────────────────────────────────
async function _TBackToFloor() {
  _TCurrentTabId = null;
  _TCurrentTab   = null;
  if (_TPrevView === 'takeaway') {
    await _TGoTakeaway();
    return;
  }
  // Refresh table data then render floor
  try {
    const [tables, twQueue] = await Promise.all([
      _TFetch('/api/ts/tables'),
      _TFetch('/api/ts/takeaway/queue').catch(() => []),
    ]);
    if (tables !== null) _TTables = tables;
    _TTakeawayQueue = twQueue || [];
  } catch (e) { /* use stale data */ }
  _TRenderFloor();
  _TStartRefresh();
}
