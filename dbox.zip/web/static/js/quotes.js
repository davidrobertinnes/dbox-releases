// ── Quotes Module (Standalone) ────────────────────────────────────────────────
// Uses the shared det-panel / det-overlay / det-title / det-body / det-foot
// pattern consistent with invoices.js, bills.js, crm.js.
//
// Line-item form rendering delegates to qfAddLine / qfRenderLines / qfCalc
// defined in crm.js — _crmQuoteLines is the shared line state.

let _qAll = [], _qFilter = 'All', _qSort = {col:'quote_date', dir:-1}, _qSearch = '';
let _qSelected = null;

// ── Panel helpers ─────────────────────────────────────────────────────────────
function _qPanelOpen() {
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
}

function _qPanelLoading(title) {
  _qPanelOpen();
  document.getElementById('det-title').textContent = title || 'Quote';
  document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading\u2026</div>';
  document.getElementById('det-foot').innerHTML = '';
}

// ── Page entry ────────────────────────────────────────────────────────────────
async function pageQuotes() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading\u2026</div>';
  try {
    _qAll = await apiFetch('/api/quotes');
  } catch(e) {
    mod.innerHTML = `<div class="state-error">Failed to load quotes: ${esc(e.message)}</div>`;
    return;
  }
  _qSelected = null;
  renderQPage();
}

// ── Filter / sort ─────────────────────────────────────────────────────────────
function _qFiltered() {
  let list = _qAll.slice();
  if (_qFilter !== 'All') list = list.filter(q => q.status === _qFilter);
  const s = _qSearch.trim().toLowerCase();
  if (s) list = list.filter(q =>
    (q.quote_number||'').toLowerCase().includes(s) ||
    (q.contact_name||'').toLowerCase().includes(s) ||
    (q.opp_title||'').toLowerCase().includes(s)
  );
  const {col, dir} = _qSort;
  list.sort((a, b) => {
    let av = a[col] ?? '', bv = b[col] ?? '';
    if (!isNaN(parseFloat(av)) && !isNaN(parseFloat(bv)))
      return (parseFloat(av) - parseFloat(bv)) * dir;
    return String(av).localeCompare(String(bv)) * dir;
  });
  return list;
}

function _qCounts() {
  const c = {All: _qAll.length};
  _qAll.forEach(q => { c[q.status] = (c[q.status]||0)+1; });
  return c;
}

function qSetFilter(f) { _qFilter = f; renderQPage(); }

function qSortBy(col) {
  _qSort = {col, dir: _qSort.col===col ? _qSort.dir*-1 : -1};
  renderQPage();
}

// ── Render list ───────────────────────────────────────────────────────────────
function renderQPage(restoreFocus) {
  const mod      = document.getElementById('module-content');
  const counts   = _qCounts();
  const filtered = _qFiltered();
  const pills    = ['All','Draft','Sent','Accepted','Invoiced','Declined','Superseded'];

  // Build sort-class helper — matches bills.js / crm.js pattern
  const thCls = col => {
    if (_qSort.col !== col) return '';
    return _qSort.dir > 0 ? 'sort-asc' : 'sort-desc';
  };

  mod.innerHTML = `
  <div class="inv-toolbar">
    <input id="q-search" class="inv-search" placeholder="Search quotes\u2026" value="${esc(_qSearch)}" oninput="_qSearch=this.value;renderQPage(true)">
    <div class="inv-filter-group">
      ${pills.map(f => `<button class="filter-btn${_qFilter===f?' active':''}" onclick="qSetFilter('${f}')">
        ${f}${counts[f] ? ` <span class="filter-count">(${counts[f]})</span>` : ''}
      </button>`).join('')}
    </div>
    <button class="btn btn-primary" onclick="qNew()">+ New Quote</button>
  </div>

  <div class="inv-list-panel">
    <div class="tbl-overflow-x">
      <table class="inv-list-table">
        <thead><tr>
          <th onclick="qSortBy('quote_number')" class="${thCls('quote_number')}">Quote #</th>
          <th onclick="qSortBy('quote_date')"   class="${thCls('quote_date')}">Date</th>
          <th onclick="qSortBy('contact_name')" class="${thCls('contact_name')}">Contact</th>
          <th onclick="qSortBy('opp_title')"    class="${thCls('opp_title')}">Opportunity</th>
          <th onclick="qSortBy('status')"       class="${thCls('status')}">Status</th>
          <th onclick="qSortBy('expiry_date')"  class="${thCls('expiry_date')}">Expires</th>
          <th onclick="qSortBy('total')"        class="th-r ${thCls('total')}">Total</th>
        </tr></thead>
        <tbody>
          ${filtered.length
            ? filtered.map(q => _qRow(q)).join('')
            : '<tr class="tbl-empty-row"><td colspan="7">No quotes found</td></tr>'}
        </tbody>
      </table>
    </div>
  </div>
  <div class="mt-8"><span class="count-pill">${filtered.length} of ${_qAll.length} quotes</span></div>`;
  if (restoreFocus) { const qi = document.getElementById('q-search'); if(qi){qi.focus();qi.setSelectionRange(qi.value.length,qi.value.length);} }
}

function _qRow(q) {
  const expired = q.expiry_date && q.expiry_date < isoToday()
                  && !['Accepted','Invoiced','Declined','Superseded'].includes(q.status);
  return `<tr class="inv-row${expired?' is-overdue':''}" onclick="qOpen(${q.id})">
    <td><span class="inv-mono">${esc(q.quote_number||'—')}</span></td>
    <td><span class="inv-mono">${fmtDate(q.quote_date)}</span></td>
    <td><span class="inv-contact">${esc(q.contact_name||'—')}</span></td>
    <td class="td-ref">${q.opp_title ? esc(q.opp_title) : '<em>Standalone</em>'}</td>
    <td>${quoteStageBadge(q.status)}</td>
    <td class="${expired?'col-red':'inv-mono'}">${q.expiry_date ? fmtDate(q.expiry_date) : '—'}</td>
    <td class="inv-amt">${fmt(q.total)}</td>
  </tr>`;
}

// ── Detail slide-over ─────────────────────────────────────────────────────────
async function qOpen(qid) {
  _qSelected = qid;
  _qPanelLoading('Quote');
  let data;
  try { data = await apiFetch(`/api/crm/quotes/${qid}`); }
  catch(e) {
    document.getElementById('det-body').innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
    return;
  }
  _renderQDetail(data);
}

function _renderQDetail(data) {
  const q = data.quote, lines = data.lines||[];

  const isInvoiced = q.status === 'Invoiced' || !!q.invoice_id;
  const canEdit    = !isInvoiced;
  const canAccept  = ['Draft','Sent'].includes(q.status);
  const canConvert = q.status === 'Accepted' && !q.invoice_id;

  document.getElementById('det-title').textContent = q.quote_number || 'Quote';

  const linesHtml = `
    <table class="det-lines">
      <thead><tr>
        <th>Description</th>
        <th class="th-r">Qty</th>
        <th class="th-r">Unit Price</th>
        <th>Tax</th>
        <th class="th-r">Total</th>
      </tr></thead>
      <tbody>
        ${lines.map(l => `<tr>
          <td>${esc(l.description)}</td>
          <td class="td-r-mono">${l.quantity}</td>
          <td class="td-r-mono">${fmt(l.unit_price)}</td>
          <td><span class="inv-mono">${esc(l.tax_code||'GST')}</span></td>
          <td class="td-r-mono">${fmt(l.line_total)}</td>
        </tr>`).join('')}
      </tbody>
    </table>
    <div class="det-totals">
      <div class="det-tot-row"><span>Subtotal</span><span>${fmt(q.subtotal)}</span></div>
      <div class="det-tot-row"><span>GST (10%)</span><span>${fmt(q.gst_total)}</span></div>
      <div class="det-tot-row grand"><span>Total</span><span>${fmt(q.total)}</span></div>
    </div>`;

  document.getElementById('det-body').innerHTML = `
  ${isInvoiced ? `<div class="stp-notice">
    &#9432; This quote has been invoiced. To make corrections, void the invoice and reissue.
  </div>` : ''}

  <div class="det-badge-row">
    ${quoteStageBadge(q.status)}
  </div>

  <div class="det-meta">
    <div><div class="det-lbl">Quote #</div>
      <div class="det-val mono">${esc(q.quote_number)}</div></div>
    <div><div class="det-lbl">Date</div>
      <div class="det-val mono">${fmtDate(q.quote_date)}</div></div>
    <div><div class="det-lbl">Expires</div>
      <div class="det-val mono">${q.expiry_date ? fmtDate(q.expiry_date) : '&mdash;'}</div></div>
    <div><div class="det-lbl">Contact</div>
      <div class="det-val">${esc(q.contact_name||'—')}</div></div>
    <div><div class="det-lbl">Opportunity</div>
      <div class="det-val">${q.opp_title
        ? esc(q.opp_title)
        : '<em class="col-ink3">Standalone</em>'}</div></div>
    <div><div class="det-lbl">Status</div>
      <div class="det-val">${esc(q.status)}</div></div>
    ${q.accepted_date ? `<div><div class="det-lbl">Accepted</div>
      <div class="det-val mono">${fmtDate(q.accepted_date)}</div></div>` : ''}
    ${q.accepted_by ? `<div><div class="det-lbl">Accepted By</div>
      <div class="det-val">${esc(q.accepted_by)}</div></div>` : ''}
    ${q.invoice_id ? `<div><div class="det-lbl">Invoice</div>
      <div class="det-val"><a href="#" onclick="invOpen(${q.invoice_id});return false"
        class="lnk-accent">#${q.invoice_id}</a></div></div>` : ''}
  </div>

  ${q.intro_text ? `<div class="det-section-block">
    <div class="det-lbl det-lbl-gap">Intro</div>
    <div class="det-note">${esc(q.intro_text)}</div>
  </div>` : ''}

  ${linesHtml}

  ${q.terms_text ? `<div class="det-section-top">
    <div class="det-lbl det-lbl-gap">Terms &amp; Conditions</div>
    <div class="det-note">${esc(q.terms_text)}</div>
  </div>` : ''}

  ${q.internal_notes ? `<div class="det-section-top">
    <div class="det-lbl det-lbl-gap">Internal Notes</div>
    <div class="det-note">${esc(q.internal_notes)}</div>
  </div>` : ''}`;

  const foot = document.getElementById('det-foot');
  foot.innerHTML = '';
  const addBtn = (label, cls, fn) => {
    const b = document.createElement('button');
    b.className = `btn ${cls}`; b.innerHTML = label; b.onclick = fn;
    foot.appendChild(b);
  };

  addBtn('+ New Quote', 'btn-outline', qNew);
  addBtn('&#9113; PDF',  'btn-outline', () => window.open(`/api/crm/quotes/${q.id}/pdf`));
  addBtn('&#9993; Email','btn-outline', () => window.open(`/api/crm/quotes/${q.id}/pdf`)); // email via PDF for now
  if (canEdit)    addBtn('&#9998; Edit',               'btn-outline', () => qEdit(q.id));
  if (canAccept)  addBtn('&#10003; Accept',             'btn-primary', () => qAccept(q.id));
  if (canConvert) addBtn('&rarr; Convert to Invoice',  'btn-primary', () => qConvert(q.id));
  if (isInvoiced) {
    const s = document.createElement('span');
    s.className = 'badge badge-paid'; s.innerHTML = '&#10003; Invoiced';
    foot.appendChild(s);
  }
  if (canEdit) {
    const spacer = document.createElement('div');
    spacer.style.marginLeft = 'auto'; foot.appendChild(spacer);
    addBtn('Delete', 'btn-danger', () => qDelete(q.id));
  }
}

// ── New / Edit form ───────────────────────────────────────────────────────────
async function qNew() {
  _qPanelLoading('New Quote');
  let contacts = [];
  try { contacts = await apiFetch('/api/contacts'); } catch(_) {}
  await _ensureQMeta(contacts);
  window._crmQuoteLines = [{description:'',quantity:1,unit_price:0,tax_code:'GST',item_id:null}];
  _renderQForm(
    {quote_date: isoToday(),
     expiry_date: isoAddDays(30),
     status: 'Draft'},
    null, false
  );
}

async function qEdit(qid) {
  _qPanelLoading('Edit Quote');
  let data, contacts = [];
  try {
    [data, contacts] = await Promise.all([
      apiFetch(`/api/crm/quotes/${qid}`),
      apiFetch('/api/contacts'),
    ]);
  } catch(e) {
    document.getElementById('det-body').innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
    return;
  }
  await _ensureQMeta(contacts);
  const defLine = {description:'',quantity:1,unit_price:0,tax_code:'GST',item_id:null};
  window._crmQuoteLines = (data.lines||[]).length
    ? data.lines.map(l => ({...defLine, ...l}))
    : [defLine];
  _renderQForm(data.quote, qid, true);
}

async function _ensureQMeta(contacts) {
  window._crmContacts = contacts;
  if (!window._crmMeta) {
    try { window._crmMeta = await apiFetch('/api/crm/meta'); } catch(_) {}
  }
  if (!window._crmMeta)
    window._crmMeta = {quote_status:['Draft','Sent','Accepted','Declined','Superseded']};
}

function _renderQForm(q, qid, isEdit) {
  const statuses = window._crmMeta?.quote_status || ['Draft','Sent','Accepted','Declined','Superseded'];
  const conOpts  = (window._crmContacts||[]).map(c =>
    `<option value="${c.id}"${c.id===q.contact_id?' selected':''}>${esc(c.name)}</option>`).join('');

  document.getElementById('det-title').textContent = isEdit
    ? `Edit ${q.quote_number||'Quote'}` : 'New Quote';

  document.getElementById('det-body').innerHTML = `
  <div class="edt-grid edt-grid-mb">
    <div class="edt-field"><label class="edt-lbl">Quote Date *</label>
      <input class="edt-inp" id="qf-date" type="date" value="${q.quote_date||''}"></div>
    <div class="edt-field"><label class="edt-lbl">Expiry Date</label>
      <input class="edt-inp" id="qf-expiry" type="date" value="${q.expiry_date||''}"></div>
    <div class="edt-field"><label class="edt-lbl">Contact</label>
      <select class="edt-sel" id="qf-contact">
        <option value="">— Select contact —</option>${conOpts}
      </select></div>
    <div class="edt-field"><label class="edt-lbl">Status</label>
      <select class="edt-sel" id="qf-status">
        ${statuses.map(s=>`<option${s===q.status?' selected':''}>${s}</option>`).join('')}
      </select></div>
    <div class="edt-field edt-span"><label class="edt-lbl">Intro Text</label>
      <textarea class="edt-ta" id="qf-intro"
        placeholder="Optional intro paragraph shown on the quote\u2026">${esc(q.intro_text||'')}</textarea></div>
  </div>

  <div class="edt-section-lbl">Line Items</div>
  <div class="edt-lines-hdr">
    <span>Description</span><span>Qty</span><span>Unit Price</span>
    <span>Tax</span><span>GST</span><span>Total</span><span></span>
  </div>
  <div id="qf-lines"></div>
  <button class="btn btn-outline edt-add-btn" onclick="qfAddLine()">+ Add Line</button>
  <div class="edt-totals-preview" id="qf-totals"></div>

  <div class="edt-divider"></div>
  <div class="edt-grid">
    <div class="edt-field edt-span"><label class="edt-lbl">Terms &amp; Conditions</label>
      <textarea class="edt-ta" id="qf-terms"
        placeholder="Payment terms, validity, conditions\u2026">${esc(q.terms_text||'')}</textarea></div>
    <div class="edt-field edt-span"><label class="edt-lbl">Internal Notes</label>
      <textarea class="edt-ta" id="qf-notes"
        placeholder="Internal notes (not shown on quote PDF)">${esc(q.internal_notes||'')}</textarea></div>
  </div>`;

  const foot = document.getElementById('det-foot');
  foot.innerHTML = '';
  const addBtn = (label, cls, fn, id) => {
    const b = document.createElement('button');
    b.className = `btn ${cls}`; b.innerHTML = label;
    if (id) b.id = id;
    b.onclick = fn; foot.appendChild(b);
  };
  addBtn(isEdit ? 'Save Changes' : 'Create Quote', 'btn-primary', () => qSave(qid||null), 'qf-save-btn');
  addBtn('Cancel', 'btn-outline', () => isEdit ? qOpen(qid) : detClose());

  qfRenderLines();
}

// ── Save ──────────────────────────────────────────────────────────────────────
async function qSave(qid) {
  const dateVal = document.getElementById('qf-date')?.value;
  if (!dateVal) { toast('Quote date is required', 'error'); return; }
  const lines = (window._crmQuoteLines||[]).filter(l => (l.description||'').trim());
  if (!lines.length) { toast('Add at least one line item', 'error'); return; }

  const btn = document.getElementById('qf-save-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving\u2026'; }

  // When editing, preserve the existing opp_id — never overwrite it with null
  let opp_id = null;
  if (qid) {
    // Find the existing quote in _qAll to retrieve its opp_id
    const existing = _qAll.find(q => q.id === qid);
    opp_id = existing?.opp_id ?? null;
  }

  const body = {
    quote: {
      ...(qid ? {id: qid} : {}),
      opp_id,
      contact_id:     parseInt(document.getElementById('qf-contact')?.value||0)||null,
      quote_date:     dateVal,
      expiry_date:    document.getElementById('qf-expiry')?.value||null,
      status:         document.getElementById('qf-status')?.value||'Draft',
      intro_text:     document.getElementById('qf-intro')?.value.trim()||null,
      terms_text:     document.getElementById('qf-terms')?.value.trim()||null,
      internal_notes: document.getElementById('qf-notes')?.value.trim()||null,
    },
    lines: lines.map(l => ({
      description: l.description, quantity: l.quantity,
      unit_price: l.unit_price, tax_code: l.tax_code||'GST',
      item_id: l.item_id||null,
    })),
  };

  try {
    const method = qid ? 'PUT' : 'POST';
    const url    = qid ? `/api/crm/quotes/${qid}` : '/api/crm/quotes';
    const r = await fetch(url, {
      method, credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(body),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error||'Save failed');
    toast(qid ? 'Quote updated' : 'Quote created');
    _qAll = await apiFetch('/api/quotes');
    renderQPage();
    const savedId = qid || j.data?.id;
    if (savedId) qOpen(savedId);
  } catch(e) {
    toast(e.message, 'error');
    if (btn) { btn.disabled = false; btn.textContent = qid ? 'Save Changes' : 'Create Quote'; }
  }
}

// ── Accept / Convert / Delete ─────────────────────────────────────────────────
async function qAccept(qid) {
  if (!await confirmDlg('Mark this quote as Accepted?')) return;
  try {
    const r = await fetch(`/api/crm/quotes/${qid}/accept`, {method:'POST', credentials:'include'});
    const j = await r.json(); if (!j.ok) throw new Error(j.error||'Failed');
    toast('Quote accepted');
    _qAll = await apiFetch('/api/quotes');
    renderQPage();
    qOpen(qid);
  } catch(e) { toast(e.message, 'error'); }
}

async function qConvert(qid) {
  if (!await confirmDlg('Convert this accepted quote to a draft invoice?')) return;
  try {
    const r = await fetch(`/api/crm/quotes/${qid}/convert`, {method:'POST', credentials:'include'});
    const j = await r.json(); if (!j.ok) throw new Error(j.error||'Failed');
    toast('Invoice created');
    detClose();
    _qAll = await apiFetch('/api/quotes');
    setTimeout(() => { navigate('invoices'); setTimeout(() => invOpen(j.data.invoice_id), 400); }, 400);
  } catch(e) { toast(e.message, 'error'); }
}

async function qDelete(qid) {
  if (!await confirmDlg('Delete this quote? This cannot be undone.')) return;
  try {
    const r = await fetch(`/api/crm/quotes/${qid}`, {method:'DELETE', credentials:'include'});
    const j = await r.json(); if (!j.ok) throw new Error(j.error||'Delete failed');
    toast('Quote deleted');
    detClose();
    _qAll = await apiFetch('/api/quotes');
    renderQPage();
  } catch(e) { toast(e.message, 'error'); }
}
