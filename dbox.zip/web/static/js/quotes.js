// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ── Quotes Module (Standalone) ────────────────────────────────────────────────
// Uses the shared det-panel / det-overlay / det-title / det-body / det-foot
// pattern consistent with invoices.js, bills.js, crm.js.
//
// Line-item form rendering delegates to qfAddLine / qfRenderLines / qfCalc
// defined in crm.js — _crmQuoteLines is the shared line state.

let _qAll = [], _qFilter = 'All', _qSort = {col:'quote_date', dir:-1}, _qSearch = '';
let _qSelected = null;

// ── Panel helpers ─────────────────────────────────────────────────────────────
function _qPanelOpen() {
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
}

function _qPanelLoading(title) {
  _qPanelOpen();
  document.getElementById('det-title').textContent = title || 'Quote';
  document.getElementById('det-body').innerHTML = '<div class="state-loading">Loading\u2026</div>';
  document.getElementById('det-foot').innerHTML = '';
}

// ── Page entry ────────────────────────────────────────────────────────────────
async function pageQuotes() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading\u2026</div>';
  try {
    _qAll = await apiFetch('/api/quotes');
  } catch(e) {
    mod.innerHTML = `<div class="state-error">Failed to load quotes: ${esc(e.message)}</div>`;
    return;
  }
  _qSelected = null;
  renderQPage();
}

// ── Filter / sort ─────────────────────────────────────────────────────────────
function _qFiltered() {
  let list = _qAll.slice();
  if (_qFilter !== 'All') list = list.filter(q => q.status === _qFilter);
  const s = _qSearch.trim().toLowerCase();
  if (s) list = list.filter(q =>
    (q.quote_number||'').toLowerCase().includes(s) ||
    (q.contact_name||'').toLowerCase().includes(s) ||
    (q.opp_title||'').toLowerCase().includes(s)
  );
  const {col, dir} = _qSort;
  list.sort((a, b) => {
    let av = a[col] ?? '', bv = b[col] ?? '';
    if (!isNaN(parseFloat(av)) && !isNaN(parseFloat(bv)))
      return (parseFloat(av) - parseFloat(bv)) * dir;
    return String(av).localeCompare(String(bv)) * dir;
  });
  return list;
}

function _qCounts() {
  const c = {All: _qAll.length};
  _qAll.forEach(q => { c[q.status] = (c[q.status]||0)+1; });
  return c;
}

function qSetFilter(f) { _qFilter = f; renderQPage(); }

function qSortBy(col) {
  _qSort = {col, dir: _qSort.col===col ? _qSort.dir*-1 : -1};
  renderQPage();
}

// ── Render list ───────────────────────────────────────────────────────────────
function renderQPage(restoreFocus) {
  const mod      = document.getElementById('module-content');
  const counts   = _qCounts();
  const filtered = _qFiltered();
  const pills    = ['All','Draft','Sent','Accepted','Invoiced','Declined','Superseded'];

  // Build sort-class helper — matches bills.js / crm.js pattern
  const thCls = col => {
    if (_qSort.col !== col) return '';
    return _qSort.dir > 0 ? 'sort-asc' : 'sort-desc';
  };

  mod.innerHTML = `
  <div class="inv-toolbar">
    <input id="q-search" class="inv-search" placeholder="Search quotes\u2026" value="${esc(_qSearch)}" oninput="_qSearch=this.value;renderQPage(true)">
    <div class="inv-filter-group">
      ${pills.map(f => `<button class="filter-btn${_qFilter===f?' active':''}" onclick="qSetFilter('${f}')">
        ${f}${counts[f] ? ` <span class="filter-count">(${counts[f]})</span>` : ''}
      </button>`).join('')}
    </div>
    <button class="btn btn-primary" onclick="qNew()">+ New Quote</button>
  </div>

  <div class="inv-list-panel">
    <div class="tbl-overflow-x">
      <table class="inv-list-table">
        <thead><tr>
          <th onclick="qSortBy('quote_number')" class="${thCls('quote_number')}">Quote #</th>
          <th onclick="qSortBy('quote_date')"   class="${thCls('quote_date')}">Date</th>
          <th onclick="qSortBy('contact_name')" class="${thCls('contact_name')}">Contact</th>
          <th onclick="qSortBy('opp_title')"    class="${thCls('opp_title')}">Opportunity</th>
          <th onclick="qSortBy('status')"       class="${thCls('status')}">Status</th>
          <th onclick="qSortBy('expiry_date')"  class="${thCls('expiry_date')}">Expires</th>
          <th onclick="qSortBy('total')"        class="th-r ${thCls('total')}">Total</th>
        </tr></thead>
        <tbody>
          ${filtered.length
            ? filtered.map(q => _qRow(q)).join('')
            : '<tr class="tbl-empty-row"><td colspan="7">No quotes found</td></tr>'}
        </tbody>
      </table>
    </div>
  </div>
  <div class="mt-8"><span class="count-pill">${filtered.length} of ${_qAll.length} quotes</span></div>`;
  if (restoreFocus) { const qi = document.getElementById('q-search'); if(qi){qi.focus();qi.setSelectionRange(qi.value.length,qi.value.length);} }
}

function _qRow(q) {
  const expired = q.expiry_date && q.expiry_date < isoToday()
                  && !['Accepted','Invoiced','Declined','Superseded'].includes(q.status);
  return `<tr class="inv-row${expired?' is-overdue':''}" onclick="qOpen(${q.id})">
    <td><span class="inv-mono">${esc(q.quote_number||'—')}</span></td>
    <td><span class="inv-mono">${fmtDate(q.quote_date)}</span></td>
    <td><span class="inv-contact">${esc(q.contact_name||'—')}</span></td>
    <td class="td-ref">${q.opp_title ? esc(q.opp_title) : '<em>Standalone</em>'}</td>
    <td>${quoteStageBadge(q.status)}</td>
    <td class="${expired?'col-red':'inv-mono'}">${q.expiry_date ? fmtDate(q.expiry_date) : '—'}</td>
    <td class="inv-amt">${fmt(q.total)}</td>
  </tr>`;
}

// ── Detail slide-over ─────────────────────────────────────────────────────────
async function qOpen(qid) {
  _qSelected = qid;
  _qPanelLoading('Quote');
  let data;
  try { data = await apiFetch(`/api/crm/quotes/${qid}`); }
  catch(e) {
    document.getElementById('det-body').innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
    return;
  }
  _renderQDetail(data);
}

function _renderQDetail(data) {
  const q = data.quote, lines = data.lines||[];

  const isInvoiced = q.status === 'Invoiced' || !!q.invoice_id;
  const canEdit    = !isInvoiced;
  const canAccept  = ['Draft','Sent'].includes(q.status);
  const canConvert = q.status === 'Accepted' && !q.invoice_id;

  document.getElementById('det-title').textContent = q.quote_number || 'Quote';

  const linesHtml = `
    <table class="det-lines">
      <thead><tr>
        <th>Description</th>
        <th class="th-r">Qty</th>
        <th class="th-r">Unit Price</th>
        <th>Tax</th>
        <th class="th-r">Total</th>
      </tr></thead>
      <tbody>
        ${lines.map(l => l.line_type==='comment'
          ? `<tr class="inv-comment-row"><td colspan="5">${esc(l.description)}</td></tr>`
          : `<tr>
          <td>${esc(l.description)}</td>
          <td class="td-r-mono">${l.quantity}</td>
          <td class="td-r-mono">${fmt(l.unit_price)}</td>
          <td><span class="inv-mono">${esc(l.tax_code||'GST')}</span></td>
          <td class="td-r-mono">${fmt(l.line_total)}</td>
        </tr>`).join('')}
      </tbody>
    </table>
    <div class="det-totals">
      <div class="det-tot-row"><span>Subtotal</span><span>${fmt(q.subtotal)}</span></div>
      <div class="det-tot-row"><span>GST (10%)</span><span>${fmt(q.gst_total)}</span></div>
      <div class="det-tot-row grand"><span>Total</span><span>${fmt(q.total)}</span></div>
    </div>`;

  document.getElementById('det-body').innerHTML = `
  ${isInvoiced ? `<div class="stp-notice">
    &#9432; This quote has been invoiced. To make corrections, void the invoice and reissue.
  </div>` : ''}

  <div class="det-badge-row">
    ${quoteStageBadge(q.status)}
  </div>

  <div class="det-meta">
    <div><div class="det-lbl">Quote #</div>
      <div class="det-val mono">${esc(q.quote_number)}</div></div>
    <div><div class="det-lbl">Date</div>
      <div class="det-val mono">${fmtDate(q.quote_date)}</div></div>
    <div><div class="det-lbl">Expires</div>
      <div class="det-val mono">${q.expiry_date ? fmtDate(q.expiry_date) : '&mdash;'}</div></div>
    <div><div class="det-lbl">Contact</div>
      <div class="det-val">${esc(q.contact_name||'—')}</div></div>
    <div><div class="det-lbl">Opportunity</div>
      <div class="det-val">${q.opp_title
        ? esc(q.opp_title)
        : '<em class="col-ink3">Standalone</em>'}</div></div>
    <div><div class="det-lbl">Status</div>
      <div class="det-val">${esc(q.status)}</div></div>
    ${q.accepted_date ? `<div><div class="det-lbl">Accepted</div>
      <div class="det-val mono">${fmtDate(q.accepted_date)}</div></div>` : ''}
    ${q.accepted_by ? `<div><div class="det-lbl">Accepted By</div>
      <div class="det-val">${esc(q.accepted_by)}</div></div>` : ''}
    ${q.invoice_id ? `<div><div class="det-lbl">Invoice</div>
      <div class="det-val"><a href="#" onclick="invOpen(${q.invoice_id});return false"
        class="lnk-accent">#${q.invoice_id}</a></div></div>` : ''}
  </div>

  ${q.intro_text ? `<div class="det-section-block">
    <div class="det-lbl det-lbl-gap">Intro</div>
    <div class="det-note">${esc(q.intro_text)}</div>
  </div>` : ''}

  ${linesHtml}

  ${q.terms_text ? `<div class="det-section-top">
    <div class="det-lbl det-lbl-gap">Terms &amp; Conditions</div>
    <div class="det-note">${esc(q.terms_text)}</div>
  </div>` : ''}

  ${q.internal_notes ? `<div class="det-section-top">
    <div class="det-lbl det-lbl-gap">Internal Notes</div>
    <div class="det-note">${esc(q.internal_notes)}</div>
  </div>` : ''}`;

  const foot = document.getElementById('det-foot');
  foot.innerHTML = '';
  const addBtn = (label, cls, fn) => {
    const b = document.createElement('button');
    b.className = `btn ${cls}`; b.innerHTML = label; b.onclick = fn;
    foot.appendChild(b);
  };

  addBtn('+ New Quote', 'btn-outline', qNew);
  addBtn('&#9113; PDF',  'btn-outline', () => window.open(`/api/crm/quotes/${q.id}/pdf`));
  addBtn('&#9993; Email','btn-outline', () => qEmailOpen(q));
  if (canEdit)    addBtn('&#9998; Edit',               'btn-outline', () => qEdit(q.id));
  if (canAccept)  addBtn('&#10003; Accept',             'btn-primary', () => qAccept(q.id));
  if (canConvert) addBtn('&rarr; Convert to Invoice',  'btn-primary', () => qConvert(q.id));
  if (isInvoiced) {
    const s = document.createElement('span');
    s.className = 'badge badge-paid'; s.innerHTML = '&#10003; Invoiced';
    foot.appendChild(s);
  }
  if (canEdit) {
    const spacer = document.createElement('div');
    spacer.style.marginLeft = 'auto'; foot.appendChild(spacer);
    addBtn('Delete', 'btn-danger', () => qDelete(q.id));
  }
}

// ── New / Edit form ───────────────────────────────────────────────────────────
async function qNew() {
  _qPanelLoading('New Quote');
  let contacts = [];
  try { contacts = await apiFetch('/api/contacts'); } catch(_) {}
  await _ensureQMeta(contacts);
  _crmQuoteLines = [{description:'',quantity:1,unit_price:0,tax_code:'GST',account_id:null,item_id:null,line_type:'item'}];
  _renderQForm(
    {quote_date: isoToday(),
     expiry_date: isoAddDays(30),
     status: 'Draft'},
    null, false
  );
}

async function qEdit(qid) {
  _qPanelLoading('Edit Quote');
  let data, contacts = [];
  try {
    [data, contacts] = await Promise.all([
      apiFetch(`/api/crm/quotes/${qid}`),
      apiFetch('/api/contacts'),
    ]);
  } catch(e) {
    document.getElementById('det-body').innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
    return;
  }
  await _ensureQMeta(contacts);
  const defLine = {description:'',quantity:1,unit_price:0,tax_code:'GST',account_id:null,item_id:null,line_type:'item'};
  _crmQuoteLines = (data.lines||[]).length
    ? data.lines.map(l => ({...defLine, ...l}))
    : [defLine];
  _renderQForm(data.quote, qid, true);
}

async function _ensureQMeta(contacts) {
  window._crmContacts = contacts;
  if (!window._crmMeta) {
    try { window._crmMeta = await apiFetch('/api/crm/meta'); } catch(_) {}
  }
  if (!window._crmMeta)
    window._crmMeta = {quote_status:['Draft','Sent','Accepted','Declined','Superseded']};
  if (!window._crmEditAccts) {
    try {
      const accts = await apiFetch('/api/accounts');
      window._crmEditAccts = (accts||[]).filter(a => ['Revenue','Income','Other Income'].includes(a.account_type));
      if (!window._crmEditAccts.length) window._crmEditAccts = (accts||[]).filter(a => a.account_type);
    } catch(_) { window._crmEditAccts = []; }
  }
}

async function _crmQNewContact() {
  const c = await quickNewContact('Customer');
  if (!c) return;
  if (window._crmContacts) window._crmContacts.push(c);
  const sel = document.getElementById('qf-contact');
  if (sel) sel.appendChild(new Option(c.name, c.id, true, true));
}

function _renderQForm(q, qid, isEdit) {
  const statuses = window._crmMeta?.quote_status || ['Draft','Sent','Accepted','Declined','Superseded'];
  const conOpts  = (window._crmContacts||[]).map(c =>
    `<option value="${c.id}"${c.id===q.contact_id?' selected':''}>${esc(c.name)}</option>`).join('');

  document.getElementById('det-title').textContent = isEdit
    ? `Edit ${q.quote_number||'Quote'}` : 'New Quote';

  document.getElementById('det-body').innerHTML = `
  <div class="edt-grid edt-grid-mb">
    <div class="edt-field"><label class="edt-lbl">Quote Date *</label>
      <input class="edt-inp" id="qf-date" type="date" value="${q.quote_date||''}"></div>
    <div class="edt-field"><label class="edt-lbl">Expiry Date</label>
      <input class="edt-inp" id="qf-expiry" type="date" value="${q.expiry_date||''}"></div>
    <div class="edt-field">
      <div class="lbl-line">
        <label class="edt-lbl">Contact</label>
        <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();_crmQNewContact()">+ New</a>
      </div>
      <select class="edt-sel" id="qf-contact">
        <option value="">— Select contact —</option>${conOpts}
      </select></div>
    <div class="edt-field"><label class="edt-lbl">Status</label>
      <select class="edt-sel" id="qf-status">
        ${statuses.map(s=>`<option${s===q.status?' selected':''}>${s}</option>`).join('')}
      </select></div>
    <div class="edt-field edt-span"><label class="edt-lbl">Intro Text</label>
      <textarea class="edt-ta" id="qf-intro"
        placeholder="Optional intro paragraph shown on the quote\u2026">${esc(q.intro_text||'')}</textarea></div>
  </div>

  <div class="edt-section-lbl">Line Items</div>
  <div class="edt-lines-hdr">
    <span></span><span>Description</span><span>Qty</span><span>Unit Price</span>
    <span>Tax</span><span>GST</span><span>Total</span><span></span>
  </div>
  <div id="qf-lines"></div>
  <button class="btn btn-outline edt-add-btn" onclick="qfAddLine()">+ Add Line</button>
  <div class="edt-totals-preview" id="qf-totals"></div>

  <div class="edt-divider"></div>
  <div class="edt-grid">
    <div class="edt-field edt-span"><label class="edt-lbl">Terms &amp; Conditions</label>
      <textarea class="edt-ta" id="qf-terms"
        placeholder="Payment terms, validity, conditions\u2026">${esc(q.terms_text||'')}</textarea></div>
    <div class="edt-field edt-span"><label class="edt-lbl">Internal Notes</label>
      <textarea class="edt-ta" id="qf-notes"
        placeholder="Internal notes (not shown on quote PDF)">${esc(q.internal_notes||'')}</textarea></div>
  </div>`;

  const foot = document.getElementById('det-foot');
  foot.innerHTML = '';
  const addBtn = (label, cls, fn, id) => {
    const b = document.createElement('button');
    b.className = `btn ${cls}`; b.innerHTML = label;
    if (id) b.id = id;
    b.onclick = fn; foot.appendChild(b);
  };
  addBtn(isEdit ? 'Save Changes' : 'Create Quote', 'btn-primary', () => qSave(qid||null), 'qf-save-btn');
  addBtn('Cancel', 'btn-outline', () => isEdit ? qOpen(qid) : detClose());

  qfRenderLines();
}

// ── Save ──────────────────────────────────────────────────────────────────────
async function qSave(qid) {
  const dateVal = document.getElementById('qf-date')?.value;
  if (!dateVal) { toast('Quote date is required', 'err'); return; }
  const lines = (_crmQuoteLines||[]).filter(l => (l.description||'').trim());
  if (!lines.length) { toast('Add at least one line item', 'err'); return; }

  const btn = document.getElementById('qf-save-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving\u2026'; }

  // When editing, preserve the existing opp_id — never overwrite it with null
  let opp_id = null;
  if (qid) {
    // Find the existing quote in _qAll to retrieve its opp_id
    const existing = _qAll.find(q => q.id === qid);
    opp_id = existing?.opp_id ?? null;
  }

  const body = {
    quote: {
      ...(qid ? {id: qid} : {}),
      opp_id,
      contact_id:     parseInt(document.getElementById('qf-contact')?.value||0)||null,
      quote_date:     dateVal,
      expiry_date:    document.getElementById('qf-expiry')?.value||null,
      status:         document.getElementById('qf-status')?.value||'Draft',
      intro_text:     document.getElementById('qf-intro')?.value.trim()||null,
      terms_text:     document.getElementById('qf-terms')?.value.trim()||null,
      internal_notes: document.getElementById('qf-notes')?.value.trim()||null,
    },
    lines: lines.map(l => ({
      description: l.description,
      quantity:    l.line_type==='comment' ? 0 : l.quantity,
      unit_price:  l.line_type==='comment' ? 0 : l.unit_price,
      tax_code:    l.tax_code||'GST',
      account_id:  l.account_id||null,
      item_id:     l.item_id||null,
      line_type:   l.line_type||'item',
    })),
  };

  try {
    const method = qid ? 'PUT' : 'POST';
    const url    = qid ? `/api/crm/quotes/${qid}` : '/api/crm/quotes';
    const r = await fetch(url, {
      method, credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(body),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error||'Save failed');
    toast(qid ? 'Quote updated' : 'Quote created');
    _qAll = await apiFetch('/api/quotes');
    renderQPage();
    const savedId = qid || j.data?.id;
    if (savedId) qOpen(savedId);
  } catch(e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = qid ? 'Save Changes' : 'Create Quote'; }
  }
}

// ── Accept / Convert / Delete ─────────────────────────────────────────────────
async function qAccept(qid) {
  if (!await confirmDlg('Mark this quote as Accepted?')) return;
  try {
    const r = await fetch(`/api/crm/quotes/${qid}/accept`, {method:'POST', credentials:'include'});
    const j = await r.json(); if (!j.ok) throw new Error(j.error||'Failed');
    toast('Quote accepted');
    _qAll = await apiFetch('/api/quotes');
    renderQPage();
    qOpen(qid);
  } catch(e) { toast(e.message, 'err'); }
}

async function qConvert(qid) {
  if (!await confirmDlg('Convert this accepted quote to a draft invoice?')) return;
  try {
    const r = await fetch(`/api/crm/quotes/${qid}/convert`, {method:'POST', credentials:'include'});
    const j = await r.json(); if (!j.ok) throw new Error(j.error||'Failed');
    toast('Invoice created');
    detClose();
    _qAll = await apiFetch('/api/quotes');
    setTimeout(() => { navigate('invoices'); setTimeout(() => invOpen(j.data.invoice_id), 400); }, 400);
  } catch(e) { toast(e.message, 'err'); }
}

async function qDelete(qid) {
  if (!await confirmDlg('Delete this quote? This cannot be undone.')) return;
  try {
    const r = await fetch(`/api/crm/quotes/${qid}`, {method:'DELETE', credentials:'include'});
    const j = await r.json(); if (!j.ok) throw new Error(j.error||'Delete failed');
    toast('Quote deleted');
    detClose();
    _qAll = await apiFetch('/api/quotes');
    renderQPage();
  } catch(e) { toast(e.message, 'err'); }
}

async function qEmailOpen(q) {
  const num = q.quote_number || ('#' + q.id);
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="width:min(560px,96vw)">
    <div class="modal-title">✉ Email Quote ${esc(num)}</div>
    <div class="modal-field"><label class="modal-lbl">To *</label>
      <input class="modal-inp" type="email" id="qeml-to" placeholder="recipient@example.com"></div>
    <div class="modal-field"><label class="modal-lbl">Subject</label>
      <input class="modal-inp" type="text" id="qeml-subj" value="${esc('Quote ' + num)}"></div>
    <div class="modal-field"><label class="modal-lbl">Message</label>
      <textarea class="modal-inp" id="qeml-body" rows="5" style="resize:vertical;min-height:90px"></textarea></div>
    <div class="modal-acts">
      <button class="btn btn-outline btn-sm" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary btn-sm" id="qeml-send-btn" onclick="_qDoEmail(${q.id})">📧 Send</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  try {
    const contact = q.contact_id ? await apiFetch(`/api/contacts/${q.contact_id}`) : null;
    if (contact?.email) document.getElementById('qeml-to').value = contact.email;
    document.getElementById('qeml-body').value =
      `Please find attached quote ${num}.\n\nThank you for your interest — please don't hesitate to contact us with any questions.`;
  } catch(e) {}
}

async function _qDoEmail(id) {
  const to = (document.getElementById('qeml-to')?.value || '').trim();
  if (!to) { toast('Recipient email is required', 'err'); return; }
  const btn = document.getElementById('qeml-send-btn');
  btn.disabled = true; btn.textContent = 'Sending…';
  try {
    const r = await fetch(`/api/crm/quotes/${id}/email`, {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        to,
        subject: document.getElementById('qeml-subj')?.value || '',
        body:    document.getElementById('qeml-body')?.value || '',
      }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Send failed');
    btn.closest('.modal-bd')?.remove();
    toast('Quote emailed');
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = '📧 Send';
  }
}

// ── Badge helper ─────────────────────────────────────────────────────────────
function quoteStageBadge(s) {
  const map = { Draft:'qs-draft', Sent:'qs-sent', Accepted:'qs-accepted',
                Declined:'qs-declined', Superseded:'qs-superseded', Invoiced:'qs-invoiced' };
  return `<span class="quote-status-badge ${map[s]||'qs-draft'}">${esc(s||'—')}</span>`;
}

// ── Quote line-item editing ───────────────────────────────────────────────────
// Previously lived in the deleted crm.js. Uses _crmQuoteLines state.

function qfRenderLines() {
  const el = document.getElementById('qf-lines');
  if (!el) return;
  const accts = window._crmEditAccts || [];
  el.innerHTML = (_crmQuoteLines || []).map((l, i) => {
    const isComment = l.line_type === 'comment';
    const toggleBtn = `<button class="edt-type-btn${isComment ? ' is-comment' : ''}"
      title="${isComment ? 'Switch to item' : 'Switch to comment'}"
      onclick="qfToggleType(${i})">${isComment ? 'T' : '≡'}</button>`;

    if (isComment) {
      return `
        <div class="edt-line-wrap" id="qf-line-${i}">
          <div class="edt-line-row edt-comment-row">
            ${toggleBtn}
            <textarea class="edt-inp edt-comment-ta" id="qf-desc-${i}"
              placeholder="Comment or heading…"
              oninput="_crmQuoteLines[${i}].description=this.value">${esc(l.description || '')}</textarea>
            <button class="edt-rm-btn" onclick="qfRemoveLine(${i})">✕</button>
          </div>
        </div>`;
    }

    const ex  = parseFloat(l.quantity || 1) * parseFloat(l.unit_price || 0);
    const g   = l.tax_code === 'GST' ? Math.round(ex * 0.1 * 100) / 100 : 0;
    const tot = Math.round((ex + g) * 100) / 100;
    const acctOpts = accts.map(a =>
      `<option value="${a.id}"${a.id === l.account_id ? ' selected' : ''}>${esc((a.code ? a.code + ' ' : '') + a.name)}</option>`
    ).join('');

    return `
      <div class="edt-line-wrap" id="qf-line-${i}">
        <div class="edt-line-row">
          ${toggleBtn}
          <input class="edt-inp" type="text" id="qf-desc-${i}" value="${esc(l.description || '')}"
            placeholder="Description…"
            oninput="_crmQuoteLines[${i}].description=this.value">
          <input class="edt-inp" type="number" id="qf-qty-${i}" step="0.01" min="0" value="${l.quantity || 1}"
            oninput="_crmQuoteLines[${i}].quantity=parseFloat(this.value)||0;qfLineCalc(${i})">
          <input class="edt-inp" type="number" id="qf-price-${i}" step="0.01" min="0" value="${l.unit_price || 0}"
            oninput="_crmQuoteLines[${i}].unit_price=parseFloat(this.value)||0;qfLineCalc(${i})">
          <select class="edt-sel" onchange="_crmQuoteLines[${i}].tax_code=this.value;qfLineCalc(${i})">
            ${['GST', 'FRE', 'N-T'].map(tc => `<option${(l.tax_code || 'GST') === tc ? ' selected' : ''}>${tc}</option>`).join('')}
          </select>
          <span class="edt-calc" id="qf-gst-${i}">${fmt(g)}</span>
          <span class="edt-calc edt-calc-total" id="qf-tot-${i}">${fmt(tot)}</span>
          <button class="edt-rm-btn" onclick="qfRemoveLine(${i})">✕</button>
        </div>
        <div class="edt-line-acct">
          <span class="edt-acct-lbl">Account</span>
          <select class="edt-sel edt-acct-sel" id="qf-acct-${i}"
            onchange="_crmQuoteLines[${i}].account_id=this.value?+this.value:null">
            <option value="">— default (Sales) —</option>${acctOpts}
          </select>
        </div>
      </div>`;
  }).join('');
  qfCalc();
}

function qfAddLine() {
  if (!_crmQuoteLines) _crmQuoteLines = [];
  _crmQuoteLines.push({ description: '', quantity: 1, unit_price: 0, tax_code: 'GST', account_id: null, item_id: null, line_type: 'item' });
  qfRenderLines();
}

function qfRemoveLine(i) {
  _crmQuoteLines.splice(i, 1);
  if (!_crmQuoteLines.length) {
    _crmQuoteLines = [{ description: '', quantity: 1, unit_price: 0, tax_code: 'GST', account_id: null, item_id: null, line_type: 'item' }];
  }
  qfRenderLines();
}

function qfToggleType(i) {
  const l = _crmQuoteLines[i];
  l.line_type = l.line_type === 'comment' ? 'item' : 'comment';
  if (l.line_type === 'comment') { l.quantity = 0; l.unit_price = 0; l.account_id = null; l.item_id = null; }
  else { l.quantity = 1; l.unit_price = 0; }
  qfRenderLines();
}

function qfLineCalc(i) {
  const l = _crmQuoteLines[i];
  if (l.line_type === 'comment') { qfCalc(); return; }
  const ex  = parseFloat(l.quantity || 0) * parseFloat(l.unit_price || 0);
  const g   = l.tax_code === 'GST' ? Math.round(ex * 0.1 * 100) / 100 : 0;
  const tot = Math.round((ex + g) * 100) / 100;
  const gEl = document.getElementById(`qf-gst-${i}`);
  const tEl = document.getElementById(`qf-tot-${i}`);
  if (gEl) gEl.textContent = fmt(g);
  if (tEl) tEl.textContent = fmt(tot);
  qfCalc();
}

function qfCalc() {
  let sub = 0, gst = 0;
  (_crmQuoteLines || []).forEach(l => {
    if (l.line_type === 'comment') return;
    const ex = parseFloat(l.quantity || 0) * parseFloat(l.unit_price || 0);
    const g  = l.tax_code === 'GST' ? Math.round(ex * 0.1 * 100) / 100 : 0;
    sub += ex; gst += g;
  });
  sub = Math.round(sub * 100) / 100;
  gst = Math.round(gst * 100) / 100;
  const el = document.getElementById('qf-totals');
  if (el) el.innerHTML = `
    <span>Subtotal <b>${fmt(sub)}</b></span>
    <span>GST <b>${fmt(gst)}</b></span>
    <span class="grand">Total <b>${fmt(Math.round((sub + gst) * 100) / 100)}</b></span>`;
}
