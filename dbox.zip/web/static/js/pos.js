// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// Point of Sale — _pos prefix for all globals
'use strict';

let _posItems     = [];   // full item catalogue from server
let _posCart      = [];   // [{item_id, description, qty, unit_price, tax_code, account_id, total, gst}]
let _posSearch    = '';
let _posPollTimer = null;
let _posSession   = null; // {id, opened_at} or null
let _posSettings  = {};   // cached settings (for auto_print flag)
let _posContacts      = [];   // all contacts for customer picker
let _posContactId     = null; // selected contact for current sale (null = use walk-in default)
let _posLastFloat     = 0;    // float_kept from last closed session
let _posPendingReport = null; // report passed between Z-report close steps
let _posHistorySales  = [];   // loaded sales for history modal filtering
let _posRefundLines   = [];   // line items staged for refund
let _posRefundInvoiceId = null; // invoice being refunded
let _posPinUserId      = null;   // user_id of signed-in operator (null = no PIN required)
let _posPinUserName    = null;   // display_name of signed-in operator
let _posCatFilter           = null;   // active category pill (null = All)
let _posCurrentReceipt      = null;   // stored receipt params for reprint
let _posStockWarnProceedFn  = null;   // callback stored for stock warning modal

function _esc(s) {
  return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}


// ═══════════════════════════════════════════════════════════════════════════
// ENTRY POINT
// ═══════════════════════════════════════════════════════════════════════════

async function pagePos() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    const [items, sessionData, settings, contacts] = await Promise.all([
      apiFetch('/api/pos/items'),
      apiFetch('/api/pos/session').catch(() => ({})),
      apiFetch('/api/pos/settings').catch(() => ({})),
      apiFetch('/api/contacts').catch(() => []),
    ]);
    _posItems    = items;
    _posSession  = sessionData?.session ?? null;
    _posLastFloat = sessionData?.last_float ?? 0;
    _posSettings = settings;
    _posContacts = contacts;
    _posCart           = [];
    _posSearch         = '';
    _posContactId      = null;
    _posCatFilter      = null;
    _posCurrentReceipt = null;
    _posRender();
  } catch(e) {
    toast(e.message || 'Failed to load POS', 'err');
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// LAYOUT
// ═══════════════════════════════════════════════════════════════════════════

function _posRender() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = `
    <div class="pos-wrap">
      <div class="pos-items-panel">
        <div class="pos-search-bar">
          <input class="pos-search-inp" type="text" id="pos-search"
                 placeholder="Search items or scan barcode…"
                 autocomplete="off"
                 oninput="_posFilter(this.value)">
          <button class="pos-search-clear" onclick="_posClearSearch()" title="Clear">&#x2715;</button>
          <button class="pos-custom-btn" onclick="_posAddCustomItem()" title="Custom line item">+ Custom</button>
          <button class="pos-custom-btn" onclick="_posOpenHistory()" title="Sales history">History</button>
          <button class="pos-custom-btn" onclick="_posOpenDrawer()" title="Open cash drawer">&#x23CF; Drawer</button>
          <button class="pos-gear-btn" onclick="_posOpenSettings()" title="POS Settings">&#x2699;</button>
        </div>
        <div class="pos-cat-bar" id="pos-cat-bar"></div>
        <div class="pos-grid" id="pos-grid"></div>
      </div>
      <div class="pos-cart-panel">
        <div class="pos-cart-hdr">
          <span>Cart</span>
          <div class="pos-cart-hdr-btns">
            <button class="pos-zrpt-btn" onclick="_posOpenSessionHistory()">Sessions</button>
            <button class="pos-zrpt-btn" onclick="_posOpenZReport()">Z-Report</button>
            <button class="pos-clear-btn" onclick="_posClearCart()">Clear</button>
          </div>
        </div>
        <div class="pos-session-bar" id="pos-session-bar"></div>
        <div class="pos-customer-bar" id="pos-customer-bar"></div>
        <div class="pos-cart-lines" id="pos-cart-lines"></div>
        <div class="pos-cart-footer">
          <div class="pos-totals" id="pos-totals"></div>
          <div class="pos-tender-btns" id="pos-tender-btns"></div>
        </div>
      </div>
    </div>`;
  setTimeout(() => document.getElementById('pos-search')?.focus(), 80);
  _posRenderCatBar();
  _posRenderGrid();
  _posRenderCart();
  _posRenderSessionBar();
}


// ═══════════════════════════════════════════════════════════════════════════
// ITEM GRID
// ═══════════════════════════════════════════════════════════════════════════

function _posRenderCatBar() {
  const bar = document.getElementById('pos-cat-bar');
  if (!bar) return;
  const cats = [...new Set(_posItems.map(i => i.account_name).filter(Boolean))].sort();
  if (cats.length < 2) { bar.style.display = 'none'; return; }
  bar.style.display = '';
  bar.innerHTML = '';

  const mkPill = (label, active, onClick) => {
    const btn = document.createElement('button');
    btn.className = active ? 'pos-cat-pill active' : 'pos-cat-pill';
    btn.textContent = label;
    btn.addEventListener('click', onClick);
    return btn;
  };

  bar.appendChild(mkPill('All', _posCatFilter === null, () => {
    _posCatFilter = null; _posRenderCatBar(); _posRenderGrid();
  }));
  cats.forEach(cat => {
    bar.appendChild(mkPill(cat, _posCatFilter === cat, () => {
      _posCatFilter = cat; _posRenderCatBar(); _posRenderGrid();
    }));
  });
}

function _posFilter(q) {
  _posSearch = q.toLowerCase();
  _posRenderGrid();
}

function _posClearSearch() {
  _posSearch = '';
  const inp = document.getElementById('pos-search');
  if (inp) inp.value = '';
  _posRenderGrid();
  inp?.focus();
}

function _posTileStockBadge(item) {
  if (!item.is_inventoried) return '';
  const qty = parseFloat(item.qty_on_hand) || 0;
  const reorder = parseFloat(item.reorder_level) || 0;
  const label = qty <= 0 ? 'Out of stock' : (qty % 1 === 0 ? qty : qty.toFixed(1)) + ' in stock';
  const cls   = qty <= 0 ? 'pos-tile-stock out' : (qty <= reorder ? 'pos-tile-stock low' : 'pos-tile-stock');
  return '<div class="' + cls + '">' + label + '</div>';
}

function _posRenderGrid() {
  const grid = document.getElementById('pos-grid');
  if (!grid) return;
  const q = _posSearch;
  let visible = q
    ? _posItems.filter(i =>
        (i.name    || '').toLowerCase().includes(q) ||
        (i.code    || '').toLowerCase().includes(q) ||
        (i.barcode || '').toLowerCase().includes(q))
    : _posItems;
  if (_posCatFilter) visible = visible.filter(i => i.account_name === _posCatFilter);

  if (!visible.length) {
    grid.innerHTML = `<div class="pos-empty">${q ? 'No items match “' + _esc(q) + '”' : 'No items in catalogue'}</div>`;
    return;
  }
  grid.innerHTML = visible.map(i => {
    const stockBadge = _posTileStockBadge(i);
    return `
    <div class="pos-tile${i.promo_name ? ' pos-tile-promo-active' : ''}" onclick="_posAddItem(${i.id})" title="${_esc(i.name)}">
      ${i.promo_name ? `<div class="pos-tile-promo-badge">${_esc(i.promo_name)}</div>` : ''}
      <div class="pos-tile-name">${_esc(i.name)}</div>
      ${i.code ? `<div class="pos-tile-code">${_esc(i.code)}</div>` : ''}
      <div class="pos-tile-price">
        ${i.standard_price != null ? `<span class="pos-tile-was">$${i.standard_price.toFixed(2)}</span>` : ''}
        $${(i.unit_price || 0).toFixed(2)}
      </div>
      ${stockBadge}
    </div>`;
  }).join('');
}


// ═══════════════════════════════════════════════════════════════════════════
// CART
// ═══════════════════════════════════════════════════════════════════════════

function _posAddItem(itemId) {
  const item = _posItems.find(i => i.id === itemId);
  if (!item) return;
  const existing = _posCart.find(l => l.item_id === itemId);
  if (existing) {
    existing.qty++;
    _posCalcLine(existing);
  } else {
    const line = {
      item_id:     item.id,
      description: item.name,
      qty:         1,
      unit_price:  item.unit_price || 0,
      tax_code:    item.tax_code || 'GST',
      account_id:  item.account_id || null,
    };
    _posCalcLine(line);
    _posCart.push(line);
  }
  _posRenderCart();
}

function _posCalcLine(line) {
  const gst_rate = line.tax_code === 'GST' ? 0.1 : 0;
  line.total = Math.round(line.qty * line.unit_price * 100) / 100;
  line.gst   = Math.round(line.total * gst_rate / (1 + gst_rate) * 100) / 100;
}

function _posQtyDelta(idx, delta) {
  const line = _posCart[idx];
  if (!line) return;
  line.qty = Math.max(1, line.qty + delta);
  _posCalcLine(line);
  _posRenderCart();
}

function _posSetQty(idx, val) {
  const line = _posCart[idx];
  if (!line) return;
  const n = parseFloat(val);
  line.qty = (isNaN(n) || n <= 0) ? 1 : Math.round(n * 1000) / 1000;
  _posCalcLine(line);
  _posRenderCart();
}

function _posRemoveLine(idx) {
  _posCart.splice(idx, 1);
  _posRenderCart();
}

function _posPriceChange(idx, val) {
  const line = _posCart[idx];
  if (!line) return;
  const p = parseFloat(val);
  line.unit_price = (isNaN(p) || p < 0) ? 0 : Math.round(p * 100) / 100;
  _posCalcLine(line);
  _posRenderCart();
}

function _posAddCustomItem() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-custom-bd';
  bd.innerHTML = `<div class="modal-box" style="max-width:380px">
    <div class="modal-hdr">Custom Item</div>
    <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
      <div>
        <label class="pos-sett-lbl">Description</label>
        <input class="pos-sett-inp" id="pos-cust-desc" type="text" placeholder="e.g. Delivery, Labour, Misc"
               autocomplete="off" maxlength="100">
      </div>
      <div>
        <label class="pos-sett-lbl">Unit Price (inc. GST)</label>
        <div class="pos-till-input-wrap">
          <span class="pos-till-dollar">$</span>
          <input class="pos-till-inp" id="pos-cust-price" type="number" min="0" step="0.01"
                 placeholder="0.00" style="width:100px">
        </div>
      </div>
      <div>
        <label class="pos-sett-check">
          <input type="checkbox" id="pos-cust-gst" checked>
          GST applies (10%)
        </label>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn" onclick="document.getElementById('pos-custom-bd').remove()">Cancel</button>
      <button class="btn btn-primary" onclick="_posConfirmCustomItem()">Add to Cart</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  setTimeout(() => document.getElementById('pos-cust-desc')?.focus(), 50);
}

function _posConfirmCustomItem() {
  const desc  = (document.getElementById('pos-cust-desc')?.value || '').trim();
  const price = parseFloat(document.getElementById('pos-cust-price')?.value || 0) || 0;
  const gst   = document.getElementById('pos-cust-gst')?.checked ?? true;
  if (!desc) { toast('Description is required', 'err'); return; }
  if (price <= 0) { toast('Price must be greater than zero', 'err'); return; }
  const line = {
    item_id:     null,
    description: desc,
    qty:         1,
    unit_price:  Math.round(price * 100) / 100,
    tax_code:    gst ? 'GST' : 'N-T',
    account_id:  null,
  };
  _posCalcLine(line);
  _posCart.push(line);
  document.getElementById('pos-custom-bd')?.remove();
  _posRenderCart();
}

function _posClearCart() {
  _posCart      = [];
  _posContactId = null;
  _posRenderCart();
}

function _posRenderCustomerBar() {
  const el = document.getElementById('pos-customer-bar');
  if (!el) return;
  const name = _posContactId
    ? (_posContacts.find(c => c.id == _posContactId)?.name || 'Unknown')
    : null;
  el.innerHTML = name
    ? `<div class="pos-cust-row pos-cust-set">
         <span class="pos-cust-icon">👤</span>
         <span class="pos-cust-name">${_esc(name)}</span>
         <button class="pos-cust-clear" onclick="_posClearCustomer()" title="Remove customer">✕</button>
       </div>`
    : `<button class="pos-cust-btn" onclick="_posPickCustomer()">+ Add Customer</button>`;
}

function _posClearCustomer() {
  _posContactId = null;
  _posRenderCustomerBar();
}

function _posPickCustomer() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-cust-modal';
  bd.innerHTML = `<div class="modal-box" style="max-width:420px">
    <div class="modal-hdr">
      <span>Select Customer</span>
      <button class="modal-close" onclick="this.closest('.modal-bd').remove()">✕</button>
    </div>
    <div class="modal-body" style="padding-top:10px">
      <input type="text" class="pos-sett-inp" id="pos-cust-search" placeholder="Search contacts…"
             oninput="_posCustFilter(this.value)" autocomplete="off" style="margin-bottom:10px">
      <div id="pos-cust-list" class="pos-cust-list"></div>
    </div>
  </div>`;
  document.body.appendChild(bd);
  _posCustFilter('');
  setTimeout(() => document.getElementById('pos-cust-search')?.focus(), 50);
}

function _posCustFilter(q) {
  const el = document.getElementById('pos-cust-list');
  if (!el) return;
  const lq = q.toLowerCase();
  const matches = _posContacts.filter(c => !lq || c.name.toLowerCase().includes(lq));
  if (!matches.length) { el.innerHTML = '<div class="pos-cust-empty">No contacts found</div>'; return; }
  el.innerHTML = matches.slice(0, 50).map(c =>
    `<div class="pos-cust-option" onclick="_posSelectCustomer(${c.id})">${_esc(c.name)}</div>`
  ).join('');
}

function _posSelectCustomer(id) {
  _posContactId = id;
  document.getElementById('pos-cust-modal')?.remove();
  _posRenderCustomerBar();
}

function _posRenderCart() {
  _posRenderCustomerBar();
  const linesEl  = document.getElementById('pos-cart-lines');
  const totalsEl = document.getElementById('pos-totals');
  const btnsEl   = document.getElementById('pos-tender-btns');
  if (!linesEl) return;

  if (!_posCart.length) {
    linesEl.innerHTML  = '<div class="pos-cart-empty">Cart is empty—tap items to add</div>';
    totalsEl.innerHTML = '';
    btnsEl.innerHTML   = `
      <button class="pos-btn pos-btn-cash" disabled>Cash</button>
      <button class="pos-btn pos-btn-card" disabled>Card</button>
      <button class="pos-btn pos-btn-split" disabled>Split</button>`;
    return;
  }

  linesEl.innerHTML = _posCart.map((l, idx) => `
    <div class="pos-cart-line">
      <div class="pos-cart-desc">${_esc(l.description)}</div>
      <div class="pos-cart-qty">
        <button class="pos-qty-btn" onclick="_posQtyDelta(${idx},-1)">&#x2212;</button>
        <input class="pos-qty-inp" type="number" min="0.001" step="0.001" value="${l.qty}"
               onchange="_posSetQty(${idx},this.value)" onclick="this.select()">
        <button class="pos-qty-btn" onclick="_posQtyDelta(${idx},1)">+</button>
      </div>
      <div class="pos-price-wrap">
        <span class="pos-price-dollar">$</span>
        <input class="pos-price-inp" type="number" min="0" step="0.01"
               value="${l.unit_price.toFixed(2)}"
               onchange="_posPriceChange(${idx},this.value)" onclick="this.select()"
               title="Unit price">
      </div>
      <div class="pos-cart-price">$${l.total.toFixed(2)}</div>
      <button class="pos-rm-btn" onclick="_posRemoveLine(${idx})" title="Remove">&#x2715;</button>
    </div>`).join('');

  const subtotal = _posCart.reduce((s, l) => s + (l.total - l.gst), 0);
  const gst      = _posCart.reduce((s, l) => s + l.gst, 0);
  const total    = _posCart.reduce((s, l) => s + l.total, 0);

  totalsEl.innerHTML = `
    <div class="pos-total-row"><span>Subtotal (ex GST)</span><span>$${subtotal.toFixed(2)}</span></div>
    <div class="pos-total-row"><span>GST</span><span>$${gst.toFixed(2)}</span></div>
    <div class="pos-total-row pos-grand-total"><span>TOTAL</span><span>$${total.toFixed(2)}</span></div>`;

  btnsEl.innerHTML = `
    <button class="pos-btn pos-btn-cash" onclick="_posCheckStockWarnings(function(){_posTenderCash(${total.toFixed(4)});})">Cash</button>
    <button class="pos-btn pos-btn-card" onclick="_posCheckStockWarnings(function(){_posTenderCard(${total.toFixed(4)});})">Card</button>
    <button class="pos-btn pos-btn-split" onclick="_posCheckStockWarnings(function(){_posTenderSplit(${total.toFixed(4)});})">Split</button>`;
}


// ═══════════════════════════════════════════════════════════════════════════
// STOCK WARNING
// ═══════════════════════════════════════════════════════════════════════════

function _posCheckStockWarnings(onProceed) {
  const warnings = [];
  _posCart.forEach(function(line) {
    if (!line.item_id) return; // custom line items have no stock
    const item = _posItems.find(function(i) { return i.id === line.item_id; });
    if (!item || !item.is_inventoried) return;
    const qtyAfter  = (parseFloat(item.qty_on_hand) || 0) - line.qty;
    const reorder   = parseFloat(item.reorder_level) || 0;
    const isOut     = qtyAfter < 0;
    const isLow     = !isOut && reorder > 0 && qtyAfter <= reorder;
    if (isOut || isLow) {
      warnings.push({ name: line.description, qtyAfter: qtyAfter, reorder: reorder, isOut: isOut });
    }
  });
  if (!warnings.length) { onProceed(); return; }

  _posStockWarnProceedFn = onProceed;

  var rows = '';
  warnings.forEach(function(w) {
    var cls   = w.isOut ? 'pos-sw-row out' : 'pos-sw-row low';
    var badge = w.isOut ? '<span class="pos-sw-badge out">Oversell</span>' : '<span class="pos-sw-badge low">Low stock</span>';
    var qty   = w.isOut
      ? (w.qtyAfter < 0 ? w.qtyAfter.toFixed(0) : '0') + ' (negative)'
      : w.qtyAfter.toFixed(w.qtyAfter % 1 === 0 ? 0 : 1) + ' remaining (reorder: ' + w.reorder + ')';
    rows += '<tr class="' + cls + '">'
      + '<td>' + _esc(w.name) + '</td>'
      + '<td>' + badge + '</td>'
      + '<td>' + qty + '</td>'
      + '</tr>';
  });

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.id = 'pos-stock-warn-bd';
  bd.style.display = 'flex';
  bd.innerHTML = '<div class="modal-box">'
    + '<div class="modal-hdr">Stock Warning</div>'
    + '<div class="modal-body">'
    + '<p class="pos-sw-intro">The following items have insufficient stock:</p>'
    + '<table class="pos-sw-table"><thead><tr><th>Item</th><th>Status</th><th>After sale</th></tr></thead>'
    + '<tbody>' + rows + '</tbody></table>'
    + '<p class="pos-sw-q">Proceed anyway?</p>'
    + '</div>'
    + '<div class="modal-foot">'
    + '<button class="btn btn-danger" onclick="_posStockWarnProceed()">Proceed</button>'
    + '<button class="btn" onclick="document.getElementById(\'pos-stock-warn-bd\').remove()">Cancel</button>'
    + '</div></div>';
  document.body.appendChild(bd);
}

function _posStockWarnProceed() {
  document.getElementById('pos-stock-warn-bd')?.remove();
  if (_posStockWarnProceedFn) { _posStockWarnProceedFn(); _posStockWarnProceedFn = null; }
}


// ═══════════════════════════════════════════════════════════════════════════
// CASH TENDER
// ═══════════════════════════════════════════════════════════════════════════

function _posTenderCash(total) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box pos-tender-modal">
    <div class="modal-hdr">Cash Payment &mdash; $${parseFloat(total).toFixed(2)} due</div>
    <div class="modal-body">
      <label class="pos-tender-label">Amount tendered ($)</label>
      <input class="pos-tender-inp" id="pos-tendered" type="number" step="0.05"
             min="${parseFloat(total).toFixed(2)}" value="${parseFloat(total).toFixed(2)}"
             oninput="_posCalcChange(${parseFloat(total).toFixed(4)})">
      <div class="pos-change-row" id="pos-change-row"></div>
      <div class="pos-quick-btns">
        ${_posQuickAmounts(total).map(a =>
          `<button class="pos-quick-btn" onclick="_posSetTendered(${a},${ parseFloat(total).toFixed(4)})"
           >$${a.toFixed(2)}</button>`
        ).join('')}
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary" id="pos-cash-ok" onclick="_posConfirmCash(${parseFloat(total).toFixed(4)})">
        Confirm Sale
      </button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  _posCalcChange(total);
  setTimeout(() => { document.getElementById('pos-tendered')?.select(); }, 60);
}

function _posQuickAmounts(total) {
  const amounts = [];
  for (const multiple of [5, 10, 20, 50, 100]) {
    const a = Math.ceil(total / multiple) * multiple;
    if (!amounts.includes(a)) amounts.push(a);
    if (amounts.length >= 4) break;
  }
  return amounts;
}

function _posSetTendered(amount, total) {
  const inp = document.getElementById('pos-tendered');
  if (inp) { inp.value = amount.toFixed(2); }
  _posCalcChange(total);
}

function _posCalcChange(total) {
  const inp     = document.getElementById('pos-tendered');
  const row     = document.getElementById('pos-change-row');
  const btn     = document.getElementById('pos-cash-ok');
  if (!inp || !row) return;
  const tendered = parseFloat(inp.value) || 0;
  const change   = tendered - total;
  if (change >= 0) {
    row.innerHTML = `<span class="pos-change-ok">Change: $${change.toFixed(2)}</span>`;
    if (btn) btn.disabled = false;
  } else {
    row.innerHTML = `<span class="pos-change-err">Amount insufficient</span>`;
    if (btn) btn.disabled = true;
  }
}

async function _posConfirmCash(total) {
  const inp = document.getElementById('pos-tendered');
  const tendered = parseFloat(inp?.value) || total;
  const bd  = inp?.closest('.modal-bd');
  const btn = document.getElementById('pos-cash-ok');
  if (btn) { btn.disabled = true; btn.textContent = 'Processing…'; }
  try {
    const result = await _posSubmitSale('cash', tendered, null, null);
    bd?.remove();
    _posShowReceipt(result, result.change, 'cash', tendered);
  } catch(e) {
    toast(e.message || 'Sale failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Confirm Sale'; }
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// CARD TENDER
// ═══════════════════════════════════════════════════════════════════════════

async function _posTenderCard(total) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-card-modal';
  bd.innerHTML = `<div class="modal-box pos-tender-modal">
    <div class="modal-hdr">Card Payment &mdash; $${parseFloat(total).toFixed(2)}</div>
    <div class="modal-body" id="pos-card-body">
      <div class="pos-terminal-waiting">
        <div class="pos-terminal-spinner"></div>
        <div class="pos-terminal-msg">Connecting to terminal…</div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn" onclick="_posCancelCard()">Cancel</button>
    </div>
  </div>`;
  document.body.appendChild(bd);

  const ref = `POS-${Date.now()}`;
  try {
    const r = await fetch('/api/pos/terminal/charge', {
      method:  'POST',
      headers: {'Content-Type': 'application/json'},
      body:    JSON.stringify({amount: parseFloat(total), reference: ref}),
    }).then(r => r.json());

    if (!r.ok) throw new Error(r.error || 'Terminal error');
    const {checkout_id, provider} = r.data;

    document.getElementById('pos-card-body').innerHTML = `
      <div class="pos-terminal-waiting">
        <div class="pos-terminal-spinner"></div>
        <div class="pos-terminal-msg">Waiting for customer to tap or insert card…</div>
        <div class="pos-terminal-sub">Present card on the terminal</div>
      </div>`;

    _posPollTerminal(checkout_id, provider, total);
  } catch(e) {
    const body = document.getElementById('pos-card-body');
    if (body) body.innerHTML = `<div class="pos-terminal-error">${_esc(e.message)}</div>`;
  }
}

async function _posPollTerminal(checkoutId, provider, total) {
  let count = 0;
  clearInterval(_posPollTimer);
  _posPollTimer = setInterval(async () => {
    count++;
    if (count > 90) {  // 3-minute timeout at 2s intervals
      clearInterval(_posPollTimer);
      const body = document.getElementById('pos-card-body');
      if (body) body.innerHTML = '<div class="pos-terminal-error">Terminal timeout — please retry</div>';
      return;
    }
    try {
      const res = await apiFetch(`/api/pos/terminal/charge/${checkoutId}?provider=${provider}`);
      if (res.status === 'completed') {
        clearInterval(_posPollTimer);
        try {
          const result = await _posSubmitSale('card', null, checkoutId, provider);
          document.getElementById('pos-card-modal')?.remove();
          _posShowReceipt(result, 0, 'card', result.total);
        } catch(e) {
          const body = document.getElementById('pos-card-body');
          if (body) body.innerHTML = `<div class="pos-terminal-error">${_esc(e.message)}</div>`;
        }
      } else if (res.status === 'declined' || res.status === 'error') {
        clearInterval(_posPollTimer);
        const body = document.getElementById('pos-card-body');
        if (body) body.innerHTML = `<div class="pos-terminal-error">${_esc(res.message || 'Payment declined')}</div>`;
      }
    } catch(_) { /* keep polling on transient errors */ }
  }, 2000);
}

function _posCancelCard() {
  clearInterval(_posPollTimer);
  document.getElementById('pos-card-modal')?.remove();
}


// ═══════════════════════════════════════════════════════════════════════════
// SPLIT TENDER
// ═══════════════════════════════════════════════════════════════════════════

function _posTenderSplit(total) {
  const t = parseFloat(total);
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-split-modal';
  bd.innerHTML = `<div class="modal-box pos-tender-modal">
    <div class="modal-hdr">Split Payment &mdash; $${t.toFixed(2)} due</div>
    <div class="modal-body" id="pos-split-body">
      <div class="pos-split-row">
        <label class="pos-tender-label">Cash ($)</label>
        <input class="pos-tender-inp" id="pos-split-cash" type="number" step="0.01"
               min="0" value="0.00"
               oninput="_posSplitUpdate(${t.toFixed(4)}, 'cash')"
               onclick="this.select()">
      </div>
      <div class="pos-split-row">
        <label class="pos-tender-label">Card ($)</label>
        <input class="pos-tender-inp" id="pos-split-card" type="number" step="0.01"
               min="0" value="${t.toFixed(2)}"
               oninput="_posSplitUpdate(${t.toFixed(4)}, 'card')"
               onclick="this.select()">
      </div>
      <div class="pos-split-total-row" id="pos-split-check"></div>
    </div>
    <div class="modal-foot">
      <button class="btn" onclick="_posCancelSplit()">Cancel</button>
      <button class="btn btn-primary" id="pos-split-ok"
              onclick="_posSplitChargeCard(${t.toFixed(4)})">Charge Card</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  _posSplitUpdate(t, 'card');
  setTimeout(() => document.getElementById('pos-split-cash')?.focus(), 50);
}

function _posSplitUpdate(total, changed) {
  const cashEl  = document.getElementById('pos-split-cash');
  const cardEl  = document.getElementById('pos-split-card');
  const checkEl = document.getElementById('pos-split-check');
  const okBtn   = document.getElementById('pos-split-ok');
  if (!cashEl || !cardEl) return;
  const t = parseFloat(total);
  // Only update the OTHER field — never overwrite the field the user is typing in
  if (changed === 'cash') {
    const cash = Math.min(Math.max(parseFloat(cashEl.value) || 0, 0), t);
    cardEl.value = Math.max(0, t - cash).toFixed(2);
  } else {
    const card = Math.min(Math.max(parseFloat(cardEl.value) || 0, 0), t);
    cashEl.value = Math.max(0, t - card).toFixed(2);
  }
  const sum  = (parseFloat(cashEl.value) || 0) + (parseFloat(cardEl.value) || 0);
  const diff = Math.abs(sum - t);
  if (checkEl) {
    checkEl.innerHTML = diff < 0.005
      ? '<span class="pos-change-ok">&#x2713; Amounts balance</span>'
      : '<span class="pos-change-err">Amounts do not add up to total</span>';
  }
  if (okBtn) okBtn.disabled = diff >= 0.005;
}

async function _posSplitChargeCard(total) {
  const cashAmt = parseFloat(document.getElementById('pos-split-cash')?.value) || 0;
  const cardAmt = parseFloat(document.getElementById('pos-split-card')?.value) || 0;
  const body = document.getElementById('pos-split-body');
  const foot = document.querySelector('#pos-split-modal .modal-foot');
  if (body) body.innerHTML = `<div class="pos-terminal-waiting">
    <div class="pos-terminal-spinner"></div>
    <div class="pos-terminal-msg">Connecting to terminal for $${cardAmt.toFixed(2)}…</div>
  </div>`;
  if (foot) foot.innerHTML = `<button class="btn" onclick="_posCancelSplit()">Cancel</button>`;
  const ref = 'SPLIT-' + Date.now();
  try {
    const r = await fetch('/api/pos/terminal/charge', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({amount: cardAmt, reference: ref}),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Terminal error');
    const {checkout_id, provider} = r.data;
    if (body) body.innerHTML = `<div class="pos-terminal-waiting">
      <div class="pos-terminal-spinner"></div>
      <div class="pos-terminal-msg">Waiting for card tap — $${cardAmt.toFixed(2)}</div>
      <div class="pos-terminal-sub">Present card on the terminal</div>
    </div>`;
    _posPollSplitTerminal(checkout_id, provider, cashAmt, cardAmt, total);
  } catch(e) {
    if (body) body.innerHTML = `<div class="pos-terminal-error">${_esc(e.message)}</div>`;
    if (foot) foot.innerHTML = `<button class="btn" onclick="_posCancelSplit()">Cancel</button>`;
  }
}

async function _posPollSplitTerminal(checkoutId, provider, cashAmt, cardAmt, total) {
  let count = 0;
  clearInterval(_posPollTimer);
  _posPollTimer = setInterval(async () => {
    count++;
    if (count > 90) {
      clearInterval(_posPollTimer);
      const body = document.getElementById('pos-split-body');
      if (body) body.innerHTML = '<div class="pos-terminal-error">Terminal timeout — please retry</div>';
      return;
    }
    try {
      const res = await apiFetch('/api/pos/terminal/charge/' + checkoutId + '?provider=' + provider);
      if (res.status === 'completed') {
        clearInterval(_posPollTimer);
        _posSplitCollectCash(cashAmt, cardAmt, total, res.tx_id || checkoutId, provider);
      } else if (res.status === 'declined' || res.status === 'error') {
        clearInterval(_posPollTimer);
        const body = document.getElementById('pos-split-body');
        if (body) body.innerHTML = '<div class="pos-terminal-error">' + _esc(res.message || 'Payment declined') + '</div>';
      }
    } catch(_) {}
  }, 2000);
}

function _posSplitCollectCash(cashAmt, cardAmt, total, txId, provider) {
  const body = document.getElementById('pos-split-body');
  const foot = document.querySelector('#pos-split-modal .modal-foot');
  if (body) {
    var html = '<div class="pos-split-cash-step">';
    html += '<div class="pos-split-cash-icon">&#x2705;</div>';
    html += '<div class="pos-split-cash-msg">Card approved &mdash; $' + cardAmt.toFixed(2) + '</div>';
    html += '<div class="pos-split-cash-collect">Collect cash: <strong>$' + cashAmt.toFixed(2) + '</strong></div>';
    html += '</div>';
    body.innerHTML = html;
  }
  if (foot) {
    foot.innerHTML = '<button class="btn btn-primary" onclick="_posSplitComplete(' +
      cashAmt.toFixed(4) + ',' + cardAmt.toFixed(4) + ',' + total.toFixed(4) +
      ',\'' + txId + '\',\'' + (provider || '') + '\')">Done &mdash; Cash Collected</button>';
  }
}

async function _posSplitComplete(cashAmt, cardAmt, total, txId, provider) {
  const foot = document.querySelector('#pos-split-modal .modal-foot');
  if (foot) foot.innerHTML = '<span style="color:var(--ink2);font-size:13px">Processing sale…</span>';
  try {
    const result = await _posSubmitSale('split', null, txId, provider, {
      cash: cashAmt, card: cardAmt, terminal_tx_id: txId, terminal_provider: provider,
    });
    document.getElementById('pos-split-modal')?.remove();
    _posShowReceipt(result, 0, 'split', total, {cash: cashAmt, card: cardAmt});
  } catch(e) {
    toast(e.message || 'Sale failed', 'err');
    if (foot) foot.innerHTML = '<button class="btn" onclick="_posCancelSplit()">Cancel</button>';
  }
}

function _posCancelSplit() {
  clearInterval(_posPollTimer);
  document.getElementById('pos-split-modal')?.remove();
}


// ═══════════════════════════════════════════════════════════════════════════
// SALE SUBMISSION
// ═══════════════════════════════════════════════════════════════════════════

async function _posSubmitSale(tender, tendered, terminalTxId, terminalProvider, splitTenders) {
  const r = await fetch('/api/pos/sale', {
    method:  'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      lines: _posCart.map(l => ({
        item_id:     l.item_id,
        description: l.description,
        qty:         l.qty,
        unit_price:  l.unit_price,
        tax_code:    l.tax_code,
        account_id:  l.account_id,
      })),
      tender,
      tendered,
      terminal_tx_id:    terminalTxId,
      terminal_provider: terminalProvider,
      split_tenders:     splitTenders || null,
      session_id:        _posSession?.id ?? null,
      contact_id:        _posContactId || null,
      gst: _posCart.reduce((s, l) => s + (l.gst || 0), 0),
    }),
  }).then(r => r.json());

  if (!r.ok) throw new Error(r.error || 'Sale failed');
  _posCart      = [];
  _posContactId = null;
  _posRenderCart();
  return r.data;
}


// ═══════════════════════════════════════════════════════════════════════════
// SESSION / Z-REPORT
// ═══════════════════════════════════════════════════════════════════════════

function _posRenderSessionBar() {
  const bar = document.getElementById('pos-session-bar');
  if (!bar) return;
  if (_posSession) {
    const t = (_posSession.opened_at || '').slice(0, 16).replace('T', ' ');
    const opHtml = (_posSession.opened_by_name)
      ? ` &mdash; <span class="pos-session-operator">&#x1F464; ${_esc(_posSession.opened_by_name)}</span>`
      : '';
    bar.className = 'pos-session-bar pos-session-open';
    bar.innerHTML = `<span class="pos-session-dot"></span>Session #${_posSession.id} — opened ${t}${opHtml}`;
  } else {
    bar.className = 'pos-session-bar pos-session-closed';
    bar.innerHTML = `No session — <button class="pos-session-link" onclick="_posOpenZReport()">open register</button>`;
  }
}

async function _posOpenZReport() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-zrpt-bd';
  bd.innerHTML = `<div class="modal-box pos-zrpt-modal">
    <div class="modal-hdr" id="pos-zrpt-hdr">Z-Report</div>
    <div class="modal-body" id="pos-zrpt-body"><div class="state-loading">Loading…</div></div>
    <div class="modal-foot" id="pos-zrpt-foot">
      <button class="btn" onclick="document.getElementById('pos-zrpt-bd').remove()">Close</button>
    </div>
  </div>`;
  document.body.appendChild(bd);

  if (!_posSession) {
    _posRenderZNoSession(_posLastFloat);
    return;
  }
  try {
    const report = await apiFetch(`/api/pos/session/${_posSession.id}/report`);
    _posRenderZReport(report, false);
  } catch(e) {
    document.getElementById('pos-zrpt-body').innerHTML = `<div class="state-error">${_esc(e.message)}</div>`;
  }
}

function _posRenderZNoSession(lastFloat = 0) {
  const hint = lastFloat > 0
    ? `Previous closing float: $${parseFloat(lastFloat).toFixed(2)}`
    : 'Enter the opening float (cash in the drawer to start the day).';
  document.getElementById('pos-zrpt-body').innerHTML = `
    <div class="pos-zrpt-nosess">
      <div class="pos-zrpt-nosess-icon">&#x1F513;</div>
      <div class="pos-zrpt-nosess-msg">No register session open</div>
      <div class="pos-zrpt-nosess-sub">${_esc(hint)}</div>
      <div class="pos-till-field">
        <label class="pos-till-lbl">Opening Float</label>
        <div class="pos-till-input-wrap">
          <span class="pos-till-dollar">$</span>
          <input type="number" id="pos-open-float" class="pos-till-inp" min="0" step="0.01"
                 value="${parseFloat(lastFloat).toFixed(2)}" placeholder="0.00">
        </div>
      </div>
      <div class="pos-till-field">
        <label class="pos-till-lbl" style="font-weight:400;text-transform:none">Session note (optional)</label>
        <input class="pos-sett-inp" id="pos-open-note" type="text"
               placeholder="e.g. Morning shift, Jane" maxlength="100" autocomplete="off">
      </div>
    </div>`;
  document.getElementById('pos-zrpt-foot').innerHTML = `
    <button class="btn" onclick="document.getElementById('pos-zrpt-bd').remove()">Cancel</button>
    <button class="btn btn-primary" onclick="_posSignOnThenOpen()">Open Register</button>`;
}

function _posRenderZReport(report, isClosed, readOnly = false) {
  const fmt    = n  => '$' + parseFloat(n || 0).toFixed(2);
  const fmtD   = s  => s ? s.slice(0, 16) : '—';
  const round2 = n  => Math.round((n || 0) * 100) / 100;
  document.getElementById('pos-zrpt-hdr').textContent = isClosed ? 'Z-Report' : 'Z-Report (Preview)';
  document.getElementById('pos-zrpt-body').innerHTML = `
    <div class="pos-zrpt-content">
      <div class="pos-zrpt-title">${isClosed ? 'Z-REPORT' : 'CURRENT TOTALS'}</div>
      <div class="pos-zrpt-meta">
        <div>Session #${report.session_id}</div>
        <div>Opened: ${fmtD(report.opened_at)}</div>
        ${report.closed_at ? `<div>Closed: ${fmtD(report.closed_at)}</div>` : ''}
      </div>
      <div class="pos-zrpt-sep"></div>
      <div class="pos-zrpt-row">
        <span>Cash</span>
        <span>${report.cash.count} txn${report.cash.count !== 1 ? 's' : ''}</span>
        <span>${fmt(report.cash.total)}</span>
      </div>
      <div class="pos-zrpt-row">
        <span>Card / EFTPOS</span>
        <span>${report.card.count} txn${report.card.count !== 1 ? 's' : ''}</span>
        <span>${fmt(report.card.total)}</span>
      </div>
      ${(report.split && report.split.count > 0) ? `
      <div class="pos-zrpt-row">
        <span>Split (Cash $${fmt(report.split.cash)} / Card $${fmt(report.split.card)})</span>
        <span>${report.split.count} txn${report.split.count !== 1 ? 's' : ''}</span>
        <span>${fmt(report.split.total)}</span>
      </div>` : ''}
      <div class="pos-zrpt-sep"></div>
      <div class="pos-zrpt-row pos-zrpt-row-total">
        <span>TOTAL SALES</span>
        <span>${report.tx_count} txn${report.tx_count !== 1 ? 's' : ''}</span>
        <span>${fmt(report.total)}</span>
      </div>
      <div class="pos-zrpt-sep"></div>
      <div class="pos-zrpt-row pos-zrpt-row-gst">
        <span>GST (included)</span><span></span><span>${fmt(report.gst)}</span>
      </div>
      <div class="pos-zrpt-row pos-zrpt-row-gst">
        <span>Ex-GST</span><span></span><span>${fmt(report.ex_gst)}</span>
      </div>
    </div>`;
  // banking report (shown on closed report)
  if (isClosed) {
    const variance     = report.variance || 0;
    const varClass     = variance > 0 ? 'pos-till-over' : variance < 0 ? 'pos-till-short' : '';
    const varLabel     = variance > 0 ? 'Over' : variance < 0 ? 'Short' : 'Balanced';
    const expected     = (report.opening_float || 0) + (report.cash_drawer_total != null ? report.cash_drawer_total : report.cash.total || 0);
    const totalBanking = round2((report.banked || 0) + (report.card.total || 0) + ((report.split && report.split.card) || 0));
    const hasCounted   = report.cash_counted !== null && report.cash_counted !== undefined;
    document.getElementById('pos-zrpt-body').innerHTML += `
      <div class="pos-zrpt-sep"></div>
      <div class="pos-zrpt-title" style="font-size:11px;margin-top:4px">BANKING REPORT</div>

      <div class="pos-zrpt-subtitle">Cash</div>
      <div class="pos-zrpt-row"><span>Opening Float</span><span></span><span>${fmt(report.opening_float)}</span></div>
      <div class="pos-zrpt-row"><span>Cash Sales</span><span></span><span>${fmt(report.cash.total)}</span></div>
      <div class="pos-zrpt-row pos-zrpt-row-sub"><span>Expected in Drawer</span><span></span><span>${fmt(expected)}</span></div>
      ${hasCounted ? `
      <div class="pos-zrpt-row"><span>Actual Counted</span><span></span><span>${fmt(report.cash_counted)}</span></div>
      <div class="pos-zrpt-row ${varClass}"><span>Variance</span><span>${varLabel}</span><span>${fmt(Math.abs(variance))}</span></div>` : ''}
      <div class="pos-zrpt-sep-thin"></div>
      <div class="pos-zrpt-row"><span>Cash Deposited</span><span></span><span>${fmt(report.banked)}</span></div>
      <div class="pos-zrpt-row"><span>Float Retained</span><span></span><span>${fmt(report.float_kept)}</span></div>

      <div class="pos-zrpt-subtitle" style="margin-top:8px">Card / EFTPOS</div>
      <div class="pos-zrpt-row">
        <span>Card Transactions</span>
        <span>${report.card.count} txn${report.card.count !== 1 ? 's' : ''}</span>
        <span>${fmt(report.card.total)}</span>
      </div>
      <div class="pos-zrpt-note">Settled directly to merchant account</div>

      <div class="pos-zrpt-sep"></div>
      <div class="pos-zrpt-row pos-zrpt-row-total"><span>TOTAL BANKING</span><span></span><span>${fmt(totalBanking)}</span></div>`;
  }
  const foot = document.getElementById('pos-zrpt-foot');
  if (isClosed || readOnly) {
    foot.innerHTML = `
      <button class="btn" onclick="window.print()">Print</button>
      <button class="btn btn-primary" onclick="document.getElementById('pos-zrpt-bd').remove()">Done</button>`;
  } else {
    _posPendingReport = report;
    foot.innerHTML = `
      <button class="btn" onclick="document.getElementById('pos-zrpt-bd').remove()">Cancel</button>
      <button class="btn btn-danger" id="pos-zrpt-close-btn"
              onclick="_posTillBalanceStep(_posPendingReport)">Close Register</button>`;
  }
}

async function _posSignOnThenOpen() {
  // If any users have PINs configured, require sign-on before opening
  let posUsers = [];
  try { posUsers = await apiFetch('/api/pos/users'); } catch(_) {}
  const pinUsers = posUsers.filter(u => u.has_pin);
  if (!pinUsers.length) {
    // No PINs configured — open directly
    _posPinUserId = null; _posPinUserName = null;
    await _posDoOpenSession();
    return;
  }
  _posShowPinModal(pinUsers, () => _posDoOpenSession());
}

function _posShowPinModal(pinUsers, onSuccess) {
  document.getElementById('pos-pin-bd')?.remove();
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-pin-bd';
  bd.innerHTML = `<div class="modal-box pos-pin-modal">
    <div class="modal-hdr">
      <span>Sign On to Register</span>
      <button class="modal-close" onclick="document.getElementById('pos-pin-bd').remove()">✕</button>
    </div>
    <div class="modal-body pos-pin-body">
      <div class="pos-pin-users" id="pos-pin-users">
        ${pinUsers.map(u => `
          <button class="pos-pin-user-btn" onclick="_posSelectPinUser(${u.id},'${_esc(u.display_name)}')">
            <span class="pos-pin-avatar">${_esc(u.display_name[0] || '?').toUpperCase()}</span>
            <span>${_esc(u.display_name)}</span>
          </button>`).join('')}
      </div>
      <div id="pos-pin-entry" class="pos-pin-entry" style="display:none">
        <div class="pos-pin-entry-name" id="pos-pin-entry-name"></div>
        <div class="pos-pin-dots" id="pos-pin-dots">
          <span></span><span></span><span></span><span></span><span></span><span></span>
        </div>
        <div class="pos-pin-pad">
          ${[1,2,3,4,5,6,7,8,9,'C',0,'⌫'].map(k =>
            `<button class="pos-pin-key${k==='C'||k==='⌫'?' pos-pin-key-fn':''}"
                     onclick="_posPinKey('${k}')">${k}</button>`
          ).join('')}
        </div>
        <button class="btn btn-sec btn-sm" onclick="_posPinBack()">← Change user</button>
      </div>
    </div>
  </div>`;
  document.body.appendChild(bd);
  bd._onSuccess = onSuccess;

  // Keyboard handler — active while this modal is open
  function _pinKeydown(e) {
    if (!document.getElementById('pos-pin-bd')) {
      document.removeEventListener('keydown', _pinKeydown);
      return;
    }
    if (e.key >= '0' && e.key <= '9') {
      // Only forward digits once a user is selected
      if (_posPinSelectedId !== null) { e.preventDefault(); _posPinKey(e.key); }
    } else if (e.key === 'Backspace') {
      e.preventDefault(); _posPinKey('⌫');
    } else if (e.key === 'Delete') {
      e.preventDefault(); _posPinKey('C');
    } else if (e.key === 'Escape') {
      e.preventDefault();
      if (_posPinSelectedId !== null) _posPinBack();
      else document.getElementById('pos-pin-bd')?.remove();
    }
  }
  document.addEventListener('keydown', _pinKeydown);
  // Clean up when the backdrop is removed
  new MutationObserver((_, obs) => {
    if (!document.getElementById('pos-pin-bd')) {
      document.removeEventListener('keydown', _pinKeydown);
      obs.disconnect();
    }
  }).observe(document.body, { childList: true });
}

let _posPinBuffer = '';
let _posPinSelectedId = null;

function _posSelectPinUser(userId, name) {
  _posPinSelectedId = userId;
  _posPinBuffer = '';
  document.getElementById('pos-pin-users').style.display = 'none';
  const entry = document.getElementById('pos-pin-entry');
  entry.style.display = '';
  document.getElementById('pos-pin-entry-name').textContent = name;
  _posUpdatePinDots();
}

function _posPinBack() {
  _posPinBuffer = ''; _posPinSelectedId = null;
  document.getElementById('pos-pin-users').style.display = '';
  document.getElementById('pos-pin-entry').style.display = 'none';
}

function _posUpdatePinDots() {
  const dots = document.querySelectorAll('#pos-pin-dots span');
  dots.forEach((d, i) => {
    d.className = i < _posPinBuffer.length ? 'pos-pin-dot filled' : 'pos-pin-dot';
  });
}

async function _posPinKey(key) {
  if (key === '⌫') {
    _posPinBuffer = _posPinBuffer.slice(0, -1);
    _posUpdatePinDots();
    return;
  }
  if (key === 'C') {
    _posPinBuffer = '';
    _posUpdatePinDots();
    return;
  }
  if (_posPinBuffer.length >= 6) return;
  _posPinBuffer += String(key);
  _posUpdatePinDots();
  if (_posPinBuffer.length >= 4) {
    // try verify after each digit once 4+ entered
    await _posPinVerify();
  }
}

async function _posPinVerify() {
  try {
    const r = await fetch('/api/pos/auth', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ pin: _posPinBuffer }),
    }).then(r => r.json());
    if (r.ok && r.data) {
      // Verify the matched user is the selected one
      if (r.data.id !== _posPinSelectedId) {
        // Wrong user's PIN — shake and clear
        _posPinWrongEntry();
        return;
      }
      _posPinUserId   = r.data.id;
      _posPinUserName = r.data.display_name;
      const bd = document.getElementById('pos-pin-bd');
      const cb = bd?._onSuccess;
      bd?.remove();
      if (cb) await cb();
    } else if (_posPinBuffer.length >= 6) {
      _posPinWrongEntry();
    }
  } catch(_) {}
}

function _posPinWrongEntry() {
  const entry = document.getElementById('pos-pin-entry');
  if (entry) { entry.classList.add('pos-pin-shake'); setTimeout(() => entry.classList.remove('pos-pin-shake'), 400); }
  _posPinBuffer = '';
  _posUpdatePinDots();
  toast('Incorrect PIN', 'err');
}

async function _posDoOpenSession() {
  const btn = document.querySelector('#pos-zrpt-foot .btn-primary');
  if (btn) { btn.disabled = true; btn.textContent = 'Opening…'; }
  const floatVal = parseFloat(document.getElementById('pos-open-float')?.value || 0) || 0;
  const noteVal  = (document.getElementById('pos-open-note')?.value || '').trim();
  try {
    const r = await fetch('/api/pos/session', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        opening_float: floatVal,
        note: noteVal,
        opened_by_user_id: _posPinUserId,
        opened_by_name: _posPinUserName,
      }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Failed to open session');
    _posSession = r.data;
    document.getElementById('pos-zrpt-bd')?.remove();
    _posRenderSessionBar();
    const who = _posPinUserName ? ` — ${_posPinUserName}` : '';
    toast(`Register open — Session #${_posSession.id}${who}`);
  } catch(e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Open Register'; }
  }
}

const _POS_DENOMS = [
  { label: '$100', value: 100 },
  { label: '$50',  value: 50  },
  { label: '$20',  value: 20  },
  { label: '$10',  value: 10  },
  { label: '$5',   value: 5   },
  { label: '$2',   value: 2   },
  { label: '$1',   value: 1   },
  { label: '50c',  value: 0.5 },
  { label: '20c',  value: 0.2 },
  { label: '10c',  value: 0.1 },
  { label: '5c',   value: 0.05},
];

function _posTillBalanceStep(report) {
  _posPendingReport = report;
  const expected = ((report.opening_float || 0) + (report.cash_drawer_total != null ? report.cash_drawer_total : report.cash.total || 0)).toFixed(2);
  document.getElementById('pos-zrpt-hdr').textContent = 'Balance Till';
  document.getElementById('pos-zrpt-body').innerHTML = `
    <div class="pos-till-step">
      <div class="pos-till-row"><span>Opening Float</span><span>$${parseFloat(report.opening_float||0).toFixed(2)}</span></div>
      <div class="pos-till-row"><span>Cash Sales</span><span>$${parseFloat(report.cash.total||0).toFixed(2)}</span></div>
      <div class="pos-till-row pos-till-expected"><span>Expected in Drawer</span><span>$${expected}</span></div>
      <div class="pos-till-sep"></div>
      <div class="pos-till-field">
        <label class="pos-till-lbl">Actual Cash Counted</label>
        <div class="pos-till-input-wrap">
          <span class="pos-till-dollar">$</span>
          <input type="number" id="pos-till-counted" class="pos-till-inp" min="0" step="0.01"
                 placeholder="0.00" oninput="_posTillVarianceUpdate(${expected})">
        </div>
      </div>
      <div id="pos-till-variance" class="pos-till-variance"></div>
      <button class="pos-till-denom-toggle" id="pos-denom-toggle"
              onclick="_posDenomToggle(${expected})">Count by denomination ▾</button>
      <div id="pos-denom-grid" style="display:none">
        <div class="pos-denom-grid">
          ${_POS_DENOMS.map(d => `
            <div class="pos-denom-row">
              <span class="pos-denom-lbl">${d.label}</span>
              <span class="pos-denom-x">×</span>
              <input type="number" class="pos-denom-inp" min="0" step="1" value=""
                     placeholder="0" data-val="${d.value}"
                     oninput="_posDenomCalc(${expected})">
              <span class="pos-denom-sub" id="pos-denom-sub-${d.value.toString().replace('.','_')}"></span>
            </div>`).join('')}
        </div>
        <div class="pos-denom-total-row">
          <span>Denomination Total</span>
          <span id="pos-denom-total">$0.00</span>
        </div>
      </div>
    </div>`;
  document.getElementById('pos-zrpt-foot').innerHTML = `
    <button class="btn" onclick="document.getElementById('pos-zrpt-bd')?.remove();_posOpenZReport()">← Back</button>
    <button class="btn btn-primary" onclick="_posBankingStep(_posPendingReport)">Next: Banking →</button>`;
}

function _posDenomToggle(expected) {
  const grid = document.getElementById('pos-denom-grid');
  const btn  = document.getElementById('pos-denom-toggle');
  if (!grid) return;
  const open = grid.style.display === 'none';
  grid.style.display = open ? '' : 'none';
  btn.textContent = open ? 'Count by denomination ▴' : 'Count by denomination ▾';
  if (open) setTimeout(() => grid.querySelector('.pos-denom-inp')?.focus(), 50);
}

function _posDenomCalc(expected) {
  let total = 0;
  document.querySelectorAll('.pos-denom-inp').forEach(inp => {
    const qty = parseInt(inp.value || 0) || 0;
    const val = parseFloat(inp.dataset.val);
    const sub = qty * val;
    total += sub;
    const key = inp.dataset.val.replace('.', '_');
    const el  = document.getElementById(`pos-denom-sub-${key}`);
    if (el) el.textContent = sub > 0 ? `$${sub.toFixed(2)}` : '';
  });
  total = Math.round(total * 100) / 100;
  const totalEl = document.getElementById('pos-denom-total');
  if (totalEl) totalEl.textContent = `$${total.toFixed(2)}`;
  const countedEl = document.getElementById('pos-till-counted');
  if (countedEl) { countedEl.value = total.toFixed(2); _posTillVarianceUpdate(expected); }
}

function _posTillVarianceUpdate(expected) {
  const counted = parseFloat(document.getElementById('pos-till-counted')?.value || 0) || 0;
  const variance = counted - parseFloat(expected);
  const el = document.getElementById('pos-till-variance');
  if (!el) return;
  if (variance === 0) {
    el.innerHTML = '<span class="pos-till-balanced">✓ Balanced</span>';
  } else if (variance > 0) {
    el.innerHTML = `<span class="pos-till-over">Over by $${variance.toFixed(2)}</span>`;
  } else {
    el.innerHTML = `<span class="pos-till-short">Short by $${Math.abs(variance).toFixed(2)}</span>`;
  }
}

function _posBankingStep(report) {
  _posPendingReport = report;
  const counted = parseFloat(document.getElementById('pos-till-counted')?.value || 0) || 0;
  const bankingAcct = _posSettings?.banking_account_id || null;
  document.getElementById('pos-zrpt-hdr').textContent = 'Banking';
  document.getElementById('pos-zrpt-body').innerHTML = `
    <div class="pos-till-step">
      <div class="pos-till-row"><span>Cash in Drawer</span><span>$${counted.toFixed(2)}</span></div>
      <div class="pos-till-sep"></div>
      <div class="pos-till-field">
        <label class="pos-till-lbl">Amount to Bank</label>
        <div class="pos-till-input-wrap">
          <span class="pos-till-dollar">$</span>
          <input type="number" id="pos-bank-amount" class="pos-till-inp" min="0" step="0.01"
                 value="${counted.toFixed(2)}" oninput="_posBankingUpdate(${counted.toFixed(2)})">
        </div>
      </div>
      <div class="pos-till-field">
        <label class="pos-till-lbl">Float to Keep</label>
        <div class="pos-till-input-wrap">
          <span class="pos-till-dollar">$</span>
          <input type="number" id="pos-float-keep" class="pos-till-inp" min="0" step="0.01"
                 value="0.00" oninput="_posFloatChange(${counted.toFixed(2)})">
        </div>
      </div>
      ${bankingAcct ? '' : '<div class="pos-till-warn">⚠ No banking account set — journal entry will be skipped. Set one in POS Settings.</div>'}
    </div>`;
  document.getElementById('pos-zrpt-foot').innerHTML = `
    <button class="btn" onclick="_posTillBalanceStep(_posPendingReport)">← Back</button>
    <button class="btn btn-danger" id="pos-zrpt-close-btn"
            onclick="_posDoCloseSession(_posPendingReport.session_id)">Confirm &amp; Close Register</button>`;
  _posBankingUpdate(counted);
}

function _posBankingUpdate(counted) {
  const banked = parseFloat(document.getElementById('pos-bank-amount')?.value || 0) || 0;
  const floatEl = document.getElementById('pos-float-keep');
  if (floatEl) floatEl.value = Math.max(0, counted - banked).toFixed(2);
}

async function _posDoCloseSession(sessionId) {
  const btn = document.getElementById('pos-zrpt-close-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Closing…'; }
  const countedRaw = document.getElementById('pos-till-counted')?.value;
  const cashCounted = countedRaw !== '' && countedRaw != null ? parseFloat(countedRaw) : null;
  const banked    = parseFloat(document.getElementById('pos-bank-amount')?.value || 0) || 0;
  const floatKept = parseFloat(document.getElementById('pos-float-keep')?.value  || 0) || 0;
  try {
    const r = await fetch(`/api/pos/session/${sessionId}/close`, {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        cash_counted:       cashCounted ?? null,
        banked:             banked,
        float_kept:         floatKept,
        banking_account_id: _posSettings?.banking_account_id || null,
      }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Failed to close session');
    _posSession = null;
    _posLastFloat = floatKept;
    _posRenderSessionBar();
    _posRenderZReport(r.data, true);
  } catch(e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Confirm & Close Register'; }
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// SETTINGS
// ═══════════════════════════════════════════════════════════════════════════

async function _posOpenSettings() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-sett-bd';
  bd.innerHTML = `<div class="modal-box pos-sett-modal">
    <div class="modal-hdr">POS Settings</div>
    <div class="modal-body" id="pos-sett-body"><div class="state-loading">Loading…</div></div>
    <div class="modal-foot">
      <button class="btn" onclick="document.getElementById('pos-sett-bd').remove()">Cancel</button>
      <button class="btn btn-primary" id="pos-sett-save" onclick="_posSaveSettings()">Save</button>
    </div>
  </div>`;
  document.body.appendChild(bd);

  try {
    const [s, accts, contacts] = await Promise.all([
      apiFetch('/api/pos/settings'),
      apiFetch('/api/accounts'),
      apiFetch('/api/contacts'),
    ]);
    _posRenderSettingsForm(s, accts || [], contacts || []);
  } catch(e) {
    const body = document.getElementById('pos-sett-body');
    if (body) body.innerHTML = `<div class="state-error">${_esc(e.message)}</div>`;
  }
}

function _posRenderSettingsForm(s, accts, contacts) {
  const body = document.getElementById('pos-sett-body');
  if (!body) return;
  const prov = s.provider || 'mock';

  const acctOpts = (sel) => '<option value="">— select account —</option>' +
    accts.map(a => `<option value="${a.id}"${a.id == sel ? ' selected' : ''}>${_esc(a.code)} — ${_esc(a.name)}</option>`).join('');
  const conOpts = '<option value="">— select contact —</option>' +
    contacts.map(c => `<option value="${c.id}"${c.id == s.walkin_contact_id ? ' selected' : ''}>${_esc(c.name)}</option>`).join('');

  body.innerHTML = `
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">Terminal Provider</label>
      <select class="pos-sett-inp" id="pos-sett-provider" onchange="_posProviderChange(this.value)">
        <option value="mock"  ${prov==='mock'  ?'selected':''}>Mock (testing — no hardware needed)</option>
        <option value="tyro"  ${prov==='tyro'  ?'selected':''}>Tyro Integrated EFTPOS</option>
        <option value="square"${prov==='square'?'selected':''}>Square Terminal</option>
        <option value="linkly"${prov==='linkly'?'selected':''}>Linkly (CBA / NAB / Westpac / ANZ bank terminals)</option>
      </select>
    </div>
    <div class="pos-sett-row" id="pos-sett-apikey-row">
      <label class="pos-sett-lbl">API Key / Access Token</label>
      <input class="pos-sett-inp" id="pos-sett-apikey" type="password" autocomplete="new-password"
             placeholder="${s.api_key_configured ? '(configured — leave blank to keep)' : 'Enter API key'}">
    </div>
    <div class="pos-sett-row" id="pos-sett-pair-row">
      <label class="pos-sett-lbl">Terminal Pairing</label>
      <div style="display:flex;align-items:center;gap:10px">
        <span id="pos-sett-pair-status" style="color:${s.api_key_configured ? 'var(--green)' : 'var(--ink3)'}">
          ${s.api_key_configured ? '✓ Terminal paired' : 'Not paired'}
        </span>
        <button class="btn btn-sm btn-sec" type="button" onclick="_posLinklyPair()">
          ${s.api_key_configured ? 'Re-pair' : 'Pair Terminal'}
        </button>
      </div>
    </div>
    <div class="pos-sett-row" id="pos-sett-device-row">
      <label class="pos-sett-lbl">Device / Terminal ID</label>
      <input class="pos-sett-inp" id="pos-sett-device" type="text"
             value="${_esc(s.device_id || '')}" placeholder="Terminal device ID">
    </div>
    <div class="pos-sett-row" id="pos-sett-location-row">
      <label class="pos-sett-lbl">Location ID <span class="pos-sett-hint">(Square only)</span></label>
      <input class="pos-sett-inp" id="pos-sett-location" type="text"
             value="${_esc(s.location_id || '')}" placeholder="Square location ID">
    </div>
    <div class="pos-sett-row" id="pos-sett-sandbox-row">
      <label class="pos-sett-lbl">Sandbox Mode <span class="pos-sett-hint">(Square only)</span></label>
      <label class="pos-sett-check">
        <input type="checkbox" id="pos-sett-sandbox" ${s.square_sandbox ? 'checked' : ''}>
        Use Square sandbox (test/developer account)
      </label>
    </div>
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">Terminal Display Name</label>
      <input class="pos-sett-inp" id="pos-sett-name" type="text"
             value="${_esc(s.terminal_name || 'POS Terminal')}">
    </div>
    <div class="pos-sett-sep"></div>
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">Cash Account</label>
      <select class="pos-sett-inp" id="pos-sett-cash">${acctOpts(s.cash_account_id)}</select>
    </div>
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">Card / EFTPOS Account</label>
      <select class="pos-sett-inp" id="pos-sett-card">${acctOpts(s.card_account_id)}</select>
    </div>
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">Banking Account <span class="pos-sett-hint">(for till banking)</span></label>
      <select class="pos-sett-inp" id="pos-sett-banking">${acctOpts(s.banking_account_id)}</select>
    </div>
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">Walk-in Customer</label>
      <select class="pos-sett-inp" id="pos-sett-walkin">${conOpts}</select>
    </div>
    <div class="pos-sett-sep"></div>
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">Thermal Printer</label>
      <label class="pos-sett-check">
        <input type="checkbox" id="pos-sett-printer-enabled"
               ${s.printer_enabled ? 'checked' : ''}
               onchange="_posPrinterEnabledChange(this.checked)">
        Enable receipt printer
      </label>
    </div>
    <div id="pos-sett-printer-rows" style="${s.printer_enabled ? '' : 'display:none'}">
      <div class="pos-sett-row">
        <label class="pos-sett-lbl">Printer Type</label>
        <select class="pos-sett-inp" id="pos-sett-printer-type">
          <option value="network" ${(s.printer_type||'network')==='network'?'selected':''}>Network (TCP/IP — LAN)</option>
        </select>
      </div>
      <div class="pos-sett-row">
        <label class="pos-sett-lbl">Printer IP Address</label>
        <input class="pos-sett-inp" id="pos-sett-printer-host" type="text"
               value="${_esc(s.printer_host || '')}" placeholder="e.g. 192.168.1.100">
      </div>
      <div class="pos-sett-row">
        <label class="pos-sett-lbl">Port <span class="pos-sett-hint">(default 9100)</span></label>
        <input class="pos-sett-inp" id="pos-sett-printer-port" type="number"
               value="${s.printer_port || 9100}" min="1" max="65535" style="width:100px">
      </div>
      <div class="pos-sett-row">
        <label class="pos-sett-lbl">Auto-print receipts</label>
        <label class="pos-sett-check">
          <input type="checkbox" id="pos-sett-auto-print"
                 ${s.printer_auto_print ? 'checked' : ''}>
          Print automatically after each sale
        </label>
      </div>
    </div>`;

  _posProviderChange(prov);
}

function _posPrinterEnabledChange(on) {
  const rows = document.getElementById('pos-sett-printer-rows');
  if (rows) rows.style.display = on ? '' : 'none';
}

function _posProviderChange(prov) {
  const apikeyRow   = document.getElementById('pos-sett-apikey-row');
  const deviceRow   = document.getElementById('pos-sett-device-row');
  const locationRow = document.getElementById('pos-sett-location-row');
  const sandboxRow  = document.getElementById('pos-sett-sandbox-row');
  const pairRow     = document.getElementById('pos-sett-pair-row');
  if (!apikeyRow) return;
  const isMock   = prov === 'mock';
  const isLinkly = prov === 'linkly';
  const isSquare = prov === 'square';
  apikeyRow.style.display   = (isMock || isLinkly) ? 'none' : '';
  deviceRow.style.display   = (isMock || isLinkly) ? 'none' : '';
  locationRow.style.display = isSquare ? '' : 'none';
  if (sandboxRow) sandboxRow.style.display = isSquare ? '' : 'none';
  if (pairRow) pairRow.style.display = isLinkly ? '' : 'none';
}

function _posLinklyPair() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="max-width:420px">
    <div class="modal-hdr">
      <span>Pair Linkly Terminal</span>
      <button class="modal-close" onclick="this.closest('.modal-bd').remove()">✕</button>
    </div>
    <div class="modal-body">
      <p style="margin:0 0 14px;color:var(--ink2)">Enter your Linkly credentials and the pair code shown on the PIN pad display.</p>
      <div class="pos-sett-row">
        <label class="pos-sett-lbl">Username</label>
        <input class="pos-sett-inp" id="lnk-pair-user" type="text" autocomplete="username" placeholder="Linkly username">
      </div>
      <div class="pos-sett-row">
        <label class="pos-sett-lbl">Password</label>
        <input class="pos-sett-inp" id="lnk-pair-pass" type="password" autocomplete="current-password" placeholder="Linkly password">
      </div>
      <div class="pos-sett-row">
        <label class="pos-sett-lbl">Pair Code</label>
        <input class="pos-sett-inp" id="lnk-pair-code" type="text" placeholder="Code shown on PIN pad" maxlength="16" style="letter-spacing:2px">
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-sec" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-pri" id="lnk-pair-btn" onclick="_posLinklyDoPair(this)">Pair Terminal</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

async function _posLinklyDoPair(btn) {
  const username = (document.getElementById('lnk-pair-user')?.value || '').trim();
  const password = document.getElementById('lnk-pair-pass')?.value || '';
  const pairCode = (document.getElementById('lnk-pair-code')?.value || '').trim();
  if (!username || !password || !pairCode) { toast('All fields are required', 'err'); return; }
  btn.disabled = true; btn.textContent = 'Pairing…';
  try {
    const r = await fetch('/api/pos/terminal/pair', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({username, password, pair_code: pairCode}),
    });
    const d = await r.json();
    if (!d.ok) throw new Error(d.error || 'Pairing failed');
    btn.closest('.modal-bd').remove();
    toast('Terminal paired successfully');
    const statusEl = document.getElementById('pos-sett-pair-status');
    if (statusEl) { statusEl.textContent = '✓ Terminal paired'; statusEl.style.color = 'var(--green)'; }
    const pairBtn = document.querySelector('#pos-sett-pair-row button');
    if (pairBtn) pairBtn.textContent = 'Re-pair';
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = 'Pair Terminal';
  }
}

async function _posSaveSettings() {
  const btn = document.getElementById('pos-sett-save');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
  try {
    const payload = {
      provider:          document.getElementById('pos-sett-provider')?.value || 'mock',
      api_key:           document.getElementById('pos-sett-apikey')?.value || '',
      device_id:         document.getElementById('pos-sett-device')?.value || '',
      location_id:       document.getElementById('pos-sett-location')?.value || '',
      terminal_name:     document.getElementById('pos-sett-name')?.value || 'POS Terminal',
      cash_account_id:   document.getElementById('pos-sett-cash')?.value || null,
      card_account_id:   document.getElementById('pos-sett-card')?.value || null,
      walkin_contact_id: document.getElementById('pos-sett-walkin')?.value || null,
      printer_enabled:   document.getElementById('pos-sett-printer-enabled')?.checked || false,
      printer_type:      document.getElementById('pos-sett-printer-type')?.value || 'network',
      printer_host:      document.getElementById('pos-sett-printer-host')?.value || '',
      printer_port:      parseInt(document.getElementById('pos-sett-printer-port')?.value) || 9100,
      printer_auto_print: document.getElementById('pos-sett-auto-print')?.checked || false,
      square_sandbox:      document.getElementById('pos-sett-sandbox')?.checked || false,
      banking_account_id:  document.getElementById('pos-sett-banking')?.value || null,
    };
    _posSettings = {..._posSettings, ...payload};
    const r = await fetch('/api/pos/settings', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Save failed');
    document.getElementById('pos-sett-bd')?.remove();
    toast('POS settings saved');
  } catch(e) {
    toast(e.message || 'Save failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Save'; }
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// RECEIPT
// ═══════════════════════════════════════════════════════════════════════════

function _posShowReceipt(result, change, tender, tendered, splitTenders) {
  _posCurrentReceipt = {
    invoice_id: result.invoice_id,
    tender:     tender || 'cash',
    tendered:   tendered || result.total,
    change:     change  || 0,
    splitTenders: splitTenders || null,
  };
  var bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-receipt-bd';
  var html = '<div class="modal-box pos-receipt-modal">';
  html += '<div class="modal-hdr pos-receipt-hdr">&#x2713; Sale Complete</div>';
  html += '<div class="modal-body pos-receipt-body">';
  html += '<div class="pos-receipt-num">Invoice ' + _esc(result.invoice_number || '') + '</div>';
  html += '<div class="pos-receipt-total">$' + parseFloat(result.total || 0).toFixed(2) + '</div>';
  if (splitTenders) {
    html += '<div class="pos-receipt-split">Cash $' + parseFloat(splitTenders.cash || 0).toFixed(2) +
            ' &bull; Card $' + parseFloat(splitTenders.card || 0).toFixed(2) + '</div>';
  } else if (change > 0.005) {
    html += '<div class="pos-receipt-change">Change: $' + change.toFixed(2) + '</div>';
  }
  html += '</div>';
  html += '<div class="modal-foot">';
  html += '<button class="btn" id="pos-receipt-print-btn" onclick="_posPrintReceiptCurrent()">Print Receipt</button>';
  html += '<button class="btn" onclick="window.open(\'/api/invoices/' + result.invoice_id + '/pdf\',\'_blank\')">Invoice PDF</button>';
  html += '<button class="btn btn-primary" onclick="document.getElementById(\'pos-receipt-bd\')?.remove()">New Sale</button>';
  html += '</div>';
  html += '</div>';
  bd.innerHTML = html;
  document.body.appendChild(bd);
  toast('Sale ' + (result.invoice_number || '') + ' recorded');
  if (_posSettings.printer_auto_print && _posSettings.printer_enabled) {
    _posPrintReceiptCurrent();
  }
}

function _posPrintReceiptCurrent() {
  if (!_posCurrentReceipt) return;
  var r = _posCurrentReceipt;
  _posPrintReceipt(r.invoice_id, r.tender, r.tendered, r.change, r.splitTenders);
}

async function _posPrintReceipt(invoiceId, tender, tendered, change, splitTenders) {
  const btn = document.getElementById('pos-receipt-print-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Printing…'; }
  try {
    const r = await fetch('/api/pos/print-receipt', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        invoice_id:    invoiceId,
        tender,
        tendered,
        change,
        split_tenders: splitTenders || null,
      }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Print failed');
    toast('Receipt printed');
    if (btn) { btn.disabled = false; btn.textContent = 'Print Receipt'; }
  } catch(e) {
    toast(e.message || 'Print failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Print Receipt'; }
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// BANKING STEP — float editable
// ═══════════════════════════════════════════════════════════════════════════

function _posFloatChange(counted) {
  const float  = parseFloat(document.getElementById('pos-float-keep')?.value || 0) || 0;
  const bankEl = document.getElementById('pos-bank-amount');
  if (bankEl) bankEl.value = Math.max(0, parseFloat(counted) - float).toFixed(2);
}


// ═══════════════════════════════════════════════════════════════════════════
// SALES HISTORY
// ═══════════════════════════════════════════════════════════════════════════

async function _posOpenHistory() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-hist-bd';
  bd.innerHTML = `<div class="modal-box pos-hist-modal" style="display:flex;flex-direction:column;max-height:90vh">
    <div class="modal-hdr">
      <span>Sales History</span>
      <button class="modal-close" onclick="document.getElementById('pos-hist-bd').remove()">✕</button>
    </div>
    <div id="pos-hist-filters-area"></div>
    <div class="modal-body" id="pos-hist-body" style="overflow-y:auto;flex:1;padding:0">
      <div class="state-loading" style="padding:24px">Loading…</div>
    </div>
  </div>`;
  document.body.appendChild(bd);
  try {
    _posHistorySales = await apiFetch('/api/pos/sales?limit=200');
    _posRenderHistory();
  } catch(e) {
    document.getElementById('pos-hist-body').innerHTML =
      `<div class="state-error" style="padding:24px">${_esc(e.message)}</div>`;
  }
}

function _posRenderHistory() {
  const filtersEl = document.getElementById('pos-hist-filters-area');
  if (filtersEl) {
    filtersEl.innerHTML = `
      <div class="pos-hist-filters">
        <input type="date" class="pos-hist-filter-inp pos-hist-date-inp" id="pos-hist-from"
               oninput="_posHistoryFilter()" title="From date">
        <span class="pos-hist-sep">–</span>
        <input type="date" class="pos-hist-filter-inp pos-hist-date-inp" id="pos-hist-to"
               oninput="_posHistoryFilter()" title="To date">
        <input type="text" class="pos-hist-filter-inp pos-hist-text-inp" id="pos-hist-contact"
               oninput="_posHistoryFilter()" placeholder="Customer…" autocomplete="off">
        <select class="pos-hist-filter-inp" id="pos-hist-tender" onchange="_posHistoryFilter()">
          <option value="">All tender</option>
          <option value="cash">Cash</option>
          <option value="card">Card</option>
        </select>
        <input type="number" class="pos-hist-filter-inp pos-hist-amt-inp" id="pos-hist-min"
               oninput="_posHistoryFilter()" placeholder="Min $" min="0" step="0.01">
        <input type="number" class="pos-hist-filter-inp pos-hist-amt-inp" id="pos-hist-max"
               oninput="_posHistoryFilter()" placeholder="Max $" min="0" step="0.01">
        <button class="btn btn-sm btn-sec" onclick="_posHistoryClear()">Clear</button>
      </div>`;
  }
  _posHistoryFilter();
}

function _posHistoryFilter() {
  const from    = document.getElementById('pos-hist-from')?.value    || '';
  const to      = document.getElementById('pos-hist-to')?.value      || '';
  const contact = (document.getElementById('pos-hist-contact')?.value || '').toLowerCase().trim();
  const tender  = document.getElementById('pos-hist-tender')?.value  || '';
  const minAmt  = parseFloat(document.getElementById('pos-hist-min')?.value || '') || null;
  const maxAmt  = parseFloat(document.getElementById('pos-hist-max')?.value || '') || null;

  let filtered = _posHistorySales;
  if (from)            filtered = filtered.filter(s => s.invoice_date >= from);
  if (to)              filtered = filtered.filter(s => s.invoice_date <= to);
  if (contact)         filtered = filtered.filter(s => (s.contact_name || '').toLowerCase().includes(contact));
  if (tender)          filtered = filtered.filter(s => s.tender === tender);
  if (minAmt !== null) filtered = filtered.filter(s => parseFloat(s.total) >= minAmt);
  if (maxAmt !== null) filtered = filtered.filter(s => parseFloat(s.total) <= maxAmt);

  _posRenderHistoryTable(filtered);
}

function _posHistoryClear() {
  ['pos-hist-from','pos-hist-to','pos-hist-contact','pos-hist-min','pos-hist-max'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  const sel = document.getElementById('pos-hist-tender');
  if (sel) sel.value = '';
  _posHistoryFilter();
}

function _posRenderHistoryTable(sales) {
  const el = document.getElementById('pos-hist-body');
  if (!el) return;
  const total    = _posHistorySales.length;
  const shown    = sales.length;
  const sumTotal = sales.reduce((s, r) => s + parseFloat(r.total || 0), 0);
  const countHtml = `<div class="pos-hist-count">
    ${shown === total ? `${total} sale${total !== 1 ? 's' : ''}` : `${shown} of ${total} sales`}
    &nbsp;·&nbsp; Total: <strong>$${sumTotal.toFixed(2)}</strong>
  </div>`;

  if (!sales.length) {
    el.innerHTML = countHtml + '<div class="pos-empty" style="padding:24px">No sales match the filters</div>';
    return;
  }
  el.innerHTML = countHtml + `<div class="tbl-overflow-x">
    <table class="inv-list-table">
      <thead><tr>
        <th>Invoice</th><th>Date</th><th>Customer</th><th>Tender</th>
        <th style="text-align:right">Total</th><th></th>
      </tr></thead>
      <tbody>
      ${sales.map(s => `
        <tr>
          <td>${_esc(s.invoice_number)}</td>
          <td>${fmtDate(s.invoice_date)}</td>
          <td>${_esc(s.contact_name || 'Walk-In')}</td>
          <td>${s.tender === 'cash' ? 'Cash' : 'Card'}</td>
          <td style="text-align:right">$${parseFloat(s.total||0).toFixed(2)}</td>
          <td style="white-space:nowrap">
            <button class="btn btn-sm btn-sec"
                    onclick="_posReprintFromHistory(this,${s.id},'${s.tender||'cash'}',${parseFloat(s.total||0).toFixed(4)})">
              Receipt
            </button>
            <button class="btn btn-sm btn-sec" style="margin-left:4px"
                    onclick="window.open('/api/invoices/${s.id}/pdf','_blank')">
              Invoice
            </button>
            <button class="btn btn-sm btn-danger" style="margin-left:4px"
                    ${s.refunded ? 'disabled title="Already refunded"' : `onclick="_posRefundFromHistory(${s.id},'${_esc(s.tender||'cash')}')"`}>
              ${s.refunded ? 'Refunded' : 'Refund'}
            </button>
          </td>
        </tr>`).join('')}
      </tbody>
    </table>
  </div>`;
}

async function _posReprintFromHistory(btn, invoiceId, tender, total) {
  const orig = btn.textContent;
  btn.disabled = true; btn.textContent = 'Printing…';
  try {
    const r = await fetch('/api/pos/print-receipt', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({invoice_id: invoiceId, tender, tendered: total, change: 0}),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Print failed');
    toast('Receipt printed');
  } catch(e) {
    toast(e.message || 'Print failed', 'err');
  }
  btn.disabled = false; btn.textContent = orig;
}


// ═══════════════════════════════════════════════════════════════════════════
// REFUND / RETURN
// ═══════════════════════════════════════════════════════════════════════════

async function _posRefundFromHistory(invoiceId, tender) {
  // Close history modal, load invoice lines, open refund modal
  document.getElementById('pos-hist-bd')?.remove();
  let inv;
  try {
    inv = await apiFetch(`/api/invoices/${invoiceId}`);
  } catch(e) {
    toast(e.message || 'Could not load invoice', 'err'); return;
  }
  _posRefundInvoiceId = invoiceId;
  // Pre-select all lines at their original qty
  _posRefundLines = (inv.lines || []).filter(l => l.line_type !== 'comment').map(l => ({
    invoice_line_id: l.id,
    description: l.description,
    qty: parseFloat(l.quantity || 1),
    unit_price: parseFloat(l.unit_price || 0),
    tax_code: l.tax_code || 'GST',
    account_id: l.account_id,
    refund_qty: parseFloat(l.quantity || 1),
  }));
  _posRenderRefundModal(inv, tender);
}

function _posRenderRefundModal(inv, tender) {
  document.getElementById('pos-refund-bd')?.remove();
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-refund-bd';
  const tenderLabel = tender === 'cash' ? 'Cash' : 'Card';
  bd.innerHTML = `<div class="modal-box pos-refund-modal">
    <div class="modal-hdr">
      <span>Refund — ${_esc(inv.invoice_number)}</span>
      <button class="modal-close" onclick="document.getElementById('pos-refund-bd').remove()">✕</button>
    </div>
    <div class="modal-body pos-refund-body">
      <p class="pos-refund-subtitle">Select quantities to refund and choose tender method.</p>
      <table class="inv-list-table pos-refund-table">
        <thead><tr>
          <th>Item</th>
          <th style="text-align:right">Orig</th>
          <th style="text-align:right">Refund Qty</th>
          <th style="text-align:right">Unit</th>
          <th style="text-align:right">Amount</th>
        </tr></thead>
        <tbody id="pos-refund-lines">
        ${_posRefundLines.map((l, i) => `
          <tr>
            <td>${_esc(l.description)}</td>
            <td style="text-align:right">${l.qty}</td>
            <td style="text-align:right">
              <input class="pos-refund-qty-inp" type="number"
                     min="0" max="${l.qty}" step="0.001"
                     value="${l.refund_qty}"
                     oninput="_posRefundUpdateTotal(${i}, this.value)">
            </td>
            <td style="text-align:right">$${l.unit_price.toFixed(2)}</td>
            <td style="text-align:right" id="pos-refund-line-${i}">
              $${(l.refund_qty * l.unit_price).toFixed(2)}
            </td>
          </tr>`).join('')}
        </tbody>
      </table>
      <div class="pos-refund-totals">
        <div class="pos-refund-tender-row">
          <label>Return tender:</label>
          <select id="pos-refund-tender" class="pos-refund-tender-sel">
            <option value="cash" ${tender === 'cash' ? 'selected' : ''}>Cash</option>
            <option value="card" ${tender !== 'cash' ? 'selected' : ''}>Card</option>
          </select>
        </div>
        <div class="pos-refund-total-row">
          <span>Refund Total:</span>
          <strong id="pos-refund-total">$0.00</strong>
        </div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-sec" onclick="document.getElementById('pos-refund-bd').remove()">Cancel</button>
      <button class="btn btn-sec" id="pos-store-credit-btn" onclick="_posStoreCreditConfirm()">
        Store Credit
      </button>
      <button class="btn btn-danger" id="pos-refund-confirm-btn" onclick="_posRefundConfirm()">
        Refund
      </button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  _posRefundUpdateTotal(-1, 0); // compute initial total
}

function _posRefundUpdateTotal(lineIdx, val) {
  if (lineIdx >= 0 && _posRefundLines[lineIdx]) {
    const max = _posRefundLines[lineIdx].qty;
    let n = parseFloat(val) || 0;
    if (n < 0) n = 0;
    if (n > max) n = max;
    _posRefundLines[lineIdx].refund_qty = n;
    const el = document.getElementById(`pos-refund-line-${lineIdx}`);
    if (el) el.textContent = `$${(n * _posRefundLines[lineIdx].unit_price).toFixed(2)}`;
  }
  const total = _posRefundLines.reduce((s, l) => s + l.refund_qty * l.unit_price, 0);
  const el = document.getElementById('pos-refund-total');
  if (el) el.textContent = `$${total.toFixed(2)}`;
  const btn = document.getElementById('pos-refund-confirm-btn');
  if (btn) btn.disabled = total <= 0;
}

async function _posRefundConfirm() {
  const tender = document.getElementById('pos-refund-tender')?.value || 'cash';
  const lines = _posRefundLines
    .filter(l => l.refund_qty > 0)
    .map(l => ({
      invoice_line_id: l.invoice_line_id,
      quantity: l.refund_qty,
      description: l.description,
      unit_price: l.unit_price,
      tax_code: l.tax_code,
      account_id: l.account_id,
    }));
  if (!lines.length) { toast('No items selected for refund', 'err'); return; }
  const btn = document.getElementById('pos-refund-confirm-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Processing…'; }
  try {
    const r = await fetch('/api/pos/refund', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ invoice_id: _posRefundInvoiceId, lines, tender }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Refund failed');
    document.getElementById('pos-refund-bd')?.remove();
    const { cn_id, cn_number, total } = r.data;
    _posShowRefundReceipt(cn_id, cn_number, total, tender);
    _posHistorySales = await apiFetch('/api/pos/sales?limit=200').catch(() => _posHistorySales);
  } catch(e) {
    toast(e.message || 'Refund failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Issue Refund'; }
  }
}

function _posShowRefundReceipt(cnId, cnNumber, total, tender) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-refund-rcpt-bd';
  bd.innerHTML = `<div class="modal-box pos-receipt-modal" style="text-align:center">
    <div class="modal-hdr"><span>Refund Issued</span></div>
    <div class="modal-body" style="padding:20px 16px">
      <div style="font-size:28px;color:var(--green)">↩</div>
      <div style="font-size:18px;font-weight:600;margin:6px 0">${_esc(cnNumber)}</div>
      <div style="font-size:22px;font-weight:700;margin:4px 0">$${parseFloat(total).toFixed(2)}</div>
      <div style="color:var(--ink2);font-size:13px">${tender === 'cash' ? 'Cash refund' : 'Card refund'}</div>
    </div>
    <div class="modal-foot" style="justify-content:center;gap:8px">
      <button class="btn btn-sec" id="pos-refund-print-btn"
              onclick="_posPrintRefundReceipt(${cnId},'${tender}',${parseFloat(total).toFixed(4)})">
        Print Receipt
      </button>
      <button class="btn" onclick="document.getElementById('pos-refund-rcpt-bd').remove()">
        Done
      </button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  if (_posSettings.auto_print) {
    _posPrintRefundReceipt(cnId, tender, parseFloat(total));
  }
}

async function _posPrintRefundReceipt(cnId, tender, amount) {
  const btn = document.getElementById('pos-refund-print-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Printing…'; }
  try {
    const r = await fetch('/api/pos/print-refund-receipt', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ cn_id: cnId, tender, amount }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Print failed');
    toast('Refund receipt printed');
  } catch(e) {
    toast(e.message || 'Print failed', 'err');
  }
  if (btn) { btn.disabled = false; btn.textContent = 'Print Receipt'; }
}


async function _posStoreCreditConfirm() {
  const lines = _posRefundLines
    .filter(l => l.refund_qty > 0)
    .map(l => ({
      invoice_line_id: l.invoice_line_id,
      quantity: l.refund_qty,
      description: l.description,
      unit_price: l.unit_price,
      tax_code: l.tax_code,
      account_id: l.account_id,
    }));
  if (!lines.length) { toast('No items selected', 'err'); return; }
  const btn = document.getElementById('pos-store-credit-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Processing…'; }
  try {
    const r = await fetch('/api/pos/store-credit', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ invoice_id: _posRefundInvoiceId, lines }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Failed');
    document.getElementById('pos-refund-bd')?.remove();
    const { cn_id, cn_number, total } = r.data;
    _posShowStoreCreditModal(cn_id, cn_number, total);
    _posHistorySales = await apiFetch('/api/pos/sales?limit=200').catch(() => _posHistorySales);
  } catch(e) {
    toast(e.message || 'Failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Store Credit'; }
  }
}

function _posShowStoreCreditModal(cnId, cnNumber, total) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-sc-bd';
  bd.innerHTML = `<div class="modal-box pos-receipt-modal" style="text-align:center">
    <div class="modal-hdr"><span>Store Credit Issued</span></div>
    <div class="modal-body" style="padding:20px 16px">
      <div style="font-size:28px;color:var(--accent)">★</div>
      <div style="font-size:18px;font-weight:600;margin:6px 0">${_esc(cnNumber)}</div>
      <div style="font-size:22px;font-weight:700;margin:4px 0">$${parseFloat(total).toFixed(2)}</div>
      <div style="color:var(--ink2);font-size:13px">Store credit — available for future purchases</div>
    </div>
    <div class="modal-foot" style="justify-content:center;gap:8px">
      <button class="btn btn-sec" id="pos-sc-print-btn"
              onclick="_posPrintCreditNote(${cnId},${parseFloat(total).toFixed(4)})">
        Print Credit Note
      </button>
      <button class="btn" onclick="document.getElementById('pos-sc-bd').remove()">Done</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  if (_posSettings.auto_print) {
    _posPrintCreditNote(cnId, parseFloat(total));
  }
}

async function _posPrintCreditNote(cnId, amount) {
  const btn = document.getElementById('pos-sc-print-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Printing…'; }
  try {
    const r = await fetch('/api/pos/print-credit-note', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ cn_id: cnId, amount }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Print failed');
    toast('Credit note printed');
  } catch(e) {
    toast(e.message || 'Print failed', 'err');
  }
  if (btn) { btn.disabled = false; btn.textContent = 'Print Credit Note'; }
}


// ═══════════════════════════════════════════════════════════════════════════
// CASH DRAWER
// ═══════════════════════════════════════════════════════════════════════════

async function _posOpenDrawer() {
  try {
    const r = await fetch('/api/pos/open-drawer', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
    }).then(r => r.json());
    if (r.ok) toast('Cash drawer opened');
    else toast(r.error || 'Could not open drawer', 'err');
  } catch(e) {
    toast(e.message || 'Drawer error', 'err');
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// SESSION HISTORY
// ═══════════════════════════════════════════════════════════════════════════

async function _posOpenSessionHistory() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-sess-hist-bd';
  bd.innerHTML = `<div class="modal-box pos-hist-modal" style="display:flex;flex-direction:column;max-height:90vh">
    <div class="modal-hdr">
      <span>Session History</span>
      <button class="modal-close" onclick="document.getElementById('pos-sess-hist-bd').remove()">✕</button>
    </div>
    <div class="modal-body" id="pos-sess-hist-body" style="overflow-y:auto;flex:1;padding:0">
      <div class="state-loading" style="padding:24px">Loading…</div>
    </div>
  </div>`;
  document.body.appendChild(bd);
  try {
    const sessions = await apiFetch('/api/pos/sessions');
    _posRenderSessionHistoryList(sessions);
  } catch(e) {
    document.getElementById('pos-sess-hist-body').innerHTML =
      `<div class="state-error" style="padding:24px">${_esc(e.message)}</div>`;
  }
}

function _posRenderSessionHistoryList(sessions) {
  const el = document.getElementById('pos-sess-hist-body');
  if (!el) return;
  if (!sessions.length) {
    el.innerHTML = '<div class="pos-empty" style="padding:32px">No sessions recorded yet</div>';
    return;
  }
  el.innerHTML = `<div class="tbl-overflow-x">
    <table class="inv-list-table">
      <thead><tr>
        <th>Session</th><th>Opened</th><th>Closed</th>
        <th style="text-align:right">Txns</th>
        <th style="text-align:right">Total</th>
        <th></th>
      </tr></thead>
      <tbody>
      ${sessions.map(s => {
        const isOpen  = !s.closed_at;
        const opened  = (s.opened_at || '').slice(0, 16).replace('T', ' ');
        const closed  = s.closed_at ? s.closed_at.slice(0, 16).replace('T', ' ') : '—';
        const noteHtml = s.note ? ` <span style="color:var(--ink3);font-size:11px">${_esc(s.note)}</span>` : '';
        return `<tr>
          <td>#${s.id}${noteHtml}</td>
          <td>${opened}</td>
          <td>${closed}</td>
          <td style="text-align:right">${s.tx_count || 0}</td>
          <td style="text-align:right">$${parseFloat(s.total||0).toFixed(2)}</td>
          <td>
            <button class="btn btn-sm btn-sec" onclick="_posViewSessionReport(${s.id})">
              ${isOpen ? 'X-View' : 'Z-Report'}
            </button>
          </td>
        </tr>`;
      }).join('')}
      </tbody>
    </table>
  </div>`;
}

async function _posViewSessionReport(sessionId) {
  document.getElementById('pos-sess-hist-bd')?.remove();
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-zrpt-bd';
  bd.innerHTML = `<div class="modal-box pos-zrpt-modal">
    <div class="modal-hdr" id="pos-zrpt-hdr">Loading…</div>
    <div class="modal-body" id="pos-zrpt-body"><div class="state-loading">Loading…</div></div>
    <div class="modal-foot" id="pos-zrpt-foot">
      <button class="btn" onclick="document.getElementById('pos-zrpt-bd').remove()">Close</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  try {
    const report  = await apiFetch(`/api/pos/session/${sessionId}/report`);
    const isClosed = !!report.closed_at;
    _posRenderZReport(report, isClosed, true);
  } catch(e) {
    document.getElementById('pos-zrpt-body').innerHTML =
      `<div class="state-error">${_esc(e.message)}</div>`;
  }
}
