// Point of Sale — _pos prefix for all globals
'use strict';

let _posItems  = [];   // full item catalogue from server
let _posCart   = [];   // [{item_id, description, qty, unit_price, tax_code, account_id, total, gst}]
let _posSearch = '';
let _posPollTimer = null;

function _esc(s) {
  return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}


// ═══════════════════════════════════════════════════════════════════════════
// ENTRY POINT
// ═══════════════════════════════════════════════════════════════════════════

async function pagePos() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    _posItems = await apiFetch('/api/pos/items');
    _posCart  = [];
    _posSearch = '';
    _posRender();
  } catch(e) {
    toast(e.message || 'Failed to load POS', 'err');
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// LAYOUT
// ═══════════════════════════════════════════════════════════════════════════

function _posRender() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = `
    <div class="pos-wrap">
      <div class="pos-items-panel">
        <div class="pos-search-bar">
          <input class="pos-search-inp" type="text" id="pos-search"
                 placeholder="Search items or scan barcode…"
                 oninput="_posFilter(this.value)">
          <button class="pos-search-clear" onclick="_posClearSearch()" title="Clear">&#x2715;</button>
        </div>
        <div class="pos-grid" id="pos-grid"></div>
      </div>
      <div class="pos-cart-panel">
        <div class="pos-cart-hdr">
          <span>Cart</span>
          <button class="pos-clear-btn" onclick="_posClearCart()">Clear</button>
        </div>
        <div class="pos-cart-lines" id="pos-cart-lines"></div>
        <div class="pos-cart-footer">
          <div class="pos-totals" id="pos-totals"></div>
          <div class="pos-tender-btns" id="pos-tender-btns"></div>
        </div>
      </div>
    </div>`;
  setTimeout(() => document.getElementById('pos-search')?.focus(), 80);
  _posRenderGrid();
  _posRenderCart();
}


// ═══════════════════════════════════════════════════════════════════════════
// ITEM GRID
// ═══════════════════════════════════════════════════════════════════════════

function _posFilter(q) {
  _posSearch = q.toLowerCase();
  _posRenderGrid();
}

function _posClearSearch() {
  _posSearch = '';
  const inp = document.getElementById('pos-search');
  if (inp) inp.value = '';
  _posRenderGrid();
  inp?.focus();
}

function _posRenderGrid() {
  const grid = document.getElementById('pos-grid');
  if (!grid) return;
  const q = _posSearch;
  const visible = q
    ? _posItems.filter(i =>
        (i.name    || '').toLowerCase().includes(q) ||
        (i.code    || '').toLowerCase().includes(q) ||
        (i.barcode || '').toLowerCase().includes(q))
    : _posItems;

  if (!visible.length) {
    grid.innerHTML = `<div class="pos-empty">${q ? 'No items match “' + _esc(q) + '”' : 'No items in catalogue'}</div>`;
    return;
  }
  grid.innerHTML = visible.map(i => `
    <div class="pos-tile" onclick="_posAddItem(${i.id})" title="${_esc(i.name)}">
      <div class="pos-tile-name">${_esc(i.name)}</div>
      ${i.code ? `<div class="pos-tile-code">${_esc(i.code)}</div>` : ''}
      <div class="pos-tile-price">$${(i.unit_price || 0).toFixed(2)}</div>
    </div>`).join('');
}


// ═══════════════════════════════════════════════════════════════════════════
// CART
// ═══════════════════════════════════════════════════════════════════════════

function _posAddItem(itemId) {
  const item = _posItems.find(i => i.id === itemId);
  if (!item) return;
  const existing = _posCart.find(l => l.item_id === itemId);
  if (existing) {
    existing.qty++;
    _posCalcLine(existing);
  } else {
    const line = {
      item_id:     item.id,
      description: item.name,
      qty:         1,
      unit_price:  item.unit_price || 0,
      tax_code:    item.tax_code || 'GST',
      account_id:  item.account_id || null,
    };
    _posCalcLine(line);
    _posCart.push(line);
  }
  _posRenderCart();
}

function _posCalcLine(line) {
  const gst_rate = line.tax_code === 'GST' ? 0.1 : 0;
  line.total = Math.round(line.qty * line.unit_price * 100) / 100;
  line.gst   = Math.round(line.total * gst_rate / (1 + gst_rate) * 100) / 100;
}

function _posQtyDelta(idx, delta) {
  const line = _posCart[idx];
  if (!line) return;
  line.qty = Math.max(1, line.qty + delta);
  _posCalcLine(line);
  _posRenderCart();
}

function _posSetQty(idx, val) {
  const line = _posCart[idx];
  if (!line) return;
  const n = parseInt(val, 10);
  line.qty = (isNaN(n) || n < 1) ? 1 : n;
  _posCalcLine(line);
  _posRenderCart();
}

function _posRemoveLine(idx) {
  _posCart.splice(idx, 1);
  _posRenderCart();
}

function _posClearCart() {
  _posCart = [];
  _posRenderCart();
}

function _posRenderCart() {
  const linesEl  = document.getElementById('pos-cart-lines');
  const totalsEl = document.getElementById('pos-totals');
  const btnsEl   = document.getElementById('pos-tender-btns');
  if (!linesEl) return;

  if (!_posCart.length) {
    linesEl.innerHTML  = '<div class="pos-cart-empty">Cart is empty—tap items to add</div>';
    totalsEl.innerHTML = '';
    btnsEl.innerHTML   = `
      <button class="pos-btn pos-btn-cash" disabled>Cash</button>
      <button class="pos-btn pos-btn-card" disabled>Card</button>`;
    return;
  }

  linesEl.innerHTML = _posCart.map((l, idx) => `
    <div class="pos-cart-line">
      <div class="pos-cart-desc">${_esc(l.description)}</div>
      <div class="pos-cart-qty">
        <button class="pos-qty-btn" onclick="_posQtyDelta(${idx},-1)">&#x2212;</button>
        <input class="pos-qty-inp" type="number" min="1" value="${l.qty}"
               onchange="_posSetQty(${idx},this.value)" onclick="this.select()">
        <button class="pos-qty-btn" onclick="_posQtyDelta(${idx},1)">+</button>
      </div>
      <div class="pos-cart-price">$${l.total.toFixed(2)}</div>
      <button class="pos-rm-btn" onclick="_posRemoveLine(${idx})" title="Remove">&#x2715;</button>
    </div>`).join('');

  const subtotal = _posCart.reduce((s, l) => s + (l.total - l.gst), 0);
  const gst      = _posCart.reduce((s, l) => s + l.gst, 0);
  const total    = _posCart.reduce((s, l) => s + l.total, 0);

  totalsEl.innerHTML = `
    <div class="pos-total-row"><span>Subtotal (ex GST)</span><span>$${subtotal.toFixed(2)}</span></div>
    <div class="pos-total-row"><span>GST</span><span>$${gst.toFixed(2)}</span></div>
    <div class="pos-total-row pos-grand-total"><span>TOTAL</span><span>$${total.toFixed(2)}</span></div>`;

  btnsEl.innerHTML = `
    <button class="pos-btn pos-btn-cash" onclick="_posTenderCash(${total.toFixed(4)})">Cash</button>
    <button class="pos-btn pos-btn-card" onclick="_posTenderCard(${total.toFixed(4)})">Card</button>`;
}


// ═══════════════════════════════════════════════════════════════════════════
// CASH TENDER
// ═══════════════════════════════════════════════════════════════════════════

function _posTenderCash(total) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box pos-tender-modal">
    <div class="modal-hdr">Cash Payment &mdash; $${parseFloat(total).toFixed(2)} due</div>
    <div class="modal-body">
      <label class="pos-tender-label">Amount tendered ($)</label>
      <input class="pos-tender-inp" id="pos-tendered" type="number" step="0.05"
             min="${parseFloat(total).toFixed(2)}" value="${parseFloat(total).toFixed(2)}"
             oninput="_posCalcChange(${parseFloat(total).toFixed(4)})">
      <div class="pos-change-row" id="pos-change-row"></div>
      <div class="pos-quick-btns">
        ${_posQuickAmounts(total).map(a =>
          `<button class="pos-quick-btn" onclick="_posSetTendered(${a},${ parseFloat(total).toFixed(4)})"
           >$${a.toFixed(2)}</button>`
        ).join('')}
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary" id="pos-cash-ok" onclick="_posConfirmCash(${parseFloat(total).toFixed(4)})">
        Confirm Sale
      </button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  _posCalcChange(total);
  setTimeout(() => { document.getElementById('pos-tendered')?.select(); }, 60);
}

function _posQuickAmounts(total) {
  const amounts = [];
  for (const multiple of [5, 10, 20, 50, 100]) {
    const a = Math.ceil(total / multiple) * multiple;
    if (!amounts.includes(a)) amounts.push(a);
    if (amounts.length >= 4) break;
  }
  return amounts;
}

function _posSetTendered(amount, total) {
  const inp = document.getElementById('pos-tendered');
  if (inp) { inp.value = amount.toFixed(2); }
  _posCalcChange(total);
}

function _posCalcChange(total) {
  const inp     = document.getElementById('pos-tendered');
  const row     = document.getElementById('pos-change-row');
  const btn     = document.getElementById('pos-cash-ok');
  if (!inp || !row) return;
  const tendered = parseFloat(inp.value) || 0;
  const change   = tendered - total;
  if (change >= 0) {
    row.innerHTML = `<span class="pos-change-ok">Change: $${change.toFixed(2)}</span>`;
    if (btn) btn.disabled = false;
  } else {
    row.innerHTML = `<span class="pos-change-err">Amount insufficient</span>`;
    if (btn) btn.disabled = true;
  }
}

async function _posConfirmCash(total) {
  const inp = document.getElementById('pos-tendered');
  const tendered = parseFloat(inp?.value) || total;
  const bd  = inp?.closest('.modal-bd');
  const btn = document.getElementById('pos-cash-ok');
  if (btn) { btn.disabled = true; btn.textContent = 'Processing…'; }
  try {
    const result = await _posSubmitSale('cash', tendered, null, null);
    bd?.remove();
    _posShowReceipt(result, result.change);
  } catch(e) {
    toast(e.message || 'Sale failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Confirm Sale'; }
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// CARD TENDER
// ═══════════════════════════════════════════════════════════════════════════

async function _posTenderCard(total) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-card-modal';
  bd.innerHTML = `<div class="modal-box pos-tender-modal">
    <div class="modal-hdr">Card Payment &mdash; $${parseFloat(total).toFixed(2)}</div>
    <div class="modal-body" id="pos-card-body">
      <div class="pos-terminal-waiting">
        <div class="pos-terminal-spinner"></div>
        <div class="pos-terminal-msg">Connecting to terminal…</div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn" onclick="_posCancelCard()">Cancel</button>
    </div>
  </div>`;
  document.body.appendChild(bd);

  const ref = `POS-${Date.now()}`;
  try {
    const r = await fetch('/api/pos/terminal/charge', {
      method:  'POST',
      headers: {'Content-Type': 'application/json'},
      body:    JSON.stringify({amount: parseFloat(total), reference: ref}),
    }).then(r => r.json());

    if (!r.ok) throw new Error(r.error || 'Terminal error');
    const {checkout_id, provider} = r.data;

    document.getElementById('pos-card-body').innerHTML = `
      <div class="pos-terminal-waiting">
        <div class="pos-terminal-spinner"></div>
        <div class="pos-terminal-msg">Waiting for customer to tap or insert card…</div>
        <div class="pos-terminal-sub">Present card on the terminal</div>
      </div>`;

    _posPollTerminal(checkout_id, provider, total);
  } catch(e) {
    const body = document.getElementById('pos-card-body');
    if (body) body.innerHTML = `<div class="pos-terminal-error">${_esc(e.message)}</div>`;
  }
}

async function _posPollTerminal(checkoutId, provider, total) {
  let count = 0;
  clearInterval(_posPollTimer);
  _posPollTimer = setInterval(async () => {
    count++;
    if (count > 90) {  // 3-minute timeout at 2s intervals
      clearInterval(_posPollTimer);
      const body = document.getElementById('pos-card-body');
      if (body) body.innerHTML = '<div class="pos-terminal-error">Terminal timeout — please retry</div>';
      return;
    }
    try {
      const res = await apiFetch(`/api/pos/terminal/charge/${checkoutId}?provider=${provider}`);
      if (res.status === 'completed') {
        clearInterval(_posPollTimer);
        try {
          const result = await _posSubmitSale('card', null, checkoutId, provider);
          document.getElementById('pos-card-modal')?.remove();
          _posShowReceipt(result, 0);
        } catch(e) {
          const body = document.getElementById('pos-card-body');
          if (body) body.innerHTML = `<div class="pos-terminal-error">${_esc(e.message)}</div>`;
        }
      } else if (res.status === 'declined' || res.status === 'error') {
        clearInterval(_posPollTimer);
        const body = document.getElementById('pos-card-body');
        if (body) body.innerHTML = `<div class="pos-terminal-error">${_esc(res.message || 'Payment declined')}</div>`;
      }
    } catch(_) { /* keep polling on transient errors */ }
  }, 2000);
}

function _posCancelCard() {
  clearInterval(_posPollTimer);
  document.getElementById('pos-card-modal')?.remove();
}


// ═══════════════════════════════════════════════════════════════════════════
// SALE SUBMISSION
// ═══════════════════════════════════════════════════════════════════════════

async function _posSubmitSale(tender, tendered, terminalTxId, terminalProvider) {
  const r = await fetch('/api/pos/sale', {
    method:  'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      lines: _posCart.map(l => ({
        item_id:     l.item_id,
        description: l.description,
        qty:         l.qty,
        unit_price:  l.unit_price,
        tax_code:    l.tax_code,
        account_id:  l.account_id,
      })),
      tender,
      tendered,
      terminal_tx_id:  terminalTxId,
      terminal_provider: terminalProvider,
    }),
  }).then(r => r.json());

  if (!r.ok) throw new Error(r.error || 'Sale failed');
  _posCart = [];
  _posRenderCart();
  return r.data;
}


// ═══════════════════════════════════════════════════════════════════════════
// RECEIPT
// ═══════════════════════════════════════════════════════════════════════════

function _posShowReceipt(result, change) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box pos-receipt-modal">
    <div class="modal-hdr pos-receipt-hdr">&#x2713; Sale Complete</div>
    <div class="modal-body pos-receipt-body">
      <div class="pos-receipt-num">Invoice ${_esc(result.invoice_number || '')}</div>
      <div class="pos-receipt-total">$${parseFloat(result.total || 0).toFixed(2)}</div>
      ${change > 0.005 ? `<div class="pos-receipt-change">Change: $${change.toFixed(2)}</div>` : ''}
    </div>
    <div class="modal-foot">
      <button class="btn" onclick="window.print();this.closest('.modal-bd').remove()">
        Print Receipt
      </button>
      <button class="btn btn-primary" onclick="this.closest('.modal-bd').remove()">
        New Sale
      </button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  toast(`Sale ${result.invoice_number} recorded`);
}
