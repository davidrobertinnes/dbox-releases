// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// Point of Sale — entry point + shared globals
// Sub-files loaded before this one (see dashboard.html):
//   pos/cart.js          — item grid, barcode scan, cart, parked sales, customer picker, stock warning
//   pos/tender.js        — cash, card (Linkly), split, on-account tender, sale submission
//   pos/terminal_tyro.js — Tyro iClient adapter
//   pos/terminal_linkly.js — Linkly pairing, settlement, recovery receipt
//   pos/session.js       — Z-report, PIN sign-on, till balance, session/sales history, analytics
//   pos/refund.js        — refund and store credit flow
//   pos/settings.js      — POS settings modal

'use strict';

// ═══════════════════════════════════════════════════════════════════════════
// SHARED GLOBALS — declared here so every sub-file can read/write them
// ═══════════════════════════════════════════════════════════════════════════

var _posItems     = [];   // full item catalogue from server
var _posCart      = [];   // [{item_id, description, qty, unit_price, tax_code, account_id, total, gst}]
var _posSearch    = '';
var _posPollTimer = null;
var _posSession   = null; // {id, opened_at} or null
var _posSettings  = {};   // cached settings (for auto_print flag)
var _posContacts      = [];   // all contacts for customer picker
var _posContactId     = null; // selected contact for current sale (null = use walk-in default)
var _posLastFloat     = 0;    // float_kept from last closed session
var _posPendingReport = null; // report passed between Z-report close steps
var _posHistorySales  = [];   // loaded sales for history modal filtering
var _posRefundLines                = [];
var _posRefundInvoiceId            = null;
var _posRefundTerminalProvider     = null;  // 'linkly'|'tyro' if original was card via terminal
var _posRefundTyroSurchargeCents   = 0;     // surcharge from the original Tyro sale (cents)
var _posTyroClient           = null;   // cached Tyro iClient instance
var _posTyroScriptReady      = null;   // Promise that resolves when iClient script is loaded
var _posTyroCustomerReceipt  = null;   // customer receipt text from integrated receipt
var _posTyroSplitSurchargeCents = 0;   // surcharge from split Tyro leg (cents)
var _posPinUserId      = null;   // user_id of signed-in operator (null = no PIN required)
var _posPinUserName    = null;   // display_name of signed-in operator
var _posCatFilter           = null;   // active category pill (null = All)
var _posCurrentReceipt      = null;   // stored receipt params for reprint
var _posStockWarnProceedFn  = null;   // callback stored for stock warning modal
var _posBasketDiscount      = 0;      // % off the whole basket (transaction-level)
var _posParkedCarts         = [];     // [{id, ts, contactId, contactName, basketDiscount, cart}]
var _posParkedSeq           = 0;      // incrementing ID for parked carts
var _posAnActiveTab         = 'analytics';  // 'analytics' | 'staff'
var _posAnData              = null;         // cached analytics API response
var _posAnStaffData         = null;         // cached staff report API response
var _posScanMode            = false;        // barcode scan mode active
var _posScanBuf             = '';           // keystroke buffer for scanner detection
var _posScanLast            = 0;            // timestamp of last buffered keystroke
var _posLinkedTabId         = null;         // Table Service tab_id linked to the current cart (if resumed from TS)

function _esc(s) {
  return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}


// ═══════════════════════════════════════════════════════════════════════════
// ENTRY POINT
// ═══════════════════════════════════════════════════════════════════════════

async function pagePos() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    const [items, sessionData, settings, contacts] = await Promise.all([
      apiFetch('/api/pos/items'),
      apiFetch('/api/pos/session').catch(() => ({})),
      apiFetch('/api/pos/settings').catch(() => ({})),
      apiFetch('/api/contacts').catch(() => []),
    ]);
    _posItems    = items;
    _posSession  = sessionData?.session ?? null;
    _posLastFloat = sessionData?.last_float ?? 0;
    _posSettings = settings;
    _posContacts = contacts;
    _posCart           = [];
    _posSearch         = '';
    _posContactId      = null;
    _posCatFilter      = null;
    _posCurrentReceipt = null;
    _posScanMode       = false;
    // Load DB-persisted parked carts (survive page reloads, visible across devices)
    try {
      const sessionParam = _posSession?.id ? `?session_id=${_posSession.id}` : '';
      const dbCarts = await apiFetch(`/api/ts/parked${sessionParam}`).catch(() => []);
      _posParkedCarts = (dbCarts || []).map(c => ({
        id:             c.id,
        dbId:           c.id,
        ts:             c.created_at,
        label:          c.label,
        contactId:      c.cart_data?.contactId || null,
        contactName:    c.cart_data?.contactName || null,
        basketDiscount: c.cart_data?.basketDiscount || 0,
        cart:           c.cart_data?.lines || [],
        tabId:          c.cart_data?._tab_id || null,
      }));
    } catch (_) { _posParkedCarts = []; }
    _posScanBuf        = '';
    document.removeEventListener('keydown', _posScanGlobal);
    document.addEventListener('keydown', _posScanGlobal);
    _posRender();
    // Tyro recovery: only call continueLastTransaction() if we flagged an in-progress
    // transaction before the page was closed/refreshed. Without the flag, calling it
    // unconditionally tries to reach the terminal on every startup and shows
    // "connection lost" if the terminal isn't immediately reachable.
    if (settings.provider === 'tyro' && sessionStorage.getItem('tyro_tx_pending')) {
      sessionStorage.removeItem('tyro_tx_pending');
      _posGetTyroClient().then(client => {
        client.continueLastTransaction({
          receiptCallback: function(receipt) {
            if (receipt && (receipt.signatureRequired || _posSettings.tyro_merchant_copy)) {
              _posTyroPrintMerchantReceipt(receipt.merchantReceipt || '', receipt.signatureRequired);
            }
          },
          transactionCompleteCallback: function(td) {
            if (td.result === 'APPROVED') {
              const surchargeCents = td.surchargeAmount ? Math.round(parseFloat(td.surchargeAmount) * 100) : 0;
              if (td.customerReceipt) _posTyroCustomerReceipt = td.customerReceipt;
              const bd = document.createElement('div');
              bd.className = 'modal-bd';
              bd.style.display = 'flex';
              bd.id = 'pos-tyro-recover-bd';
              bd.innerHTML = '<div class="modal-box" style="max-width:420px">'
                + '<div class="modal-hdr"><span>Recovered Tyro Transaction</span></div>'
                + '<div class="modal-body" style="padding:16px;font-size:14px">'
                + '<p style="margin:0 0 8px">A completed Tyro transaction was found from before the page reloaded.</p>'
                + '<table style="width:100%;border-collapse:collapse;font-size:13px">'
                + '<tr><td style="color:var(--ink2);padding:3px 8px 3px 0">Result</td>'
                + '<td style="font-weight:600;color:var(--green)">' + _esc(td.result) + '</td></tr>'
                + (td.transactionReference ? '<tr><td style="color:var(--ink2);padding:3px 8px 3px 0">TXN Ref</td>'
                  + '<td style="font-family:monospace">' + _esc(td.transactionReference) + '</td></tr>' : '')
                + (td.authorisationCode ? '<tr><td style="color:var(--ink2);padding:3px 8px 3px 0">Auth Code</td>'
                  + '<td style="font-family:monospace">' + _esc(td.authorisationCode) + '</td></tr>' : '')
                + (surchargeCents ? '<tr><td style="color:var(--ink2);padding:3px 8px 3px 0">Surcharge</td>'
                  + '<td>$' + (surchargeCents / 100).toFixed(2) + '</td></tr>' : '')
                + '</table>'
                + '<p style="margin:10px 0 0;color:var(--ink2);font-size:12px">Check whether the corresponding POS sale was recorded. If not, complete it manually using the transaction reference above.</p>'
                + '</div>'
                + '<div class="modal-foot"><button class="btn" onclick="document.getElementById(\'pos-tyro-recover-bd\')?.remove()">OK</button></div>'
                + '</div>';
              document.body.appendChild(bd);
            }
          },
        });
      }).catch(() => {});
    }

    // Power-fail recovery: if provider is Linkly, check for an incomplete transaction
    if (settings.provider === 'linkly') {
      apiFetch('/api/pos/terminal/recover').then(res => {
        if (res?.pending && (res?.status === 'completed' || res?.status === 'declined')) {
          const failed = res.status === 'declined';
          const bd = document.createElement('div');
          bd.className = 'modal-bd';
          bd.style.display = 'flex';
          bd.id = 'pos-recover-bd';
          window._posRecoverData = res;
          bd.innerHTML = `<div class="modal-box" style="max-width:420px">
            <div class="modal-hdr"><span>${failed ? 'Transaction Failed — Recovery' : 'Recovered Transaction'}</span></div>
            <div class="modal-body" style="padding:16px;font-size:14px">
              <p style="margin:0 0 8px">${failed ? 'A failed transaction was found from before the last restart.' : 'A terminal transaction was found from before the last restart.'}</p>
              <table style="width:100%;border-collapse:collapse;font-size:13px">
                <tr><td style="color:var(--ink2);padding:3px 8px 3px 0">Status</td>
                    <td style="font-weight:600;color:${failed ? 'var(--red)' : 'inherit'}">${_esc(res.response_text || (failed ? 'Declined' : 'Approved'))}</td></tr>
                ${!failed && res.amount != null ? `<tr><td style="color:var(--ink2);padding:3px 8px 3px 0">Amount</td>
                    <td>$${(res.amount / 100).toFixed(2)}</td></tr>` : ''}
                ${res.tx_id ? `<tr><td style="color:var(--ink2);padding:3px 8px 3px 0">TXN Ref</td>
                    <td style="font-family:monospace">${_esc(res.tx_id)}</td></tr>` : ''}
                ${res.rfn ? `<tr><td style="color:var(--ink2);padding:3px 8px 3px 0">RFN</td>
                    <td style="font-family:monospace">${_esc(res.rfn)}</td></tr>` : ''}
              </table>
              <p style="margin:10px 0 0;color:var(--ink2);font-size:12px">
                ${failed ? 'No payment was taken. The sale is incomplete — no action required.' : 'Check whether the corresponding POS sale was recorded. If not, complete it manually.'}
              </p>
            </div>
            <div class="modal-foot">
              <button class="btn btn-sec" id="pos-recover-print-btn" onclick="_posPrintRecoveryReceipt(window._posRecoverData)">Print Receipt</button>
              <button class="btn" onclick="document.getElementById('pos-recover-bd')?.remove()">OK</button>
            </div>
          </div>`;
          document.body.appendChild(bd);
        }
      }).catch(() => {});
    }
  } catch(e) {
    toast(e.message || 'Failed to load POS', 'err');
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// LAYOUT
// ═══════════════════════════════════════════════════════════════════════════

function _posRender() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = `
    <div class="pos-wrap">
      <div class="pos-items-panel">
        <div class="pos-search-bar">
          <input class="pos-search-inp" type="text" id="pos-search"
                 placeholder="Search items or scan barcode…"
                 autocomplete="off"
                 oninput="_posFilter(this.value)"
                 onkeydown="_posScanKeyInSearch(event)">
          <button class="pos-search-clear" onclick="_posClearSearch()" title="Clear">&#x2715;</button>
          <button class="pos-custom-btn" onclick="_posAddCustomItem()" title="Custom line item">+ Custom</button>
          <button class="pos-custom-btn" onclick="_posOpenHistory()" title="Sales history">History</button>
          <button class="pos-custom-btn" onclick="_posOpenDrawer()" title="Open cash drawer">&#x23CF; Drawer</button>
          <button class="pos-custom-btn pos-scan-btn" id="pos-scan-btn" onclick="_posToggleScan()" title="Barcode scan mode — scanner adds items automatically">&#x29C9; Scan</button>
          <button class="pos-gear-btn" onclick="_posOpenSettings()" title="POS Settings">&#x2699;</button>
        </div>
        <div class="pos-cat-bar" id="pos-cat-bar"></div>
        <div class="pos-grid" id="pos-grid"></div>
      </div>
      <div class="pos-cart-panel">
        <div class="pos-cart-hdr">
          <span>Cart</span>
          <div class="pos-cart-hdr-btns" id="pos-cart-hdr-btns">
            <button class="pos-zrpt-btn" onclick="_posOpenSessionHistory()">Sessions</button>
            <button class="pos-zrpt-btn" onclick="_posOpenZReport()">End Day</button>
            <button class="pos-zrpt-btn" onclick="_posOpenAnalytics()">Analytics</button>
            <button class="pos-clear-btn" onclick="_posClearCart()">Clear</button>
          </div>
        </div>
        <div class="pos-session-bar" id="pos-session-bar"></div>
        <div class="pos-customer-bar" id="pos-customer-bar"></div>
        <div class="pos-cart-lines" id="pos-cart-lines"></div>
        <div class="pos-cart-footer">
          <div class="pos-totals" id="pos-totals"></div>
          <div class="pos-tender-btns" id="pos-tender-btns"></div>
        </div>
      </div>
    </div>`;
  setTimeout(() => document.getElementById('pos-search')?.focus(), 80);
  _posRenderCatBar();
  _posRenderGrid();
  _posRenderCart();
  _posRenderSessionBar();
}


// ═══════════════════════════════════════════════════════════════════════════
// RECEIPT DISPLAY, PRINT & EMAIL
// ═══════════════════════════════════════════════════════════════════════════

function _posShowReceipt(result, change, tender, tendered, splitTenders, tyroSurchargeCents) {
  const contactEmail = (result.contactEmail || '').trim();
  _posCurrentReceipt = {
    invoice_id:           result.invoice_id,
    tender:               tender || 'cash',
    tendered:             tendered || result.total,
    change:               change  || 0,
    splitTenders:         splitTenders || null,
    contactEmail,
    tyroSurchargeCents:   tyroSurchargeCents || 0,
    tyroCustomerReceipt:  _posTyroCustomerReceipt || null,
  };
  var bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-receipt-bd';
  var html = '<div class="modal-box pos-receipt-modal">';
  html += '<div class="modal-hdr pos-receipt-hdr">&#x2713; Sale Complete</div>';
  html += '<div class="modal-body pos-receipt-body">';
  html += '<div class="pos-receipt-num">Invoice ' + _esc(result.invoice_number || '') + '</div>';
  const surchargeDollars = tyroSurchargeCents ? tyroSurchargeCents / 100 : 0;
  html += '<div class="pos-receipt-total">$' + parseFloat(result.total || 0).toFixed(2) + '</div>';
  if (surchargeDollars > 0) {
    html += '<div class="pos-receipt-surcharge">Tyro Surcharge: $' + surchargeDollars.toFixed(2) + '</div>';
    html += '<div class="pos-receipt-charged">Card charged: $' + (parseFloat(result.total || 0) + surchargeDollars).toFixed(2) + '</div>';
  }
  if (splitTenders) {
    html += '<div class="pos-receipt-split">Cash $' + parseFloat(splitTenders.cash || 0).toFixed(2) +
            ' &bull; Card $' + parseFloat(splitTenders.card || 0).toFixed(2) + '</div>';
  } else if (tender === 'account') {
    html += '<div class="pos-receipt-change" style="color:var(--amber)">On Account — payment due</div>';
  } else if (change > 0.005) {
    html += '<div class="pos-receipt-change">Change: $' + change.toFixed(2) + '</div>';
  }
  if (contactEmail) {
    html += '<div class="pos-receipt-email-hint">&#x2709; ' + _esc(contactEmail) + '</div>';
  }
  if (_posTyroCustomerReceipt) {
    html += '<div class="pos-receipt-tyro-rcpt"><pre style="font-family:monospace;font-size:11px;white-space:pre-wrap;margin:8px 0 0;text-align:left">' + _esc(_posTyroCustomerReceipt) + '</pre></div>';
    _posTyroCustomerReceipt = null;
  }
  html += '</div>';
  html += '<div class="modal-foot">';
  html += '<button class="btn" id="pos-receipt-print-btn" onclick="_posPrintReceiptCurrent()">Print Receipt</button>';
  if (contactEmail) {
    html += '<button class="btn" id="pos-receipt-email-btn" onclick="_posEmailReceiptCurrent()">Email Receipt</button>';
  }
  html += '<button class="btn" onclick="window.open(\'/api/invoices/' + result.invoice_id + '/pdf\',\'_blank\')">Invoice PDF</button>';
  html += '<button class="btn btn-primary" onclick="document.getElementById(\'pos-receipt-bd\')?.remove()">New Sale</button>';
  html += '</div>';
  html += '</div>';
  bd.innerHTML = html;
  document.body.appendChild(bd);
  toast('Sale ' + (result.invoice_number || '') + ' recorded');
  if (_posSettings.printer_auto_print && _posSettings.printer_enabled) {
    _posPrintReceiptCurrent();
  }
}

async function _posEmailReceiptCurrent() {
  const r = _posCurrentReceipt;
  if (!r?.contactEmail) return;
  const btn = document.getElementById('pos-receipt-email-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }
  try {
    const res = await fetch('/api/invoices/' + r.invoice_id + '/email', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ to: r.contactEmail }),
    }).then(res => res.json());
    if (!res.ok) throw new Error(res.error || 'Send failed');
    toast('Receipt emailed to ' + r.contactEmail);
    if (btn) { btn.textContent = '✓ Sent'; }
  } catch(e) {
    toast(e.message || 'Email failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Email Receipt'; }
  }
}

function _posPrintReceiptCurrent() {
  if (!_posCurrentReceipt) return;
  var r = _posCurrentReceipt;
  _posPrintReceipt(r.invoice_id, r.tender, r.tendered, r.change, r.splitTenders,
                   r.tyroSurchargeCents || 0, r.tyroCustomerReceipt || null);
}

async function _posPrintReceipt(invoiceId, tender, tendered, change, splitTenders, tyroSurchargeCents, tyroReceiptText) {
  const btn = document.getElementById('pos-receipt-print-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Printing…'; }
  try {
    const r = await fetch('/api/pos/print-receipt', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        invoice_id:          invoiceId,
        tender,
        tendered,
        change,
        split_tenders:       splitTenders || null,
        tyro_surcharge_cents: tyroSurchargeCents || 0,
        tyro_receipt_text:   tyroReceiptText || null,
      }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Print failed');
    toast('Receipt printed');
    if (btn) { btn.disabled = false; btn.textContent = 'Print Receipt'; }
  } catch(e) {
    toast(e.message || 'Print failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Print Receipt'; }
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// CASH DRAWER
// ═══════════════════════════════════════════════════════════════════════════

async function _posOpenDrawer() {
  try {
    const r = await fetch('/api/pos/open-drawer', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
    }).then(r => r.json());
    if (r.ok) toast('Cash drawer opened');
    else toast(r.error || 'Could not open drawer', 'err');
  } catch(e) {
    toast(e.message || 'Drawer error', 'err');
  }
}
