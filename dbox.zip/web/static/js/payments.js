// ═══════════════════════════════════════════════════════════════════════════
// PAYMENTS PAGE
// ═══════════════════════════════════════════════════════════════════════════
let _pmtAll=[], _pmtFilter='All', _pmtSearch='', _pmtSort={col:'payment_date',dir:-1}, _pmtSelected=null;
let _pmtEditId=null;
const PMT_TYPES=['All','Receipt','Payment'];
const PMT_TYPE_BADGE={'Receipt':'badge-paid','Payment':'badge-overdue'};
const PMT_METHODS=['EFT','BPAY','Cash','Cheque','Credit Card','Direct Debit'];

async function pagePayments() {
  try {
    _pmtAll = await apiFetch('/api/payments') || [];
    renderPaymentsPage();
  } catch(e) {
    document.getElementById('module-content').innerHTML=`<div class="state-error">Failed to load payments: ${esc(e.message)}</div>`;
  }
}

function _pmtFiltered() {
  const q=_pmtSearch.toLowerCase();
  return _pmtAll.filter(p=>{
    if(_pmtFilter!=='All'&&p.payment_type!==_pmtFilter) return false;
    if(q&&![p.contact_name,p.reference,p.description,p.bank_name].some(v=>(v||'').toLowerCase().includes(q))) return false;
    return true;
  }).sort((a,b)=>{
    const col=_pmtSort.col, av=a[col]??'', bv=b[col]??'';
    return(typeof av==='number'?(av-bv):String(av).localeCompare(String(bv)))*_pmtSort.dir;
  });
}

function renderPaymentsPage(restoreFocus) {
  const rows=_pmtFiltered();
  const counts={All:_pmtAll.length};
  PMT_TYPES.slice(1).forEach(t=>{ counts[t]=_pmtAll.filter(p=>p.payment_type===t).length; });
  const totalReceipts=_pmtAll.filter(p=>p.payment_type==='Receipt').reduce((s,p)=>s+(p.amount||0),0);
  const totalPayments=_pmtAll.filter(p=>p.payment_type==='Payment').reduce((s,p)=>s+(p.amount||0),0);
  const net=totalReceipts-totalPayments;

  const mc=document.getElementById('module-content');
  mc.innerHTML=`
    <div class="pmt-kpi-row">
      <div class="pmt-kpi-card">
        <div class="pmt-kpi-lbl">Total Receipts</div>
        <div class="pmt-kpi-val col-green">${fmt(totalReceipts)}</div>
      </div>
      <div class="pmt-kpi-card">
        <div class="pmt-kpi-lbl">Total Payments</div>
        <div class="pmt-kpi-val col-red">${fmt(totalPayments)}</div>
      </div>
      <div class="pmt-kpi-card">
        <div class="pmt-kpi-lbl">Net</div>
        <div class="pmt-kpi-val ${net>=0?'col-green':'col-red'}">${fmt(net)}</div>
      </div>
    </div>
    <div class="inv-toolbar">
      <input class="inv-search" id="pmt-q" placeholder="Search contact, reference, description…" value="${esc(_pmtSearch)}">
      <div class="inv-filter-group">
        ${PMT_TYPES.map(t=>`<button class="filter-btn${_pmtFilter===t?' active':''}" onclick="pmtSetFilter('${t}')">
          ${t}${counts[t]?` <span class="filter-count">(${counts[t]})</span>`:''}</button>`).join('')}
      </div>
      <div class="pmt-toolbar-btns">
        <button class="btn btn-primary" onclick="pmtNew('Receipt')">+ Receipt</button>
        <button class="btn btn-outline" onclick="pmtNew('Payment')">+ Payment</button>
      </div>
    </div>
    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        ${pmtTh('payment_date','Date')}
        ${pmtTh('payment_type','Type')}
        ${pmtTh('contact_name','Contact')}
        ${pmtTh('bank_name','Bank Account')}
        ${pmtTh('amount','Amount','r')}
        ${pmtTh('reference','Reference')}
        ${pmtTh('description','Description')}
      </tr></thead><tbody>
        ${rows.length ? rows.map(pmtRow).join('') : `<tr class="tbl-empty-row"><td colspan="7">No payments match your filter</td></tr>`}
      </tbody></table>
    </div></div>
    <div class="mt-8"><span class="count-pill">${rows.length} of ${_pmtAll.length} payment${_pmtAll.length!==1?'s':''}</span></div>`;

  const q=document.getElementById('pmt-q');
  if(q) {
    q.addEventListener('input',e=>{_pmtSearch=e.target.value;renderPaymentsPage(true);});
    if(restoreFocus){q.focus();q.setSelectionRange(q.value.length,q.value.length);}
  }
}

function pmtTh(col,label,align) {
  const cls=_pmtSort.col===col?(_pmtSort.dir>0?'sort-asc':'sort-desc'):'';
  return `<th class="${cls}${align==='r'?' th-r':''}" onclick="pmtSortBy('${col}')">${label}</th>`;
}

function pmtRow(p) {
  const sel=_pmtSelected===p.id;
  const amtCls=p.payment_type==='Receipt'?'inv-amt-paid':'inv-amt-red';
  return `<tr class="inv-row${sel?' pmt-row-selected':''}" onclick="pmtOpen(${p.id})">
    <td><span class="inv-mono">${fmtDate(p.payment_date)}</span></td>
    <td><span class="badge ${PMT_TYPE_BADGE[p.payment_type]||'badge-draft'}">${esc(p.payment_type||'—')}</span></td>
    <td><span class="inv-contact">${esc(p.contact_name||'—')}</span></td>
    <td><span class="td-ref">${esc(p.bank_name||'—')}</span></td>
    <td><span class="inv-amt ${amtCls}">${fmt(p.amount)}</span></td>
    <td><span class="td-ref">${esc(p.reference||'—')}</span></td>
    <td><span class="td-sm col-ink2">${esc(p.description||'—')}</span></td>
  </tr>`;
}

function pmtSortBy(col){_pmtSort={col,dir:_pmtSort.col===col?_pmtSort.dir*-1:1};renderPaymentsPage();}
function pmtSetFilter(f){_pmtFilter=f;renderPaymentsPage();}

async function pmtOpen(id) {
  _pmtSelected=id;
  renderPaymentsPage();
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent='Payment';
  document.getElementById('det-body').innerHTML='<div class="state-loading">Loading…</div>';
  document.getElementById('det-foot').innerHTML='';
  try {
    const data=await apiFetch(`/api/payments/${id}`);
    renderPmtDetail(data);
  } catch(e) {
    document.getElementById('det-body').innerHTML=`<div class="state-error">${esc(e.message)}</div>`;
  }
}

function renderPmtDetail(data) {
  const p=data.payment, allocs=data.allocations||[];
  document.getElementById('det-title').textContent=`${p.payment_type} #${p.id}`;
  const isReceipt=p.payment_type==='Receipt';
  const amtCls=isReceipt?'col-green':'col-red';

  const allocHtml=allocs.length ? `
    <div class="pmt-alloc-section">
      <div class="det-section-title">Allocated To</div>
      <table class="det-lines">
        <thead><tr>
          <th>${isReceipt?'Invoice':'Bill'}</th>
          <th class="th-r">Amount</th>
        </tr></thead><tbody>
        ${allocs.map(a=>`<tr>
          <td class="col-ink2">${esc(a.invoice_number||a.bill_number||'—')}</td>
          <td class="td-r-mono">${fmt(a.amount)}</td>
        </tr>`).join('')}
        </tbody>
      </table>
    </div>` : `<div class="pmt-no-alloc det-empty">No invoice/bill allocations (direct payment)</div>`;

  document.getElementById('det-body').innerHTML=`
    <div class="con-badge-row">
      <span class="badge ${PMT_TYPE_BADGE[p.payment_type]||'badge-draft'}">${esc(p.payment_type)}</span>
      ${p.payment_method?`<span class="badge badge-draft">${esc(p.payment_method)}</span>`:''}
    </div>
    <div class="pmt-amt-card">
      <div class="pmt-amt-lbl">Amount</div>
      <div class="pmt-amt-val ${amtCls}">${fmt(p.amount)}</div>
    </div>
    <div class="det-meta">
      <div><div class="det-lbl">Date</div><div class="det-val mono">${fmtDate(p.payment_date)}</div></div>
      <div><div class="det-lbl">${isReceipt?'Customer':'Supplier'}</div><div class="det-val">${esc(p.contact_name||'—')}</div></div>
      <div><div class="det-lbl">Bank Account</div><div class="det-val">${esc(p.bank_name||'—')}</div></div>
      <div><div class="det-lbl">Reference</div><div class="det-val mono">${esc(p.reference||'—')}</div></div>
      ${p.description?`<div style="grid-column:span 2"><div class="det-lbl">Description</div><div class="det-val">${esc(p.description)}</div></div>`:''}
      ${p.job_id?`<div><div class="det-lbl">Job</div><div class="det-val mono">#${p.job_id}</div></div>`:''}
    </div>
    ${allocHtml}
    <div class="det-section-title" style="margin-top:16px;cursor:pointer" onclick="_pmtToggleAtt(this,${p.id})">📎 Attachments <span style="font-size:10px;color:var(--ink3)">(click to load)</span></div>
    <div id="pmt-att-pane-${p.id}" style="display:none"></div>`;

  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" onclick="pmtEdit(${p.id})">✏ Amend</button>
    <button class="btn btn-danger" onclick="pmtVoid(${p.id})">Void</button>
    <button class="btn btn-outline" onclick="detClose()">Close</button>`;
}

// ── New / Amend form ─────────────────────────────────────────────────────────

function pmtNew(defaultType) {
  _pmtEditId=null;
  _showPmtForm(null, defaultType||'Receipt');
}

async function pmtEdit(id) {
  _pmtEditId=id;
  try {
    const data=await apiFetch(`/api/payments/${id}`);
    _showPmtForm(data.payment, data.payment.payment_type, data.allocations||[]);
  } catch(e){ toast(e.message,'err'); }
}

// _pmtAllocRows: [{id, number, balance, allocAmount}]
let _pmtAllocRows=[];
let _pmtGlMode=false;

async function _showPmtForm(p, forceType, existingAllocs) {
  const isNew=!p;
  const pType=forceType||(p?.payment_type||'Receipt');
  const isReceipt=pType==='Receipt';
  const contactType=isReceipt?'Customer':'Supplier';

  // Load contacts + bank accounts
  const [contacts, accounts] = await Promise.all([
    apiFetch('/api/contacts'),
    apiFetch('/api/accounts'),
  ]);
  const filtered = (contacts||[]).filter(c=>
    c.contact_type===contactType||c.contact_type==='Both');
  const banks = (accounts||[]).filter(a=>a.is_bank);

  const conOpts=filtered.map(c=>`<option value="${c.id}"${p?.contact_id===c.id?' selected':''}>${esc(c.name)}</option>`).join('');
  const bankOpts=banks.map(a=>`<option value="${a.id}"${p?.bank_account_id===a.id?' selected':''}>${esc((a.code?a.code+' ':'')+a.name)}</option>`).join('');
  const methodOpts=PMT_METHODS.map(m=>`<option${(p?.payment_method||'EFT')===m?' selected':''}>${m}</option>`).join('');

  _pmtAllocRows=[];
  const initGlMode = !!(p?.expense_account_id);
  _pmtGlMode = initGlMode;

  const glAccs = (accounts||[]).filter(a=>!a.is_bank);
  const glOpts = glAccs.map(a=>`<option value="${a.id}"${p?.expense_account_id===a.id?' selected':''}>${esc((a.code?a.code+' ':'')+a.name)}</option>`).join('');

  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent=isNew?`New ${pType}`:`Amend ${pType} #${p.id}`;
  document.getElementById('det-body').innerHTML=`
    <div class="edt-body-pad">
    <div class="edt-grid">
      <div class="edt-field"><label class="edt-lbl">Type *</label>
        <select class="edt-sel" id="pf-type" onchange="pmtTypeChange(this.value)">
          <option${pType==='Receipt'?' selected':''}>Receipt</option>
          <option${pType==='Payment'?' selected':''}>Payment</option>
        </select></div>
      <div class="edt-field"><label class="edt-lbl">Date *</label>
        <input class="edt-inp" id="pf-date" type="date" value="${p?.payment_date||isoToday()}"></div>
      <div class="edt-field edt-span">
        <div class="lbl-line">
          <label class="edt-lbl" id="pf-contact-lbl">${contactType}</label>
          <a href="#" class="lnk-accent lnk-sm" onclick="event.preventDefault();_pmtNewContact('${contactType}')">+ New</a>
        </div>
        <select class="edt-sel" id="pf-contact" onchange="pmtContactChanged()"><option value="">— None —</option>${conOpts}</select></div>
      <div class="edt-field"><label class="edt-lbl">Amount ($) *</label>
        <input class="edt-inp" id="pf-amount" type="number" step="0.01" min="0" value="${p?.amount||''}"></div>
      <div class="edt-field"><label class="edt-lbl">Method</label>
        <select class="edt-sel" id="pf-method">${methodOpts}</select></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Bank Account *</label>
        <select class="edt-sel" id="pf-bank">${bankOpts||'<option value="">— No bank accounts —</option>'}</select></div>
      <div class="edt-field"><label class="edt-lbl">Reference</label>
        <input class="edt-inp" id="pf-ref" value="${esc(p?.reference||'')}"></div>
      <div class="edt-field"><label class="edt-lbl">Description</label>
        <input class="edt-inp" id="pf-desc" value="${esc(p?.description||'')}"></div>
    </div>
    <div class="edt-divider"></div>
    <div class="pmt-alloc-tabs">
      <div class="pmt-alloc-tab${!initGlMode?' active':''}" onclick="pmtAllocModeChange('items')">${isReceipt?'Invoices':'Bills'}</div>
      <div class="pmt-alloc-tab${initGlMode?' active':''}" onclick="pmtAllocModeChange('gl')">GL Account</div>
    </div>
    <div id="pf-items-section"${initGlMode?' style="display:none"':''}>
      <div class="pmt-alloc-hdr">
        <div class="det-section-title">Allocate to ${isReceipt?'Invoices':'Bills'} <span class="pmt-alloc-optional">(optional)</span></div>
        <button class="btn btn-sm btn-outline" onclick="pmtLoadOpenItems()">Load Open ${isReceipt?'Invoices':'Bills'}</button>
      </div>
      <div id="pf-alloc-rows"></div>
      <div id="pf-alloc-unalloc" class="pmt-unalloc-hint"></div>
    </div>
    <div id="pf-gl-section"${!initGlMode?' style="display:none"':''}>
      <div class="edt-grid" style="margin-top:8px">
        <div class="edt-field edt-span"><label class="edt-lbl">Account *</label>
          <select class="edt-sel" id="pf-gl-acc"><option value="">— Select account —</option>${glOpts}</select></div>
        <div class="edt-field"><label class="edt-lbl">Tax Code</label>
          <select class="edt-sel" id="pf-gl-tax">${['N-T','GST','FRE','INP'].map(c=>`<option${c==='N-T'?' selected':''}>${c}</option>`).join('')}</select></div>
      </div>
    </div>
    </div>`;

  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="pmt-save-btn" onclick="savePmt()">${isNew?'Save':'Amend'}</button>
    <button class="btn btn-outline" onclick="${_pmtEditId?`pmtOpen(${_pmtEditId})`:'detClose()'}">Cancel</button>`;

  // Pre-populate allocations if amending
  if(existingAllocs?.length) {
    const contactId=parseInt(document.getElementById('pf-contact')?.value||0);
    if(contactId) await pmtLoadOpenItems(existingAllocs);
  }
}

async function pmtTypeChange(newType) {
  // Reload the form with new type
  const p=_pmtEditId?null:null; // new only — amend keeps original type
  await _showPmtForm(null, newType);
}

async function _pmtNewContact(type) {
  const c = await quickNewContact(type || 'Both');
  if (!c) return;
  const sel = document.getElementById('pf-contact');
  if (sel) { sel.appendChild(new Option(c.name, c.id, true, true)); pmtContactChanged(); }
}

async function pmtContactChanged() {
  _pmtAllocRows=[];
  const el=document.getElementById('pf-alloc-rows');
  if(el) el.innerHTML='';
  const hint=document.getElementById('pf-alloc-unalloc');
  if(hint) hint.textContent='';
}

function pmtAllocModeChange(mode) {
  _pmtGlMode = mode==='gl';
  document.querySelectorAll('.pmt-alloc-tab').forEach((t,i)=>t.classList.toggle('active', i===(_pmtGlMode?1:0)));
  document.getElementById('pf-items-section').style.display = _pmtGlMode?'none':'';
  document.getElementById('pf-gl-section').style.display   = _pmtGlMode?'':'none';
}

async function pmtLoadOpenItems(prefillAllocs) {
  const contactId=parseInt(document.getElementById('pf-contact')?.value||0);
  const pType=document.getElementById('pf-type')?.value||'Receipt';
  if(!contactId){toast('Select a contact first','err');return;}

  try {
    const items=await apiFetch(`/api/payments/open-items?contact_id=${contactId}&type=${pType}`)||[];
    _pmtAllocRows=items.map(item=>{
      const existing=prefillAllocs?.find(a=>a.invoice_id===item.id||a.bill_id===item.id);
      return {...item, allocAmount: existing?.amount||0};
    });
    renderAllocRows();
  } catch(e){ toast(e.message,'err'); }
}

function renderAllocRows() {
  const el=document.getElementById('pf-alloc-rows');
  if(!el) return;
  if(!_pmtAllocRows.length){
    el.innerHTML=`<div class="det-empty">No open items for this contact.</div>`;
    return;
  }
  el.innerHTML=`<table class="det-lines">
    <thead><tr>
      <th>Number</th>
      <th>Due</th>
      <th class="th-r">Balance</th>
      <th class="th-r">Apply ($)</th>
    </tr></thead><tbody>
    ${_pmtAllocRows.map((item,i)=>`<tr>
      <td class="inv-mono">${esc(item.number)}</td>
      <td class="td-ref">${fmtDate(item.due_date)}</td>
      <td class="td-r-mono">${fmt(item.balance)}</td>
      <td><input type="number" step="0.01" min="0" max="${item.balance}"
        class="edt-inp pmt-alloc-inp"
        id="alloc-amt-${i}" value="${item.allocAmount||''}"
        oninput="pmtUpdateUnalloc()" placeholder="0.00"></td>
    </tr>`).join('')}
    </tbody></table>
    <button class="btn btn-sm btn-outline pmt-fill-btn" onclick="pmtFillAlloc()">Fill from Amount</button>`;
  pmtUpdateUnalloc();
}

function pmtFillAlloc() {
  // Distribute the payment amount across open items in order
  let remaining=parseFloat(document.getElementById('pf-amount')?.value||0);
  _pmtAllocRows.forEach((item,i)=>{
    const apply=Math.min(remaining, item.balance);
    const inp=document.getElementById(`alloc-amt-${i}`);
    if(inp) inp.value=apply>0?apply.toFixed(2):'';
    remaining=Math.max(0,remaining-apply);
  });
  pmtUpdateUnalloc();
}

function pmtUpdateUnalloc() {
  const total=parseFloat(document.getElementById('pf-amount')?.value||0);
  const allocated=_pmtAllocRows.reduce((s,_,i)=>{
    const v=parseFloat(document.getElementById(`alloc-amt-${i}`)?.value||0);
    return s+(isNaN(v)?0:v);
  },0);
  const unalloc=total-allocated;
  const el=document.getElementById('pf-alloc-unalloc');
  if(!el) return;
  if(Math.abs(unalloc)<0.005) { el.textContent=''; el.className='pmt-unalloc-hint'; return; }
  el.className=unalloc<0?'pmt-unalloc-hint pmt-unalloc-over':'pmt-unalloc-hint';
  el.textContent=unalloc>0
    ?`Unallocated: ${fmt(unalloc)} (will be posted as direct payment)`
    :`Over-allocated by ${fmt(Math.abs(unalloc))} — reduce allocation amounts`;
}

async function savePmt() {
  const pType=document.getElementById('pf-type')?.value;
  const contactId=parseInt(document.getElementById('pf-contact')?.value||0);
  const amount=parseFloat(document.getElementById('pf-amount')?.value||0);
  const bankId=parseInt(document.getElementById('pf-bank')?.value||0);
  const date=document.getElementById('pf-date')?.value;

  if(!pType||!amount||!bankId||!date){toast('Type, date, amount and bank account are required','err');return;}

  let allocations=[];
  let expense_account_id=null, tax_code=null;

  if(_pmtGlMode) {
    expense_account_id=parseInt(document.getElementById('pf-gl-acc')?.value||0)||null;
    if(!expense_account_id){toast('Select a GL account','err');return;}
    tax_code=document.getElementById('pf-gl-tax')?.value||'N-T';
  } else {
    const isReceipt=pType==='Receipt';
    allocations=_pmtAllocRows.map((item,i)=>{
      const v=parseFloat(document.getElementById(`alloc-amt-${i}`)?.value||0);
      if(!v||isNaN(v)) return null;
      return isReceipt?{invoice_id:item.id,amount:v}:{bill_id:item.id,amount:v};
    }).filter(Boolean);
  }

  const payload={
    payment_type:  pType,
    contact_id:    contactId||null,
    payment_date:  date,
    amount,
    bank_account_id: bankId,
    payment_method: document.getElementById('pf-method')?.value||'EFT',
    reference:     document.getElementById('pf-ref')?.value.trim()||'',
    description:   document.getElementById('pf-desc')?.value.trim()||'',
    allocations,
    expense_account_id,
    tax_code,
  };

  const btn=document.getElementById('pmt-save-btn');
  btn.disabled=true; btn.textContent='Saving…';

  try {
    let savedId=_pmtEditId;
    if(_pmtEditId) {
      const r=await fetch(`/api/payments/${_pmtEditId}`,{method:'PUT',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      const j=await r.json(); if(!j.ok) throw new Error(j.error||'Amend failed');
      savedId=j.data?.id||_pmtEditId;
    } else {
      const r=await fetch('/api/payments',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
      savedId=j.data?.id;
    }
    toast(_pmtEditId?'Payment amended':'Payment recorded');
    _pmtAll=await apiFetch('/api/payments')||[];
    if(savedId){ _pmtSelected=savedId; await pmtOpen(savedId); }
    else { detClose(); renderPaymentsPage(); }
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent=_pmtEditId?'Amend':'Save';
  }
}

async function pmtVoid(id) {
  if(!await confirmDlg('Void this payment? A reversing journal entry will be posted. This cannot be undone.')) return;
  try {
    const r=await fetch(`/api/payments/${id}/void`,{method:'POST',credentials:'include'});
    const j=await r.json(); if(!j.ok) throw new Error(j.error||'Void failed');
    toast('Payment voided');
    detClose();
    _pmtAll=await apiFetch('/api/payments')||[];
    renderPaymentsPage();
  } catch(e){ toast(e.message,'err'); }
}

function _pmtToggleAtt(hdr, pmtId) {
  const pane = document.getElementById(`pmt-att-pane-${pmtId}`);
  if (!pane) return;
  const open = pane.style.display !== 'none';
  if (open) {
    pane.style.display = 'none';
    return;
  }
  pane.style.display = 'block';
  const paneId = `pmt-att-pane-${pmtId}`;
  if (!_attLoadedFor || _attLoadedFor.type !== 'payment' || _attLoadedFor.id !== pmtId) {
    _attLoad(paneId, 'payment', pmtId);
  }
}
