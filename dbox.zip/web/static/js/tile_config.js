// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// ═══════════════════════════════════════════════════════════════════════════
// DASHBOARD TILE CONFIGURATION  (Phase 5)
// ═══════════════════════════════════════════════════════════════════════════

const _TC_ROLES = ['Accountant', 'Trades', 'Retail', 'ReadOnly'];

// Must mirror ROLE_MODULES in core/auth.py
const _TC_ROLE_MODULES = {
  Accountant: new Set(['dashboard','contacts','accounts','journal','payments',
    'bankrec','reports','invoices','bills','credit_cards','budget','recurring',
    'fixed_assets','petty_cash','expense_claims','items','warranties','purchase_orders']),
  Trades: new Set(['dashboard','contacts','invoices','bills','payments','bankrec',
    'jobs','quotes','schedule','purchase_orders','warranties','items','expense_claims']),
  Retail: new Set(['dashboard','contacts','invoices','bills','payments',
    'pos','table_service','inventory','items','expense_claims']),
  ReadOnly: new Set(['dashboard','contacts','reports','invoices','bills']),
};

let _tcRole      = 'Accountant';
let _tcOverrides = {};   // {role: {tile_key: bool}} — all roles, loaded from server

async function pageTileConfig() {
  document.getElementById('module-content').innerHTML =
    '<div class="state-loading">Loading…</div>';
  try {
    _tcOverrides = await apiFetch('/api/admin/tile-overrides');
  } catch(e) {
    _tcOverrides = {};
  }
  _tcRender();
}

function _tcRender() {
  document.getElementById('module-content').innerHTML = `
    <div class="inv-toolbar">
      <div style="font-weight:600;font-size:14px;color:var(--ink)">Dashboard Configuration</div>
      <button class="btn btn-primary" id="tc-save-btn" onclick="_tcSave()">Save Changes</button>
    </div>
    <p style="padding:0 26px;margin:6px 0 0;font-size:12px;color:var(--ink3)">
      Control which tiles appear in each hub for each role. Tiles blocked by licence pack or role
      permissions are marked — they will not show regardless of this setting.
    </p>
    <div class="tc-role-tabs" id="tc-role-tabs">
      ${_TC_ROLES.map(r =>
        `<div class="tc-role-tab${r===_tcRole?' active':''}" onclick="_tcSetRole('${r}')">${esc(r)}</div>`
      ).join('')}
    </div>
    <div class="tc-body" id="tc-body"></div>`;
  _tcRenderBody();
}

function _tcSetRole(role) {
  _tcRole = role;
  document.querySelectorAll('.tc-role-tab').forEach(el =>
    el.classList.toggle('active', el.textContent.trim() === role));
  _tcRenderBody();
}

function _tcRenderBody() {
  const roleMods   = _TC_ROLE_MODULES[_tcRole] || null;
  const roleOverrides = _tcOverrides[_tcRole] || {};

  let html = '';
  for (const [hubKey, cfg] of Object.entries(_HUB_CONFIG)) {
    if (hubKey === 'hub_admin') continue;
    const hubTitle = PAGE_TITLES[hubKey] || hubKey;

    const rows = cfg.tiles.map(t => {
      if (!t.key) return '';

      const roleBlocked    = !!(t.role && roleMods && !roleMods.has(t.role));
      const payrollBlocked = !!(t.payroll);
      const capRequired    = t.cap || null;

      // enabled = server says true (or key not in map), unless explicitly false
      const enabled = roleBlocked ? false
        : (roleOverrides[t.key] === false ? false : true);

      let notes = '';
      if (roleBlocked)    notes += `<span class="tc-note tc-note-blocked">not in this role</span>`;
      else if (payrollBlocked) notes += `<span class="tc-note">requires Payroll add-on</span>`;
      else if (capRequired)    notes += `<span class="tc-note">requires ${capRequired} pack</span>`;

      return `<div class="tc-tile-row${roleBlocked?' tc-blocked':''}">
        <span class="tc-tile-icon">${t.icon}</span>
        <div class="tc-tile-info">
          <div class="tc-tile-label">${esc(t.label)}</div>
          ${notes ? `<div class="tc-tile-notes">${notes}</div>` : ''}
        </div>
        <label class="tc-toggle${roleBlocked?' tc-toggle-disabled':''}">
          <input type="checkbox" ${enabled?'checked':''} ${roleBlocked?'disabled':''}
            data-key="${t.key}" onchange="_tcToggle('${t.key}',this.checked)">
          <span class="tc-toggle-track"></span>
        </label>
      </div>`;
    }).join('');

    html += `<div class="tc-hub-section">
      <div class="tc-hub-hdr">${esc(hubTitle)}</div>
      <div class="tc-hub-tiles">${rows}</div>
    </div>`;
  }
  document.getElementById('tc-body').innerHTML = html;
}

function _tcToggle(tileKey, enabled) {
  if (!_tcOverrides[_tcRole]) _tcOverrides[_tcRole] = {};
  _tcOverrides[_tcRole][tileKey] = enabled;
}

async function _tcSave() {
  const btn = document.getElementById('tc-save-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
  try {
    const r = await fetch('/api/admin/tile-overrides', {
      method: 'POST', credentials: 'include',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ role: _tcRole, changes: _tcOverrides[_tcRole] || {} }),
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Save failed');
    toast('Tile configuration saved');
  } catch(e) {
    toast('Failed to save: ' + e.message, 'err');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Save Changes'; }
  }
}
