// ═══════════════════════════════════════════════════════════════════════════
// ACCOUNTS PAGE  (Chart of Accounts + Credit Cards)
// ═══════════════════════════════════════════════════════════════════════════
let _acctAll=[], _acctBalances={}, _acctSearch='', _acctSelected=null, _acctTypeFilter='All';
let _acctTab='coa';   // 'coa' | 'cc'
const ACCT_TYPES=['All','Asset','Liability','Equity','Income','Expense'];
const ACCT_TYPE_COLOR={Asset:'badge-pending',Liability:'badge-overdue',Equity:'badge-partial',Income:'badge-paid',Expense:'badge-draft'};
const _TYPE_CLASS={Asset:'1',Liability:'2',Equity:'3',Income:'4',Expense:'5'};
const _CODE_RE=/^[1-5]-\d{4}$/;

// Credit-card state
let _acctCcCards=[], _acctCcCardMap={}, _acctCcCardId=null, _acctCcTxns=[], _acctCcFrom='', _acctCcTo='';

async function pageAccounts() {
  try {
    _acctAll = await apiFetch('/api/accounts') || [];
    const ids = _acctAll.map(a=>a.id);
    if (ids.length) {
      try {
        const bals = await fetch('/api/accounts/balances',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(ids)});
        const j = await bals.json();
        if (j.ok) _acctBalances = j.data;
      } catch(e) { _acctBalances={}; }
    }
    renderAccountsPage();
  } catch(e) {
    document.getElementById('module-content').innerHTML=`<div class="state-error">Failed to load accounts: ${esc(e.message)}</div>`;
  }
}

// ── Filtering ──────────────────────────────────────────────────────────────

function _acctFiltered() {
  const q=_acctSearch.toLowerCase();
  return _acctAll.filter(a=>{
    if (_acctTypeFilter!=='All' && a.account_type!==_acctTypeFilter) return false;
    if (q && ![a.code,a.name,a.account_type,a.account_subtype].some(v=>(v||'').toLowerCase().includes(q))) return false;
    return true;
  });
}

// ── Page render ────────────────────────────────────────────────────────────

function renderAccountsPage() {
  const mc=document.getElementById('module-content');
  mc.innerHTML=`
    <div class="acct-tab-bar">
      <button class="acct-tab-btn${_acctTab==='coa'?' active':''}" onclick="acctSwitchTab('coa')">📒 Chart of Accounts</button>
      <button class="acct-tab-btn${_acctTab==='cc'?' active':''}"  onclick="acctSwitchTab('cc')">💳 Credit Cards</button>
    </div>
    <div id="acct-coa-pane" class="${_acctTab==='coa'?'':'acct-pane-hidden'}"></div>
    <div id="acct-cc-pane"  class="${_acctTab==='cc' ?'':'acct-pane-hidden'}"></div>`;

  if (_acctTab==='coa') _renderCoaPane();
  else { _renderCcPane(); _loadCcCards(); }
}

function acctSwitchTab(tab) {
  _acctTab=tab;
  renderAccountsPage();
}

// ── Chart of Accounts pane ─────────────────────────────────────────────────

function _renderCoaPane(restoreFocus) {
  const all=_acctFiltered();
  const counts={All:_acctAll.length};
  ACCT_TYPES.slice(1).forEach(t=>{ counts[t]=_acctAll.filter(a=>a.account_type===t).length; });

  const order=['Asset','Liability','Equity','Income','Expense'];
  const groups={};
  order.forEach(t=>{ groups[t]=[]; });
  all.forEach(a=>{ if(groups[a.account_type]) groups[a.account_type].push(a); });

  document.getElementById('acct-coa-pane').innerHTML=`
    <div class="inv-toolbar">
      <input class="inv-search" id="acct-q" placeholder="Search code, name\u2026" value="${esc(_acctSearch)}">
      <div class="inv-filter-group">
        ${ACCT_TYPES.map(t=>`<button class="filter-btn${_acctTypeFilter===t?' active':''}" onclick="acctSetFilter('${t}')">
          ${t}${counts[t]?`<span class="filter-count">(${counts[t]})</span>`:''}</button>`).join('')}
      </div>
      <button class="btn btn-primary" onclick="acctNew()">+ New Account</button>
    </div>
    ${order.filter(t=>groups[t]&&groups[t].length).map(type=>`
    <div class="acct-type-group">
      <div class="acct-type-hdr">
        <span class="badge ${ACCT_TYPE_COLOR[type]||'badge-draft'}">${type}</span>
        <span class="acct-type-count">${groups[type].length} account${groups[type].length!==1?'s':''}</span>
        <span class="acct-type-total">Total: <span class="inv-mono">${fmt(_acctGroupTotal(type,groups[type]))}</span></span>
      </div>
      <div class="inv-list-panel acct-list-panel-flush"><div class="tbl-overflow-x">
        <table class="inv-list-table"><thead><tr>
          <th class="acct-th-code">Code</th>
          <th>Name</th>
          <th>Subtype</th>
          <th class="acct-th-bank">Bank</th>
          <th class="th-r acct-th-bal">Balance</th>
          <th class="acct-th-active">Active</th>
        </tr></thead><tbody>
          ${groups[type].map(a=>acctRow(a)).join('')}
        </tbody></table>
      </div></div>
    </div>`).join('')}
    <div class="mt-8"><span class="count-pill">${all.length} of ${_acctAll.length} account${_acctAll.length!==1?'s':''}</span></div>`;

  const q=document.getElementById('acct-q');
  if(q){
    q.addEventListener('input',e=>{ _acctSearch=e.target.value; _renderCoaPane(true); });
    if(restoreFocus){q.focus();q.setSelectionRange(q.value.length,q.value.length);}
  }
}

function _acctGroupTotal(type, accts) {
  return accts.reduce((s,a)=>s+(_acctBalances[String(a.id)]||0),0);
}

function acctRow(a) {
  const bal=_acctBalances[String(a.id)];
  const balFmt=bal!=null?fmt(bal):'—';
  // Balance colour is JS-driven (runtime sign check) — inline style is correct here
  const balColor=bal==null?'':(bal<-0.005?'color:var(--red)':bal>0.005?'color:var(--green)':'color:var(--ink3)');
  const sel=_acctSelected===a.id;
  return `<tr class="inv-row${sel?' acct-row-selected':''}" onclick="acctOpen(${a.id})">
    <td><span class="inv-mono">${esc(a.code||'')}</span></td>
    <td><span class="inv-contact">${esc(a.name)}</span>${a.is_bank?'<span class="acct-bank-icon">🏦</span>':''}</td>
    <td><span class="acct-subtype-cell">${esc(a.account_subtype||'—')}</span></td>
    <td class="td-c-mono">${a.is_bank?'<span class="col-green">\u2713</span>':'—'}</td>
    <td class="td-r-mono" style="${balColor}">${balFmt}</td>
    <td class="td-c-mono">${a.is_active!==0?'<span class="col-green">\u2713</span>':'<span class="col-red">\u2715</span>'}</td>
  </tr>`;
}

function acctSetFilter(t){ _acctTypeFilter=t; _renderCoaPane(); }

// ── CoA detail ─────────────────────────────────────────────────────────────

async function acctOpen(id) {
  _acctSelected=id;
  document.querySelectorAll('.acct-row-selected').forEach(r=>r.classList.remove('acct-row-selected'));
  const row=document.querySelector(`[onclick="acctOpen(${id})"]`);
  if (row) row.classList.add('acct-row-selected');

  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent='Account';
  document.getElementById('det-body').innerHTML='<div class="state-loading">Loading\u2026</div>';
  document.getElementById('det-foot').innerHTML='';
  try {
    const a=await apiFetch(`/api/accounts/${id}`);
    renderAcctDetail(a);
  } catch(e) {
    document.getElementById('det-body').innerHTML=`<div class="state-error">${esc(e.message)}</div>`;
  }
}

function renderAcctDetail(a) {
  document.getElementById('det-title').textContent=`${a.code} \u2014 ${a.name}`;
  const bal=a.balance??_acctBalances[String(a.id)];
  const balColor=bal==null?'':(bal<-0.005?'color:var(--red)':bal>0.005?'color:var(--green)':'color:var(--ink3)');
  document.getElementById('det-body').innerHTML=`
    <div class="acct-det-badges">
      <span class="badge ${ACCT_TYPE_COLOR[a.account_type]||'badge-draft'}">${esc(a.account_type||'—')}</span>
      ${a.account_subtype?`<span class="badge badge-draft badge-sm-inline">${esc(a.account_subtype)}</span>`:''}
      ${a.is_active===0?'<span class="badge badge-overdue badge-sm-inline">Inactive</span>':''}
    </div>
    ${bal!=null?`
    <div class="acct-det-bal-card">
      <div class="acct-det-bal-lbl">Current Balance</div>
      <div class="acct-det-bal-val" style="${balColor}">${fmt(bal)}</div>
    </div>`:''}
    <div class="det-meta">
      <div><div class="det-lbl">Account Code</div><div class="det-val mono">${esc(a.code||'—')}</div></div>
      <div><div class="det-lbl">Tax Code</div><div class="det-val mono">${esc(a.tax_code||'—')}</div></div>
      <div><div class="det-lbl">Opening Balance</div><div class="det-val mono">${a.opening_balance!=null?fmt(a.opening_balance):'—'}</div></div>
      <div><div class="det-lbl">Is Bank Account</div><div class="det-val">${a.is_bank?'<span class="col-green">Yes</span>':'No'}</div></div>
      ${a.is_bank&&(a.bsb||a.account_number)?`
      <div><div class="det-lbl">BSB</div><div class="det-val mono">${esc(a.bsb||'—')}</div></div>
      <div><div class="det-lbl">Account No.</div><div class="det-val mono">${esc(a.account_number||'—')}</div></div>`:''}
    </div>`;
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" onclick="acctEdit(${a.id})">\u270f Edit</button>
    <button class="btn btn-outline" onclick="detClose()">Close</button>`;
}

// ── CoA new / edit form ────────────────────────────────────────────────────

function acctNew() {
  _acctEditId=null;
  _showAcctForm(null);
}

function acctEdit(id) {
  _acctEditId=id;
  apiFetch(`/api/accounts/${id}`).then(a=>_showAcctForm(a)).catch(e=>toast(e.message,'err'));
}

let _acctEditId=null;
function _showAcctForm(a) {
  const v=(f,fb='')=>esc(a?String(a[f]??fb):fb);
  const sel=(f,opts,fb='')=>opts.map(o=>`<option${(a?a[f]:fb)===o?' selected':''}>${o}</option>`).join('');
  document.getElementById('det-overlay').classList.add('open');
  document.getElementById('det-panel').classList.add('open');
  document.getElementById('det-title').textContent=a?`Edit \u2014 ${a.code} ${a.name}`:'New Account';
  document.getElementById('det-body').innerHTML=`
    <div class="edt-body-pad">
    <div class="edt-grid">
      <div class="edt-field"><label class="edt-lbl">Code *</label><input class="edt-inp" id="af-code" value="${v('code')}" placeholder="${_TYPE_CLASS[a?.account_type||'Asset']}-0000" maxlength="6"></div>
      <div class="edt-field"><label class="edt-lbl">Tax Code</label>
        <select class="edt-sel" id="af-tax">${sel('tax_code',['GST','FRE','INP','N-T','CAP'],'GST')}</select></div>
      <div class="edt-field edt-span"><label class="edt-lbl">Name *</label><input class="edt-inp" id="af-name" value="${v('name')}"></div>
      <div class="edt-field"><label class="edt-lbl">Type *</label>
        <select class="edt-sel" id="af-type" onchange="acctTypeChange()">${sel('account_type',['Asset','Liability','Equity','Income','Expense'],'Asset')}</select></div>
      <div class="edt-field"><label class="edt-lbl">Subtype</label>
        <select class="edt-sel" id="af-subtype">${_acctSubtypeOpts(a?.account_type||'Asset',a?.account_subtype)}</select></div>
      <div class="edt-field"><label class="edt-lbl">Opening Balance ($)</label><input class="edt-inp" id="af-ob" type="number" step="0.01" value="${v('opening_balance','0')}"></div>
      <div class="edt-field acct-ck-field">
        <input type="checkbox" id="af-isbank" ${a?.is_bank?'checked':''} onchange="acctBankToggle()">
        <label for="af-isbank" class="acct-ck-lbl">Is Bank Account</label>
      </div>
    </div>
    <div id="af-bank-fields" style="${a?.is_bank?'':'display:none'}">
      <div class="acct-bank-sep"><span class="acct-bank-sep-lbl">Bank Details</span></div>
      <div class="edt-grid">
        <div class="edt-field"><label class="edt-lbl">BSB</label><input class="edt-inp" id="af-bsb" value="${v('bsb')}"></div>
        <div class="edt-field"><label class="edt-lbl">Account Number</label><input class="edt-inp" id="af-accnum" value="${v('account_number')}"></div>
      </div>
    </div>
    </div>`;
  document.getElementById('det-foot').innerHTML=`
    <button class="btn btn-primary" id="acct-save-btn" onclick="saveAccount()">Save</button>
    <button class="btn btn-outline" onclick="${_acctEditId?`acctOpen(${_acctEditId})`:'detClose()'}">Cancel</button>`;
  setTimeout(()=>{ document.getElementById('af-code')?.focus(); },50);
}

function _acctSubtypeOpts(type, current) {
  const map={
    Asset:['Bank','Current Asset','Fixed Asset',''],
    Liability:['Current Liability','Non-Current Liability',''],
    Equity:['Equity',''],
    Income:['Income',''],
    Expense:['Direct Cost','Overhead','Header',''],
  };
  return (map[type]||['']).map(o=>`<option${current===o?' selected':''}>${o}</option>`).join('');
}

function acctTypeChange() {
  const typeEl=document.getElementById('af-type');
  const sub=document.getElementById('af-subtype');
  if(sub) sub.innerHTML=_acctSubtypeOpts(typeEl?.value);
  const codeEl=document.getElementById('af-code');
  if(!typeEl||!codeEl) return;
  const cls=_TYPE_CLASS[typeEl.value]||'';
  codeEl.placeholder=`${cls}-0000`;
  const cur=codeEl.value.trim();
  if(cur && /^[1-5]-/.test(cur)) codeEl.value=cls+'-'+cur.slice(2);
}

function acctBankToggle() {
  const bf=document.getElementById('af-bank-fields');
  if(bf) bf.style.display=document.getElementById('af-isbank')?.checked?'':'none';
}

async function saveAccount() {
  const code=(document.getElementById('af-code')?.value||'').trim();
  const name=(document.getElementById('af-name')?.value||'').trim();
  if(!code||!name){ toast('Code and Name are required','err'); return; }
  if(!_CODE_RE.test(code)){ toast('Code must be in format C-HXXX — e.g. 1-1100','err'); return; }
  const _atype=document.getElementById('af-type')?.value;
  if(_TYPE_CLASS[_atype]&&code[0]!==_TYPE_CLASS[_atype]){
    toast(`${_atype} accounts must start with ${_TYPE_CLASS[_atype]}- (e.g. ${_TYPE_CLASS[_atype]}-1100)`,'err'); return;
  }
  const btn=document.getElementById('acct-save-btn');
  btn.disabled=true; btn.textContent='Saving\u2026';
  const payload={
    code, name,
    account_type:    document.getElementById('af-type').value,
    account_subtype: document.getElementById('af-subtype').value||null,
    tax_code:        document.getElementById('af-tax').value,
    opening_balance: parseFloat(document.getElementById('af-ob').value||0),
    is_bank:         document.getElementById('af-isbank').checked?1:0,
    bsb:             document.getElementById('af-bsb')?.value.trim()||'',
    account_number:  document.getElementById('af-accnum')?.value.trim()||'',
    is_active: 1,
  };
  try {
    const savedId=_acctEditId;
    if (_acctEditId) {
      const r=await fetch(`/api/accounts/${_acctEditId}`,{method:'PUT',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
    } else {
      const r=await fetch('/api/accounts',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(payload)});
      const j=await r.json(); if(!j.ok) throw new Error(j.error||'Save failed');
    }
    // Invalidate caches used by invoice/bill/journal editors if they exist
    if (typeof _bankAccts     !== 'undefined') _bankAccts=[];
    if (typeof _editAccts     !== 'undefined') _editAccts=[];
    if (typeof _billEditAccts !== 'undefined') _billEditAccts=[];
    toast('Account saved');
    _acctAll=await apiFetch('/api/accounts')||[];
    const ids=_acctAll.map(a=>a.id);
    if(ids.length){
      const bals=await fetch('/api/accounts/balances',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'include',body:JSON.stringify(ids)});
      const bj=await bals.json(); if(bj.ok) _acctBalances=bj.data;
    }
    if(savedId){ _acctSelected=savedId; await acctOpen(savedId); }
    else { detClose(); _acctTab='coa'; renderAccountsPage(); }
  } catch(e){
    toast(e.message,'err');
    btn.disabled=false; btn.textContent='Save';
  }
}

// ══════════════════════════════════════════════════════════════════════════
// CREDIT CARDS PANE
// ══════════════════════════════════════════════════════════════════════════

function _renderCcPane() {
  const cardOpts=_acctCcCards.map(c=>`<option value="${c.id}"${c.id===_acctCcCardId?' selected':''}>${esc(c.code)}  ${esc(c.name)}</option>`).join('');
  document.getElementById('acct-cc-pane').innerHTML=`
    <div class="inv-toolbar">
      <button class="btn btn-primary" onclick="ccNewCard()">+ New Card</button>
      <button class="btn btn-outline" onclick="ccCharge()">💳 Record Charge</button>
      <button class="btn btn-outline" onclick="ccPayment()">💸 Record Payment</button>
    </div>
    <div class="acct-cc-picker-row">
      <span class="acct-cc-picker-lbl">Card:</span>
      <select class="edt-sel acct-cc-sel" id="cc-card-sel" onchange="ccCardChanged(this.value)">
        ${_acctCcCards.length?cardOpts:'<option value="">No credit card accounts found</option>'}
      </select>
      <span class="acct-cc-bal" id="cc-bal-lbl"></span>
    </div>
    <div class="acct-cc-filter-row">
      <span class="acct-cc-filter-lbl">From:</span>
      <input type="date" class="edt-inp acct-cc-date-inp" id="cc-from" value="${_acctCcFrom}">
      <span class="acct-cc-filter-lbl">To:</span>
      <input type="date" class="edt-inp acct-cc-date-inp" id="cc-to" value="${_acctCcTo}">
      <button class="btn btn-outline btn-sm" onclick="ccFilter()">\uD83D\uDD0D Filter</button>
      <button class="btn btn-outline btn-sm" onclick="ccClearFilter()">Clear</button>
    </div>
    <div class="inv-list-panel"><div class="tbl-overflow-x">
      <table class="inv-list-table"><thead><tr>
        <th>Date</th>
        <th class="th-r acct-th-jnl">Jnl#</th>
        <th>Type</th>
        <th>Reference</th>
        <th>Description</th>
        <th class="th-r">Charge</th>
        <th class="th-r">Payment</th>
        <th class="th-r">Balance</th>
      </tr></thead><tbody id="cc-txn-tbody">
        <tr><td colspan="8" class="det-empty acct-cc-empty">Select a card to view transactions.</td></tr>
      </tbody></table>
    </div></div>
    <div class="mt-8"><span class="count-pill" id="cc-count"></span></div>`;
  if (_acctCcCardId) _renderCcTxns();
}

async function _loadCcCards() {
  try {
    const all=_acctAll.length?_acctAll:await apiFetch('/api/accounts')||[];
    _acctCcCards=all.filter(a=>a.account_type==='Liability'&&a.is_bank);
    _acctCcCardMap={};
    _acctCcCards.forEach(c=>{ _acctCcCardMap[c.id]=c; });
    if (!_acctCcCardId && _acctCcCards.length) _acctCcCardId=_acctCcCards[0].id;
    _renderCcPane();
    if (_acctCcCardId) _renderCcTxns();
  } catch(e){ toast('Failed to load cards: '+e.message,'err'); }
}

function ccCardChanged(id) {
  _acctCcCardId=id?parseInt(id):null;
  _acctCcFrom=''; _acctCcTo='';
  _renderCcTxns();
}

function ccFilter() {
  _acctCcFrom=document.getElementById('cc-from')?.value||'';
  _acctCcTo  =document.getElementById('cc-to')?.value||'';
  _renderCcTxns();
}

function ccClearFilter() {
  _acctCcFrom=''; _acctCcTo='';
  const f=document.getElementById('cc-from'); if(f) f.value='';
  const t=document.getElementById('cc-to');   if(t) t.value='';
  _renderCcTxns();
}

async function _renderCcTxns() {
  if (!_acctCcCardId) return;
  const tbody=document.getElementById('cc-txn-tbody');
  if (tbody) tbody.innerHTML='<tr><td colspan="8" class="state-loading">Loading\u2026</td></tr>';
  try {
    let url=`/api/accounts/${_acctCcCardId}/cc-transactions`;
    const params=[];
    if (_acctCcFrom) params.push(`from=${_acctCcFrom}`);
    if (_acctCcTo)   params.push(`to=${_acctCcTo}`);
    if (params.length) url+='?'+params.join('&');
    _acctCcTxns=await apiFetch(url)||[];
    _renderCcTxnsTable();
    const balData=await apiFetch(`/api/accounts/${_acctCcCardId}/cc-balance`).catch(()=>null);
    _updateCcBal(balData?.balance??null);
  } catch(e){
    const tb=document.getElementById('cc-txn-tbody');
    if(tb) tb.innerHTML=`<tr><td colspan="8" class="state-error">${esc(e.message)}</td></tr>`;
  }
}

function _renderCcTxnsTable() {
  const tbody=document.getElementById('cc-txn-tbody');
  if (!tbody) return;
  if (!_acctCcTxns.length){
    tbody.innerHTML='<tr><td colspan="8" class="det-empty acct-cc-empty">No transactions in this range.</td></tr>';
    const c=document.getElementById('cc-count'); if(c) c.textContent='';
    return;
  }
  let running=0;
  tbody.innerHTML=_acctCcTxns.map((tx,i)=>{
    const charge =tx.charge ||0;
    const payment=tx.payment||0;
    running+=charge-payment;
    const desc=tx.line_desc||tx.journal_desc||'';
    return `<tr class="inv-row${i%2?' inv-row-alt':''}">
      <td><span class="inv-mono">${esc(tx.entry_date||'')}</span></td>
      <td class="td-r-mono">${tx.journal_id||''}</td>
      <td><span class="acct-subtype-cell">${esc(tx.entry_type||'')}</span></td>
      <td><span class="inv-mono">${esc(tx.reference||'')}</span></td>
      <td>${esc(desc)}</td>
      <td class="td-r-mono${charge?'':' col-ink3'}">${charge?fmt(charge):'—'}</td>
      <td class="td-r-mono${payment?'':' col-ink3'}">${payment?fmt(payment):'—'}</td>
      <td class="td-r-mono-bold ${running>0?'col-red':running<-0.005?'col-green':''}">${fmt(running)}</td>
    </tr>`;
  }).join('');
  const c=document.getElementById('cc-count');
  if(c) c.textContent=`${_acctCcTxns.length} transaction${_acctCcTxns.length!==1?'s':''}`;
}

function _updateCcBal(bal) {
  const lbl=document.getElementById('cc-bal-lbl');
  if (!lbl) return;
  if (bal==null){ lbl.textContent=''; return; }
  lbl.textContent=`Balance: ${fmt(bal)}`;
  lbl.className='acct-cc-bal '+(bal>0?'acct-cc-bal-owed':'acct-cc-bal-clear');
}

// Stubs — full charge/payment dialogs require server routes matching desktop journal_cc_ui.py
function ccNewCard()  { toast('Create a Liability account with \u201cIs Bank Account\u201d checked to add a credit card',''); }
function ccCharge()   { if(!_acctCcCardId){toast('Select a card first','err');return;} toast('Use a Journal entry to record a charge against this card'); }
function ccPayment()  { if(!_acctCcCardId){toast('Select a card first','err');return;} toast('Use a Journal entry to record a payment to this card'); }
