// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
'use strict';

// ── Module state ─────────────────────────────────────────────────────────────
let _tsZones       = [];
let _tsTables      = [];
let _tsItems       = [];
let _tsSession     = null;
let _tsSettings    = {};
let _tsContacts    = [];
let _tsCurrentTabId  = null;
let _tsCurrentTab    = null;
let _tsZoneFilter    = 'all';
let _tsItemSearch    = '';
let _tsCatFilter     = null;
let _tsRefreshTimer  = null;
let _tsTenderModal   = null;

// ── Entry point ───────────────────────────────────────────────────────────────

async function pageTableService() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading…</div>';
  if (_tsRefreshTimer) { clearInterval(_tsRefreshTimer); _tsRefreshTimer = null; }
  try {
    const [tables, zones, items, sessionResp, settings, contacts] = await Promise.all([
      apiFetch('/api/ts/tables'),
      apiFetch('/api/ts/zones'),
      apiFetch('/api/pos/items'),
      apiFetch('/api/pos/session').catch(() => ({})),
      apiFetch('/api/pos/settings').catch(() => ({})),
      apiFetch('/api/contacts').catch(() => []),
    ]);
    _tsTables   = tables   || [];
    _tsZones    = zones    || [];
    _tsItems    = items    || [];
    _tsSession  = sessionResp.session || null;
    _tsSettings = settings || {};
    _tsContacts = contacts || [];
    _tsCurrentTabId = null;
    _tsCurrentTab   = null;
    _tsZoneFilter   = 'all';
    _tsRenderFloor();
    _tsRefreshTimer = setInterval(_tsAutoRefreshFloor, 30000);
  } catch (e) {
    mod.innerHTML = `<div class="state-error">${esc(e.message || 'Failed to load Table Service')}</div>`;
  }
}

// ── Floor plan ────────────────────────────────────────────────────────────────

function _tsRenderFloor() {
  const mod = document.getElementById('module-content');
  const sessionLabel = _tsSession
    ? `<span class="badge-green" style="font-size:11px;padding:2px 8px">Session open</span>`
    : `<span class="badge-amber" style="font-size:11px;padding:2px 8px">No session</span>`;

  const filtered = _tsZoneFilter === 'all'
    ? _tsTables
    : _tsTables.filter(t => String(t.zone_id) === _tsZoneFilter);

  mod.innerHTML = `
    <div style="display:flex;flex-direction:column;height:calc(100vh - 110px);overflow:hidden">
      <div class="inv-toolbar" style="flex-shrink:0">
        <span style="font-weight:700;font-size:14px;color:var(--ink);flex:1">Floor Plan</span>
        ${sessionLabel}
        <button class="btn" onclick="_tsOpenAdmin()">Manage Tables</button>
      </div>
      <div class="ts-zone-bar">
        <button class="ts-zone-pill${_tsZoneFilter==='all'?' active':''}" onclick="_tsSetZone('all')">All</button>
        ${_tsZones.map(z =>
          `<button class="ts-zone-pill${_tsZoneFilter===String(z.id)?' active':''}"
            onclick="_tsSetZone('${z.id}')">${esc(z.name)}</button>`
        ).join('')}
      </div>
      <div class="ts-floor-grid" id="ts-floor-grid">
        ${filtered.length
          ? filtered.map(_tsMakeTableCard).join('')
          : '<div style="grid-column:1/-1;color:var(--ink3);padding:24px">No tables configured — click Manage Tables to add some.</div>'
        }
      </div>
    </div>`;
}

function _tsMakeTableCard(t) {
  const status = t.open_tab_status;  // 'Open', 'Sent', or null
  const cls = status === 'Sent' ? 'ts-table-sent'
            : status === 'Open' ? 'ts-table-occupied'
            : 'ts-table-free';
  let timeStr = '';
  if (status && t.tab_opened_at) {
    timeStr = `<div class="ts-table-total">${_tsElapsed(t.tab_opened_at)}</div>`;
  }
  const badge = status === 'Sent'
    ? `<div style="font-size:10px;font-weight:700;color:var(--accent);margin-top:2px">AT REGISTER</div>`
    : '';
  return `
    <div class="ts-table-card ${cls}" onclick="_tsOpenTable(${t.id},${t.open_tab_id || 'null'})">
      <div class="ts-status-dot"></div>
      <div class="ts-table-name">${esc(t.name)}</div>
      ${t.zone_name ? `<div class="ts-table-zone">${esc(t.zone_name)}</div>` : ''}
      <div class="ts-table-seats">${t.seats} seats</div>
      ${timeStr}${badge}
    </div>`;
}

function _tsSetZone(zoneId) {
  _tsZoneFilter = String(zoneId);
  _tsRenderFloor();
}

function _tsElapsed(opened_at) {
  const then = new Date(opened_at.replace(' ', 'T'));
  const mins = Math.round((Date.now() - then.getTime()) / 60000);
  if (mins < 60) return `${mins}m`;
  return `${Math.floor(mins/60)}h ${mins%60}m`;
}

async function _tsAutoRefreshFloor() {
  try {
    _tsTables = await apiFetch('/api/ts/tables');
    const grid = document.getElementById('ts-floor-grid');
    if (!grid) return;
    const filtered = _tsZoneFilter === 'all'
      ? _tsTables
      : _tsTables.filter(t => String(t.zone_id) === _tsZoneFilter);
    grid.innerHTML = filtered.length
      ? filtered.map(_tsMakeTableCard).join('')
      : '<div style="grid-column:1/-1;color:var(--ink3);padding:24px">No tables configured.</div>';
  } catch (_) {}
}

// ── Open / create tab ─────────────────────────────────────────────────────────

async function _tsOpenTable(tableId, openTabId) {
  if (openTabId) {
    await _tsRenderTab(openTabId);
    return;
  }
  const table = _tsTables.find(t => t.id === tableId);
  const name = table ? table.name : `Table ${tableId}`;
  if (!await confirmDlg(`Open a tab for ${name}?`)) return;
  try {
    const r = await fetch('/api/ts/tabs', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({
        table_id: tableId,
        session_id: _tsSession ? _tsSession.id : null,
      }),
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Could not open tab', 'err'); return; }
    _tsTables = await apiFetch('/api/ts/tables');
    await _tsRenderTab(j.data.id);
  } catch (e) {
    toast(e.message || 'Error opening tab', 'err');
  }
}

// ── Tab detail view ───────────────────────────────────────────────────────────

async function _tsRenderTab(tabId) {
  if (_tsRefreshTimer) { clearInterval(_tsRefreshTimer); _tsRefreshTimer = null; }
  _tsCurrentTabId = tabId;
  _tsItemSearch   = '';
  _tsCatFilter    = null;

  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading tab…</div>';
  try {
    _tsCurrentTab = await apiFetch(`/api/ts/tabs/${tabId}`);
  } catch (e) {
    mod.innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
    return;
  }
  _tsDrawTabView();
}

function _tsDrawTabView() {
  const tab = _tsCurrentTab;
  const mod = document.getElementById('module-content');
  const cats = _tsGetCategories();

  const tabTitle = tab.zone_name
    ? `${esc(tab.zone_name)} — ${esc(tab.table_name)}`
    : esc(tab.table_name);

  mod.innerHTML = `
    <div class="ts-tab-wrap">
      <!-- item picker panel -->
      <div class="ts-items-panel">
        <div class="inv-toolbar" style="flex-shrink:0;border-bottom:1px solid var(--border)">
          <button class="btn" onclick="_tsBackToFloor()">← Floor</button>
          <span style="font-weight:700;font-size:14px;color:var(--ink)">${tabTitle}</span>
          <span style="margin-left:auto;font-size:11px;color:var(--ink3)">Tab #${tab.id}</span>
        </div>
        <div class="ts-item-search-row">
          <input class="ts-item-search" id="ts-item-search" placeholder="Search items…"
            oninput="_tsItemSearchInput(this.value)">
        </div>
        <div class="ts-cat-bar" id="ts-cat-bar">
          <button class="ts-cat-pill${_tsCatFilter===null?' active':''}" onclick="_tsSetCat(null)">All</button>
          ${cats.map(c => `<button class="ts-cat-pill${_tsCatFilter===c?' active':''}"
            onclick="_tsSetCat(${JSON.stringify(c)})">${esc(c)}</button>`).join('')}
        </div>
        <div class="ts-item-grid" id="ts-item-grid">
          ${_tsMakeItemTiles()}
        </div>
      </div>
      <!-- order panel -->
      <div class="ts-order-panel">
        <div class="ts-order-hdr">
          <span>Order</span>
          <span class="ts-order-hdr-sub">${_tsFormatTime(tab.opened_at)}</span>
          ${tab.status === 'Open'
            ? `<button class="btn" style="font-size:11px;padding:3px 8px" onclick="_tsVoidTab()">Void</button>`
            : ''}
        </div>
        <div class="ts-order-lines" id="ts-order-lines">
          ${_tsMakeOrderLines(tab.items)}
        </div>
        <div class="ts-order-footer">
          ${_tsMakeTotals(tab.items)}
          ${tab.status === 'Open' ? `
          <div class="ts-action-btns">
            <button class="ts-btn-kitchen" id="ts-btn-kitchen"
              ${!tab.items.some(i=>!i.sent_to_kitchen)?'disabled':''} onclick="_tsFireKitchen()">
              Fire Kitchen
            </button>
            <button class="ts-btn-settle" id="ts-btn-settle"
              ${!tab.items.length?'disabled':''} onclick="_tsOpenSettle()">
              Settle
            </button>
          </div>
          <button class="btn" style="width:100%;margin-top:8px;font-size:12px"
            ${!tab.items.length?'disabled':''} onclick="_tsSendToRegister()">
            → Send to Register
          </button>`
          : tab.status === 'Sent' ? `
          <div style="text-align:center;padding:10px 0">
            <span style="font-size:12px;font-weight:700;color:var(--accent)">AT REGISTER</span>
            <div style="font-size:11px;color:var(--ink3);margin-top:2px">Being processed at the counter</div>
          </div>
          <button class="btn" style="width:100%;margin-top:6px;font-size:12px" onclick="_tsRecallTab()">
            ← Recall to Floor
          </button>`
          : `<div style="text-align:center;color:var(--ink3);font-size:13px;padding:8px">${tab.status}</div>`}
        </div>
      </div>
    </div>`;

  const searchEl = document.getElementById('ts-item-search');
  if (searchEl) { searchEl.focus(); }
}

// ── Item picker helpers ───────────────────────────────────────────────────────

function _tsGetCategories() {
  const cats = new Set();
  for (const item of _tsItems) {
    if (item.category) cats.add(item.category);
  }
  return [...cats].sort();
}

function _tsGetFilteredItems() {
  let items = _tsItems;
  if (_tsCatFilter) items = items.filter(i => i.category === _tsCatFilter);
  if (_tsItemSearch.trim()) {
    const q = _tsItemSearch.toLowerCase();
    items = items.filter(i =>
      (i.name || '').toLowerCase().includes(q) ||
      (i.code || '').toLowerCase().includes(q) ||
      (i.barcode || '').toLowerCase().includes(q)
    );
  }
  return items;
}

function _tsMakeItemTiles() {
  const items = _tsGetFilteredItems();
  if (!items.length) return '<div style="padding:20px;color:var(--ink3);font-size:13px">No items found</div>';
  return items.map(item => {
    const soldOut = item.is_available === 0;
    return soldOut
      ? `<div class="ts-item-tile ts-item-tile-soldout">
           <div class="ts-item-tile-name">${esc(item.name)}</div>
           <div class="ts-item-tile-price">${fmt(item.unit_price || 0)}</div>
         </div>`
      : `<div class="ts-item-tile" onclick="_tsPromptAdd(${item.id})">
           <div class="ts-item-tile-name">${esc(item.name)}</div>
           <div class="ts-item-tile-price">${fmt(item.unit_price || 0)}</div>
         </div>`;
  }).join('');
}

function _tsItemSearchInput(val) {
  _tsItemSearch = val;
  const grid = document.getElementById('ts-item-grid');
  if (grid) grid.innerHTML = _tsMakeItemTiles();
}

function _tsSetCat(cat) {
  _tsCatFilter = cat;
  const bar = document.getElementById('ts-cat-bar');
  if (bar) {
    bar.querySelectorAll('.ts-cat-pill').forEach(b => b.classList.remove('active'));
    bar.querySelectorAll('.ts-cat-pill').forEach(b => {
      if ((cat === null && b.textContent === 'All') ||
          (cat !== null && b.textContent === cat)) b.classList.add('active');
    });
  }
  const grid = document.getElementById('ts-item-grid');
  if (grid) grid.innerHTML = _tsMakeItemTiles();
}

// ── Order panel helpers ───────────────────────────────────────────────────────

function _tsMakeOrderLines(items) {
  if (!items || !items.length) {
    return '<div class="ts-order-empty">No items yet — tap items on the left to add.</div>';
  }
  return items.map(item => {
    const lineTotal = item.qty * item.unit_price * (item.tax_code === 'GST' ? 1.1 : 1.0);
    const badge = item.sent_to_kitchen
      ? '<span class="ts-sent-badge">Sent</span>'
      : '<span class="ts-unsent-badge">Unsent</span>';
    return `
      <div class="ts-order-line">
        <div class="ts-order-desc">
          <div class="ts-order-desc-txt">${esc(item.description)}</div>
          ${item.note ? `<div class="ts-order-note">${esc(item.note)}</div>` : ''}
          <div style="margin-top:2px">${badge}</div>
        </div>
        <div class="ts-order-qty-wrap">
          <button class="ts-order-qty-btn" onclick="_tsQtyDelta(${item.id},-1)">−</button>
          <span class="ts-order-qty-val">${item.qty % 1 === 0 ? item.qty : item.qty.toFixed(2)}</span>
          <button class="ts-order-qty-btn" onclick="_tsQtyDelta(${item.id},1)">+</button>
        </div>
        <div class="ts-order-price">${fmt(lineTotal)}</div>
        <button class="ts-order-rm" onclick="_tsRemoveItem(${item.id})" title="Remove">✕</button>
      </div>`;
  }).join('');
}

function _tsMakeTotals(items) {
  if (!items || !items.length) return '';
  let subtotal = 0, gst = 0;
  for (const item of items) {
    const ex = item.qty * item.unit_price;
    const g  = item.tax_code === 'GST' ? ex * 0.1 : 0;
    subtotal += ex;
    gst      += g;
  }
  const total = subtotal + gst;
  return `
    <div class="ts-totals">
      <div class="ts-total-row"><span>Subtotal</span><span>${fmt(subtotal)}</span></div>
      <div class="ts-total-row"><span>GST</span><span>${fmt(gst)}</span></div>
      <div class="ts-grand-total"><span>Total</span><span>${fmt(total)}</span></div>
    </div>`;
}

function _tsFormatTime(dt) {
  if (!dt) return '';
  const d = new Date(dt.replace(' ', 'T'));
  return d.toLocaleTimeString('en-AU', {hour:'2-digit', minute:'2-digit', hour12:true});
}

// ── Add item ──────────────────────────────────────────────────────────────────

function _tsPromptAdd(itemId) {
  const item = _tsItems.find(i => i.id === itemId);
  if (!item) return;
  // Close any existing prompt
  document.getElementById('ts-add-prompt')?.remove();
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex'; bd.id = 'ts-add-prompt';
  bd.innerHTML = `
    <div class="modal-box" style="width:340px;padding:0;display:flex;flex-direction:column">
      <div class="modal-hdr">
        <span class="modal-title">${esc(item.name)}</span>
        <button class="modal-close" onclick="document.getElementById('ts-add-prompt')?.remove()">✕</button>
      </div>
      <div class="modal-body" style="display:flex;flex-direction:column;gap:10px">
        <div style="display:flex;align-items:center;gap:10px">
          <label class="pos-sett-lbl" style="margin:0;white-space:nowrap">Qty</label>
          <button class="ts-order-qty-btn" style="width:28px;height:28px;font-size:16px"
            onclick="_tsPromptQtyDelta(-1)">−</button>
          <input id="ts-prompt-qty" type="number" min="0.5" step="0.5" value="1"
            class="pos-sett-inp" style="width:64px;text-align:center">
          <button class="ts-order-qty-btn" style="width:28px;height:28px;font-size:16px"
            onclick="_tsPromptQtyDelta(1)">+</button>
          <span style="margin-left:auto;font-weight:700;color:var(--ink)">${fmt(item.unit_price||0)}</span>
        </div>
        <div>
          <label class="pos-sett-lbl">Note <span style="font-weight:400;color:var(--ink3)">(optional — e.g. no onion, well done)</span></label>
          <input id="ts-prompt-note" class="pos-sett-inp" placeholder="Leave blank if none" style="margin-top:4px">
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn" onclick="document.getElementById('ts-add-prompt')?.remove()">Cancel</button>
        <button class="btn btn-primary" onclick="_tsConfirmAdd(${itemId})">Add to Tab</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
  const noteEl = document.getElementById('ts-prompt-note');
  if (noteEl) {
    noteEl.focus();
    noteEl.addEventListener('keydown', e => { if (e.key === 'Enter') _tsConfirmAdd(itemId); });
  }
}

function _tsPromptQtyDelta(delta) {
  const inp = document.getElementById('ts-prompt-qty');
  if (!inp) return;
  const newVal = Math.max(0.5, parseFloat(inp.value || 1) + delta);
  inp.value = newVal % 1 === 0 ? newVal : newVal.toFixed(1);
}

async function _tsConfirmAdd(itemId) {
  const item = _tsItems.find(i => i.id === itemId);
  if (!item) return;
  const qty  = parseFloat(document.getElementById('ts-prompt-qty')?.value || 1);
  const note = (document.getElementById('ts-prompt-note')?.value || '').trim() || null;
  document.getElementById('ts-add-prompt')?.remove();
  const price_inc = parseFloat(item.unit_price || 0);
  const unit_price_ex = item.tax_code === 'GST'
    ? Math.round(price_inc / 1.1 * 10000) / 10000
    : price_inc;
  await _tsSendItems([{
    item_id:     item.id,
    description: item.name,
    qty,
    unit_price:  unit_price_ex,
    tax_code:    item.tax_code || 'GST',
    account_id:  item.account_id || null,
    note,
  }]);
}

async function _tsSendItems(lines) {
  try {
    const r = await fetch(`/api/ts/tabs/${_tsCurrentTabId}/items`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({lines}),
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Could not add item', 'err'); return; }
    await _tsRefreshTab();
  } catch (e) {
    toast(e.message || 'Error adding item', 'err');
  }
}

async function _tsRefreshTab() {
  try {
    _tsCurrentTab = await apiFetch(`/api/ts/tabs/${_tsCurrentTabId}`);
    _tsUpdateOrderPanel();
  } catch (e) {
    toast('Could not refresh tab', 'err');
  }
}

function _tsUpdateOrderPanel() {
  const tab = _tsCurrentTab;
  const lines = document.getElementById('ts-order-lines');
  if (lines) lines.innerHTML = _tsMakeOrderLines(tab.items);
  const footer = document.querySelector('.ts-order-footer');
  if (footer) {
    footer.innerHTML = _tsMakeTotals(tab.items) + (tab.status === 'Open' ? `
      <div class="ts-action-btns">
        <button class="ts-btn-kitchen" id="ts-btn-kitchen"
          ${!tab.items.some(i=>!i.sent_to_kitchen)?'disabled':''} onclick="_tsFireKitchen()">
          Fire Kitchen
        </button>
        <button class="ts-btn-settle" id="ts-btn-settle"
          ${!tab.items.length?'disabled':''} onclick="_tsOpenSettle()">
          Settle
        </button>
      </div>
      <button class="btn" style="width:100%;margin-top:8px;font-size:12px"
        ${!tab.items.length?'disabled':''} onclick="_tsSendToRegister()">
        → Send to Register
      </button>`
      : tab.status === 'Sent' ? `
      <div style="text-align:center;padding:10px 0">
        <span style="font-size:12px;font-weight:700;color:var(--accent)">AT REGISTER</span>
      </div>
      <button class="btn" style="width:100%;margin-top:6px;font-size:12px" onclick="_tsRecallTab()">
        ← Recall to Floor
      </button>`
      : `<div style="text-align:center;color:var(--ink3);font-size:13px;padding:8px">${tab.status}</div>`);
  }
}

// ── Qty / remove ──────────────────────────────────────────────────────────────

async function _tsQtyDelta(itemId, delta) {
  const tab = _tsCurrentTab;
  const item = tab && tab.items.find(i => i.id === itemId);
  if (!item) return;
  const newQty = item.qty + delta;
  if (newQty <= 0) {
    if (!await confirmDlg('Remove this item from the tab?')) return;
  }
  try {
    const r = await fetch(`/api/ts/tab-items/${itemId}`, {
      method: 'PATCH',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({qty: newQty}),
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Error', 'err'); return; }
    await _tsRefreshTab();
  } catch (e) {
    toast(e.message, 'err');
  }
}

async function _tsRemoveItem(itemId) {
  if (!await confirmDlg('Remove this item from the tab?')) return;
  try {
    const r = await fetch(`/api/ts/tab-items/${itemId}`, {method:'DELETE'});
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Error', 'err'); return; }
    await _tsRefreshTab();
  } catch (e) {
    toast(e.message, 'err');
  }
}

// ── Kitchen docket ────────────────────────────────────────────────────────────

async function _tsFireKitchen() {
  const btn = document.getElementById('ts-btn-kitchen');
  if (btn) { btn.disabled = true; btn.textContent = 'Firing…'; }
  try {
    const r = await fetch(`/api/ts/tabs/${_tsCurrentTabId}/fire-kitchen`, {method:'POST'});
    const j = await r.json();
    if (j.ok) {
      toast('Kitchen docket sent');
      await _tsRefreshTab();
    } else {
      // Printer unavailable — offer manual confirmation
      if (btn) { btn.disabled = false; btn.textContent = 'Fire Kitchen'; }
      _tsShowManualKitchenConfirm(j.error);
    }
  } catch (e) {
    toast(e.message || 'Printer error', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Fire Kitchen'; }
  }
}

function _tsShowManualKitchenConfirm(reason) {
  const tab = _tsCurrentTab;
  if (!tab) return;
  const unsent = (tab.items || []).filter(i => !i.sent_to_kitchen);
  if (!unsent.length) { toast('No new items to send', 'err'); return; }

  const itemRows = unsent.map(i => {
    const note = i.note ? `<div style="font-size:11px;color:var(--ink3);padding-left:8px">↳ ${esc(i.note)}</div>` : '';
    return `<div style="padding:4px 0;border-bottom:1px solid var(--border)">
      <span style="font-weight:600">${i.qty} × ${esc(i.description)}</span>
      ${note}
    </div>`;
  }).join('');

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box" style="width:360px;padding:0;display:flex;flex-direction:column">
      <div class="modal-hdr">
        <span class="modal-title">Manual Kitchen Order</span>
        <button class="modal-close" onclick="this.closest('.modal-bd').remove()">✕</button>
      </div>
      <div class="modal-body" style="display:flex;flex-direction:column;gap:10px">
        <div style="font-size:12px;color:var(--ink2)">${esc(reason || 'No printer available')} — please advise the kitchen verbally or in writing.</div>
        <div style="font-size:13px;font-weight:700;color:var(--ink);margin-bottom:4px">Items to send:</div>
        <div style="font-size:13px;color:var(--ink)">${itemRows}</div>
        <div style="font-size:12px;color:var(--ink3);margin-top:4px">Confirm once the kitchen has been notified.</div>
      </div>
      <div class="modal-foot">
        <button class="btn" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary" id="ts-manual-kitchen-btn" onclick="_tsConfirmManualKitchen(this)">Confirm Order Sent</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
}

async function _tsConfirmManualKitchen(btn) {
  btn.disabled = true; btn.textContent = 'Confirming…';
  try {
    const r = await fetch(`/api/ts/tabs/${_tsCurrentTabId}/confirm-kitchen`, {method:'POST'});
    const j = await r.json();
    btn.closest('.modal-bd').remove();
    if (j.ok) {
      toast('Order confirmed — items marked as sent');
      await _tsRefreshTab();
    } else {
      toast(j.error || 'Error confirming order', 'err');
    }
  } catch (e) {
    toast(e.message || 'Error', 'err');
    btn.disabled = false; btn.textContent = 'Confirm Order Sent';
  }
}

// ── Void tab ──────────────────────────────────────────────────────────────────

async function _tsVoidTab() {
  if (!await confirmDlg('Void this tab? This cannot be undone.')) return;
  try {
    const r = await fetch(`/api/ts/tabs/${_tsCurrentTabId}/void`, {method:'POST'});
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Could not void tab', 'err'); return; }
    toast('Tab voided');
    _tsTables = await apiFetch('/api/ts/tables');
    _tsCurrentTabId = null;
    _tsCurrentTab   = null;
    _tsRenderFloor();
    _tsRefreshTimer = setInterval(_tsAutoRefreshFloor, 30000);
  } catch (e) {
    toast(e.message, 'err');
  }
}

// ── Settlement ────────────────────────────────────────────────────────────────

function _tsOpenSettle() {
  const tab = _tsCurrentTab;
  if (!tab || !tab.items.length) return;
  let subtotal = 0, gst = 0;
  for (const item of tab.items) {
    const ex = item.qty * item.unit_price;
    subtotal += ex;
    gst      += item.tax_code === 'GST' ? ex * 0.1 : 0;
  }
  const total = Math.round((subtotal + gst) * 100) / 100;

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'ts-settle-modal';
  bd.innerHTML = `
    <div class="modal-box" style="width:380px;padding:0;display:flex;flex-direction:column">
      <div class="modal-hdr">
        <span class="modal-title">Settle Tab — ${fmt(total)}</span>
        <button class="modal-close" onclick="_tsDismissSettle()">✕</button>
      </div>
      <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn btn-primary" style="flex:1" onclick="_tsSettleSubmit('cash',${total})">Cash</button>
          <button class="btn btn-primary" style="flex:1" onclick="_tsSettleSubmit('card',${total})">Card</button>
          <button class="btn" style="flex:1" onclick="_tsSettleAccount(${total})">Account</button>
        </div>
        <div id="ts-settle-extra" style="display:none"></div>
      </div>
    </div>`;
  document.body.appendChild(bd);
  _tsTenderModal = bd;
}

function _tsDismissSettle() {
  if (_tsTenderModal) { _tsTenderModal.remove(); _tsTenderModal = null; }
}

function _tsSettleAccount(total) {
  _tsDismissSettle();
  _tsDoSettle({tender:'account', tendered: total});
}

function _tsSettleSubmit(tender, total) {
  const extra = document.getElementById('ts-settle-extra');
  if (!extra) return;
  extra.style.display = 'block';
  if (tender === 'cash') {
    extra.innerHTML = `
      <div>
        <label style="font-size:12px;color:var(--ink2)">Cash tendered</label>
        <input id="ts-cash-in" type="number" step="0.01" min="${total}" value="${total}"
          class="form-control" style="margin-top:4px"
          oninput="_tsCashChange(this.value,${total})">
        <div style="display:flex;justify-content:space-between;margin-top:8px;font-size:13px">
          <span>Change</span><span id="ts-change-val" style="font-weight:700">${fmt(0)}</span>
        </div>
        <button class="btn btn-primary" style="width:100%;margin-top:12px"
          onclick="_tsConfirmCash(${total})">Confirm Cash</button>
      </div>`;
    const inp = document.getElementById('ts-cash-in');
    if (inp) inp.focus();
  } else {
    extra.innerHTML = `
      <div style="text-align:center;color:var(--ink2);font-size:13px;padding:8px 0">
        Process card payment of ${fmt(total)} on terminal, then confirm.
      </div>
      <button class="btn btn-primary" style="width:100%;margin-top:4px"
        onclick="_tsDoSettle({tender:'card',tendered:${total}})">Confirm Card Paid</button>`;
  }
}

function _tsCashChange(tendered, total) {
  const change = Math.max(0, parseFloat(tendered || 0) - total);
  const el = document.getElementById('ts-change-val');
  if (el) el.textContent = fmt(change);
}

function _tsConfirmCash(total) {
  const inp = document.getElementById('ts-cash-in');
  const tendered = inp ? parseFloat(inp.value || 0) : total;
  if (tendered < total) { toast('Cash entered is less than total', 'err'); return; }
  _tsDoSettle({tender:'cash', tendered});
}

async function _tsDoSettle(payload) {
  _tsDismissSettle();
  const btn = document.getElementById('ts-btn-settle');
  if (btn) { btn.disabled = true; btn.textContent = 'Settling…'; }
  try {
    const r = await fetch(`/api/ts/tabs/${_tsCurrentTabId}/settle`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(payload),
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Settlement failed', 'err'); if (btn) { btn.disabled=false; btn.textContent='Settle'; } return; }
    // Auto-print receipt if configured
    if (_tsSettings.printer_auto_print && j.data.invoice_id) {
      fetch('/api/pos/print-receipt', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({
          invoice_id: j.data.invoice_id,
          tender: payload.tender,
          tendered: payload.tendered || j.data.total,
          change: j.data.change || 0,
        }),
      }).catch(() => {});
    }
    toast(`Tab settled — ${j.data.invoice_number}`);
    _tsTables = await apiFetch('/api/ts/tables');
    _tsCurrentTabId = null;
    _tsCurrentTab   = null;
    _tsRenderFloor();
    _tsRefreshTimer = setInterval(_tsAutoRefreshFloor, 30000);
  } catch (e) {
    toast(e.message || 'Settlement error', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Settle'; }
  }
}

// ── Back to floor ─────────────────────────────────────────────────────────────

function _tsBackToFloor() {
  _tsCurrentTabId = null;
  _tsCurrentTab   = null;
  _tsRenderFloor();
  _tsRefreshTimer = setInterval(_tsAutoRefreshFloor, 30000);
}

// ── Admin view ────────────────────────────────────────────────────────────────

async function _tsOpenAdmin() {
  if (_tsRefreshTimer) { clearInterval(_tsRefreshTimer); _tsRefreshTimer = null; }
  const mod = document.getElementById('module-content');
  mod.innerHTML = '<div class="state-loading">Loading…</div>';
  try {
    const [tables, zones] = await Promise.all([
      apiFetch('/api/ts/tables?all=1'),
      apiFetch('/api/ts/zones'),
    ]);
    _tsTables = tables || [];
    _tsZones  = zones  || [];
  } catch (e) {
    mod.innerHTML = `<div class="state-error">${esc(e.message)}</div>`;
    return;
  }
  _tsDrawAdmin();
}

function _tsDrawAdmin() {
  const mod = document.getElementById('module-content');
  mod.innerHTML = `
    <div>
      <div class="inv-toolbar">
        <button class="btn" onclick="_tsBackToFloor()">← Floor</button>
        <span style="font-weight:700;font-size:14px;color:var(--ink);flex:1">Manage Tables</span>
      </div>
      <div style="padding:18px;display:flex;gap:24px;flex-wrap:wrap;align-items:flex-start">
        <!-- Zones -->
        <div class="ts-admin-section" style="flex:1;min-width:240px">
          <div class="ts-admin-hdr">
            <span class="ts-admin-title">Zones</span>
            <button class="btn btn-primary" style="font-size:12px;padding:4px 10px" onclick="_tsNewZone()">+ Zone</button>
          </div>
          <div class="inv-list-panel">
            <div class="tbl-overflow-x">
              <table class="inv-list-table">
                <thead><tr><th>Name</th><th>Order</th><th></th></tr></thead>
                <tbody id="ts-zones-body">
                  ${_tsZones.length
                    ? _tsZones.map(z => `
                      <tr>
                        <td>${esc(z.name)}</td>
                        <td>${z.sort_order}</td>
                        <td style="text-align:right">
                          <button class="btn" style="font-size:11px;padding:2px 8px"
                            onclick="_tsEditZone(${z.id},'${esc(z.name)}',${z.sort_order})">Edit</button>
                          <button class="btn" style="font-size:11px;padding:2px 8px;color:var(--red)"
                            onclick="_tsDeleteZone(${z.id})">Delete</button>
                        </td>
                      </tr>`).join('')
                    : '<tr><td colspan="3" class="tbl-empty-row">No zones yet</td></tr>'}
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <!-- Tables -->
        <div class="ts-admin-section" style="flex:2;min-width:300px">
          <div class="ts-admin-hdr">
            <span class="ts-admin-title">Tables</span>
            <button class="btn btn-primary" style="font-size:12px;padding:4px 10px" onclick="_tsNewTable()">+ Table</button>
          </div>
          <div class="inv-list-panel">
            <div class="tbl-overflow-x">
              <table class="inv-list-table">
                <thead><tr><th>Name</th><th>Zone</th><th>Seats</th><th>Order</th><th>Active</th><th></th></tr></thead>
                <tbody id="ts-tables-body">
                  ${_tsTables.length
                    ? _tsTables.map(t => `
                      <tr style="${!t.is_active?'opacity:.55':''}">
                        <td>${esc(t.name)}</td>
                        <td>${t.zone_name ? esc(t.zone_name) : '<span style="color:var(--ink3)">—</span>'}</td>
                        <td>${t.seats}</td>
                        <td>${t.sort_order}</td>
                        <td>${t.is_active ? '✓' : ''}</td>
                        <td style="text-align:right">
                          <button class="btn" style="font-size:11px;padding:2px 8px"
                            onclick="_tsEditTable(${JSON.stringify(t).replace(/"/g,'&quot;')})">Edit</button>
                          <button class="btn" style="font-size:11px;padding:2px 8px;color:var(--red)"
                            onclick="_tsDeleteTable(${t.id})">Delete</button>
                        </td>
                      </tr>`).join('')
                    : '<tr><td colspan="6" class="tbl-empty-row">No tables yet</td></tr>'}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>`;
}

// Zone forms
function _tsNewZone() { _tsZoneForm(null); }
function _tsEditZone(id, name, sort_order) { _tsZoneForm({id, name, sort_order}); }

function _tsZoneForm(zone) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  bd.innerHTML = `
    <div class="modal-box" style="width:340px;padding:0;display:flex;flex-direction:column">
      <div class="modal-hdr">
        <span class="modal-title">${zone ? 'Edit Zone' : 'New Zone'}</span>
        <button class="modal-close" onclick="this.closest('.modal-bd').remove()">✕</button>
      </div>
      <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
        <div>
          <label class="pos-sett-lbl">Zone Name</label>
          <input id="ts-zf-name" class="pos-sett-inp" value="${esc(zone ? zone.name : '')}">
        </div>
        <div>
          <label class="pos-sett-lbl">Sort Order</label>
          <input id="ts-zf-order" type="number" class="pos-sett-inp" value="${zone ? zone.sort_order : 0}">
        </div>
      </div>
      <div class="modal-foot">
        <button class="btn" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary" onclick="_tsSaveZone(${zone ? zone.id : 'null'},this)">Save</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
  document.getElementById('ts-zf-name').focus();
}

async function _tsSaveZone(id, btn) {
  const name = (document.getElementById('ts-zf-name').value || '').trim();
  const sort_order = parseInt(document.getElementById('ts-zf-order').value || 0);
  if (!name) { toast('Zone name is required', 'err'); return; }
  btn.disabled = true;
  try {
    const r = await fetch('/api/ts/zones', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({id, name, sort_order}),
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Error saving zone', 'err'); btn.disabled=false; return; }
    btn.closest('.modal-bd').remove();
    toast('Zone saved');
    _tsZones = await apiFetch('/api/ts/zones');
    _tsDrawAdmin();
  } catch (e) { toast(e.message, 'err'); btn.disabled=false; }
}

async function _tsDeleteZone(id) {
  if (!await confirmDlg('Delete this zone? Tables assigned to it will become unzoned.')) return;
  try {
    const r = await fetch(`/api/ts/zones/${id}`, {method:'DELETE'});
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Error', 'err'); return; }
    toast('Zone deleted');
    const [tables, zones] = await Promise.all([apiFetch('/api/ts/tables?all=1'), apiFetch('/api/ts/zones')]);
    _tsTables = tables; _tsZones = zones;
    _tsDrawAdmin();
  } catch (e) { toast(e.message, 'err'); }
}

// Table forms
function _tsNewTable() { _tsTableForm(null); }
function _tsEditTable(t) { _tsTableForm(t); }

function _tsTableForm(table) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex';
  const zoneOpts = `<option value="">No zone</option>` + _tsZones.map(z =>
    `<option value="${z.id}"${table && table.zone_id == z.id?' selected':''}>${esc(z.name)}</option>`
  ).join('');
  bd.innerHTML = `
    <div class="modal-box" style="width:360px;padding:0;display:flex;flex-direction:column">
      <div class="modal-hdr">
        <span class="modal-title">${table ? 'Edit Table' : 'New Table'}</span>
        <button class="modal-close" onclick="this.closest('.modal-bd').remove()">✕</button>
      </div>
      <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
        <div>
          <label class="pos-sett-lbl">Table Name</label>
          <input id="ts-tf-name" class="pos-sett-inp" value="${esc(table ? table.name : '')}">
        </div>
        <div>
          <label class="pos-sett-lbl">Zone</label>
          <select id="ts-tf-zone" class="pos-sett-inp">${zoneOpts}</select>
        </div>
        <div style="display:flex;gap:10px">
          <div style="flex:1">
            <label class="pos-sett-lbl">Seats</label>
            <input id="ts-tf-seats" type="number" min="1" class="pos-sett-inp" value="${table ? table.seats : 4}">
          </div>
          <div style="flex:1">
            <label class="pos-sett-lbl">Sort Order</label>
            <input id="ts-tf-order" type="number" class="pos-sett-inp" value="${table ? table.sort_order : 0}">
          </div>
        </div>
        ${table ? `
        <div style="display:flex;align-items:center;gap:8px">
          <input type="checkbox" id="ts-tf-active"${table.is_active?' checked':''}>
          <label for="ts-tf-active" style="font-size:13px;color:var(--ink)">Active</label>
        </div>` : ''}
      </div>
      <div class="modal-foot">
        <button class="btn" onclick="this.closest('.modal-bd').remove()">Cancel</button>
        <button class="btn btn-primary" onclick="_tsSaveTable(${table ? table.id : 'null'},this)">Save</button>
      </div>
    </div>`;
  document.body.appendChild(bd);
  document.getElementById('ts-tf-name').focus();
}

async function _tsSaveTable(id, btn) {
  const name = (document.getElementById('ts-tf-name').value || '').trim();
  const zone_id = document.getElementById('ts-tf-zone').value || null;
  const seats = parseInt(document.getElementById('ts-tf-seats').value || 4);
  const sort_order = parseInt(document.getElementById('ts-tf-order').value || 0);
  const activeEl = document.getElementById('ts-tf-active');
  const is_active = activeEl ? (activeEl.checked ? 1 : 0) : 1;
  if (!name) { toast('Table name is required', 'err'); return; }
  btn.disabled = true;
  try {
    const r = await fetch('/api/ts/tables', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({id, name, zone_id, seats, sort_order, is_active}),
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Error saving table', 'err'); btn.disabled=false; return; }
    btn.closest('.modal-bd').remove();
    toast('Table saved');
    const [tables, zones] = await Promise.all([apiFetch('/api/ts/tables?all=1'), apiFetch('/api/ts/zones')]);
    _tsTables = tables; _tsZones = zones;
    _tsDrawAdmin();
  } catch (e) { toast(e.message, 'err'); btn.disabled=false; }
}

async function _tsDeleteTable(id) {
  if (!await confirmDlg('Delete this table?')) return;
  try {
    const r = await fetch(`/api/ts/tables/${id}`, {method:'DELETE'});
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Cannot delete table', 'err'); return; }
    toast(j.data && j.data.warning ? j.data.warning : 'Table deleted', j.data && j.data.warning ? 'err' : undefined);
    const [tables, zones] = await Promise.all([apiFetch('/api/ts/tables?all=1'), apiFetch('/api/ts/zones')]);
    _tsTables = tables; _tsZones = zones;
    _tsDrawAdmin();
  } catch (e) { toast(e.message, 'err'); }
}

// ── Send tab to register / Recall ─────────────────────────────────────────────

async function _tsSendToRegister() {
  const sessionId = _tsSession ? _tsSession.id : null;
  const btn = document.querySelector('[onclick="_tsSendToRegister()"]');
  if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }
  try {
    const r = await fetch(`/api/ts/tabs/${_tsCurrentTabId}/send-to-register`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({session_id: sessionId}),
    });
    const j = await r.json();
    if (!j.ok) { toast(j.error || 'Could not send to register', 'err'); if (btn) { btn.disabled=false; btn.textContent='→ Send to Register'; } return; }
    toast('Tab sent to register — resume from POS Held');
    _tsCurrentTab = await apiFetch(`/api/ts/tabs/${_tsCurrentTabId}`);
    _tsTables = await apiFetch('/api/ts/tables');
    _tsDrawTabView();
  } catch (e) {
    toast(e.message || 'Error', 'err');
    if (btn) { btn.disabled=false; btn.textContent='→ Send to Register'; }
  }
}

async function _tsRecallTab() {
  const btn = document.querySelector('[onclick="_tsRecallTab()"]');
  if (btn) { btn.disabled = true; btn.textContent = 'Recalling…'; }
  try {
    const r = await fetch(`/api/ts/tabs/${_tsCurrentTabId}/recall`, {method:'POST'});
    const j = await r.json();
    if (!j.ok) {
      toast(j.error || 'Could not recall tab', 'err');
      // Reload tab state — it may have been settled by the register already
      try {
        _tsCurrentTab = await apiFetch(`/api/ts/tabs/${_tsCurrentTabId}`);
        _tsTables     = await apiFetch('/api/ts/tables');
        _tsDrawTabView();
      } catch (_) { _tsBackToFloor(); }
      return;
    }
    toast('Tab recalled — back to Open');
    _tsCurrentTab = await apiFetch(`/api/ts/tabs/${_tsCurrentTabId}`);
    _tsTables = await apiFetch('/api/ts/tables');
    _tsDrawTabView();
  } catch (e) {
    toast(e.message || 'Error', 'err');
    if (btn) { btn.disabled=false; btn.textContent='← Recall to Floor'; }
  }
}
