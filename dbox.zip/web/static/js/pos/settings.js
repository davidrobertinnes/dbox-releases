// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// POS — Settings modal: provider selection, printer config, account mapping
// Depends on globals in pos.js: _posSettings, _posTyroClient, _posTyroScriptReady
'use strict';


// ═══════════════════════════════════════════════════════════════════════════
// SETTINGS MODAL
// ═══════════════════════════════════════════════════════════════════════════

async function _posOpenSettings() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-sett-bd';
  bd.innerHTML = `<div class="modal-box pos-sett-modal">
    <div class="modal-hdr">POS Settings</div>
    <div class="modal-body" id="pos-sett-body"><div class="state-loading">Loading…</div></div>
    <div class="modal-foot">
      <button class="btn" onclick="document.getElementById('pos-sett-bd').remove()">Cancel</button>
      <button class="btn btn-primary" id="pos-sett-save" onclick="_posSaveSettings()">Save</button>
    </div>
  </div>`;
  document.body.appendChild(bd);

  try {
    const [s, accts, contacts] = await Promise.all([
      apiFetch('/api/pos/settings'),
      apiFetch('/api/accounts'),
      apiFetch('/api/contacts'),
    ]);
    _posRenderSettingsForm(s, accts || [], contacts || []);
  } catch(e) {
    const body = document.getElementById('pos-sett-body');
    if (body) body.innerHTML = `<div class="state-error">${_esc(e.message)}</div>`;
  }
}

function _posRenderSettingsForm(s, accts, contacts) {
  const body = document.getElementById('pos-sett-body');
  if (!body) return;
  const prov = s.provider || 'mock';

  const acctOpts = (sel) => '<option value="">— select account —</option>' +
    accts.map(a => `<option value="${a.id}"${a.id == sel ? ' selected' : ''}>${_esc(a.code)} — ${_esc(a.name)}</option>`).join('');
  const conOpts = '<option value="">— select contact —</option>' +
    contacts.map(c => `<option value="${c.id}"${c.id == s.walkin_contact_id ? ' selected' : ''}>${_esc(c.name)}</option>`).join('');

  body.innerHTML = `
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">Terminal Provider</label>
      <select class="pos-sett-inp" id="pos-sett-provider" onchange="_posProviderChange(this.value)">
        <option value="mock"  ${prov==='mock'  ?'selected':''}>Mock (testing — no hardware needed)</option>
        <option value="tyro"  ${prov==='tyro'  ?'selected':''}>Tyro Integrated EFTPOS (certification pending)</option>
        <option value="square"${prov==='square'?'selected':''}>Square Terminal</option>
        <option value="linkly"${prov==='linkly'?'selected':''}>Linkly (CBA / NAB / Westpac / ANZ bank terminals)</option>
      </select>
    </div>
    <div class="pos-sett-row" id="pos-sett-apikey-row">
      <label class="pos-sett-lbl">API Key / Access Token</label>
      <input class="pos-sett-inp" id="pos-sett-apikey" type="password" autocomplete="new-password"
             placeholder="${s.api_key_configured ? '(configured — leave blank to keep)' : 'Enter API key'}">
    </div>
    <div class="pos-sett-row" id="pos-sett-pair-row">
      <label class="pos-sett-lbl">Terminal Pairing</label>
      <div style="display:flex;align-items:center;gap:10px">
        <span id="pos-sett-pair-status" style="color:${s.api_key_configured ? 'var(--green)' : 'var(--ink3)'}">
          ${s.api_key_configured ? '✓ Terminal paired' : 'Not paired'}
        </span>
        <button class="btn btn-sm btn-sec" type="button" onclick="_posLinklyPair()">
          ${s.api_key_configured ? 'Re-pair' : 'Pair Terminal'}
        </button>
      </div>
    </div>
    <div class="pos-sett-row" id="pos-sett-settle-row">
      <label class="pos-sett-lbl">End-of-Day Settlement</label>
      <button class="btn btn-sm btn-sec" type="button" onclick="_posSettleTerminal(this)">Settle Terminal</button>
    </div>
    <div class="pos-sett-row" id="pos-sett-device-row">
      <label class="pos-sett-lbl">Device / Terminal ID</label>
      <input class="pos-sett-inp" id="pos-sett-device" type="text"
             value="${_esc(s.device_id || '')}" placeholder="Terminal device ID">
    </div>
    <div class="pos-sett-row" id="pos-sett-location-row">
      <label class="pos-sett-lbl">Location ID <span class="pos-sett-hint">(Square only)</span></label>
      <input class="pos-sett-inp" id="pos-sett-location" type="text"
             value="${_esc(s.location_id || '')}" placeholder="Square location ID">
    </div>
    <div class="pos-sett-row" id="pos-sett-sandbox-row">
      <label class="pos-sett-lbl">Sandbox Mode <span class="pos-sett-hint">(Square only)</span></label>
      <label class="pos-sett-check">
        <input type="checkbox" id="pos-sett-sandbox" ${s.square_sandbox ? 'checked' : ''}>
        Use Square sandbox (test/developer account)
      </label>
    </div>
    <div class="pos-sett-row" id="pos-sett-tyro-sandbox-row">
      <label class="pos-sett-lbl">Sandbox Mode <span class="pos-sett-hint">(Tyro only)</span></label>
      <label class="pos-sett-check">
        <input type="checkbox" id="pos-sett-tyro-sandbox" ${s.tyro_sandbox ? 'checked' : ''}>
        Use Tyro test simulator (iclientsimulator.test.tyro.com)
      </label>
    </div>
    <div class="pos-sett-row" id="pos-sett-tyro-pair-row">
      <label class="pos-sett-lbl">Terminal Pairing</label>
      <button class="btn btn-sm btn-sec" type="button" onclick="_posTyroPair()">Pair Terminal</button>
    </div>
    <div class="pos-sett-row" id="pos-sett-tyro-settle-row">
      <label class="pos-sett-lbl">End-of-Day Settlement</label>
      <button class="btn btn-sm btn-sec" type="button" onclick="_posTyroSettle(this)">Settle Terminal</button>
    </div>
    <div class="pos-sett-row" id="pos-sett-tyro-int-receipt-row">
      <label class="pos-sett-lbl">Integrated Receipts <span class="pos-sett-hint">(Tyro)</span></label>
      <label class="pos-sett-check">
        <input type="checkbox" id="pos-sett-tyro-int-receipt" ${s.tyro_integrated_receipt ? 'checked' : ''}>
        Return receipt text to POS (instead of terminal printing)
      </label>
    </div>
    <div class="pos-sett-row" id="pos-sett-tyro-merchant-copy-row">
      <label class="pos-sett-lbl">Merchant Copy Printing <span class="pos-sett-hint">(Tyro)</span></label>
      <label class="pos-sett-check">
        <input type="checkbox" id="pos-sett-tyro-merchant-copy" ${s.tyro_merchant_copy ? 'checked' : ''}>
        Auto-print merchant copy for all transactions (always on for signature-required)
      </label>
    </div>
    <div class="pos-sett-row" id="pos-sett-tyro-int-surcharge-row">
      <label class="pos-sett-lbl">Integrated Surcharging <span class="pos-sett-hint">(Tyro)</span></label>
      <label class="pos-sett-check">
        <input type="checkbox" id="pos-sett-tyro-int-surcharge" ${s.tyro_integrated_surcharge ? 'checked' : ''}>
        Enable Tyro surcharging (terminal adds card surcharge)
      </label>
    </div>
    <div class="pos-sett-row" id="pos-sett-tyro-logs-row">
      <label class="pos-sett-lbl">iClient Diagnostics <span class="pos-sett-hint">(Tyro)</span></label>
      <button class="btn btn-sm btn-sec" type="button" onclick="_posTyroShowLogs()">Request iClient Logs</button>
    </div>
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">Terminal Display Name</label>
      <input class="pos-sett-inp" id="pos-sett-name" type="text"
             value="${_esc(s.terminal_name || 'POS Terminal')}">
    </div>
    <div class="pos-sett-sep"></div>
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">Cash Account</label>
      <select class="pos-sett-inp" id="pos-sett-cash">${acctOpts(s.cash_account_id)}</select>
    </div>
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">Card / EFTPOS Account</label>
      <select class="pos-sett-inp" id="pos-sett-card">${acctOpts(s.card_account_id)}</select>
    </div>
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">Banking Account <span class="pos-sett-hint">(for till banking)</span></label>
      <select class="pos-sett-inp" id="pos-sett-banking">${acctOpts(s.banking_account_id)}</select>
    </div>
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">Walk-in Customer</label>
      <select class="pos-sett-inp" id="pos-sett-walkin">${conOpts}</select>
    </div>
    <div class="pos-sett-sep"></div>
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">Thermal Printer</label>
      <label class="pos-sett-check">
        <input type="checkbox" id="pos-sett-printer-enabled"
               ${s.printer_enabled ? 'checked' : ''}
               onchange="_posPrinterEnabledChange(this.checked)">
        Enable receipt printer
      </label>
    </div>
    <div id="pos-sett-printer-rows" style="${s.printer_enabled ? '' : 'display:none'}">
      <div class="pos-sett-row">
        <label class="pos-sett-lbl">Printer Type</label>
        <select class="pos-sett-inp" id="pos-sett-printer-type">
          <option value="network" ${(s.printer_type||'network')==='network'?'selected':''}>Network (TCP/IP — LAN)</option>
        </select>
      </div>
      <div class="pos-sett-row">
        <label class="pos-sett-lbl">Printer IP Address</label>
        <input class="pos-sett-inp" id="pos-sett-printer-host" type="text"
               value="${_esc(s.printer_host || '')}" placeholder="e.g. 192.168.1.100">
      </div>
      <div class="pos-sett-row">
        <label class="pos-sett-lbl">Port <span class="pos-sett-hint">(default 9100)</span></label>
        <input class="pos-sett-inp" id="pos-sett-printer-port" type="number"
               value="${s.printer_port || 9100}" min="1" max="65535" style="width:100px">
      </div>
      <div class="pos-sett-row">
        <label class="pos-sett-lbl">Auto-print receipts</label>
        <label class="pos-sett-check">
          <input type="checkbox" id="pos-sett-auto-print"
                 ${s.printer_auto_print ? 'checked' : ''}>
          Print automatically after each sale
        </label>
      </div>
    </div>
    <div class="pos-sett-sep"></div>
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">Receipt Footer Message</label>
      <input class="pos-sett-inp" id="pos-sett-footer" type="text"
             value="${_esc(s.receipt_footer || '')}" placeholder="e.g. Thanks for shopping with us!">
    </div>
    <div class="pos-sett-sep"></div>
    <div class="pos-sett-row">
      <label class="pos-sett-lbl">End-of-Day Email</label>
      <label class="pos-sett-check">
        <input type="checkbox" id="pos-sett-eod-email"
               ${s.eod_email_enabled ? 'checked' : ''}
               onchange="document.getElementById('pos-sett-eod-addr-row').style.display=this.checked?'':'none'">
        Email Z-report when session closes
      </label>
    </div>
    <div class="pos-sett-row" id="pos-sett-eod-addr-row" style="${s.eod_email_enabled ? '' : 'display:none'}">
      <label class="pos-sett-lbl">Send to <span class="pos-sett-hint">(email address)</span></label>
      <input class="pos-sett-inp" id="pos-sett-eod-addr" type="email"
             value="${_esc(s.eod_email_address || '')}" placeholder="owner@example.com">
    </div>`;

  _posProviderChange(prov);
}

function _posPrinterEnabledChange(on) {
  const rows = document.getElementById('pos-sett-printer-rows');
  if (rows) rows.style.display = on ? '' : 'none';
}

function _posProviderChange(prov) {
  const apikeyRow      = document.getElementById('pos-sett-apikey-row');
  const deviceRow      = document.getElementById('pos-sett-device-row');
  const locationRow    = document.getElementById('pos-sett-location-row');
  const sandboxRow     = document.getElementById('pos-sett-sandbox-row');
  const pairRow        = document.getElementById('pos-sett-pair-row');
  const settleRow      = document.getElementById('pos-sett-settle-row');
  const tyroSandboxRow   = document.getElementById('pos-sett-tyro-sandbox-row');
  const tyroPairRow      = document.getElementById('pos-sett-tyro-pair-row');
  const tyroSettleRow    = document.getElementById('pos-sett-tyro-settle-row');
  const tyroIntRcptRow    = document.getElementById('pos-sett-tyro-int-receipt-row');
  const tyroMerchCopyRow  = document.getElementById('pos-sett-tyro-merchant-copy-row');
  const tyroIntSurRow     = document.getElementById('pos-sett-tyro-int-surcharge-row');
  const tyroLogsRow       = document.getElementById('pos-sett-tyro-logs-row');
  if (!apikeyRow) return;
  const isMock   = prov === 'mock';
  const isLinkly = prov === 'linkly';
  const isSquare = prov === 'square';
  const isTyro   = prov === 'tyro';
  apikeyRow.style.display      = (isMock || isLinkly || isTyro) ? 'none' : '';
  deviceRow.style.display      = (isMock || isLinkly || isTyro) ? 'none' : '';
  locationRow.style.display    = isSquare ? '' : 'none';
  if (sandboxRow)     sandboxRow.style.display     = isSquare ? '' : 'none';
  if (pairRow)        pairRow.style.display        = isLinkly ? '' : 'none';
  if (settleRow)      settleRow.style.display      = isLinkly ? '' : 'none';
  if (tyroSandboxRow) tyroSandboxRow.style.display = isTyro ? '' : 'none';
  if (tyroPairRow)    tyroPairRow.style.display    = isTyro ? '' : 'none';
  if (tyroSettleRow)  tyroSettleRow.style.display  = isTyro ? '' : 'none';
  if (tyroIntRcptRow)   tyroIntRcptRow.style.display   = isTyro ? '' : 'none';
  if (tyroMerchCopyRow) tyroMerchCopyRow.style.display = isTyro ? '' : 'none';
  if (tyroIntSurRow)    tyroIntSurRow.style.display    = isTyro ? '' : 'none';
  if (tyroLogsRow)      tyroLogsRow.style.display      = isTyro ? '' : 'none';
  // Default sandbox to ON for Tyro — production requires explicit opt-out
  if (isTyro && tyroSandboxRow) {
    const cb = document.getElementById('pos-sett-tyro-sandbox');
    if (cb && !cb.checked) cb.checked = true;
  }
}

async function _posSaveSettings() {
  const btn = document.getElementById('pos-sett-save');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
  try {
    const isTyroProv = (document.getElementById('pos-sett-provider')?.value || 'mock') === 'tyro';
    const payload = {
      provider:          document.getElementById('pos-sett-provider')?.value || 'mock',
      // Tyro API key is embedded server-side — never read from or written by the UI
      api_key:           isTyroProv ? '' : (document.getElementById('pos-sett-apikey')?.value || ''),
      device_id:         document.getElementById('pos-sett-device')?.value || '',
      location_id:       document.getElementById('pos-sett-location')?.value || '',
      terminal_name:     document.getElementById('pos-sett-name')?.value || 'POS Terminal',
      cash_account_id:   document.getElementById('pos-sett-cash')?.value || null,
      card_account_id:   document.getElementById('pos-sett-card')?.value || null,
      walkin_contact_id: document.getElementById('pos-sett-walkin')?.value || null,
      printer_enabled:   document.getElementById('pos-sett-printer-enabled')?.checked || false,
      printer_type:      document.getElementById('pos-sett-printer-type')?.value || 'network',
      printer_host:      document.getElementById('pos-sett-printer-host')?.value || '',
      printer_port:      parseInt(document.getElementById('pos-sett-printer-port')?.value) || 9100,
      printer_auto_print: document.getElementById('pos-sett-auto-print')?.checked || false,
      square_sandbox:      document.getElementById('pos-sett-sandbox')?.checked || false,
      banking_account_id:  document.getElementById('pos-sett-banking')?.value || null,
      receipt_footer:      document.getElementById('pos-sett-footer')?.value || '',
      eod_email_enabled:   document.getElementById('pos-sett-eod-email')?.checked || false,
      eod_email_address:   document.getElementById('pos-sett-eod-addr')?.value || '',
      tyro_sandbox:              document.getElementById('pos-sett-tyro-sandbox')?.checked || false,
      tyro_integrated_receipt:   document.getElementById('pos-sett-tyro-int-receipt')?.checked || false,
      tyro_merchant_copy:        document.getElementById('pos-sett-tyro-merchant-copy')?.checked || false,
      tyro_integrated_surcharge: document.getElementById('pos-sett-tyro-int-surcharge')?.checked || false,
    };
    // If sandbox mode changed, reset the cached script promise so the correct
    // script URL is used on the next _posGetTyroClient() call
    const sandboxChanged = !!_posSettings.tyro_sandbox !== !!payload.tyro_sandbox;
    _posSettings = {..._posSettings, ...payload};
    if (sandboxChanged) {
      _posTyroClient = null;
      _posTyroScriptReady = null;
    }
    const r = await fetch('/api/pos/settings', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Save failed');
    document.getElementById('pos-sett-bd')?.remove();
    toast('POS settings saved');
  } catch(e) {
    toast(e.message || 'Save failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Save'; }
  }
}
