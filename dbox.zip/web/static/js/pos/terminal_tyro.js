// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// POS — Tyro iClient adapter
// All _posTyro* and _posGetTyroClient functions live here.
// Depends on globals in pos.js: _posSettings, _posTyroClient, _posTyroScriptReady,
// _posTyroCustomerReceipt, _posTyroSplitSurchargeCents
'use strict';

// Tyro API key is read from TYRO_API_KEY env var server-side (Phase 2+).
// Certification requires it is never configurable by merchants via the UI.

// Production:   https://iclient.tyro.com/iclient-with-ui-v1.js
// Sandbox/test: https://iclientsimulator.test.tyro.com/iclient-with-ui-v1.js  (simulator — no physical terminal)
function _posTyroScriptUrl() {
  return _posSettings.tyro_sandbox
    ? 'https://iclientsimulator.test.tyro.com/iclient-with-ui-v1.js'
    : 'https://iclient.tyro.com/iclient-with-ui-v1.js';
}

function _posTyroLogsUrl() {
  return _posSettings.tyro_sandbox
    ? 'https://iclientsimulator.test.tyro.com/logs.html'
    : 'https://iclient.tyro.com/logs.html';
}

function _posTyroConfigUrl() {
  return _posSettings.tyro_sandbox
    ? 'https://iclientsimulator.test.tyro.com/configuration.html'
    : 'https://iclient.tyro.com/configuration.html';
}

async function _posGetTyroClient() {
  // Sandbox Mode switched since the iClient library was loaded: drop the old
  // library (live or simulator) so sales don't keep going to the wrong service
  const wantUrl = _posTyroScriptUrl();
  const loaded  = document.getElementById('tyro-iclient-script');
  if (loaded && loaded.src !== wantUrl) {
    loaded.remove();
    try { delete window.TYRO; } catch (_) {}
    if (window.TYRO) window.TYRO = undefined;
    _posTyroScriptReady = null;
    _posTyroClient      = null;
  }
  if (!_posTyroScriptReady) {
    _posTyroScriptReady = new Promise((resolve, reject) => {
      if (window.TYRO) { resolve(); return; }
      const existing = document.getElementById('tyro-iclient-script');
      if (existing) {
        const poll = setInterval(() => { if (window.TYRO) { clearInterval(poll); resolve(); } }, 100);
        return;
      }
      const s = document.createElement('script');
      s.id = 'tyro-iclient-script';
      s.src = _posTyroScriptUrl();
      s.onload = () => resolve();
      s.onerror = () => reject(new Error('Failed to load Tyro iClient — check internet connection'));
      document.head.appendChild(s);
    });
  }
  await _posTyroScriptReady;
  if (!_posTyroClient) {
    // Tyro POS-info criteria: no spaces or empty values; version must match the running app
    const noSpaces = v => String(v || '').replace(/\s+/g, '');
    _posTyroClient = new TYRO.IClientWithUI(_posSettings.tyro_api_key || 'sandbox', {
      posProductVendor:  'DogboxSoftware',
      posProductName:    'Dogbox',
      posProductVersion: noSpaces(_posSettings.app_version) || 'dev',
      siteReference:     noSpaces(_posSettings.location_id || _posSettings.device_id) || 'DogboxPOS',
    });
  }
  return _posTyroClient;
}

// Tyro amounts are whole cents as strings — never floating dollars
function _posTyroCents(dollars) {
  return Math.round(parseFloat(dollars || 0) * 100);
}

function _posTyroSurchargeCents(td) {
  return td && td.surchargeAmount ? Math.round(parseFloat(td.surchargeAmount) * 100) : 0;
}

// Shared receiptCallback: signature-verified merchant copies always print;
// other merchant copies only when "Merchant Copy Printing" is on.
function _posTyroReceiptCallback(receipt) {
  if (receipt && (receipt.signatureRequired || _posSettings.tyro_merchant_copy)) {
    _posTyroPrintMerchantReceipt(receipt.merchantReceipt || '', receipt.signatureRequired);
  }
}

async function _posTenderCardTyro(total) {
  const amountStr  = String(_posTyroCents(total));
  const intReceipt = !!_posSettings.tyro_integrated_receipt;

  let client;
  try {
    client = await _posGetTyroClient();
  } catch(e) {
    toast(e.message, 'err');
    return;
  }

  _posTyroCustomerReceipt = null;
  _posTyroMerchantReceipt = null;

  const callbacks = {
    // Must be a plain function — Tyro iClient checks .constructor === Function;
    // async functions are AsyncFunction and fail that check
    transactionCompleteCallback: function(td) {
      sessionStorage.removeItem('tyro_tx_pending');
      if (td.result === 'APPROVED') {
        const surchargeCents = _posTyroSurchargeCents(td);
        if (intReceipt && td.customerReceipt) _posTyroCustomerReceipt = td.customerReceipt;
        const txRef = td.transactionReference || ('TYR-' + Date.now());
        _posSubmitSale('card', null, txRef, 'tyro', null, td.rrn || td.authorisationCode || '', surchargeCents)
          .then(function(result) { _posShowReceipt(result, 0, 'card', result.total, null, surchargeCents); })
          .catch(function(e) { toast(e.message || 'Sale submission failed', 'err'); });
      } else {
        _posTyroShowUnsuccessful(td, 'Payment');
      }
    },
    // Always provide receiptCallback — IClientWithUI requires both callbacks
    receiptCallback: _posTyroReceiptCallback,
  };

  // IClientWithUI manages its own overlay — do not show a competing modal
  sessionStorage.setItem('tyro_tx_pending', '1');
  try {
    // Dogbox has no surcharge of its own, so Tyro surcharging is always requested
    client.initiatePurchase(
      { amount: amountStr, cashout: "0", integratedReceipt: intReceipt, enableSurcharge: true },
      callbacks
    );
  } catch(e) {
    sessionStorage.removeItem('tyro_tx_pending');
    toast('Tyro error: ' + (e.message || e), 'err');
  }
}

async function _posSplitChargeTyro(total) {
  const cashAmt = parseFloat(document.getElementById('pos-split-cash')?.value) || 0;
  const cardAmt = parseFloat(document.getElementById('pos-split-card')?.value) || 0;
  const intReceipt = !!_posSettings.tyro_integrated_receipt;

  const amountStr = String(_posTyroCents(cardAmt));
  _posTyroSplitSurchargeCents = 0;
  _posTyroCustomerReceipt = null;
  _posTyroMerchantReceipt = null;

  let client;
  try {
    client = await _posGetTyroClient();
  } catch(e) {
    toast(e.message, 'err');
    return;
  }

  // Hide (not remove) the split modal while Tyro shows its own overlay —
  // _posSplitCollectCash renders the next step into it once the card is approved
  const splitModal = document.getElementById('pos-split-modal');
  if (splitModal) splitModal.style.display = 'none';
  const restoreSplitModal = function() { if (splitModal) splitModal.style.display = 'flex'; };

  const splitCallbacks = {
    transactionCompleteCallback: function(td) {
      sessionStorage.removeItem('tyro_tx_pending');
      restoreSplitModal();
      if (td.result === 'APPROVED') {
        const txRef = td.transactionReference || ('TYR-' + Date.now());
        _posTyroSplitSurchargeCents = _posTyroSurchargeCents(td);
        if (intReceipt && td.customerReceipt) _posTyroCustomerReceipt = td.customerReceipt;
        _posSplitCollectCash(cashAmt, cardAmt, total, txRef, 'tyro', _posTyroSplitSurchargeCents);
      } else {
        // Split form is still in the modal — operator can retry or cancel
        _posTyroShowUnsuccessful(td, 'Payment');
      }
    },
    receiptCallback: _posTyroReceiptCallback,
  };

  // IClientWithUI manages its own overlay — do not show a competing modal
  sessionStorage.setItem('tyro_tx_pending', '1');
  try {
    client.initiatePurchase(
      { amount: amountStr, cashout: "0", integratedReceipt: intReceipt, enableSurcharge: true },
      splitCallbacks
    );
  } catch(e) {
    sessionStorage.removeItem('tyro_tx_pending');
    restoreSplitModal();
    toast('Tyro error: ' + (e.message || e), 'err');
  }
}

async function _posTyroPair() {
  // Reset the iClient instance so pairing always starts clean. If the previous
  // instance was put into a bad state (e.g. continueLastTransaction on a
  // non-existent transaction), a stale instance would cause the pairing request
  // to fail with 404. We keep _posTyroScriptReady so the script isn't re-fetched.
  // Also clear any pending-transaction flag — re-pairing abandons any prior transaction.
  sessionStorage.removeItem('tyro_tx_pending');
  _posTyroClient = null;
  // The configuration page communicates with the iClient instance on the parent page via
  // postMessage — the iClient must be loaded and instantiated before the iframe opens.
  try {
    await _posGetTyroClient();
  } catch(e) {
    toast('Failed to load Tyro iClient: ' + e.message, 'err');
    return;
  }
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-tyro-pair-bd';
  bd.innerHTML = `<div class="modal-box" style="max-width:700px;width:90vw;height:80vh;display:flex;flex-direction:column">
    <div class="modal-hdr">
      <span>Pair Tyro Terminal</span>
      <button class="modal-close" onclick="document.getElementById('pos-tyro-pair-bd').remove()">✕</button>
    </div>
    <div style="flex:1">
      <iframe src="${_posTyroConfigUrl()}" style="width:100%;height:100%;border:none;border-radius:0 0 8px 8px"></iframe>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

function _posTyroSettle(btn) {
  // Certification requires user confirmation before initiating settlement
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-tyro-settle-confirm-bd';
  bd.innerHTML = `<div class="modal-box" style="max-width:380px">
    <div class="modal-hdr">Tyro Manual Settlement</div>
    <div class="modal-body" style="padding:16px;font-size:14px">
      <p style="margin:0 0 10px">This will close the current settlement period on the Tyro terminal and begin a new one.</p>
      <p style="margin:0;color:var(--ink2);font-size:13px">Only proceed if you intend to finalise today's transactions. This action cannot be undone.</p>
    </div>
    <div class="modal-foot">
      <button class="btn btn-sec" onclick="document.getElementById('pos-tyro-settle-confirm-bd').remove()">Cancel</button>
      <button class="btn btn-primary" onclick="_posTyroDoSettle(this)">Settle Terminal</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

async function _posTyroDoSettle(btn) {
  document.getElementById('pos-tyro-settle-confirm-bd')?.remove();
  if (btn) { btn.disabled = true; btn.textContent = 'Settling…'; }
  try {
    const client = await _posGetTyroClient();
    // result: 'success'|'failure'; message; currentTerminalBusinessDay (dd/MM/yyyy) on success
    client.manualSettlement((response) => {
      if ((response.result || '').toLowerCase() === 'success') {
        const day = response.currentTerminalBusinessDay ? ' — ' + response.currentTerminalBusinessDay : '';
        const msg = response.message ? ' (' + response.message + ')' : '';
        toast('Terminal settled' + day + msg);
      } else {
        toast('Settlement failed — ' + (response.message || 'check terminal'), 'err');
      }
    });
  } catch(e) {
    toast(e.message, 'err');
  }
}

function _posTyroShowLogs() {
  // Tyro iClient logs are accessed by embedding the logs URL in an iframe — no JS method call
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-tyro-logs-bd';
  bd.innerHTML = `<div class="modal-box" style="max-width:800px;width:90vw;height:80vh;display:flex;flex-direction:column">
    <div class="modal-hdr">
      <span>Tyro iClient Logs</span>
      <button class="modal-close" onclick="document.getElementById('pos-tyro-logs-bd').remove()">✕</button>
    </div>
    <div style="flex:1;padding:0">
      <iframe src="${_posTyroLogsUrl()}" style="width:100%;height:100%;border:none;border-radius:0 0 8px 8px"></iframe>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

function _posTyroPrintMerchantReceipt(text, signatureRequired) {
  if (!text) return;
  // Send to thermal printer if enabled
  if (_posSettings.printer_enabled) {
    _posTyroPrintRawReceipt(text);
    if (!signatureRequired) return; // no modal needed for non-signature prints
  } else if (!signatureRequired) {
    // No receipt printer — keep it to show on the result/receipt screen
    _posTyroMerchantReceipt = text;
    return;
  }
  // For signature-required: always show modal so operator can collect signature.
  // It arrives while Tyro's overlay is asking "Signature OK?", so it must sit above
  // that overlay — the operator checks the signature here, then answers Tyro.
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.style.zIndex = '2147483647';
  bd.innerHTML = `<div class="modal-box" style="max-width:380px">
    <div class="modal-hdr">Merchant Receipt — Signature Required</div>
    <div class="modal-body" style="padding:16px">
      <pre style="font-family:monospace;font-size:12px;white-space:pre-wrap;margin:0">${_esc(text)}</pre>
    </div>
    <div class="modal-foot">
      <button class="btn btn-primary" onclick="this.closest('.modal-bd').remove()">Done — Signed</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

// Merchant copy block for the sale/refund receipt screens (consumes the stored copy)
function _posTyroMerchantCopyHtml() {
  if (!_posTyroMerchantReceipt) return '';
  const html = '<div class="pos-receipt-tyro-rcpt"><pre style="font-family:monospace;font-size:11px;'
    + 'white-space:pre-wrap;margin:8px 0 0;text-align:left;border-top:1px dashed var(--border);padding-top:8px">'
    + _esc(_posTyroMerchantReceipt) + '</pre></div>';
  _posTyroMerchantReceipt = null;
  return html;
}

function _posTyroPrintRawReceipt(text) {
  // Send Tyro receipt text to the thermal printer (no-op without one)
  if (!text || !_posSettings.printer_enabled) return;
  fetch('/api/pos/print-raw', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ text }),
  }).catch(() => {});
}

// Declined / cancelled / reversed / error results. Tyro's own overlay shows the
// result; the POS must also make the customer copy (marked with the result)
// available — printed when there is a receipt printer, otherwise shown on screen.
function _posTyroShowUnsuccessful(td, label) {
  const result = td.result || 'UNKNOWN';
  if (result === 'CANCELLED') toast(label + ' cancelled');
  else toast(label + ' ' + (result === 'DECLINED' ? 'declined' : result.toLowerCase()), 'err');

  const custCopy  = _posSettings.tyro_integrated_receipt ? (td.customerReceipt || '') : '';
  const merchCopy = _posTyroMerchantReceipt;
  _posTyroMerchantReceipt = null;
  const unknown = result === 'UNKNOWN';
  if (!custCopy && !merchCopy && !unknown) return;

  if (_posSettings.printer_enabled && custCopy) _posTyroPrintRawReceipt(custCopy);
  const pre = t => `<pre style="font-family:monospace;font-size:11px;white-space:pre-wrap;margin:8px 0 0">${_esc(t)}</pre>`;
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="max-width:400px">
    <div class="modal-hdr">${_esc(label)} ${_esc(result)}</div>
    <div class="modal-body" style="padding:16px;font-size:13px">
      ${unknown ? `<p style="margin:0 0 8px;color:var(--amber)">The result could not be confirmed.
        Check the Tyro terminal to see whether the transaction went through before trying again.</p>` : ''}
      ${custCopy ? pre(custCopy) : ''}
      ${merchCopy ? pre(merchCopy) : ''}
    </div>
    <div class="modal-foot">
      <button class="btn btn-primary" onclick="this.closest('.modal-bd').remove()">OK</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
}
