// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// POS — Tyro iClient adapter
// All _posTyro* and _posGetTyroClient functions live here.
// Depends on globals in pos.js: _posSettings, _posTyroClient, _posTyroScriptReady,
// _posTyroCustomerReceipt, _posTyroSplitSurchargeCents
'use strict';

// Tyro API key is read from TYRO_API_KEY env var server-side (Phase 2+).
// Certification requires it is never configurable by merchants via the UI.

// Production:   https://iclient.tyro.com/iclient-with-ui-v1.js
// Sandbox/test: https://iclientsimulator.test.tyro.com/iclient-with-ui-v1.js  (simulator — no physical terminal)
function _posTyroScriptUrl() {
  return _posSettings.tyro_sandbox
    ? 'https://iclientsimulator.test.tyro.com/iclient-with-ui-v1.js'
    : 'https://iclient.tyro.com/iclient-with-ui-v1.js';
}

function _posTyroLogsUrl() {
  return _posSettings.tyro_sandbox
    ? 'https://iclientsimulator.test.tyro.com/logs.html'
    : 'https://iclient.tyro.com/logs.html';
}

function _posTyroConfigUrl() {
  return _posSettings.tyro_sandbox
    ? 'https://iclientsimulator.test.tyro.com/configuration.html'
    : 'https://iclient.tyro.com/configuration.html';
}

async function _posGetTyroClient() {
  if (!_posTyroScriptReady) {
    _posTyroScriptReady = new Promise((resolve, reject) => {
      if (window.TYRO) { resolve(); return; }
      const existing = document.getElementById('tyro-iclient-script');
      if (existing) {
        const poll = setInterval(() => { if (window.TYRO) { clearInterval(poll); resolve(); } }, 100);
        return;
      }
      const s = document.createElement('script');
      s.id = 'tyro-iclient-script';
      s.src = _posTyroScriptUrl();
      s.onload = () => resolve();
      s.onerror = () => reject(new Error('Failed to load Tyro iClient — check internet connection'));
      document.head.appendChild(s);
    });
  }
  await _posTyroScriptReady;
  if (!_posTyroClient) {
    _posTyroClient = new TYRO.IClientWithUI(_posSettings.tyro_api_key || 'sandbox', {
      posProductVendor:  'DogboxSoftware',
      posProductName:    'Dogbox',
      posProductVersion: '2.0.0',
      siteReference:     _posSettings.location_id || _posSettings.device_id || 'DogboxPOS',
    });
  }
  return _posTyroClient;
}

async function _posTenderCardTyro(total) {
  const amountStr  = String(Math.round(parseFloat(total) * 100));
  const intReceipt = !!_posSettings.tyro_integrated_receipt;

  let client;
  try {
    client = await _posGetTyroClient();
  } catch(e) {
    toast(e.message, 'err');
    return;
  }

  _posTyroCustomerReceipt = null;

  const callbacks = {
    // Must be a plain function — Tyro iClient checks .constructor === Function;
    // async functions are AsyncFunction and fail that check
    transactionCompleteCallback: function(td) {
      sessionStorage.removeItem('tyro_tx_pending');
      if (td.result === 'APPROVED') {
        const surchargeCents = td.surchargeAmount ? Math.round(parseFloat(td.surchargeAmount) * 100) : 0;
        if (intReceipt && td.customerReceipt) _posTyroCustomerReceipt = td.customerReceipt;
        const txRef = td.transactionReference || ('TYR-' + Date.now());
        _posSubmitSale('card', null, txRef, 'tyro', null, td.rrn || td.authorisationCode || '', surchargeCents)
          .then(function(result) { _posShowReceipt(result, 0, 'card', result.total, null, surchargeCents); })
          .catch(function(e) { toast(e.message || 'Sale submission failed', 'err'); });
      } else if (td.result === 'CANCELLED') {
        if (intReceipt && td.customerReceipt) _posTyroPrintRawReceipt(td.customerReceipt);
      } else {
        toast('Payment ' + (td.result === 'DECLINED' ? 'declined' : td.result), 'err');
        if (intReceipt && td.customerReceipt) _posTyroPrintRawReceipt(td.customerReceipt);
      }
    },
    // Always provide receiptCallback — IClientWithUI requires both callbacks
    receiptCallback: function(receipt) {
      if (receipt && (receipt.signatureRequired || _posSettings.tyro_merchant_copy)) {
        _posTyroPrintMerchantReceipt(receipt.merchantReceipt || '', receipt.signatureRequired);
      }
    },
  };

  // IClientWithUI manages its own overlay — do not show a competing modal
  sessionStorage.setItem('tyro_tx_pending', '1');
  try {
    client.initiatePurchase(
      { amount: amountStr, cashout: "0", integratedReceipt: intReceipt,
        enableSurcharge: !!_posSettings.tyro_integrated_surcharge },
      callbacks
    );
  } catch(e) {
    sessionStorage.removeItem('tyro_tx_pending');
    toast('Tyro error: ' + (e.message || e), 'err');
  }
}

async function _posSplitChargeTyro(total) {
  const cashAmt = parseFloat(document.getElementById('pos-split-cash')?.value) || 0;
  const cardAmt = parseFloat(document.getElementById('pos-split-card')?.value) || 0;

  const amountStr = String(Math.round(cardAmt * 100));
  _posTyroSplitSurchargeCents = 0;

  let client;
  try {
    client = await _posGetTyroClient();
  } catch(e) {
    toast(e.message, 'err');
    return;
  }

  // Close the split modal before Tyro shows its own overlay
  document.getElementById('pos-split-modal')?.remove();

  const splitCallbacks = {
    transactionCompleteCallback: function(td) {
      sessionStorage.removeItem('tyro_tx_pending');
      if (td.result === 'APPROVED') {
        const txRef = td.transactionReference || ('TYR-' + Date.now());
        _posTyroSplitSurchargeCents = td.surchargeAmount ? Math.round(parseFloat(td.surchargeAmount) * 100) : 0;
        _posSplitCollectCash(cashAmt, cardAmt, total, txRef, 'tyro', _posTyroSplitSurchargeCents);
      } else if (td.result === 'CANCELLED') {
        toast('Payment cancelled');
      } else {
        toast('Payment ' + (td.result === 'DECLINED' ? 'declined' : td.result), 'err');
      }
    },
    receiptCallback: function(receipt) {
      if (receipt && (receipt.signatureRequired || _posSettings.tyro_merchant_copy)) {
        _posTyroPrintMerchantReceipt(receipt.merchantReceipt || '', receipt.signatureRequired);
      }
    },
  };

  // IClientWithUI manages its own overlay — do not show a competing modal
  sessionStorage.setItem('tyro_tx_pending', '1');
  try {
    client.initiatePurchase(
      { amount: amountStr, cashout: "0", integratedReceipt: !!_posSettings.tyro_integrated_receipt,
        enableSurcharge: !!_posSettings.tyro_integrated_surcharge },
      splitCallbacks
    );
  } catch(e) {
    sessionStorage.removeItem('tyro_tx_pending');
    toast('Tyro error: ' + (e.message || e), 'err');
  }
}

async function _posTyroPair() {
  // Reset the iClient instance so pairing always starts clean. If the previous
  // instance was put into a bad state (e.g. continueLastTransaction on a
  // non-existent transaction), a stale instance would cause the pairing request
  // to fail with 404. We keep _posTyroScriptReady so the script isn't re-fetched.
  // Also clear any pending-transaction flag — re-pairing abandons any prior transaction.
  sessionStorage.removeItem('tyro_tx_pending');
  _posTyroClient = null;
  // The configuration page communicates with the iClient instance on the parent page via
  // postMessage — the iClient must be loaded and instantiated before the iframe opens.
  try {
    await _posGetTyroClient();
  } catch(e) {
    toast('Failed to load Tyro iClient: ' + e.message, 'err');
    return;
  }
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-tyro-pair-bd';
  bd.innerHTML = `<div class="modal-box" style="max-width:700px;width:90vw;height:80vh;display:flex;flex-direction:column">
    <div class="modal-hdr">
      <span>Pair Tyro Terminal</span>
      <button class="modal-close" onclick="document.getElementById('pos-tyro-pair-bd').remove()">✕</button>
    </div>
    <div style="flex:1">
      <iframe src="${_posTyroConfigUrl()}" style="width:100%;height:100%;border:none;border-radius:0 0 8px 8px"></iframe>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

function _posTyroSettle(btn) {
  // Certification requires user confirmation before initiating settlement
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-tyro-settle-confirm-bd';
  bd.innerHTML = `<div class="modal-box" style="max-width:380px">
    <div class="modal-hdr">Tyro Manual Settlement</div>
    <div class="modal-body" style="padding:16px;font-size:14px">
      <p style="margin:0 0 10px">This will close the current settlement period on the Tyro terminal and begin a new one.</p>
      <p style="margin:0;color:var(--ink2);font-size:13px">Only proceed if you intend to finalise today's transactions. This action cannot be undone.</p>
    </div>
    <div class="modal-foot">
      <button class="btn btn-sec" onclick="document.getElementById('pos-tyro-settle-confirm-bd').remove()">Cancel</button>
      <button class="btn btn-primary" onclick="_posTyroDoSettle(this)">Settle Terminal</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

async function _posTyroDoSettle(btn) {
  document.getElementById('pos-tyro-settle-confirm-bd')?.remove();
  if (btn) { btn.disabled = true; btn.textContent = 'Settling…'; }
  try {
    const client = await _posGetTyroClient();
    // result: 'success'|'failure'; message; currentTerminalBusinessDay (dd/MM/yyyy) on success
    client.manualSettlement((response) => {
      if ((response.result || '').toLowerCase() === 'success') {
        const day = response.currentTerminalBusinessDay ? ' — ' + response.currentTerminalBusinessDay : '';
        const msg = response.message ? ' (' + response.message + ')' : '';
        toast('Terminal settled' + day + msg);
      } else {
        toast('Settlement failed — ' + (response.message || 'check terminal'), 'err');
      }
    });
  } catch(e) {
    toast(e.message, 'err');
  }
}

function _posTyroShowLogs() {
  // Tyro iClient logs are accessed by embedding the logs URL in an iframe — no JS method call
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-tyro-logs-bd';
  bd.innerHTML = `<div class="modal-box" style="max-width:800px;width:90vw;height:80vh;display:flex;flex-direction:column">
    <div class="modal-hdr">
      <span>Tyro iClient Logs</span>
      <button class="modal-close" onclick="document.getElementById('pos-tyro-logs-bd').remove()">✕</button>
    </div>
    <div style="flex:1;padding:0">
      <iframe src="${_posTyroLogsUrl()}" style="width:100%;height:100%;border:none;border-radius:0 0 8px 8px"></iframe>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

function _posTyroPrintMerchantReceipt(text, signatureRequired) {
  if (!text) return;
  // Send to thermal printer if enabled
  if (_posSettings.printer_enabled) {
    fetch('/api/pos/print-raw', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ text }),
    }).catch(() => {});
    if (!signatureRequired) return; // no modal needed for non-signature prints
  }
  // For signature-required: always show modal so operator can collect signature
  if (signatureRequired) {
    const bd = document.createElement('div');
    bd.className = 'modal-bd';
    bd.style.display = 'flex';
    bd.innerHTML = `<div class="modal-box" style="max-width:380px">
      <div class="modal-hdr">Merchant Receipt — Signature Required</div>
      <div class="modal-body" style="padding:16px">
        <pre style="font-family:monospace;font-size:12px;white-space:pre-wrap;margin:0">${_esc(text)}</pre>
      </div>
      <div class="modal-foot">
        <button class="btn btn-primary" onclick="this.closest('.modal-bd').remove()">Done — Signed</button>
      </div>
    </div>`;
    document.body.appendChild(bd);
  }
}

function _posTyroPrintRawReceipt(text) {
  // Print customer receipt for declined/cancelled/reversed transactions (thermal only)
  if (!text || !_posSettings.printer_enabled) return;
  fetch('/api/pos/print-raw', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ text }),
  }).catch(() => {});
}
