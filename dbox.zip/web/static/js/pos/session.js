// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// POS — Session / Z-Report / PIN sign-on / till balance / banking
// Also: sales history, session history, summary report, analytics modal
// Depends on globals in pos.js: _posSession, _posLastFloat, _posSettings,
// _posPendingReport, _posHistorySales, _posPinUserId, _posPinUserName,
// _posAnActiveTab, _posAnData, _posAnStaffData
'use strict';


// ═══════════════════════════════════════════════════════════════════════════
// SESSION BAR
// ═══════════════════════════════════════════════════════════════════════════

function _posRenderSessionBar() {
  const bar = document.getElementById('pos-session-bar');
  if (!bar) return;
  if (_posSession) {
    const t = (_posSession.opened_at || '').slice(0, 16).replace('T', ' ');
    const opHtml = (_posSession.opened_by_name)
      ? ` &mdash; <span class="pos-session-operator">&#x1F464; ${_esc(_posSession.opened_by_name)}</span>`
      : '';
    bar.className = 'pos-session-bar pos-session-open';
    bar.innerHTML = `<span class="pos-session-dot"></span>Session #${_posSession.id} — opened ${t}${opHtml}`;
  } else {
    bar.className = 'pos-session-bar pos-session-closed';
    bar.innerHTML = `No session — <button class="pos-session-link" onclick="_posOpenZReport()">open register</button>`;
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// Z-REPORT / END OF DAY
// ═══════════════════════════════════════════════════════════════════════════

async function _posOpenZReport() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-zrpt-bd';
  bd.innerHTML = `<div class="modal-box pos-zrpt-modal">
    <div class="modal-hdr" id="pos-zrpt-hdr">Z-Report</div>
    <div class="modal-body" id="pos-zrpt-body"><div class="state-loading">Loading…</div></div>
    <div class="modal-foot" id="pos-zrpt-foot">
      <button class="btn" onclick="document.getElementById('pos-zrpt-bd').remove()">Close</button>
    </div>
  </div>`;
  document.body.appendChild(bd);

  if (!_posSession) {
    _posRenderZNoSession(_posLastFloat);
    return;
  }
  try {
    const report = await apiFetch(`/api/pos/session/${_posSession.id}/report`);
    _posRenderZReport(report, false);
  } catch(e) {
    document.getElementById('pos-zrpt-body').innerHTML = `<div class="state-error">${_esc(e.message)}</div>`;
  }
}

function _posRenderZNoSession(lastFloat = 0) {
  const hint = lastFloat > 0
    ? `Previous closing float: $${parseFloat(lastFloat).toFixed(2)}`
    : 'Enter the opening float (cash in the drawer to start the day).';
  document.getElementById('pos-zrpt-body').innerHTML = `
    <div class="pos-zrpt-nosess">
      <div class="pos-zrpt-nosess-icon">&#x1F513;</div>
      <div class="pos-zrpt-nosess-msg">No register session open</div>
      <div class="pos-zrpt-nosess-sub">${_esc(hint)}</div>
      <div class="pos-till-field">
        <label class="pos-till-lbl">Opening Float</label>
        <div class="pos-till-input-wrap">
          <span class="pos-till-dollar">$</span>
          <input type="number" id="pos-open-float" class="pos-till-inp" min="0" step="0.01"
                 value="${parseFloat(lastFloat).toFixed(2)}" placeholder="0.00">
        </div>
      </div>
      <div class="pos-till-field">
        <label class="pos-till-lbl" style="font-weight:400;text-transform:none">Session note (optional)</label>
        <input class="pos-sett-inp" id="pos-open-note" type="text"
               placeholder="e.g. Morning shift, Jane" maxlength="100" autocomplete="off">
      </div>
    </div>`;
  document.getElementById('pos-zrpt-foot').innerHTML = `
    <button class="btn" onclick="document.getElementById('pos-zrpt-bd').remove()">Cancel</button>
    <button class="btn btn-primary" onclick="_posSignOnThenOpen()">Open Register</button>`;
}

function _posRenderZReport(report, isClosed, readOnly = false) {
  const fmt    = n  => '$' + parseFloat(n || 0).toFixed(2);
  const fmtD   = s  => s ? s.slice(0, 16) : '—';
  const round2 = n  => Math.round((n || 0) * 100) / 100;
  document.getElementById('pos-zrpt-hdr').textContent = isClosed ? 'Day Report' : 'End of Day';
  document.getElementById('pos-zrpt-body').innerHTML = `
    <div class="pos-zrpt-content">
      <div class="pos-zrpt-title">${isClosed ? 'DAY REPORT' : 'CURRENT TOTALS'}</div>
      <div class="pos-zrpt-meta">
        <div>Session #${report.session_id}</div>
        <div>Opened: ${fmtD(report.opened_at)}</div>
        ${report.closed_at ? `<div>Closed: ${fmtD(report.closed_at)}</div>` : ''}
      </div>
      <div class="pos-zrpt-sep"></div>
      <div class="pos-zrpt-row">
        <span>Cash</span>
        <span>${report.cash.count} txn${report.cash.count !== 1 ? 's' : ''}</span>
        <span>${fmt(report.cash.total)}</span>
      </div>
      <div class="pos-zrpt-row">
        <span>Card / EFTPOS</span>
        <span>${report.card.count} txn${report.card.count !== 1 ? 's' : ''}</span>
        <span>${fmt(report.card.total)}</span>
      </div>
      ${(report.split && report.split.count > 0) ? `
      <div class="pos-zrpt-row">
        <span>Split (Cash $${fmt(report.split.cash)} / Card $${fmt(report.split.card)})</span>
        <span>${report.split.count} txn${report.split.count !== 1 ? 's' : ''}</span>
        <span>${fmt(report.split.total)}</span>
      </div>` : ''}
      ${(report.account && report.account.count > 0) ? `
      <div class="pos-zrpt-row" style="color:var(--amber)">
        <span>On Account <span style="font-size:10px;opacity:.7">(AR — not collected)</span></span>
        <span>${report.account.count} txn${report.account.count !== 1 ? 's' : ''}</span>
        <span>${fmt(report.account.total)}</span>
      </div>` : ''}
      <div class="pos-zrpt-sep"></div>
      <div class="pos-zrpt-row pos-zrpt-row-total">
        <span>TOTAL SALES</span>
        <span>${report.tx_count} txn${report.tx_count !== 1 ? 's' : ''}</span>
        <span>${fmt(report.total)}</span>
      </div>
      <div class="pos-zrpt-sep"></div>
      <div class="pos-zrpt-row pos-zrpt-row-gst">
        <span>GST (included)</span><span></span><span>${fmt(report.gst)}</span>
      </div>
      <div class="pos-zrpt-row pos-zrpt-row-gst">
        <span>Ex-GST</span><span></span><span>${fmt(report.ex_gst)}</span>
      </div>
    </div>`;
  // banking report (shown on closed report)
  if (isClosed) {
    const variance     = report.variance || 0;
    const varClass     = variance > 0 ? 'pos-till-over' : variance < 0 ? 'pos-till-short' : '';
    const varLabel     = variance > 0 ? 'Over' : variance < 0 ? 'Short' : 'Balanced';
    const expected     = (report.opening_float || 0) + (report.cash_drawer_total != null ? report.cash_drawer_total : report.cash.total || 0);
    const totalBanking = round2((report.banked || 0) + (report.card.total || 0) + ((report.split && report.split.card) || 0));
    const hasCounted   = report.cash_counted !== null && report.cash_counted !== undefined;
    document.getElementById('pos-zrpt-body').innerHTML += `
      <div class="pos-zrpt-sep"></div>
      <div class="pos-zrpt-title" style="font-size:11px;margin-top:4px">BANKING REPORT</div>

      <div class="pos-zrpt-subtitle">Cash</div>
      <div class="pos-zrpt-row"><span>Opening Float</span><span></span><span>${fmt(report.opening_float)}</span></div>
      <div class="pos-zrpt-row"><span>Cash Sales</span><span></span><span>${fmt(report.cash.total)}</span></div>
      <div class="pos-zrpt-row pos-zrpt-row-sub"><span>Expected in Drawer</span><span></span><span>${fmt(expected)}</span></div>
      ${hasCounted ? `
      <div class="pos-zrpt-row"><span>Actual Counted</span><span></span><span>${fmt(report.cash_counted)}</span></div>
      <div class="pos-zrpt-row ${varClass}"><span>Variance</span><span>${varLabel}</span><span>${fmt(Math.abs(variance))}</span></div>` : ''}
      <div class="pos-zrpt-sep-thin"></div>
      <div class="pos-zrpt-row"><span>Cash Deposited</span><span></span><span>${fmt(report.banked)}</span></div>
      <div class="pos-zrpt-row"><span>Float Retained</span><span></span><span>${fmt(report.float_kept)}</span></div>

      <div class="pos-zrpt-subtitle" style="margin-top:8px">Card / EFTPOS</div>
      <div class="pos-zrpt-row">
        <span>Card Transactions</span>
        <span>${report.card.count} txn${report.card.count !== 1 ? 's' : ''}</span>
        <span>${fmt(report.card.total)}</span>
      </div>
      <div class="pos-zrpt-note">Settled directly to merchant account</div>

      <div class="pos-zrpt-sep"></div>
      <div class="pos-zrpt-row pos-zrpt-row-total"><span>TOTAL BANKING</span><span></span><span>${fmt(totalBanking)}</span></div>`;
  }
  const foot = document.getElementById('pos-zrpt-foot');
  if (isClosed || readOnly) {
    foot.innerHTML = `
      <button class="btn" onclick="window.print()">Print</button>
      <button class="btn btn-primary" onclick="document.getElementById('pos-zrpt-bd').remove()">Done</button>`;
  } else {
    _posPendingReport = report;
    foot.innerHTML = `
      <button class="btn" onclick="document.getElementById('pos-zrpt-bd').remove()">Cancel</button>
      <button class="btn btn-sec" onclick="_posQuickCloseSession(${report.session_id})">Staff Change</button>
      <button class="btn btn-danger" id="pos-zrpt-close-btn"
              onclick="_posTillBalanceStep(_posPendingReport)">End of Day →</button>`;
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// PIN SIGN-ON
// ═══════════════════════════════════════════════════════════════════════════

async function _posSignOnThenOpen() {
  // If any users have PINs configured, require sign-on before opening
  let posUsers = [];
  try { posUsers = await apiFetch('/api/pos/users'); } catch(_) {}
  const pinUsers = posUsers.filter(u => u.has_pin);
  if (!pinUsers.length) {
    // No PINs configured — open directly
    _posPinUserId = null; _posPinUserName = null;
    await _posDoOpenSession();
    return;
  }
  _posShowPinModal(pinUsers, () => _posDoOpenSession());
}

function _posShowPinModal(pinUsers, onSuccess) {
  document.getElementById('pos-pin-bd')?.remove();
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-pin-bd';
  bd.innerHTML = `<div class="modal-box pos-pin-modal">
    <div class="modal-hdr">
      <span>Sign On to Register</span>
      <button class="modal-close" onclick="document.getElementById('pos-pin-bd').remove()">✕</button>
    </div>
    <div class="modal-body pos-pin-body">
      <div class="pos-pin-users" id="pos-pin-users">
        ${pinUsers.map(u => `
          <button class="pos-pin-user-btn" onclick="_posSelectPinUser(${u.id},'${_esc(u.display_name)}')">
            <span class="pos-pin-avatar">${_esc(u.display_name[0] || '?').toUpperCase()}</span>
            <span>${_esc(u.display_name)}</span>
          </button>`).join('')}
      </div>
      <div id="pos-pin-entry" class="pos-pin-entry" style="display:none">
        <div class="pos-pin-entry-name" id="pos-pin-entry-name"></div>
        <div class="pos-pin-dots" id="pos-pin-dots">
          <span></span><span></span><span></span><span></span><span></span><span></span>
        </div>
        <div class="pos-pin-pad">
          ${[1,2,3,4,5,6,7,8,9,'C',0,'⌫'].map(k =>
            `<button class="pos-pin-key${k==='C'||k==='⌫'?' pos-pin-key-fn':''}"
                     onclick="_posPinKey('${k}')">${k}</button>`
          ).join('')}
        </div>
        <button class="btn btn-sec btn-sm" onclick="_posPinBack()">← Change user</button>
      </div>
    </div>
  </div>`;
  document.body.appendChild(bd);
  bd._onSuccess = onSuccess;

  // Keyboard handler — active while this modal is open
  function _pinKeydown(e) {
    if (!document.getElementById('pos-pin-bd')) {
      document.removeEventListener('keydown', _pinKeydown);
      return;
    }
    if (e.key >= '0' && e.key <= '9') {
      // Only forward digits once a user is selected
      if (_posPinSelectedId !== null) { e.preventDefault(); _posPinKey(e.key); }
    } else if (e.key === 'Backspace') {
      e.preventDefault(); _posPinKey('⌫');
    } else if (e.key === 'Delete') {
      e.preventDefault(); _posPinKey('C');
    } else if (e.key === 'Escape') {
      e.preventDefault();
      if (_posPinSelectedId !== null) _posPinBack();
      else document.getElementById('pos-pin-bd')?.remove();
    }
  }
  document.addEventListener('keydown', _pinKeydown);
  // Clean up when the backdrop is removed
  new MutationObserver((_, obs) => {
    if (!document.getElementById('pos-pin-bd')) {
      document.removeEventListener('keydown', _pinKeydown);
      obs.disconnect();
    }
  }).observe(document.body, { childList: true });
}

var _posPinBuffer = '';
var _posPinSelectedId = null;

function _posSelectPinUser(userId, name) {
  _posPinSelectedId = userId;
  _posPinBuffer = '';
  document.getElementById('pos-pin-users').style.display = 'none';
  const entry = document.getElementById('pos-pin-entry');
  entry.style.display = '';
  document.getElementById('pos-pin-entry-name').textContent = name;
  _posUpdatePinDots();
}

function _posPinBack() {
  _posPinBuffer = ''; _posPinSelectedId = null;
  document.getElementById('pos-pin-users').style.display = '';
  document.getElementById('pos-pin-entry').style.display = 'none';
}

function _posUpdatePinDots() {
  const dots = document.querySelectorAll('#pos-pin-dots span');
  dots.forEach((d, i) => {
    d.className = i < _posPinBuffer.length ? 'pos-pin-dot filled' : 'pos-pin-dot';
  });
}

async function _posPinKey(key) {
  if (key === '⌫') {
    _posPinBuffer = _posPinBuffer.slice(0, -1);
    _posUpdatePinDots();
    return;
  }
  if (key === 'C') {
    _posPinBuffer = '';
    _posUpdatePinDots();
    return;
  }
  if (_posPinBuffer.length >= 6) return;
  _posPinBuffer += String(key);
  _posUpdatePinDots();
  if (_posPinBuffer.length >= 4) {
    // try verify after each digit once 4+ entered
    await _posPinVerify();
  }
}

async function _posPinVerify() {
  try {
    const r = await fetch('/api/pos/auth', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ pin: _posPinBuffer }),
    }).then(r => r.json());
    if (r.ok && r.data) {
      // Verify the matched user is the selected one
      if (r.data.id !== _posPinSelectedId) {
        // Wrong user's PIN — shake and clear
        _posPinWrongEntry();
        return;
      }
      _posPinUserId   = r.data.id;
      _posPinUserName = r.data.display_name;
      const bd = document.getElementById('pos-pin-bd');
      const cb = bd?._onSuccess;
      bd?.remove();
      if (cb) await cb();
    } else if (_posPinBuffer.length >= 6) {
      _posPinWrongEntry();
    }
  } catch(_) {}
}

function _posPinWrongEntry() {
  const entry = document.getElementById('pos-pin-entry');
  if (entry) { entry.classList.add('pos-pin-shake'); setTimeout(() => entry.classList.remove('pos-pin-shake'), 400); }
  _posPinBuffer = '';
  _posUpdatePinDots();
  toast('Incorrect PIN', 'err');
}

async function _posDoOpenSession() {
  const btn = document.querySelector('#pos-zrpt-foot .btn-primary');
  if (btn) { btn.disabled = true; btn.textContent = 'Opening…'; }
  const floatVal = parseFloat(document.getElementById('pos-open-float')?.value || 0) || 0;
  const noteVal  = (document.getElementById('pos-open-note')?.value || '').trim();
  try {
    const r = await fetch('/api/pos/session', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        opening_float: floatVal,
        note: noteVal,
        opened_by_user_id: _posPinUserId,
        opened_by_name: _posPinUserName,
      }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Failed to open session');
    _posSession = r.data;
    document.getElementById('pos-zrpt-bd')?.remove();
    _posRenderSessionBar();
    const who = _posPinUserName ? ` — ${_posPinUserName}` : '';
    toast(`Register open — Session #${_posSession.id}${who}`);
  } catch(e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Open Register'; }
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// TILL BALANCE + BANKING STEPS
// ═══════════════════════════════════════════════════════════════════════════

const _POS_DENOMS = [
  { label: '$100', value: 100 },
  { label: '$50',  value: 50  },
  { label: '$20',  value: 20  },
  { label: '$10',  value: 10  },
  { label: '$5',   value: 5   },
  { label: '$2',   value: 2   },
  { label: '$1',   value: 1   },
  { label: '50c',  value: 0.5 },
  { label: '20c',  value: 0.2 },
  { label: '10c',  value: 0.1 },
  { label: '5c',   value: 0.05},
];

function _posTillBalanceStep(report) {
  _posPendingReport = report;
  const expected = ((report.opening_float || 0) + (report.cash_drawer_total != null ? report.cash_drawer_total : report.cash.total || 0)).toFixed(2);
  document.getElementById('pos-zrpt-hdr').textContent = 'Balance Till';
  document.getElementById('pos-zrpt-body').innerHTML = `
    <div class="pos-till-step">
      <div class="pos-till-row"><span>Opening Float</span><span>$${parseFloat(report.opening_float||0).toFixed(2)}</span></div>
      <div class="pos-till-row"><span>Cash Sales</span><span>$${parseFloat(report.cash.total||0).toFixed(2)}</span></div>
      <div class="pos-till-row pos-till-expected"><span>Expected in Drawer</span><span>$${expected}</span></div>
      <div class="pos-till-sep"></div>
      <div class="pos-till-field">
        <label class="pos-till-lbl">Actual Cash Counted</label>
        <div class="pos-till-input-wrap">
          <span class="pos-till-dollar">$</span>
          <input type="number" id="pos-till-counted" class="pos-till-inp" min="0" step="0.01"
                 placeholder="0.00" oninput="_posTillVarianceUpdate(${expected})">
        </div>
      </div>
      <div id="pos-till-variance" class="pos-till-variance"></div>
      <button class="pos-till-denom-toggle" id="pos-denom-toggle"
              onclick="_posDenomToggle(${expected})">Count by denomination ▾</button>
      <div id="pos-denom-grid" style="display:none">
        <div class="pos-denom-grid">
          ${_POS_DENOMS.map(d => `
            <div class="pos-denom-row">
              <span class="pos-denom-lbl">${d.label}</span>
              <span class="pos-denom-x">×</span>
              <input type="number" class="pos-denom-inp" min="0" step="1" value=""
                     placeholder="0" data-val="${d.value}"
                     oninput="_posDenomCalc(${expected})">
              <span class="pos-denom-sub" id="pos-denom-sub-${d.value.toString().replace('.','_')}"></span>
            </div>`).join('')}
        </div>
        <div class="pos-denom-total-row">
          <span>Denomination Total</span>
          <span id="pos-denom-total">$0.00</span>
        </div>
      </div>
    </div>`;
  document.getElementById('pos-zrpt-foot').innerHTML = `
    <button class="btn" onclick="document.getElementById('pos-zrpt-bd')?.remove();_posOpenZReport()">← Back</button>
    <button class="btn btn-primary" onclick="_posBankingStep(_posPendingReport)">Next: Banking →</button>`;
}

function _posDenomToggle(expected) {
  const grid = document.getElementById('pos-denom-grid');
  const btn  = document.getElementById('pos-denom-toggle');
  if (!grid) return;
  const open = grid.style.display === 'none';
  grid.style.display = open ? '' : 'none';
  btn.textContent = open ? 'Count by denomination ▴' : 'Count by denomination ▾';
  if (open) setTimeout(() => grid.querySelector('.pos-denom-inp')?.focus(), 50);
}

function _posDenomCalc(expected) {
  let total = 0;
  document.querySelectorAll('.pos-denom-inp').forEach(inp => {
    const qty = parseInt(inp.value || 0) || 0;
    const val = parseFloat(inp.dataset.val);
    const sub = qty * val;
    total += sub;
    const key = inp.dataset.val.replace('.', '_');
    const el  = document.getElementById(`pos-denom-sub-${key}`);
    if (el) el.textContent = sub > 0 ? `$${sub.toFixed(2)}` : '';
  });
  total = Math.round(total * 100) / 100;
  const totalEl = document.getElementById('pos-denom-total');
  if (totalEl) totalEl.textContent = `$${total.toFixed(2)}`;
  const countedEl = document.getElementById('pos-till-counted');
  if (countedEl) { countedEl.value = total.toFixed(2); _posTillVarianceUpdate(expected); }
}

function _posTillVarianceUpdate(expected) {
  const counted = parseFloat(document.getElementById('pos-till-counted')?.value || 0) || 0;
  const variance = counted - parseFloat(expected);
  const el = document.getElementById('pos-till-variance');
  if (!el) return;
  if (variance === 0) {
    el.innerHTML = '<span class="pos-till-balanced">✓ Balanced</span>';
  } else if (variance > 0) {
    el.innerHTML = `<span class="pos-till-over">Over by $${variance.toFixed(2)}</span>`;
  } else {
    el.innerHTML = `<span class="pos-till-short">Short by $${Math.abs(variance).toFixed(2)}</span>`;
  }
}

function _posBankingStep(report) {
  _posPendingReport = report;
  const counted = parseFloat(document.getElementById('pos-till-counted')?.value || 0) || 0;
  const bankingAcct = _posSettings?.banking_account_id || null;
  document.getElementById('pos-zrpt-hdr').textContent = 'Banking';
  document.getElementById('pos-zrpt-body').innerHTML = `
    <div class="pos-till-step">
      <div class="pos-till-row"><span>Cash in Drawer</span><span>$${counted.toFixed(2)}</span></div>
      <div class="pos-till-sep"></div>
      <div class="pos-till-field">
        <label class="pos-till-lbl">Amount to Bank</label>
        <div class="pos-till-input-wrap">
          <span class="pos-till-dollar">$</span>
          <input type="number" id="pos-bank-amount" class="pos-till-inp" min="0" step="0.01"
                 value="${counted.toFixed(2)}" oninput="_posBankingUpdate(${counted.toFixed(2)})">
        </div>
      </div>
      <div class="pos-till-field">
        <label class="pos-till-lbl">Float to Keep</label>
        <div class="pos-till-input-wrap">
          <span class="pos-till-dollar">$</span>
          <input type="number" id="pos-float-keep" class="pos-till-inp" min="0" step="0.01"
                 value="0.00" oninput="_posFloatChange(${counted.toFixed(2)})">
        </div>
      </div>
      ${bankingAcct ? '' : '<div class="pos-till-warn">⚠ No banking account set — journal entry will be skipped. Set one in POS Settings.</div>'}
      ${(_posSettings?.provider === 'linkly' || _posSettings?.provider === 'tyro') ? `
      <div class="pos-till-field" style="margin-top:12px">
        <label style="display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer">
          <input type="checkbox" id="pos-settle-toggle" checked>
          Settle ${_posSettings?.provider === 'tyro' ? 'Tyro ' : ''}terminal after close
        </label>
      </div>` : ''}
    </div>`;
  document.getElementById('pos-zrpt-foot').innerHTML = `
    <button class="btn" onclick="_posTillBalanceStep(_posPendingReport)">← Back</button>
    <button class="btn btn-danger" id="pos-zrpt-close-btn"
            onclick="_posDoCloseSession(_posPendingReport.session_id)">Confirm &amp; Close Register</button>`;
  _posBankingUpdate(counted);
}

function _posBankingUpdate(counted) {
  const banked = parseFloat(document.getElementById('pos-bank-amount')?.value || 0) || 0;
  const floatEl = document.getElementById('pos-float-keep');
  if (floatEl) floatEl.value = Math.max(0, counted - banked).toFixed(2);
}

function _posFloatChange(counted) {
  const float  = parseFloat(document.getElementById('pos-float-keep')?.value || 0) || 0;
  const bankEl = document.getElementById('pos-bank-amount');
  if (bankEl) bankEl.value = Math.max(0, parseFloat(counted) - float).toFixed(2);
}

async function _posDoCloseSession(sessionId) {
  const btn = document.getElementById('pos-zrpt-close-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Closing…'; }
  const shouldSettle = document.getElementById('pos-settle-toggle')?.checked ?? false;
  const countedRaw = document.getElementById('pos-till-counted')?.value;
  const cashCounted = countedRaw !== '' && countedRaw != null ? parseFloat(countedRaw) : null;
  const banked    = parseFloat(document.getElementById('pos-bank-amount')?.value || 0) || 0;
  const floatKept = parseFloat(document.getElementById('pos-float-keep')?.value  || 0) || 0;
  try {
    const r = await fetch(`/api/pos/session/${sessionId}/close`, {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        cash_counted:       cashCounted ?? null,
        banked:             banked,
        float_kept:         floatKept,
        banking_account_id: _posSettings?.banking_account_id || null,
      }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Failed to close session');
    _posSession = null;
    _posLastFloat = floatKept;
    _posRenderSessionBar();
    _posRenderZReport(r.data, true);
    if (shouldSettle) {
      const foot = document.getElementById('pos-zrpt-foot');
      if (foot) {
        const settleBtn = document.createElement('button');
        settleBtn.className = 'btn btn-primary';
        settleBtn.style.cssText = 'margin-right:auto';
        const isTyro = _posSettings?.provider === 'tyro';
        settleBtn.textContent = 'Settling terminal…';
        settleBtn.disabled = true;
        foot.prepend(settleBtn);
        try {
          if (isTyro) {
            const client = await _posGetTyroClient();
            await new Promise((resolve) => {
              client.manualSettlement((response) => {
                if ((response.result || '').toLowerCase() === 'success') {
                  settleBtn.textContent = '✓ Terminal settled';
                  settleBtn.className = 'btn';
                } else {
                  settleBtn.textContent = 'Settlement failed — retry in Settings';
                  settleBtn.className = 'btn btn-sec';
                  settleBtn.disabled = false;
                }
                resolve();
              });
            });
          } else {
            const sr = await fetch('/api/pos/terminal/settle', {method: 'POST'}).then(x => x.json());
            if (sr.ok && sr.data?.success) {
              settleBtn.textContent = '✓ Terminal settled';
              settleBtn.className = 'btn';
            } else {
              settleBtn.textContent = 'Settlement failed — retry in Settings';
              settleBtn.className = 'btn btn-sec';
              settleBtn.disabled = false;
            }
          }
        } catch(_) {
          settleBtn.textContent = 'Settlement failed — retry in Settings';
          settleBtn.className = 'btn btn-sec';
          settleBtn.disabled = false;
        }
      }
    }
  } catch(e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Confirm & Close Register'; }
  }
}

async function _posQuickCloseSession(sessionId) {
  const bd = document.getElementById('pos-zrpt-bd');
  const btn = bd?.querySelector('.btn-sec');
  if (btn) { btn.disabled = true; btn.textContent = 'Closing…'; }
  try {
    const r = await fetch(`/api/pos/session/${sessionId}/close`, {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ cash_counted: null, banked: 0, float_kept: 0, banking_account_id: null }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Failed to close session');
    _posSession = null;
    _posRenderSessionBar();
    document.getElementById('pos-zrpt-hdr').textContent = 'Open Register';
    _posRenderZNoSession(_posLastFloat);
  } catch(e) {
    toast(e.message, 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Staff Change'; }
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// SALES HISTORY
// ═══════════════════════════════════════════════════════════════════════════

async function _posOpenHistory() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-hist-bd';
  bd.innerHTML = `<div class="modal-box pos-hist-modal" style="display:flex;flex-direction:column;max-height:90vh">
    <div class="modal-hdr">
      <span>Sales History</span>
      <button class="modal-close" onclick="document.getElementById('pos-hist-bd').remove()">✕</button>
    </div>
    <div id="pos-hist-filters-area"></div>
    <div class="modal-body" id="pos-hist-body" style="overflow-y:auto;flex:1;padding:0">
      <div class="state-loading" style="padding:24px">Loading…</div>
    </div>
  </div>`;
  document.body.appendChild(bd);
  try {
    _posHistorySales = await apiFetch('/api/pos/sales?limit=200');
    _posRenderHistory();
  } catch(e) {
    document.getElementById('pos-hist-body').innerHTML =
      `<div class="state-error" style="padding:24px">${_esc(e.message)}</div>`;
  }
}

function _posRenderHistory() {
  const filtersEl = document.getElementById('pos-hist-filters-area');
  if (filtersEl) {
    filtersEl.innerHTML = `
      <div class="pos-hist-filters">
        <input type="date" class="pos-hist-filter-inp pos-hist-date-inp" id="pos-hist-from"
               oninput="_posHistoryFilter()" title="From date">
        <span class="pos-hist-sep">–</span>
        <input type="date" class="pos-hist-filter-inp pos-hist-date-inp" id="pos-hist-to"
               oninput="_posHistoryFilter()" title="To date">
        <input type="text" class="pos-hist-filter-inp pos-hist-text-inp" id="pos-hist-contact"
               oninput="_posHistoryFilter()" placeholder="Customer…" autocomplete="off">
        <select class="pos-hist-filter-inp" id="pos-hist-tender" onchange="_posHistoryFilter()">
          <option value="">All tender</option>
          <option value="cash">Cash</option>
          <option value="card">Card</option>
          <option value="account">Account</option>
        </select>
        <input type="number" class="pos-hist-filter-inp pos-hist-amt-inp" id="pos-hist-min"
               oninput="_posHistoryFilter()" placeholder="Min $" min="0" step="0.01">
        <input type="number" class="pos-hist-filter-inp pos-hist-amt-inp" id="pos-hist-max"
               oninput="_posHistoryFilter()" placeholder="Max $" min="0" step="0.01">
        <button class="btn btn-sm btn-sec" onclick="_posHistoryClear()">Clear</button>
      </div>`;
  }
  _posHistoryFilter();
}

function _posHistoryFilter() {
  const from    = document.getElementById('pos-hist-from')?.value    || '';
  const to      = document.getElementById('pos-hist-to')?.value      || '';
  const contact = (document.getElementById('pos-hist-contact')?.value || '').toLowerCase().trim();
  const tender  = document.getElementById('pos-hist-tender')?.value  || '';
  const minAmt  = parseFloat(document.getElementById('pos-hist-min')?.value || '') || null;
  const maxAmt  = parseFloat(document.getElementById('pos-hist-max')?.value || '') || null;

  let filtered = _posHistorySales;
  if (from)            filtered = filtered.filter(s => s.invoice_date >= from);
  if (to)              filtered = filtered.filter(s => s.invoice_date <= to);
  if (contact)         filtered = filtered.filter(s => (s.contact_name || '').toLowerCase().includes(contact));
  if (tender)          filtered = filtered.filter(s => s.tender === tender);
  if (minAmt !== null) filtered = filtered.filter(s => parseFloat(s.total) >= minAmt);
  if (maxAmt !== null) filtered = filtered.filter(s => parseFloat(s.total) <= maxAmt);

  _posRenderHistoryTable(filtered);
}

function _posHistoryClear() {
  ['pos-hist-from','pos-hist-to','pos-hist-contact','pos-hist-min','pos-hist-max'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  const sel = document.getElementById('pos-hist-tender');
  if (sel) sel.value = '';
  _posHistoryFilter();
}

function _posRenderHistoryTable(sales) {
  const el = document.getElementById('pos-hist-body');
  if (!el) return;
  const total    = _posHistorySales.length;
  const shown    = sales.length;
  const sumTotal = sales.reduce((s, r) => s + parseFloat(r.total || 0), 0);
  const countHtml = `<div class="pos-hist-count">
    ${shown === total ? `${total} sale${total !== 1 ? 's' : ''}` : `${shown} of ${total} sales`}
    &nbsp;·&nbsp; Total: <strong>$${sumTotal.toFixed(2)}</strong>
  </div>`;

  if (!sales.length) {
    el.innerHTML = countHtml + '<div class="pos-empty" style="padding:24px">No sales match the filters</div>';
    return;
  }
  el.innerHTML = countHtml + `<div class="tbl-overflow-x">
    <table class="inv-list-table">
      <thead><tr>
        <th>Invoice</th><th>Date</th><th>Customer</th><th>Tender</th>
        <th style="text-align:right">Total</th><th></th>
      </tr></thead>
      <tbody>
      ${sales.map(s => `
        <tr>
          <td>${_esc(s.invoice_number)}</td>
          <td>${fmtDate(s.invoice_date)}</td>
          <td>${_esc(s.contact_name || 'Walk-In')}</td>
          <td>${s.tender === 'cash' ? 'Cash' : s.tender === 'account' ? 'Account' : 'Card'}</td>
          <td style="text-align:right">$${parseFloat(s.total||0).toFixed(2)}</td>
          <td style="white-space:nowrap">
            <button class="btn btn-sm btn-sec"
                    onclick="_posReprintFromHistory(this,${s.id},'${s.tender||'cash'}',${parseFloat(s.total||0).toFixed(4)})">
              Receipt
            </button>
            <button class="btn btn-sm btn-sec" style="margin-left:4px"
                    onclick="window.open('/api/invoices/${s.id}/pdf','_blank')">
              Invoice
            </button>
            <button class="btn btn-sm btn-danger" style="margin-left:4px"
                    ${s.refunded ? 'disabled title="Already refunded"' : `onclick="_posRefundFromHistory(${s.id},'${_esc(s.tender||'cash')}','${_esc(s.terminal_provider||'')}',${s.tyro_surcharge_cents||0})"`}>
              ${s.refunded ? 'Refunded' : 'Refund'}
            </button>
          </td>
        </tr>`).join('')}
      </tbody>
    </table>
  </div>`;
}

async function _posReprintFromHistory(btn, invoiceId, tender, total) {
  const orig = btn.textContent;
  btn.disabled = true; btn.textContent = 'Printing…';
  try {
    const r = await fetch('/api/pos/print-receipt', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({invoice_id: invoiceId, tender, tendered: total, change: 0}),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Print failed');
    toast('Receipt printed');
  } catch(e) {
    toast(e.message || 'Print failed', 'err');
  }
  btn.disabled = false; btn.textContent = orig;
}


// ═══════════════════════════════════════════════════════════════════════════
// SESSION HISTORY + SUMMARY REPORT
// ═══════════════════════════════════════════════════════════════════════════

async function _posOpenSessionHistory() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-sess-hist-bd';
  bd.innerHTML = `<div class="modal-box pos-hist-modal" style="display:flex;flex-direction:column;max-height:90vh">
    <div class="modal-hdr">
      <span>Session History</span>
      <div style="display:flex;gap:8px;align-items:center">
        <button class="btn btn-sm btn-sec" onclick="_posOpenSummaryReport()">Summary Report</button>
        <button class="modal-close" onclick="document.getElementById('pos-sess-hist-bd').remove()">✕</button>
      </div>
    </div>
    <div class="modal-body" id="pos-sess-hist-body" style="overflow-y:auto;flex:1;padding:0">
      <div class="state-loading" style="padding:24px">Loading…</div>
    </div>
  </div>`;
  document.body.appendChild(bd);
  try {
    const sessions = await apiFetch('/api/pos/sessions');
    _posRenderSessionHistoryList(sessions);
  } catch(e) {
    document.getElementById('pos-sess-hist-body').innerHTML =
      `<div class="state-error" style="padding:24px">${_esc(e.message)}</div>`;
  }
}

function _posRenderSessionHistoryList(sessions) {
  const el = document.getElementById('pos-sess-hist-body');
  if (!el) return;
  if (!sessions.length) {
    el.innerHTML = '<div class="pos-empty" style="padding:32px">No sessions recorded yet</div>';
    return;
  }
  el.innerHTML = `<div class="tbl-overflow-x">
    <table class="inv-list-table">
      <thead><tr>
        <th>Session</th><th>Opened</th><th>Closed</th>
        <th style="text-align:right">Txns</th>
        <th style="text-align:right">Total</th>
        <th></th>
      </tr></thead>
      <tbody>
      ${sessions.map(s => {
        const isOpen  = !s.closed_at;
        const opened  = (s.opened_at || '').slice(0, 16).replace('T', ' ');
        const closed  = s.closed_at ? s.closed_at.slice(0, 16).replace('T', ' ') : '—';
        const noteHtml = s.note ? ` <span style="color:var(--ink3);font-size:11px">${_esc(s.note)}</span>` : '';
        return `<tr>
          <td>#${s.id}${noteHtml}</td>
          <td>${opened}</td>
          <td>${closed}</td>
          <td style="text-align:right">${s.tx_count || 0}</td>
          <td style="text-align:right">$${parseFloat(s.total||0).toFixed(2)}</td>
          <td>
            <button class="btn btn-sm btn-sec" onclick="_posViewSessionReport(${s.id})">
              ${isOpen ? 'X-View' : 'Day Report'}
            </button>
          </td>
        </tr>`;
      }).join('')}
      </tbody>
    </table>
  </div>`;
}

async function _posViewSessionReport(sessionId) {
  document.getElementById('pos-sess-hist-bd')?.remove();
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-zrpt-bd';
  bd.innerHTML = `<div class="modal-box pos-zrpt-modal">
    <div class="modal-hdr" id="pos-zrpt-hdr">Loading…</div>
    <div class="modal-body" id="pos-zrpt-body"><div class="state-loading">Loading…</div></div>
    <div class="modal-foot" id="pos-zrpt-foot">
      <button class="btn" onclick="document.getElementById('pos-zrpt-bd').remove()">Close</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  try {
    const report  = await apiFetch(`/api/pos/session/${sessionId}/report`);
    const isClosed = !!report.closed_at;
    _posRenderZReport(report, isClosed, true);
  } catch(e) {
    document.getElementById('pos-zrpt-body').innerHTML =
      `<div class="state-error">${_esc(e.message)}</div>`;
  }
}

function _posOpenSummaryReport() {
  document.getElementById('pos-sess-hist-bd')?.remove();
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-summary-bd';

  const today = new Date().toISOString().slice(0, 10);
  const weekAgo = new Date(Date.now() - 6 * 86400000).toISOString().slice(0, 10);
  const monthStart = today.slice(0, 8) + '01';

  bd.innerHTML = `<div class="modal-box pos-summary-modal" style="display:flex;flex-direction:column;max-height:90vh">
    <div class="modal-hdr">
      <span>Summary Report</span>
      <button class="modal-close" onclick="document.getElementById('pos-summary-bd').remove()">✕</button>
    </div>
    <div class="modal-body" style="overflow-y:auto;flex:1">
      <div class="pos-summary-presets">
        <button class="btn btn-sm btn-sec" onclick="_posSummaryPreset('${today}','${today}')">Today</button>
        <button class="btn btn-sm btn-sec" onclick="_posSummaryPreset('${weekAgo}','${today}')">Last 7 Days</button>
        <button class="btn btn-sm btn-sec" onclick="_posSummaryPreset('${monthStart}','${today}')">This Month</button>
      </div>
      <div class="pos-summary-range">
        <label class="pos-sett-lbl">From</label>
        <input type="date" class="pos-sett-inp" id="pos-sum-from" value="${weekAgo}" style="width:auto">
        <label class="pos-sett-lbl" style="margin-left:10px">To</label>
        <input type="date" class="pos-sett-inp" id="pos-sum-to" value="${today}" style="width:auto">
        <button class="btn btn-primary" style="margin-left:8px" onclick="_posRunSummaryReport()">Run</button>
      </div>
      <div id="pos-summary-result"></div>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

function _posSummaryPreset(from, to) {
  const f = document.getElementById('pos-sum-from');
  const t = document.getElementById('pos-sum-to');
  if (f) f.value = from;
  if (t) t.value = to;
  _posRunSummaryReport();
}

async function _posRunSummaryReport() {
  const from = document.getElementById('pos-sum-from')?.value;
  const to   = document.getElementById('pos-sum-to')?.value;
  const el   = document.getElementById('pos-summary-result');
  if (!from || !to || !el) return;
  el.innerHTML = '<div class="state-loading" style="padding:16px">Loading…</div>';
  try {
    const r = await apiFetch(`/api/pos/summary-report?from=${from}&to=${to}`);
    _posRenderSummaryReport(r, el);
  } catch(e) {
    el.innerHTML = `<div class="state-error" style="padding:12px">${_esc(e.message)}</div>`;
  }
}

function _posRenderSummaryReport(r, el) {
  const fmt = n => '$' + parseFloat(n || 0).toFixed(2);
  if (!r.session_count) {
    el.innerHTML = '<div class="pos-empty" style="padding:20px;text-align:center">No sessions in this date range</div>';
    return;
  }
  const splitRow = (r.split && r.split.count > 0) ? `
    <div class="pos-zrpt-row">
      <span>Split</span>
      <span>${r.split.count} txn${r.split.count !== 1 ? 's' : ''}</span>
      <span>${fmt(r.split.total)}</span>
    </div>` : '';
  const acctRow = (r.account && r.account.count > 0) ? `
    <div class="pos-zrpt-row" style="color:var(--amber)">
      <span>On Account <span style="font-size:10px;opacity:.7">(AR)</span></span>
      <span>${r.account.count} txn${r.account.count !== 1 ? 's' : ''}</span>
      <span>${fmt(r.account.total)}</span>
    </div>` : '';

  const sessRows = r.sessions.map(s => {
    const opened = (s.opened_at || '').slice(0, 10);
    const isOpen = !s.closed_at;
    const note = s.note ? ` <span style="color:var(--ink3);font-size:11px">${_esc(s.note)}</span>` : '';
    return `<tr>
      <td>#${s.id}${note}</td>
      <td>${opened}</td>
      <td>${_esc(s.opened_by_name || '—')}</td>
      <td style="text-align:right">${s.tx_count}</td>
      <td style="text-align:right">${fmt(s.total)}</td>
      <td>${isOpen ? '<span class="badge badge-pending badge-sm-inline">Open</span>' : ''}</td>
    </tr>`;
  }).join('');

  el.innerHTML = `
    <div class="pos-summary-totals">
      <div class="pos-summary-period">${r.date_from} → ${r.date_to} &nbsp;·&nbsp; ${r.session_count} session${r.session_count !== 1 ? 's' : ''}</div>
      <div class="pos-zrpt-sep"></div>
      <div class="pos-zrpt-row">
        <span>Cash</span>
        <span>${r.cash.count} txn${r.cash.count !== 1 ? 's' : ''}</span>
        <span>${fmt(r.cash.total)}</span>
      </div>
      <div class="pos-zrpt-row">
        <span>Card / EFTPOS</span>
        <span>${r.card.count} txn${r.card.count !== 1 ? 's' : ''}</span>
        <span>${fmt(r.card.total)}</span>
      </div>
      ${splitRow}${acctRow}
      <div class="pos-zrpt-sep"></div>
      <div class="pos-zrpt-row pos-zrpt-row-total">
        <span>TOTAL SALES</span>
        <span>${r.tx_count} txn${r.tx_count !== 1 ? 's' : ''}</span>
        <span>${fmt(r.total)}</span>
      </div>
      <div class="pos-zrpt-sep"></div>
      <div class="pos-zrpt-row pos-zrpt-row-gst"><span>GST (included)</span><span></span><span>${fmt(r.gst)}</span></div>
      <div class="pos-zrpt-row pos-zrpt-row-gst"><span>Ex-GST</span><span></span><span>${fmt(r.ex_gst)}</span></div>
    </div>
    <div class="pos-summary-sess-hdr">Sessions</div>
    <div class="tbl-overflow-x">
      <table class="inv-list-table">
        <thead><tr>
          <th>Session</th><th>Date</th><th>Operator</th>
          <th style="text-align:right">Txns</th>
          <th style="text-align:right">Total</th>
          <th></th>
        </tr></thead>
        <tbody>${sessRows}</tbody>
      </table>
    </div>`;
}


// ═══════════════════════════════════════════════════════════════════════════
// ANALYTICS MODAL
// ═══════════════════════════════════════════════════════════════════════════

function _posOpenAnalytics() {
  const today      = new Date().toISOString().slice(0, 10);
  const monthStart = today.slice(0, 8) + '01';
  _posAnData      = null;
  _posAnStaffData = null;
  _posAnActiveTab = 'analytics';

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-an-bd';
  bd.innerHTML = `
    <div class="modal-box pos-an-modal">
      <div class="modal-hdr">
        <span>POS Analytics</span>
        <button class="modal-close" onclick="document.getElementById('pos-an-bd').remove()">✕</button>
      </div>
      <div class="pos-an-datebar">
        <button class="btn btn-sm btn-sec" onclick="_posAnPreset('today')">Today</button>
        <button class="btn btn-sm btn-sec" onclick="_posAnPreset('7d')">Last 7 Days</button>
        <button class="btn btn-sm btn-sec" onclick="_posAnPreset('month')">This Month</button>
        <input type="date" id="pos-an-from" value="${monthStart}">
        <span style="color:var(--ink3)">→</span>
        <input type="date" id="pos-an-to" value="${today}">
        <button class="btn btn-sm" onclick="_posAnLoad()">Run</button>
      </div>
      <div class="pos-an-tabs">
        <button class="pos-an-tab active" onclick="_posAnSwitchTab(this,'analytics')">Analytics</button>
        <button class="pos-an-tab"        onclick="_posAnSwitchTab(this,'staff')">By Staff</button>
      </div>
      <div class="modal-body pos-an-body" id="pos-an-body" style="overflow-y:auto;flex:1;padding:0">
        <div class="state-loading" style="padding:24px">Loading…</div>
      </div>
    </div>`;
  document.body.appendChild(bd);
  _posAnLoad();
}

function _posAnPreset(key) {
  const today = new Date().toISOString().slice(0, 10);
  let from = today;
  if (key === '7d') {
    const d = new Date(); d.setDate(d.getDate() - 6);
    from = d.toISOString().slice(0, 10);
  } else if (key === 'month') {
    from = today.slice(0, 8) + '01';
  }
  const fi = document.getElementById('pos-an-from');
  const ti = document.getElementById('pos-an-to');
  if (fi) fi.value = from;
  if (ti) ti.value = today;
  _posAnData      = null;
  _posAnStaffData = null;
  _posAnLoad();
}

function _posAnSwitchTab(el, tab) {
  _posAnActiveTab = tab;
  document.querySelectorAll('#pos-an-bd .pos-an-tab').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  _posAnLoad();
}

async function _posAnLoad() {
  const body = document.getElementById('pos-an-body');
  if (!body) return;
  const from = document.getElementById('pos-an-from')?.value || '';
  const to   = document.getElementById('pos-an-to')?.value   || '';
  if (!from || !to) { toast('Select a date range', 'err'); return; }

  if (_posAnActiveTab === 'analytics') {
    if (_posAnData) { _posAnRenderAnalytics(_posAnData); return; }
    body.innerHTML = '<div class="state-loading" style="padding:24px">Loading…</div>';
    try {
      _posAnData = await apiFetch(`/api/pos/analytics?from=${from}&to=${to}`);
      _posAnRenderAnalytics(_posAnData);
    } catch(e) {
      body.innerHTML = `<div class="state-error" style="padding:24px">${_esc(e.message)}</div>`;
    }
  } else {
    if (_posAnStaffData) { _posAnRenderStaff(_posAnStaffData); return; }
    body.innerHTML = '<div class="state-loading" style="padding:24px">Loading…</div>';
    try {
      _posAnStaffData = await apiFetch(`/api/pos/staff-report?from=${from}&to=${to}`);
      _posAnRenderStaff(_posAnStaffData);
    } catch(e) {
      body.innerHTML = `<div class="state-error" style="padding:24px">${_esc(e.message)}</div>`;
    }
  }
}

function _posAnRenderAnalytics(d) {
  const body = document.getElementById('pos-an-body');
  if (!body) return;
  const fmt = v => '$' + parseFloat(v || 0).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  const s = d.summary;

  // ── stat cards ────────────────────────────────────────────────────
  const cards = `
    <div class="pos-an-cards">
      <div class="pos-an-card">
        <div class="pos-an-card-val">${fmt(s.total)}</div>
        <div class="pos-an-card-lbl">Total Revenue</div>
      </div>
      <div class="pos-an-card">
        <div class="pos-an-card-val">${s.tx_count}</div>
        <div class="pos-an-card-lbl">Transactions</div>
      </div>
      <div class="pos-an-card">
        <div class="pos-an-card-val">${fmt(s.avg_tx)}</div>
        <div class="pos-an-card-lbl">Avg Sale</div>
      </div>
      <div class="pos-an-card">
        <div class="pos-an-card-val">${fmt(s.gst)}</div>
        <div class="pos-an-card-lbl">GST Collected</div>
      </div>
    </div>`;

  if (!d.daily.length) {
    body.innerHTML = cards + '<div class="pos-an-empty">No sales in this period</div>';
    return;
  }

  // ── daily chart ───────────────────────────────────────────────────
  const maxDay = Math.max(...d.daily.map(r => r.total), 0.01);
  const dayBars = d.daily.map(r => {
    const pct  = Math.round((r.total / maxDay) * 100);
    const date = r.day.slice(5); // MM-DD
    return `<div class="pos-an-bar-wrap" title="${r.day}: ${fmt(r.total)} (${r.tx_count} txns)">
      <div class="pos-an-bar" style="height:${pct}%"></div>
      <div class="pos-an-bar-lbl">${date}</div>
    </div>`;
  }).join('');

  const chart = `
    <div class="pos-an-section">
      <div class="pos-an-section-hdr">Daily Revenue</div>
      <div class="pos-an-chart-wrap">
        <div class="pos-an-chart">${dayBars}</div>
      </div>
    </div>`;

  // ── bottom row: top items + hourly pattern ────────────────────────
  const maxRev = d.top_items.length ? Math.max(...d.top_items.map(i => i.revenue), 0.01) : 0.01;
  const itemRows = d.top_items.length
    ? d.top_items.map((item, idx) => {
        const pct = Math.round((item.revenue / maxRev) * 100);
        return `<div class="pos-an-item-row">
          <span class="pos-an-item-rank">${idx + 1}</span>
          <div class="pos-an-item-info">
            <div class="pos-an-item-name">${_esc(item.description)}</div>
            <div class="pos-an-item-bar-wrap">
              <div class="pos-an-item-bar" style="width:${pct}%"></div>
            </div>
          </div>
          <span class="pos-an-item-rev">${fmt(item.revenue)}</span>
        </div>`;
      }).join('')
    : '<div style="color:var(--ink3);font-size:13px;padding:12px 0">No item data</div>';

  // hourly — build full 0-23 array filling gaps with 0
  const hourMap = {};
  d.hourly.forEach(h => { hourMap[h.hour] = h; });
  const maxHr = d.hourly.length ? Math.max(...d.hourly.map(h => h.tx_count), 0) : 0;
  const hourCells = Array.from({length: 24}, (_, h) => {
    const entry  = hourMap[h] || {tx_count: 0, total: 0};
    const pct    = maxHr > 0 ? Math.round((entry.tx_count / maxHr) * 80) : 0;
    const lbl    = h === 0 ? '12am' : h < 12 ? `${h}am` : h === 12 ? '12pm' : `${h-12}pm`;
    const showLbl = (h % 6 === 0);
    return `<div class="pos-an-hour-cell"
                 style="background:color-mix(in srgb, var(--accent) ${pct}%, var(--surface))"
                 title="${lbl}: ${entry.tx_count} txns, ${fmt(entry.total)}">
      ${showLbl ? `<span class="pos-an-hour-lbl">${lbl}</span>` : ''}
    </div>`;
  }).join('');

  const bottom = `
    <div class="pos-an-bottom">
      <div class="pos-an-section pos-an-items-section">
        <div class="pos-an-section-hdr">Top Items</div>
        ${itemRows}
      </div>
      <div class="pos-an-section pos-an-hours-section">
        <div class="pos-an-section-hdr">Peak Hours</div>
        <div class="pos-an-hour-grid">${hourCells}</div>
        <div class="pos-an-hour-legend">
          <span>Lighter = fewer sales</span>
          <span>Darker = more sales</span>
        </div>
      </div>
    </div>`;

  body.innerHTML = `<div class="pos-an-content">${cards}${chart}${bottom}</div>`;
}

function _posAnRenderStaff(d) {
  const body = document.getElementById('pos-an-body');
  if (!body) return;
  const fmt = v => '$' + parseFloat(v || 0).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

  if (!d.staff.length) {
    body.innerHTML = '<div class="pos-an-empty">No sessions in this period</div>';
    return;
  }

  const rows = d.staff.map(r => `
    <tr>
      <td>${_esc(r.operator)}</td>
      <td style="text-align:right">${r.session_count}</td>
      <td style="text-align:right">${r.tx_count}</td>
      <td style="text-align:right">${fmt(r.total)}</td>
      <td style="text-align:right">${fmt(r.avg_tx)}</td>
    </tr>`).join('');

  const grand_total = d.staff.reduce((a, r) => a + r.total, 0);
  const grand_tx    = d.staff.reduce((a, r) => a + r.tx_count, 0);

  body.innerHTML = `
    <div class="pos-an-content">
      <div class="pos-an-section">
        <div class="tbl-overflow-x">
          <table class="inv-list-table">
            <thead><tr>
              <th>Operator</th>
              <th style="text-align:right">Sessions</th>
              <th style="text-align:right">Transactions</th>
              <th style="text-align:right">Revenue</th>
              <th style="text-align:right">Avg Sale</th>
            </tr></thead>
            <tbody>${rows}</tbody>
            <tfoot><tr class="pos-an-staff-total">
              <td><strong>Total</strong></td>
              <td></td>
              <td style="text-align:right"><strong>${grand_tx}</strong></td>
              <td style="text-align:right"><strong>${fmt(grand_total)}</strong></td>
              <td></td>
            </tr></tfoot>
          </table>
        </div>
        <div style="font-size:12px;color:var(--ink3);margin-top:8px;padding:0 4px">
          ${d.date_from} → ${d.date_to}
        </div>
      </div>
    </div>`;
}
