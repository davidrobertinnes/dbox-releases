// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// POS — Refund / return / store credit flow
// Depends on globals in pos.js: _posRefundLines, _posRefundInvoiceId,
// _posRefundTerminalProvider, _posRefundTyroSurchargeCents,
// _posSettings, _posHistorySales
'use strict';


// ═══════════════════════════════════════════════════════════════════════════
// REFUND / RETURN
// ═══════════════════════════════════════════════════════════════════════════

async function _posRefundFromHistory(invoiceId, tender, terminalProvider, tyroSurchargeCents) {
  // Close history modal, load invoice lines, open refund modal
  document.getElementById('pos-hist-bd')?.remove();
  let inv;
  try {
    inv = await apiFetch(`/api/invoices/${invoiceId}`);
  } catch(e) {
    toast(e.message || 'Could not load invoice', 'err'); return;
  }
  _posRefundInvoiceId          = invoiceId;
  _posRefundTerminalProvider   = terminalProvider || null;
  _posRefundTyroSurchargeCents = parseInt(tyroSurchargeCents, 10) || 0;
  // Pre-select all lines at their original qty
  _posRefundLines = (inv.lines || []).filter(l => l.line_type !== 'comment').map(l => ({
    invoice_line_id: l.id,
    description: l.description,
    qty: parseFloat(l.quantity || 1),
    unit_price: parseFloat(l.unit_price || 0),
    tax_code: l.tax_code || 'GST',
    account_id: l.account_id,
    refund_qty: parseFloat(l.quantity || 1),
  }));
  _posRenderRefundModal(inv, tender);
}

function _posRenderRefundModal(inv, tender) {
  document.getElementById('pos-refund-bd')?.remove();
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-refund-bd';
  const tenderLabel = tender === 'cash' ? 'Cash' : 'Card';
  bd.innerHTML = `<div class="modal-box pos-refund-modal">
    <div class="modal-hdr">
      <span>Refund — ${_esc(inv.invoice_number)}</span>
      <button class="modal-close" onclick="document.getElementById('pos-refund-bd').remove()">✕</button>
    </div>
    <div class="modal-body pos-refund-body">
      <p class="pos-refund-subtitle">Select quantities to refund and choose tender method.</p>
      <table class="inv-list-table pos-refund-table">
        <thead><tr>
          <th>Item</th>
          <th style="text-align:right">Orig</th>
          <th style="text-align:right">Refund Qty</th>
          <th style="text-align:right">Unit</th>
          <th style="text-align:right">Amount</th>
        </tr></thead>
        <tbody id="pos-refund-lines">
        ${_posRefundLines.map((l, i) => `
          <tr>
            <td>${_esc(l.description)}</td>
            <td style="text-align:right">${l.qty}</td>
            <td style="text-align:right">
              <input class="pos-refund-qty-inp" type="number"
                     min="0" max="${l.qty}" step="0.001"
                     value="${l.refund_qty}"
                     oninput="_posRefundUpdateTotal(${i}, this.value)">
            </td>
            <td style="text-align:right">$${l.unit_price.toFixed(2)}</td>
            <td style="text-align:right" id="pos-refund-line-${i}">
              $${(l.refund_qty * l.unit_price).toFixed(2)}
            </td>
          </tr>`).join('')}
        </tbody>
      </table>
      <div class="pos-refund-totals">
        <div class="pos-refund-tender-row">
          <label>Return tender:</label>
          <select id="pos-refund-tender" class="pos-refund-tender-sel">
            <option value="cash" ${tender === 'cash' ? 'selected' : ''}>Cash</option>
            <option value="card" ${tender !== 'cash' ? 'selected' : ''}>Card</option>
          </select>
        </div>
        <div class="pos-refund-total-row">
          <span>Refund Total:</span>
          <strong id="pos-refund-total">$0.00</strong>
        </div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-sec" onclick="document.getElementById('pos-refund-bd').remove()">Cancel</button>
      <button class="btn btn-sec" id="pos-store-credit-btn" onclick="_posStoreCreditConfirm()">
        Store Credit
      </button>
      <button class="btn btn-danger" id="pos-refund-confirm-btn" onclick="_posRefundConfirm()">
        Refund
      </button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  _posRefundUpdateTotal(-1, 0); // compute initial total
}

function _posRefundUpdateTotal(lineIdx, val) {
  if (lineIdx >= 0 && _posRefundLines[lineIdx]) {
    const max = _posRefundLines[lineIdx].qty;
    let n = parseFloat(val) || 0;
    if (n < 0) n = 0;
    if (n > max) n = max;
    _posRefundLines[lineIdx].refund_qty = n;
    const el = document.getElementById(`pos-refund-line-${lineIdx}`);
    const gst = (((_posRefundLines[lineIdx].tax_code || 'GST') === 'GST') ? 1.1 : 1.0);
    if (el) el.textContent = `$${(n * _posRefundLines[lineIdx].unit_price * gst).toFixed(2)}`;
  }
  const total = _posRefundLines.reduce((s, l) => s + l.refund_qty * l.unit_price * ((l.tax_code || 'GST') === 'GST' ? 1.1 : 1.0), 0);
  const el = document.getElementById('pos-refund-total');
  if (el) el.textContent = `$${total.toFixed(2)}`;
  const btn = document.getElementById('pos-refund-confirm-btn');
  if (btn) btn.disabled = total <= 0;
}

async function _posRefundConfirm() {
  const tender = document.getElementById('pos-refund-tender')?.value || 'cash';
  const lines = _posRefundLines
    .filter(l => l.refund_qty > 0)
    .map(l => ({
      invoice_line_id: l.invoice_line_id,
      quantity: l.refund_qty,
      description: l.description,
      unit_price: l.unit_price,
      tax_code: l.tax_code,
      account_id: l.account_id,
    }));
  if (!lines.length) { toast('No items selected for refund', 'err'); return; }
  const btn = document.getElementById('pos-refund-confirm-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Processing…'; }
  const refundTotal = _posRefundLines
    .filter(l => l.refund_qty > 0)
    .reduce((s, l) => s + l.refund_qty * l.unit_price * ((l.tax_code || 'GST') === 'GST' ? 1.1 : 1.0), 0);
  let _tyroRefundTd = null;
  try {
    // For card sales, push a reversal to the terminal first
    if (tender === 'card' && _posRefundTerminalProvider === 'linkly') {
      if (btn) btn.textContent = 'Contacting terminal…';
      const tr = await fetch('/api/pos/terminal/refund', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ invoice_id: _posRefundInvoiceId, amount: refundTotal }),
      }).then(r => r.json());
      if (!tr.ok) throw new Error(tr.error || 'Terminal refund failed');
      if (btn) btn.textContent = 'Processing…';
    } else if (tender === 'card' && _posRefundTerminalProvider === 'tyro') {
      if (btn) btn.textContent = 'Contacting terminal…';
      // Tyro reverses the surcharge automatically on its end — send original invoice amount only
      const amountCents = Math.round(refundTotal * 100);
      const client = await _posGetTyroClient();
      await new Promise((resolve, reject) => {
        client.initiateRefund(
          { amount: String(amountCents), integratedReceipt: !!_posSettings.tyro_integrated_receipt },
          {
            receiptCallback: function(receipt) {
              if (receipt && (receipt.signatureRequired || _posSettings.tyro_merchant_copy)) {
                _posTyroPrintMerchantReceipt(receipt.merchantReceipt || '', receipt.signatureRequired);
              }
            },
            transactionCompleteCallback: function(td) {
              if (td.result === 'APPROVED') { td._at = new Date(); _tyroRefundTd = td; resolve(); }
              else reject(new Error(td.result === 'CANCELLED' ? 'Refund cancelled' : td.result === 'DECLINED' ? 'Refund declined by terminal' : 'Terminal refund failed'));
            },
          }
        );
      });
      if (btn) btn.textContent = 'Processing…';
    }
    const r = await fetch('/api/pos/refund', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ invoice_id: _posRefundInvoiceId, lines, tender }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Refund failed');
    document.getElementById('pos-refund-bd')?.remove();
    const { cn_id, cn_number, total } = r.data;
    _posShowRefundReceipt(cn_id, cn_number, total, tender, _tyroRefundTd);
    _posHistorySales = await apiFetch('/api/pos/sales?limit=200').catch(() => _posHistorySales);
  } catch(e) {
    toast(e.message || 'Refund failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Issue Refund'; }
  }
}

function _posShowRefundReceipt(cnId, cnNumber, total, tender, tyroTd) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-refund-rcpt-bd';
  let tyroDetail = '';
  if (tyroTd) {
    const dateStr = tyroTd._at ? tyroTd._at.toLocaleString('en-AU', {day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}) : '';
    const rows = [
      tyroTd.cardType       ? `<tr><td style="color:var(--ink2);padding:2px 10px 2px 0">Card</td><td>${_esc(tyroTd.cardType)}${tyroTd.elidedPan ? ' ' + _esc(tyroTd.elidedPan) : ''}</td></tr>` : '',
      tyroTd.transactionReference ? `<tr><td style="color:var(--ink2);padding:2px 10px 2px 0">TXN Ref</td><td style="font-family:monospace">${_esc(tyroTd.transactionReference)}</td></tr>` : '',
      (tyroTd.rrn || tyroTd.authorisationCode) ? `<tr><td style="color:var(--ink2);padding:2px 10px 2px 0">Auth</td><td style="font-family:monospace">${_esc(tyroTd.rrn || tyroTd.authorisationCode)}</td></tr>` : '',
      dateStr ? `<tr><td style="color:var(--ink2);padding:2px 10px 2px 0">Date</td><td>${_esc(dateStr)}</td></tr>` : '',
    ].join('');
    if (rows) tyroDetail = `<table style="margin:10px auto 0;font-size:12px;border-collapse:collapse;text-align:left">${rows}</table>`;
  }
  bd.innerHTML = `<div class="modal-box pos-receipt-modal" style="text-align:center">
    <div class="modal-hdr"><span>Refund Issued</span></div>
    <div class="modal-body" style="padding:20px 16px">
      <div style="font-size:28px;color:var(--green)">↩</div>
      <div style="font-size:18px;font-weight:600;margin:6px 0">${_esc(cnNumber)}</div>
      <div style="font-size:22px;font-weight:700;margin:4px 0">$${parseFloat(total).toFixed(2)}</div>
      <div style="color:var(--ink2);font-size:13px">${tender === 'cash' ? 'Cash refund' : 'Card refund'}</div>
      ${tyroDetail}
    </div>
    <div class="modal-foot" style="justify-content:center;gap:8px">
      <button class="btn btn-sec" id="pos-refund-print-btn"
              onclick="_posPrintRefundReceipt(${cnId},'${tender}',${parseFloat(total).toFixed(4)})">
        Print Receipt
      </button>
      <button class="btn" onclick="document.getElementById('pos-refund-rcpt-bd').remove()">
        Done
      </button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  if (_posSettings.auto_print) {
    _posPrintRefundReceipt(cnId, tender, parseFloat(total));
  }
}

async function _posPrintRefundReceipt(cnId, tender, amount) {
  const btn = document.getElementById('pos-refund-print-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Printing…'; }
  try {
    const r = await fetch('/api/pos/print-refund-receipt', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ cn_id: cnId, tender, amount }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Print failed');
    toast('Refund receipt printed');
  } catch(e) {
    toast(e.message || 'Print failed', 'err');
  }
  if (btn) { btn.disabled = false; btn.textContent = 'Print Receipt'; }
}


// ═══════════════════════════════════════════════════════════════════════════
// STORE CREDIT
// ═══════════════════════════════════════════════════════════════════════════

async function _posStoreCreditConfirm() {
  const lines = _posRefundLines
    .filter(l => l.refund_qty > 0)
    .map(l => ({
      invoice_line_id: l.invoice_line_id,
      quantity: l.refund_qty,
      description: l.description,
      unit_price: l.unit_price,
      tax_code: l.tax_code,
      account_id: l.account_id,
    }));
  if (!lines.length) { toast('No items selected', 'err'); return; }
  const btn = document.getElementById('pos-store-credit-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Processing…'; }
  try {
    const r = await fetch('/api/pos/store-credit', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ invoice_id: _posRefundInvoiceId, lines }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Failed');
    document.getElementById('pos-refund-bd')?.remove();
    const { cn_id, cn_number, total } = r.data;
    _posShowStoreCreditModal(cn_id, cn_number, total);
    _posHistorySales = await apiFetch('/api/pos/sales?limit=200').catch(() => _posHistorySales);
  } catch(e) {
    toast(e.message || 'Failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Store Credit'; }
  }
}

function _posShowStoreCreditModal(cnId, cnNumber, total) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-sc-bd';
  bd.innerHTML = `<div class="modal-box pos-receipt-modal" style="text-align:center">
    <div class="modal-hdr"><span>Store Credit Issued</span></div>
    <div class="modal-body" style="padding:20px 16px">
      <div style="font-size:28px;color:var(--accent)">★</div>
      <div style="font-size:18px;font-weight:600;margin:6px 0">${_esc(cnNumber)}</div>
      <div style="font-size:22px;font-weight:700;margin:4px 0">$${parseFloat(total).toFixed(2)}</div>
      <div style="color:var(--ink2);font-size:13px">Store credit — available for future purchases</div>
    </div>
    <div class="modal-foot" style="justify-content:center;gap:8px">
      <button class="btn btn-sec" id="pos-sc-print-btn"
              onclick="_posPrintCreditNote(${cnId},${parseFloat(total).toFixed(4)})">
        Print Credit Note
      </button>
      <button class="btn" onclick="document.getElementById('pos-sc-bd').remove()">Done</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  if (_posSettings.auto_print) {
    _posPrintCreditNote(cnId, parseFloat(total));
  }
}

async function _posPrintCreditNote(cnId, amount) {
  const btn = document.getElementById('pos-sc-print-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Printing…'; }
  try {
    const r = await fetch('/api/pos/print-credit-note', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ cn_id: cnId, amount }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Print failed');
    toast('Credit note printed');
  } catch(e) {
    toast(e.message || 'Print failed', 'err');
  }
  if (btn) { btn.disabled = false; btn.textContent = 'Print Credit Note'; }
}
