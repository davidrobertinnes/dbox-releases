// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// POS — Tender: cash, card (Linkly polling), split tender, on-account, sale submission
// Depends on globals in pos.js: _posSettings, _posCart, _posContactId, _posContacts,
// _posBasketDiscount, _posSession, _posLinkedTabId, _posPollTimer
'use strict';


// ═══════════════════════════════════════════════════════════════════════════
// CASH TENDER
// ═══════════════════════════════════════════════════════════════════════════

function _posTenderCash(total) {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box pos-tender-modal">
    <div class="modal-hdr">Cash Payment &mdash; $${parseFloat(total).toFixed(2)} due</div>
    <div class="modal-body">
      <label class="pos-tender-label">Amount tendered ($)</label>
      <input class="pos-tender-inp" id="pos-tendered" type="number" step="0.05"
             min="${parseFloat(total).toFixed(2)}" value="${parseFloat(total).toFixed(2)}"
             oninput="_posCalcChange(${parseFloat(total).toFixed(4)})">
      <div class="pos-change-row" id="pos-change-row"></div>
      <div class="pos-quick-btns">
        ${_posQuickAmounts(total).map(a =>
          `<button class="pos-quick-btn" onclick="_posSetTendered(${a},${parseFloat(total).toFixed(4)})"
           >$${a.toFixed(2)}</button>`
        ).join('')}
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-primary" id="pos-cash-ok" onclick="_posConfirmCash(${parseFloat(total).toFixed(4)})">
        Confirm Sale
      </button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  _posCalcChange(total);
  setTimeout(() => { document.getElementById('pos-tendered')?.select(); }, 60);
}

function _posQuickAmounts(total) {
  const amounts = [];
  for (const multiple of [5, 10, 20, 50, 100]) {
    const a = Math.ceil(total / multiple) * multiple;
    if (!amounts.includes(a)) amounts.push(a);
    if (amounts.length >= 4) break;
  }
  return amounts;
}

function _posSetTendered(amount, total) {
  const inp = document.getElementById('pos-tendered');
  if (inp) { inp.value = amount.toFixed(2); }
  _posCalcChange(total);
}

function _posCalcChange(total) {
  const inp     = document.getElementById('pos-tendered');
  const row     = document.getElementById('pos-change-row');
  const btn     = document.getElementById('pos-cash-ok');
  if (!inp || !row) return;
  const tendered = parseFloat(inp.value) || 0;
  const change   = tendered - total;
  if (change >= 0) {
    row.innerHTML = `<span class="pos-change-ok">Change: $${change.toFixed(2)}</span>`;
    if (btn) btn.disabled = false;
  } else {
    row.innerHTML = `<span class="pos-change-err">Amount insufficient</span>`;
    if (btn) btn.disabled = true;
  }
}

async function _posConfirmCash(total) {
  const inp = document.getElementById('pos-tendered');
  const tendered = parseFloat(inp?.value) || total;
  const bd  = inp?.closest('.modal-bd');
  const btn = document.getElementById('pos-cash-ok');
  if (btn) { btn.disabled = true; btn.textContent = 'Processing…'; }
  try {
    const result = await _posSubmitSale('cash', tendered, null, null);
    bd?.remove();
    _posShowReceipt(result, result.change, 'cash', tendered);
  } catch(e) {
    toast(e.message || 'Sale failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Confirm Sale'; }
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// CARD TENDER (Linkly / mock polling path)
// ═══════════════════════════════════════════════════════════════════════════

async function _posTenderCard(total) {
  if (_posSettings.provider === 'tyro') return _posTenderCardTyro(total);

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-card-modal';
  bd.innerHTML = `<div class="modal-box pos-tender-modal">
    <div class="modal-hdr">Card Payment &mdash; $${parseFloat(total).toFixed(2)}</div>
    <div class="modal-body" id="pos-card-body">
      <div class="pos-terminal-waiting">
        <div class="pos-terminal-spinner"></div>
        <div class="pos-terminal-msg" id="pos-terminal-msg">Connecting to terminal…</div>
        <div class="pos-terminal-sub" id="pos-terminal-sub" style="display:none"></div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn" onclick="_posCancelCard()">Cancel</button>
    </div>
  </div>`;
  document.body.appendChild(bd);

  const _switchMsg = setTimeout(() => {
    const m = document.getElementById('pos-terminal-msg');
    const s = document.getElementById('pos-terminal-sub');
    if (m) m.textContent = 'Present card on terminal';
    if (s) { s.textContent = 'Tap, insert or swipe'; s.style.display = ''; }
  }, 2500);

  const ref = `POS-${Date.now()}`;
  try {
    const r = await fetch('/api/pos/terminal/charge', {
      method:  'POST',
      headers: {'Content-Type': 'application/json'},
      body:    JSON.stringify({amount: parseFloat(total), reference: ref}),
    }).then(r => r.json());

    clearTimeout(_switchMsg);
    if (!r.ok) throw new Error(r.error || 'Terminal error');
    const {checkout_id, provider} = r.data;
    _posPollTerminal(checkout_id, provider, total);
  } catch(e) {
    clearTimeout(_switchMsg);
    const body = document.getElementById('pos-card-body');
    if (body) body.innerHTML = `<div class="pos-terminal-error">${_esc(e.message)}</div>`;
  }
}

async function _posPollTerminal(checkoutId, provider, total) {
  let count = 0;
  clearInterval(_posPollTimer);
  _posPollTimer = setInterval(async () => {
    count++;
    if (count > 90) {  // 3-minute timeout at 2s intervals
      clearInterval(_posPollTimer);
      const body = document.getElementById('pos-card-body');
      if (body) body.innerHTML = '<div class="pos-terminal-error">Terminal timeout — please retry</div>';
      return;
    }
    try {
      const res = await apiFetch(`/api/pos/terminal/charge/${checkoutId}?provider=${provider}`);
      if (res.status === 'completed') {
        clearInterval(_posPollTimer);
        try {
          if (res.signature_required) {
            const body = document.getElementById('pos-card-body');
            if (body) body.innerHTML = `<div class="pos-terminal-waiting">
              <div style="font-size:22px;margin-bottom:8px">✍️</div>
              <div class="pos-terminal-msg">Signature Required</div>
              <div class="pos-terminal-sub">Check the customer's signature, then confirm below</div>
              <div style="display:flex;gap:10px;margin-top:16px;justify-content:center">
                <button class="btn btn-danger" onclick="_posCancelCard()">Decline</button>
                <button class="btn btn-primary" id="pos-sig-confirm">Confirm Signature</button>
              </div></div>`;
            await new Promise((resolve, reject) => {
              document.getElementById('pos-sig-confirm').onclick = resolve;
            });
          }
          const result = await _posSubmitSale('card', null, checkoutId, provider, null, res.rfn || '');
          document.getElementById('pos-card-modal')?.remove();
          _posShowReceipt(result, 0, 'card', result.total);
        } catch(e) {
          const body = document.getElementById('pos-card-body');
          if (body) body.innerHTML = `<div class="pos-terminal-error">${_esc(e.message)}</div>`;
        }
      } else if (res.status === 'declined' || res.status === 'error') {
        clearInterval(_posPollTimer);
        const body = document.getElementById('pos-card-body');
        if (body) body.innerHTML = `<div class="pos-terminal-error">${_esc(res.message || 'Payment declined')}</div>`;
      }
    } catch(_) { /* keep polling on transient errors */ }
  }, 2000);
}

function _posCancelCard() {
  clearInterval(_posPollTimer);
  document.getElementById('pos-card-modal')?.remove();
  if (_posSettings.provider === 'linkly') {
    fetch('/api/pos/terminal/cancel', {method: 'POST'}).catch(() => {});
  }
  // Tyro iClient manages its own cancellation — user presses Cancel on terminal
}


// ═══════════════════════════════════════════════════════════════════════════
// SPLIT TENDER
// ═══════════════════════════════════════════════════════════════════════════

function _posTenderSplit(total) {
  const t = parseFloat(total);
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-split-modal';
  bd.innerHTML = `<div class="modal-box pos-tender-modal">
    <div class="modal-hdr">Split Payment &mdash; $${t.toFixed(2)} due</div>
    <div class="modal-body" id="pos-split-body">
      <div class="pos-split-row">
        <label class="pos-tender-label">Cash ($)</label>
        <input class="pos-tender-inp" id="pos-split-cash" type="number" step="0.01"
               min="0" value="0.00"
               oninput="_posSplitUpdate(${t.toFixed(4)}, 'cash')"
               onclick="this.select()">
      </div>
      <div class="pos-split-row">
        <label class="pos-tender-label">Card ($)</label>
        <input class="pos-tender-inp" id="pos-split-card" type="number" step="0.01"
               min="0" value="${t.toFixed(2)}"
               oninput="_posSplitUpdate(${t.toFixed(4)}, 'card')"
               onclick="this.select()">
      </div>
      <div class="pos-split-total-row" id="pos-split-check"></div>
    </div>
    <div class="modal-foot">
      <button class="btn" onclick="_posCancelSplit()">Cancel</button>
      <button class="btn btn-primary" id="pos-split-ok"
              onclick="_posSplitChargeCard(${t.toFixed(4)})">Charge Card</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  _posSplitUpdate(t, 'card');
  setTimeout(() => document.getElementById('pos-split-cash')?.focus(), 50);
}

function _posSplitUpdate(total, changed) {
  const cashEl  = document.getElementById('pos-split-cash');
  const cardEl  = document.getElementById('pos-split-card');
  const checkEl = document.getElementById('pos-split-check');
  const okBtn   = document.getElementById('pos-split-ok');
  if (!cashEl || !cardEl) return;
  const t = parseFloat(total);
  // Only update the OTHER field — never overwrite the field the user is typing in
  if (changed === 'cash') {
    const cash = Math.min(Math.max(parseFloat(cashEl.value) || 0, 0), t);
    cardEl.value = Math.max(0, t - cash).toFixed(2);
  } else {
    const card = Math.min(Math.max(parseFloat(cardEl.value) || 0, 0), t);
    cashEl.value = Math.max(0, t - card).toFixed(2);
  }
  const sum  = (parseFloat(cashEl.value) || 0) + (parseFloat(cardEl.value) || 0);
  const diff = Math.abs(sum - t);
  if (checkEl) {
    checkEl.innerHTML = diff < 0.005
      ? '<span class="pos-change-ok">&#x2713; Amounts balance</span>'
      : '<span class="pos-change-err">Amounts do not add up to total</span>';
  }
  if (okBtn) okBtn.disabled = diff >= 0.005;
}

async function _posSplitChargeCard(total) {
  if (_posSettings.provider === 'tyro') return _posSplitChargeTyro(total);

  const cashAmt = parseFloat(document.getElementById('pos-split-cash')?.value) || 0;
  const cardAmt = parseFloat(document.getElementById('pos-split-card')?.value) || 0;
  const body = document.getElementById('pos-split-body');
  const foot = document.querySelector('#pos-split-modal .modal-foot');
  if (body) body.innerHTML = `<div class="pos-terminal-waiting">
    <div class="pos-terminal-spinner"></div>
    <div class="pos-terminal-msg" id="pos-terminal-msg">Connecting to terminal…</div>
    <div class="pos-terminal-sub" id="pos-terminal-sub" style="display:none"></div>
  </div>`;
  if (foot) foot.innerHTML = `<button class="btn" onclick="_posCancelSplit()">Cancel</button>`;
  const _switchMsg = setTimeout(() => {
    const m = document.getElementById('pos-terminal-msg');
    const s = document.getElementById('pos-terminal-sub');
    if (m) m.textContent = 'Present card on terminal';
    if (s) { s.textContent = `$${cardAmt.toFixed(2)} — tap, insert or swipe`; s.style.display = ''; }
  }, 2500);
  const ref = 'SPLIT-' + Date.now();
  try {
    const r = await fetch('/api/pos/terminal/charge', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({amount: cardAmt, reference: ref}),
    }).then(r => r.json());
    clearTimeout(_switchMsg);
    if (!r.ok) throw new Error(r.error || 'Terminal error');
    const {checkout_id, provider} = r.data;
    _posPollSplitTerminal(checkout_id, provider, cashAmt, cardAmt, total);
  } catch(e) {
    clearTimeout(_switchMsg);
    if (body) body.innerHTML = `<div class="pos-terminal-error">${_esc(e.message)}</div>`;
    if (foot) foot.innerHTML = `<button class="btn" onclick="_posCancelSplit()">Cancel</button>`;
  }
}

async function _posPollSplitTerminal(checkoutId, provider, cashAmt, cardAmt, total) {
  let count = 0;
  clearInterval(_posPollTimer);
  _posPollTimer = setInterval(async () => {
    count++;
    if (count > 90) {
      clearInterval(_posPollTimer);
      const body = document.getElementById('pos-split-body');
      if (body) body.innerHTML = '<div class="pos-terminal-error">Terminal timeout — please retry</div>';
      return;
    }
    try {
      const res = await apiFetch('/api/pos/terminal/charge/' + checkoutId + '?provider=' + provider);
      if (res.status === 'completed') {
        clearInterval(_posPollTimer);
        _posSplitCollectCash(cashAmt, cardAmt, total, res.tx_id || checkoutId, provider);
      } else if (res.status === 'declined' || res.status === 'error') {
        clearInterval(_posPollTimer);
        const body = document.getElementById('pos-split-body');
        if (body) body.innerHTML = '<div class="pos-terminal-error">' + _esc(res.message || 'Payment declined') + '</div>';
      }
    } catch(_) {}
  }, 2000);
}

function _posSplitCollectCash(cashAmt, cardAmt, total, txId, provider, surchargeCents) {
  const body = document.getElementById('pos-split-body');
  const foot = document.querySelector('#pos-split-modal .modal-foot');
  if (body) {
    var html = '<div class="pos-split-cash-step">';
    html += '<div class="pos-split-cash-icon">&#x2705;</div>';
    html += '<div class="pos-split-cash-msg">Card approved &mdash; $' + cardAmt.toFixed(2) + '</div>';
    html += '<div class="pos-split-cash-collect">Collect cash: <strong>$' + cashAmt.toFixed(2) + '</strong></div>';
    html += '</div>';
    body.innerHTML = html;
  }
  if (foot) {
    foot.innerHTML = '<button class="btn btn-primary" onclick="_posSplitComplete(' +
      cashAmt.toFixed(4) + ',' + cardAmt.toFixed(4) + ',' + total.toFixed(4) +
      ',\'' + txId + '\',\'' + (provider || '') + '\',' + (surchargeCents || 0) +
      ')">Done &mdash; Cash Collected</button>';
  }
}

async function _posSplitComplete(cashAmt, cardAmt, total, txId, provider, surchargeCents) {
  const foot = document.querySelector('#pos-split-modal .modal-foot');
  if (foot) foot.innerHTML = '<span style="color:var(--ink2);font-size:13px">Processing sale…</span>';
  try {
    const result = await _posSubmitSale('split', null, txId, provider, {
      cash: cashAmt, card: cardAmt, terminal_tx_id: txId, terminal_provider: provider,
    }, null, surchargeCents || 0);
    document.getElementById('pos-split-modal')?.remove();
    _posShowReceipt(result, 0, 'split', total, {cash: cashAmt, card: cardAmt}, surchargeCents || 0);
  } catch(e) {
    toast(e.message || 'Sale failed', 'err');
    if (foot) foot.innerHTML = '<button class="btn" onclick="_posCancelSplit()">Cancel</button>';
  }
}

function _posCancelSplit() {
  clearInterval(_posPollTimer);
  document.getElementById('pos-split-modal')?.remove();
}


// ═══════════════════════════════════════════════════════════════════════════
// ON-ACCOUNT TENDER
// ═══════════════════════════════════════════════════════════════════════════

function _posTenderAccount(total) {
  const contact = _posContacts.find(c => c.id == _posContactId);
  const name = contact?.name || 'Unknown';
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-account-modal';
  bd.innerHTML = `<div class="modal-box pos-tender-modal">
    <div class="modal-hdr">On Account</div>
    <div class="modal-body" style="text-align:center;padding:20px 16px">
      <div class="pos-tender-label" style="font-size:15px;margin-bottom:6px">${_esc(name)}</div>
      <div style="font-size:32px;font-weight:700;color:var(--accent);margin-bottom:8px">$${total.toFixed(2)}</div>
      <div style="color:var(--ink2);font-size:13px">This sale will be added to the customer's account.<br>No payment is taken now.</div>
    </div>
    <div class="modal-foot" style="gap:8px">
      <button class="btn btn-sec" onclick="document.getElementById('pos-account-modal')?.remove()">Cancel</button>
      <button class="btn btn-primary" id="pos-acct-confirm" onclick="_posDoAccount(${total.toFixed(4)})">Charge to Account</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

async function _posDoAccount(total) {
  const btn = document.getElementById('pos-acct-confirm');
  if (btn) { btn.disabled = true; btn.textContent = 'Processing…'; }
  try {
    const result = await _posSubmitSale('account', total, null, null);
    document.getElementById('pos-account-modal')?.remove();
    _posShowReceipt(result, 0, 'account', total);
  } catch(e) {
    toast(e.message || 'Sale failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Charge to Account'; }
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// SALE SUBMISSION
// ═══════════════════════════════════════════════════════════════════════════

async function _posSubmitSale(tender, tendered, terminalTxId, terminalProvider, splitTenders, terminalRfn, tyroSurchargeCents) {
  // Capture contact email before clearing state
  const contact      = _posContactId ? _posContacts.find(c => c.id == _posContactId) : null;
  const contactEmail = (contact?.email || '').trim();

  const r = await fetch('/api/pos/sale', {
    method:  'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      lines: _posCart.map(l => ({
        item_id:     l.item_id,
        description: l.description,
        qty:         l.qty,
        // Items are priced GST-inclusive; save_invoice expects ex-GST
        unit_price:  (() => {
          const gstRate   = l.tax_code === 'GST' ? 0.1 : 0;
          const inclusive = Math.round(l.unit_price * (1 - (l.discount || 0) / 100) * 100) / 100;
          return gstRate ? Math.round(inclusive / (1 + gstRate) * 10000) / 10000 : inclusive;
        })(),
        tax_code:    l.tax_code,
        account_id:  l.account_id,
      })),
      tender,
      tendered,
      terminal_tx_id:    terminalTxId,
      terminal_provider: terminalProvider,
      terminal_rfn:           terminalRfn || null,
      split_tenders:          splitTenders || null,
      tyro_surcharge_cents:   tyroSurchargeCents || null,
      session_id:        _posSession?.id ?? null,
      contact_id:        _posContactId || null,
      basket_discount:   _posBasketDiscount || 0,
      gst: _posCart.reduce((s, l) => s + (l.gst || 0), 0),
    }),
  }).then(r => r.json());

  if (!r.ok) throw new Error(r.error || 'Sale failed');
  // If this cart came from Table Service, mark the tab as settled
  if (_posLinkedTabId) {
    fetch(`/api/ts/tabs/${_posLinkedTabId}/mark-settled`, {method:'POST'}).catch(()=>{});
    _posLinkedTabId = null;
  }
  _posCart           = [];
  _posContactId      = null;
  _posBasketDiscount = 0;
  _posRenderCart();
  return { ...r.data, contactEmail };
}
