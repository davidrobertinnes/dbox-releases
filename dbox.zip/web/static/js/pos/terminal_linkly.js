// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// POS — Linkly EFTPOS adapter
// Pairing, settlement, and recovery-receipt functions for the Linkly provider.
// The actual polling loop lives in tender.js (_posPollTerminal / _posPollSplitTerminal).
// Depends on globals in pos.js: _posSettings
'use strict';


// ═══════════════════════════════════════════════════════════════════════════
// LINKLY PAIRING
// ═══════════════════════════════════════════════════════════════════════════

function _posLinklyPair() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.innerHTML = `<div class="modal-box" style="max-width:420px">
    <div class="modal-hdr">
      <span>Pair Linkly Terminal</span>
      <button class="modal-close" onclick="this.closest('.modal-bd').remove()">✕</button>
    </div>
    <div class="modal-body">
      <p style="margin:0 0 14px;color:var(--ink2)">Enter your Linkly credentials and the pair code shown on the PIN pad display.</p>
      <div class="pos-sett-row">
        <label class="pos-sett-lbl">Username</label>
        <input class="pos-sett-inp" id="lnk-pair-user" type="text" autocomplete="username" placeholder="Linkly username">
      </div>
      <div class="pos-sett-row">
        <label class="pos-sett-lbl">Password</label>
        <input class="pos-sett-inp" id="lnk-pair-pass" type="password" autocomplete="current-password" placeholder="Linkly password">
      </div>
      <div class="pos-sett-row">
        <label class="pos-sett-lbl">Pair Code</label>
        <input class="pos-sett-inp" id="lnk-pair-code" type="text" placeholder="Code shown on PIN pad" maxlength="16" style="letter-spacing:2px">
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-sec" onclick="this.closest('.modal-bd').remove()">Cancel</button>
      <button class="btn btn-pri" id="lnk-pair-btn" onclick="_posLinklyDoPair(this)">Pair Terminal</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
}

async function _posLinklyDoPair(btn) {
  const username = (document.getElementById('lnk-pair-user')?.value || '').trim();
  const password = document.getElementById('lnk-pair-pass')?.value || '';
  const pairCode = (document.getElementById('lnk-pair-code')?.value || '').trim();
  if (!username || !password || !pairCode) { toast('All fields are required', 'err'); return; }
  btn.disabled = true; btn.textContent = 'Pairing…';
  try {
    const r = await fetch('/api/pos/terminal/pair', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({username, password, pair_code: pairCode}),
    });
    const d = await r.json();
    if (!d.ok) throw new Error(d.error || 'Pairing failed');
    btn.closest('.modal-bd').remove();
    toast('Terminal paired successfully');
    const statusEl = document.getElementById('pos-sett-pair-status');
    if (statusEl) { statusEl.textContent = '✓ Terminal paired'; statusEl.style.color = 'var(--green)'; }
    const pairBtn = document.querySelector('#pos-sett-pair-row button');
    if (pairBtn) pairBtn.textContent = 'Re-pair';
  } catch(e) {
    toast(e.message, 'err');
    btn.disabled = false; btn.textContent = 'Pair Terminal';
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// LINKLY SETTLEMENT
// ═══════════════════════════════════════════════════════════════════════════

async function _posSettleTerminal(btn) {
  btn.disabled = true; btn.textContent = 'Settling…';
  try {
    const r = await fetch('/api/pos/terminal/settle', {method: 'POST'});
    const d = await r.json();
    if (!d.ok) throw new Error(d.error || 'Settlement failed');
    const res = d.data || {};
    if (res.success) {
      toast('Terminal settled successfully');
    } else {
      toast(`Settlement: ${res.response_text || 'failed'} (${res.response_code || ''})`, 'err');
    }
  } catch(e) {
    toast(e.message, 'err');
  } finally {
    btn.disabled = false; btn.textContent = 'Settle Terminal';
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// LINKLY POWER-FAIL RECOVERY RECEIPT
// ═══════════════════════════════════════════════════════════════════════════

async function _posPrintRecoveryReceipt(res) {
  // If no ESC/POS printer, go to browser print synchronously before any await
  // so the print dialog fires within the user-gesture context (avoids popup blocker)
  if (!_posSettings?.printer_enabled) {
    _posBrowserPrintRecovery(res);
    return;
  }
  const btn = document.getElementById('pos-recover-print-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Printing…'; }
  try {
    const r = await fetch('/api/pos/terminal/print-recovery', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        amount:        res.amount || 0,
        rfn:           res.rfn || '',
        tx_id:         res.tx_id || res.session_id || '',
        response_text: res.response_text || 'Approved',
      }),
    }).then(x => x.json());
    if (r.ok) {
      toast('Receipt printed');
    } else {
      _posBrowserPrintRecovery(res);
    }
  } catch(e) {
    _posBrowserPrintRecovery(res);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Print Receipt'; }
  }
}

function _posBrowserPrintRecovery(res) {
  const amt    = res.amount ? `$${(res.amount / 100).toFixed(2)}` : '';
  const now    = new Date().toLocaleString('en-AU');
  const txnRef = res.tx_id || res.session_id || '';
  const status = (res.response_text || (res.status === 'declined' ? 'DECLINED' : 'APPROVED')).trim().toUpperCase();
  const html = `<!DOCTYPE html><html><head><title>Recovery Receipt</title>
<style>
  body{font-family:monospace;font-size:13px;padding:20px;max-width:280px;margin:0 auto}
  h2{text-align:center;font-size:14px;letter-spacing:1px;margin:0 0 10px}
  hr{border:none;border-top:1px dashed #000;margin:8px 0}
  .row{display:flex;justify-content:space-between;margin:4px 0}
  .lbl{color:#555}
  .note{text-align:center;font-size:11px;margin-top:12px;color:#444}
</style></head><body>
<h2>TERMINAL RECOVERY</h2>
<hr>
<div class="row"><span class="lbl">STATUS</span><strong>${status}</strong></div>
${amt    ? `<div class="row"><span class="lbl">AMOUNT</span><span>${amt}</span></div>`    : ''}
${txnRef ? `<div class="row"><span class="lbl">TXN REF</span><span style="font-size:11px">${txnRef}</span></div>` : ''}
${res.rfn ? `<div class="row"><span class="lbl">RFN</span><span>${res.rfn}</span></div>` : ''}
<hr>
<div class="row"><span class="lbl">PRINTED</span><span>${now}</span></div>
<div class="note">Check if corresponding sale was recorded.<br>If not, record manually.</div>
</body></html>`;
  // Use a hidden iframe — avoids popup blockers in Chromium app-mode
  const frame = document.createElement('iframe');
  frame.style.cssText = 'position:fixed;top:-9999px;left:-9999px;width:1px;height:1px;border:none';
  document.body.appendChild(frame);
  frame.contentDocument.open();
  frame.contentDocument.write(html);
  frame.contentDocument.close();
  setTimeout(() => {
    frame.contentWindow.print();
    setTimeout(() => frame.remove(), 2000);
  }, 300);
}
