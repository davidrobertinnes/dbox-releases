// Copyright © 2026 David Robert Innes trading as Dogbox Software
// ABN 40 986 160 328 — All rights reserved.
// Unauthorised copying, modification, or distribution is prohibited.

// POS — Cart: item grid, barcode scan, cart lines, parked sales, customer picker
// Depends on globals declared in pos.js: _posItems, _posCart, _posSearch,
// _posCatFilter, _posContactId, _posContacts, _posBasketDiscount,
// _posParkedCarts, _posParkedSeq, _posSession, _posLinkedTabId,
// _posStockWarnProceedFn, _posScanMode, _posScanBuf, _posScanLast
'use strict';


// ═══════════════════════════════════════════════════════════════════════════
// ITEM GRID
// ═══════════════════════════════════════════════════════════════════════════

function _posRenderCatBar() {
  const bar = document.getElementById('pos-cat-bar');
  if (!bar) return;
  const cats = [...new Set(_posItems.map(i => i.pos_category || i.account_name).filter(Boolean))].sort();
  if (cats.length < 2) { bar.style.display = 'none'; return; }
  bar.style.display = '';
  bar.innerHTML = '';

  const mkPill = (label, active, onClick) => {
    const btn = document.createElement('button');
    btn.className = active ? 'pos-cat-pill active' : 'pos-cat-pill';
    btn.textContent = label;
    btn.addEventListener('click', onClick);
    return btn;
  };

  bar.appendChild(mkPill('All', _posCatFilter === null, () => {
    _posCatFilter = null; _posRenderCatBar(); _posRenderGrid();
  }));
  cats.forEach(cat => {
    bar.appendChild(mkPill(cat, _posCatFilter === cat, () => {
      _posCatFilter = cat; _posRenderCatBar(); _posRenderGrid();
    }));
  });
}

function _posFilter(q) {
  _posSearch = q.toLowerCase();
  _posRenderGrid();
}

function _posClearSearch() {
  _posSearch = '';
  const inp = document.getElementById('pos-search');
  if (inp) inp.value = '';
  _posRenderGrid();
  inp?.focus();
}

function _posTileStockBadge(item) {
  if (!item.is_inventoried) return '';
  const qty = parseFloat(item.qty_on_hand) || 0;
  const reorder = parseFloat(item.reorder_level) || 0;
  const label = qty <= 0 ? 'Out of stock' : (qty % 1 === 0 ? qty : qty.toFixed(1)) + ' in stock';
  const cls   = qty <= 0 ? 'pos-tile-stock out' : (qty <= reorder ? 'pos-tile-stock low' : 'pos-tile-stock');
  return '<div class="' + cls + '">' + label + '</div>';
}

function _posRenderGrid() {
  const grid = document.getElementById('pos-grid');
  if (!grid) return;
  const q = _posSearch;
  let visible = q
    ? _posItems.filter(i =>
        (i.name    || '').toLowerCase().includes(q) ||
        (i.code    || '').toLowerCase().includes(q) ||
        (i.barcode || '').toLowerCase().includes(q))
    : _posItems;
  if (_posCatFilter) visible = visible.filter(i => (i.pos_category || i.account_name) === _posCatFilter);

  if (!visible.length) {
    grid.innerHTML = `<div class="pos-empty">${q ? 'No items match "' + _esc(q) + '"' : 'No items in catalogue'}</div>`;
    return;
  }
  grid.innerHTML = visible.map(i => {
    const stockBadge = _posTileStockBadge(i);
    return `
    <div class="pos-tile${i.promo_name ? ' pos-tile-promo-active' : ''}" data-id="${i.id}" onclick="_posAddItem(${i.id})" title="${_esc(i.name)}">
      ${i.promo_name ? `<div class="pos-tile-promo-badge">${_esc(i.promo_name)}</div>` : ''}
      <div class="pos-tile-name">${_esc(i.name)}</div>
      ${i.code ? `<div class="pos-tile-code">${_esc(i.code)}</div>` : ''}
      <div class="pos-tile-price">
        ${i.standard_price != null ? `<span class="pos-tile-was">$${i.standard_price.toFixed(2)}</span>` : ''}
        $${(i.unit_price || 0).toFixed(2)}
      </div>
      ${stockBadge}
    </div>`;
  }).join('');
}


// ═══════════════════════════════════════════════════════════════════════════
// BARCODE SCAN MODE
// ═══════════════════════════════════════════════════════════════════════════

function _posToggleScan() {
  _posScanMode = !_posScanMode;
  _posScanBuf  = '';
  const btn = document.getElementById('pos-scan-btn');
  if (btn) btn.classList.toggle('pos-scan-btn-active', _posScanMode);
  if (_posScanMode) toast('Scan mode on — point scanner at any barcode');
}

function _posScanKeyInSearch(e) {
  if (e.key !== 'Enter') return;
  const val = (e.target.value || '').trim();
  if (!val) return;
  const item = _posItems.find(i => i.barcode && i.barcode.toLowerCase() === val.toLowerCase())
             || _posItems.find(i => i.code   && i.code.toLowerCase()    === val.toLowerCase());
  if (item) {
    e.preventDefault();
    _posAddItemWithFlash(item.id);
  }
}

function _posScanGlobal(e) {
  if (!_posScanMode) return;
  if (document.querySelector('.modal-bd')) return;
  const active = document.activeElement;
  if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.tagName === 'SELECT')) return;

  const now = Date.now();
  if (now - _posScanLast > 80) _posScanBuf = '';
  _posScanLast = now;

  if (e.key === 'Enter') {
    const code = _posScanBuf.trim();
    _posScanBuf = '';
    if (code.length >= 2) { e.preventDefault(); _posHandleScan(code); }
    return;
  }
  if (e.key.length === 1) _posScanBuf += e.key;
}

function _posHandleScan(code) {
  const item = _posItems.find(i => i.barcode && i.barcode.toLowerCase() === code.toLowerCase())
             || _posItems.find(i => i.code   && i.code.toLowerCase()    === code.toLowerCase());
  if (!item) { toast(`Barcode not found: ${_esc(code)}`, 'err'); return; }
  _posAddItemWithFlash(item.id);
}

function _posAddItemWithFlash(itemId) {
  _posAddItem(itemId);
  _posClearSearch();
  const tile = document.querySelector(`.pos-tile[data-id="${itemId}"]`);
  if (tile) {
    tile.classList.add('pos-scan-flash');
    setTimeout(() => tile.classList.remove('pos-scan-flash'), 500);
  }
  const item = _posItems.find(i => i.id === itemId);
  if (item) toast(`Added: ${item.name}`);
}


// ═══════════════════════════════════════════════════════════════════════════
// CART
// ═══════════════════════════════════════════════════════════════════════════

function _posAddItem(itemId) {
  const item = _posItems.find(i => i.id === itemId);
  if (!item) return;
  const existing = _posCart.find(l => l.item_id === itemId);
  if (existing) {
    existing.qty++;
    _posCalcLine(existing);
  } else {
    const line = {
      item_id:     item.id,
      description: item.name,
      qty:         1,
      unit_price:  item.unit_price || 0,
      tax_code:    item.tax_code || 'GST',
      account_id:  item.account_id || null,
    };
    _posCalcLine(line);
    _posCart.push(line);
  }
  _posRenderCart();
}

function _posCalcLine(line) {
  const gst_rate  = line.tax_code === 'GST' ? 0.1 : 0;
  const discount  = line.discount || 0;
  const effective = Math.round(line.unit_price * (1 - discount / 100) * 100) / 100;
  line.total = Math.round(line.qty * effective * 100) / 100;
  line.gst   = Math.round(line.total * gst_rate / (1 + gst_rate) * 100) / 100;
}

function _posQtyDelta(idx, delta) {
  const line = _posCart[idx];
  if (!line) return;
  line.qty = Math.max(1, line.qty + delta);
  _posCalcLine(line);
  _posRenderCart();
}

function _posSetQty(idx, val) {
  const line = _posCart[idx];
  if (!line) return;
  const n = parseFloat(val);
  line.qty = (isNaN(n) || n <= 0) ? 1 : Math.round(n * 1000) / 1000;
  _posCalcLine(line);
  _posRenderCart();
}

function _posRemoveLine(idx) {
  _posCart.splice(idx, 1);
  _posRenderCart();
}

function _posPriceChange(idx, val) {
  const line = _posCart[idx];
  if (!line) return;
  const p = parseFloat(val);
  line.unit_price = (isNaN(p) || p < 0) ? 0 : Math.round(p * 100) / 100;
  _posCalcLine(line);
  _posRenderCart();
}

function _posDiscountChange(idx, val) {
  const line = _posCart[idx];
  if (!line) return;
  const d = parseFloat(val);
  line.discount = (isNaN(d) || d < 0) ? 0 : Math.min(100, Math.round(d * 10) / 10);
  _posCalcLine(line);
  _posRenderCart();
}

function _posBasketDiscChange(val) {
  const d = parseFloat(val);
  _posBasketDiscount = (isNaN(d) || d < 0) ? 0 : Math.min(100, Math.round(d * 10) / 10);
  _posRenderCart();
}

function _posAddCustomItem() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-custom-bd';
  bd.innerHTML = `<div class="modal-box" style="max-width:380px">
    <div class="modal-hdr">Custom Item</div>
    <div class="modal-body" style="display:flex;flex-direction:column;gap:12px">
      <div>
        <label class="pos-sett-lbl">Description</label>
        <input class="pos-sett-inp" id="pos-cust-desc" type="text" placeholder="e.g. Delivery, Labour, Misc"
               autocomplete="off" maxlength="100">
      </div>
      <div>
        <label class="pos-sett-lbl">Unit Price (inc. GST)</label>
        <div class="pos-till-input-wrap">
          <span class="pos-till-dollar">$</span>
          <input class="pos-till-inp" id="pos-cust-price" type="number" min="0" step="0.01"
                 placeholder="0.00" style="width:100px">
        </div>
      </div>
      <div>
        <label class="pos-sett-check">
          <input type="checkbox" id="pos-cust-gst" checked>
          GST applies (10%)
        </label>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn" onclick="document.getElementById('pos-custom-bd').remove()">Cancel</button>
      <button class="btn btn-primary" onclick="_posConfirmCustomItem()">Add to Cart</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  setTimeout(() => document.getElementById('pos-cust-desc')?.focus(), 50);
}

function _posConfirmCustomItem() {
  const desc  = (document.getElementById('pos-cust-desc')?.value || '').trim();
  const price = parseFloat(document.getElementById('pos-cust-price')?.value || 0) || 0;
  const gst   = document.getElementById('pos-cust-gst')?.checked ?? true;
  if (!desc) { toast('Description is required', 'err'); return; }
  if (price <= 0) { toast('Price must be greater than zero', 'err'); return; }
  const line = {
    item_id:     null,
    description: desc,
    qty:         1,
    unit_price:  Math.round(price * 100) / 100,
    tax_code:    gst ? 'GST' : 'N-T',
    account_id:  null,
  };
  _posCalcLine(line);
  _posCart.push(line);
  document.getElementById('pos-custom-bd')?.remove();
  _posRenderCart();
}

function _posClearCart() {
  _posCart           = [];
  _posContactId      = null;
  _posBasketDiscount = 0;
  _posRenderCart();
}


// ═══════════════════════════════════════════════════════════════════════════
// HELD / PARKED SALES
// ═══════════════════════════════════════════════════════════════════════════

function _posParkSale() {
  if (!_posCart.length) { toast('Cart is empty', 'err'); return; }
  // Show label prompt before parking
  const nextN = _posParkedCarts.length + 1;
  const bd = document.createElement('div');
  bd.className = 'modal-bd'; bd.style.display = 'flex'; bd.id = 'pos-park-modal';
  bd.innerHTML = `<div class="modal-box" style="width:320px;padding:0;display:flex;flex-direction:column">
    <div class="modal-hdr"><span class="modal-title">Park Sale</span>
      <button class="modal-close" onclick="document.getElementById('pos-park-modal')?.remove()">✕</button>
    </div>
    <div class="modal-body">
      <label class="pos-sett-lbl">Label <span style="color:var(--ink3);font-weight:400">(so you can find it in Held)</span></label>
      <input class="pos-sett-inp" id="pos-park-label" value="Order ${nextN}" style="margin-top:4px">
    </div>
    <div class="modal-foot">
      <button class="btn" onclick="document.getElementById('pos-park-modal')?.remove()">Cancel</button>
      <button class="btn btn-primary" onclick="_posConfirmPark()">Park</button>
    </div>
  </div>`;
  document.body.appendChild(bd);
  const inp = document.getElementById('pos-park-label');
  if (inp) { inp.focus(); inp.select(); }
  inp?.addEventListener('keydown', e => { if (e.key === 'Enter') _posConfirmPark(); });
}

async function _posConfirmPark() {
  const labelEl = document.getElementById('pos-park-label');
  const label = (labelEl?.value || '').trim() || `Order ${_posParkedCarts.length + 1}`;
  document.getElementById('pos-park-modal')?.remove();
  const contact = _posContactId ? _posContacts.find(c => c.id == _posContactId) : null;
  const cartData = {
    contactId:      _posContactId,
    contactName:    contact?.name || null,
    basketDiscount: _posBasketDiscount,
    lines:          _posCart.map(l => ({...l})),
  };
  // Persist to DB
  let dbId = null;
  try {
    const r = await fetch('/api/ts/parked', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({session_id: _posSession?.id || null, label, cart_data: cartData}),
    });
    const j = await r.json();
    if (j.ok) dbId = j.data.id;
  } catch (_) {}
  _posParkedCarts.push({
    id:             dbId || (++_posParkedSeq),
    dbId,
    ts:             new Date(),
    label,
    contactId:      _posContactId,
    contactName:    contact?.name || null,
    basketDiscount: _posBasketDiscount,
    cart:           _posCart.map(l => ({...l})),
  });
  _posCart           = [];
  _posContactId      = null;
  _posBasketDiscount = 0;
  _posRenderCart();
  toast('Sale parked');
}

function _posOpenParked() {
  const existing = document.getElementById('pos-held-modal');
  if (existing) { existing.remove(); return; }
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-held-modal';
  document.body.appendChild(bd);
  _posRenderParkedModal();
}

function _posRenderParkedModal() {
  const bd = document.getElementById('pos-held-modal');
  if (!bd) return;
  const rows = _posParkedCarts.map(p => {
    const t = p.ts instanceof Date
      ? p.ts.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})
      : (p.ts || '').slice(11, 16);
    const lines = p.cart || p.lines || [];
    const lineTotal = lines.reduce((s, l) => s + (l.total ?? (l.qty * l.unit_price * (l.tax_code === 'GST' ? 1.1 : 1.0))), 0);
    const discRatio = 1 - (p.basketDiscount || 0) / 100;
    const total = Math.round(lineTotal * discRatio * 100) / 100;
    const itemCount = lines.reduce((s, l) => s + (l.qty || 0), 0);
    const discNote = p.basketDiscount ? ` <span style="color:var(--red);font-size:11px">${p.basketDiscount}% off</span>` : '';
    const label = p.label || p.contactName || 'Walk-In';
    return `<div class="pos-held-row">
      <div class="pos-held-info">
        <div class="pos-held-name">${_esc(label)}</div>
        <div class="pos-held-meta">${t} &bull; ${itemCount} item${itemCount !== 1 ? 's' : ''} &bull; $${total.toFixed(2)}${discNote}</div>
      </div>
      <div class="pos-held-actions">
        <button class="btn btn-sm btn-primary" onclick="_posResumeSale(${p.id})">Resume</button>
        <button class="btn btn-sm btn-danger" onclick="_posDeleteParked(${p.id})">✕</button>
      </div>
    </div>`;
  }).join('');
  bd.innerHTML = `<div class="modal-box" style="max-width:440px">
    <div class="modal-hdr">
      <span>Held Sales</span>
      <button class="modal-close" onclick="document.getElementById('pos-held-modal')?.remove()">✕</button>
    </div>
    <div class="modal-body" style="padding:0">
      ${rows || '<div style="padding:20px;text-align:center;color:var(--ink3)">No held sales</div>'}
    </div>
  </div>`;
}

function _posResumeSale(id) {
  const parked = _posParkedCarts.find(p => p.id === id);
  if (!parked) return;
  if (_posCart.length) {
    const bd = document.getElementById('pos-held-modal');
    if (bd) bd.remove();
    const conf = document.createElement('div');
    conf.className = 'modal-bd';
    conf.style.display = 'flex';
    conf.id = 'pos-held-conf';
    conf.innerHTML = `<div class="modal-box" style="max-width:360px">
      <div class="modal-hdr">Resume Held Sale</div>
      <div class="modal-body" style="padding:16px">
        <p style="color:var(--ink2);margin:0 0 12px">You have an active cart. What would you like to do with it?</p>
      </div>
      <div class="modal-foot" style="gap:8px">
        <button class="btn btn-sec" onclick="document.getElementById('pos-held-conf')?.remove()">Cancel</button>
        <button class="btn" onclick="_posDiscardAndResume(${id})">Discard &amp; Resume</button>
        <button class="btn btn-primary" onclick="_posParkAndResume(${id})">Park &amp; Resume</button>
      </div>
    </div>`;
    document.body.appendChild(conf);
    return;
  }
  _posDoResume(id);
}

function _posDiscardAndResume(id) {
  document.getElementById('pos-held-conf')?.remove();
  _posCart           = [];
  _posContactId      = null;
  _posBasketDiscount = 0;
  _posLinkedTabId    = null;
  _posDoResume(id);
}

function _posParkAndResume(id) {
  document.getElementById('pos-held-conf')?.remove();
  if (_posCart.length) _posParkSale();
  _posDoResume(id);
}

function _posDoResume(id) {
  const idx = _posParkedCarts.findIndex(p => p.id === id);
  if (idx === -1) return;
  const parked = _posParkedCarts.splice(idx, 1)[0];
  const lines = parked.cart || parked.lines || [];
  _posCart           = lines.map(l => ({...l}));
  _posContactId      = parked.contactId || null;
  _posBasketDiscount = parked.basketDiscount || 0;
  _posLinkedTabId    = parked.tabId || null;
  // Delete from DB if it was persisted
  if (parked.dbId) {
    fetch(`/api/ts/parked/${parked.dbId}`, {method:'DELETE'}).catch(()=>{});
  }
  document.getElementById('pos-held-modal')?.remove();
  _posRenderCart();
  toast('Sale resumed');
}

function _posDeleteParked(id) {
  const parked = _posParkedCarts.find(p => p.id === id);
  if (parked?.dbId) {
    fetch(`/api/ts/parked/${parked.dbId}`, {method:'DELETE'}).catch(()=>{});
  }
  _posParkedCarts = _posParkedCarts.filter(p => p.id !== id);
  _posRenderCartHdrBtns();
  if (!_posParkedCarts.length) {
    document.getElementById('pos-held-modal')?.remove();
  } else {
    _posRenderParkedModal();
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// CUSTOMER PICKER
// ═══════════════════════════════════════════════════════════════════════════

function _posRenderCustomerBar() {
  const el = document.getElementById('pos-customer-bar');
  if (!el) return;
  const name = _posContactId
    ? (_posContacts.find(c => c.id == _posContactId)?.name || 'Unknown')
    : null;
  el.innerHTML = name
    ? `<div class="pos-cust-row pos-cust-set">
         <span class="pos-cust-icon">👤</span>
         <span class="pos-cust-name">${_esc(name)}</span>
         <button class="pos-cust-clear" onclick="_posClearCustomer()" title="Remove customer">✕</button>
       </div>`
    : `<button class="pos-cust-btn" onclick="_posPickCustomer()">+ Add Customer</button>`;
}

function _posClearCustomer() {
  _posContactId = null;
  _posRenderCart();
}

function _posPickCustomer() {
  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.style.display = 'flex';
  bd.id = 'pos-cust-modal';
  bd.innerHTML = `<div class="modal-box" style="max-width:420px">
    <div class="modal-hdr">
      <span>Select Customer</span>
      <div style="display:flex;gap:8px;align-items:center">
        <button class="btn btn-sm btn-sec" onclick="_posNewContactForm()">+ New Contact</button>
        <button class="modal-close" onclick="this.closest('.modal-bd').remove()">✕</button>
      </div>
    </div>
    <div class="modal-body" style="padding-top:10px">
      <input type="text" class="pos-sett-inp" id="pos-cust-search"
             placeholder="Search by name, phone, email or address…"
             oninput="_posCustFilter(this.value)" autocomplete="off" style="margin-bottom:10px">
      <div id="pos-cust-list" class="pos-cust-list"></div>
    </div>
  </div>`;
  document.body.appendChild(bd);
  _posCustFilter('');
  setTimeout(() => document.getElementById('pos-cust-search')?.focus(), 50);
}

function _posCustFilter(q) {
  const el = document.getElementById('pos-cust-list');
  if (!el) return;
  const lq = q.toLowerCase();
  const matches = _posContacts.filter(c => {
    if (!lq) return true;
    return (c.name        || '').toLowerCase().includes(lq)
        || (c.phone       || '').toLowerCase().includes(lq)
        || (c.email       || '').toLowerCase().includes(lq)
        || (c.address     || '').toLowerCase().includes(lq)
        || (c.city        || '').toLowerCase().includes(lq);
  });
  if (!matches.length) { el.innerHTML = '<div class="pos-cust-empty">No contacts found</div>'; return; }
  el.innerHTML = matches.slice(0, 50).map(c => {
    const sub = [c.phone, c.email].filter(Boolean).join(' · ');
    return `<div class="pos-cust-option" onclick="_posSelectCustomer(${c.id})">
      <div>${_esc(c.name)}</div>
      ${sub ? `<div class="pos-cust-sub">${_esc(sub)}</div>` : ''}
    </div>`;
  }).join('');
}

function _posSelectCustomer(id) {
  _posContactId = id;
  document.getElementById('pos-cust-modal')?.remove();
  _posRenderCart();
}

function _posNewContactForm() {
  const list = document.getElementById('pos-cust-list');
  const search = document.getElementById('pos-cust-search');
  if (search) search.style.display = 'none';
  if (!list) return;
  list.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:10px;padding:4px 0">
      <div>
        <label class="pos-sett-lbl">Name <span style="color:var(--red)">*</span></label>
        <input class="pos-sett-inp" id="pos-nc-name" type="text" autocomplete="off" placeholder="Contact name">
      </div>
      <div>
        <label class="pos-sett-lbl">Phone</label>
        <input class="pos-sett-inp" id="pos-nc-phone" type="text" autocomplete="off" placeholder="Phone number">
      </div>
      <div>
        <label class="pos-sett-lbl">Email</label>
        <input class="pos-sett-inp" id="pos-nc-email" type="email" autocomplete="off" placeholder="Email address">
      </div>
      <div>
        <label class="pos-sett-lbl">Address</label>
        <input class="pos-sett-inp" id="pos-nc-address" type="text" autocomplete="off" placeholder="Street address">
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:4px">
        <button class="btn btn-sec" onclick="_posCustFilter('');document.getElementById('pos-cust-search').style.display=''">Cancel</button>
        <button class="btn btn-primary" id="pos-nc-save" onclick="_posCreateContact(this)">Create Contact</button>
      </div>
    </div>`;
  setTimeout(() => document.getElementById('pos-nc-name')?.focus(), 50);
}

async function _posCreateContact(btn) {
  const name = (document.getElementById('pos-nc-name')?.value || '').trim();
  if (!name) { toast('Name is required', 'err'); return; }
  btn.disabled = true; btn.textContent = 'Saving…';
  try {
    const r = await fetch('/api/contacts', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        contact_type: 'Customer',
        name,
        phone:   (document.getElementById('pos-nc-phone')?.value  || '').trim(),
        email:   (document.getElementById('pos-nc-email')?.value  || '').trim(),
        address: (document.getElementById('pos-nc-address')?.value || '').trim(),
        is_active: 1,
      }),
    }).then(r => r.json());
    if (!r.ok) throw new Error(r.error || 'Save failed');
    const newContact = { id: r.data.id, name, phone: document.getElementById('pos-nc-phone')?.value || '',
                         email: document.getElementById('pos-nc-email')?.value || '' };
    _posContacts.push(newContact);
    _posContacts.sort((a, b) => a.name.localeCompare(b.name));
    _posSelectCustomer(r.data.id);
    toast('Contact created');
  } catch(e) {
    toast(e.message || 'Save failed', 'err');
    btn.disabled = false; btn.textContent = 'Create Contact';
  }
}


// ═══════════════════════════════════════════════════════════════════════════
// CART RENDER
// ═══════════════════════════════════════════════════════════════════════════

function _posRenderCartHdrBtns() {
  const el = document.getElementById('pos-cart-hdr-btns');
  if (!el) return;
  const hasCart   = _posCart.length > 0;
  const heldCount = _posParkedCarts.length;
  const heldBtn   = heldCount > 0
    ? `<button class="pos-zrpt-btn pos-held-btn" onclick="_posOpenParked()">Held (${heldCount})</button>`
    : '';
  const parkBtn = hasCart
    ? `<button class="pos-zrpt-btn" onclick="_posParkSale()">Park</button>`
    : '';
  el.innerHTML = `
    <button class="pos-zrpt-btn" onclick="_posOpenSessionHistory()">Sessions</button>
    <button class="pos-zrpt-btn" onclick="_posOpenZReport()">End Day</button>
    <button class="pos-zrpt-btn" onclick="_posOpenAnalytics()">Analytics</button>
    ${heldBtn}${parkBtn}
    <button class="pos-clear-btn" onclick="_posClearCart()">Clear</button>`;
}

function _posRenderCart() {
  _posRenderCustomerBar();
  _posRenderCartHdrBtns();
  const linesEl  = document.getElementById('pos-cart-lines');
  const totalsEl = document.getElementById('pos-totals');
  const btnsEl   = document.getElementById('pos-tender-btns');
  if (!linesEl) return;

  if (!_posCart.length) {
    linesEl.innerHTML  = '<div class="pos-cart-empty">Cart is empty—tap items to add</div>';
    totalsEl.innerHTML = '';
    btnsEl.innerHTML   = `
      <button class="pos-btn pos-btn-cash" disabled>Cash</button>
      <button class="pos-btn pos-btn-card" disabled>Card</button>
      <button class="pos-btn pos-btn-split" disabled>Split</button>`;
    return;
  }

  linesEl.innerHTML = _posCart.map((l, idx) => `
    <div class="pos-cart-line">
      <div class="pos-cart-desc">${_esc(l.description)}</div>
      <div class="pos-cart-qty">
        <button class="pos-qty-btn" onclick="_posQtyDelta(${idx},-1)">&#x2212;</button>
        <input class="pos-qty-inp" type="number" min="0.001" step="0.001" value="${l.qty}"
               onchange="_posSetQty(${idx},this.value)" onclick="this.select()">
        <button class="pos-qty-btn" onclick="_posQtyDelta(${idx},1)">+</button>
      </div>
      <div class="pos-price-wrap">
        <span class="pos-price-dollar">$</span>
        <input class="pos-price-inp" type="number" min="0" step="0.01"
               value="${l.unit_price.toFixed(2)}"
               onchange="_posPriceChange(${idx},this.value)" onclick="this.select()"
               title="Unit price">
      </div>
      <div class="pos-disc-wrap">
        <input class="pos-disc-inp" type="number" min="0" max="100" step="1"
               value="${l.discount || 0}"
               onchange="_posDiscountChange(${idx},this.value)" onclick="this.select()"
               title="Discount %">
        <span class="pos-disc-pct">%</span>
      </div>
      <div class="pos-cart-price">$${l.total.toFixed(2)}</div>
      <button class="pos-rm-btn" onclick="_posRemoveLine(${idx})" title="Remove">&#x2715;</button>
    </div>`).join('');

  const subtotal = _posCart.reduce((s, l) => s + (l.total - l.gst), 0);
  const gst      = _posCart.reduce((s, l) => s + l.gst, 0);
  const total    = _posCart.reduce((s, l) => s + l.total, 0);

  const discRatio   = 1 - (_posBasketDiscount || 0) / 100;
  const discAmt     = Math.round((total - total * discRatio) * 100) / 100;
  const finalTotal  = Math.round(total * discRatio * 100) / 100;
  const discRow = (_posBasketDiscount > 0)
    ? `<div class="pos-total-row pos-disc-basket-row"><span>Discount (${_posBasketDiscount}%)</span><span style="color:var(--red)">-$${discAmt.toFixed(2)}</span></div>`
    : '';

  totalsEl.innerHTML = `
    <div class="pos-total-row"><span>Subtotal (ex GST)</span><span>$${subtotal.toFixed(2)}</span></div>
    <div class="pos-total-row"><span>GST</span><span>$${gst.toFixed(2)}</span></div>
    <div class="pos-disc-basket-wrap">
      <span class="pos-disc-basket-lbl">% Discount</span>
      <input class="pos-disc-basket-inp" type="number" min="0" max="100" step="1"
             value="${_posBasketDiscount || ''}" placeholder="0"
             onchange="_posBasketDiscChange(this.value)" onclick="this.select()">
      <span class="pos-disc-basket-pct">%</span>
    </div>
    ${discRow}
    <div class="pos-total-row pos-grand-total"><span>TOTAL</span><span>$${finalTotal.toFixed(2)}</span></div>`;

  const selContact = _posContactId ? _posContacts.find(c => c.id == _posContactId) : null;
  const acctBtn = (selContact?.approved_account)
    ? `<button class="pos-btn pos-btn-account" onclick="_posCheckStockWarnings(function(){_posTenderAccount(${finalTotal.toFixed(4)});})">Account</button>`
    : '';
  btnsEl.innerHTML = `
    <button class="pos-btn pos-btn-cash" onclick="_posCheckStockWarnings(function(){_posTenderCash(${finalTotal.toFixed(4)});})">Cash</button>
    <button class="pos-btn pos-btn-card" onclick="_posCheckStockWarnings(function(){_posTenderCard(${finalTotal.toFixed(4)});})">Card</button>
    <button class="pos-btn pos-btn-split" onclick="_posCheckStockWarnings(function(){_posTenderSplit(${finalTotal.toFixed(4)});})">Split</button>
    ${acctBtn}`;
}


// ═══════════════════════════════════════════════════════════════════════════
// STOCK WARNING
// ═══════════════════════════════════════════════════════════════════════════

function _posCheckStockWarnings(onProceed) {
  const warnings = [];
  _posCart.forEach(function(line) {
    if (!line.item_id) return; // custom line items have no stock
    const item = _posItems.find(function(i) { return i.id === line.item_id; });
    if (!item || !item.is_inventoried) return;
    const qtyAfter  = (parseFloat(item.qty_on_hand) || 0) - line.qty;
    const reorder   = parseFloat(item.reorder_level) || 0;
    const isOut     = qtyAfter < 0;
    const isLow     = !isOut && reorder > 0 && qtyAfter <= reorder;
    if (isOut || isLow) {
      warnings.push({ name: line.description, qtyAfter: qtyAfter, reorder: reorder, isOut: isOut });
    }
  });
  if (!warnings.length) { onProceed(); return; }

  _posStockWarnProceedFn = onProceed;

  var rows = '';
  warnings.forEach(function(w) {
    var cls   = w.isOut ? 'pos-sw-row out' : 'pos-sw-row low';
    var badge = w.isOut ? '<span class="pos-sw-badge out">Oversell</span>' : '<span class="pos-sw-badge low">Low stock</span>';
    var qty   = w.isOut
      ? (w.qtyAfter < 0 ? w.qtyAfter.toFixed(0) : '0') + ' (negative)'
      : w.qtyAfter.toFixed(w.qtyAfter % 1 === 0 ? 0 : 1) + ' remaining (reorder: ' + w.reorder + ')';
    rows += '<tr class="' + cls + '">'
      + '<td>' + _esc(w.name) + '</td>'
      + '<td>' + badge + '</td>'
      + '<td>' + qty + '</td>'
      + '</tr>';
  });

  const bd = document.createElement('div');
  bd.className = 'modal-bd';
  bd.id = 'pos-stock-warn-bd';
  bd.style.display = 'flex';
  bd.innerHTML = '<div class="modal-box">'
    + '<div class="modal-hdr">Stock Warning</div>'
    + '<div class="modal-body">'
    + '<p class="pos-sw-intro">The following items have insufficient stock:</p>'
    + '<table class="pos-sw-table"><thead><tr><th>Item</th><th>Status</th><th>After sale</th></tr></thead>'
    + '<tbody>' + rows + '</tbody></table>'
    + '<p class="pos-sw-q">Proceed anyway?</p>'
    + '</div>'
    + '<div class="modal-foot">'
    + '<button class="btn btn-danger" onclick="_posStockWarnProceed()">Proceed</button>'
    + '<button class="btn" onclick="document.getElementById(\'pos-stock-warn-bd\').remove()">Cancel</button>'
    + '</div></div>';
  document.body.appendChild(bd);
}

function _posStockWarnProceed() {
  document.getElementById('pos-stock-warn-bd')?.remove();
  if (_posStockWarnProceedFn) { _posStockWarnProceedFn(); _posStockWarnProceedFn = null; }
}
