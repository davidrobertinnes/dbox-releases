# Dogbox Accounting Web Interface

A full-featured web UI for dbox, served by Flask.

## Quick Start

```bash
# Install Flask (one-time)
pip install flask

# Start the web server (opens your existing .dbox database)
python web/server.py your_company.dbox

# Or create a fresh database
python web/server.py

# Then open: http://localhost:5000
# Default login: admin / admin
```

## Options

```
python web/server.py [database_file] [--port 5000] [--host 127.0.0.1]

# Examples:
python web/server.py company.dbox --port 8080
python web/server.py company.dbox --host 0.0.0.0  # accessible on network
```

## Features in Web Interface

| Feature | Web | Desktop |
|---------|-----|---------|
| Dashboard (balances, KPIs, quick actions) | ✅ Full | ✅ Full |
| General Journal (post, edit, void, reverse) | ✅ Full | ✅ Full |
| Credit Cards (charges, payments, statements) | ✅ Full | ✅ Full |
| Recurring Transactions (create, process, manage) | ✅ Full | ✅ Full |
| Jobs / Project Costing (P&L, allocations) | ✅ Full | ✅ Full |
| Reports (P&L, Balance Sheet, Trial Balance) | ✅ Full | ✅ Full |
| Invoice Viewing | ✅ View | ✅ Full |
| Bill Viewing | ✅ View | ✅ Full |
| Contacts & Accounts | ✅ View + Create | ✅ Full |
| Payroll | ✅ View | ✅ Full (STP, payslips) |
| Bank Reconciliation | ✗ | ✅ Full |
| Email Invoices | ✗ | ✅ Full |
| PDF Payslips | ✗ | ✅ Full |
| Custom Themes | ✗ | ✅ Full |

## Architecture

```
web/
  server.py          Flask app — 54 REST API routes + SPA serving
  templates/
    login.html       Elegant login page
    app.html         Full SPA (single-page application) — all pages in JS
```

The web interface reads and writes to the same `.dbox` SQLite database 
as the desktop app. You can switch between desktop and web seamlessly.

## REST API

All endpoints return `{"ok": true, "data": ...}` or `{"ok": false, "error": "..."}`.

Key endpoints:
- `POST /api/login` — authenticate
- `GET  /api/dashboard` — summary stats
- `GET/POST /api/journal` — journal entries
- `POST /api/journal/:id/void` — void entry
- `POST /api/journal/:id/reverse` — reverse entry
- `GET/POST /api/recurring` — recurring templates
- `POST /api/recurring/process` — process due transactions
- `GET/POST /api/jobs` — job management
- `POST /api/jobs/:id/allocate` — allocate transaction to job
- `GET /api/credit-cards` — card balances
- `POST /api/credit-cards/charge` — record charge
- `POST /api/credit-cards/payment` — record payment
- `GET /api/reports/profit-loss` — P&L report
- `GET /api/reports/balance-sheet` — balance sheet
- `GET /api/reports/trial-balance` — trial balance
