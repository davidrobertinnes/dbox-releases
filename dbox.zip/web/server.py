# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

"""
Dogbox Accounting Web Interface
Run: python web_server.py [path/to/file.dbox]
Then open http://localhost:5000
"""

import sys, os, argparse
from flask import Flask, request, redirect

# Make sure parent dir is on path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.database import initialise_database, seed_defaults, get_connection
from core.budget   import ensure_default_admin
from core.purchase_orders import migrate_purchase_orders
from core.fixed_assets    import migrate_fixed_assets as _migrate_fixed_assets

# ── App setup ──────────────────────────────────────────────────────────────────
app = Flask(__name__,
            static_folder=os.path.join(os.path.dirname(__file__), "static"),
            static_url_path="/static")

app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    PERMANENT_SESSION_LIFETIME=28800,   # 8-hour sessions
    SEND_FILE_MAX_AGE_DEFAULT=0,        # always serve fresh static files (local app)
)
app.secret_key = b"placeholder-overwritten-by-launcher"

# Kept for backward compatibility with web_server.py which sets _srv.DB_PATH
DB_PATH = None


def _derive_secret_key(db_path: str) -> bytes:
    import hashlib, secrets as _sec
    if not db_path or not os.path.exists(db_path):
        return _sec.token_bytes(32)
    seed = f"dbox-web-{os.path.abspath(db_path)}-{os.stat(db_path).st_ino}"
    return hashlib.sha256(seed.encode()).digest()


# ── Blueprints ─────────────────────────────────────────────────────────────────
from web.routes.startup      import bp as startup_bp
from web.routes.auth         import bp as auth_bp
from web.routes.dashboard    import bp as dashboard_bp
from web.routes.reports      import bp as reports_bp
from web.routes.payroll      import bp as payroll_bp
from web.routes.purchase_orders import bp as po_bp
from web.routes.bills        import bp as bills_bp
from web.routes.bankrec      import bp as bankrec_bp
from web.routes.jobs         import bp as jobs_bp
from web.routes.fixed_assets import bp as fa_bp
from web.routes.accounts     import bp as accounts_bp
from web.routes.inventory    import bp as inventory_bp
from web.routes.attachments  import bp as attachments_bp
from web.routes.contacts     import bp as contacts_bp
from web.routes.invoices     import bp as invoices_bp
from web.routes.payments     import bp as payments_bp
from web.routes.journal      import bp as journal_bp
from web.routes.credit_cards import bp as cc_bp
from web.routes.company      import bp as company_bp
from web.routes.users        import bp as users_bp
from web.routes.admin        import bp as admin_bp
from web.routes.settings     import bp as settings_bp
from web.routes.backup          import bp as backup_bp
from web.routes.system          import bp as system_bp
from web.routes.expense_claims  import bp as expense_claims_bp
from web.routes.help            import bp as help_bp
from web.routes.pos             import bp as pos_bp
from web.routes.table_service   import bp as table_service_bp

app.register_blueprint(startup_bp)
app.register_blueprint(auth_bp)
app.register_blueprint(dashboard_bp)
app.register_blueprint(reports_bp)
app.register_blueprint(payroll_bp)
app.register_blueprint(po_bp)
app.register_blueprint(bills_bp)
app.register_blueprint(bankrec_bp)
app.register_blueprint(jobs_bp)
app.register_blueprint(fa_bp)
app.register_blueprint(accounts_bp)
app.register_blueprint(inventory_bp)
app.register_blueprint(attachments_bp)
app.register_blueprint(contacts_bp)
app.register_blueprint(invoices_bp)
app.register_blueprint(payments_bp)
app.register_blueprint(journal_bp)
app.register_blueprint(cc_bp)
app.register_blueprint(company_bp)
app.register_blueprint(users_bp)
app.register_blueprint(admin_bp)
app.register_blueprint(settings_bp)
app.register_blueprint(backup_bp)
app.register_blueprint(system_bp)
app.register_blueprint(expense_claims_bp)
app.register_blueprint(help_bp)
app.register_blueprint(pos_bp)
app.register_blueprint(table_service_bp)


_NO_DB_PASSTHROUGH = {'/api/alive', '/api/system/close-beacon'}

@app.before_request
def _require_db():
    """Redirect all routes to /startup while no company file is loaded."""
    if app.config.get('DEMO_MODE'):
        return  # demo_server.py before_request hook handles DB assignment
    if app.config.get('DB_PATH') is None:
        if (not request.path.startswith('/startup')
                and not request.path.startswith('/static')
                and request.path not in _NO_DB_PASSTHROUGH):
            return redirect('/startup')


# ── File picker (CLI fallback) ─────────────────────────────────────────────────
def _pick_db_file() -> str:
    """
    Show a native file dialog to open or create a .dbox file.
    Returns the absolute path chosen, or exits if the user cancels.
    Falls back to a console prompt if tkinter is unavailable.
    """
    import pathlib

    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)

        choice = messagebox.askquestion(
            "dogbox — Open File",
            "Do you want to open an existing company file?\n\n"
            "Select Yes to open an existing .dbox file.\n"
            "Select No to create a new company file.",
            icon="question",
        )

        if choice == "yes":
            path = filedialog.askopenfilename(
                parent=root,
                title="Open Company File",
                filetypes=[("dbox company files", "*.dbox"), ("All files", "*.*")],
                initialdir=str(pathlib.Path.home()),
            )
        else:
            path = filedialog.asksaveasfilename(
                parent=root,
                title="Create New Company File",
                defaultextension=".dbox",
                filetypes=[("dbox company files", "*.dbox")],
                initialdir=str(pathlib.Path.home()),
                initialfile="company.dbox",
            )

        root.destroy()

        if not path:
            print("No file selected — exiting.")
            sys.exit(0)

        return os.path.abspath(path)

    except Exception:
        print("\ndogbox Web Interface")
        print("─" * 40)
        print("Enter path to .dbox file (or press Enter for 'dbox_data.db'):")
        path = input("> ").strip()
        if not path:
            path = "dbox_data.db"
        return os.path.abspath(path)


# ── Main ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="dogbox Web Interface")
    parser.add_argument("db_file", nargs="?", default=None,
                        help="Path to .dbox file (optional — shows file picker if omitted)")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--host", default="127.0.0.1")
    args = parser.parse_args()

    if args.db_file:
        db_path = os.path.abspath(args.db_file)
    else:
        db_path = _pick_db_file()

    app.config['DB_PATH'] = db_path
    app.secret_key = _derive_secret_key(db_path)

    print(f"\n  dogbox Web Interface")
    print(f"  {'─' * 37}")
    print(f"  Database : {db_path}")

    initialise_database(db_path)
    seed_defaults(db_path)
    ensure_default_admin(db_path)

    conn = get_connection(db_path)
    migrate_purchase_orders(conn)
    conn.commit()
    conn.close()
    conn2 = get_connection(db_path)
    _migrate_fixed_assets(conn2)
    conn2.close()

    print(f"  Login    : admin / admin  (change after first login)")
    print(f"  Open     : http://{args.host}:{args.port}\n")

    import threading, webbrowser
    url = f"http://{args.host}:{args.port}"
    def _open_browser():
        import time; time.sleep(1.2)
        webbrowser.open(url)
    threading.Thread(target=_open_browser, daemon=True).start()

    app.run(host=args.host, port=args.port, debug=False, threaded=True)
