"""
Dogbox Accounting Web Interface
Run: python web/server.py [path/to/file.dbox]
Then open http://localhost:5000
"""
# Copyright © 2026 David Robert Innes trading as Dogbox Software
# ABN 40 986 160 328 — All rights reserved.
# Unauthorised copying, modification, or distribution is prohibited.

import sys, os, json, argparse, sqlite3, subprocess
import urllib.request, zipfile, shutil, tempfile
from datetime import date, timedelta
from functools import wraps
from flask import (Flask, render_template, request, jsonify,
                   session, redirect, url_for, abort, send_file)

# Make sure parent dir is on path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# ── App version ───────────────────────────────────────────────────────────────
_VERSION_FILE = os.path.join(os.path.dirname(__file__), '..', 'version.txt')
APP_VERSION   = open(_VERSION_FILE).read().strip() if os.path.exists(_VERSION_FILE) else 'dev'
_UPDATE_URL   = 'https://raw.githubusercontent.com/davidrobertinnes/dbox-releases/main/version.json'
_update_cache: dict = {}           # {version, notes, url, checked_at}
_update_prog:  dict = {'state': 'idle', 'pct': 0, 'error': None}

from core.database  import initialise_database, seed_defaults, get_connection
from core.ledger    import (
    get_accounts, save_account, get_account_balance, get_account_balances_batch,
    get_contacts, save_contact,
    get_invoices, get_invoice, save_invoice, void_invoice, mark_invoice_sent,
    get_bills, get_bill, save_bill, void_bill, mark_bill_approved,
    get_payments, get_payment, record_payment, void_payment, amend_payment,
    post_journal, get_journal_entries_full, get_journal_entry,
    update_journal, void_journal, reverse_journal,
    get_credit_card_accounts, record_credit_card_charge,
    record_credit_card_payment, get_credit_card_transactions,
    get_credit_card_balance, trial_balance, profit_and_loss, balance_sheet,
    get_account_ledger,
    get_monthly_totals, bas_report, aged_receivables, aged_payables,
    cash_flow_statement,
    get_bank_transactions, import_bank_csv, import_transactions,
    get_bank_journal_transactions, reconcile_journal_line,
    allocate_bank_transaction, deallocate_bank_transaction,
    reconcile_transaction, get_last_reconciliation, complete_reconciliation,
    repair_orphaned_void_journals,
    repair_missing_gl_journals,
)
from core.reports_pdf import (
    render_pl_pdf, render_bs_pdf, render_tb_pdf, render_bas_pdf, render_ias_pdf,
    render_aged_pdf, render_cash_flow_pdf, render_statement_of_account_pdf,
)
from core.crm import (
    get_crm_dashboard, get_pipeline_summary, PIPELINE_STAGES,
    COMM_TYPES, TASK_TYPES, PRIORITY, QUOTE_STATUS,
    get_opportunities, get_opportunity, save_opportunity, delete_opportunity,
    next_opp_number, next_quote_number,
    get_communications, save_communication, delete_communication,
    get_tasks, save_task, complete_task, delete_task,
    get_quotes, get_quote, save_quote, accept_quote,
    convert_quote_to_invoice, delete_quote,
    get_progress_claims, save_progress_claim, claim_to_invoice, delete_progress_claim,
)
from core.budget    import (
    authenticate_user, ensure_default_admin, audit,
    get_users, get_user, create_user, update_user, set_own_password,
    get_audit_log,
    get_budget_periods, get_budget_period, build_actual_vs_budget_report,
    create_budget_period, delete_budget_period,
    get_budget_lines, save_budget_lines,
    generate_budget_csv_template, import_budget_csv,
)
from core.jobs      import (
    get_jobs, get_job, save_job, delete_job, get_job_pl,
    get_job_transactions, allocate_transaction, deallocate_transaction,
    get_unallocated_invoices, get_unallocated_bills, get_unallocated_payments,
    next_job_number, get_job_for_bill, set_bill_job,
    get_job_time_entries, save_job_time_entry, delete_job_time_entry,
)
from core.recurring import (
    get_templates, get_template, save_template, delete_template,
    get_upcoming, get_runs, process_due_templates, FREQUENCIES, TEMPLATE_TYPES,
)
from core.payroll   import (
    get_employees, get_employee, save_employee,
    get_pay_runs, get_pay_run, calculate_payslip,
    create_pay_run, finalise_pay_run, void_pay_run,
    super_rate, current_fy, PAY_FREQUENCIES, EMPLOYMENT_TYPES,
    next_employee_number, LEAVE_TYPES, ALLOWANCE_TYPES,
    get_stp_submissions, lodge_stp, lodge_stp_finalisation,
    generate_payslip_pdf,
    get_super_payments, get_super_payment, get_super_accruals,
    create_super_payment, finalise_super_payment,
    generate_super_remittance_pdf, _super_quarter,
    get_payslips_for_employee,
    load_payg_rates, save_payg_rates, list_payg_rate_years,
    payg_for_period,
    get_payg_summary, render_payg_summary_pdf, reset_ytd,
    generate_payrun_report_pdf,
    generate_outstanding_leave_pdf, generate_outstanding_leave_csv,
)
from core.awards import (
    get_awards, get_award, save_award, delete_award,
    get_classifications, get_classification, save_classification, delete_classification,
    get_pay_rates, get_current_rate, save_pay_rate, delete_pay_rate,
    get_award_allowances, save_award_allowance, delete_award_allowance,
    get_penalty_rates, save_penalty_rate, delete_penalty_rate,
    resolve_rate_from_classification, get_employees_by_award,
    bulk_apply_wage_increase,
    INSTRUMENT_TYPES, ALLOWANCE_TYPES, PENALTY_TYPES,
)
from core.items import get_items, get_item, save_item, delete_item
from core.attachments import (get_attachments, add_attachment, delete_attachment,
                               get_attachment_data, attachment_count)
from core.inventory import (
    get_stock_receipts, create_stock_receipt, post_stock_movement,
    get_inventory_items, get_inventory_item, get_stock_movements, get_stock_summary,
    get_inventory_analytics, adjust_stock, stock_valuation_report,
    save_inventory_settings, get_livestock_trading_statement,
    get_livestock_category_list,
)
from core.purchase_orders import (
    get_purchase_orders, get_purchase_order, save_purchase_order,
    cancel_purchase_order, receive_po_lines, convert_po_to_bill,
    render_po_pdf, migrate_purchase_orders, create_po_from_crm_quote,
)
from core.leave import (
    get_leave_types, get_leave_type, save_leave_type,
    get_leave_balances, initialise_employee_leave,
    get_leave_requests, get_leave_request, save_leave_request,
    approve_leave, decline_leave, cancel_leave,
    get_medical_certs, save_medical_cert, delete_medical_cert,
    get_public_holidays, save_public_holiday, delete_public_holiday,
    post_accrual, get_accrual_history,
)
from core.licence import get_licence_status, watermark_text, status_banner
from core.fixed_assets import (
    get_fixed_assets, get_fixed_asset, save_fixed_asset, delete_fixed_asset,
    get_depn_schedule, regenerate_schedule,
    post_depreciation_journal, post_all_fy_depreciation,
    dispose_asset, asset_register_report,
    lookup_ato_life, get_class_defaults,
    ASSET_CLASS_BY_KEY, ASSET_CLASSES,
)
from core.fixed_assets import migrate_fixed_assets as _migrate_fixed_assets
from core.warranty import (
    get_warranties, get_warranty, save_warranty, delete_warranty, lodge_claim,
    get_linked_attachments, set_linked_attachments,
    CLAIM_OUTCOMES,
)

# ── Tier capability sets ───────────────────────────────────────────────────────
# Mirrors ui/app.py TIER_CAPS exactly. Each tier is a strict superset of the one above.
TIER_CAPS = {
    "cashbook": {
        "dashboard", "contacts", "accounts", "journal",
        "payments", "bankrec", "reports", "users",
    },
    "invoices": {
        "dashboard", "contacts", "accounts", "journal",
        "payments", "bankrec", "reports", "users",
        "invoices", "quotes", "bills", "recurring",
        "aged", "budget",
    },
    "payroll": {
        "dashboard", "contacts", "accounts", "journal",
        "payments", "bankrec", "reports", "users",
        "invoices", "quotes", "bills", "recurring",
        "aged", "budget",
        "payroll",
    },
    "full": {
        "dashboard", "contacts", "accounts", "journal",
        "payments", "bankrec", "reports", "users",
        "invoices", "quotes", "bills", "recurring",
        "aged", "budget",
        "payroll",
        "crm", "jobs", "items", "inventory", "promotions",
        "sales_catalogue", "fixed_assets",
        "warranties", "purchase_orders", "credit_cards",
    },
}

TIER_LABELS = {
    "cashbook": "Cashbook",
    "invoices": "Invoices & Bills",
    "payroll":  "Payroll",
    "full":     "Full",
}

def _get_tier(db_path: str) -> str:
    """
    Read tier from the company table. Falls back to 'full' so that a missing
    or malformed row never locks anyone out unexpectedly — the licence check
    in the desktop app is the authoritative gate.
    """
    if not db_path:
        return "full"
    try:
        conn = get_connection(db_path)
        row  = conn.execute("SELECT tier FROM company LIMIT 1").fetchone()
        conn.close()
        if row and row["tier"] in TIER_CAPS:
            return row["tier"]
    except Exception:
        pass
    return "full"


def _get_pdf_watermark() -> str | None:
    """
    Return a watermark string for PDFs if the licence is invalid/missing/lapsed,
    or None if fully licenced. Mirrors get_watermark() from ui/shared.py.
    The app_dir search matches app.py: one level up from server.py (web/).
    """
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
        return watermark_text(status)
    except Exception:
        return "Unregistered"


def _get_licence_status() -> dict:
    """Return the full licence status dict, with safe fallback."""
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        return get_licence_status(_app_dir)
    except Exception:
        return {"status": "missing", "tier": None, "is_eval": False,
                "is_permanent": False, "days_remaining": None,
                "issued_to": None, "eval_expiry": None, "path": None}


# ── App setup ──────────────────────────────────────────────────────────────────
app = Flask(__name__,
            static_folder=os.path.join(os.path.dirname(__file__), "static"),
            static_url_path="/static")
# Derive a stable secret key from the DB path so sessions survive restarts.
# Falls back to random if no DB path is available yet.
def _derive_secret_key(db_path: str) -> bytes:
    import hashlib, secrets as _sec
    if not db_path or not os.path.exists(db_path):
        return _sec.token_bytes(32)
    # Use file inode + path + a fixed app salt for a stable but unpredictable key
    seed = f"dbox-web-{os.path.abspath(db_path)}-{os.stat(db_path).st_ino}"
    return hashlib.sha256(seed.encode()).digest()

app.config.update(
    SESSION_COOKIE_HTTPONLY=True,    # JS cannot read session cookie
    SESSION_COOKIE_SAMESITE="Lax",   # CSRF mitigation
    PERMANENT_SESSION_LIFETIME=28800  # 8-hour sessions
)
# Set by web_server.py after DB path is known — do not set randomly here
app.secret_key = b"placeholder-overwritten-by-launcher"

DB_PATH = None  # set on startup

# ── Startup / file-picker infrastructure ──────────────────────────────────────
_RECENT_PATH = os.path.join(os.path.expanduser('~'), '.dbox_recent.json')

def _load_recent() -> list:
    try:
        with open(_RECENT_PATH, encoding='utf-8') as fh:
            items = json.load(fh)
        return [p for p in items if isinstance(p, str) and os.path.isfile(p)][:8]
    except Exception:
        return []

def _add_recent(path: str):
    recent = _load_recent()
    path = os.path.abspath(path)
    if path in recent:
        recent.remove(path)
    recent.insert(0, path)
    try:
        with open(_RECENT_PATH, 'w', encoding='utf-8') as fh:
            json.dump(recent[:8], fh)
    except Exception:
        pass


_FILE_SVG = (
    '<svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"'
    ' style="width:14px;height:14px;fill:none;stroke:#185FA5;'
    'stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round">'
    '<path d="M3 2h7l3 3v9H3z"/><path d="M10 2v3h3"/>'
    '</svg>'
)

_LOGO_SVG = (
    '<svg viewBox="88 24 136 88" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'
    '<rect x="112" y="24" width="88" height="88" rx="14" fill="#185FA5"/>'
    '<rect x="88"  y="32" width="18" height="70" rx="9"  fill="#185FA5"/>'
    '<rect x="206" y="32" width="18" height="70" rx="9"  fill="#185FA5"/>'
    '<circle cx="140" cy="58" r="8"   fill="white"/>'
    '<circle cx="172" cy="58" r="8"   fill="white"/>'
    '<circle cx="141" cy="59" r="4"   fill="#185FA5"/>'
    '<circle cx="173" cy="59" r="4"   fill="#185FA5"/>'
    '<circle cx="142.5" cy="57" r="1.5" fill="white"/>'
    '<circle cx="174.5" cy="57" r="1.5" fill="white"/>'
    '<ellipse cx="156" cy="94" rx="10" ry="7"   fill="white"/>'
    '<ellipse cx="156" cy="93" rx="5"  ry="3.5" fill="#185FA5"/>'
    '</svg>'
)

_STARTUP_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>dbox &mdash; Open Company</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Mono:wght@300;400;500&family=Instrument+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;background:#EBF2FA;font-family:'Instrument Sans',sans-serif;color:#1A2E45;-webkit-font-smoothing:antialiased}
.page{min-height:100vh;display:grid;grid-template-columns:1fr 1fr}
.left{background:#1A2E45;display:flex;flex-direction:column;justify-content:center;padding:80px 72px;position:relative;overflow:hidden}
.left::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 70% 50% at 10% 90%,rgba(24,95,165,.4) 0%,transparent 60%),radial-gradient(ellipse 50% 40% at 90% 10%,rgba(24,95,165,.2) 0%,transparent 55%);pointer-events:none}
.left::after{content:'';position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.03) 1px,transparent 1px);background-size:32px 32px;pointer-events:none}
.left-content{position:relative;z-index:1}
.brand-wordmark{display:flex;align-items:center;gap:12px;margin-bottom:56px}
.brand-wordmark svg{width:40px;height:40px;flex-shrink:0}
.brand-wordmark-text{font-family:'Syne',sans-serif;font-size:26px;font-weight:800;letter-spacing:-.5px;color:#fff}
.brand-wordmark-text span{color:#185FA5}
.left h1{font-family:'Syne',sans-serif;font-size:42px;line-height:1.1;font-weight:700;color:#fff;letter-spacing:-1px;margin-bottom:18px}
.left h1 em{font-style:normal;color:#5b8dee}
.left-desc{font-size:15px;line-height:1.65;color:#6B8BAA;max-width:340px;margin-bottom:52px}
.features{display:flex;flex-direction:column;gap:11px}
.feature{display:flex;align-items:center;gap:10px;font-size:13px;color:#8facc8;font-family:'DM Mono',monospace}
.feature-dot{width:5px;height:5px;background:#185FA5;border-radius:50%;flex-shrink:0}
.right{display:flex;flex-direction:column;justify-content:center;align-items:center;padding:80px 72px;background:#EBF2FA}
.form-card{width:100%;max-width:360px;animation:fadeUp .3s ease both}
.form-heading{font-family:'Syne',sans-serif;font-size:28px;font-weight:700;letter-spacing:-.5px;color:#1A2E45;margin-bottom:6px}
.form-sub{font-size:13px;color:#6B8BAA;margin-bottom:28px;font-family:'DM Mono',monospace}
.btn-open{width:100%;padding:12px;background:#185FA5;color:#fff;border:none;border-radius:9px;font-family:'Syne',sans-serif;font-size:14px;font-weight:700;letter-spacing:.2px;cursor:pointer;margin-bottom:10px;transition:opacity .15s,transform .1s}
.btn-open:hover{opacity:.88}
.btn-open:active{transform:scale(.99)}
.btn-open:disabled{opacity:.5;cursor:not-allowed}
.btn-new{width:100%;padding:11px;background:transparent;color:#1A2E45;border:1.5px solid #C8DCEE;border-radius:9px;font-family:'Syne',sans-serif;font-size:14px;font-weight:600;cursor:pointer;transition:border-color .15s,color .15s}
.btn-new:hover{border-color:#185FA5;color:#185FA5}
.btn-new:disabled{opacity:.5;cursor:not-allowed}
.confirm-box{margin-top:16px;padding:14px 16px;background:#fff;border:1.5px solid #C8DCEE;border-radius:9px;display:none}
.confirm-label{font-size:9px;font-weight:500;letter-spacing:1.2px;text-transform:uppercase;font-family:'DM Mono',monospace;color:#6B8BAA;margin-bottom:6px}
.confirm-path{font-size:12px;font-family:'DM Mono',monospace;color:#1A2E45;word-break:break-all;margin-bottom:14px;line-height:1.5}
.confirm-btns{display:flex;gap:8px}
.confirm-btns .btn-open{flex:1;margin-bottom:0}
.btn-cancel{flex:1;padding:11px;background:transparent;color:#6B8BAA;border:1.5px solid #C8DCEE;border-radius:9px;font-family:'Syne',sans-serif;font-size:13px;font-weight:600;cursor:pointer;transition:border-color .15s,color .15s}
.btn-cancel:hover{border-color:#1A2E45;color:#1A2E45}
.error-msg{color:#A32D2D;font-size:12px;font-family:'DM Mono',monospace;margin-top:10px;min-height:18px}
.recent-sep{margin-top:28px;padding-top:22px;border-top:1px solid #C8DCEE;font-size:9px;font-weight:500;letter-spacing:1.2px;text-transform:uppercase;font-family:'DM Mono',monospace;color:#6B8BAA;margin-bottom:12px}
.recent-list{list-style:none;display:flex;flex-direction:column;gap:4px}
.recent-item{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;cursor:pointer;border:1.5px solid transparent;transition:border-color .12s,background .12s}
.recent-item:hover{background:#fff;border-color:#C8DCEE}
.recent-icon{width:30px;height:30px;flex-shrink:0;background:rgba(24,95,165,.10);border-radius:7px;display:flex;align-items:center;justify-content:center}
.recent-name{font-size:13px;font-weight:600;color:#1A2E45}
.recent-path{font-size:11px;font-family:'DM Mono',monospace;color:#6B8BAA;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:270px}
.form-logo{display:none;align-items:center;gap:10px;margin-bottom:32px}
.form-logo svg{width:36px;height:36px}
.form-logo-text{font-family:'Syne',sans-serif;font-size:22px;font-weight:800;letter-spacing:-.5px;color:#1A2E45}
.form-logo-text span{color:#185FA5}
@media(max-width:768px){.form-logo{display:flex}.page{grid-template-columns:1fr}.left{display:none}.right{padding:48px 28px}}
@keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
/* ── File browser modal ── */
#fbModal{display:none;position:fixed;inset:0;background:rgba(26,46,69,.55);backdrop-filter:blur(3px);z-index:999;align-items:center;justify-content:center}
.fb-box{background:#fff;border-radius:14px;width:540px;max-width:94vw;max-height:78vh;display:flex;flex-direction:column;box-shadow:0 24px 64px rgba(0,0,0,.22);overflow:hidden}
.fb-hdr{padding:16px 18px 12px;border-bottom:1px solid #C8DCEE;display:flex;align-items:flex-start;gap:10px}
.fb-htitle{font-family:'Syne',sans-serif;font-weight:700;font-size:15px;color:#1A2E45;flex:1}
.fb-crumb{font-size:11px;font-family:'DM Mono',monospace;color:#6B8BAA;margin-top:3px;word-break:break-all;line-height:1.4}
.fb-close{background:none;border:none;cursor:pointer;color:#6B8BAA;font-size:20px;line-height:1;padding:0 4px;border-radius:4px;transition:color .12s}
.fb-close:hover{color:#1A2E45}
.fb-list{overflow-y:auto;flex:1;padding:6px 8px;min-height:180px}
.fb-entry{display:flex;align-items:center;gap:9px;padding:7px 10px;border-radius:7px;cursor:pointer;font-size:13px;color:#1A2E45;transition:background .1s;user-select:none}
.fb-entry:hover{background:#EBF2FA}
.fb-entry.fb-file{color:#185FA5;font-family:'DM Mono',monospace}
.fb-entry.fb-up{color:#6B8BAA;font-family:'DM Mono',monospace}
.fb-entry.fb-selected{background:#dceaf7;font-weight:600}
.fb-icon{flex-shrink:0}
.fb-new-row{padding:12px 18px;border-top:1px solid #C8DCEE}
.fb-new-label{font-size:9px;font-weight:500;letter-spacing:1.2px;text-transform:uppercase;font-family:'DM Mono',monospace;color:#6B8BAA;margin-bottom:5px}
.fb-new-input{width:100%;padding:9px 11px;border:1.5px solid #C8DCEE;border-radius:7px;font-family:'DM Mono',monospace;font-size:13px;color:#1A2E45;outline:none;transition:border-color .12s;box-sizing:border-box}
.fb-new-input:focus{border-color:#185FA5}
.fb-foot{padding:12px 18px;border-top:1px solid #C8DCEE;display:flex;gap:8px;justify-content:flex-end}
.fb-btn-ok{padding:9px 20px;background:#185FA5;color:#fff;border:none;border-radius:7px;font-family:'Syne',sans-serif;font-size:13px;font-weight:700;cursor:pointer;transition:opacity .15s}
.fb-btn-ok:hover{opacity:.87}
.fb-btn-ok:disabled{opacity:.4;cursor:not-allowed}
.fb-btn-cancel{padding:9px 16px;background:transparent;color:#6B8BAA;border:1.5px solid #C8DCEE;border-radius:7px;font-family:'Syne',sans-serif;font-size:13px;font-weight:600;cursor:pointer;transition:border-color .15s,color .15s}
.fb-btn-cancel:hover{border-color:#1A2E45;color:#1A2E45}
.fb-msg{padding:28px;text-align:center;color:#6B8BAA;font-size:12px;font-family:'DM Mono',monospace}
.fb-err{padding:20px;color:#A32D2D;font-size:12px;font-family:'DM Mono',monospace}
.fb-set-default{font-size:11px;font-family:'DM Mono',monospace;color:#6B8BAA;background:none;border:none;cursor:pointer;padding:0;margin-right:auto;transition:color .12s}
.fb-set-default:hover{color:#185FA5}
.fb-set-default.fb-set-done{color:#2a7a45}
</style>
</head>
<body>
<div class="page">
  <div class="left">
    <div class="left-content">
      <div class="brand-wordmark">
        __LOGO__
        <div class="brand-wordmark-text">dog<span>box</span></div>
      </div>
      <h1>Australian<br>accounting,<br><em>made simple.</em></h1>
      <p class="left-desc">A complete double-entry bookkeeping system built for Australian small businesses &mdash; invoices, payroll, BAS, and more. No subscription. No cloud. Your data stays yours.</p>
      <div class="features">
        <div class="feature"><div class="feature-dot"></div>STP Phase 2 payroll compliance</div>
        <div class="feature"><div class="feature-dot"></div>GST &amp; BAS reporting</div>
        <div class="feature"><div class="feature-dot"></div>Job costing &amp; project P&amp;L</div>
        <div class="feature"><div class="feature-dot"></div>Multi-user with full audit trail</div>
        <div class="feature"><div class="feature-dot"></div>Works offline &mdash; single file</div>
      </div>
    </div>
  </div>
  <div class="right">
    <div class="form-card">
      <div class="form-logo" aria-hidden="true">
        __LOGO__
        <div class="form-logo-text">dog<span>box</span></div>
      </div>
      <div class="form-heading">Open company file</div>
      <div class="form-sub">Select an existing file or create a new one</div>
      <button class="btn-open" id="btnOpen" onclick="browse('open')">Open existing file&hellip;</button>
      <button class="btn-new"  id="btnNew"  onclick="browse('new')">Create new file&hellip;</button>
      <div class="confirm-box" id="confirmBox">
        <div class="confirm-label">Selected file</div>
        <div class="confirm-path" id="confirmPath"></div>
        <div class="confirm-btns">
          <button class="btn-open" onclick="openFile()">Open &rarr;</button>
          <button class="btn-cancel" onclick="cancelConfirm()">Cancel</button>
        </div>
      </div>
      <div class="error-msg" id="errMsg"></div>
      __RECENT__
    </div>
  </div>
</div>
<div id="fbModal">
  <div class="fb-box">
    <div class="fb-hdr">
      <div style="flex:1">
        <div class="fb-htitle" id="fbTitle">Open existing file</div>
        <div class="fb-crumb" id="fbCrumb"></div>
      </div>
      <button class="fb-close" onclick="fbClose()" title="Close">&times;</button>
    </div>
    <div id="fbList" class="fb-list"></div>
    <div id="fbNewRow" class="fb-new-row" style="display:none">
      <div class="fb-new-label">Filename</div>
      <input class="fb-new-input" id="fbFilename" type="text" value="company.dbox" placeholder="company.dbox">
    </div>
    <div class="fb-foot">
      <button class="fb-set-default" id="fbSetDefault" onclick="fbSaveDefault()" style="display:none">&#x1F4CC; Set as default folder</button>
      <button class="fb-btn-cancel" onclick="fbClose()">Cancel</button>
      <button class="fb-btn-ok" id="fbOkBtn" onclick="fbConfirm()" disabled>Open</button>
    </div>
  </div>
</div>
<script>
const _FB_DIR  = `<svg class="fb-icon" width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M1 5a1.5 1.5 0 0 1 1.5-1.5H6l1 1.5h7c.276 0 .5.224.5.5V12a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 1 12V5z" fill="rgba(24,95,165,.1)" stroke="#185FA5" stroke-width="1.3"/></svg>`;
const _FB_FILE = `<svg class="fb-icon" width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 2h7l3 3v9H3z" stroke="#185FA5" stroke-width="1.4"/><path d="M10 2v3h3" stroke="#185FA5" stroke-width="1.4"/></svg>`;
const _FB_DRV  = `<svg class="fb-icon" width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="1.5" y="5" width="13" height="8" rx="1.5" stroke="#6B8BAA" stroke-width="1.3"/><path d="M1.5 9h13" stroke="#6B8BAA" stroke-width="1.3"/><circle cx="12" cy="11" r="1" fill="#6B8BAA"/></svg>`;
let _DEFAULT_DIR = __DEFAULT_DIR_JSON__;

let _path = "", _busy = false;
let _fbMode = 'open', _fbCurPath = '', _fbSelFile = '';

function setBusy(on) {
  _busy = on;
  ["btnOpen","btnNew"].forEach(id => { const el = document.getElementById(id); if (el) el.disabled = on; });
}
function _esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function browse(mode) {
  _fbMode = mode;
  _fbSelFile = '';
  document.getElementById('fbTitle').textContent = mode === 'open' ? 'Open existing file' : 'Choose folder for new file';
  document.getElementById('fbNewRow').style.display = mode === 'new' ? 'block' : 'none';
  const okBtn = document.getElementById('fbOkBtn');
  okBtn.textContent = mode === 'open' ? 'Open' : 'Create here';
  okBtn.disabled = true;
  document.getElementById('fbModal').style.display = 'flex';
  fbNavigate(_DEFAULT_DIR || '');
}
function fbClose() {
  document.getElementById('fbModal').style.display = 'none';
}
document.getElementById('fbModal').addEventListener('click', function(e) { if (e.target === this) fbClose(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') fbClose(); });

async function fbNavigate(path) {
  _fbCurPath = path;
  _fbSelFile = '';
  document.getElementById('fbOkBtn').disabled = true;
  const list = document.getElementById('fbList');
  list.innerHTML = '<div class="fb-msg">Loading…</div>';
  let d;
  try {
    const r = await fetch('/startup/fs?path=' + encodeURIComponent(path));
    d = await r.json();
  } catch(e) {
    list.innerHTML = '<div class="fb-err">Could not read directory.</div>';
    return;
  }
  if (d.error) {
    list.innerHTML = `<div class="fb-err">${_esc(d.error)}</div>`;
    return;
  }
  let html = '';
  const setDefBtn = document.getElementById('fbSetDefault');
  if (d.drives) {
    _fbCurPath = '';
    document.getElementById('fbCrumb').textContent = 'This PC';
    html = d.drives.map(drv => `<div class="fb-entry fb-dir" data-nav="${_esc(drv)}">${_FB_DRV}<span>${_esc(drv)}</span></div>`).join('');
    if (setDefBtn) { setDefBtn.style.display = 'none'; setDefBtn.className = 'fb-set-default'; setDefBtn.textContent = '📌 Set as default folder'; }
  } else {
    _fbCurPath = d.path;
    document.getElementById('fbCrumb').textContent = d.path;
    if (d.show_drives) {
      html += `<div class="fb-entry fb-up" data-nav="">${_FB_DRV}<span>This PC</span></div>`;
    } else if (d.parent !== null && d.parent !== undefined) {
      html += `<div class="fb-entry fb-up" data-nav="${_esc(d.parent)}">${_FB_DIR}<span>&#x2191; ..</span></div>`;
    }
    html += d.dirs.map(n => `<div class="fb-entry fb-dir" data-nav="${_esc(d.path + '/' + n)}">${_FB_DIR}<span>${_esc(n)}</span></div>`).join('');
    if (_fbMode === 'open') {
      html += d.files.map(n => `<div class="fb-entry fb-file" data-file="${_esc(d.path + '/' + n)}">${_FB_FILE}<span>${_esc(n)}</span></div>`).join('');
    }
    if (_fbMode === 'new' && _fbCurPath) document.getElementById('fbOkBtn').disabled = false;
    const isDefault = _fbCurPath.replace(/\\\\/g,'/') === _DEFAULT_DIR;
    if (setDefBtn) {
      setDefBtn.style.display = 'inline';
      setDefBtn.className = 'fb-set-default' + (isDefault ? ' fb-set-done' : '');
      setDefBtn.textContent = isDefault ? '✓ Default folder' : '📌 Set as default folder';
    }
  }
  list.innerHTML = html || '<div class="fb-msg">Empty folder</div>';
  list.querySelectorAll('[data-nav]').forEach(el => el.addEventListener('click', () => fbNavigate(el.dataset.nav)));
  list.querySelectorAll('[data-file]').forEach(el => el.addEventListener('click', () => fbSelectFile(el, el.dataset.file)));
}

async function fbSaveDefault() {
  const btn = document.getElementById('fbSetDefault');
  if (!_fbCurPath || !btn) return;
  btn.disabled = true;
  try {
    await fetch('/startup/set-default-dir', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({path: _fbCurPath}),
    });
    _DEFAULT_DIR = _fbCurPath.replace(/\\\\/g, '/');
    btn.className = 'fb-set-default fb-set-done';
    btn.textContent = '✓ Default folder';
  } catch(e) { /* silent */ }
  btn.disabled = false;
}

function fbSelectFile(el, filePath) {
  document.querySelectorAll('#fbList .fb-selected').forEach(e => e.classList.remove('fb-selected'));
  el.classList.add('fb-selected');
  _fbSelFile = filePath;
  document.getElementById('fbOkBtn').disabled = false;
}
function fbConfirm() {
  let chosen;
  if (_fbMode === 'open') {
    chosen = _fbSelFile;
    if (!chosen) return;
  } else {
    if (!_fbCurPath) return;
    let fname = (document.getElementById('fbFilename').value || '').trim() || 'company.dbox';
    if (!fname.toLowerCase().endsWith('.dbox')) fname += '.dbox';
    chosen = _fbCurPath + '/' + fname;
  }
  fbClose();
  showConfirm(chosen);
}

function showConfirm(path) {
  _path = path;
  document.getElementById("confirmPath").textContent = path;
  document.getElementById("confirmBox").style.display = "block";
}
function cancelConfirm() {
  _path = "";
  document.getElementById("confirmBox").style.display = "none";
}
async function openFile(path) {
  const p = path || _path;
  if (!p || _busy) return;
  setBusy(true);
  setErr("");
  try {
    const r = await fetch("/startup/open", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({path:p})});
    const d = await r.json();
    if (d.ok) { window.location.href = "/"; return; }
    setErr(d.error || "Could not open file.");
  } catch(e) {
    setErr("Server error — please try again.");
  }
  setBusy(false);
}
function setErr(msg) { document.getElementById("errMsg").textContent = msg; }
</script>
</body>
</html>"""

def _render_startup_page() -> str:
    import json as _json
    recent = _load_recent()
    recent_block = ''
    if recent:
        import html as _html
        items = ''.join(
            f'<li class="recent-item"'
            f' data-path="{_html.escape(p, quote=True)}"'
            f' title="Double-click to open"'
            f' onclick="showConfirm(this.dataset.path)"'
            f' ondblclick="openFile(this.dataset.path)">'
            f'<div class="recent-icon">{_FILE_SVG}</div>'
            f'<div><div class="recent-name">{_html.escape(os.path.basename(p))}</div>'
            f'<div class="recent-path">{_html.escape(p)}</div></div>'
            f'</li>'
            for p in recent
        )
        recent_block = (
            '<div class="recent-sep">Recently opened</div>'
            f'<ul class="recent-list">{items}</ul>'
        )
    default_dir = _load_prefs().get('default_file_dir', '').replace('\\', '/')
    return (_STARTUP_HTML
            .replace('__LOGO__', _LOGO_SVG)
            .replace('__RECENT__', recent_block)
            .replace('__DEFAULT_DIR_JSON__', _json.dumps(default_dir)))


@app.before_request
def _require_db():
    """Redirect all routes to /startup while no company file is loaded."""
    if DB_PATH is None:
        if not request.path.startswith('/startup') and not request.path.startswith('/static'):
            return redirect('/startup')


def db():
    return DB_PATH

def dict_rows(rows):
    """Convert sqlite3.Row objects to plain dicts."""
    return [dict(r) for r in rows]

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("user"):
            return redirect(url_for("login_page"))
        return f(*args, **kwargs)
    return decorated

def current_user():
    return session.get("user", {})

def tier_required(*modules):
    """
    Decorator that returns 403 if the session tier doesn't include ALL of the
    listed module keys.  Apply after @login_required.

    Example:
        @app.route("/api/payroll/employees")
        @login_required
        @tier_required("payroll")
        def api_employees(): ...
    """
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            user = current_user()
            caps = set(user.get("tier_caps") or TIER_CAPS.get(user.get("tier", "full"), set()))
            missing = [m for m in modules if m not in caps]
            if missing:
                return err(
                    f"Your licence tier ({user.get('tier_label','Unknown')}) "
                    f"does not include: {', '.join(missing)}",
                    403,
                )
            return f(*args, **kwargs)
        return decorated
    return decorator

def ok(data=None, **kwargs):
    return jsonify({"ok": True, "data": data, **kwargs})

def err(msg, code=400):
    return jsonify({"ok": False, "error": msg}), code


# ── Startup ───────────────────────────────────────────────────────────────────
@app.route('/startup')
def startup_page():
    if DB_PATH is not None:
        return redirect('/')
    return _render_startup_page()

@app.route('/startup/fs')
def startup_fs():
    """Return directory listing for the HTML file browser."""
    import pathlib, string as _str
    raw = request.args.get('path', '').strip()

    # Windows with no path — return available drives
    if not raw and sys.platform == 'win32':
        drives = [f'{d}:\\' for d in _str.ascii_uppercase if os.path.exists(f'{d}:\\')]
        return jsonify({'drives': drives, 'path': ''})

    path = os.path.abspath(raw) if raw else str(pathlib.Path.home())
    if not os.path.isdir(path):
        return jsonify({'error': 'Not a directory'}), 400

    dirs, files = [], []
    try:
        with os.scandir(path) as it:
            for e in sorted(it, key=lambda x: x.name.lower()):
                try:
                    if e.is_dir(follow_symlinks=False) and not e.name.startswith('.'):
                        dirs.append(e.name)
                    elif e.is_file() and e.name.lower().endswith('.dbox'):
                        files.append(e.name)
                except OSError:
                    pass
    except PermissionError:
        return jsonify({'error': 'Permission denied'}), 403

    pp = pathlib.Path(path)
    at_root = pp == pp.parent
    return jsonify({
        'path': path,
        'parent': None if at_root else str(pp.parent),
        'show_drives': at_root and sys.platform == 'win32',
        'dirs': dirs,
        'files': files,
    })

@app.route('/startup/set-default-dir', methods=['POST'])
def startup_set_default_dir():
    path = ((request.json or {}).get('path') or '').strip()
    if not path or not os.path.isdir(path):
        return jsonify({'ok': False})
    p = _load_prefs()
    p['default_file_dir'] = os.path.normpath(path)
    try:
        _save_prefs(p)
    except Exception:
        pass
    return jsonify({'ok': True})

@app.route('/startup/open', methods=['POST'])
def startup_open():
    global DB_PATH
    path = ((request.json or {}).get('path') or '').strip()
    if not path:
        return jsonify({'ok': False, 'error': 'No file path provided.'})
    path = os.path.abspath(path)
    if not os.path.isdir(os.path.dirname(path)):
        return jsonify({'ok': False, 'error': f'Directory not found: {os.path.dirname(path)}'})
    try:
        initialise_database(path)
        seed_defaults(path)
        ensure_default_admin(path)
    except Exception as exc:
        return jsonify({'ok': False, 'error': str(exc)})
    DB_PATH = path
    import hashlib, time as _t
    app.secret_key = hashlib.sha256(f'dbox-web-{path}-{_t.time()}'.encode()).digest()
    _add_recent(path)
    return jsonify({'ok': True})



# ── EULA ───────────────────────────────────────────────────────────────────────
CURRENT_EULA_VERSION = "2.0"
_PREFS_PATH = os.path.join(os.path.expanduser("~"), "dbox_prefs.json")

def _load_eula_text() -> str:
    this_dir = os.path.dirname(os.path.abspath(__file__))
    for path in [
        os.path.normpath(os.path.join(this_dir, "..", "EULA.txt")),
        os.path.join(this_dir, "EULA.txt"),
    ]:
        if os.path.isfile(path):
            with open(path, encoding="utf-8", errors="replace") as f:
                return f.read()
    return (
        "DOGBOX ACCOUNTING — END USER LICENCE AGREEMENT\n\n"
        "EULA.txt could not be found in the application directory.\n\n"
        "Please contact david.robert.innes@gmail.com to obtain a copy "
        "of the full licence agreement before using this software."
    )

def _eula_accepted() -> bool:
    try:
        with open(_PREFS_PATH, encoding="utf-8") as f:
            return json.load(f).get("eula_version") == CURRENT_EULA_VERSION
    except Exception:
        return False

def _eula_acceptance_date() -> str:
    try:
        with open(_PREFS_PATH, encoding="utf-8") as f:
            return json.load(f).get("eula_date", "")
    except Exception:
        return ""

def _record_eula_acceptance():
    try:
        with open(_PREFS_PATH, encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = {}
    import datetime as _dt
    data["eula_version"] = CURRENT_EULA_VERSION
    data["eula_date"]    = _dt.date.today().isoformat()
    with open(_PREFS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


# ── Auth ───────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    if not _eula_accepted():
        return redirect(url_for("eula_page"))
    if not session.get("user"):
        return redirect(url_for("login_page"))
    return redirect(url_for("dashboard"))

@app.route("/login", methods=["GET"])
def login_page():
    if not _eula_accepted():
        return redirect(url_for("eula_page"))
    return render_template("login.html")

@app.route("/eula", methods=["GET"])
def eula_page():
    if _eula_accepted():
        return redirect(url_for("login_page"))
    return render_template("eula.html", eula_text=_load_eula_text(),
                           eula_version=CURRENT_EULA_VERSION)

@app.route("/api/eula/accept", methods=["POST"])
def api_eula_accept():
    _record_eula_acceptance()
    try:
        from core.licence import log_licence_event, ACTION_EULA_ACCEPT
        if db():
            log_licence_event(db(), ACTION_EULA_ACCEPT,
                              eula_version=CURRENT_EULA_VERSION)
    except Exception:
        pass
    return ok()

@app.route("/api/eula", methods=["GET"])
@login_required
def api_eula_status():
    return ok({
        "version":       CURRENT_EULA_VERSION,
        "accepted":      _eula_accepted(),
        "accepted_date": _eula_acceptance_date(),
        "text":          _load_eula_text(),
    })

@app.route("/api/licence", methods=["GET"])
@login_required
def api_licence_status():
    return ok(_get_licence_status())

@app.route("/api/licence/upload", methods=["POST"])
@login_required
def api_licence_upload():
    f = request.files.get("licence")
    if not f:
        return err("No file provided")
    text = f.read().decode("utf-8", errors="replace")
    from core.licence import _parse_licence_text, verify_licence
    fields = _parse_licence_text(text)
    if not fields:
        return err("File could not be parsed — is this a valid dbox.lic?")
    if not verify_licence(fields):
        return err("Licence signature is invalid or the file has been modified")
    app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    lic_path = os.path.join(app_dir, "dbox.lic")
    with open(lic_path, "w", encoding="utf-8") as fh:
        fh.write(text)
    return ok(_get_licence_status())

# ── Simple brute-force protection ─────────────────────────────────────────────
_login_attempts: dict = {}   # ip -> [timestamp, ...]
_MAX_ATTEMPTS  = 10
_LOCKOUT_SECS  = 300  # 5 minutes

def _check_rate_limit(ip: str) -> bool:
    """Return True if allowed, False if locked out."""
    import time
    now = time.time()
    attempts = [t for t in _login_attempts.get(ip, []) if now - t < _LOCKOUT_SECS]
    _login_attempts[ip] = attempts
    return len(attempts) < _MAX_ATTEMPTS

def _record_attempt(ip: str):
    import time
    _login_attempts.setdefault(ip, []).append(time.time())

def _clear_attempts(ip: str):
    _login_attempts.pop(ip, None)


@app.route("/api/login", methods=["POST"])
def api_login():
    ip = request.remote_addr or "unknown"
    if not _check_rate_limit(ip):
        return err("Too many login attempts. Please wait 5 minutes.", 429)
    data = request.get_json() or {}
    user = authenticate_user(db(), data.get("username",""), data.get("password",""))
    if not user:
        _record_attempt(ip)
        return err("Invalid username or password", 401)
    _clear_attempts(ip)
    global _locked
    _locked = False            # clear inactivity lock on successful login
    _reset_shutdown_timer()    # restart the inactivity countdown
    session.permanent = True   # honour PERMANENT_SESSION_LIFETIME (8h)
    tier = _get_tier(db())
    session["user"] = {
        "id":           user["id"],
        "username":     user["username"],
        "display_name": user["display_name"],
        "role":         user["role"],
        "tier":         tier,
        "tier_label":   TIER_LABELS.get(tier, tier.title()),
        "tier_caps":    sorted(TIER_CAPS[tier]),   # list — JSON-serialisable
    }
    return ok({
        "display_name":          user["display_name"],
        "role":                  user["role"],
        "tier":                  tier,
        "tier_label":            TIER_LABELS.get(tier, tier.title()),
        "force_password_change": bool(user.get("force_password_change", 0)),
    })

@app.route("/api/logout", methods=["POST"])
def api_logout():
    session.clear()
    return ok()

@app.route("/api/me/set-password", methods=["POST"])
@login_required
def api_me_set_password():
    data     = request.get_json() or {}
    password = (data.get("password") or "").strip()
    if len(password) < 8:
        return err("Password must be at least 8 characters", 400)
    uid = session["user"]["id"]
    set_own_password(db(), uid, password)
    audit(db(), uid, session["user"]["username"], "change_own_password")
    return ok()

@app.route("/api/me")
@login_required
def api_me():
    user = dict(current_user())
    # Attach licence banner so the dashboard can display it
    try:
        lic    = _get_licence_status()
        banner = status_banner(lic)
        user["licence_status"]    = lic.get("status")
        user["licence_issued_to"] = lic.get("issued_to")
        user["licence_banner"]    = {"message": banner[0], "severity": banner[1]} if banner else None
        user["licence_watermark"] = watermark_text(lic)
    except Exception:
        user["licence_banner"]    = None
        user["licence_watermark"] = "Unregistered"
    try:
        conn = get_connection(db())
        row  = conn.execute("SELECT gst_registered FROM company WHERE id=1").fetchone()
        conn.close()
        user["gst_registered"] = int(row["gst_registered"]) if row else 1
    except Exception:
        user["gst_registered"] = 1
    return ok(user)


# ── Pages ──────────────────────────────────────────────────────────────────────
@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html")

@app.route("/<path:path>")
@login_required
def spa(path):
    return render_template("app.html", page=path.split("/")[0])


# ── Dashboard API ──────────────────────────────────────────────────────────────
@app.route("/api/dashboard")
@login_required
def api_dashboard():
    import calendar
    today       = date.today()
    month_start = today.replace(day=1)
    month_end   = today.replace(day=calendar.monthrange(today.year, today.month)[1])
    lm_last     = month_start - timedelta(days=1)
    lm_start    = lm_last.replace(day=1)
    fy_start    = date(today.year, 7, 1) if today.month >= 7 else date(today.year - 1, 7, 1)

    # ── Bank balance ──────────────────────────────────────────────────────────
    accounts   = get_accounts(db())
    bank_accs  = [a for a in accounts if a.get("is_bank")]
    all_ids    = [a["id"] for a in bank_accs]
    balances   = get_account_balances_batch(db(), all_ids)
    bank_total = sum(balances.get(a["id"], 0.0) for a in bank_accs)

    # ── AR ────────────────────────────────────────────────────────────────────
    invoices   = get_invoices(db())
    active_inv = [i for i in invoices if i["status"] not in ("Paid", "Void", "Draft")]
    ar_total   = sum((i.get("total") or i.get("total_amount") or 0)
                     - (i.get("amount_paid") or 0) for i in active_inv)
    ar_count   = len(active_inv)
    overdue_inv = [i for i in active_inv
                   if i.get("due_date") and i["due_date"] < str(today)]
    ar_overdue_count  = len(overdue_inv)
    ar_overdue_amount = sum((i.get("total") or i.get("total_amount") or 0)
                            - (i.get("amount_paid") or 0) for i in overdue_inv)

    # ── AP ────────────────────────────────────────────────────────────────────
    bills      = get_bills(db())
    active_bil = [b for b in bills if b["status"] not in ("Paid", "Void", "Draft")]
    ap_total   = sum((b.get("total") or b.get("total_amount") or 0)
                     - (b.get("amount_paid") or 0) for b in active_bil)
    ap_count   = len(active_bil)
    overdue_bil = [b for b in active_bil
                   if b.get("due_date") and b["due_date"] < str(today)]
    ap_overdue_count = len(overdue_bil)
    upcoming_bil = sorted(
        [b for b in active_bil if b.get("due_date") and b["due_date"] >= str(today)],
        key=lambda b: b["due_date"]
    )
    ap_next_due = upcoming_bil[0]["due_date"] if upcoming_bil else None

    # ── GST net (collected minus credits) ─────────────────────────────────────
    try:
        conn = get_connection(db())
        gst_row = conn.execute("""
            SELECT
              COALESCE(SUM(CASE WHEN a.name LIKE '%GST Collected%'
                                THEN jl.credit - jl.debit ELSE 0 END), 0) AS collected,
              COALESCE(SUM(CASE WHEN a.name LIKE '%GST Paid%'
                                THEN jl.debit - jl.credit ELSE 0 END), 0) AS credits
            FROM journal_lines jl
            JOIN accounts a ON jl.account_id = a.id
        """).fetchone()
        conn.close()
        gst_net = round((gst_row["collected"] or 0) - (gst_row["credits"] or 0), 2)
    except Exception:
        gst_net = 0.0

    # ── BAS period label (quarterly — will come from company details later) ───
    q_month = ((today.month - 1) // 3) * 3 + 1
    q_names = {1: "Jan–Mar", 4: "Apr–Jun", 7: "Jul–Sep", 10: "Oct–Dec"}
    q_nums  = {1: "Q3",      4: "Q4",      7: "Q1",      10: "Q2"}
    q_label = q_names.get(q_month, "")
    q_num   = q_nums.get(q_month, "")
    q_start_year = today.year if q_month <= today.month else today.year - 1
    q_end_month  = q_month + 2
    q_end_year   = q_start_year
    if q_end_month > 12:
        q_end_month -= 12; q_end_year += 1
    bas_due_month = q_end_month + 1
    bas_due_year  = q_end_year
    if bas_due_month > 12:
        bas_due_month -= 12; bas_due_year += 1
    bas_due            = date(bas_due_year, bas_due_month, 28)
    bas_days_remaining = (bas_due - today).days
    ato_period         = f"GST · {q_num} {q_label} {q_start_year}"

    # ── P&L ───────────────────────────────────────────────────────────────────
    def _expenses(pl):
        return round(sum(r.get("amount", 0) for r in (pl.get("expense") or []))
                     + sum(r.get("amount", 0) for r in (pl.get("cost_of_sales") or [])), 2)
    try:
        pl_month  = profit_and_loss(db(), str(month_start), str(month_end))
        pl_fytd   = profit_and_loss(db(), str(fy_start),    str(today))
        pl_lm     = profit_and_loss(db(), str(lm_start),    str(lm_last))
        fytd_income    = round(pl_fytd.get("total_income", 0) or 0, 2)
        fytd_expenses  = _expenses(pl_fytd)
        fytd_net       = round(pl_fytd.get("net_profit",   0) or 0, 2)
        month_net      = round(pl_month.get("net_profit",  0) or 0, 2)
        last_month_net = round(pl_lm.get("net_profit",     0) or 0, 2)
    except Exception:
        fytd_income = fytd_expenses = fytd_net = month_net = last_month_net = 0.0

    # ── Sparklines — 6 months ─────────────────────────────────────────────────
    try:
        monthly           = get_monthly_totals(db(), months=6)
        monthly_ar        = [round(m.get("income",   0), 2) for m in monthly]
        monthly_ap        = [round(m.get("expenses", 0), 2) for m in monthly]
        monthly_bank      = [round(ar - ap, 2) for ar, ap in zip(monthly_ar, monthly_ap)]
        monthly_projected = [round(bank_total + ar - ap, 2)
                             for ar, ap in zip(monthly_ar, monthly_ap)]
    except Exception:
        monthly_bank = monthly_ar = monthly_ap = monthly_projected = [0] * 6

    # ── Recurring overdue ─────────────────────────────────────────────────────
    try:
        upcoming_rec      = get_upcoming(db(), days=0)
        recurring_overdue = len([t for t in upcoming_rec
                                  if t.get("next_due") and t["next_due"] < str(today)])
    except Exception:
        recurring_overdue = 0

    # ── CRM tasks & pipeline via get_crm_dashboard ────────────────────────────
    # get_crm_dashboard returns overdue_tasks, upcoming_tasks (with opp_title),
    # pipeline dict {stage: {count, value}}, and recent_comms
    try:
        crm = get_crm_dashboard(db())

        task_list = []

        # BAS due task — prepend if within 60 days
        if bas_days_remaining <= 60:
            task_list.append({
                "id":      0,
                "text":    "BAS lodgement due",
                "sub":     f"{q_num} {q_label} · due {bas_due.strftime('%-d %b')}",
                "bas":     True,
                "days":    bas_days_remaining,
                "overdue": bas_days_remaining < 0,
            })

        # Overdue CRM tasks first
        for t in crm.get("overdue_tasks", []):
            task_list.append({
                "id":      t["id"],
                "text":    t.get("title") or t.get("task_type") or "Task",
                "sub":     t.get("opp_title") or t.get("task_type", "Follow Up"),
                "due":     t.get("due_date", ""),
                "overdue": True,
            })

        # Upcoming tasks (due within ~14 days)
        for t in crm.get("upcoming_tasks", []):
            due = t.get("due_date", "")
            if due:
                days_away = (date.fromisoformat(due) - today).days
                if days_away > 14:
                    continue
            task_list.append({
                "id":      t["id"],
                "text":    t.get("title") or t.get("task_type") or "Task",
                "sub":     t.get("opp_title") or t.get("task_type", "Follow Up"),
                "due":     due,
                "overdue": False,
            })

        task_list = task_list[:6]

        # Pipeline — convert from {stage: {count, value}} to list with pct
        pipeline_raw = crm.get("pipeline", {})
        active_stages = {"Lead", "Qualified", "Quoted", "Accepted", "In Progress", "On Hold"}
        pipeline = [
            {"stage": stage, "amount": round(v["value"], 2), "count": v["count"]}
            for stage, v in pipeline_raw.items()
            if stage in active_stages and v["count"] > 0
        ]
        max_amt = max((p["amount"] for p in pipeline), default=1) or 1
        for p in pipeline:
            p["pct"] = round(p["amount"] / max_amt * 100)

    except Exception:
        task_list = []
        pipeline  = []

    return ok({
        # KPI row 1
        "bank_balance":       round(bank_total, 2),
        "projected_balance":  round(bank_total + ar_total - ap_total, 2),
        "gst_net":            gst_net,
        "ato_period":         ato_period,
        # KPI row 2
        "ar_total":           round(ar_total, 2),
        "ar_count":           ar_count,
        "ar_overdue_count":   ar_overdue_count,
        "ar_overdue_amount":  round(ar_overdue_amount, 2),
        "ap_total":           round(ap_total, 2),
        "ap_count":           ap_count,
        "ap_overdue_count":   ap_overdue_count,
        "ap_next_due":        ap_next_due,
        # P&L panel
        "pl_fytd_income":     fytd_income,
        "pl_fytd_expenses":   fytd_expenses,
        "pl_fytd_net":        fytd_net,
        "pl_month_net":       month_net,
        "pl_last_month_net":  last_month_net,
        "pl_fy_start":        str(fy_start),
        # Sparklines
        "monthly_bank":       monthly_bank,
        "monthly_projected":  monthly_projected,
        "monthly_ar":         monthly_ar,
        "monthly_ap":         monthly_ap,
        # Panels
        "tasks":              task_list,
        "pipeline":           pipeline,
        "recurring_overdue":  recurring_overdue,
    })


# ── Accounts ───────────────────────────────────────────────────────────────────
@app.route("/api/accounts")
@login_required
def api_accounts():
    accs = get_accounts(db(), active_only=False)
    return ok([dict(a) for a in accs])

@app.route("/api/accounts", methods=["POST"])
@login_required
def api_account_save():
    data = request.get_json() or {}
    try:
        save_account(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/accounts/<int:aid>")
@login_required
def api_account(aid):
    conn = get_connection(db())
    row = conn.execute("SELECT * FROM accounts WHERE id=?", (aid,)).fetchone()
    conn.close()
    if not row:
        return err("Not found", 404)
    a = dict(row)
    a["balance"] = round(get_account_balance(db(), aid), 2)
    return ok(a)

@app.route("/api/accounts/<int:aid>", methods=["PUT"])
@login_required
def api_account_update(aid):
    data = request.get_json() or {}
    data["id"] = aid
    try:
        save_account(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/accounts/<int:aid>/balance")
@login_required
def api_account_balance(aid):
    bal = get_account_balance(db(), aid)
    return ok(round(bal, 2))

@app.route("/api/accounts/balances", methods=["POST"])
@login_required
def api_account_balances_batch():
    ids = request.get_json() or []
    try:
        balances = get_account_balances_batch(db(), ids)
        return ok({str(k): round(v, 2) for k, v in balances.items()})
    except Exception as e:
        return err(str(e))


# ── Items ─────────────────────────────────────────────────────────────────────
@app.route("/api/items")
@login_required
def api_items():
    return ok(get_items(db(), active_only=True))

@app.route("/api/items/<int:iid>/stock")
@login_required
def api_item_stock(iid):
    item = get_item(db(), iid)
    if not item:
        return err("Not found", 404)
    return ok({"qty_on_hand": item.get("qty_on_hand", 0),
               "is_inventoried": bool(item.get("is_inventoried"))})


@app.route("/api/items/all")
@login_required
def api_items_all():
    return ok(get_items(db(), active_only=False))

@app.route("/api/items/<int:iid>")
@login_required
def api_item(iid):
    item = get_item(db(), iid)
    if not item:
        return err("Not found", 404)
    return ok(dict(item))

@app.route("/api/items", methods=["POST"])
@login_required
def api_item_save():
    data = request.get_json() or {}
    try:
        iid = save_item(db(), data)
        return ok({"id": iid})
    except Exception as e:
        return err(str(e))

@app.route("/api/items/<int:iid>", methods=["PUT"])
@login_required
def api_item_update(iid):
    data = request.get_json() or {}
    data["id"] = iid
    try:
        save_item(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/items/<int:iid>", methods=["DELETE"])
@login_required
def api_item_delete(iid):
    try:
        delete_item(db(), iid)
        return ok()
    except Exception as e:
        return err(str(e))



# ── Inventory ──────────────────────────────────────────────────────────────────

@app.route("/api/inventory/summary")
@login_required
def api_inventory_summary():
    return ok(get_stock_summary(db()))

@app.route("/api/inventory/items")
@login_required
def api_inventory_items():
    return ok(get_inventory_items(db()))

@app.route("/api/inventory/analytics")
@login_required
def api_inventory_analytics():
    months = request.args.get("months", 6, type=int)
    result = get_inventory_analytics(db(), months=months)
    # JSON keys must be strings
    return ok({str(k): v for k, v in result.items()})

@app.route("/api/inventory/movements")
@login_required
def api_inventory_movements():
    item_id  = request.args.get("item_id",  type=int)
    date_from= request.args.get("from")
    date_to  = request.args.get("to")
    mov_type = request.args.get("type")
    limit    = request.args.get("limit", type=int)
    rows = get_stock_movements(db(),
                               item_id=item_id,
                               date_from=date_from,
                               date_to=date_to,
                               movement_type=mov_type)
    if limit:
        rows = rows[:limit]
    return ok(rows)

@app.route("/api/inventory/adjust", methods=["POST"])
@login_required
def api_inventory_adjust():
    data = request.get_json() or {}
    item_id = data.get("item_id")
    new_qty = data.get("new_qty")
    if item_id is None or new_qty is None:
        return err("item_id and new_qty required")
    try:
        mov_id = adjust_stock(
            db(),
            item_id=int(item_id),
            new_qty=float(new_qty),
            adjustment_date=data.get("adjustment_date"),
            reason=data.get("reason", "Stock count correction"),
        )
        return ok({"movement_id": mov_id})
    except Exception as e:
        return err(str(e))

@app.route("/api/inventory/valuation/pdf")
@login_required
def api_inventory_valuation_pdf():
    from core.inventory_pdf import render_stock_valuation_pdf
    import io
    report = stock_valuation_report(db())
    buf = render_stock_valuation_pdf(report, db_path=db())
    return send_file(io.BytesIO(buf), mimetype="application/pdf",
                     as_attachment=True,
                     download_name=f"stock-valuation-{report['as_at']}.pdf")

@app.route("/api/inventory/item/<int:iid>")
@login_required
def api_inventory_item_get(iid):
    item = get_inventory_item(db(), iid)
    if not item:
        return err("Item not found", 404)
    return ok(dict(item))

@app.route("/api/inventory/item/<int:iid>/settings", methods=["PUT"])
@login_required
def api_inventory_item_settings_put(iid):
    data = request.get_json() or {}
    try:
        is_livestock = int(bool(data.get("is_livestock")))
        stock_acc_id = int(data["stock_account_id"]) if data.get("stock_account_id") else None
        cogs_acc_id  = int(data["cogs_account_id"])  if data.get("cogs_account_id")  else None

        valid_cats = {"cattle_horses_deer", "pigs", "emus", "sheep_goats", "poultry"}
        valid_ni   = {"prescribed", "actual"}
        valid_pu   = {"market", "cost"}
        save_inventory_settings(db(), iid, {
            "is_inventoried":      int(bool(data.get("is_inventoried"))),
            "is_livestock":        is_livestock,
            "livestock_category":  data.get("livestock_category") if data.get("livestock_category") in valid_cats else None,
            "livestock_ni_method": data.get("livestock_ni_method") if data.get("livestock_ni_method") in valid_ni else "prescribed",
            "livestock_pu_method": data.get("livestock_pu_method") if data.get("livestock_pu_method") in valid_pu else "market",
            "reorder_level":       float(data.get("reorder_level") or 0),
            "reorder_qty":         float(data.get("reorder_qty") or 0),
            "unit_cost":           float(data.get("unit_cost") or 0),
            "location":            data.get("location") or None,
            "barcode":             data.get("barcode") or None,
            "stock_account_id":    stock_acc_id,
            "cogs_account_id":     cogs_acc_id,
        })
        pricing_mode = data.get("pricing_mode", "fixed")
        markup_value = float(data.get("markup_value") or 0)
        unit_price   = float(data.get("unit_price") or 0)
        conn = get_connection(db())
        conn.execute(
            "UPDATE items SET unit_price=?, pricing_mode=?, markup_value=? WHERE id=?",
            (round(unit_price, 4), pricing_mode, markup_value, iid))
        conn.commit()
        conn.close()
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/inventory/movement", methods=["POST"])
@login_required
def api_inventory_movement_post():
    data = request.get_json() or {}
    item_id       = data.get("item_id")
    movement_type = (data.get("movement_type") or "").upper()
    allowed = {"SALE", "WRITE_OFF", "RETURN_IN", "RETURN_OUT", "PURCHASE",
               "NATURAL_INCREASE", "DEATH", "PRIVATE_USE"}
    if not item_id or movement_type not in allowed:
        return err("item_id required and movement_type must be one of: " + ", ".join(sorted(allowed)))
    try:
        qty = float(data.get("qty") or 0)
        if qty <= 0:
            return err("qty must be positive")
        source_doc_type = data.get("source_doc_type") or None
        source_doc_id   = int(data["source_doc_id"]) if data.get("source_doc_id") else None
        # Livestock SALE must be linked to an invoice
        if movement_type == "SALE":
            item_row = get_item(db(), int(item_id))
            if item_row and item_row.get("is_livestock") and not source_doc_id:
                return err("Livestock sales must be linked to an invoice (source_doc_id required)")
        mov_id = post_stock_movement(
            db(),
            item_id=int(item_id),
            movement_type=movement_type,
            movement_date=data.get("movement_date") or str(date.today()),
            qty=qty,
            unit_cost=float(data["unit_cost"]) if data.get("unit_cost") not in (None, "") else None,
            unit_price=float(data["unit_price"]) if data.get("unit_price") not in (None, "") else None,
            reference=data.get("reference") or "",
            source_doc_type=source_doc_type,
            source_doc_id=source_doc_id,
            notes=data.get("notes") or "",
        )
        return ok({"id": mov_id})
    except Exception as e:
        return err(str(e))

@app.route("/api/inventory/stocktake", methods=["POST"])
@login_required
def api_inventory_stocktake():
    data = request.get_json() or {}
    count_date = data.get("count_date") or str(date.today())
    lines = data.get("lines", [])
    if not lines:
        return err("No items provided")
    posted = 0
    errors = []
    for line in lines:
        item_id = line.get("item_id")
        new_qty = line.get("new_qty")
        if item_id is None or new_qty is None:
            continue
        try:
            adjust_stock(db(), int(item_id), float(new_qty),
                         adjustment_date=count_date,
                         reason=f"Stocktake {count_date}")
            posted += 1
        except Exception as e:
            errors.append({"item_id": item_id, "error": str(e)})
    return ok({"posted": posted, "errors": errors})

# ── Purchase Orders ────────────────────────────────────────────────────────────

@app.route("/api/purchase-orders")
@login_required
def api_po_list():
    status     = request.args.get("status") or None
    contact_id = request.args.get("contact_id", type=int)
    rows = get_purchase_orders(db(), status=status, contact_id=contact_id)
    return ok(rows)


@app.route("/api/purchase-orders/<int:po_id>")
@login_required
def api_po_get(po_id):
    data = get_purchase_order(db(), po_id)
    if not data:
        return err("Not found", 404)
    return ok(data)


@app.route("/api/purchase-orders", methods=["POST"])
@login_required
def api_po_create():
    body  = request.get_json(force=True)
    po_d  = body.get("po",    {})
    lines = body.get("lines", [])
    try:
        po_id = save_purchase_order(db(), po_d, lines,
                                    created_by=session.get("username"))
        return jsonify({"po_id": po_id}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/purchase-orders/<int:po_id>", methods=["PUT"])
@login_required
def api_po_update(po_id):
    body  = request.get_json(force=True)
    po_d  = body.get("po",    {})
    lines = body.get("lines", [])
    po_d["id"] = po_id
    try:
        save_purchase_order(db(), po_d, lines,
                            created_by=session.get("username"))
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/purchase-orders/<int:po_id>/receive", methods=["POST"])
@login_required
def api_po_receive(po_id):
    body  = request.get_json(force=True)
    # received: {str(line_id): qty}  — convert keys to int
    received_raw  = body.get("received", {})
    received      = {int(k): float(v) for k, v in received_raw.items()}
    received_date = body.get("received_date") or None
    try:
        new_status = receive_po_lines(db(), po_id, received,
                                      received_date=received_date,
                                      created_by=session.get("username"))
        return jsonify({"status": new_status})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/purchase-orders/<int:po_id>/receive-all", methods=["POST"])
@login_required
def api_po_receive_all(po_id):
    from datetime import date as _d
    data = get_purchase_order(db(), po_id)
    if not data:
        return jsonify({"error": "Not found"}), 404
    lines = data.get("lines", [])
    to_receive = {}
    for ln in lines:
        outstanding = float(ln.get("quantity") or 0) - float(ln.get("qty_received") or 0)
        if outstanding > 0:
            to_receive[ln["id"]] = outstanding
    if not to_receive:
        return jsonify({"error": "All lines already received"}), 400
    try:
        new_status = receive_po_lines(db(), po_id, to_receive,
                                      received_date=str(_d.today()),
                                      created_by=session.get("username"))
        return jsonify({"status": new_status})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/purchase-orders/<int:po_id>/convert-bill", methods=["POST"])
@login_required
def api_po_convert_bill(po_id):
    try:
        bill_id = convert_po_to_bill(db(), po_id)
        return jsonify({"bill_id": bill_id})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/purchase-orders/<int:po_id>/cancel", methods=["POST"])
@login_required
def api_po_cancel(po_id):
    try:
        cancel_purchase_order(db(), po_id)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/purchase-orders/<int:po_id>/pdf")
@login_required
def api_po_pdf(po_id):
    import tempfile, os as _os
    data = get_purchase_order(db(), po_id)
    if not data:
        return jsonify({"error": "Not found"}), 404
    po_num = data["po"].get("po_number", str(po_id))
    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
        tmp_path = tmp.name
    try:
        render_po_pdf(db(), po_id, tmp_path)
        return send_file(tmp_path, mimetype="application/pdf",
                         as_attachment=True,
                         download_name=f"{po_num}.pdf")
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        try:
            _os.unlink(tmp_path)
        except Exception:
            pass



@app.route("/api/crm/quotes/<int:qid>/create-po", methods=["POST"])
@login_required
def api_crm_quote_create_po(qid):
    body = request.get_json(force=True) or {}
    supplier_id   = body.get("supplier_id")
    po_date       = body.get("po_date") or None
    expected_date = body.get("expected_date") or None
    if not supplier_id:
        return err("supplier_id required", 400)
    try:
        po_id = create_po_from_crm_quote(
            db(), qid, int(supplier_id),
            po_date=po_date, expected_date=expected_date,
            created_by=session.get("username"),
        )
        return ok({"po_id": po_id})
    except Exception as e:
        return err(str(e), 400)


# ── Contacts ───────────────────────────────────────────────────────────────────
def _contacts_with_employee_flag(db_path):
    """Return contacts list with has_employee boolean derived from employees.contact_id FK."""
    conn = get_connection(db_path)
    rows = conn.execute("SELECT * FROM contacts ORDER BY name").fetchall()
    emp_contact_ids = {r[0] for r in conn.execute(
        "SELECT contact_id FROM employees "
        "WHERE contact_id IS NOT NULL AND (termination_date IS NULL OR termination_date='')"
    ).fetchall()}
    conn.close()
    result = []
    for row in rows:
        d = dict(row)
        d["has_employee"] = 1 if d["id"] in emp_contact_ids else 0
        result.append(d)
    return result


# ── Attachments ───────────────────────────────────────────────────────────────
# Valid source types — guards against arbitrary table access
_ATTACH_TYPES = {"invoice", "bill", "payment", "purchase_order",
                 "job", "warranty", "payslip", "journal"}

@app.route("/api/attachments/<source_type>/<int:source_id>")
@login_required
def api_attachments_list(source_type, source_id):
    if source_type not in _ATTACH_TYPES:
        return err("Invalid source type", 400)
    rows = get_attachments(db(), source_type, source_id)
    return ok(rows)

@app.route("/api/attachments/<source_type>/<int:source_id>", methods=["POST"])
@login_required
def api_attachments_upload(source_type, source_id):
    if source_type not in _ATTACH_TYPES:
        return err("Invalid source type", 400)
    f = request.files.get("file")
    if not f:
        return err("No file provided", 400)
    description = request.form.get("description", "")
    MAX_BYTES = 20 * 1024 * 1024
    data = f.read()
    if len(data) > MAX_BYTES:
        return err("File exceeds 20 MB limit", 400)
    import mimetypes as _mt, tempfile as _tmp
    filename  = f.filename or "upload"
    tmp = _tmp.NamedTemporaryFile(delete=False, suffix=os.path.splitext(filename)[1])
    dest = None
    try:
        tmp.write(data); tmp.close()
        dest = os.path.join(os.path.dirname(tmp.name), filename)
        os.rename(tmp.name, dest)
        add_attachment(db(), source_type, source_id, dest, description)
    finally:
        for p in [tmp.name, dest]:
            if p:
                try: os.unlink(p)
                except: pass
    rows = get_attachments(db(), source_type, source_id)
    return ok(rows)

@app.route("/api/attachments/<int:att_id>", methods=["DELETE"])
@login_required
def api_attachment_delete(att_id):
    delete_attachment(db(), att_id)
    return ok()

@app.route("/api/attachments/<int:att_id>/download")
@login_required
def api_attachment_download(att_id):
    att = get_attachment_data(db(), att_id)
    if not att:
        return err("Not found", 404)
    from flask import Response
    return Response(
        att["file_data"],
        mimetype=att["mime_type"] or "application/octet-stream",
        headers={"Content-Disposition": f'attachment; filename="{att["filename"]}"'})

@app.route("/api/contacts")
@login_required
def api_contacts():
    return ok(_contacts_with_employee_flag(db()))

@app.route("/api/contacts", methods=["POST"])
@login_required
def api_contact_save():
    data = request.get_json() or {}
    try:
        cid = save_contact(db(), data)
        return ok({"id": cid})
    except Exception as e:
        return err(str(e))

@app.route("/api/contacts/<int:cid>")
@login_required
def api_contact(cid):
    conn = get_connection(db())
    row = conn.execute("SELECT * FROM contacts WHERE id=?", (cid,)).fetchone()
    if not row:
        conn.close()
        return err("Not found", 404)
    d = dict(row)
    emp = conn.execute(
        "SELECT id FROM employees WHERE contact_id=? "
        "AND (termination_date IS NULL OR termination_date='')", (cid,)
    ).fetchone()
    d["has_employee"] = 1 if emp else 0
    conn.close()
    return ok(d)

@app.route("/api/contacts/<int:cid>", methods=["PUT"])
@login_required
def api_contact_update(cid):
    data = request.get_json() or {}
    data["id"] = cid
    try:
        save_contact(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@app.route("/api/contacts/<int:cid>/statement")
@login_required
def api_contact_statement(cid):
    """Stream a Statement of Account PDF for the given contact and date range."""
    date_from = request.args.get("date_from")
    date_to   = request.args.get("date_to")
    if not date_from or not date_to:
        return err("date_from and date_to are required", 400)
    try:
        pdf_path = render_statement_of_account_pdf(
            db(), cid, date_from, date_to, watermark=_get_pdf_watermark()
        )
        return send_file(pdf_path, mimetype="application/pdf",
                         as_attachment=True,
                         download_name=f"statement_{cid}_{date_from}_{date_to}.pdf")
    except Exception as e:
        return err(str(e), 500)


@app.route("/api/contacts/<int:cid>/statement/email", methods=["POST"])
@login_required
def api_contact_statement_email(cid):
    from core.email_invoice import send_pdf_email
    import tempfile, os
    data = request.get_json() or {}
    to_email = (data.get("to") or "").strip()
    date_from = data.get("date_from", "")
    date_to   = data.get("date_to", "")
    if not to_email:
        return err("Recipient email is required", 400)
    if not date_from or not date_to:
        return err("date_from and date_to are required", 400)
    try:
        pdf_path = render_statement_of_account_pdf(
            db(), cid, date_from, date_to, watermark=_get_pdf_watermark()
        )
        subject = data.get("subject") or f"Statement of Account — {date_from} to {date_to}"
        body    = data.get("body") or f"Please find attached your statement of account for the period {date_from} to {date_to}."
        ok_flag, msg = send_pdf_email(db(), pdf_path, to_email, subject, body)
        if not ok_flag:
            return err(msg)
        return ok()
    except Exception as e:
        return err(str(e), 500)
    finally:
        try: os.unlink(pdf_path)
        except Exception: pass


# ── Invoices ───────────────────────────────────────────────────────────────────
@app.route("/api/invoices")
@login_required
def api_invoices():
    invs = get_invoices(db())
    # Enrich with contact name and normalise field names for the web UI
    contacts = {c["id"]: c["name"] for c in get_contacts(db())}
    result = []
    for i in dict_rows(invs):
        i["contact_name"]  = contacts.get(i.get("contact_id"), "—")
        i["total_amount"]  = i.get("total", 0)        # alias
        i["invoice_date"]  = i.get("invoice_date") or i.get("created_at","")[:10]
        result.append(i)
    return ok(result)

@app.route("/api/invoices/<int:iid>")
@login_required
def api_invoice(iid):
    data = get_invoice(db(), iid)
    if not data:
        return err("Not found", 404)
    # get_invoice returns {"invoice": row, "lines": [rows]}
    inv   = dict(data["invoice"])
    lines = [dict(l) for l in data["lines"]]
    # Enrich with contact name
    contacts = {c["id"]: c["name"] for c in get_contacts(db())}
    inv["contact_name"] = contacts.get(inv.get("contact_id"), "—")
    return ok({"invoice": inv, "lines": lines})

@app.route("/api/invoices/<int:iid>", methods=["PUT"])
@login_required
def api_invoice_update(iid):
    data = request.get_json() or {}
    data["id"] = iid
    try:
        save_invoice(db(), data, data.get("lines", []))
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/invoices/<int:iid>/void", methods=["POST"])
@login_required
def api_invoice_void(iid):
    try:
        void_invoice(db(), iid)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "VoidInvoice", "invoices", iid, "voided via web")
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/invoices/<int:iid>/mark-sent", methods=["POST"])
@login_required
def api_invoice_mark_sent(iid):
    try:
        mark_invoice_sent(db(), iid)
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/invoices/<int:iid>/pdf", methods=["GET"])
@login_required
def api_invoice_pdf(iid):
    """Generate and return invoice PDF as a file download."""
    import tempfile, os
    try:
        from core.invoice_pdf import generate_invoice_pdf
        inv_data = get_invoice(db(), iid)
        if not inv_data:
            return err("Invoice not found", 404)
        inv = inv_data["invoice"]
        num = inv.get("invoice_number") or f"INV-{iid}"
        tmp = tempfile.mktemp(suffix=".pdf", prefix=f"{num}_")
        generate_invoice_pdf(db(), iid, tmp)
        return send_file(tmp, mimetype="application/pdf",
                         as_attachment=True,
                         download_name=f"{num}.pdf")
    except Exception as e:
        return err(str(e))


@app.route("/api/invoices/<int:iid>/email", methods=["POST"])
@login_required
def api_invoice_email(iid):
    from core.email_invoice import send_invoice_email
    from core.invoice_pdf import generate_invoice_pdf
    import tempfile, os
    data = request.get_json() or {}
    to_email = (data.get("to") or "").strip()
    if not to_email:
        return err("Recipient email is required", 400)
    inv_data = get_invoice(db(), iid)
    if not inv_data:
        return err("Invoice not found", 404)
    inv = inv_data["invoice"]
    num = inv.get("invoice_number") or f"INV-{iid}"
    tmp = tempfile.mktemp(suffix=".pdf", prefix=f"{num}_")
    try:
        generate_invoice_pdf(db(), iid, tmp)
        ok_flag, msg = send_invoice_email(
            db(), iid, tmp, to_email,
            subject_override=data.get("subject") or None,
            body_override=data.get("body") or None,
        )
        if not ok_flag:
            return err(msg)
        return ok()
    except Exception as e:
        return err(str(e))
    finally:
        try: os.unlink(tmp)
        except Exception: pass


@app.route("/api/invoices/<int:iid>/payment", methods=["POST"])
@login_required
def api_invoice_payment(iid):
    """Record a payment against an invoice."""
    data = request.get_json() or {}
    try:
        # Get invoice to resolve contact_id
        inv_data = get_invoice(db(), iid)
        if not inv_data:
            return err("Invoice not found", 404)
        inv = inv_data["invoice"]
        pid = record_payment(db(), {
            "payment_type":    "Receipt",
            "contact_id":      inv.get("contact_id"),
            "payment_date":    data.get("payment_date", str(date.today())),
            "amount":          float(data.get("amount", 0)),
            "bank_account_id": data.get("account_id"),
            "reference":       data.get("reference", ""),
            "description":     f"Invoice payment — {inv.get('invoice_number','')}",
        }, [{"invoice_id": iid, "amount": float(data.get("amount", 0))}])
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "RecordPayment", "invoices", iid,
              f"amount={data.get('amount')} ref={data.get('reference','')}")
        return ok({"id": pid})
    except Exception as e:
        return err(str(e))

@app.route("/api/invoices", methods=["POST"])
@login_required
def api_invoice_save():
    data = request.get_json() or {}
    try:
        iid = save_invoice(db(), data, data.get("lines", []))
        return ok({"id": iid})
    except Exception as e:
        return err(str(e))


# ── Bills ──────────────────────────────────────────────────────────────────────
@app.route("/api/bills")
@login_required
def api_bills():
    contacts = {c["id"]: c["name"] for c in get_contacts(db())}
    result = []
    for b in dict_rows(get_bills(db())):
        b["contact_name"] = contacts.get(b.get("contact_id"), "—")
        b["total_amount"] = b.get("total", 0)
        b["bill_date"]    = b.get("bill_date") or b.get("created_at","")[:10]
        result.append(b)
    return ok(result)

@app.route("/api/bills/<int:bid>")
@login_required
def api_bill(bid):
    data = get_bill(db(), bid)
    if not data:
        return err("Not found", 404)
    bill  = dict(data["bill"])
    lines = [dict(l) for l in data["lines"]]
    contacts = {c["id"]: c["name"] for c in get_contacts(db())}
    bill["contact_name"] = contacts.get(bill.get("contact_id"), "—")
    job_id = get_job_for_bill(db(), bid)
    bill["job_id"] = job_id
    if job_id:
        job = get_job(db(), job_id)
        bill["job_name"] = f"{job['job_number']}  {job['name']}" if job else None
    else:
        bill["job_name"] = None
    return ok({"bill": bill, "lines": lines})

@app.route("/api/bills/<int:bid>", methods=["PUT"])
@login_required
def api_bill_update(bid):
    data = request.get_json() or {}
    data["id"] = bid
    try:
        save_bill(db(), data, data.get("lines", []))
        if "job_id" in data:
            set_bill_job(db(), bid, data["job_id"] if data["job_id"] else None)
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/bills/<int:bid>/void", methods=["POST"])
@login_required
def api_bill_void(bid):
    try:
        void_bill(db(), bid)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "VoidBill", "bills", bid, "voided via web")
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/bills/<int:bid>/mark-approved", methods=["POST"])
@login_required
def api_bill_mark_approved(bid):
    try:
        mark_bill_approved(db(), bid)
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/bills/<int:bid>/pdf", methods=["GET"])
@login_required
def api_bill_pdf(bid):
    """Generate and return bill PDF as a file download."""
    import tempfile
    try:
        from core.bill_pdf import generate_bill_pdf
        bill_data = get_bill(db(), bid)
        if not bill_data:
            return err("Bill not found", 404)
        bill = bill_data["bill"]
        num = bill.get("bill_number") or f"BILL-{bid}"
        tmp = tempfile.mktemp(suffix=".pdf", prefix=f"{num}_")
        generate_bill_pdf(db(), bid, tmp)
        return send_file(tmp, mimetype="application/pdf",
                         as_attachment=True,
                         download_name=f"{num}.pdf")
    except Exception as e:
        return err(str(e))


@app.route("/api/bills/<int:bid>/email", methods=["POST"])
@login_required
def api_bill_email(bid):
    from core.email_invoice import send_pdf_email
    from core.bill_pdf import generate_bill_pdf as _gen_bill_pdf
    import tempfile, os
    data = request.get_json() or {}
    to_email = (data.get("to") or "").strip()
    if not to_email:
        return err("Recipient email is required", 400)
    bill_data = get_bill(db(), bid)
    if not bill_data:
        return err("Bill not found", 404)
    bill = bill_data["bill"]
    num = bill.get("bill_number") or f"BILL-{bid}"
    tmp = tempfile.mktemp(suffix=".pdf", prefix=f"{num}_")
    try:
        _gen_bill_pdf(db(), bid, tmp)
        subject = data.get("subject") or f"Bill {num}"
        body    = data.get("body") or f"Please find attached bill {num}."
        ok_flag, msg = send_pdf_email(db(), tmp, to_email, subject, body)
        if not ok_flag:
            return err(msg)
        return ok()
    except Exception as e:
        return err(str(e))
    finally:
        try: os.unlink(tmp)
        except Exception: pass


@app.route("/api/bills/<int:bid>/payment", methods=["POST"])
@login_required
def api_bill_payment(bid):
    """Record a payment against a bill (supplier payment)."""
    data = request.get_json() or {}
    try:
        # get_bill to resolve contact_id for the payment record
        bill_data = get_bill(db(), bid)
        if not bill_data:
            return err("Bill not found", 404)
        bill = bill_data["bill"]
        pid = record_payment(db(), {
            "payment_type":  "Payment",
            "contact_id":    bill.get("contact_id"),
            "payment_date":  data.get("payment_date", str(date.today())),
            "amount":        float(data.get("amount", 0)),
            "bank_account_id": data.get("account_id"),
            "reference":     data.get("reference", ""),
            "description":   f"Bill payment — {bill.get('bill_number','')}",
        }, [{"bill_id": bid, "amount": float(data.get("amount", 0))}])
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "RecordBillPayment", "bills", bid,
              f"amount={data.get('amount')} ref={data.get('reference','')}")
        return ok({"id": pid})
    except Exception as e:
        return err(str(e))

@app.route("/api/bills/<int:bid>/receive-lines")
@login_required
def api_bill_receive_lines(bid):
    """Return inventoried bill lines with ordered/received/outstanding per line.
    Used to populate the Receive Stock modal in the web UI (Stage 6B)."""
    try:
        bill_data = get_bill(db(), bid)
        if not bill_data:
            return err("Bill not found", 404)
        bill     = dict(bill_data["bill"])
        bill_num = bill.get("bill_number") or str(bid)
        conn     = get_connection(db())
        rows = conn.execute("""
            SELECT bl.id                          AS line_id,
                   bl.item_id,
                   bl.description,
                   COALESCE(bl.quantity,     0)   AS ordered,
                   COALESCE(bl.qty_received, 0)   AS received,
                   COALESCE(bl.unit_price,   0)   AS unit_price,
                   i.name                         AS item_name,
                   COALESCE(i.is_inventoried, 0)  AS is_inventoried
            FROM   bill_lines bl
            JOIN   items i ON i.id = bl.item_id
            WHERE  bl.bill_id       = ?
              AND  bl.item_id       IS NOT NULL
              AND  i.is_inventoried = 1
            ORDER  BY bl.id
        """, (bid,)).fetchall()
        conn.close()
        lines = []
        for r in rows:
            ordered  = float(r["ordered"])
            received = float(r["received"])
            lines.append({
                "line_id":     r["line_id"],
                "item_id":     r["item_id"],
                "item_name":   r["item_name"],
                "description": r["description"] or r["item_name"],
                "ordered":     ordered,
                "received":    received,
                "outstanding": max(0.0, ordered - received),
                "unit_price":  float(r["unit_price"]),
            })
        return ok({"lines": lines, "bill_number": bill_num,
                   "contact_name": bill.get("contact_name", "")})
    except Exception as e:
        return err(str(e))


@app.route("/api/bills/<int:bid>/receipts", methods=["GET"])
@login_required
def api_bill_receipts_get(bid):
    """Return stock receipt history for a bill."""
    try:
        rows = get_stock_receipts(db(), bill_id=bid)
        return ok({"receipts": [dict(r) for r in rows]})
    except Exception as e:
        return err(str(e))

@app.route("/api/bills/<int:bid>/receipts", methods=["POST"])
@login_required
def api_bill_receipts_post(bid):
    """Receive stock against a bill — creates receipt header + movements."""
    data = request.get_json() or {}
    lines = data.get("lines", [])   # [{line_id, item_id, qty, unit_price}]
    if not lines:
        return err("No lines provided")
    try:
        bill_data = get_bill(db(), bid)
        if not bill_data:
            return err("Bill not found", 404)
        bill         = dict(bill_data["bill"])
        bill_num     = bill.get("bill_number") or str(bid)
        receipt_date = data.get("receipt_date", str(date.today()))
        reference    = data.get("reference", "BILL-" + bill_num)
        receipt_id = create_stock_receipt(
            db(), bid,
            receipt_date=receipt_date,
            reference=reference,
            notes=data.get("notes", ""),
        )
        conn = get_connection(db())
        for ln in lines:
            qty = float(ln.get("qty", 0))
            if qty <= 0:
                continue
            item_id = ln.get("item_id")
            if item_id:
                # If post_bill already auto-created a PURCHASE movement for this
                # bill/item (receipt_id IS NULL), adopt it instead of creating a
                # second movement (which would double qty_on_hand and trading totals).
                auto_mov = conn.execute(
                    """SELECT id FROM inventory_movements
                       WHERE source_doc_type='bill' AND source_doc_id=?
                         AND item_id=? AND movement_type='PURCHASE'
                         AND receipt_id IS NULL
                       LIMIT 1""",
                    (bid, item_id)).fetchone()
                if auto_mov:
                    conn.execute(
                        """UPDATE inventory_movements
                           SET receipt_id=?, movement_date=?, reference=?,
                               notes=?, created_by=?
                           WHERE id=?""",
                        (receipt_id, receipt_date, reference,
                         f"Receipt {receipt_id}",
                         current_user().get("username", "?"),
                         auto_mov["id"]))
                else:
                    post_stock_movement(
                        db(), item_id=item_id, movement_type="PURCHASE",
                        movement_date=receipt_date,
                        qty=qty, unit_cost=float(ln.get("unit_price", 0)),
                        reference=reference,
                        source_doc_type="bill", source_doc_id=bid,
                        notes=f"Receipt {receipt_id}",
                        created_by=current_user().get("username", "?"),
                        receipt_id=receipt_id,
                        post_gl=False,
                    )
            # Update qty_received on the bill line (additive)
            conn.execute(
                "UPDATE bill_lines SET qty_received = COALESCE(qty_received,0) + ? WHERE id=?",
                (qty, ln["line_id"])
            )
        conn.commit()
        audit(db(), current_user().get("id"), current_user().get("username", "?"),
              "ReceiveStock", "bills", bid,
              f"receipt_id={receipt_id} lines={len(lines)}")
        return ok({"receipt_id": receipt_id})
    except Exception as e:
        return err(str(e))

@app.route("/api/bills", methods=["POST"])
@login_required
def api_bill_save():
    data = request.get_json() or {}
    try:
        bid = save_bill(db(), data, data.get("lines", []))
        job_id = data.get("job_id")
        set_bill_job(db(), bid, job_id if job_id else None)
        return ok({"id": bid})
    except Exception as e:
        return err(str(e))


@app.route("/api/bills/<int:bid>/job", methods=["GET"])
@login_required
def api_bill_job_get(bid):
    job_id = get_job_for_bill(db(), bid)
    return ok({"job_id": job_id})

@app.route("/api/bills/<int:bid>/job", methods=["PUT"])
@login_required
def api_bill_job_set(bid):
    data   = request.get_json() or {}
    job_id = data.get("job_id")
    try:
        set_bill_job(db(), bid, job_id if job_id else None)
        return ok()
    except Exception as e:
        return err(str(e))


# ── Supplier Payment Run  (Stage 5S) ──────────────────────────────────────────

@app.route("/api/bills/payment-run/candidates")
@login_required
def api_bills_payment_run_candidates():
    """
    Return all Approved/Overdue bills with a balance > 0, including supplier
    BSB/account availability flag.  Used to populate the payment run dialog.
    """
    from core.aba import get_bills_for_aba
    rows = get_bills_for_aba(db())   # no date filter — return all payable bills
    # Sort in Python — avoids NULLS LAST syntax which requires SQLite 3.30+
    rows.sort(key=lambda r: (r.get("due_date") or "9999-99-99", r.get("supplier_name") or ""))
    # Flag whether this supplier has bank details (for ABA eligibility indicator)
    for r in rows:
        r["has_bank"] = bool(r.get("dest_bsb") and r.get("dest_account"))
    return ok(rows)


@app.route("/api/bills/payment-run", methods=["POST"])
@login_required
def api_bills_payment_run():
    """
    Batch-pay a selection of bills, one payment per supplier (consolidated).

    POST body:
      {
        bill_ids:        [1, 2, 3],
        bank_account_id: 5,
        payment_date:    "2026-04-16",
        generate_aba:    true,
        aba_description: "SUPPLIERS"   (optional, max 12 chars)
      }

    Returns:
      {
        posted:      [{contact_id, amount, payment_id}, ...],
        pmt_ids:     [101, 102],
        aba_content: "0 ..."  | null,
        errors:      [],
        missing_bank: ["Acme Pty Ltd", ...]   (suppliers skipped from ABA)
      }
    """
    from collections import defaultdict
    from core.aba import generate_aba, get_payments_for_aba, ABAError

    body            = request.json or {}
    bill_ids        = [int(i) for i in (body.get("bill_ids") or [])]
    bank_account_id = body.get("bank_account_id")
    payment_date    = body.get("payment_date") or str(date.today())
    want_aba        = bool(body.get("generate_aba"))
    description     = (body.get("aba_description") or "SUPPLIERS")[:12]

    if not bill_ids:
        return err("No bills selected", 400)
    if not bank_account_id:
        return err("No bank account selected", 400)

    # Load selected bills from the candidates query (includes contact_id, balance)
    from core.aba import get_bills_for_aba
    all_candidates = {r["bill_id"]: r for r in get_bills_for_aba(db())}
    selected = [all_candidates[i] for i in bill_ids if i in all_candidates]
    if not selected:
        return err("No valid payable bills found for the selected IDs", 400)

    # Group by supplier — one payment per contact, allocating all their bills
    by_supplier = defaultdict(list)
    for b in selected:
        by_supplier[b["contact_id"]].append(b)

    posted = []; errors = []; pmt_ids = []

    for contact_id, bills in by_supplier.items():
        amount      = sum(b["balance_due"] for b in bills)
        allocations = [{"bill_id": b["bill_id"], "amount": b["balance_due"]} for b in bills]
        try:
            pid = record_payment(db(), {
                "payment_type":    "Payment",
                "contact_id":      contact_id,
                "payment_date":    payment_date,
                "amount":          round(amount, 2),
                "bank_account_id": bank_account_id,
                "reference":       f"Pmt run {payment_date}",
                "description":     (
                    f"Payment run \u2014 {len(bills)} bill"
                    f"{'s' if len(bills) != 1 else ''}"
                ),
            }, allocations)
            pmt_ids.append(pid)
            posted.append({
                "contact_id":  contact_id,
                "amount":      round(amount, 2),
                "payment_id":  pid,
                "supplier":    bills[0].get("supplier_name", ""),
            })
        except Exception as e:
            errors.append(f"{bills[0].get('supplier_name','?')}: {e}")

    # Optional ABA generation
    aba_content  = None
    missing_bank = []

    if want_aba and pmt_ids:
        try:
            pmts = get_payments_for_aba(db(), payment_date, payment_date)
            pmts = [p for p in pmts if p.get("payment_id") in pmt_ids]

            # Separate payments with and without bank details
            ok_pmts = [p for p in pmts if p.get("dest_bsb") and p.get("dest_account")]
            no_bank = [p for p in pmts if not (p.get("dest_bsb") and p.get("dest_account"))]
            missing_bank = [p["dest_name"] for p in no_bank]

            if ok_pmts:
                aba_content = generate_aba(db(), ok_pmts, payment_date, description)
        except ABAError as e:
            errors.append(f"ABA: {e}")
        except Exception as e:
            errors.append(f"ABA (unexpected): {e}")

    return ok({
        "posted":       posted,
        "pmt_ids":      pmt_ids,
        "aba_content":  aba_content,
        "errors":       errors,
        "missing_bank": missing_bank,
    })


# ── ABA Export  (Stage 5T) ────────────────────────────────────────────────────

@app.route("/api/bills/aba-candidates")
@login_required
def api_bills_aba_candidates():
    """
    Return posted supplier payments for a date range, ready for ABA selection.
    GET params: from=YYYY-MM-DD, to=YYYY-MM-DD
    """
    from core.aba import get_payments_for_aba
    date_from = request.args.get("from") or str(date.today())
    date_to   = request.args.get("to")   or str(date.today())
    rows = get_payments_for_aba(db(), date_from, date_to)
    return ok(rows)


@app.route("/api/bills/aba-generate", methods=["POST"])
@login_required
def api_bills_aba_generate():
    """
    Generate ABA content for a selected list of payment IDs.
    POST body: { payment_ids: [1,2,3], process_date: "YYYY-MM-DD", description: "SUPPLIERS" }
    Returns: { aba_content: "...", payment_count: N, total: 99.99 }
    Does NOT post any payments — generation only.
    """
    from core.aba import generate_aba, get_payments_for_aba, ABAError
    from datetime import date as _date, timedelta

    body         = request.json or {}
    payment_ids  = set(int(i) for i in (body.get("payment_ids") or []))
    process_date = body.get("process_date") or str(date.today())
    description  = (body.get("description") or "SUPPLIERS")[:12]

    if not payment_ids:
        return err("No payment IDs provided", 400)

    # Fetch a wide window around the process date and filter to requested IDs
    wide_from = (_date.fromisoformat(process_date) - timedelta(days=90)).isoformat()
    wide_to   = (_date.fromisoformat(process_date) + timedelta(days=1)).isoformat()

    all_pmts = get_payments_for_aba(db(), wide_from, wide_to)
    pmts     = [p for p in all_pmts if p.get("payment_id") in payment_ids]

    if not pmts:
        return err("No matching payments found for the supplied IDs", 400)

    ok_pmts = [p for p in pmts if p.get("dest_bsb") and p.get("dest_account")]
    no_bank = [p["dest_name"] for p in pmts if not (p.get("dest_bsb") and p.get("dest_account"))]

    if not ok_pmts:
        return err(
            "None of the selected payments have bank details on file. "
            "Edit each supplier's contact record and add BSB and Account Number.", 422)

    try:
        aba_content = generate_aba(db(), ok_pmts, process_date, description)
    except ABAError as e:
        return err(str(e), 422)

    total = sum(float(p.get("amount", 0)) for p in ok_pmts)

    return ok({
        "aba_content":   aba_content,
        "payment_count": len(ok_pmts),
        "total":         round(total, 2),
        "missing_bank":  no_bank,
    })


# ── Payments ───────────────────────────────────────────────────────────────────
@app.route("/api/payments")
@login_required
def api_payments():
    return ok([dict(p) for p in get_payments(db())])

@app.route("/api/payments/open-items")
@login_required
def api_payments_open_items():
    """Return unpaid invoices or bills for a contact, for allocation picker.
    Must be defined BEFORE /api/payments/<int:pid> so Flask matches it first."""
    contact_id = request.args.get("contact_id", type=int)
    pmt_type   = request.args.get("type", "Receipt")  # Receipt=invoices, Payment=bills
    conn = get_connection(db())
    if pmt_type == "Receipt":
        rows = conn.execute("""
            SELECT id, invoice_number AS number, due_date,
                   total - COALESCE(amount_paid,0) AS balance
            FROM invoices
            WHERE contact_id=? AND status NOT IN ('Paid','Void')
              AND total - COALESCE(amount_paid,0) > 0.005
            ORDER BY due_date""", (contact_id,)).fetchall() if contact_id else []
    else:
        rows = conn.execute("""
            SELECT id, bill_number AS number, due_date,
                   total - COALESCE(amount_paid,0) AS balance
            FROM bills
            WHERE contact_id=? AND status NOT IN ('Paid','Void')
              AND total - COALESCE(amount_paid,0) > 0.005
            ORDER BY due_date""", (contact_id,)).fetchall() if contact_id else []
    conn.close()
    return ok([dict(r) for r in rows])

@app.route("/api/payments/<int:pid>")
@login_required
def api_payment(pid):
    data = get_payment(db(), pid)
    if not data:
        return err("Not found", 404)
    return ok({"payment": dict(data["payment"]),
               "allocations": [dict(a) for a in data["allocations"]]})

@app.route("/api/payments", methods=["POST"])
@login_required
def api_payment_new():
    """Record a standalone payment/receipt (not linked to a specific invoice/bill via URL)."""
    data = request.get_json() or {}
    try:
        pmt_data = {
            "payment_type":       data.get("payment_type", "Receipt"),
            "contact_id":         data.get("contact_id"),
            "payment_date":       data.get("payment_date", str(date.today())),
            "amount":             float(data.get("amount", 0)),
            "bank_account_id":    data.get("bank_account_id"),
            "payment_method":     data.get("payment_method", "EFT"),
            "reference":          data.get("reference", ""),
            "description":        data.get("description", ""),
            "expense_account_id": data.get("expense_account_id"),
            "tax_code":           data.get("tax_code", "N-T"),
        }
        allocations = data.get("allocations", [])
        pid = record_payment(db(), pmt_data, allocations)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "NewPayment", "payments", pid,
              f"{pmt_data['payment_type']} amount={pmt_data['amount']}")
        return ok({"id": pid})
    except Exception as e:
        return err(str(e))

@app.route("/api/payments/<int:pid>", methods=["PUT"])
@login_required
def api_payment_amend(pid):
    """Amend a payment via void+re-record."""
    data = request.get_json() or {}
    try:
        new_data = {
            "payment_type":       data.get("payment_type", "Receipt"),
            "contact_id":         data.get("contact_id"),
            "payment_date":       data.get("payment_date", str(date.today())),
            "amount":             float(data.get("amount", 0)),
            "bank_account_id":    data.get("bank_account_id"),
            "payment_method":     data.get("payment_method", "EFT"),
            "reference":          data.get("reference", ""),
            "description":        data.get("description", ""),
            "expense_account_id": data.get("expense_account_id"),
            "tax_code":           data.get("tax_code", "N-T"),
        }
        allocations = data.get("allocations", [])
        new_id = amend_payment(db(), pid, new_data, allocations)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "AmendPayment", "payments", pid,
              f"amended → new id={new_id}")
        return ok({"id": new_id})
    except Exception as e:
        return err(str(e))

@app.route("/api/payments/<int:pid>/void", methods=["POST"])
@login_required
def api_payment_void(pid):
    try:
        void_payment(db(), pid)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "VoidPayment", "payments", pid, f"Payment {pid} voided via web UI")
        return ok()
    except Exception as e:
        return err(str(e))


# ── Journal ────────────────────────────────────────────────────────────────────
@app.route("/api/journal")
@login_required
def api_journal():
    search   = request.args.get("search")
    etype    = request.args.get("type")
    date_from = request.args.get("from")
    date_to   = request.args.get("to")
    limit    = max(1, min(1000, int(request.args.get("limit", 200) or 200)))
    rows = get_journal_entries_full(
        db(),
        entry_type=etype if etype and etype != "All" else None,
        search=search or None,
        date_from=date_from or None,
        date_to=date_to or None,
        limit=limit,
    )
    return ok([dict(r) for r in rows])

@app.route("/api/journal/<int:jid>")
@login_required
def api_journal_entry(jid):
    entry, lines = get_journal_entry(db(), jid)
    if not entry:
        return err("Not found", 404)
    return ok({"entry": dict(entry), "lines": [dict(l) for l in lines]})

@app.route("/api/journal", methods=["POST"])
@login_required
def api_journal_post():
    data = request.get_json() or {}
    try:
        jid = post_journal(
            db(),
            data["entry_date"],
            data["description"],
            data.get("reference", ""),
            data.get("lines", []),
        )
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "NewJournal", "journal_entry", jid, data["description"])
        return ok({"id": jid})
    except Exception as e:
        return err(str(e))

@app.route("/api/journal/<int:jid>", methods=["PUT"])
@login_required
def api_journal_update(jid):
    data = request.get_json() or {}
    try:
        update_journal(db(), jid, data["entry_date"], data.get("reference",""),
                       data["description"], data.get("lines", []))
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/journal/<int:jid>/void", methods=["POST"])
@login_required
def api_journal_void(jid):
    try:
        rev = void_journal(db(), jid)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "VoidJournal", "journal_entry", jid, f"reversal={rev}")
        return ok({"reversal_id": rev})
    except Exception as e:
        return err(str(e))

@app.route("/api/journal/<int:jid>/reverse", methods=["POST"])
@login_required
def api_journal_reverse(jid):
    data = request.get_json() or {}
    try:
        rev = reverse_journal(db(), jid, data.get("reverse_date"))
        return ok({"reversal_id": rev})
    except Exception as e:
        return err(str(e))


# ── Credit Cards ───────────────────────────────────────────────────────────────
@app.route("/api/credit-cards")
@login_required
def api_credit_cards():
    cards = get_credit_card_accounts(db())
    result = []
    for c in cards:
        d = dict(c)
        d["balance"] = round(get_credit_card_balance(db(), c["id"]), 2)
        result.append(d)
    return ok(result)

@app.route("/api/credit-cards/<int:cid>/transactions")
@login_required
def api_cc_transactions(cid):
    txns = get_credit_card_transactions(db(), cid,
        date_from=request.args.get("from"),
        date_to=request.args.get("to"))
    return ok([dict(t) for t in txns])

@app.route("/api/credit-cards/charge", methods=["POST"])
@login_required
def api_cc_charge():
    d = request.get_json() or {}
    try:
        jid = record_credit_card_charge(
            db(), d["card_id"], d["date"], d["description"],
            float(d["amount"]), d["expense_account_id"],
            reference=d.get("reference",""),
            tax_code=d.get("tax_code"),
            gst_amount=float(d.get("gst_amount", 0)),
        )
        return ok({"journal_id": jid})
    except Exception as e:
        return err(str(e))

@app.route("/api/credit-cards/payment", methods=["POST"])
@login_required
def api_cc_payment():
    d = request.get_json() or {}
    try:
        jid = record_credit_card_payment(
            db(), d["card_id"], d["date"],
            float(d["amount"]), d["bank_account_id"],
            reference=d.get("reference",""),
            description=d.get("description","Credit Card Payment"),
        )
        return ok({"journal_id": jid})
    except Exception as e:
        return err(str(e))


# ── CRM ────────────────────────────────────────────────────────────────────────

@app.route("/api/crm/meta")
@login_required
def api_crm_meta():
    """Return pipeline stages, comm types, task types, priorities, quote statuses."""
    return ok({
        "pipeline_stages": PIPELINE_STAGES,
        "comm_types":      COMM_TYPES,
        "task_types":      TASK_TYPES,
        "priority":        PRIORITY,
        "quote_status":    QUOTE_STATUS,
    })


@app.route("/api/crm/opportunities")
@login_required
def api_crm_opps():
    stage  = request.args.get("stage")
    search = request.args.get("search")
    rows   = get_opportunities(db(), stage=stage or None, search=search or None)
    return ok(rows)


@app.route("/api/crm/opportunities/<int:oid>")
@login_required
def api_crm_opp(oid):
    opp = get_opportunity(db(), oid)
    if not opp:
        return err("Not found", 404)
    comms  = get_communications(db(), opp_id=oid)
    tasks  = get_tasks(db(), opp_id=oid, open_only=False)
    quotes = get_quotes(db(), opp_id=oid)
    claims = get_progress_claims(db(), opp_id=oid)
    return ok({"opp": opp, "comms": comms, "tasks": tasks,
               "quotes": quotes, "claims": claims})


@app.route("/api/crm/opportunities", methods=["POST"])
@login_required
def api_crm_opp_save():
    data = request.get_json() or {}
    try:
        if not data.get("opp_number"):
            data["opp_number"] = next_opp_number(db())
        data["created_by"] = current_user().get("id")
        oid = save_opportunity(db(), data)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "SaveOpportunity", "crm_opportunity", oid, data.get("title",""))
        return ok({"id": oid})
    except Exception as e:
        return err(str(e))


@app.route("/api/crm/opportunities/<int:oid>", methods=["PUT"])
@login_required
def api_crm_opp_update(oid):
    data = request.get_json() or {}
    data["id"] = oid
    try:
        save_opportunity(db(), data)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "UpdateOpportunity", "crm_opportunity", oid, data.get("title",""))
        return ok({"id": oid})
    except Exception as e:
        return err(str(e))


@app.route("/api/crm/opportunities/<int:oid>", methods=["DELETE"])
@login_required
def api_crm_opp_delete(oid):
    try:
        delete_opportunity(db(), oid)
        return ok()
    except Exception as e:
        return err(str(e))


@app.route("/api/crm/next-opp-number")
@login_required
def api_crm_next_opp_number():
    return ok(next_opp_number(db()))


# ── CRM Communications ─────────────────────────────────────────────────────────

@app.route("/api/crm/communications", methods=["POST"])
@login_required
def api_crm_comm_save():
    data = request.get_json() or {}
    data["logged_by"] = current_user().get("id")
    try:
        cid = save_communication(db(), data)
        return ok({"id": cid})
    except Exception as e:
        return err(str(e))


@app.route("/api/crm/communications/<int:cid>", methods=["DELETE"])
@login_required
def api_crm_comm_delete(cid):
    try:
        delete_communication(db(), cid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── CRM Tasks ─────────────────────────────────────────────────────────────────

@app.route("/api/crm/tasks", methods=["POST"])
@login_required
def api_crm_task_save():
    data = request.get_json() or {}
    try:
        tid = save_task(db(), data)
        return ok({"id": tid})
    except Exception as e:
        return err(str(e))


@app.route("/api/crm/tasks/<int:tid>/complete", methods=["POST"])
@login_required
def api_crm_task_complete(tid):
    try:
        complete_task(db(), tid)
        return ok()
    except Exception as e:
        return err(str(e))


@app.route("/api/crm/tasks/<int:tid>", methods=["DELETE"])
@login_required
def api_crm_task_delete(tid):
    try:
        delete_task(db(), tid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── Standalone Quotes list ────────────────────────────────────────────────────

@app.route("/api/quotes")
@login_required
def api_quotes_all():
    """Return all quotes regardless of opportunity, enriched with contact/opp names."""
    quotes = get_quotes(db())          # opp_id=None → returns all
    contacts = {c["id"]: c["name"] for c in get_contacts(db())}
    result = []
    for q in quotes:
        q = dict(q)
        q["contact_name"] = contacts.get(q.get("contact_id"), "—")
        result.append(q)
    return ok(result)


@app.route("/api/crm/quotes/<int:qid>/pdf")
@login_required
def api_crm_quote_pdf(qid):
    """Download a quote as a PDF."""
    try:
        from core.quote_pdf import generate_quote_pdf
        import tempfile, os
        from flask import send_file
        watermark = _get_pdf_watermark()
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
            tmp_path = tmp.name
        generate_quote_pdf(db(), qid, output_path=tmp_path, watermark=watermark)
        q, _ = get_quote(db(), qid)
        fname = f"Quote-{q['quote_number']}.pdf" if q else "quote.pdf"
        response = send_file(tmp_path, mimetype="application/pdf",
                             as_attachment=True, download_name=fname)
        @response.call_on_close
        def _cleanup(): 
            try: os.unlink(tmp_path)
            except: pass
        return response
    except Exception as e:
        return err(str(e))


# ── CRM Quotes ────────────────────────────────────────────────────────────────

@app.route("/api/crm/quotes/<int:qid>")
@login_required
def api_crm_quote(qid):
    q, lines = get_quote(db(), qid)
    if not q:
        return err("Not found", 404)
    return ok({"quote": q, "lines": lines})


@app.route("/api/crm/quotes", methods=["POST"])
@login_required
def api_crm_quote_save():
    body = request.get_json() or {}
    qdata = body.get("quote", {})
    lines = body.get("lines", [])
    if not qdata.get("quote_number"):
        qdata["quote_number"] = next_quote_number(db())
    qdata["created_by"] = current_user().get("id")
    try:
        qid = save_quote(db(), qdata, lines)
        return ok({"id": qid})
    except Exception as e:
        return err(str(e))


@app.route("/api/crm/quotes/<int:qid>", methods=["PUT"])
@login_required
def api_crm_quote_update(qid):
    body = request.get_json() or {}
    qdata = body.get("quote", {})
    lines = body.get("lines", [])
    qdata["id"] = qid
    try:
        save_quote(db(), qdata, lines)
        return ok({"id": qid})
    except Exception as e:
        return err(str(e))


@app.route("/api/crm/quotes/<int:qid>/accept", methods=["POST"])
@login_required
def api_crm_quote_accept(qid):
    try:
        opp_id = accept_quote(db(), qid, current_user().get("username",""))
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "AcceptQuote", "crm_quote", qid, "")
        return ok({"opp_id": opp_id})
    except Exception as e:
        return err(str(e))


@app.route("/api/crm/quotes/<int:qid>/convert", methods=["POST"])
@login_required
def api_crm_quote_convert(qid):
    """Convert accepted quote to a draft invoice. Returns invoice_id."""
    try:
        inv_id = convert_quote_to_invoice(db(), qid, current_user().get("id"))
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "ConvertQuoteToInvoice", "crm_quote", qid, f"inv={inv_id}")
        return ok({"invoice_id": inv_id})
    except Exception as e:
        return err(str(e))


@app.route("/api/crm/quotes/<int:qid>", methods=["DELETE"])
@login_required
def api_crm_quote_delete(qid):
    try:
        delete_quote(db(), qid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── CRM Progress Claims ───────────────────────────────────────────────────────

@app.route("/api/crm/claims", methods=["POST"])
@login_required
def api_crm_claim_save():
    data = request.get_json() or {}
    data["created_by"] = current_user().get("id")
    try:
        cid = save_progress_claim(db(), data)
        return ok({"id": cid})
    except Exception as e:
        return err(str(e))


@app.route("/api/crm/claims/<int:cid>/convert", methods=["POST"])
@login_required
def api_crm_claim_convert(cid):
    try:
        inv_id = claim_to_invoice(db(), cid, current_user().get("id"))
        return ok({"invoice_id": inv_id})
    except Exception as e:
        return err(str(e))


@app.route("/api/crm/claims/<int:cid>", methods=["DELETE"])
@login_required
def api_crm_claim_delete(cid):
    try:
        delete_progress_claim(db(), cid)
        return ok()
    except Exception as e:
        return err(str(e))


@app.route("/api/crm/opportunities/<int:oid>/transactions")
@login_required
def api_crm_opp_transactions(oid):
    """Return all invoices and bills for the contact linked to this opportunity,
    merged and sorted by date descending.  contact_id-only query — no opp_id
    FK on invoices/bills tables yet (deferred to pre-beta)."""
    opp = get_opportunity(db(), oid)
    if not opp:
        return err("Not found", 404)
    contact_id = opp.get("contact_id")
    if not contact_id:
        return ok([])

    invoices = get_invoices(db(), contact_id=contact_id)
    bills    = get_bills(db(),    contact_id=contact_id)

    rows = []
    for inv in invoices:
        rows.append({
            "type":        "Invoice",
            "id":          inv["id"],
            "number":      inv.get("invoice_number") or "",
            "date":        inv.get("invoice_date")   or "",
            "due_date":    inv.get("due_date")        or "",
            "status":      inv.get("status")          or "",
            "total":       float(inv.get("total")     or 0),
            "balance_due": round(float(inv.get("total") or 0)
                                 - float(inv.get("amount_paid") or 0), 2),
            "contact_name": inv.get("contact_name")  or "",
        })
    for bill in bills:
        rows.append({
            "type":        "Bill",
            "id":          bill["id"],
            "number":      bill.get("bill_number")  or "",
            "date":        bill.get("bill_date")    or "",
            "due_date":    bill.get("due_date")      or "",
            "status":      bill.get("status")        or "",
            "total":       float(bill.get("total")  or 0),
            "balance_due": round(float(bill.get("total") or 0)
                                 - float(bill.get("amount_paid") or 0), 2),
            "contact_name": bill.get("contact_name") or "",
        })

    rows.sort(key=lambda r: (r["date"] or ""), reverse=True)
    return ok(rows)
# ── Bank Reconciliation ───────────────────────────────────────────────────────

@app.route("/api/bankrec/accounts")
@login_required
def api_bankrec_accounts():
    """Return all bank/savings/credit-card accounts suitable for reconciliation."""
    RECONCILABLE_SUBTYPES = {
        "Bank", "Savings", "Cash", "Credit Card",
        "PayPal", "Electronic Clearing", "Term Deposit",
    }
    all_asset = get_accounts(db(), account_type="Asset")
    result = []
    for a in all_asset:
        a = dict(a)
        if a.get("is_bank") or a.get("is_credit_card") \
                or a.get("account_subtype") in RECONCILABLE_SUBTYPES:
            result.append(a)
    result.sort(key=lambda a: (
        0 if a.get("is_bank") else 1 if a.get("is_credit_card") else 2,
        a.get("code", "")
    ))
    return ok(result)


@app.route("/api/bankrec/<int:acc_id>/transactions")
@login_required
def api_bankrec_transactions(acc_id):
    """Return merged journal + CSV transactions for an account, with duplicate flags."""
    txns = get_bank_journal_transactions(db(), acc_id)
    for t in txns:
        t["_source"] = "journal"

    csv_txns = get_bank_transactions(db(), acc_id)
    for t in csv_txns:
        t["_source"] = "csv"

    # Duplicate detection.
    # CSV uses bank-statement convention: credit=money-in, debit=money-out.
    # GL journal lines use Asset convention:  debit=money-in, credit=money-out.
    # Swap CSV debit/credit when building the key so the same real-world event matches.
    #
    # Allocated CSVs (journal_id set) and the journal lines they created are excluded
    # from dup detection — they're the same transaction, not independent duplicates.
    alloc_jids = {t["journal_id"] for t in csv_txns if t.get("journal_id")}

    j_by_key = {}
    for t in txns:
        if t.get("journal_id") in alloc_jids:
            continue  # Journal line created from a CSV allocation — skip
        key = (t["transaction_date"],
               round(float(t.get("debit") or 0), 2),
               round(float(t.get("credit") or 0), 2))
        j_by_key.setdefault(key, []).append(t["id"])

    dup_ids = set()
    for t in csv_txns:
        if t.get("journal_id"):
            continue  # Already allocated — not a loose duplicate
        key = (t["transaction_date"],
               round(float(t.get("credit") or 0), 2),   # bank credit → GL debit
               round(float(t.get("debit")  or 0), 2))   # bank debit  → GL credit
        if key in j_by_key:
            dup_ids.add(f"csv:{t['id']}")
            for jid in j_by_key[key]:
                dup_ids.add(f"journal:{jid}")

    all_txns = txns + csv_txns
    for t in all_txns:
        iid = f"{t['_source']}:{t['id']}"
        t["_iid"]       = iid
        t["_duplicate"] = iid in dup_ids

    all_txns.sort(key=lambda x: (x["transaction_date"], x.get("id", 0)))
    return ok(all_txns)


@app.route("/api/bankrec/<int:acc_id>/last-reconciliation")
@login_required
def api_bankrec_last_rec(acc_id):
    rec = get_last_reconciliation(db(), acc_id)
    return ok(rec)


@app.route("/api/bankrec/<int:acc_id>/reconciliations")
@login_required
def api_bankrec_all_recs(acc_id):
    """Debug: return all reconciliation records for an account."""
    conn = get_connection(db())
    rows = conn.execute(
        "SELECT * FROM bank_reconciliations WHERE account_id=? ORDER BY id DESC",
        (acc_id,)
    ).fetchall()
    conn.close()
    return ok([dict(r) for r in rows])


@app.route("/api/bankrec/reconcile", methods=["POST"])
@login_required
def api_bankrec_reconcile():
    """Mark journal lines or CSV transactions as reconciled/unreconciled."""
    data = request.get_json() or {}
    items    = data.get("items", [])   # [{source, id}]
    reconcile = data.get("reconcile", True)
    from datetime import date as _date
    today = str(_date.today())
    conn = get_connection(db())
    try:
        for item in items:
            src = item.get("source")
            rid = item.get("id")
            if src == "journal":
                if reconcile:
                    conn.execute(
                        "UPDATE journal_lines SET is_reconciled=1, reconciled_date=? WHERE id=?",
                        (today, rid))
                else:
                    conn.execute(
                        "UPDATE journal_lines SET is_reconciled=0, reconciled_date=NULL WHERE id=?",
                        (rid,))
            else:
                if reconcile:
                    conn.execute(
                        "UPDATE bank_transactions SET is_reconciled=1, reconciled_date=? WHERE id=?",
                        (today, rid))
                else:
                    conn.execute(
                        "UPDATE bank_transactions SET is_reconciled=0, reconciled_date=NULL WHERE id=?",
                        (rid,))
        conn.commit()
        return ok()
    except Exception as e:
        return err(str(e))
    finally:
        conn.close()


@app.route("/api/bankrec/reject", methods=["POST"])
@login_required
def api_bankrec_reject():
    """Mark rows as rejected duplicates (hidden from rec list)."""
    data  = request.get_json() or {}
    items = data.get("items", [])
    conn  = get_connection(db())
    try:
        for item in items:
            src = item.get("source")
            rid = item.get("id")
            if src == "journal":
                conn.execute("UPDATE journal_lines SET is_rejected=1 WHERE id=?", (rid,))
            else:
                conn.execute("UPDATE bank_transactions SET is_rejected=1 WHERE id=?", (rid,))
        conn.commit()
        return ok()
    except Exception as e:
        return err(str(e))
    finally:
        conn.close()


@app.route("/api/bankrec/unreject", methods=["POST"])
@login_required
def api_bankrec_unreject():
    """Restore rejected rows back to active reconciliation list."""
    data  = request.get_json() or {}
    items = data.get("items", [])
    conn  = get_connection(db())
    try:
        for item in items:
            src = item.get("source")
            rid = item.get("id")
            if src == "journal":
                conn.execute("UPDATE journal_lines SET is_rejected=0 WHERE id=?", (rid,))
            else:
                conn.execute("UPDATE bank_transactions SET is_rejected=0 WHERE id=?", (rid,))
        conn.commit()
        return ok()
    except Exception as e:
        return err(str(e))
    finally:
        conn.close()


@app.route("/api/bankrec/allocate", methods=["POST"])
@login_required
def api_bankrec_allocate():
    """Allocate a CSV bank transaction to a GL account, invoice, or bill."""
    data = request.get_json() or {}
    bank_txn_id = data.get("bank_txn_id")
    mode        = data.get("mode")          # "account" | "invoice" | "bill"
    alloc_data  = data.get("alloc_data", {})
    try:
        jid = allocate_bank_transaction(db(), bank_txn_id, mode, alloc_data)
        return ok({"journal_id": jid})
    except Exception as e:
        return err(str(e))


@app.route("/api/bankrec/deallocate", methods=["POST"])
@login_required
def api_bankrec_deallocate():
    """Remove categorisation from a CSV bank transaction."""
    data = request.get_json() or {}
    bank_txn_id = data.get("bank_txn_id")
    try:
        deallocate_bank_transaction(db(), bank_txn_id)
        return ok()
    except Exception as e:
        return err(str(e))


@app.route("/api/bankrec/<int:acc_id>/complete", methods=["POST"])
@login_required
def api_bankrec_complete(acc_id):
    """Finalise a reconciliation period."""
    data            = request.get_json() or {}
    reconcile_date  = data.get("reconcile_date")
    closing_balance = data.get("closing_balance")
    if not reconcile_date or closing_balance is None:
        return err("reconcile_date and closing_balance are required")
    expected_opening = data.get("opening_balance")
    # Parse selected_iids (e.g. ["journal:12","csv:7"]) into typed ID lists
    selected_iids = data.get("selected_iids")
    journal_line_ids = None
    bank_txn_ids = None
    if selected_iids is not None:
        journal_line_ids, bank_txn_ids = [], []
        for iid in selected_iids:
            try:
                source, id_str = iid.split(":", 1)
                id_val = int(id_str)
            except (ValueError, AttributeError):
                continue
            if source == "journal":
                journal_line_ids.append(id_val)
            elif source == "csv":
                bank_txn_ids.append(id_val)
    try:
        complete_reconciliation(db(), acc_id, reconcile_date, float(closing_balance),
                                expected_opening=expected_opening,
                                journal_line_ids=journal_line_ids,
                                bank_txn_ids=bank_txn_ids)
        return ok()
    except Exception as e:
        return err(str(e))


@app.route("/api/bankrec/<int:acc_id>/rec-report")
@login_required
def api_bankrec_rec_report(acc_id):
    """Bank reconciliation proof report: GL balance vs bank statement balance."""
    conn = get_connection(db())
    acc = conn.execute("SELECT * FROM accounts WHERE id=?", (acc_id,)).fetchone()
    if not acc:
        conn.close()
        return err("Account not found")
    last_rec = conn.execute("""SELECT * FROM bank_reconciliations
        WHERE account_id=? AND status='Completed'
        ORDER BY reconcile_date DESC, id DESC LIMIT 1""", (acc_id,)).fetchone()
    unrgl = conn.execute("""
        SELECT jl.id, je.entry_date AS date,
               COALESCE(jl.description, je.description, '') AS description,
               COALESCE(je.reference, '') AS reference,
               jl.debit, jl.credit
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id = je.id
        WHERE jl.account_id = ?
          AND jl.is_reconciled = 0
          AND (jl.is_rejected IS NULL OR jl.is_rejected = 0)
        ORDER BY je.entry_date, je.id
    """, (acc_id,)).fetchall()
    unrbank = conn.execute("""
        SELECT id, transaction_date AS date, description, reference, debit, credit
        FROM bank_transactions
        WHERE account_id = ?
          AND is_reconciled = 0
          AND (is_rejected IS NULL OR is_rejected = 0)
        ORDER BY transaction_date, id
    """, (acc_id,)).fetchall()
    conn.close()

    gl_balance   = get_account_balance(db(), acc_id)
    last_rec_bal = float(last_rec["closing_balance"]) if last_rec else 0.0
    # GL: asset convention — debit=money in, credit=money out
    unrgl_net    = sum(float(r["debit"] or 0) - float(r["credit"] or 0) for r in unrgl)
    # Bank: statement convention — credit=money in, debit=money out
    unrbank_net  = sum(float(r["credit"] or 0) - float(r["debit"] or 0) for r in unrbank)
    bank_balance = round(last_rec_bal + unrbank_net, 2)
    difference   = round(gl_balance - bank_balance, 2)

    return ok({
        "account":               {"id": acc_id, "code": acc["code"], "name": acc["name"]},
        "as_at":                 str(date.today()),
        "gl_balance":            round(gl_balance, 2),
        "last_rec":              dict(last_rec) if last_rec else None,
        "last_rec_balance":      round(last_rec_bal, 2),
        "unreconciled_gl":       [dict(r) for r in unrgl],
        "unreconciled_gl_net":   round(unrgl_net, 2),
        "unreconciled_bank":     [dict(r) for r in unrbank],
        "unreconciled_bank_net": round(unrbank_net, 2),
        "bank_balance":          bank_balance,
        "difference":            difference,
    })


@app.route("/api/bankrec/<int:acc_id>/import-csv", methods=["POST"])
@login_required
def api_bankrec_import_csv(acc_id):
    """
    Import pre-parsed bank CSV rows.
    Body: { rows: [{date, description, reference, debit, credit, balance}] }
    """
    data = request.get_json() or {}
    rows = data.get("rows", [])
    if not rows:
        return err("No rows supplied")
    try:
        inserted = import_bank_csv(db(), acc_id, rows)
        return ok({"inserted": inserted})
    except Exception as e:
        return err(str(e))


# ── Bank Rules ────────────────────────────────────────────────────────────────

@app.route("/api/bankrec/rules")
@login_required
def api_bankrec_rules_list():
    from core.bank_rules import get_all_rules
    return ok(get_all_rules(db()))


@app.route("/api/bankrec/rules", methods=["POST"])
@login_required
def api_bankrec_rules_save():
    from core.bank_rules import save_rule
    data = request.get_json() or {}
    try:
        rid = save_rule(db(), data)
        return ok({"id": rid})
    except Exception as e:
        return err(str(e))


@app.route("/api/bankrec/rules/<int:rid>", methods=["PUT"])
@login_required
def api_bankrec_rules_update(rid):
    from core.bank_rules import save_rule
    data = request.get_json() or {}
    data["id"] = rid
    try:
        save_rule(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))


@app.route("/api/bankrec/rules/<int:rid>", methods=["DELETE"])
@login_required
def api_bankrec_rules_delete(rid):
    from core.bank_rules import delete_rule
    try:
        delete_rule(db(), rid)
        return ok()
    except Exception as e:
        return err(str(e))


@app.route("/api/bankrec/apply-rules", methods=["POST"])
@login_required
def api_bankrec_apply_rules():
    """Apply saved categorisation rules to a list of unallocated CSV transactions."""
    from core.bank_rules import apply_rules
    data       = request.get_json() or {}
    candidates = data.get("transactions", [])
    if not candidates:
        return ok({"applied": 0})
    matched_pairs = apply_rules(db(), candidates)
    applied = 0
    errors  = []
    for txn, rule in matched_pairs:
        acc_id = rule.get("account_id")
        if not acc_id:
            continue
        try:
            allocate_bank_transaction(
                db(), txn["id"], "account",
                {"account_id": acc_id,
                 "amount": float(txn.get("debit") or txn.get("credit") or 0),
                 "contact_id": rule.get("contact_id")})
            applied += 1
        except Exception as e:
            errors.append(str(e))
    return ok({"applied": applied, "errors": errors})


@app.route("/api/jobs")
@login_required
def api_jobs():
    return ok([dict(j) for j in get_jobs(db())])

@app.route("/api/jobs/<int:jid>")
@login_required
def api_job(jid):
    job = get_job(db(), jid)
    if not job:
        return err("Not found", 404)
    pl = get_job_pl(db(), jid)
    txns = get_job_transactions(db(), jid)
    return ok({"job": dict(job), "pl": pl, "transactions": [dict(t) for t in txns]})

@app.route("/api/jobs", methods=["POST"])
@login_required
def api_job_save():
    data = request.get_json() or {}
    try:
        jid = save_job(db(), data)
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "SaveJob", "job", jid, data.get("name",""))
        return ok({"id": jid})
    except Exception as e:
        return err(str(e))

@app.route("/api/jobs/<int:jid>", methods=["DELETE"])
@login_required
def api_job_delete(jid):
    try:
        delete_job(db(), jid)
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/jobs/<int:jid>/allocate", methods=["POST"])
@login_required
def api_job_allocate(jid):
    d = request.get_json() or {}
    try:
        allocate_transaction(db(), jid, d["source_type"], d["source_id"],
                             float(d.get("amount", 0)),
                             d.get("notes",""),
                             current_user().get("id"))
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/jobs/allocations/<int:alloc_id>", methods=["DELETE"])
@login_required
def api_job_deallocate(alloc_id):
    try:
        conn = get_connection(db())
        row = conn.execute(
            "SELECT job_id, source_type, source_id FROM job_transactions WHERE id=?",
            (alloc_id,)).fetchone()
        conn.close()
        if not row:
            return err("Allocation not found", 404)
        deallocate_transaction(db(), row["job_id"], row["source_type"], row["source_id"])
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/jobs/unallocated")
@login_required
def api_unallocated():
    invs  = get_unallocated_invoices(db())
    bills = get_unallocated_bills(db())
    pmts  = get_unallocated_payments(db())
    return ok({
        "invoices": [dict(i) for i in invs],
        "bills":    [dict(b) for b in bills],
        "payments": [dict(p) for p in pmts],
    })

@app.route("/api/jobs/next-number")
@login_required
def api_job_next_number():
    return ok(next_job_number(db()))

@app.route("/api/jobs/<int:jid>/time")
@login_required
def api_job_time_list(jid):
    return ok([dict(e) for e in get_job_time_entries(db(), jid)])

@app.route("/api/jobs/<int:jid>/time/<int:eid>")
@login_required
def api_job_time_get(jid, eid):
    entries = get_job_time_entries(db(), jid)
    row = next((e for e in entries if e["id"] == eid), None)
    if not row:
        return err("Not found", 404)
    return ok(dict(row))

@app.route("/api/jobs/<int:jid>/time", methods=["POST"])
@login_required
def api_job_time_save(jid):
    data = request.get_json() or {}
    data["job_id"] = jid
    try:
        eid = save_job_time_entry(db(), data)
        return ok({"id": eid})
    except Exception as e:
        return err(str(e))

@app.route("/api/jobs/time/<int:eid>", methods=["DELETE"])
@login_required
def api_job_time_delete(eid):
    try:
        delete_job_time_entry(db(), eid)
        return ok()
    except Exception as e:
        return err(str(e))


# ── Recurring ──────────────────────────────────────────────────────────────────
@app.route("/api/recurring")
@login_required
def api_recurring():
    templates = get_templates(db())
    return ok([dict(t) for t in templates])

@app.route("/api/recurring/upcoming")
@login_required
def api_recurring_upcoming():
    days = max(1, min(365, int(request.args.get("days", 30) or 30)))
    return ok([dict(t) for t in get_upcoming(db(), days=days)])

@app.route("/api/recurring/<int:tid>")
@login_required
def api_recurring_template(tid):
    t = get_template(db(), tid)
    return ok(dict(t)) if t else err("Not found", 404)

@app.route("/api/recurring", methods=["POST"])
@login_required
def api_recurring_save():
    data = request.get_json() or {}
    try:
        tid = save_template(db(), data)
        return ok({"id": tid})
    except Exception as e:
        return err(str(e))

@app.route("/api/recurring/<int:tid>", methods=["DELETE"])
@login_required
def api_recurring_delete(tid):
    try:
        delete_template(db(), tid)
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/recurring/<int:tid>", methods=["PUT"])
@login_required
def api_recurring_update(tid):
    data = request.get_json() or {}
    data["id"] = tid
    try:
        save_template(db(), data)
        return ok()
    except Exception as e:
        return err(str(e))

@app.route("/api/recurring/process", methods=["POST"])
@login_required
def api_recurring_process():
    data = request.get_json() or {}
    try:
        results = process_due_templates(
            db(), as_of=data.get("as_of") or str(date.today()))
        audit(db(), current_user().get("id"), current_user().get("username","?"),
              "ProcessRecurring", "recurring", None,
              f"{len(results)} templates processed")
        return ok(results)
    except Exception as e:
        return err(str(e))

@app.route("/api/recurring/<int:tid>/runs")
@login_required
def api_recurring_runs(tid):
    return ok([dict(r) for r in get_runs(db(), tid)])


# ── Reports ────────────────────────────────────────────────────────────────────
@app.route("/api/reports/trial-balance")
@login_required
def api_trial_balance():
    as_of = request.args.get("as_of", str(date.today()))
    return ok(trial_balance(db(), as_at_date=as_of))

@app.route("/api/reports/profit-loss")
@login_required
def api_profit_loss():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to", str(date.today()))
    basis     = request.args.get("basis", "accrual")
    return ok(profit_and_loss(db(), date_from, date_to, basis=basis))

@app.route("/api/reports/balance-sheet")
@login_required
def api_balance_sheet():
    as_of = request.args.get("as_of", str(date.today()))
    return ok(balance_sheet(db(), as_of))

@app.route("/api/reports/account-ledger")
@login_required
def api_account_ledger():
    account_id = request.args.get("account_id", type=int)
    if not account_id:
        return err("account_id required", 400)
    date_from = request.args.get("from")
    date_to   = request.args.get("to") or request.args.get("as_of")
    data = get_account_ledger(db(), account_id, date_from=date_from, date_to=date_to)
    if data is None:
        return err("Account not found", 404)
    return ok(data)

@app.route("/api/reports/budget-vs-actual")
@login_required
def api_budget_vs_actual():
    periods = get_budget_periods(db())
    if not periods:
        return ok({"rows": [], "period": None})
    pid = int(request.args.get("period_id") or periods[0]["id"])
    rows, period = build_actual_vs_budget_report(db(), pid)
    return ok({"rows": rows, "period": dict(period) if period else None})

@app.route("/api/reports/budget-periods")
@login_required
def api_budget_periods():
    """Return list of all budget periods for the period picker."""
    periods = get_budget_periods(db())
    return ok([dict(p) for p in periods])


@app.route("/api/budget/periods", methods=["POST"])
@login_required
def api_budget_period_create():
    d = request.json or {}
    name = (d.get("name") or "").strip()
    if not name:
        return err("Name is required", 400)
    try:
        fy = int(d.get("fy_year") or 0)
    except (TypeError, ValueError):
        return err("fy_year must be an integer", 400)
    pid = create_budget_period(
        db(), name, fy,
        d.get("period_type", "Annual"),
        d.get("start_date") or f"{fy-1}-07-01",
        d.get("end_date")   or f"{fy}-06-30",
        created_by=session.get("username"))
    audit(db(), session.get("user_id"), session.get("username"),
          "CreateBudget", "budget_period", pid, name)
    return ok({"id": pid})


@app.route("/api/budget/periods/<int:pid>", methods=["PUT"])
@login_required
def api_budget_period_update(pid):
    d = request.json or {}
    name = (d.get("name") or "").strip()
    if not name:
        return err("Name is required", 400)
    try:
        fy = int(d.get("fy_year") or 0)
    except (TypeError, ValueError):
        return err("fy_year must be an integer", 400)
    conn = get_connection(db())
    conn.execute("""UPDATE budget_periods SET name=?,fy_year=?,period_type=?,
        start_date=?,end_date=? WHERE id=?""",
        (name, fy, d.get("period_type","Annual"),
         d.get("start_date") or f"{fy-1}-07-01",
         d.get("end_date")   or f"{fy}-06-30",
         pid))
    conn.commit()
    conn.close()
    return ok()


@app.route("/api/budget/periods/<int:pid>", methods=["DELETE"])
@login_required
def api_budget_period_delete(pid):
    delete_budget_period(db(), pid)
    return ok()


@app.route("/api/budget/periods/<int:pid>/lines", methods=["GET"])
@login_required
def api_budget_lines_get(pid):
    lines = get_budget_lines(db(), pid)
    # Convert integer month keys to strings for JSON safety
    for line in lines:
        line["months"] = {str(k): v for k, v in line["months"].items()}
    return ok(lines)


@app.route("/api/budget/periods/<int:pid>/lines", methods=["POST"])
@login_required
def api_budget_lines_save(pid):
    d = request.json or {}
    lines = d.get("lines", [])
    save_budget_lines(db(), pid, lines)
    audit(db(), session.get("user_id"), session.get("username"),
          "SaveBudget", "budget_period", pid, f"{len(lines)} lines")
    return ok()


@app.route("/api/budget/periods/<int:pid>/template")
@login_required
def api_budget_template(pid):
    csv_data = generate_budget_csv_template(db(), pid)
    period = get_budget_period(db(), pid)
    fname = f"budget_template_{period['name'] if period else pid}.csv"
    from flask import Response
    return Response(csv_data, mimetype="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{fname}"'})


@app.route("/api/budget/periods/<int:pid>/import", methods=["POST"])
@login_required
def api_budget_import(pid):
    if "file" not in request.files:
        return err("No file uploaded", 400)
    f = request.files["file"]
    try:
        content = f.read().decode("utf-8-sig")
    except UnicodeDecodeError:
        return err("File encoding error — save as UTF-8 CSV", 400)
    n, errors = import_budget_csv(db(), pid, content)
    if errors:
        return err("; ".join(errors[:5]) + (f" (+{len(errors)-5} more)" if len(errors) > 5 else ""), 400)
    audit(db(), session.get("user_id"), session.get("username"),
          "ImportBudget", "budget_period", pid, f"imported {n} lines")
    return ok({"imported": n})


@app.route("/api/reports/bas")
@login_required
def api_bas():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to", str(date.today()))
    basis     = request.args.get("basis", "accrual")
    try:
        data = bas_report(db(), date_from, date_to, basis=basis)
        return ok(data)
    except Exception as e:
        return err(str(e))

@app.route("/api/reports/aged")
@login_required
def api_aged():
    as_of       = request.args.get("as_of", str(date.today()))
    report_type = request.args.get("type", "receivables")
    try:
        if report_type == "payables":
            data = aged_payables(db(), as_of)
        else:
            data = aged_receivables(db(), as_of)
        # aged_receivables/payables returns a dict: {as_at, totals, rows}
        # rows items are dicts already; just ensure they're serialisable
        result = dict(data)
        result["rows"] = [dict(r) for r in result.get("rows", [])]
        result["type"] = report_type
        return ok(result)
    except Exception as e:
        return err(str(e))

@app.route("/api/reports/cash-flow")
@login_required
def api_cash_flow():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to", str(date.today()))
    try:
        data = cash_flow_statement(db(), date_from, date_to)
        return ok(data)
    except Exception as e:
        return err(str(e))

# ── Reports PDF downloads ──────────────────────────────────────────────────────

@app.route("/api/reports/profit-loss/pdf")
@login_required
def api_pl_pdf():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    basis     = request.args.get("basis", "accrual")
    theme     = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix="_pl.pdf")
        render_pl_pdf(db(), date_from, date_to, out_path=out,
                      basis=basis, theme=theme, watermark=_get_pdf_watermark())
        return send_file(out, as_attachment=True,
                         download_name=f"profit_loss_{date_from}_{date_to}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

@app.route("/api/reports/balance-sheet/pdf")
@login_required
def api_bs_pdf():
    as_of = request.args.get("as_of", str(date.today()))
    theme = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix="_bs.pdf")
        render_bs_pdf(db(), as_at_date=as_of, out_path=out,
                      theme=theme, watermark=_get_pdf_watermark())
        return send_file(out, as_attachment=True,
                         download_name=f"balance_sheet_{as_of}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

@app.route("/api/reports/trial-balance/pdf")
@login_required
def api_tb_pdf():
    theme = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix="_tb.pdf")
        render_tb_pdf(db(), out_path=out, theme=theme, watermark=_get_pdf_watermark())
        return send_file(out, as_attachment=True,
                         download_name=f"trial_balance_{date.today()}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

@app.route("/api/reports/bas/pdf")
@login_required
def api_bas_pdf():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    basis     = request.args.get("basis", "accrual")
    form      = request.args.get("form", "bas")
    theme     = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix=f"_{form}.pdf")
        if form == "ias":
            render_ias_pdf(db(), date_from, date_to, out_path=out,
                           theme=theme, watermark=_get_pdf_watermark())
        else:
            render_bas_pdf(db(), date_from, date_to, out_path=out,
                           basis=basis, theme=theme, watermark=_get_pdf_watermark())
        return send_file(out, as_attachment=True,
                         download_name=f"{form}_{date_from}_{date_to}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

@app.route("/api/reports/aged/pdf")
@login_required
def api_aged_pdf():
    as_of       = request.args.get("as_of", str(date.today()))
    report_type = request.args.get("type", "receivables")
    theme       = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix=f"_aged_{report_type}.pdf")
        render_aged_pdf(db(), as_of, report_type=report_type,
                        out_path=out, theme=theme, watermark=_get_pdf_watermark())
        return send_file(out, as_attachment=True,
                         download_name=f"aged_{report_type}_{as_of}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

@app.route("/api/reports/cash-flow/pdf")
@login_required
def api_cash_flow_pdf():
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    theme     = request.args.get("theme")
    try:
        import tempfile
        out = tempfile.mktemp(suffix="_cashflow.pdf")
        render_cash_flow_pdf(db(), date_from, date_to, out_path=out,
                             theme=theme, watermark=_get_pdf_watermark())
        return send_file(out, as_attachment=True,
                         download_name=f"cash_flow_{date_from}_{date_to}.pdf",
                         mimetype="application/pdf")
    except Exception as e:
        return err(str(e))

# ── Reports CSV exports ────────────────────────────────────────────────────────

@app.route("/api/reports/profit-loss/csv")
@login_required
def api_pl_csv():
    import csv, io
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    basis     = request.args.get("basis", "accrual")
    try:
        d = profit_and_loss(db(), date_from, date_to, basis=basis)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Section", "Code", "Account", "Amount"])
        for r in d.get("income", []):
            w.writerow(["Income", r.get("code",""), r.get("name",""), r.get("amount",0)])
        w.writerow(["Income", "", "TOTAL INCOME", d.get("total_income", 0)])
        w.writerow([])
        for r in d.get("cost_of_sales", []):
            w.writerow(["Cost of Sales", r.get("code",""), r.get("name",""), r.get("amount",0)])
        if d.get("cost_of_sales"):
            w.writerow(["Cost of Sales", "", "TOTAL COST OF SALES",
                        sum(r.get("amount",0) for r in d.get("cost_of_sales",[]))])
            w.writerow([])
        for r in d.get("expense", []):
            w.writerow(["Expense", r.get("code",""), r.get("name",""), r.get("amount",0)])
        w.writerow(["Expense", "", "TOTAL EXPENSES", d.get("total_expense", 0)])
        w.writerow([])
        w.writerow(["", "", "NET PROFIT / (LOSS)", d.get("net_profit", 0)])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"profit_loss_{date_from}_{date_to}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))

@app.route("/api/reports/balance-sheet/csv")
@login_required
def api_bs_csv():
    import csv, io
    as_of = request.args.get("as_of", str(date.today()))
    try:
        d = balance_sheet(db(), as_of)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Section", "Code", "Account", "Balance"])
        for section in ("assets", "liabilities", "equity"):
            for r in d.get(section, []):
                if abs(r.get("balance", 0)) >= 0.005:
                    w.writerow([section.title(), r.get("code",""), r.get("name",""), r.get("balance",0)])
            w.writerow([section.title(), "", "TOTAL " + section.upper(),
                        d.get("total_" + section, 0)])
            w.writerow([])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"balance_sheet_{as_of}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))

@app.route("/api/reports/trial-balance/csv")
@login_required
def api_tb_csv():
    import csv, io
    try:
        rows = trial_balance(db())
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Code", "Account", "Type", "Debit", "Credit"])
        for r in rows:
            dr = r.get("total_debit", 0) or 0
            cr = r.get("total_credit", 0) or 0
            if dr or cr:
                w.writerow([r.get("code",""), r.get("name",""),
                             r.get("account_type",""), dr, cr])
        w.writerow(["", "TOTALS", "",
                    sum((r.get("total_debit",0) or 0) for r in rows),
                    sum((r.get("total_credit",0) or 0) for r in rows)])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"trial_balance_{date.today()}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))

@app.route("/api/reports/bas/csv")
@login_required
def api_bas_csv():
    import csv, io
    from core.ledger import ias_report
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    basis     = request.args.get("basis", "accrual")
    form      = request.args.get("form",  "bas")
    try:
        d = ias_report(db(), date_from, date_to) if form == "ias" \
            else bas_report(db(), date_from, date_to, basis=basis)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Label", "Description", "Amount"])
        for key, val in d.items():
            if key not in ("period_from", "period_to", "pay_runs") \
                    and isinstance(val, (int, float)):
                w.writerow([key, key.replace("_", " ").title(), val])
        w.writerow(["period_from", "Period From", d.get("period_from", "")])
        w.writerow(["period_to",   "Period To",   d.get("period_to",   "")])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"{form}_{date_from}_{date_to}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))

@app.route("/api/reports/aged/csv")
@login_required
def api_aged_csv():
    import csv, io
    as_of       = request.args.get("as_of", str(date.today()))
    report_type = request.args.get("type", "receivables")
    try:
        data   = aged_payables(db(), as_of) if report_type == "payables" \
                 else aged_receivables(db(), as_of)
        rows   = [dict(r) for r in data.get("rows", [])]
        totals = data.get("totals", {})
        contact_col = "Supplier" if report_type == "payables" else "Customer"
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow([contact_col, "Current", "1-30 Days", "31-60 Days",
                    "61-90 Days", "90+ Days", "Total"])
        for r in rows:
            w.writerow([r.get("contact_name",""),
                        r.get("current",0), r.get("b0",0), r.get("b1",0),
                        r.get("b2",0), r.get("b3",0), r.get("total",0)])
        w.writerow(["TOTAL",
                    totals.get("current",0), totals.get("b0",0), totals.get("b1",0),
                    totals.get("b2",0), totals.get("b3",0), totals.get("total",0)])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"aged_{report_type}_{as_of}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))

@app.route("/api/reports/cash-flow/csv")
@login_required
def api_cash_flow_csv():
    import csv, io
    date_from = request.args.get("from", str(date.today().replace(month=7, day=1)
                                             if date.today().month >= 7
                                             else date.today().replace(year=date.today().year-1, month=7, day=1)))
    date_to   = request.args.get("to",   str(date.today()))
    try:
        d = cash_flow_statement(db(), date_from, date_to)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["Section", "Description", "Amount"])
        for section_key, section_label in [
            ("operating", "Operating Activities"),
            ("investing", "Investing Activities"),
            ("financing", "Financing Activities"),
        ]:
            sec = d.get(section_key, {})
            for item in sec.get("items", []):
                w.writerow([section_label,
                             item.get("label", item.get("description","")),
                             item.get("amount", 0)])
            w.writerow([section_label, f"Net Cash from {section_label}",
                        sec.get("subtotal", 0)])
            w.writerow([])
        w.writerow(["Summary", "Opening Cash Balance", d.get("opening_cash", 0)])
        w.writerow(["Summary", "Net Change",           d.get("net_change",   0)])
        w.writerow(["Summary", "Closing Cash Balance", d.get("closing_cash", 0)])
        buf.seek(0)
        return send_file(
            io.BytesIO(buf.getvalue().encode("utf-8-sig")),
            as_attachment=True,
            download_name=f"cash_flow_{date_from}_{date_to}.csv",
            mimetype="text/csv")
    except Exception as e:
        return err(str(e))


@app.route("/api/inventory/livestock-categories")
@login_required
def api_livestock_categories():
    return ok(get_livestock_category_list())


@app.route("/api/reports/livestock-trading")
@login_required
def api_livestock_trading():
    date_from = request.args.get("from", "")
    date_to   = request.args.get("to",   "")
    if not date_from or not date_to:
        return err("from and to date parameters are required")
    try:
        return ok(get_livestock_trading_statement(db(), date_from, date_to))
    except Exception as e:
        return err(str(e))


# ── Payroll ────────────────────────────────────────────────────────────────────
@app.route("/api/payroll/employees")
@login_required
@tier_required("payroll")
def api_employees():
    return ok([dict(e) for e in get_employees(db())])

@app.route("/api/payroll/pay-runs")
@login_required
@tier_required("payroll")
def api_pay_runs():
    return ok([dict(r) for r in get_pay_runs(db())])

@app.route("/api/payroll/pay-runs/<int:rid>")
@login_required
@tier_required("payroll")
def api_pay_run(rid):
    run, slips = get_pay_run(db(), rid)
    return ok({"run": dict(run), "slips": [dict(s) for s in slips]})

@app.route("/api/payroll/employees/<int:eid>")
@login_required
@tier_required("payroll")
def api_employee(eid):
    emp = get_employee(db(), eid)
    if not emp:
        return err("Employee not found", 404)
    return ok(dict(emp))

@app.route("/api/payroll/employees/<int:eid>", methods=["POST"])
@login_required
@tier_required("payroll")
def api_employee_save(eid):
    data = request.get_json(force=True)
    data["id"] = eid
    new_id = save_employee(db(), data)
    emp = get_employee(db(), new_id)
    return ok(dict(emp))

@app.route("/api/payroll/employees", methods=["POST"])
@login_required
@tier_required("payroll")
def api_employee_create():
    data = request.get_json(force=True)
    data.pop("id", None)   # ensure insert
    new_id = save_employee(db(), data)
    emp = get_employee(db(), new_id)
    return ok(dict(emp))

@app.route("/api/payroll/next-employee-number")
@login_required
@tier_required("payroll")
def api_next_employee_number():
    return ok({"number": next_employee_number(db())})


@app.route("/api/payroll/awards")
@login_required
@tier_required("payroll")
def api_payroll_awards():
    """Return awards/agreements. Pass ?active_only=0 to include inactive."""
    active_only = request.args.get("active_only", "1") != "0"
    awards = get_awards(db(), active_only=active_only)
    return ok([{"id": a["id"], "name": a["name"],
                "instrument_type": a.get("instrument_type", ""),
                "code": a.get("code", ""),
                "is_active": a.get("is_active", 1),
                "employee_count": a.get("employee_count", 0)} for a in awards])

@app.route("/api/payroll/awards/<int:award_id>/classifications")
@login_required
@tier_required("payroll")
def api_payroll_classifications(award_id):
    """Return active classifications for an award, with current resolved pay rate."""
    clss = get_classifications(db(), award_id)
    result = []
    for c in clss:
        resolved = resolve_rate_from_classification(db(), c["id"], pay_point=1)
        result.append({
            "id":         c["id"],
            "name":       c["name"],
            "code":       c.get("code", ""),
            "sort_order": c.get("sort_order", 0),
            "hourly_rate": resolved.get("hourly_rate"),
        })
    return ok(result)

@app.route("/api/payroll/awards/<int:award_id>/classifications/<int:cls_id>/rate")
@login_required
@tier_required("payroll")
def api_payroll_cls_rate(award_id, cls_id):
    """Resolve award pay rate for a classification + pay point."""
    pay_point = request.args.get("pay_point", 1, type=int)
    resolved = resolve_rate_from_classification(db(), cls_id, pay_point=pay_point)
    return ok({
        "hourly_rate":  resolved.get("hourly_rate"),
        "award_name":   resolved.get("award_name", ""),
        "cls_name":     resolved.get("classification_name", ""),
    })


# ── Awards Management — full CRUD (Stage 5M) ─────────────────────────────────

@app.route("/api/payroll/awards", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payroll_awards_create():
    """Create a new award/agreement."""
    data = request.get_json() or {}
    new_id = save_award(db(), data)
    return ok({"id": new_id})

@app.route("/api/payroll/awards/<int:award_id>")
@login_required
@tier_required("payroll")
def api_payroll_award_get(award_id):
    """Return full award detail."""
    a = get_award(db(), award_id)
    if not a:
        return err("Award not found", 404)
    a.pop("file_data", None)   # never send blob over JSON
    return ok(a)

@app.route("/api/payroll/awards/<int:award_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_payroll_award_update(award_id):
    """Update an award/agreement."""
    data = request.get_json() or {}
    data["id"] = award_id
    save_award(db(), data)
    return ok({"id": award_id})

@app.route("/api/payroll/awards/<int:award_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_payroll_award_delete(award_id):
    """Soft-delete (deactivate) an award."""
    delete_award(db(), award_id)
    return ok({})

@app.route("/api/payroll/awards/<int:award_id>/employees")
@login_required
@tier_required("payroll")
def api_payroll_award_employees(award_id):
    """Return employees assigned to this award."""
    emps = get_employees_by_award(db(), award_id)
    return ok(emps)

@app.route("/api/payroll/awards/<int:award_id>/wage-increase", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payroll_award_wage_increase(award_id):
    """Bulk apply an annual wage increase to all classifications."""
    data = request.get_json() or {}
    effective_date   = data.get("effective_date")
    increase_percent = data.get("increase_percent")
    source_note      = data.get("source_note", "")
    if not effective_date or increase_percent is None:
        return err("effective_date and increase_percent required")
    try:
        count = bulk_apply_wage_increase(db(), award_id, effective_date,
                                         float(increase_percent), source_note)
    except Exception as e:
        return err(str(e), 500)
    return ok({"rows_created": count})

@app.route("/api/payroll/awards/meta")
@login_required
@tier_required("payroll")
def api_payroll_awards_meta():
    """Return dropdown constants for the awards UI."""
    return ok({
        "instrument_types": INSTRUMENT_TYPES,
        "allowance_types":  ALLOWANCE_TYPES,
        "penalty_types":    [{"code": c, "label": l} for c, l in PENALTY_TYPES],
    })

# ── Classifications ────────────────────────────────────────────────────────────

@app.route("/api/payroll/awards/<int:award_id>/classifications", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payroll_classifications_create(award_id):
    data = request.get_json() or {}
    data["award_id"] = award_id
    new_id = save_classification(db(), data)
    return ok({"id": new_id})

@app.route("/api/payroll/classifications/<int:cls_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_payroll_classification_update(cls_id):
    data = request.get_json() or {}
    data["id"] = cls_id
    save_classification(db(), data)
    return ok({"id": cls_id})

@app.route("/api/payroll/classifications/<int:cls_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_payroll_classification_delete(cls_id):
    delete_classification(db(), cls_id)
    return ok({})

# ── Pay Rates ─────────────────────────────────────────────────────────────────

@app.route("/api/payroll/classifications/<int:cls_id>/pay-rates")
@login_required
@tier_required("payroll")
def api_payroll_pay_rates(cls_id):
    rows = get_pay_rates(db(), cls_id)
    return ok(rows)

@app.route("/api/payroll/classifications/<int:cls_id>/pay-rates", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payroll_pay_rates_create(cls_id):
    data = request.get_json() or {}
    data["classification_id"] = cls_id
    try:
        new_id = save_pay_rate(db(), data)
    except sqlite3.IntegrityError:
        return err("A rate for this pay point and effective date already exists.", 409)
    return ok({"id": new_id})

@app.route("/api/payroll/pay-rates/<int:rate_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_payroll_pay_rate_update(rate_id):
    data = request.get_json() or {}
    data["id"] = rate_id
    try:
        save_pay_rate(db(), data)
    except sqlite3.IntegrityError:
        return err("A rate for this pay point and effective date already exists.", 409)
    return ok({"id": rate_id})

@app.route("/api/payroll/pay-rates/<int:rate_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_payroll_pay_rate_delete(rate_id):
    delete_pay_rate(db(), rate_id)
    return ok({})

# ── Allowances ────────────────────────────────────────────────────────────────

@app.route("/api/payroll/awards/<int:award_id>/allowances")
@login_required
@tier_required("payroll")
def api_payroll_allowances(award_id):
    rows = get_award_allowances(db(), award_id)
    return ok(rows)

@app.route("/api/payroll/awards/<int:award_id>/allowances", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payroll_allowances_create(award_id):
    data = request.get_json() or {}
    data["award_id"] = award_id
    try:
        new_id = save_award_allowance(db(), data)
    except Exception as e:
        return err(str(e), 500)
    return ok({"id": new_id})

@app.route("/api/payroll/allowances/<int:allowance_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_payroll_allowance_update(allowance_id):
    data = request.get_json() or {}
    data["id"] = allowance_id
    try:
        save_award_allowance(db(), data)
    except Exception as e:
        return err(str(e), 500)
    return ok({"id": allowance_id})

@app.route("/api/payroll/allowances/<int:allowance_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_payroll_allowance_delete(allowance_id):
    delete_award_allowance(db(), allowance_id)
    return ok({})

# ── Penalty Rates ─────────────────────────────────────────────────────────────

@app.route("/api/payroll/awards/<int:award_id>/penalties")
@login_required
@tier_required("payroll")
def api_payroll_penalties(award_id):
    rows = get_penalty_rates(db(), award_id)
    return ok(rows)

@app.route("/api/payroll/awards/<int:award_id>/penalties", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payroll_penalties_create(award_id):
    data = request.get_json() or {}
    data["award_id"] = award_id
    try:
        new_id = save_penalty_rate(db(), data)
    except Exception as e:
        return err(str(e), 500)
    return ok({"id": new_id})

@app.route("/api/payroll/penalties/<int:penalty_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_payroll_penalty_update(penalty_id):
    data = request.get_json() or {}
    data["id"] = penalty_id
    try:
        save_penalty_rate(db(), data)
    except Exception as e:
        return err(str(e), 500)
    return ok({"id": penalty_id})

@app.route("/api/payroll/penalties/<int:penalty_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_payroll_penalty_delete(penalty_id):
    delete_penalty_rate(db(), penalty_id)
    return ok({})

# ── End Stage 5M ──────────────────────────────────────────────────────────────

@app.route("/api/payroll/pay-runs/preview", methods=["POST"])
@login_required
@tier_required("payroll")
def api_pay_run_preview():
    """
    Calculate payslips for a proposed pay run without saving anything.
    Body: {
      period_start, period_end, payment_date, frequency,
      employee_ids: [int, ...],          // subset; omit or [] = all active
      adjustments: {                     // keyed by employee_id (string)
        "42": {
          ordinary_hours, overtime_hours,
          leave_type, leave_hours,
          salary_sacrifice,
          allowances: [{type, amount}, ...]
        }
      }
    }
    Returns: { slips: [...], totals: {gross, tax, net, super} }
    """
    body = request.get_json(force=True) or {}
    period_start  = body.get("period_start")
    period_end    = body.get("period_end")
    payment_date  = body.get("payment_date")
    frequency     = body.get("frequency", "Fortnightly")
    emp_ids       = body.get("employee_ids") or []
    adjustments   = body.get("adjustments") or {}

    if not all([period_start, period_end, payment_date]):
        return err("period_start, period_end, and payment_date are required", 400)

    # Resolve employee list
    if emp_ids:
        employees = [get_employee(db(), eid) for eid in emp_ids]
        employees = [e for e in employees if e]
    else:
        employees = get_employees(db(), active_only=True)

    slips = []
    errors = []
    for emp in employees:
        adj = adjustments.get(str(emp["id"])) or {}
        try:
            slip = calculate_payslip(
                db_path       = db(),
                employee_id   = emp["id"],
                period_start  = period_start,
                period_end    = period_end,
                payment_date  = payment_date,
                frequency     = frequency,
                ordinary_hours     = adj.get("ordinary_hours"),        # None = auto
                overtime_hours     = float(adj.get("overtime_hours") or 0),
                leave_type         = adj.get("leave_type") or None,
                leave_hours        = float(adj.get("leave_hours") or 0),
                allowances         = adj.get("allowances") or [],
                salary_sacrifice   = adj.get("salary_sacrifice"),      # None = employee default
            )
            # Strip internal-only keys before sending to client
            clean = {k: v for k, v in slip.items() if not k.startswith("_")}
            clean["employee_name"] = f"{emp['first_name']} {emp['last_name']}"
            clean["employee_number"] = emp.get("employee_number", "")
            clean["pay_frequency"] = emp.get("pay_frequency", frequency)
            slips.append(clean)
        except Exception as ex:
            errors.append({"employee_id": emp["id"],
                           "employee_name": f"{emp['first_name']} {emp['last_name']}",
                           "error": str(ex)})

    totals = {
        "gross": sum(s["gross_pay"]    for s in slips),
        "tax":   sum(s["payg_tax"]     for s in slips),
        "net":   sum(s["net_pay"]      for s in slips),
        "super": sum(s["super_amount"] for s in slips),
    }
    return ok({"slips": slips, "totals": totals, "errors": errors})


@app.route("/api/payroll/pay-runs", methods=["POST"])
@login_required
@tier_required("payroll")
def api_pay_run_create():
    """
    Create a draft pay run from confirmed preview data.
    Body: same shape as preview — re-calculates and saves atomically.
    Returns: saved pay run id + run_number.
    """
    body = request.get_json(force=True) or {}
    period_start  = body.get("period_start")
    period_end    = body.get("period_end")
    payment_date  = body.get("payment_date")
    frequency     = body.get("frequency", "Fortnightly")
    emp_ids       = body.get("employee_ids") or []
    adjustments   = body.get("adjustments") or {}

    if not all([period_start, period_end, payment_date]):
        return err("period_start, period_end, and payment_date are required", 400)

    employees = [get_employee(db(), eid) for eid in emp_ids] if emp_ids \
                else get_employees(db(), active_only=True)
    employees = [e for e in employees if e]

    payslips_data = []
    for emp in employees:
        adj = adjustments.get(str(emp["id"])) or {}
        try:
            slip = calculate_payslip(
                db_path       = db(),
                employee_id   = emp["id"],
                period_start  = period_start,
                period_end    = period_end,
                payment_date  = payment_date,
                frequency     = frequency,
                ordinary_hours   = adj.get("ordinary_hours"),
                overtime_hours   = float(adj.get("overtime_hours") or 0),
                leave_type       = adj.get("leave_type") or None,
                leave_hours      = float(adj.get("leave_hours") or 0),
                allowances       = adj.get("allowances") or [],
                salary_sacrifice = adj.get("salary_sacrifice"),
            )
            payslips_data.append(slip)
        except Exception as ex:
            return err(f"Could not calculate payslip for "
                       f"{emp['first_name']} {emp['last_name']}: {ex}", 400)

    if not payslips_data:
        return err("No employees to include in pay run", 400)

    user_id = session.get("user_id")
    run_id  = create_pay_run(db(), period_start, period_end, payment_date,
                              frequency, payslips_data, created_by=user_id)
    run, _ = get_pay_run(db(), run_id)
    return ok({"id": run_id, "run_number": run["run_number"]})


@app.route("/api/payroll/pay-runs/<int:rid>/finalise", methods=["POST"])
@login_required
@tier_required("payroll")
def api_pay_run_finalise(rid):
    """Finalise a draft pay run: update YTD, post GL journal, mark Finalised."""
    run, _ = get_pay_run(db(), rid)
    if not run:
        return err("Pay run not found", 404)
    if run["status"] != "Draft":
        return err(f"Pay run is already {run['status']} — cannot finalise", 400)
    try:
        finalise_pay_run(db(), rid)
    except Exception as ex:
        return err(str(ex), 400)
    run, slips = get_pay_run(db(), rid)
    return ok({"run": dict(run), "slips": [dict(s) for s in slips]})


@app.route("/api/payroll/pay-runs/<int:rid>/void", methods=["POST"])
@login_required
@tier_required("payroll")
def api_pay_run_void(rid):
    """Void a finalised pay run: reverse GL journal, unwind YTD."""
    run, _ = get_pay_run(db(), rid)
    if not run:
        return err("Pay run not found", 404)
    username = (session.get("user", {}) or {}).get("username", "web")
    try:
        void_pay_run(db(), rid, voided_by=username)
    except ValueError as ex:
        return err(str(ex), 400)
    except Exception as ex:
        return err(str(ex), 500)
    run, slips = get_pay_run(db(), rid)
    return ok({"run": dict(run), "slips": [dict(s) for s in slips]})


@app.route("/api/payroll/pay-runs/<int:rid>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_pay_run_delete(rid):
    """Delete a draft pay run and its payslips. Finalised runs cannot be deleted."""
    run, _ = get_pay_run(db(), rid)
    if not run:
        return err("Pay run not found", 404)
    if run["status"] != "Draft":
        return err("Only Draft pay runs can be deleted", 400)
    conn = get_connection(db())
    try:
        conn.execute("DELETE FROM payslips  WHERE pay_run_id=?", (rid,))
        conn.execute("DELETE FROM pay_runs  WHERE id=?", (rid,))
        conn.commit()
    finally:
        conn.close()
    return ok({"deleted": rid})


@app.route("/api/payroll/meta")
@login_required
@tier_required("payroll")
def api_payroll_meta():
    """Return constants the UI needs: leave types, allowance types, frequencies."""
    return ok({
        "leave_types":    LEAVE_TYPES,
        "allowance_types": ALLOWANCE_TYPES,
        "pay_frequencies": PAY_FREQUENCIES,
    })


# ── STP Submissions ────────────────────────────────────────────────────────────

@app.route("/api/payroll/stp-submissions")
@login_required
@tier_required("payroll")
def api_stp_submissions():
    """List all STP submissions, newest first."""
    try:
        subs = get_stp_submissions(db())
        return ok(subs)
    except Exception as e:
        return err(str(e), 500)


@app.route("/api/payroll/pay-runs/<int:rid>/lodge-stp", methods=["POST"])
@login_required
@tier_required("payroll")
def api_lodge_stp(rid):
    """Generate STP Phase 2 XML, record in stp_submissions, mark run STP_Lodged."""
    body = request.get_json() or {}
    abn  = body.get("abn", "").replace(" ", "")
    if not abn or not abn.isdigit() or len(abn) != 11:
        return err("Invalid ABN — must be 11 digits", 400)
    try:
        result = lodge_stp(db(), rid, abn)
        # Retrieve the submission id that lodge_stp just inserted
        subs   = get_stp_submissions(db())
        sub_id = next((s["id"] for s in subs if s["pay_run_id"] == rid), None)
        return ok({
            "submission_id": sub_id,
            "status":        result["status"],
            "message":       result["message"],
        })
    except Exception as e:
        return err(str(e), 500)


@app.route("/api/payroll/stp-submissions/<int:sub_id>/xml")
@login_required
@tier_required("payroll")
def api_stp_xml_download(sub_id):
    """Return the stored STP XML payload as a downloadable file."""
    from flask import Response
    conn = get_connection(db())
    row  = conn.execute(
        "SELECT payload_xml, pay_run_id FROM stp_submissions WHERE id=?",
        (sub_id,)
    ).fetchone()
    conn.close()
    if not row or not row["payload_xml"]:
        return err("STP submission not found or has no XML", 404)
    filename = f"stp_submission_{sub_id}_run_{row['pay_run_id']}.xml"
    return Response(
        row["payload_xml"],
        mimetype="application/xml",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.route("/api/payroll/pay-runs/<int:run_id>/payslips/<int:slip_id>/pdf")
@login_required
@tier_required("payroll")
def api_payslip_pdf(run_id, slip_id):
    """Download a single payslip as a Fair Work Act compliant PDF."""
    import os as _os
    try:
        watermark = _get_pdf_watermark()
        pdf_path = generate_payslip_pdf(db(), payslip_id=slip_id,
                                        watermark=watermark)
    except ValueError as e:
        return err(str(e), 404)
    except ImportError as e:
        return err(str(e), 500)
    except Exception as e:
        return err(f"PDF generation failed: {e}", 500)
    filename = _os.path.basename(pdf_path)
    return send_file(pdf_path, mimetype="application/pdf",
                     as_attachment=True, download_name=filename)


@app.route("/api/payroll/pay-runs/<int:run_id>/payslips/pdf")
@login_required
@tier_required("payroll")
def api_payslips_bulk_pdf(run_id):
    """Download all payslips for a pay run merged into a single PDF."""
    import io as _io
    import os as _os
    try:
        from pypdf import PdfWriter
    except ImportError:
        return err("pypdf not installed. Run: pip install pypdf", 500)
    try:
        conn = get_connection(db())
        run  = conn.execute("SELECT run_number FROM pay_runs WHERE id=?",
                            (run_id,)).fetchone()
        if not run:
            return err("Pay run not found", 404)
        run_number = run["run_number"]
        slip_ids = [r["id"] for r in conn.execute(
            "SELECT id FROM payslips WHERE pay_run_id=? ORDER BY id",
            (run_id,)).fetchall()]
        conn.close()
        if not slip_ids:
            return err("No payslips in this pay run", 404)

        watermark = _get_pdf_watermark()
        writer = PdfWriter()
        tmp_paths = []
        for sid in slip_ids:
            path = generate_payslip_pdf(db(), payslip_id=sid, watermark=watermark)
            tmp_paths.append(path)
            from pypdf import PdfReader
            reader = PdfReader(path)
            for page in reader.pages:
                writer.add_page(page)

        buf = _io.BytesIO()
        writer.write(buf)
        buf.seek(0)

        # Clean up temp files
        for p in tmp_paths:
            try: _os.remove(p)
            except OSError: pass

        filename = f"payslips_{run_number}.pdf"
        return send_file(buf, mimetype="application/pdf",
                         as_attachment=True, download_name=filename)
    except (ValueError, ImportError) as e:
        return err(str(e), 400)
    except Exception as e:
        return err(f"Bulk PDF generation failed: {e}", 500)


@app.route("/api/payroll/pay-runs/<int:run_id>/report")
@login_required
@tier_required("payroll")
def api_payrun_report_pdf(run_id):
    """Download the pay run summary report as a PDF."""
    import os as _os
    try:
        watermark = _get_pdf_watermark()
        pdf_path = generate_payrun_report_pdf(db(), run_id, watermark=watermark)
    except ValueError as e:
        return err(str(e), 404)
    except ImportError as e:
        return err(str(e), 500)
    except Exception as e:
        return err(f"PDF generation failed: {e}", 500)
    filename = _os.path.basename(pdf_path)
    return send_file(pdf_path, mimetype="application/pdf",
                     as_attachment=True, download_name=filename)


@app.route("/api/payroll/stp-submissions/<int:sub_id>/mark-lodged", methods=["POST"])
@login_required
@tier_required("payroll")
def api_stp_mark_lodged(sub_id):
    """Manually mark a submission as Lodged (used after filing via tax agent)."""
    import datetime as _dt
    conn = get_connection(db())
    conn.execute(
        "UPDATE stp_submissions SET status='Lodged', message=? WHERE id=?",
        (f"Manually marked as lodged {_dt.date.today()}", sub_id)
    )
    conn.commit()
    conn.close()
    return ok({})


@app.route("/api/payroll/stp-submissions/<int:sub_id>/status", methods=["PATCH"])
@login_required
@tier_required("payroll")
def api_stp_update_status(sub_id):
    """Update status and append a timestamped note to an STP submission."""
    import datetime as _dt
    body   = request.get_json(force=True) or {}
    status = (body.get("status") or "").strip()
    note   = (body.get("note")   or "").strip()

    allowed = {"Pending", "Submitted", "Lodged", "Rejected"}
    if status not in allowed:
        return err(f"Invalid status — must be one of: {', '.join(sorted(allowed))}", 400)

    conn = get_connection(db())
    row  = conn.execute(
        "SELECT message FROM stp_submissions WHERE id=?", (sub_id,)
    ).fetchone()
    if not row:
        conn.close()
        return err("Submission not found", 404)

    existing    = (row["message"] or "").strip()
    ts          = _dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    new_message = (f"{existing}\n[{ts}] {note}".strip()) if note else existing

    conn.execute(
        "UPDATE stp_submissions SET status=?, message=? WHERE id=?",
        (status, new_message, sub_id)
    )
    conn.commit()
    conn.close()
    return ok({})


@app.route("/api/payroll/stp-finalisation", methods=["POST"])
@login_required
@tier_required("payroll")
def api_lodge_stp_finalisation():
    """
    Generate an STP Phase 2 Finalisation declaration for the current FY.
    Uses YTD totals from the most recent finalised pay run.
    Not tied to a specific pay run — this is the end-of-year declaration.
    """
    body = request.get_json() or {}
    abn  = body.get("abn", "").replace(" ", "")
    if not abn or not abn.isdigit() or len(abn) != 11:
        return err("Invalid ABN — must be 11 digits", 400)
    try:
        result = lodge_stp_finalisation(db(), abn)
        if result["status"] == "Error":
            return err(result["message"], 400)
        return ok({
            "submission_id": result["submission_id"],
            "status":        result["status"],
            "message":       result["message"],
        })
    except Exception as e:
        return err(str(e), 500)


@app.route("/api/payroll/super-payments", methods=["GET", "POST"])
@login_required
@tier_required("payroll")
def api_super_payments():
    """
    GET  — Return all super payment batches, newest first.
    POST — Create a super payment batch from accruals.
           Body: { payment_date, payment_method, reference, notes, lines: [...] }
           lines shape mirrors get_super_accruals rows: employee_id, fund_name,
           fund_abn, fund_usi, member_number, sgc_amount, salary_sacrifice,
           voluntary_amount, period_start, period_end, pay_run_ids (list of ints).
    """
    if request.method == "GET":
        return ok(get_super_payments(db()))

    # POST — create batch
    body = request.json or {}
    payment_date = body.get("payment_date")
    if not payment_date:
        return err("payment_date is required")
    lines = body.get("lines")
    if not lines:
        return err("lines cannot be empty")
    quarter, due_date = _super_quarter(payment_date)
    try:
        pmt_id = create_super_payment(
            db(),
            payment_date=payment_date,
            quarter=quarter,
            due_date=due_date,
            lines=lines,
            payment_method=body.get("payment_method", "SuperStream"),
            reference=body.get("reference") or None,
            notes=body.get("notes") or None,
            created_by=session.get("user_id"),
        )
    except Exception as e:
        return err(str(e))
    pmt, pmt_lines = get_super_payment(db(), pmt_id)
    return ok({"payment": pmt, "lines": pmt_lines})


@app.route("/api/payroll/super-payments/<int:payment_id>")
@login_required
@tier_required("payroll")
def api_super_payment(payment_id):
    """Return a single super payment batch with its employee lines."""
    pmt, lines = get_super_payment(db(), payment_id)
    if not pmt:
        return err("Super payment not found", 404)
    return ok({"payment": pmt, "lines": lines})


@app.route("/api/payroll/super-accruals")
@login_required
@tier_required("payroll")
def api_super_accruals():
    """Return unremitted super accruals from finalised pay runs."""
    return ok(get_super_accruals(db()))


@app.route("/api/payroll/super-payments/<int:payment_id>/finalise", methods=["POST"])
@login_required
@tier_required("payroll")
def api_super_payment_finalise(payment_id):
    """Mark a super payment batch as Paid and post the GL journal."""
    try:
        finalise_super_payment(db(), payment_id, post_journal=True)
    except (ValueError, Exception) as e:
        return err(str(e))
    pmt, lines = get_super_payment(db(), payment_id)
    return ok({"payment": pmt, "lines": lines})


@app.route("/api/payroll/super-payments/<int:payment_id>/remittance-pdf")
@login_required
@tier_required("payroll")
def api_super_remittance_pdf(payment_id):
    """Download a SuperStream-style remittance advice PDF."""
    try:
        pdf_path = generate_super_remittance_pdf(db(), payment_id)
    except Exception as e:
        return err(str(e))
    from flask import send_file
    pmt, _ = get_super_payment(db(), payment_id)
    filename = (f"super_remittance_{pmt['payment_number']}.pdf"
                if pmt else "super_remittance.pdf")
    return send_file(pdf_path, mimetype="application/pdf",
                     as_attachment=True, download_name=filename)


# ── Payslip History  (Stage 5R) ───────────────────────────────────────────────

@app.route("/api/payroll/employees/<int:employee_id>/payslips")
@login_required
@tier_required("payroll")
def api_employee_payslips(employee_id):
    """Return recent payslips for an employee (default last 20)."""
    limit = int(request.args.get("limit", 20))
    return ok(get_payslips_for_employee(db(), employee_id, limit=limit))


# ── ABA File Export  (Stage 5P) ───────────────────────────────────────────────

@app.route("/api/payroll/aba-settings")
@login_required
@tier_required("payroll")
def api_aba_settings_get():
    """Return ABA configuration (user_id, description, plus bank account details)."""
    from core.aba import get_aba_settings
    return ok(get_aba_settings(db()))


@app.route("/api/payroll/aba-settings", methods=["POST"])
@login_required
@tier_required("payroll")
def api_aba_settings_save():
    """Persist ABA-specific settings (user_id, description) to company record."""
    from core.aba import save_aba_settings
    save_aba_settings(db(), request.json or {})
    return ok({})


@app.route("/api/payroll/pay-runs/<int:rid>/aba", methods=["POST"])
@login_required
@tier_required("payroll")
def api_pay_run_aba(rid):
    """
    Build and stream an ABA direct-entry file for the net pay of all payslips
    in this pay run.

    POST body: { process_date: "YYYY-MM-DD", description: "PAYROLL" }

    Bank details (BSB, account_number) are read from the contact record linked
    to each employee.  Returns 422 with a plain-text error if any employee is
    missing bank details or if the company bank account is not configured.
    """
    from core.aba import generate_aba, ABAError
    from flask import Response

    body         = request.json or {}
    process_date = body.get("process_date", date.today().isoformat())
    description  = (body.get("description") or "PAYROLL")[:12]

    run, slips = get_pay_run(db(), rid)
    if not run:
        return err("Pay run not found", 404)

    run_dict = dict(run)

    conn     = get_connection(db())
    payments = []
    missing  = []

    for slip in slips:
        slip = dict(slip)
        row  = conn.execute(
            """SELECT e.id, e.bank_bsb, e.bank_account, e.bank_name,
                      e.first_name, e.last_name
               FROM employees e
               WHERE e.id = ?""",
            (slip["employee_id"],)
        ).fetchone()
        emp = dict(row) if row else {}

        bsb  = (emp.get("bank_bsb")     or "").strip()
        acct = (emp.get("bank_account") or "").strip()
        name = (emp.get("bank_name") or
                " ".join(filter(None, [emp.get("first_name"), emp.get("last_name")])) or
                f"Employee {slip['employee_id']}")

        if not bsb or not acct:
            missing.append(name)
            continue

        net = round(float(slip.get("net_pay") or 0), 2)
        if net <= 0:
            continue   # skip $0 payslips silently

        payments.append({
            "dest_bsb":      bsb,
            "dest_account":  acct,
            "dest_name":     name[:32],
            "amount":        net,
            "lodgement_ref": f"PAY{rid:04d}",
        })

    conn.close()

    if missing:
        return err(
            f"Missing BSB/account for: {', '.join(missing)}.\n\n"
            f"Edit each employee in Payroll → Employees and add their "
            f"BSB and Account Number.", 422)

    if not payments:
        return err("No payable employees in this run (all net pay is $0).", 422)

    try:
        content = generate_aba(db(), payments, process_date, description)
    except ABAError as e:
        return err(str(e), 422)

    period_end = run_dict.get("pay_period_end", "").replace("-", "") or str(rid)
    filename   = f"payroll_{period_end}.aba"

    return Response(
        content,
        mimetype="text/plain",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ── Leave Management ─────────────────────────────────────────────────────────

@app.route("/api/leave/types")
@login_required
@tier_required("payroll")
def api_leave_types():
    active_only = request.args.get("active_only", "1") != "0"
    return ok(get_leave_types(db(), active_only=active_only))


@app.route("/api/leave/requests")
@login_required
@tier_required("payroll")
def api_leave_requests():
    emp_id    = request.args.get("employee_id", type=int)
    status    = request.args.get("status")
    date_from = request.args.get("date_from")
    date_to   = request.args.get("date_to")
    return ok(get_leave_requests(db(), employee_id=emp_id, status=status,
                                  date_from=date_from, date_to=date_to))


@app.route("/api/leave/requests/<int:req_id>")
@login_required
@tier_required("payroll")
def api_leave_request(req_id):
    r = get_leave_request(db(), req_id)
    if not r:
        return err("Not found", 404)
    return ok(r)


@app.route("/api/leave/requests", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_request_create():
    data = request.json or {}
    try:
        new_id = save_leave_request(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": new_id})


@app.route("/api/leave/requests/<int:req_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_leave_request_update(req_id):
    data = request.json or {}
    data["id"] = req_id
    try:
        save_leave_request(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": req_id})


@app.route("/api/leave/requests/<int:req_id>/approve", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_approve(req_id):
    approved_by = (request.json or {}).get("approved_by", "Web UI")
    try:
        approve_leave(db(), req_id, approved_by)
    except Exception as e:
        return err(str(e))
    return ok({})


@app.route("/api/leave/requests/<int:req_id>/decline", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_decline(req_id):
    body = request.json or {}
    try:
        decline_leave(db(), req_id, body.get("declined_by", "Web UI"),
                      body.get("reason", ""))
    except Exception as e:
        return err(str(e))
    return ok({})


@app.route("/api/leave/requests/<int:req_id>/cancel", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_cancel(req_id):
    try:
        cancel_leave(db(), req_id)
    except Exception as e:
        return err(str(e))
    return ok({})


@app.route("/api/leave/balances")
@login_required
@tier_required("payroll")
def api_leave_balances():
    emp_id = request.args.get("employee_id", type=int)
    if not emp_id:
        return err("employee_id required", 400)
    return ok(get_leave_balances(db(), emp_id))



# ── Leave Types CRUD ──────────────────────────────────────────────────────────

@app.route("/api/leave/types/<int:type_id>")
@login_required
@tier_required("payroll")
def api_leave_type(type_id):
    lt = get_leave_type(db(), type_id)
    if not lt:
        return err("Not found", 404)
    return ok(lt)


@app.route("/api/leave/types", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_type_create():
    data = request.json or {}
    try:
        new_id = save_leave_type(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": new_id})


@app.route("/api/leave/types/<int:type_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_leave_type_update(type_id):
    data = request.json or {}
    data["id"] = type_id
    try:
        save_leave_type(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": type_id})


@app.route("/api/leave/types/<int:type_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_leave_type_delete(type_id):
    lt = get_leave_type(db(), type_id)
    if not lt:
        return err("Not found", 404)
    if lt.get("is_system"):
        return err("System leave types cannot be deleted", 400)
    try:
        conn = db()
        conn.execute("DELETE FROM leave_types WHERE id = ?", (type_id,))
        conn.commit()
    except Exception as e:
        return err(str(e))
    return ok({})


# ── Medical Certificates CRUD ─────────────────────────────────────────────────

@app.route("/api/leave/certs")
@login_required
@tier_required("payroll")
def api_leave_certs():
    emp_id = request.args.get("employee_id", type=int)
    return ok(get_medical_certs(db(), employee_id=emp_id))


@app.route("/api/leave/certs/<int:cert_id>")
@login_required
@tier_required("payroll")
def api_leave_cert(cert_id):
    conn = db()
    row = conn.execute(
        """SELECT mc.*, e.first_name || ' ' || e.last_name AS employee_name
           FROM medical_certs mc
           LEFT JOIN employees e ON e.id = mc.employee_id
           WHERE mc.id = ?""", (cert_id,)
    ).fetchone()
    if not row:
        return err("Not found", 404)
    return ok(dict(row))


def _cert_decode_file(data):
    """Decode base64 file_data from JSON payload to bytes in-place."""
    import base64 as _b64
    if data.get("file_data") and isinstance(data["file_data"], str):
        data["file_data"] = _b64.b64decode(data["file_data"])


@app.route("/api/leave/certs", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_cert_create():
    data = request.json or {}
    _cert_decode_file(data)
    try:
        new_id = save_medical_cert(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": new_id})


@app.route("/api/leave/certs/<int:cert_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_leave_cert_update(cert_id):
    data = request.json or {}
    data["id"] = cert_id
    _cert_decode_file(data)
    try:
        save_medical_cert(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": cert_id})


@app.route("/api/leave/certs/<int:cert_id>/file")
@login_required
@tier_required("payroll")
def api_leave_cert_file(cert_id):
    row = db().execute(
        "SELECT file_data, file_name, mime_type FROM medical_certs WHERE id=?",
        (cert_id,)).fetchone()
    if not row or not row["file_data"]:
        return err("No file attached", 404)
    from flask import Response
    return Response(
        bytes(row["file_data"]),
        mimetype=row["mime_type"] or "application/octet-stream",
        headers={"Content-Disposition": f'attachment; filename="{row["file_name"] or "cert_file"}"'})


@app.route("/api/leave/certs/<int:cert_id>/file", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_leave_cert_file_delete(cert_id):
    conn = db()
    conn.execute(
        "UPDATE medical_certs SET file_data=NULL, file_name=NULL, mime_type=NULL WHERE id=?",
        (cert_id,))
    conn.commit()
    return ok()


@app.route("/api/leave/certs/<int:cert_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_leave_cert_delete(cert_id):
    try:
        delete_medical_cert(db(), cert_id)
    except Exception as e:
        return err(str(e))
    return ok({})


# ── Public Holidays CRUD ──────────────────────────────────────────────────────

@app.route("/api/leave/holidays")
@login_required
@tier_required("payroll")
def api_leave_holidays():
    state     = request.args.get("state")
    year_from = request.args.get("year_from", type=int)
    year_to   = request.args.get("year_to",   type=int)
    return ok(get_public_holidays(db(), state=state,
                                  year_from=year_from, year_to=year_to))


@app.route("/api/leave/holidays", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_holiday_create():
    data = request.json or {}
    try:
        new_id = save_public_holiday(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": new_id})


@app.route("/api/leave/holidays/<int:hol_id>", methods=["PUT"])
@login_required
@tier_required("payroll")
def api_leave_holiday_update(hol_id):
    data = request.json or {}
    data["id"] = hol_id
    try:
        save_public_holiday(db(), data)
    except Exception as e:
        return err(str(e))
    return ok({"id": hol_id})


@app.route("/api/leave/holidays/<int:hol_id>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_leave_holiday_delete(hol_id):
    try:
        delete_public_holiday(db(), hol_id)
    except Exception as e:
        return err(str(e))
    return ok({})


@app.route("/api/leave/holidays/export-csv")
@login_required
@tier_required("payroll")
def api_leave_holidays_export_csv():
    import csv, io
    state     = request.args.get("state")
    year_from = request.args.get("year_from", type=int)
    year_to   = request.args.get("year_to",   type=int)
    rows = get_public_holidays(db(), state=state,
                               year_from=year_from, year_to=year_to)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["holiday_date", "state", "name"])
    for r in rows:
        w.writerow([r["holiday_date"], r["state"], r["name"]])
    output = buf.getvalue()
    from flask import Response
    return Response(
        output,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=public_holidays.csv"},
    )


@app.route("/api/leave/holidays/import-csv", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_holidays_import_csv():
    body     = request.json or {}
    rows     = body.get("rows", [])
    overwrite = body.get("overwrite", False)
    if not rows:
        return err("No rows provided", 400)
    imported = skipped = 0
    try:
        # Fetch existing keys for duplicate detection when not overwriting
        existing_keys = set()
        if not overwrite:
            existing = get_public_holidays(db())
            existing_keys = {(r["holiday_date"], r["state"]) for r in existing}
        for row in rows:
            key = (row.get("holiday_date"), row.get("state", "NAT"))
            if not overwrite and key in existing_keys:
                skipped += 1
                continue
            save_public_holiday(db(), {
                "holiday_date": row["holiday_date"],
                "state":        row.get("state", "NAT"),
                "name":         row["name"],
            })
            imported += 1
    except Exception as e:
        return err(str(e))
    return ok({"imported": imported, "skipped": skipped})




@app.route("/api/leave/balances/<int:employee_id>/adjust", methods=["POST"])
@login_required
@tier_required("payroll")
def api_leave_adjust(employee_id):
    """Post a manual leave balance adjustment (opening, correction, purchased leave)."""
    body     = request.json or {}
    type_id  = body.get("leave_type_id")
    hours    = body.get("hours")
    adj_type = body.get("accrual_type", "manual")
    notes    = body.get("notes", "")
    if not type_id:
        return err("leave_type_id is required", 400)
    if hours is None:
        return err("hours is required", 400)
    try:
        hours = float(hours)
    except (TypeError, ValueError):
        return err("hours must be a number", 400)
    import datetime
    username = (session.get("username") or "Web UI")
    post_accrual(
        db(), employee_id, type_id,
        hours        = hours,
        accrual_date = str(datetime.date.today()),
        accrual_type = adj_type,
        notes        = notes,
        created_by   = username,
    )
    return ok({"adjusted": hours})


@app.route("/api/leave/balances/<int:employee_id>/history")
@login_required
@tier_required("payroll")
def api_leave_history(employee_id):
    """Return accrual/deduction history for an employee (up to 200 rows)."""
    limit = int(request.args.get("limit", 200))
    rows  = get_accrual_history(db(), employee_id, limit=limit)
    return ok(rows)


@app.route("/api/leave/outstanding-leave/pdf")
@login_required
@tier_required("payroll")
def api_outstanding_leave_pdf():
    """Download the outstanding leave balances report as a PDF."""
    import os as _os
    try:
        watermark = _get_pdf_watermark()
        pdf_path = generate_outstanding_leave_pdf(db(), watermark=watermark)
    except ImportError as e:
        return err(str(e), 500)
    except Exception as e:
        return err(f"PDF generation failed: {e}", 500)
    filename = _os.path.basename(pdf_path)
    return send_file(pdf_path, mimetype="application/pdf",
                     as_attachment=True, download_name=filename)


@app.route("/api/leave/outstanding-leave/csv")
@login_required
@tier_required("payroll")
def api_outstanding_leave_csv():
    """Download the outstanding leave balances as a CSV file."""
    import tempfile as _tmp, os as _os
    try:
        out = _tmp.mktemp(suffix=".csv", prefix="outstanding_leave_")
        generate_outstanding_leave_csv(db(), output_path=out)
    except Exception as e:
        return err(f"CSV generation failed: {e}", 500)
    return send_file(out, mimetype="text/csv",
                     as_attachment=True,
                     download_name="outstanding_leave_balances.csv")


# ── PAYG Tax Rates ────────────────────────────────────────────────────────────

@app.route("/api/payroll/payg-rates")
@login_required
@tier_required("payroll")
def api_payg_rates_list():
    """List all FY years that have saved PAYG rates."""
    return ok(list_payg_rate_years(db()))


@app.route("/api/payroll/payg-rates/<int:fy_year>")
@login_required
@tier_required("payroll")
def api_payg_rates_get(fy_year):
    """Return full rate set for a given FY year."""
    r = load_payg_rates(db(), fy_year)
    if not r:
        return err("No PAYG rates found for that year", 404)
    r["fy_year"] = fy_year
    return ok(r)


@app.route("/api/payroll/payg-rates", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payg_rates_save():
    """Save or update a full rate set for a FY year."""
    data = request.get_json(force=True)
    try:
        save_payg_rates(
            db(),
            fy_year           = int(data["fy_year"]),
            label             = data.get("label", str(data["fy_year"])),
            brackets          = data.get("brackets", []),
            brackets_no_thresh= data.get("brackets_no_thresh", []),
            medicare          = data.get("medicare", {}),
            lito              = data.get("lito", []),
            lito_no_thresh    = data.get("lito_no_thresh", []),
            help_table        = data.get("help", []),
            sapto             = data.get("sapto", {}),
            no_tfn_rate       = float(data.get("no_tfn_rate", 0.47)),
            help_method       = data.get("help_method", "whole"),
            notes             = data.get("notes", ""),
        )
        return ok({"fy_year": data["fy_year"]})
    except Exception as e:
        return err(str(e), 400)


@app.route("/api/payroll/payg-rates/<int:fy_year>", methods=["DELETE"])
@login_required
@tier_required("payroll")
def api_payg_rates_delete(fy_year):
    """Delete a FY year's PAYG rates (revert to built-in defaults for that year)."""
    try:
        conn = get_connection(db())
        conn.execute("DELETE FROM payg_tax_rates WHERE fy_year=?", (fy_year,))
        conn.commit()
        conn.close()
        return ok({"deleted": fy_year})
    except Exception as e:
        return err(str(e), 400)


@app.route("/api/payroll/payg-rates/calculate", methods=["POST"])
@login_required
@tier_required("payroll")
def api_payg_rates_calculate():
    """
    Test calculator: given gross period earnings + employee flags, return
    withholding amount.  Uses DB rates if available for the requested FY year,
    otherwise falls back to built-in defaults.
    """
    data = request.get_json(force=True)
    try:
        gross      = float(data.get("gross_period", 0))
        frequency  = data.get("frequency", "Fortnightly")
        fy_year    = data.get("fy_year")
        wh = payg_for_period(
            gross_period       = gross,
            frequency          = frequency,
            has_tfn            = data.get("has_tfn", True),
            has_threshold      = data.get("has_threshold", True),
            db_path            = db() if fy_year else None,
            fy_year            = int(fy_year) if fy_year else None,
            has_study_loan     = data.get("has_study_loan", False),
            is_senior          = data.get("is_senior", False),
            senior_couple      = data.get("senior_couple", False),
            is_foreign_resident= data.get("is_foreign_resident", False),
            medicare_exemption = data.get("medicare_exemption", "none"),
        )
        periods = {"Weekly": 52, "Fortnightly": 26, "Monthly": 12}.get(frequency, 26)
        annual_gross = round(gross * periods, 2)
        annual_wh    = round(wh * periods, 2)
        return ok({
            "gross_period":  gross,
            "withholding":   wh,
            "annual_gross":  annual_gross,
            "annual_wh":     annual_wh,
            "effective_rate": round(annual_wh / annual_gross * 100, 2) if annual_gross else 0,
        })
    except Exception as e:
        return err(str(e), 400)


# ── PAYG Payment Summaries ────────────────────────────────────────────────────

@app.route("/api/payroll/payment-summaries")
@login_required
@tier_required("payroll")
def api_payment_summaries_list():
    """
    Return PAYG Payment Summary figures for all employees in a given FY.
    Query param: fy_year (int, e.g. 2025 = FY 2024-25). Defaults to current FY.
    """
    try:
        fy_year = int(request.args.get("fy_year") or current_fy())
        rows = get_payg_summary(db(), fy_year)
        return ok(rows)
    except Exception as e:
        return err(str(e), 400)


@app.route("/api/payroll/payment-summaries/pdf")
@login_required
@tier_required("payroll")
def api_payment_summaries_pdf():
    """
    Stream a PAYG Payment Summary PDF.
    Query params:
        fy_year     (int)  — required
        employee_id (int)  — optional; omit for bulk (all employees)
    """
    import os
    try:
        fy_year     = int(request.args.get("fy_year") or current_fy())
        employee_id = request.args.get("employee_id")
        emp_ids     = [int(employee_id)] if employee_id else None

        out_path = render_payg_summary_pdf(db(), fy_year, employee_ids=emp_ids)

        fy_label = f"{fy_year-1}-{str(fy_year)[2:]}"
        if emp_ids and len(emp_ids) == 1:
            summaries = get_payg_summary(db(), fy_year, employee_id=emp_ids[0])
            emp_name  = summaries[0]["employee_name"].replace(" ", "_") if summaries else "employee"
            filename  = f"PAYG_Summary_{emp_name}_FY{fy_label}.pdf"
        else:
            filename = f"PAYG_Summaries_FY{fy_label}.pdf"

        with open(out_path, "rb") as f:
            data = f.read()
        try:
            os.unlink(out_path)
        except Exception:
            pass

        from flask import Response
        return Response(
            data,
            mimetype="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except ValueError as e:
        return err(str(e), 404)
    except Exception as e:
        return err(str(e), 400)


@app.route("/api/payroll/reset-ytd", methods=["POST"])
@login_required
@tier_required("payroll")
def api_reset_ytd():
    """Reset all employee YTD accumulators to zero. Run once at 1 July each year."""
    try:
        reset_ytd(db())
        return ok()
    except Exception as e:
        return err(str(e), 400)


@app.route("/api/company")
@login_required
def api_company():
    conn = get_connection(db())
    try:
        # Ensure BLOB columns exist before querying them
        for col, typ in (("logo_blob", "BLOB"), ("logo_mime", "TEXT")):
            try:
                conn.execute(f"ALTER TABLE company ADD COLUMN {col} {typ}")
                conn.commit()
            except Exception:
                pass
        row = conn.execute(
            "SELECT id,name,abn,acn,address,city,state,postcode,phone,email,website,"
            "gst_registered,fy_start_month,logo_path,logo_blob,default_payment_instructions,"
            "created_at FROM company WHERE id=1"
        ).fetchone()
    finally:
        conn.close()
    if not row:
        return ok({"name": "dbox", "has_logo": False})
    d = {k: row[k] for k in row.keys() if k != "logo_blob"}
    d["has_logo"] = bool(row["logo_blob"]) or bool(
        d.get("logo_path") and os.path.exists(d.get("logo_path") or ""))
    return ok(d)


# ── Theme persistence ──────────────────────────────────────────────────────────
@app.route("/api/theme", methods=["GET"])
@login_required
def api_theme_get():
    """Return the currently persisted theme name."""
    if not db():
        return ok({"name": "Ocean Light"})
    theme_path = db() + ".dbox.theme"
    try:
        import json as _json
        with open(theme_path) as f:
            data = _json.load(f)
        return ok({"name": data.get("name", "Ocean Light")})
    except Exception:
        return ok({"name": "Ocean Light"})

@app.route("/api/theme", methods=["POST"])
@login_required
def api_theme_set():
    """
    Persist the selected theme name to the .dbox.theme file alongside the DB.
    Called by the web UI whenever the user changes theme — keeps the desktop
    app and PDF renderer in sync.
    """
    data = request.get_json() or {}
    name = data.get("name", "Ocean Light")
    if not db():
        return ok()
    theme_path = db() + ".dbox.theme"
    try:
        import json as _json
        # Preserve any existing custom colours — only update the name
        existing = {}
        try:
            with open(theme_path) as f:
                existing = _json.load(f)
        except Exception:
            pass
        existing["name"] = name
        with open(theme_path, "w") as f:
            _json.dump(existing, f, indent=2)
    except Exception as e:
        return err(str(e))
    return ok()


# ── Navigate (tkinter bridge — stub for future use) ────────────────────────────
@app.route("/api/navigate", methods=["POST"])
@login_required
def api_navigate():
    """
    Receives a module key from the web dashboard and brings the tkinter
    window to that module. Currently a stub — wire to tkinter via IPC when ready.
    """
    data = request.get_json() or {}
    module = data.get("module", "")
    return ok({"module": module})


# ── Heartbeat — browser tab keep-alive / inactivity lock ──────────────────────
import time as _time
import threading as _threading

_last_heartbeat: float = _time.time()
_HEARTBEAT_TIMEOUT = 600  # 10 minutes — lock session if no ping for this long
_shutdown_timer: "_threading.Timer | None" = None
_locked: bool = False     # True after timeout — forces re-login


def _do_lock():
    """
    Called when the heartbeat timer expires. Locks the server by clearing
    all active sessions and setting the _locked flag. The server process
    stays running — the next heartbeat ping from the browser will return
    alive=False and the JS will redirect to the login page.
    """
    global _locked
    _locked = True
    print("\n  dbox: inactivity timeout — session locked. Server still running.")


def _reset_shutdown_timer():
    global _shutdown_timer
    if _shutdown_timer is not None:
        _shutdown_timer.cancel()
    _shutdown_timer = _threading.Timer(_HEARTBEAT_TIMEOUT, _do_lock)
    _shutdown_timer.daemon = True
    _shutdown_timer.start()


# ══════════════════════════════════════════════════════════════════════════════
#  FIXED ASSETS
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/api/fixed-assets")
@login_required
def api_fa_list():
    status = request.args.get("status")
    rows = asset_register_report(DB_PATH)
    if status and status != "All":
        rows = [r for r in rows if r.get("status") == status]
    # Attach category label
    for r in rows:
        cat = r.get("category") or ""
        cls = ASSET_CLASS_BY_KEY.get(cat)
        r["category_label"] = cls["label"] if cls else cat
    return ok(rows)


@app.route("/api/fixed-assets/<int:aid>")
@login_required
def api_fa_get(aid):
    a = get_fixed_asset(DB_PATH, aid)
    if not a:
        return err("Asset not found", 404)
    cat = a.get("category") or ""
    cls = ASSET_CLASS_BY_KEY.get(cat)
    a["category_label"] = cls["label"] if cls else cat
    # Attach account name/code fields (get_fixed_asset returns plain row)
    from core.database import get_connection as _gc
    conn = _gc(DB_PATH)
    def _acc(acc_id):
        if not acc_id:
            return None, None
        r = conn.execute("SELECT code, name FROM accounts WHERE id=?", (acc_id,)).fetchone()
        return (r["code"], r["name"]) if r else (None, None)
    a["asset_account_code"],     a["asset_account_name"]     = _acc(a.get("asset_account_id"))
    a["accum_depn_account_code"], a["accum_depn_account_name"] = _acc(a.get("accum_depn_account_id"))
    a["depn_expense_account_code"], a["depn_expense_account_name"] = _acc(a.get("depn_expense_account_id"))
    conn.close()
    return ok(a)


@app.route("/api/fixed-assets", methods=["POST"])
@login_required
def api_fa_create():
    data = request.get_json(force=True)
    if not data.get("description"):
        return err("Description is required")
    if not data.get("acquisition_date"):
        return err("Acquisition date is required")
    if not data.get("cost_excl_gst") and not data.get("cost_price"):
        return err("Cost is required")
    # Ensure no id on create
    data.pop("id", None)
    aid = save_fixed_asset(DB_PATH, data)
    # Build depreciation schedule
    try:
        regenerate_schedule(DB_PATH, aid)
    except Exception:
        pass
    return ok({"id": aid})


@app.route("/api/fixed-assets/<int:aid>", methods=["PUT"])
@login_required
def api_fa_update(aid):
    data = request.get_json(force=True)
    data["id"] = aid
    save_fixed_asset(DB_PATH, data)
    try:
        regenerate_schedule(DB_PATH, aid)
    except Exception:
        pass
    return ok()


@app.route("/api/fixed-assets/<int:aid>", methods=["DELETE"])
@login_required
def api_fa_delete(aid):
    try:
        delete_fixed_asset(DB_PATH, aid)
        return ok()
    except ValueError as e:
        return err(str(e))


@app.route("/api/fixed-assets/<int:aid>/schedule")
@login_required
def api_fa_schedule(aid):
    rows = get_depn_schedule(DB_PATH, aid)
    return ok(rows)


@app.route("/api/fixed-assets/<int:aid>/regenerate-schedule", methods=["POST"])
@login_required
def api_fa_regenerate_schedule(aid):
    try:
        rows = regenerate_schedule(DB_PATH, aid)
        return ok({"rows": len(rows)})
    except ValueError as e:
        return err(str(e))


@app.route("/api/fixed-assets/<int:aid>/post-depreciation", methods=["POST"])
@login_required
def api_fa_post_depn(aid):
    data    = request.get_json(force=True) or {}
    fy_year = int(data.get("fy_year", 0))
    if not fy_year:
        return err("fy_year is required")
    try:
        jid = post_depreciation_journal(DB_PATH, aid, fy_year)
        asset = get_fixed_asset(DB_PATH, aid)
        from core.database import get_connection as _gc
        conn = _gc(DB_PATH)
        row  = conn.execute(
            "SELECT depn_amount FROM fixed_asset_depn WHERE asset_id=? AND fy_year=?",
            (aid, fy_year)).fetchone()
        conn.close()
        return ok({"journal_id": jid, "depn_amount": row["depn_amount"] if row else 0})
    except ValueError as e:
        return err(str(e))


@app.route("/api/fixed-assets/post-fy-preview")
@login_required
def api_fa_post_fy_preview():
    """Preview which assets will be posted for a given FY (no side effects)."""
    fy_year   = int(request.args.get("fy_year", 0))
    asset_id  = request.args.get("asset_id")
    if not fy_year:
        return err("fy_year is required")
    assets = (get_fixed_assets(DB_PATH, status="Active")
              if not asset_id
              else [get_fixed_asset(DB_PATH, int(asset_id))] if get_fixed_asset(DB_PATH, int(asset_id)) else [])
    from core.database import get_connection as _gc
    rows = []
    for a in assets:
        conn = _gc(DB_PATH)
        srow = conn.execute(
            "SELECT depn_amount, posted FROM fixed_asset_depn WHERE asset_id=? AND fy_year=?",
            (a["id"], fy_year)).fetchone()
        conn.close()
        if not srow:
            continue
        already = bool(srow["posted"])
        has_accs = bool(a.get("depn_expense_account_id") and a.get("accum_depn_account_id"))
        if already:
            status = "Already posted"
        elif not has_accs:
            status = "⚠ Missing GL accounts"
        else:
            status = "Ready to post"
        rows.append({
            "asset_id":     a["id"],
            "asset_number": a.get("asset_number"),
            "description":  a.get("description"),
            "depn_amount":  srow["depn_amount"],
            "already_posted": already,
            "ready":        not already and has_accs,
            "status":       status,
        })
    return ok(rows)


@app.route("/api/fixed-assets/post-all-depreciation", methods=["POST"])
@login_required
def api_fa_post_all_depn():
    data    = request.get_json(force=True) or {}
    fy_year = int(data.get("fy_year", 0))
    if not fy_year:
        return err("fy_year is required")
    results = post_all_fy_depreciation(DB_PATH, fy_year)
    return ok({"results": results})


@app.route("/api/fixed-assets/<int:aid>/dispose", methods=["POST"])
@login_required
def api_fa_dispose(aid):
    data = request.get_json(force=True) or {}
    try:
        result = dispose_asset(
            DB_PATH,
            aid,
            data.get("disposal_date"),
            float(data.get("proceeds", 0)),
            data.get("method", "Sale"),
            data.get("notes", ""),
        )
        return ok(result)
    except (ValueError, Exception) as e:
        return err(str(e))


@app.route("/api/fixed-assets/class-defaults")
@login_required
def api_fa_class_defaults():
    cat = request.args.get("category", "")
    # Accept both key and label (web sends label; desktop sends key)
    if cat not in ASSET_CLASS_BY_KEY:
        match = next((c["key"] for c in ASSET_CLASSES if c["label"] == cat), None)
        if match:
            cat = match
    d = get_class_defaults(DB_PATH, cat)
    return ok(d)


@app.route("/api/fixed-assets/ato-lookup")
@login_required
def api_fa_ato_lookup():
    desc = request.args.get("description", "")
    life = lookup_ato_life(desc)
    return ok({"life": life})


@app.route("/api/fixed-assets/register-pdf")
@login_required
def api_fa_register_pdf():
    import io
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors as rl_colors
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib.units import mm

        rows   = asset_register_report(DB_PATH)
        buf    = io.BytesIO()
        doc    = SimpleDocTemplate(buf, pagesize=A4,
                                   leftMargin=15*mm, rightMargin=15*mm,
                                   topMargin=18*mm, bottomMargin=15*mm)
        styles = getSampleStyleSheet()
        story  = []

        story.append(Paragraph("Fixed Asset Register", styles["h1"]))
        story.append(Paragraph(f"Generated {__import__('datetime').date.today()}", styles["Normal"]))
        story.append(Spacer(1, 8*mm))

        hdr = ["Asset No", "Description", "Category", "Acquired",
               "Cost (ex GST)", "Method", "Accum Depr", "WDV", "Status"]
        data = [hdr]
        for a in rows:
            cost  = a.get("cost_excl_gst") or a.get("cost_price", 0)
            accum = a.get("accum_depn", 0)
            wdv   = a.get("current_wdv", 0)
            data.append([
                a.get("asset_number") or f"#{a['id']}",
                a.get("description", ""),
                a.get("category") or "",
                a.get("acquisition_date", ""),
                f"${cost:,.2f}",
                a.get("depn_method", ""),
                f"${accum:,.2f}",
                f"${wdv:,.2f}",
                a.get("status", ""),
            ])

        t = Table(data, repeatRows=1,
                  colWidths=[22*mm,55*mm,30*mm,22*mm,24*mm,28*mm,24*mm,22*mm,22*mm])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), rl_colors.HexColor("#1a3a5c")),
            ("TEXTCOLOR",  (0,0), (-1,0), rl_colors.white),
            ("FONTSIZE",   (0,0), (-1,0), 8),
            ("FONTSIZE",   (0,1), (-1,-1), 7),
            ("GRID",       (0,0), (-1,-1), 0.3, rl_colors.lightgrey),
            ("ROWBACKGROUNDS", (0,1), (-1,-1),
             [rl_colors.white, rl_colors.HexColor("#f5f7fa")]),
            ("ALIGN", (4,0), (-1,-1), "RIGHT"),
        ]))
        story.append(t)

        doc.build(story)
        buf.seek(0)
        from flask import send_file
        return send_file(buf, mimetype="application/pdf",
                         as_attachment=False,
                         download_name="asset_register.pdf")
    except Exception as e:
        return err(f"PDF generation failed: {e}")


# ── Warranties ────────────────────────────────────────────────────────────────

@app.route("/api/warranties")
@login_required
def api_warranties_list():
    search      = request.args.get("search", "")
    status      = request.args.get("status", "all")
    source_type = request.args.get("source_type", "")
    date_from   = request.args.get("date_from", "")
    date_to     = request.args.get("date_to", "")
    rows = get_warranties(DB_PATH, search=search, status=status,
                          source_type=source_type,
                          date_from=date_from, date_to=date_to)
    return ok(rows)


@app.route("/api/warranties/txn_options")
@login_required
def api_warranty_txn_options():
    """Compact list of recent invoices/bills/payments for the warranty transaction picker."""
    options = []
    try:
        for inv in (get_invoices(DB_PATH) or [])[:50]:
            ref = inv.get("invoice_number") or f"#{inv['id']}"
            options.append({
                "key":   f"invoice:{inv['id']}",
                "label": f"Invoice {ref} — {inv.get('contact_name','')} ({(inv.get('invoice_date') or '')[:7]})",
            })
    except Exception:
        pass
    try:
        for b in (get_bills(DB_PATH) or [])[:50]:
            ref = b.get("bill_number") or f"#{b['id']}"
            options.append({
                "key":   f"bill:{b['id']}",
                "label": f"Bill {ref} — {b.get('contact_name','')} ({(b.get('bill_date') or '')[:7]})",
            })
    except Exception:
        pass
    try:
        for p in (get_payments(DB_PATH) or [])[:50]:
            options.append({
                "key":   f"payment:{p['id']}",
                "label": (f"Payment #{p['id']} — {p.get('contact_name','')} "
                          f"{p.get('payment_type','')} "
                          f"${float(p.get('amount') or 0):,.2f} "
                          f"({(p.get('payment_date') or '')[:7]})"),
            })
    except Exception:
        pass
    return ok(options)


@app.route("/api/warranties/<int:wid>")
@login_required
def api_warranty_get(wid):
    w = get_warranty(DB_PATH, wid)
    if not w:
        return err("Warranty not found", 404)
    return ok(w)


@app.route("/api/warranties", methods=["POST"])
@login_required
def api_warranty_save():
    d = request.get_json(force=True)
    try:
        new_id = save_warranty(
            DB_PATH,
            source_type      = d.get("source_type", "invoice"),
            source_id        = int(d.get("source_id") or 0),
            item_description = d.get("item_description", ""),
            warranty_expiry  = d.get("warranty_expiry", ""),
            serial_number    = d.get("serial_number", ""),
            provider         = d.get("provider", ""),
            purchase_date    = d.get("purchase_date") or "",
            notes            = d.get("notes", ""),
            warranty_id      = d.get("warranty_id") or None,
        )
        return ok({"id": new_id})
    except Exception as e:
        return err(str(e))


@app.route("/api/warranties/<int:wid>", methods=["DELETE"])
@login_required
def api_warranty_delete(wid):
    try:
        delete_warranty(DB_PATH, wid)
        return ok()
    except Exception as e:
        return err(str(e))


@app.route("/api/warranties/<int:wid>/claim", methods=["POST"])
@login_required
def api_warranty_claim(wid):
    d = request.get_json(force=True)
    outcome = d.get("outcome", "")
    if outcome not in CLAIM_OUTCOMES:
        return err(f"Unknown outcome: {outcome}")
    try:
        result = lodge_claim(
            DB_PATH,
            warranty_id          = wid,
            outcome              = outcome,
            claim_date           = d.get("claim_date", ""),
            claim_notes          = d.get("claim_notes", ""),
            claim_amount         = d.get("claim_amount"),
            new_serial           = d.get("new_serial", ""),
            new_item_description = d.get("new_item_description", ""),
            new_expiry           = d.get("new_expiry", ""),
            new_notes            = d.get("new_notes", ""),
        )
        return ok(result)
    except ValueError as e:
        return err(str(e), 404)
    except Exception as e:
        return err(str(e))


@app.route("/api/warranties/outcomes")
@login_required
def api_warranty_outcomes():
    return ok(CLAIM_OUTCOMES)


@app.route("/api/warranties/<int:wid>/linked_attachments")
@login_required
def api_warranty_linked_attachments_get(wid):
    return ok(get_linked_attachments(DB_PATH, wid))


@app.route("/api/warranties/<int:wid>/linked_attachments", methods=["POST"])
@login_required
def api_warranty_linked_attachments_set(wid):
    d = request.get_json(force=True)
    ids = [int(x) for x in (d.get("attachment_ids") or [])]
    try:
        set_linked_attachments(DB_PATH, wid, ids)
        return ok()
    except Exception as e:
        return err(str(e))


@app.route("/api/heartbeat", methods=["POST"])
def api_heartbeat():
    """
    Called every 5 seconds by the browser to signal the tab is still open.
    - If the inactivity timeout has fired (_locked=True), clears the Flask
      session and returns alive=False so the browser redirects to login.
    - Otherwise resets the countdown and returns alive=True.
    No login required — unauthenticated tabs still keep the server alive
    and receive the lock signal correctly.
    """
    global _last_heartbeat, _locked
    if _locked:
        session.clear()
        return ok({"alive": False, "reason": "timeout"})
    _last_heartbeat = _time.time()
    _reset_shutdown_timer()
    return ok({"alive": True})


# ── File picker ────────────────────────────────────────────────────────────────
def _pick_db_file() -> str:
    """
    Show a native file dialog to open or create a .dbox file.
    Returns the absolute path chosen, or exits if the user cancels.

    Uses tkinter only for the dialog — the main app window is never shown.
    Falls back to a console prompt if tkinter is unavailable (e.g. headless server).
    """
    import pathlib

    # Try native file dialog first
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox

        root = tk.Tk()
        root.withdraw()          # hide the blank tk window
        root.attributes("-topmost", True)

        choice = messagebox.askquestion(
            "dogbox — Open File",
            "Do you want to open an existing company file?\n\n"
            "Select Yes to open an existing .dbox file.\n"
            "Select No to create a new company file.",
            icon="question",
        )

        if choice == "yes":
            path = filedialog.askopenfilename(
                parent=root,
                title="Open Company File",
                filetypes=[("dbox company files", "*.dbox"), ("All files", "*.*")],
                initialdir=str(pathlib.Path.home()),
            )
        else:
            path = filedialog.asksaveasfilename(
                parent=root,
                title="Create New Company File",
                defaultextension=".dbox",
                filetypes=[("dbox company files", "*.dbox")],
                initialdir=str(pathlib.Path.home()),
                initialfile="company.dbox",
            )

        root.destroy()

        if not path:
            print("No file selected — exiting.")
            sys.exit(0)

        return os.path.abspath(path)

    except Exception:
        # Headless / tkinter not available — fall back to console prompt
        print("\ndogbox Web Interface")
        print("─" * 40)
        print("Enter path to .dbox file (or press Enter for 'dbox_data.db'):")
        path = input("> ").strip()
        if not path:
            path = "dbox_data.db"
        return os.path.abspath(path)


# ── Users ──────────────────────────────────────────────────────────────────────

def _admin_required(f):
    """Decorator: requires Admin role in addition to login."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if current_user().get("role") != "Admin":
            return err("Admin role required", 403)
        return f(*args, **kwargs)
    return decorated


@app.route("/api/users")
@login_required
@_admin_required
def api_users_list():
    active_only = request.args.get("active_only", "1") != "0"
    return ok(get_users(db(), active_only=active_only))


@app.route("/api/users/<int:uid>")
@login_required
@_admin_required
def api_users_get(uid):
    user = get_user(db(), uid)
    if not user:
        return err("User not found", 404)
    # Never return the password hash to the client
    user.pop("password_hash", None)
    return ok(user)


@app.route("/api/users", methods=["POST"])
@login_required
@_admin_required
def api_users_create():
    data = request.get_json() or {}
    username     = (data.get("username") or "").strip()
    display_name = (data.get("display_name") or "").strip()
    password     = data.get("password") or ""
    role         = data.get("role", "Staff")
    if not username:
        return err("Username is required")
    if not display_name:
        return err("Display name is required")
    if not password:
        return err("Password is required")
    if role not in ("Admin", "Accountant", "Staff", "ReadOnly"):
        return err("Invalid role")
    try:
        uid = create_user(db(), username, display_name, password, role=role)
    except ValueError as e:
        return err(str(e))
    audit(db(), current_user().get("id"), current_user().get("username", "?"),
          "create_user", "user", uid, f"Created user '{username}' role={role}")
    return ok({"id": uid})


@app.route("/api/users/<int:uid>", methods=["PUT"])
@login_required
@_admin_required
def api_users_update(uid):
    data = request.get_json() or {}
    display_name = data.get("display_name")
    role         = data.get("role")
    is_active    = data.get("is_active")
    if role is not None and role not in ("Admin", "Accountant", "Staff", "ReadOnly"):
        return err("Invalid role")
    if display_name is not None:
        display_name = display_name.strip()
        if not display_name:
            return err("Display name cannot be empty")
    update_user(db(), uid,
                display_name=display_name,
                role=role,
                is_active=is_active)
    audit(db(), current_user().get("id"), current_user().get("username", "?"),
          "update_user", "user", uid,
          f"display_name={display_name!r} role={role!r} is_active={is_active!r}")
    return ok()


@app.route("/api/users/<int:uid>/set-password", methods=["POST"])
@login_required
@_admin_required
def api_users_set_password(uid):
    data = request.get_json() or {}
    password = data.get("password") or ""
    if len(password) < 6:
        return err("Password must be at least 6 characters")
    update_user(db(), uid, new_password=password)
    audit(db(), current_user().get("id"), current_user().get("username", "?"),
          "set_password", "user", uid, "Password changed by admin")
    return ok()


@app.route("/api/users/audit-log")
@login_required
@_admin_required
def api_users_audit_log():
    return ok(get_audit_log(db()))


# ── Settings: Company Details (PUT) ───────────────────────────────────────────
@app.route("/api/company", methods=["PUT"])
@login_required
def api_company_save():
    """Update company details from the web UI Settings → Company Details panel."""
    data = request.get_json() or {}
    name = (data.get("name") or "").strip()
    if not name:
        return err("Company name is required")
    conn = get_connection(db())
    try:
        # Ensure acn column exists (older DB files may not have it)
        try:
            conn.execute("ALTER TABLE company ADD COLUMN acn TEXT")
        except Exception:
            pass
        existing = conn.execute("SELECT id FROM company WHERE id=1").fetchone()
        fields = ("name", "abn", "acn", "address", "city", "state", "postcode",
                  "phone", "email", "website", "gst_registered",
                  "default_payment_instructions")
        vals = tuple(data.get(f, "") if f not in ("gst_registered",) else int(data.get(f, 1))
                     for f in fields)
        if existing:
            set_clause = ", ".join(f"{f}=?" for f in fields)
            conn.execute(f"UPDATE company SET {set_clause} WHERE id=1", vals)
        else:
            col_list = ", ".join(("id",) + fields)
            placeholders = ", ".join("?" for _ in range(len(fields) + 1))
            conn.execute(f"INSERT INTO company ({col_list}) VALUES ({placeholders})",
                         (1,) + vals)
        conn.commit()
    finally:
        conn.close()
    return ok()


# ── Company logo ───────────────────────────────────────────────────────────────
# Logo bytes are stored directly in the DB (logo_blob / logo_mime columns).
# This avoids any filesystem path issues on Windows.

def _ensure_logo_columns(conn):
    """Add logo_blob / logo_mime columns if this is an older DB file."""
    for col, typ in (("logo_blob", "BLOB"), ("logo_mime", "TEXT")):
        try:
            conn.execute(f"ALTER TABLE company ADD COLUMN {col} {typ}")
        except Exception:
            pass


@app.route("/api/company/logo")
@login_required
def api_company_logo_get():
    from flask import Response
    conn = get_connection(db())
    _ensure_logo_columns(conn)
    row = conn.execute("SELECT logo_blob, logo_mime, logo_path FROM company WHERE id=1").fetchone()
    conn.close()
    if not row:
        return err("No logo", 404)
    # Prefer BLOB stored by web upload; fall back to desktop file path
    if row["logo_blob"]:
        mime = row["logo_mime"] or "image/png"
        return Response(bytes(row["logo_blob"]), mimetype=mime,
                        headers={"Cache-Control": "no-store"})
    if row["logo_path"] and os.path.exists(row["logo_path"]):
        return send_file(row["logo_path"])
    return err("No logo", 404)


@app.route("/api/company/logo", methods=["POST"])
@login_required
def api_company_logo_upload():
    if "logo" not in request.files:
        return err("No file provided")
    f = request.files["logo"]
    if not f.filename:
        return err("No file selected")
    ext = os.path.splitext(f.filename)[1].lower()
    mime_map = {".png": "image/png", ".jpg": "image/jpeg",
                ".jpeg": "image/jpeg", ".gif": "image/gif"}
    if ext not in mime_map:
        return err("Unsupported format — use PNG, JPG, or GIF")
    data = f.read()
    mime = mime_map[ext]
    conn = get_connection(db())
    try:
        _ensure_logo_columns(conn)
        conn.execute(
            "UPDATE company SET logo_blob=?, logo_mime=? WHERE id=1",
            (data, mime))
        conn.commit()
    finally:
        conn.close()
    return ok()


@app.route("/api/company/logo", methods=["DELETE"])
@login_required
def api_company_logo_delete():
    conn = get_connection(db())
    try:
        _ensure_logo_columns(conn)
        conn.execute("UPDATE company SET logo_blob=NULL, logo_mime=NULL WHERE id=1")
        conn.commit()
    finally:
        conn.close()
    return ok()


# ── Data Diagnostics ──────────────────────────────────────────────────────────
@app.route("/api/admin/diagnose-balances")
@login_required
def api_diagnose_balances():
    """
    For every bank account, show the three numbers each report sees so we can
    identify where they split.
    """
    from core.database import get_connection as _gc
    today = str(date.today())
    conn  = _gc(db())

    accounts_raw = conn.execute(
        "SELECT id, code, name, account_type, account_subtype, is_bank, opening_balance "
        "FROM accounts WHERE is_bank=1 AND is_active=1 ORDER BY code"
    ).fetchall()

    result = []
    for a in accounts_raw:
        aid = a["id"]

        # Raw journal_lines sum (no date filter) — what dashboard uses
        jl_all = conn.execute(
            "SELECT COALESCE(SUM(debit),0)-COALESCE(SUM(credit),0) AS net "
            "FROM journal_lines WHERE account_id=?", (aid,)
        ).fetchone()["net"] or 0.0

        # Journal_lines sum filtered to today — what trial_balance uses
        jl_today = conn.execute(
            "SELECT COALESCE(SUM(jl.debit),0)-COALESCE(SUM(jl.credit),0) AS net "
            "FROM journal_lines jl "
            "JOIN journal_entries je ON jl.journal_id=je.id "
            "WHERE jl.account_id=? AND je.entry_date<=?", (aid, today)
        ).fetchone()["net"] or 0.0

        # Orphaned journal_lines (no matching journal_entries)
        orphaned = conn.execute(
            "SELECT COALESCE(SUM(jl.debit),0)-COALESCE(SUM(jl.credit),0) AS net "
            "FROM journal_lines jl "
            "LEFT JOIN journal_entries je ON jl.journal_id=je.id "
            "WHERE jl.account_id=? AND je.id IS NULL", (aid,)
        ).fetchone()["net"] or 0.0

        ob = a["opening_balance"] or 0.0

        # OB journal contribution specifically
        ob_jl = conn.execute(
            "SELECT COALESCE(SUM(jl.debit),0)-COALESCE(SUM(jl.credit),0) AS net "
            "FROM journal_lines jl "
            "JOIN journal_entries je ON jl.journal_id=je.id "
            "WHERE jl.account_id=? AND (je.reference LIKE 'OB-%' OR je.description='Opening balances')",
            (aid,)
        ).fetchone()["net"] or 0.0

        future_jl = conn.execute(
            "SELECT COALESCE(SUM(jl.debit),0)-COALESCE(SUM(jl.credit),0) AS net "
            "FROM journal_lines jl "
            "JOIN journal_entries je ON jl.journal_id=je.id "
            "WHERE jl.account_id=? AND je.entry_date>?", (aid, today)
        ).fetchone()["net"] or 0.0

        result.append({
            "id": aid, "code": a["code"], "name": a["name"],
            "account_type": a["account_type"], "subtype": a["account_subtype"],
            "opening_balance_field": ob,
            "jl_sum_all_time":  round(ob + jl_all,   2),
            "jl_sum_as_at_today": round(ob + jl_today, 2),
            "ob_journal_contribution": round(ob_jl, 2),
            "double_counted_by": round(ob_jl, 2) if abs(ob) > 0.01 and abs(ob_jl) > 0.01 else 0,
            "orphaned_jl_net": round(orphaned, 2),
            "future_dated_jl_net": round(future_jl, 2),
        })

    conn.close()
    return ok(result)


@app.route("/api/admin/future-dated-entries")
@login_required
def api_future_dated_entries():
    """List all journal entries dated after today."""
    today = date.today().isoformat()
    conn  = get_connection(db())
    rows  = conn.execute("""
        SELECT je.id, je.entry_date, je.description, je.reference, je.entry_type,
               a.code as acc_code, a.name as acc_name,
               jl.debit, jl.credit
        FROM journal_entries je
        JOIN journal_lines jl ON jl.journal_id=je.id
        JOIN accounts a ON jl.account_id=a.id
        WHERE je.entry_date > ?
        ORDER BY je.entry_date, je.id
    """, (today,)).fetchall()
    conn.close()
    return ok([dict(r) for r in rows])


# ── Data Repair ───────────────────────────────────────────────────────────────
@app.route("/api/admin/repair-void-journals", methods=["POST"])
@login_required
def api_repair_void_journals():
    """
    Repair voided invoices/bills whose GL journals were never reversed.
    Safe to run repeatedly — idempotent (already-reversed journals are skipped).
    """
    result = repair_orphaned_void_journals(db())
    return ok(result)


@app.route("/api/admin/repair-missing-gl", methods=["POST"])
@login_required
def api_repair_missing_gl():
    """
    Post GL journal entries for any Sent/Approved/Partial/Paid invoices or bills
    that have no journal_id. Idempotent — documents with an existing journal are skipped.
    """
    result = repair_missing_gl_journals(db())
    return ok(result)


@app.route("/api/admin/repair-opening-balances", methods=["POST"])
@login_required
def api_repair_opening_balances():
    """
    One-time repair for files where the OB wizard double-counted balances by
    setting both a journal entry AND accounts.opening_balance.

    Zeroes opening_balance for any account that has an OB journal entry, so the
    journal becomes the single source of truth.  Idempotent — safe to run again.
    """
    conn = get_connection(db())
    affected = conn.execute("""
        SELECT DISTINCT jl.account_id
        FROM journal_lines jl
        JOIN journal_entries je ON jl.journal_id = je.id
        WHERE je.reference LIKE 'OB-%' OR je.description = 'Opening balances'
    """).fetchall()

    fixed = 0
    skipped = 0
    for row in affected:
        cur = conn.execute("SELECT opening_balance FROM accounts WHERE id=?",
                           (row["account_id"],)).fetchone()
        if cur and (cur["opening_balance"] or 0) != 0:
            conn.execute("UPDATE accounts SET opening_balance=0 WHERE id=?",
                         (row["account_id"],))
            fixed += 1
        else:
            skipped += 1
    conn.commit()
    conn.close()
    return ok({"accounts_fixed": fixed, "already_zero": skipped})


@app.route("/api/admin/repair-date-formats", methods=["POST"])
@login_required
def api_repair_date_formats():
    """
    Fix dates stored as YYYY-MON-DD (e.g. 2026-APR-01) instead of YYYY-MM-DD.
    Caused by the CSV importer using %Y-%m-%d format on CBA exports that use
    abbreviated month names instead of numeric months.
    """
    MONTHS = {'JAN':'01','FEB':'02','MAR':'03','APR':'04','MAY':'05','JUN':'06',
              'JUL':'07','AUG':'08','SEP':'09','OCT':'10','NOV':'11','DEC':'12'}
    import re
    pattern = re.compile(r'^(\d{4})-([A-Z]{3})-(\d{2})$')

    def fix(d):
        if not d:
            return None
        m = pattern.match(str(d))
        if m:
            y, mon, day = m.groups()
            num = MONTHS.get(mon)
            return f"{y}-{num}-{day}" if num else None
        return None

    conn = get_connection(db())
    bt_rows = conn.execute(
        "SELECT id, transaction_date FROM bank_transactions").fetchall()
    je_rows = conn.execute(
        "SELECT id, entry_date FROM journal_entries").fetchall()

    bt_fixed = je_fixed = 0
    for r in bt_rows:
        iso = fix(r["transaction_date"])
        if iso:
            conn.execute("UPDATE bank_transactions SET transaction_date=? WHERE id=?",
                         (iso, r["id"]))
            bt_fixed += 1
    for r in je_rows:
        iso = fix(r["entry_date"])
        if iso:
            conn.execute("UPDATE journal_entries SET entry_date=? WHERE id=?",
                         (iso, r["id"]))
            je_fixed += 1

    conn.commit()
    conn.close()
    return ok({"bank_transactions_fixed": bt_fixed, "journal_entries_fixed": je_fixed})


# ── Settings: Email / SMTP ─────────────────────────────────────────────────────
@app.route("/api/settings/email", methods=["GET"])
@login_required
def api_email_settings_get():
    from core.email_invoice import get_email_settings
    return ok(get_email_settings(db()))


@app.route("/api/settings/email", methods=["POST"])
@login_required
def api_email_settings_save():
    from core.email_invoice import save_email_settings
    data = request.get_json() or {}
    save_email_settings(db(), data)
    return ok()


@app.route("/api/settings/email/test", methods=["POST"])
@login_required
def api_email_test():
    import smtplib, ssl
    data = request.get_json() or {}
    host = data.get("smtp_host", "").strip()
    port = int(data.get("smtp_port") or 587)
    user = data.get("smtp_user", "").strip()
    pwd  = data.get("smtp_password", "")
    tls  = int(data.get("use_tls", 1))
    if not host or not user or not pwd:
        return err("Fill in host, username, and password first")
    try:
        ctx = ssl.create_default_context()
        if port == 465:
            with smtplib.SMTP_SSL(host, port, context=ctx) as s:
                s.login(user, pwd)
        else:
            with smtplib.SMTP(host, port, timeout=10) as s:
                if tls:
                    s.starttls(context=ctx)
                s.login(user, pwd)
        return ok()
    except smtplib.SMTPAuthenticationError:
        return err("Authentication failed. For Gmail use an App Password, not your regular password.")
    except Exception as e:
        return err(str(e))


# ── Settings: Discount Limits ──────────────────────────────────────────────────
@app.route("/api/settings/discount-limits", methods=["GET"])
@login_required
def api_discount_limits_get():
    from core.discounts import get_discount_limits
    return ok(get_discount_limits(db()))


@app.route("/api/settings/discount-limits", methods=["POST"])
@login_required
def api_discount_limits_save():
    from core.discounts import save_discount_limits
    data = request.get_json() or {}
    # Validate all values are 0-100
    for role, val in data.items():
        try:
            v = float(val)
            if v < 0 or v > 100:
                return err(f"{role}: percentage must be 0–100")
        except (TypeError, ValueError):
            return err(f"{role}: must be a number")
    save_discount_limits(db(), {k: float(v) for k, v in data.items()})
    return ok()


# ── Settings: Opening Balance Wizard ─────────────────────────────────────────

@app.route("/api/opening-balances/status")
@login_required
def api_ob_status():
    conn = get_connection(db())
    n = conn.execute(
        "SELECT COUNT(*) as n FROM journal_entries "
        "WHERE reference LIKE 'OB-%' OR description='Opening balances'"
    ).fetchone()["n"]
    conn.close()
    return ok({"already_posted": n > 0, "count": n})


@app.route("/api/opening-balances", methods=["POST"])
@login_required
def api_ob_post():
    import datetime as _dt
    data     = request.get_json() or {}
    date_str = (data.get("date") or "").strip()
    entries  = data.get("entries") or []
    try:
        _dt.date.fromisoformat(date_str)
    except ValueError:
        return err("Invalid date — use YYYY-MM-DD")

    DEBIT_TYPES = {"Asset", "Bank", "Expense", "Accounts Receivable",
                   "Cost of Sales", "Credit Card"}
    conn  = get_connection(db())
    lines = []
    total_dr = total_cr = 0.0
    for e in entries:
        try:
            amt = float(e.get("amount") or 0)
        except (TypeError, ValueError):
            continue
        if amt < 0.005:
            continue
        acc = conn.execute(
            "SELECT id, name, account_type FROM accounts WHERE id=?",
            (e.get("account_id"),)).fetchone()
        if not acc:
            continue
        if acc["account_type"] in DEBIT_TYPES:
            lines.append({"account_id": acc["id"], "debit": amt, "credit": 0.0,
                          "description": acc["name"]})
            total_dr += amt
        else:
            lines.append({"account_id": acc["id"], "debit": 0.0, "credit": amt,
                          "description": acc["name"]})
            total_cr += amt

    # Auto-balance via Retained Earnings if TB doesn't balance
    diff = round(total_dr - total_cr, 2)
    if abs(diff) > 0.01:
        re_acc = conn.execute(
            "SELECT id FROM accounts WHERE code LIKE '3-%' "
            "AND name LIKE '%Retained%' LIMIT 1").fetchone()
        if re_acc:
            if diff > 0:
                lines.append({"account_id": re_acc["id"], "debit": 0.0, "credit": diff,
                              "description": "Retained Earnings (auto-balance)"})
            else:
                lines.append({"account_id": re_acc["id"], "debit": abs(diff), "credit": 0.0,
                              "description": "Retained Earnings (auto-balance)"})
    conn.close()

    if not lines:
        return err("No valid entries — enter at least one non-zero balance")
    try:
        post_journal(db(), date_str, "Opening balances", f"OB-{date_str}", lines)
        # Zero out opening_balance — the journal entry is now the single source of truth.
        # Keeping a non-zero opening_balance AND a journal would double-count the amount.
        conn2 = get_connection(db())
        for e in entries:
            try:
                conn2.execute("UPDATE accounts SET opening_balance=0 WHERE id=?",
                              (e["account_id"],))
            except Exception:
                pass
        conn2.commit(); conn2.close()
        return ok({"posted": len(lines)})
    except Exception as exc:
        return err(str(exc))


# ── Settings: Import report CSV (parse only — no DB write) ────────────────────

@app.route("/api/import/parse-report-csv", methods=["POST"])
@login_required
def api_import_parse_report_csv():
    if "file" not in request.files:
        return err("No file uploaded")
    f = request.files["file"]
    if not f.filename:
        return err("No file selected")
    import tempfile, os as _os
    tmp = tempfile.NamedTemporaryFile(suffix=".csv", delete=False)
    try:
        f.save(tmp.name); tmp.close()
        from core.importer import parse_report_csv
        result = parse_report_csv(tmp.name)
        return ok(result)
    except Exception as exc:
        return err(str(exc))
    finally:
        try: _os.unlink(tmp.name)
        except Exception: pass


# ── Transaction Import Wizard ─────────────────────────────────────────────────

@app.route("/api/txn-import/parse", methods=["POST"])
@login_required
def api_txn_import_parse():
    """Parse a Saasu transactions CSV — return unique accounts, counterparties, summary."""
    if "file" not in request.files:
        return err("No file uploaded")
    f = request.files["file"]
    if not f.filename:
        return err("No file selected")
    import csv, io as _io
    try:
        content = f.read().decode("utf-8-sig")
        reader = csv.DictReader(_io.StringIO(content))
        accounts = {}
        counterparties = {}
        type_counts = {}
        dates = []
        for row in reader:
            txn_type = (row.get("Transaction type") or "").strip()
            acct_id  = (row.get("Account ID") or "").strip()
            acct_nm  = (row.get("Account name") or "").strip()
            acct_tp  = (row.get("Account type") or "").strip()
            cp_id    = (row.get("Counterparty ID") or "").strip()
            cp_nm    = (row.get("Counterparty legal name") or "").strip()
            date_str = (row.get("Date") or "").strip()
            if txn_type:
                type_counts[txn_type] = type_counts.get(txn_type, 0) + 1
            if acct_id and acct_nm:
                if acct_id not in accounts:
                    accounts[acct_id] = {"ext_id": acct_id, "ext_name": acct_nm,
                                         "ext_type": acct_tp, "count": 0}
                accounts[acct_id]["count"] += 1
            if cp_id and cp_nm:
                if cp_id not in counterparties:
                    counterparties[cp_id] = {"ext_id": cp_id, "ext_name": cp_nm, "count": 0}
                counterparties[cp_id]["count"] += 1
            if date_str:
                dates.append(date_str)
        summary = dict(type_counts)
        if dates:
            summary["date_from"] = min(dates)
            summary["date_to"]   = max(dates)
        return ok({
            "accounts":       sorted(accounts.values(),       key=lambda x: x["ext_name"]),
            "counterparties": sorted(counterparties.values(), key=lambda x: x["ext_name"]),
            "summary":        summary,
        })
    except Exception as exc:
        return err(f"Parse error: {str(exc)}")


@app.route("/api/txn-import/confirm", methods=["POST"])
@login_required
def api_txn_import_confirm():
    """Receive CSV + mapping config, create balanced journal entries."""
    if "file" not in request.files:
        return err("No file uploaded")
    f = request.files["file"]
    try:
        config = json.loads(request.form.get("config", "{}"))
    except Exception:
        return err("Invalid config JSON")

    account_map = {str(k): int(v) for k, v in config.get("account_map", {}).items() if v}
    balancing   = {k: int(v) for k, v in config.get("balancing", {}).items() if v}
    contact_map = {}
    for k, v in config.get("contact_map", {}).items():
        try:
            iv = int(v)
            contact_map[str(k)] = iv if iv > 0 else None
        except Exception:
            contact_map[str(k)] = None
    date_from = config.get("date_from", "")
    date_to   = config.get("date_to", "")

    import csv, io as _io
    try:
        content = f.read().decode("utf-8-sig")
        reader  = csv.DictReader(_io.StringIO(content))
        rows = []
        for row in reader:
            date_str = (row.get("Date") or "").strip()
            if not date_str:
                continue
            if date_from and date_str < date_from:
                continue
            if date_to and date_str > date_to:
                continue
            try:
                amount = float(row.get("Amount") or 0)
            except (ValueError, TypeError):
                amount = 0.0
            try:
                gst = float(row.get("Tax amount") or 0)
            except (ValueError, TypeError):
                gst = 0.0
            rows.append({
                "txn_number":      (row.get("Transaction number") or "").strip(),
                "txn_type":        (row.get("Transaction type") or "").strip(),
                "date":            date_str,
                "ext_account_id":  (row.get("Account ID") or "").strip(),
                "amount":          amount,
                "gst_amount":      gst,
                "ext_contact_id":  (row.get("Counterparty ID") or "").strip(),
                "counterparty_name": (row.get("Counterparty legal name") or "").strip(),
                "line_comment":    (row.get("Line comment") or "").strip(),
                "doc_number":      (row.get("Document number") or "").strip(),
                "tax_code":        (row.get("Tax code") or "").strip(),
            })
        result = import_transactions(db(), rows, account_map, balancing, contact_map)
        return ok(result)
    except Exception as exc:
        return err(str(exc))


# ── Settings: AR/AP Reconciliation Wizard ─────────────────────────────────────

@app.route("/api/arap-balances")
@login_required
def api_arap_balances():
    conn = get_connection(db())
    ar_gl = conn.execute("""
        SELECT COALESCE(SUM(jl.debit-jl.credit),0) as b
        FROM journal_lines jl JOIN accounts a ON a.id=jl.account_id
        WHERE a.code='1-1200'""").fetchone()["b"]
    ar_ob = conn.execute("""
        SELECT COALESCE(SUM(total-amount_paid),0) as b
        FROM invoices WHERE invoice_number LIKE 'OB-AR-%'
        AND status NOT IN ('Paid','Void')""").fetchone()["b"]
    ap_gl = conn.execute("""
        SELECT COALESCE(SUM(jl.credit-jl.debit),0) as b
        FROM journal_lines jl JOIN accounts a ON a.id=jl.account_id
        WHERE a.code='2-1100'""").fetchone()["b"]
    ap_ob = conn.execute("""
        SELECT COALESCE(SUM(total-amount_paid),0) as b
        FROM bills WHERE bill_number LIKE 'OB-AP-%'
        AND status NOT IN ('Paid','Void')""").fetchone()["b"]
    ob = conn.execute(
        "SELECT entry_date FROM journal_entries "
        "WHERE reference LIKE 'OB-%' ORDER BY id LIMIT 1").fetchone()
    conn.close()
    return ok({
        "ar": {"gl":         round(ar_gl - ar_ob, 2),
               "reconciled": round(ar_ob, 2),
               "remaining":  max(0.0, round(ar_gl - 2*ar_ob, 2))},
        "ap": {"gl":         round(ap_gl - ap_ob, 2),
               "reconciled": round(ap_ob, 2),
               "remaining":  max(0.0, round(ap_gl - 2*ap_ob, 2))},
        "ob_date": ob["entry_date"] if ob else "",
    })


@app.route("/api/arap-reconcile", methods=["POST"])
@login_required
def api_arap_reconcile():
    import datetime as _dt
    data     = request.get_json() or {}
    date_str = (data.get("date") or "").strip()
    ar_rows  = data.get("ar_rows") or []   # [{name, amount}]
    ap_rows  = data.get("ap_rows") or []
    try:
        _dt.date.fromisoformat(date_str)
    except ValueError:
        return err("Invalid date — use YYYY-MM-DD")

    conn     = get_connection(db())
    inc_acc  = conn.execute(
        "SELECT id FROM accounts WHERE code='4-1200'").fetchone()
    exp_acc  = conn.execute(
        "SELECT id FROM accounts WHERE account_type='Expense' "
        "AND code NOT LIKE '5-9%' ORDER BY code LIMIT 1").fetchone()
    ar_exist = conn.execute(
        "SELECT COUNT(*) as n FROM invoices "
        "WHERE invoice_number LIKE 'OB-AR-%'").fetchone()["n"]
    ap_exist = conn.execute(
        "SELECT COUNT(*) as n FROM bills "
        "WHERE bill_number LIKE 'OB-AP-%'").fetchone()["n"]
    conn.close()

    if not inc_acc or not exp_acc:
        return err("Required GL accounts (Sales, Expense) not found")

    def _contact(name, ctype):
        c = get_connection(db())
        row = c.execute("SELECT id FROM contacts WHERE name=? LIMIT 1",
                        (name,)).fetchone()
        if row: c.close(); return row["id"]
        c.execute("INSERT INTO contacts (name,contact_type,is_active) VALUES (?,?,1)",
                  (name, ctype))
        c.commit()
        cid = c.execute("SELECT id FROM contacts WHERE name=? "
                        "ORDER BY id DESC LIMIT 1", (name,)).fetchone()["id"]
        c.close(); return cid

    errors = []; ar_total = ap_total = 0.0
    for i, row in enumerate(ar_rows, ar_exist + 1):
        try:
            amt  = float(row.get("amount") or 0)
            name = (row.get("name") or "Opening Balance Entries").strip() \
                   or "Opening Balance Entries"
            if amt < 0.001: continue
            cid = _contact(name, "Customer")
            save_invoice(db(),
                {"id": None, "contact_id": cid,
                 "invoice_number": f"OB-AR-{i:03d}",
                 "invoice_date": date_str, "due_date": date_str, "status": "Approved"},
                [{"description": f"Opening accounts receivable — {name}",
                  "quantity": 1, "unit_price": amt, "tax_code": "N-T",
                  "account_id": inc_acc["id"]}],
                skip_gl=True)
            ar_total += amt
        except Exception as exc:
            errors.append(f"AR {row.get('name','?')}: {exc}")

    for i, row in enumerate(ap_rows, ap_exist + 1):
        try:
            amt  = float(row.get("amount") or 0)
            name = (row.get("name") or "Opening Balance Entries").strip() \
                   or "Opening Balance Entries"
            if amt < 0.001: continue
            cid = _contact(name, "Supplier")
            save_bill(db(),
                {"id": None, "contact_id": cid,
                 "bill_number": f"OB-AP-{i:03d}",
                 "bill_date": date_str, "due_date": date_str, "status": "Approved"},
                [{"description": f"Opening accounts payable — {name}",
                  "quantity": 1, "unit_price": amt, "tax_code": "N-T",
                  "account_id": exp_acc["id"]}],
                skip_gl=True)
            ap_total += amt
        except Exception as exc:
            errors.append(f"AP {row.get('name','?')}: {exc}")

    return ok({"ar_total": ar_total, "ap_total": ap_total, "errors": errors})


# ── Backup ────────────────────────────────────────────────────────────────────

_PREFS_PATH = os.path.join(os.path.expanduser("~"), "dbox_prefs.json")

def _load_prefs():
    try:
        if os.path.exists(_PREFS_PATH):
            with open(_PREFS_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}

def _save_prefs(data):
    with open(_PREFS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def _default_backup_dir():
    docs = os.path.join(os.path.expanduser("~"), "Documents")
    base = docs if os.path.isdir(docs) else os.path.expanduser("~")
    return os.path.join(base, "Dogbox Backups")

@app.route("/api/backup/status")
@login_required
def api_backup_status():
    import glob as _glob, datetime as _dt
    db_path = db()
    p = _load_prefs()
    auto_on = p.get("auto_backup_enabled", False)
    bdir    = p.get("auto_backup_dir", "").strip()

    if not bdir or not os.path.isdir(bdir):
        return ok({"warn": True, "reason": "never", "last": None, "auto": auto_on})

    name    = os.path.splitext(os.path.basename(db_path or "company"))[0]
    files   = sorted(_glob.glob(os.path.join(bdir, f"{name}_*.abk")), reverse=True)
    if not files:
        return ok({"warn": True, "reason": "never", "last": None, "auto": auto_on})

    try:
        mtime    = os.path.getmtime(files[0])
        age_days = (_dt.datetime.now().timestamp() - mtime) / 86400
        last_str = _dt.datetime.fromtimestamp(mtime).strftime("%d %b %Y")
        warn     = not auto_on and age_days > 7
        return ok({"warn": warn, "reason": "stale" if warn else "ok",
                   "last": last_str, "age_days": int(age_days), "auto": auto_on})
    except Exception:
        return ok({"warn": False})

@app.route("/api/backup/settings")
@login_required
def api_backup_settings_get():
    p = _load_prefs()
    return ok({
        "enabled":        p.get("auto_backup_enabled",  False),
        "directory":      p.get("auto_backup_dir",      ""),
        "interval_hours": p.get("auto_backup_interval", 1),
        "keep_count":     p.get("auto_backup_keep",     10),
        "db_name":        os.path.basename(db() or ""),
        "suggested_dir":  _default_backup_dir(),
    })

@app.route("/api/backup/settings", methods=["POST"])
@login_required
def api_backup_settings_post():
    d = request.get_json(force=True) or {}
    p = _load_prefs()
    p["auto_backup_enabled"]  = bool(d.get("enabled", False))
    p["auto_backup_dir"]      = str(d.get("directory", "")).strip()
    p["auto_backup_interval"] = float(d.get("interval_hours", 1))
    p["auto_backup_keep"]     = int(d.get("keep_count", 10))
    try:
        _save_prefs(p)
    except Exception as e:
        return err(str(e))
    return ok()

@app.route("/api/backup/browse-dir")
@login_required
def api_backup_browse_dir():
    # Run in a subprocess so tkinter gets its own main thread (Flask uses threads)
    import subprocess
    _dialog = (
        "import tkinter as tk, tkinter.filedialog as fd, sys\n"
        "root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True)\n"
        "p = fd.askdirectory(title='Select Backup Folder')\n"
        "root.destroy()\n"
        "print(p)\n"
    )
    try:
        r = subprocess.run(
            [sys.executable, "-c", _dialog],
            capture_output=True, text=True, timeout=120,
        )
        chosen = r.stdout.strip()
        if not chosen:
            return ok({"path": None})
        return ok({"path": os.path.normpath(chosen)})
    except Exception as e:
        return err(str(e))

@app.route("/api/backup/now", methods=["POST"])
@login_required
def api_backup_now():
    import shutil, datetime, glob
    db_path = db()
    if not db_path or not os.path.exists(db_path):
        return err("No company file open")
    p    = _load_prefs()
    body = request.get_json(silent=True) or {}
    bdir = (body.get("directory") or p.get("auto_backup_dir", "")).strip()
    if not bdir:
        return err("Backup directory not configured — set it in Auto-Backup Settings first")
    os.makedirs(bdir, exist_ok=True)
    if not os.path.isdir(bdir):
        return err(f"Could not create backup directory: {bdir}")
    ts   = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    name = os.path.splitext(os.path.basename(db_path))[0]
    dest = os.path.join(bdir, f"{name}_backup_{ts}.abk")
    try:
        shutil.copy2(db_path, dest)
    except Exception as e:
        return err(str(e))
    keep     = max(1, int(p.get("auto_backup_keep", 10)))
    pattern  = os.path.join(bdir, f"{name}_backup_*.abk")
    existing = sorted(glob.glob(pattern))
    while len(existing) > keep:
        try:
            os.remove(existing.pop(0))
        except Exception:
            break
    return ok({"filename": os.path.basename(dest)})

@app.route("/api/backup/list")
@login_required
def api_backup_list():
    import glob, datetime
    db_path = db()
    p    = _load_prefs()
    bdir = p.get("auto_backup_dir", "").strip()
    if not bdir or not os.path.isdir(bdir):
        return ok([])
    name    = os.path.splitext(os.path.basename(db_path or "company"))[0]
    pattern = os.path.join(bdir, f"{name}_*.abk")
    files   = sorted(glob.glob(pattern), reverse=True)
    result  = []
    for f in files[:50]:
        try:
            stat = os.stat(f)
            result.append({
                "filename": os.path.basename(f),
                "size":     stat.st_size,
                "modified": datetime.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
            })
        except Exception:
            pass
    return ok(result)

@app.route("/api/backup/download")
@login_required
def api_backup_download():
    import datetime
    db_path = db()
    if not db_path or not os.path.exists(db_path):
        return err("No company file open")
    ts      = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    name    = os.path.splitext(os.path.basename(db_path))[0]
    dl_name = f"{name}_backup_{ts}.abk"
    return send_file(db_path, as_attachment=True, download_name=dl_name)

@app.route("/api/backup/pick-file")
@login_required
def api_backup_pick_file():
    import subprocess
    p    = _load_prefs()
    bdir = p.get("auto_backup_dir", "").strip() or _default_backup_dir()
    _dialog = (
        "import tkinter as tk, tkinter.filedialog as fd, sys\n"
        f"idir = {repr(bdir)}\n"
        "root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True)\n"
        "p = fd.askopenfilename(\n"
        "    title='Select Backup to Restore',\n"
        "    initialdir=idir,\n"
        "    filetypes=[('dbox Backup','*.abk'),('dbox File','*.dbox'),('All files','*.*')],\n"
        ")\n"
        "root.destroy()\n"
        "print(p)\n"
    )
    try:
        r = subprocess.run(
            [sys.executable, "-c", _dialog],
            capture_output=True, text=True, timeout=120,
        )
        chosen = r.stdout.strip()
        if not chosen:
            return ok({"path": None})
        return ok({"path": os.path.normpath(chosen)})
    except Exception as e:
        return err(str(e))

@app.route("/api/backup/restore", methods=["POST"])
@login_required
def api_backup_restore():
    import shutil
    d       = request.get_json(force=True) or {}
    src     = d.get("path", "").strip()
    db_path = db()
    if not src:
        return err("No backup file specified")
    if not os.path.exists(src):
        return err(f"File not found: {src}")
    if not db_path:
        return err("No company file open")
    try:
        shutil.copy2(src, db_path)
    except Exception as e:
        return err(str(e))
    return ok()


# ── General settings ──────────────────────────────────────────────────────────
@app.route("/api/general/settings")
@login_required
def api_general_settings_get():
    p = _load_prefs()
    docs = os.path.join(os.path.expanduser("~"), "Documents")
    suggested = docs if os.path.isdir(docs) else os.path.expanduser("~")
    return ok({
        "default_file_dir": p.get("default_file_dir", ""),
        "suggested_dir":    suggested,
    })

@app.route("/api/general/settings", methods=["POST"])
@login_required
def api_general_settings_post():
    d = request.get_json(force=True) or {}
    p = _load_prefs()
    p["default_file_dir"] = str(d.get("default_file_dir", "")).strip()
    try:
        _save_prefs(p)
    except Exception as e:
        return err(str(e))
    return ok()

@app.route("/api/general/browse-dir")
@login_required
def api_general_browse_dir():
    import subprocess
    p    = _load_prefs()
    idir = p.get("default_file_dir", "").strip()
    if not idir or not os.path.isdir(idir):
        docs = os.path.join(os.path.expanduser("~"), "Documents")
        idir = docs if os.path.isdir(docs) else os.path.expanduser("~")
    _dialog = (
        "import tkinter as tk, tkinter.filedialog as fd\n"
        f"idir = {repr(idir)}\n"
        "root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True)\n"
        "p = fd.askdirectory(title='Select Default File Folder', initialdir=idir)\n"
        "root.destroy()\n"
        "print(p)\n"
    )
    try:
        r = subprocess.run(
            [sys.executable, "-c", _dialog],
            capture_output=True, text=True, timeout=120,
        )
        chosen = r.stdout.strip()
        if not chosen:
            return ok({"path": None})
        return ok({"path": os.path.normpath(chosen)})
    except Exception as e:
        return err(str(e))


# ── System / update routes ────────────────────────────────────────────────────
@app.route('/api/system/version')
@login_required
def api_system_version():
    now = _time.time()
    if not _update_cache or now - _update_cache.get('checked_at', 0) > 86400:
        try:
            with urllib.request.urlopen(_UPDATE_URL, timeout=5) as r:
                data = json.loads(r.read())
            _update_cache.update({**data, 'checked_at': now})
        except Exception:
            _update_cache['checked_at'] = now   # back off for 24 h on failure
    latest  = _update_cache.get('version')
    current = tuple(int(x) for x in APP_VERSION.split('.') if x.isdigit())
    newest  = tuple(int(x) for x in latest.split('.') if x.isdigit()) if latest else ()
    return ok({
        'current':          APP_VERSION,
        'latest':           latest,
        'update_available': newest > current,
        'notes':            _update_cache.get('notes', ''),
        'download_url':     _update_cache.get('url', ''),
    })

@app.route('/api/system/apply-update', methods=['POST'])
@login_required
def api_system_apply_update():
    url = (request.json or {}).get('url', '')
    if not url:
        return err('No download URL')
    _update_prog.update({'state': 'downloading', 'pct': 0, 'error': None})
    _threading.Thread(target=_do_update, args=(url,), daemon=True).start()
    return ok({'started': True})

@app.route('/api/system/update-progress')
@login_required
def api_system_update_progress():
    return ok(_update_prog)

def _do_update(url):
    install_dir = os.path.normpath(
        os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
    )
    SKIP = {'backups', '.git', '__pycache__'}
    try:
        with tempfile.TemporaryDirectory() as tmp:
            zip_path = os.path.join(tmp, 'update.zip')

            def _progress(count, block, total):
                if total > 0:
                    _update_prog['pct'] = min(int(count * block * 100 / total), 95)

            urllib.request.urlretrieve(url, zip_path, _progress)
            _update_prog.update({'state': 'applying', 'pct': 96})

            extract_dir = os.path.join(tmp, 'x')
            with zipfile.ZipFile(zip_path) as zf:
                names = zf.namelist()
                # Strip single top-level dir if present (GitHub zip convention)
                tops = {n.split('/')[0] for n in names}
                prefix = (tops.pop() + '/') if len(tops) == 1 else ''
                for m in zf.infolist():
                    rel = m.filename[len(prefix):] if prefix else m.filename
                    if not rel or any(part in SKIP for part in rel.split('/')):
                        continue
                    m.filename = rel
                    zf.extract(m, extract_dir)

            for root, dirs, files in os.walk(extract_dir):
                dirs[:] = [d for d in dirs if d not in SKIP]
                rel_root = os.path.relpath(root, extract_dir)
                for f in files:
                    if f.endswith('.dbox'):
                        continue
                    src = os.path.join(root, f)
                    dst = os.path.join(install_dir, rel_root, f)
                    os.makedirs(os.path.dirname(dst), exist_ok=True)
                    shutil.copy2(src, dst)

        _update_prog.update({'state': 'done', 'pct': 100})
    except Exception as e:
        _update_prog.update({'state': 'error', 'error': str(e)})


# ── Main ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="dogbox Web Interface")
    parser.add_argument("db_file", nargs="?", default=None,
                        help="Path to .dbox file (optional — shows file picker if omitted)")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--host", default="127.0.0.1")
    args = parser.parse_args()

    # If no file was passed on the command line, show the picker
    if args.db_file:
        DB_PATH = os.path.abspath(args.db_file)
    else:
        DB_PATH = _pick_db_file()

    print(f"\n  dogbox Web Interface")
    print(f"  {'─' * 37}")
    print(f"  Database : {DB_PATH}")

    initialise_database(DB_PATH)
    seed_defaults(DB_PATH)
    ensure_default_admin(DB_PATH)
    # Schema migrations (safe to re-run on existing DBs)
    from core.database import get_connection as _gc_startup
    _conn = _gc_startup(DB_PATH)
    migrate_purchase_orders(_conn)
    _conn.commit()
    _conn.close()
    _conn2 = _gc_startup(DB_PATH)
    _migrate_fixed_assets(_conn2)
    _conn2.close()

    # Derive a stable secret key from the DB path
    app.secret_key = _derive_secret_key(DB_PATH)

    url = f"http://{args.host}:{args.port}"
    print(f"  Login    : admin / admin  (change after first login)")
    print(f"  Open     : {url}\n")

    # Open the browser automatically after a short delay
    import threading, webbrowser
    def _open_browser():
        import time; time.sleep(1.2)
        webbrowser.open(url)
    threading.Thread(target=_open_browser, daemon=True).start()

    app.run(host=args.host, port=args.port, debug=False)
