"""
Shared utilities for Flask blueprints.
Import ok, err, login_required, tier_required, db, dict_rows from here.
"""
import os
import json
from functools import wraps
from flask import current_app, session, redirect, jsonify

from core.database import get_connection
from core.licence import (get_licence_status, watermark_text,
                          validate_online, VALIDATION_URL)

TIER_CAPS = {
    "cashbook": {
        "dashboard", "contacts", "accounts", "journal",
        "payments", "bankrec", "reports", "users",
    },
    "invoices": {
        "dashboard", "contacts", "accounts", "journal",
        "payments", "bankrec", "reports", "users",
        "invoices", "quotes", "bills", "recurring",
        "aged", "budget",
    },
    "payroll": {
        "dashboard", "contacts", "accounts", "journal",
        "payments", "bankrec", "reports", "users",
        "invoices", "quotes", "bills", "recurring",
        "aged", "budget",
        "payroll",
    },
    "full": {
        "dashboard", "contacts", "accounts", "journal",
        "payments", "bankrec", "reports", "users",
        "invoices", "quotes", "bills", "recurring",
        "aged", "budget",
        "payroll",
        "crm", "jobs", "items", "inventory", "promotions",
        "sales_catalogue", "fixed_assets",
        "warranties", "purchase_orders", "credit_cards",
    },
}

TIER_LABELS = {
    "cashbook": "Cashbook",
    "invoices": "Invoices & Bills",
    "payroll":  "Payroll",
    "full":     "Full",
}

_PREFS_PATH = os.path.join(os.path.expanduser("~"), "dbox_prefs.json")


def _load_prefs() -> dict:
    try:
        if os.path.exists(_PREFS_PATH):
            with open(_PREFS_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _save_prefs(data: dict):
    with open(_PREFS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def _get_tier(db_path: str) -> str:
    """Read tier from company table; falls back to 'full' on any error."""
    if not db_path:
        return "full"
    try:
        conn = get_connection(db_path)
        row  = conn.execute("SELECT tier FROM company LIMIT 1").fetchone()
        conn.close()
        if row and row["tier"] in TIER_CAPS:
            return row["tier"]
    except Exception:
        pass
    return "full"


def _get_licence_status() -> dict:
    """Return the full licence status dict with phone-home revocation check."""
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
    except Exception:
        return {"status": "missing", "tier": None, "features": [],
                "is_eval": False, "is_permanent": False, "days_remaining": None,
                "issued_to": None, "eval_expiry": None, "path": None,
                "revoked": False}

    lic_id = status.get("licence_id")
    if lic_id and status.get("status") == "valid":
        revoked, _, lic_content = validate_online(lic_id, VALIDATION_URL)
        if revoked:
            status["status"]  = "revoked"
            status["revoked"] = True
        elif lic_content:
            try:
                lic_path = status.get("path") or os.path.join(_app_dir, "dbox.lic")
                with open(lic_path, "w", encoding="utf-8") as fh:
                    fh.write(lic_content)
                status = get_licence_status(_app_dir)
            except Exception:
                pass

    return status


def _get_pdf_watermark() -> "str | None":
    """Return a watermark string for PDFs if licence is invalid, else None."""
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
        return watermark_text(status)
    except Exception:
        return "Unregistered"


def db():
    """Return the current DB path — session-scoped in demo mode, global otherwise."""
    if current_app.config.get('DEMO_MODE'):
        return session.get('demo_db')
    return current_app.config.get('DB_PATH')


def dict_rows(rows):
    return [dict(r) for r in rows]


def ok(data=None, **kwargs):
    return jsonify({"ok": True, "data": data, **kwargs})


def err(msg, code=400):
    return jsonify({"ok": False, "error": msg}), code


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("user"):
            return redirect("/login")
        return f(*args, **kwargs)
    return decorated


def current_user():
    return session.get("user", {})


def tier_required(*modules):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            user = current_user()
            caps = set(user.get("tier_caps") or TIER_CAPS.get(user.get("tier", "full"), set()))
            missing = [m for m in modules if m not in caps]
            if missing:
                return err(
                    f"Your licence tier ({user.get('tier_label','Unknown')}) "
                    f"does not include: {', '.join(missing)}",
                    403,
                )
            return f(*args, **kwargs)
        return decorated
    return decorator
