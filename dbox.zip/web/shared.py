"""
Shared utilities for Flask blueprints.
Import ok, err, login_required, tier_required, role_required, db, dict_rows from here.
"""
import os
import json
from functools import wraps
from flask import current_app, session, redirect, jsonify

from core.database import get_connection
import time as _time
from core.licence import (get_licence_status, watermark_text, pdf_footer_text,
                          validate_online, VALIDATION_URL, CHECK_UPDATE_URL,
                          check_for_update, pdf_branding_footer)

# Free tier — basic accounting and compliance essentials
_FREE_CAPS = frozenset({
    "dashboard", "contacts", "accounts", "journal",
    "payments", "bankrec", "reports", "users",
    "invoices", "bills", "aged", "credit_cards",
})

# Paid tier — full access to all modules
_PAID_CAPS = _FREE_CAPS | frozenset({
    "email_docs", "lan",
    "quotes", "jobs", "crm", "purchase_orders", "fixed_assets", "warranties",
    "pos", "inventory", "promotions", "table_service",
    "budget", "recurring", "expense_claims", "items", "sales_catalogue",
    "petty_cash",
})

TIER_CAPS = {
    "free":        _FREE_CAPS,
    "paid":        _PAID_CAPS,
    # Legacy tier aliases — map to nearest equivalent
    "core":        _FREE_CAPS,
    "full":        _PAID_CAPS,
    "trades":      _PAID_CAPS,
    "retail":      _PAID_CAPS,
    "hospitality": _PAID_CAPS,
}

TIER_LABELS = {
    "free":        "Free",
    "paid":        "Paid",
    # Legacy aliases
    "core":        "Free",
    "full":        "Paid",
    "trades":      "Paid",
    "retail":      "Paid",
    "hospitality": "Paid",
}

_PREFS_PATH = os.path.join(os.path.expanduser("~"), "dbox_prefs.json")


def _load_prefs() -> dict:
    try:
        if os.path.exists(_PREFS_PATH):
            with open(_PREFS_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _save_prefs(data: dict):
    with open(_PREFS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def _get_tier(db_path: str) -> str:
    """Return the effective tier name for the current licence.

    During FREE_UNTIL everyone gets 'full' (all packs).
    After that, the licence tier field maps to a pack name:
      trades / retail / hospitality → as-is
      full / pro / invoices / payroll / cashbook → 'full' (legacy Pro)
      anything else → 'core'
    """
    from datetime import date as _date
    from core.licence import FREE_UNTIL as _FREE_UNTIL
    if _date.today() <= _FREE_UNTIL:
        return "paid"
    lic = _get_licence_status()
    if lic.get("status") != "valid":
        return "free"
    lic_tier = (lic.get("tier") or "free").lower()
    if lic_tier in ("paid", "full", "pro", "trades", "retail", "hospitality",
                    "invoices", "payroll", "cashbook"):
        return "paid"
    return "free"


def _get_licence_status() -> dict:
    """Return the full licence status dict with phone-home revocation check."""
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
    except Exception:
        return {"status": "missing", "tier": None, "features": [],
                "is_eval": False, "is_permanent": False, "days_remaining": None,
                "issued_to": None, "eval_expiry": None, "path": None,
                "revoked": False}

    lic_id = status.get("licence_id")
    if lic_id and status.get("status") == "valid":
        revoked, _, lic_content = validate_online(lic_id, VALIDATION_URL)
        if revoked:
            status["status"]  = "revoked"
            status["revoked"] = True
        elif lic_content:
            try:
                lic_path = status.get("path") or os.path.join(_app_dir, "dbox.lic")
                with open(lic_path, "w", encoding="utf-8") as fh:
                    fh.write(lic_content)
                status = get_licence_status(_app_dir)
            except Exception:
                pass

    return status


def _get_pdf_watermark() -> "str | None":
    """Return a watermark string for PDFs if licence is invalid, else None."""
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
        return watermark_text(status)
    except Exception:
        return "Unregistered"


def _get_pdf_footer() -> "str | None":
    """Return a footer string for PDFs when maintenance has lapsed, else None."""
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
        return pdf_footer_text(status)
    except Exception:
        return None


def _get_pdf_branding(db_path: str) -> "str | None":
    """Return branding footer text if enabled in company settings, else None."""
    try:
        if db_path:
            conn = get_connection(db_path)
            row = conn.execute("SELECT pdf_branding FROM company WHERE id=1").fetchone()
            conn.close()
            if row is not None and int(row["pdf_branding"] if row["pdf_branding"] is not None else 1) == 0:
                return None
    except Exception:
        pass
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
        return pdf_branding_footer(status)
    except Exception:
        return None


def _get_combined_pdf_footer(db_path: str) -> "str | None":
    """Return maintenance-lapse footer (priority) or branding footer."""
    return _get_pdf_footer() or _get_pdf_branding(db_path)


# ── Inactivity lock state (shared so login_required can check without circular import) ──
import threading as _threading
_app_state: dict = {"locked": False}
_app_state_lock = _threading.Lock()

# ── Update check cache ────────────────────────────────────────────────────────
_update_cache: dict = {"ts": 0.0, "data": None}
_UPDATE_CACHE_TTL = 3600  # 1 hour


def _get_update_info(app_version: str = "") -> dict | None:
    """
    Non-blocking check for a newer dbox version. Result is cached for 1 hour.
    Returns None if offline or no licence_id available.
    """
    global _update_cache
    now = _time.time()
    if _update_cache["data"] is not None and now - _update_cache["ts"] < _UPDATE_CACHE_TTL:
        return _update_cache["data"]
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
        lic_id = status.get("licence_id") or ""
        if not lic_id:
            return None
        result = check_for_update(lic_id, app_version)
        _update_cache = {"ts": now, "data": result}
        return result
    except Exception:
        return None


def db():
    """Return the current DB path — session-scoped in demo mode, global otherwise."""
    if current_app.config.get('DEMO_MODE'):
        return session.get('demo_db')
    return current_app.config.get('DB_PATH')


def dict_rows(rows):
    return [dict(r) for r in rows]


def ok(data=None, **kwargs):
    return jsonify({"ok": True, "data": data, **kwargs})


def err(msg, code=400):
    return jsonify({"ok": False, "error": msg}), code


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        with _app_state_lock:
            locked = _app_state["locked"]
        if locked:
            session.clear()
            return jsonify({"ok": False, "error": "locked"}), 401
        if not session.get("user"):
            return redirect("/login")
        return f(*args, **kwargs)
    return decorated


def current_user():
    return session.get("user", {})


def role_required(*modules):
    """Restrict route to roles whose ROLE_MODULES set includes all specified modules."""
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            from core.auth import ROLE_MODULES
            user = current_user()
            role = user.get("role", "")
            allowed = ROLE_MODULES.get(role)
            if allowed is None:  # Admin / Staff — unrestricted
                return f(*args, **kwargs)
            missing = [m for m in modules if m not in allowed]
            if missing:
                return err(
                    f"Your role ({role}) does not have access to: {', '.join(missing)}",
                    403,
                )
            return f(*args, **kwargs)
        return decorated
    return decorator


def tier_required(*modules):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            user = current_user()
            caps = set(user.get("tier_caps") or TIER_CAPS.get(user.get("tier", "full"), set()))
            missing = [m for m in modules if m not in caps]
            if missing:
                return err(
                    f"Your licence tier ({user.get('tier_label','Unknown')}) "
                    f"does not include: {', '.join(missing)}",
                    403,
                )
            return f(*args, **kwargs)
        return decorated
    return decorator
