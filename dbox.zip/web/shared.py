"""
Shared utilities for Flask blueprints.
Import ok, err, login_required, tier_required, db, dict_rows from here.
"""
import os
import json
from functools import wraps
from flask import current_app, session, redirect, jsonify

from core.database import get_connection
import time as _time
from core.licence import (get_licence_status, watermark_text, pdf_footer_text,
                          validate_online, VALIDATION_URL, CHECK_UPDATE_URL,
                          check_for_update)

TIER_CAPS = {
    "free": {
        "dashboard", "contacts", "accounts", "journal",
        "payments", "bankrec", "reports", "users",
        "invoices", "quotes", "bills",
        "expense_claims", "credit_cards", "items", "aged",
    },
    "full": {
        "dashboard", "contacts", "accounts", "journal",
        "payments", "bankrec", "reports", "users",
        "invoices", "quotes", "bills", "recurring",
        "aged", "budget", "email_docs",
        "payroll",
        "crm", "jobs", "items", "inventory", "promotions",
        "sales_catalogue", "fixed_assets",
        "warranties", "purchase_orders", "credit_cards",
        "expense_claims",
    },
}

TIER_LABELS = {
    "free": "Free",
    "full": "Pro",
}

_PREFS_PATH = os.path.join(os.path.expanduser("~"), "dbox_prefs.json")


def _load_prefs() -> dict:
    try:
        if os.path.exists(_PREFS_PATH):
            with open(_PREFS_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _save_prefs(data: dict):
    with open(_PREFS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def _get_tier(db_path: str) -> str:
    """Effective tier from licence status; FREE_UNTIL grants Pro access to all."""
    from datetime import date as _date
    from core.licence import FREE_UNTIL as _FREE_UNTIL
    if _date.today() <= _FREE_UNTIL:
        return "full"
    lic = _get_licence_status()
    if lic.get("status") != "valid":
        return "free"
    # All paid licence tiers (including legacy cashbook/invoices/payroll) map to Pro.
    lic_tier = (lic.get("tier") or "free").lower()
    if lic_tier in ("full", "pro", "invoices", "payroll", "cashbook"):
        return "full"
    return "free"


def _get_licence_status() -> dict:
    """Return the full licence status dict with phone-home revocation check."""
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
    except Exception:
        return {"status": "missing", "tier": None, "features": [],
                "is_eval": False, "is_permanent": False, "days_remaining": None,
                "issued_to": None, "eval_expiry": None, "path": None,
                "revoked": False}

    lic_id = status.get("licence_id")
    if lic_id and status.get("status") == "valid":
        revoked, _, lic_content = validate_online(lic_id, VALIDATION_URL)
        if revoked:
            status["status"]  = "revoked"
            status["revoked"] = True
        elif lic_content:
            try:
                lic_path = status.get("path") or os.path.join(_app_dir, "dbox.lic")
                with open(lic_path, "w", encoding="utf-8") as fh:
                    fh.write(lic_content)
                status = get_licence_status(_app_dir)
            except Exception:
                pass

    return status


def _get_pdf_watermark() -> "str | None":
    """Return a watermark string for PDFs if licence is invalid, else None."""
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
        return watermark_text(status)
    except Exception:
        return "Unregistered"


def _get_pdf_footer() -> "str | None":
    """Return a footer string for PDFs when maintenance has lapsed, else None."""
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
        return pdf_footer_text(status)
    except Exception:
        return None


# ── Inactivity lock state (shared so login_required can check without circular import) ──
_app_state: dict = {"locked": False}

# ── Update check cache ────────────────────────────────────────────────────────
_update_cache: dict = {"ts": 0.0, "data": None}
_UPDATE_CACHE_TTL = 3600  # 1 hour


def _get_update_info(app_version: str = "") -> dict | None:
    """
    Non-blocking check for a newer dbox version. Result is cached for 1 hour.
    Returns None if offline or no licence_id available.
    """
    global _update_cache
    now = _time.time()
    if _update_cache["data"] is not None and now - _update_cache["ts"] < _UPDATE_CACHE_TTL:
        return _update_cache["data"]
    try:
        _app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        status = get_licence_status(_app_dir)
        lic_id = status.get("licence_id") or ""
        if not lic_id:
            return None
        result = check_for_update(lic_id, app_version)
        _update_cache = {"ts": now, "data": result}
        return result
    except Exception:
        return None


def db():
    """Return the current DB path — session-scoped in demo mode, global otherwise."""
    if current_app.config.get('DEMO_MODE'):
        return session.get('demo_db')
    return current_app.config.get('DB_PATH')


def dict_rows(rows):
    return [dict(r) for r in rows]


def ok(data=None, **kwargs):
    return jsonify({"ok": True, "data": data, **kwargs})


def err(msg, code=400):
    return jsonify({"ok": False, "error": msg}), code


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if _app_state["locked"]:
            session.clear()
            return jsonify({"ok": False, "error": "locked"}), 401
        if not session.get("user"):
            return redirect("/login")
        return f(*args, **kwargs)
    return decorated


def current_user():
    return session.get("user", {})


def tier_required(*modules):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            user = current_user()
            caps = set(user.get("tier_caps") or TIER_CAPS.get(user.get("tier", "full"), set()))
            missing = [m for m in modules if m not in caps]
            if missing:
                return err(
                    f"Your licence tier ({user.get('tier_label','Unknown')}) "
                    f"does not include: {', '.join(missing)}",
                    403,
                )
            return f(*args, **kwargs)
        return decorated
    return decorator
