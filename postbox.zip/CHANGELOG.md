# Changelog

## Unreleased

- **dbox integration: unread badge** — dbox sidebar now shows a red unread-count badge sourced from `GET /api/ext/unread_count`; polls on load and every 2 minutes; badge hidden when count is zero or Mailman offline. No postbox code changed — work was entirely on the dbox side. (dbox: `web/templates/dashboard.html`, `web/routes/contacts.py`, `web/static/dbox.css`)

- core/database.py: migration adds `priority INTEGER DEFAULT 0` column to rules table
- core/rules.py: `_sender_matches()` helper supports `@domain.com` patterns for whitelist/blacklist; `apply_rules_to_message()` returns bool (True if any rule/list entry fired); ORDER BY priority DESC, id
- web/routes/rules.py: `priority` field in CREATE/UPDATE; ORDER BY priority DESC; `POST /api/rules/run` applies active rules to inbox messages and returns `{processed, matched}` counts; sender_lists normalises bare domain entries to `@domain.com` on insert
- web/static/js/rules.js: click-to-select row pattern with Edit/Delete in section toolbar; active badge clickable inline to toggle without opening form; Run Now button with result toast; priority + active fields in add/edit form; domain hint in whitelist/blacklist modal; `_rlCreateRuleFromEmail()` updated with priority/active defaults
- web/static/postbox.css: `rl-toolbar`, `rl-hint`, `rl-empty`, `rl-cell-sm`, `rl-rule-row` hover/selected, `rl-badge-active`/`rl-badge-inactive` styles
- web/static/js/rules.js, emails.js: `_rlCreateRuleFromEmail()` — "Create Rule" button in single-message and thread view footers; pre-fills rule form with sender email, account, and auto-generated name

- core/imap_actions.py: all user-triggered IMAP write-back operations (`toggle_starred`, `mark_read`, `mark_unread`, `trash_message`, `bulk_move_messages`, `empty_trash`, `mark_spam`, `mark_not_spam`, `mark_all_read`, `move_message`) now update the local DB first and fire the IMAP write in a background daemon thread — eliminates per-action IMAP round-trip delay; `threading` import hoisted to module level
- web/static/js/rules.js: `_rlCreateRuleFromEmail(accountId, fromAddr, fromName, subject)` — opens rule det-panel pre-filled with sender email, auto-generated name, and account; loads accounts on demand if Filters page not yet visited
- web/static/js/emails.js: "Create Rule" button added to single-message detail footer and thread view footer; pre-fills rule form from message sender

- core/database.py: contacts table — id, name, email, email_alt, phone, company, dbox_contact_id, source, last_emailed, notes, created_at; UNIQUE(email); idx_contacts_email index
- web/routes/contacts.py: CRUD routes (GET/POST /api/contacts, GET/PUT/DELETE /api/contacts/<id>); GET /api/contacts/autocomplete?q= (min 2 chars, limit 10, matches name/email/company); POST /api/contacts/import_dbox — calls dbox GET /api/ext/contacts, upserts with ON CONFLICT, maps contact_person→name and name→company for business contacts
- web/server.py: contacts blueprint registered
- web/static/js/contacts.js: pageContacts() — list with search, Add Contact button, Import from Dogbox button; det-panel add/edit form (name, email, email_alt, phone, company, notes); delete with confirm(); source badges (dbox/auto); _cntImportDbox() calls import route and reloads
- web/static/js/compose.js: _cmpAttachAutocomplete(inputId) — debounced input handler (250ms) fetches /api/contacts/autocomplete; _cmpAcShow() positions fixed dropdown below input; arrow key navigation, Enter to select, Escape to dismiss, mousedown to prevent blur; _cmpAcInsert() appends after last comma for multiple recipients; autocomplete wired to To/CC/BCC on modal open; _cmpClose() dismisses dropdown
- web/static/js/emails.js: _emLoadAll() fixed to respect _emStarredOnly (was missing is:starred from load-all query)
- web/static/postbox.css: .cnt-badge, .cnt-badge-dbox, .cnt-badge-auto, .req; .cmp-ac-dropdown, .cmp-ac-item, .cmp-ac-name, .cmp-ac-company, .cmp-ac-email
- web/templates/dashboard.html: Contacts nav item (👤) in Manage section; contacts.js script tag; navigate() dispatch for contacts key

- web/static/js/emails.js: `_emStarredOnly` state flag; `pageEmailsStarred()` sets `folder=all&q=is:starred`; `_emLoad()` builds effective query from `_emSearch` + `_emStarredOnly`; unstarring a message while in Starred view removes it from the list in all three star toggle sites (row cell, detail footer, thread footer); flag reset to false in `pageEmails()` and `pageEmailsFolder()`
- web/templates/dashboard.html: Starred nav item (★) added to sidebar below All Mail; `navigate()` titles map and dispatch updated for `starred` key

- web/static/js/emails.js: `_emTrash()` refactored — UI removes message immediately; IMAP call deferred 5 s; undo toast with Undo button cancels timer and splices message back at original index; messages already in Trash are permanently expunged immediately (no undo); pending deferred trash committed on folder navigation; `_emUndoToast()` helper added; `_emPendingTrash` module-level state tracks deferred operation
- web/static/js/emails.js: `_emRestore()` — calls `POST /api/emails/<id>/restore`, removes from Trash list, toasts "Restored to Inbox"
- web/static/js/emails.js: detail and thread footers show "Restore to Inbox" button when `folder_role === 'trash'`; Delete button relabelled "Delete Forever" in Trash
- web/static/postbox.css: `.toast-undo` and `.toast-undo-btn` styles for undo toast
- web/routes/emails.py: `POST /api/emails/<id>/restore` — looks up message account, finds Inbox folder, calls `move_message()`
- core/imap_actions.py: `purge_old_trash(db_path, days=30)` — deletes trash messages where `trashed_at` is older than 30 days; DB delete first, then IMAP EXPUNGE grouped by account/folder; skips messages with NULL `trashed_at` (pre-migration)
- core/imap_actions.py: `trash_message()` — sets `trashed_at = datetime('now')` on DB row when moving message to Trash
- core/database.py: migration adds `trashed_at TEXT` column to messages table
- mail.py: background thread at startup calls `purge_old_trash()` and logs count if any purged

- ops: Google OAuth consent screen published to production — Gmail refresh tokens no longer expire after 7 days; re-authenticated both Gmail accounts (Dogbox, David Innes)

- web/static/js/emails.js: `_emSelectedId` and `_emOpenMsg` module state variables; `_emSelectMsg(id)` updates DOM selection class and scrolls row into view; `_emKeyHandler(e)` — j/↓ next message (auto-opens when panel open), k/↑ previous, Enter open selected, r reply, a reply-all, f forward, e trash selected/open, u mark unread, n compose new, / focus search, Escape close panel; handler registered with `addEventListener` on page enter and removed first to prevent duplicates; suppressed when focus is in an input/textarea or a modal is open; panel-open detection via `.det-panel.open` used to auto-clear `_emOpenMsg` and switch j/k to auto-advance mode; `_emOpenMsg` set after single-message load, after thread expanded-message fetch, and on `_emToggleThreadMsg` expand; `_emSetTitleBadge()` fetches `/api/emails/unread_count` and prefixes `document.title` with `(N)` — strips existing badge first; badge updated on inbox load, `_emMarkAllRead`, and after `emOpen` marks read
- web/static/postbox.css: `.em-row.em-selected` — accent-tint background and 2px accent outline for keyboard focus indicator

- core/database.py: `draft_meta TEXT` migration on messages table — stores BCC, reply_msg_id, references as JSON for draft messages
- web/routes/compose.py: `POST /api/drafts` creates a draft message in the account's Drafts folder (created if missing); `PUT /api/drafts/<id>` updates subject/to/cc/body/meta; `DELETE /api/drafts/<id>` removes draft; `api_send()` accepts `draft_id` and deletes it server-side after successful send; `_get_or_create_drafts_folder()` helper finds or creates a local Drafts folder
- web/routes/emails.py: `/api/threads/<thread_id>` extended — adds `cc_addrs`, `has_attachments`, `body_fetched`, `folder_role` (via folders JOIN), `account_email` (via accounts JOIN); required for thread view rendering and footer button wiring
- web/static/js/compose.js: "Save Draft" button in compose footer calls `_cmpSaveDraft()`; `bd._draftId` tracked on modal — first save POSTs, subsequent saves PUT to same id; `_cmpSaveDraft()` posts all compose fields including BCC and reply context; send payload appends `draft_id` so server deletes it on send; `composeFromDraft(msg)` reopens compose pre-populated — handles both plain-string and JSON-array `to_addrs`/`cc_addrs`, restores BCC/reply_msg_id/references from `draft_meta`
- web/static/js/emails.js: `emOpen()` checks `\Draft` flag before opening detail panel — draft rows open compose via `composeFromDraft()` instead; `emOpen()` fetches `/api/threads/<id>` when threadId present and renders thread view for threads with >1 message; `_emRenderThread()` builds collapsible message cards in chronological order, pre-expands the clicked message, lazily fetches its body via `/api/emails/<id>`; `_emRenderThreadBody()` renders meta strip + HTML iframe or plain text + attachment chips per card; `_emRenderThreadFoot()` builds full action footer (Reply, Reply All, Forward, AI Draft, Move, Star, Mark Unread, Spam/Not Spam, Delete) and updates when a different card is expanded; `_emToggleThreadMsg()` expand/collapse with lazy body fetch on first expand, updates footer to reflect newly-expanded message; single-message view preserved as fallback for threads of 1
- web/static/postbox.css: thread view styles — `.th-count`, `.th-list`, `.th-msg`, `.th-hdr`, `.th-avatar`, `.th-hdr-main`, `.th-from`, `.th-snippet`, `.th-date`, `.th-body`, `.th-loading`; unread bold on `.th-msg.unread .th-from`; expanded header tint on `.th-msg.expanded .th-hdr`

- core/database.py: added `rules`, `sender_lists` tables and `receipt_to TEXT`, `receipt_sent INTEGER DEFAULT 0` migrations to messages table
- core/imap_actions.py: `empty_trash()` — IMAP EXPUNGE on trash folder then deletes all trash messages from DB for the account
- core/imap_actions.py: `mark_spam()` / `mark_not_spam()` — IMAP MOVE to/from spam folder with COPY+DELETE fallback; updates DB folder_id
- core/imap_actions.py: `mark_read()` extended — checks `receipt_to` and `receipt_sent=0` after marking; fires background thread `_send_mdn_and_mark()` to send RFC 3798 MDN then sets `receipt_sent=1`
- core/imap_actions.py: `_send_mdn_and_mark()` — sends MDN via `smtp_send.send_mdn()` then marks `receipt_sent=1` in DB; runs in daemon thread to avoid blocking read action
- core/smtp_send.py: `request_receipt` param on `send_message()` — adds `Disposition-Notification-To` header when True; `send_mdn()` function — sends RFC 3798 Message Disposition Notification to the requesting address
- core/email_parser.py: `parse_raw()` now returns `receipt_to` field from `Disposition-Notification-To` or `Return-Receipt-To` header; stored in DB on inbound message insert
- core/imap_sync.py: `_store_envelope()` now returns `int | None` — `lastrowid` when newly inserted, `None` for duplicates; sync Phase 3 collects `new_msg_ids` list and spawns background thread calling `apply_rules_to_message` for each new message
- core/rules.py (NEW): `apply_rules_to_message(message_id, db_path)` — loads message, checks whitelist (bypass) and blacklist (auto-spam), then applies active rules in order; `_matches(rule, msg)` for field/operator/value matching; `_do_action()` dispatches to imap_actions functions; terminal actions (move/trash/spam/delete) break the chain
- web/routes/emails.py: `POST /api/emails/empty_trash` — calls `empty_trash()` for account; `POST /api/emails/<id>/spam` and `<id>/unspam` — calls `mark_spam()` / `mark_not_spam()`; `POST /api/emails/prefetch` — starts background body-fetch thread for a folder, updates `_prefetch_state`; `GET /api/emails/prefetch_status` — returns current prefetch progress dict
- web/routes/rules.py (NEW): `GET/POST /api/rules` — list and create filter rules; `PUT/DELETE /api/rules/<id>` — update and delete; `GET/POST /api/sender_lists` — list and add whitelist/blacklist entries; `DELETE /api/sender_lists/<id>` — remove entry
- web/routes/import_mail.py (NEW): `POST /api/import` — accepts `files[]` upload; detects `.mbox` by filename or `b"From "` prefix and iterates messages; falls back to split on `\nFrom ` if `mailbox.mbox` fails; `.eml` treated as single message; `_import_one()` parses with `parse_raw()`, inserts with time-based synthetic UID, updates `uid=lastrowid` for guaranteed uniqueness; stores body and attachments
- web/routes/compose.py: `request_receipt` read from form/JSON body; passed to `send_message()` as `request_receipt=True/False`
- web/server.py: registered `rules_bp` and `import_bp` blueprints
- web/templates/dashboard.html: added "Filters" nav item; `navigate('filters')` dispatch in `navigate()`; `titles` map includes `filters:'Filters'`; `<script src="/static/js/rules.js">` added
- web/static/js/emails.js: "Empty Trash" button in toolbar (shown only in trash folder); `_emEmptyTrash()` POSTs to `/api/emails/empty_trash`, clears list; Spam button in detail footer (shown when `folder_role` is inbox/sent/etc); Not Spam button (shown when `folder_role === 'spam'`); Star/Unstar button in detail footer; "⇙ Offline" button in toolbar — `_emPrefetch()` POSTs to start prefetch, polls `/prefetch_status` every 3s, toasts progress
- web/static/js/accounts.js: Import button added below account list; `_acctImport()` modal — account picker, folder picker, file input (multiple .eml/.mbox); `_acctImportUpdateFolders()` fetches folder list when account changes; POSTs to `/api/import` with FormData; toasts result count
- web/static/js/compose.js: "Read receipt" checkbox in compose footer; `fd.append('request_receipt', '1')` in `_cmpSend()` when checked
- web/static/js/rules.js (NEW): `pageFilters()` — renders Filter Rules and Sender Lists cards; `_rlRender()` fetches and displays rules table with edit/delete; `_rlOpenRuleForm()` opens det-panel with field/operator/value/action/target-folder inputs; `_rlSaveRule()` POST/PUT; `_rlDeleteRule()` DELETE with confirmation; `_rlAddSender()` / `_rlDeleteSender()` for whitelist/blacklist management
- web/static/postbox.css: `.rl-section`, `.rl-section-hdr`, `.rl-section-title`, `.rl-table` styles for filters page; `.cmp-receipt-label` for read-receipt checkbox in compose

- core/database.py: added `signature TEXT` migration to accounts table
- core/imap_actions.py: `toggle_starred()` — toggles `\\Flagged` IMAP flag on a message, updates DB flags JSON, write-back to IMAP best-effort; returns bool (now starred)
- core/imap_actions.py: `mark_all_read()` — marks a list of message IDs as read in DB, batches IMAP write-back grouped by (account, folder)
- web/routes/accounts.py: `signature` field included in GET `/api/accounts` response; added to updatable fields in PUT `/api/accounts/<id>`
- web/routes/emails.py: `_parse_search_operators()` — tokenises search query into `from:`, `subject:`, `has:attachment`, `is:unread`, `is:starred` filters plus freetext remainder; applied in `api_emails()`
- web/routes/emails.py: `POST /api/emails/<id>/star` — calls `toggle_starred`, returns `{starred: bool}`
- web/routes/emails.py: `POST /api/emails/mark_all_read` — accepts `folder_role`/`folder_id` + optional `account_id`, marks up to 1000 unread messages read
- web/static/js/accounts.js: signature textarea added to account edit panel; value sent in PUT payload
- web/static/js/compose.js: `_cmpPopulateAccounts` stores signature in `data-sig` on each option; for new messages (`_isNew` flag on modal), auto-injects signature below `-- ` separator; account-change listener swaps signature in-place
- web/static/js/emails.js: star column (☆/★) added to list table header and `_emRow`; click calls `_emToggleStar()` with `stopPropagation` so email doesn't open; star cell updated optimistically
- web/static/js/emails.js: `_emToggleStar()` — POSTs to `/star`, updates cell HTML and in-memory `msg.flags`
- web/static/js/emails.js: "✓ All read" button added to toolbar (inbox and specific-folder views); calls `_emMarkAllRead()`
- web/static/js/emails.js: `_emMarkAllRead()` — POSTs to `/api/emails/mark_all_read`, updates `_emMessages` flags in memory, re-renders
- web/static/js/emails.js: `_emAiDraft()` rewritten — replaces `window.prompt()` with a modal textarea; Ctrl+Enter submits; Cancel closes
- web/static/js/emails.js: Star/Unstar button added to detail footer; updates both the footer button and the list-row star cell
- web/static/js/emails.js: inbox auto-refresh — `setInterval` every 2 minutes calls `_emLoad()` (which also triggers triage); timer cleared on folder/page navigation via `_emStopAutoRefresh()`
- web/static/postbox.css: `.em-star-cell`, `.em-star`, `.em-star.starred` styles for star column

- web/static/js/compose.js: Attach button in compose footer opens hidden file input (multiple files); selected files shown as removable chips in bar above footer; _cmpFiles reset on open and close
- web/static/js/compose.js: send switched from JSON to FormData so binary file data is carried correctly
- web/routes/compose.py: accepts multipart/form-data or JSON; reads attached files via request.files.getlist('attachments')
- core/smtp_send.py: attachments param added (list of filename/content_type/bytes tuples); wraps message in multipart/mixed when attachments present, body as multipart/alternative sub-part; MIMEBase + encode_base64 per attachment
- web/static/postbox.css: .cmp-attach-bar, .cmp-att-chip, .cmp-att-remove, .cmp-att-size styles for compose attachment chips

- web/static/js/compose.js: added CC field (always visible) and BCC field (hidden, revealed by "+ BCC" toggle in modal header)
- web/static/js/compose.js: added `composeReplyAll()` — To=original sender, CC=original To+CC recipients minus own account email
- web/static/js/compose.js: modal title now reflects context (New Message / Reply / Reply All / Forward) instead of always "New Message"
- web/static/js/emails.js: Reply All button added to email detail footer
- web/routes/compose.py: `bcc` field passed from request body to `send_message()`
- core/smtp_send.py: `bcc` parameter added; BCC addresses included in SMTP envelope recipients but omitted from message headers per RFC 5321
- web/static/postbox.css: `.cmp-box` widens compose modal to 680px; `.cmp-bcc-btn` style for the BCC toggle

- core/imap_sync.py: fixed DB lock contention — `sync_all_folders_messages` and `sync_inbox` now use three-phase pattern (read DB → close → IMAP fetch → reopen → write); connection was previously held open for the entire IMAP session causing `database is locked` errors under concurrent multi-account sync
- web/static/js/emails.js: fixed Junk folder showing empty — `pageEmails('junk')` was sending `folder=junk` to the API but DB stores role as `spam`; aliased via `_folderAlias` map
- core/imap_sync.py: fixed false attachment badges — `_has_attachments` now skips `ALTERNATIVE` and `RELATED` multipart subtypes (plain+html and inline images); `fetch_body` now corrects `has_attachments` on the message row from actual parsed attachment count
- web/static/js/emails.js, web/static/js/emails.js: AI summary and actions boxes in preview panel now start hidden (`style="display:none"`) and are shown only when AI content arrives; previously rendered as empty placeholder boxes pushing body out of view
- web/static/js/emails.js: preview panel date now shows full date+time (`_emFmtDetailDate`) instead of abbreviated `fmtDate` label ("Yesterday", "12 Jul")
- web/static/js/emails.js: CC field now shown in preview panel meta strip when present
- web/static/js/emails.js: iframe height re-measured 800ms after `onload` to include images that render late
- core/imap_sync.py: fixed thread chaining for 3+ message chains — `_store_envelope` now looks up parent message's `thread_id` so A→B→C all share A's thread_id; previously C got `thread_id=B` fragmenting the conversation
- core/imap_actions.py: `mark_read` now parses flags JSON properly (`json.loads`) instead of substring-matching the raw JSON string
- core/imap_actions.py: `mark_unread` remove list cleaned up — removed dead entries `"\\\\Seen"` and `"Seen"` that never matched after JSON parse
- web/static/js/emails.js: `_emRow` unread check now uses `JSON.parse(msg.flags).includes('\\Seen')` instead of raw string substring match
- core/database.py: added DB indices on `messages(account_id, folder_id)`, `messages(date)`, `messages(thread_id)`, `folders(role)` — previously all folder loads were full table scans

- web/static/js/emails.js: fixed search input losing focus after each keypress — capture focus state before `mc.innerHTML` replacement and restore with cursor at end after render
- web/static/js/emails.js: debounced search input 300ms to avoid firing an API call on every keystroke
- web/static/js/emails.js: fixed `scrollTop` captured but never restored in `_emRender(keepScroll)` — sort and move operations now preserve scroll position
- core/ai_client.py: rule-based triage fallback (`_triage_rules`) — categorises and prioritises messages by regex when no Anthropic API key is configured
- core/imap_actions.py: `bulk_move_messages()` — IMAP batch move for a list of message IDs, grouped by source folder with COPY+DELETE expunge fallback
- web/routes/emails.py: `category=` filter param on `/api/emails`; new `POST /api/emails/bulk_move` route to move all messages of a given category at once
- web/routes/ai.py: removed `AND m.flags NOT LIKE '%Seen%'` from triage query — now triages all untriaged messages, not just unread
- web/static/js/emails.js: category filter pills in inbox toolbar (`_emCategoryPills`, `_emSetCategory`); "Move all N…" bulk move button when a category filter is active
- web/static/js/emails.js: `_emBulkMove()` — searchable folder picker modal to bulk-move all messages in the active category
- web/static/postbox.css: category filter pill styles (`.em-pill-cat`, per-category colour variants)

- **chore: rename launcher `web_server.py` → `mail.py`** — (`mail.py`)
- **docs: add `CLAUDE.md`** — app overview, tech stack, directory layout, web UI conventions, hard rules, session end protocol. (`CLAUDE.md`)
- web/templates/dashboard.html, web/static/js/emails.js: Renamed app to **Dogbox Mailman**; updated title, sidebar wordmark
- mail.py: Changed DB file extension from `.db` to `.pbox`
- mail.py, web/server.py: Updated all description strings to Dogbox Mailman
- web/templates/dashboard.html: Moved power/close button to top-right page header (matching dbox/investments); removed from sidebar footer
- web/static/postbox.css: Power button styled red (`.footer-icon-close`) with red hover, matching sibling apps
- web/templates/dashboard.html: Inbox subfolders now render as a collapsible tree directly under the Inbox nav item (toggle arrow) instead of a separate "Inbox Folders" section below
- web/templates/dashboard.html: Switched role-based sidebar items back to `navigate(role)` so active state highlights correctly; fixed `_refreshPage()` to handle folder-id keys (`f_X`) by calling `navigateFolder` instead of `navigate`
- web/static/postbox.css: Added `.nav-expand` style for subfolder toggle arrows
- core/imap_sync.py: Expanded `_FOLDER_ROLE_MAP` to cover provider variants — "Sent Items", "Deleted Items", "Sent Mail", "Bulk Mail", "Junk E-mail", etc.; fixes Internode and other non-standard IMAP servers
- core/imap_sync.py: Added `sync_all_folders_messages()` — single IMAP connection that syncs headers for every folder, not just INBOX; background loop now uses this instead of `sync_inbox`
- web/static/js/emails.js: Added `_emOffset` pagination state; reset on folder/search change; `_emLoad(append)` supports appending to existing list
- web/static/js/emails.js: Added "Load more" button (fetches next 200, appends) and "Load all" button (fetches all remaining in one request) shown when list is truncated
- web/routes/emails.py: Raised server-side message limit cap from 500 to 9999 to support Load All
- web/routes/accounts.py: Added `POST /api/sync` endpoint — triggers immediate `sync_all_folders_messages` for all active accounts in a background thread; fixed app-context bug (db() resolved on request thread, path passed to background thread)
- web/routes/accounts.py: `_initial_sync` now runs a full all-folder sync before starting the background loop, so new accounts populate all folders immediately
- web/templates/dashboard.html: Refresh button (↻) now calls `_syncAndRefresh()` — triggers `/api/sync`, reloads folder list, then refreshes current view; icon spins during sync
- web/static/postbox.css: Added `@keyframes spin` for refresh button animation
- core/imap_actions.py: New module — `mark_read`, `mark_unread`, `trash_message`, `move_message`; local DB updated first, IMAP write-back best-effort; `trash_message` uses MOVE with COPY+DELETE+expunge fallback; permanent expunge when already in trash
- web/routes/emails.py: Added `POST /api/emails/<id>/mark_read`, `mark_unread`, `trash`, `move`; removed duplicate `api_mark_read` stub that caused Flask registration error on startup
- web/static/js/emails.js: Auto-mark-read + row styling on email open; Mark Unread and Delete buttons in detail footer; `_emMarkUnread` and `_emTrash` functions; `data-msgid` attr on rows for DOM targeting
- web/static/postbox.css: Outline danger button variant (`.btn-outline.btn-danger`) for Delete button
- core/ai_client.py: Added `triage_messages()` — batch Claude Haiku call scoring messages with priority (1=urgent/2=normal/3=low) and category (invoice|support|personal|newsletter|etc); lazy `_client()` instantiation reads API key at call time, not import time
- core/credentials.py: Added `store_api_key` / `get_api_key` — keyring-backed Anthropic API key storage with env var fallback; service name `postbox_ai`
- web/routes/ai.py: Added `POST /api/ai/triage` — fetches unscored unread inbox messages, calls `triage_messages`, writes `ai_priority` + `ai_category` to DB, returns results for in-place UI update
- web/routes/emails.py: Added `priority=` filter param to `/api/emails` — server-side Urgent filter
- web/routes/accounts.py: Added `GET/POST /api/settings/ai_key` — masked key status + keyring storage
- web/static/js/emails.js: `_emPriorityFilter` state; All / ⚑ Urgent filter pills in inbox toolbar; `_emAutoTriage` fires after inbox load, updates messages in-place and re-renders; urgent rows get red left border + flag icon; category badge in subject cell
- web/static/js/accounts.js: AI Settings card at bottom of accounts page with API key input, save, and masked status display
- web/static/postbox.css: AI settings card, filter pill, priority indicator, and category badge styles
- web/static/js/emails.js: Move to… button in email detail footer; `_emMoveModal` fetches account folders, renders searchable list (search input + scrollable rows) excluding current folder and trash; `_emMoveToFolder` calls `POST /api/emails/<id>/move`, removes from list, toasts
- web/static/postbox.css: `.em-move-row` styles for folder picker modal
- core/imap_sync.py: Replaced 60s poll loop with IMAP IDLE; `_idle_watch()` enters IDLE, polls `idle_check(timeout=1)` so stop event interrupts within 1s, returns True on EXISTS/RECENT push; `_sync_loop_idle()` IDLEs on inbox for real-time new mail, reconnects every 29 min before server's 30-min timeout, full all-folder sync every 10 min; automatic 60s polling fallback for servers without IDLE capability; confirmed working against Internode (Dovecot)
- web/static/js/emails.js: HTML email iframe sandbox now includes `allow-popups` so links open in new tabs
- web/static/js/compose.js, emails.js: `composeNew()` accepts optional `accountId`; Compose button passes current account filter so new mail defaults to the active account when filtered to a single account
- core/oauth_microsoft.py, web/routes/oauth.py: Microsoft OAuth2 (XOAUTH2) — MSAL auth code flow, token storage in keyring, `/oauth/callback/microsoft` creates account and kicks off sync; no app password needed
- core/oauth_google.py, web/routes/oauth.py: Google OAuth2 (XOAUTH2) — google-auth-oauthlib Desktop app flow, bundled credentials (Thunderbird pattern), `/oauth/callback/google`; scope fix for `email` → full URI
- core/imap_sync.py, core/imap_actions.py: `_OAUTH_AUTH_TYPES` set; all sync/action functions skip password lookup for OAuth accounts; `_make_client` dispatches to `oauth2_login()` for both providers
- core/smtp_send.py: XOAUTH2 `AUTH` command for OAuth accounts (both providers); password path unchanged
- core/credentials.py: OAuth token storage (`store_oauth_tokens`/`get_oauth_tokens`/`delete_oauth_tokens`); MS client ID storage; Google client config storage (unused now — credentials bundled)
- web/routes/accounts.py: MS client ID GET/POST settings; delete route cleans up OAuth tokens
- web/static/js/accounts.js: `gmail_oauth` and `outlook_oauth` presets in provider grid; OAuth form branch in `_acctRenderForm`; `_acctStartGoogleOAuth` / `_acctStartMicrosoftOAuth`; edit panel handles OAuth accounts (no password field); MS Integration settings card
- web/templates/dashboard.html: detect `?oauth_success` / `?oauth_error` on load, show toast and navigate to accounts
- requirements.txt: added `msal>=1.29`, `google-auth-oauthlib>=1.2`, `google-auth>=2.29`
- core/database.py: raised SQLite connection timeout 10s → 30s to prevent "database is locked" errors when multiple sync threads and request handlers write concurrently
- web/routes/emails.py: removed premature `\Seen` flag write from `api_email` route — was causing `mark_read` to short-circuit before pushing flag to IMAP server; IMAP write-back now works correctly for all account types
- core/database.py: added `needs_reauth INTEGER DEFAULT 0` column to accounts table via migration
- core/imap_sync.py: `_is_auth_error()` detects OAuth/token failures; `_set_needs_reauth()` / `_clear_needs_reauth()` flag accounts; sync loop sets flag + waits 1h on auth failure, clears on successful connect; `fetch_body` and `fetch_raw` also set flag on auth errors
- web/routes/oauth.py: `_create_oauth_account` now upserts — if same email+auth_type exists, updates tokens and clears `needs_reauth` (re-auth flow) rather than inserting a duplicate; stops old sync thread and restarts
- web/routes/accounts.py: `needs_reauth` included in `/api/accounts` response
- web/static/js/accounts.js: account edit panel shows amber warning and Re-authenticate button when `needs_reauth=1`; fixed OAuth description to say Google or Microsoft correctly
- web/templates/dashboard.html: amber banner below page header shows when any account needs re-auth; `_checkReauth()` runs on load and every 5 minutes
- web/static/postbox.css: `.reauth-banner`, `.reauth-banner-close`, `.reauth-warning` styles
- core/imap_sync.py: added `fetch_raw()` — lightweight RFC822 byte fetch without storing or parsing; used for on-demand attachment extraction
- core/email_parser.py: added `extract_attachment_bytes(raw_bytes, att_index)` — extracts attachment payload by zero-based MIME walk index; strips newline characters from MIME-decoded filenames at parse time
- web/routes/emails.py: added `GET /api/emails/<mid>/attachment/<att_id>` — looks up attachment record, re-fetches RFC822 from IMAP, strips control chars from filename, streams file download via `send_file`
- web/static/js/emails.js: attachment chips in email detail view wired with `addEventListener` (not inline onclick); `_emDownloadAtt()` uses fetch+Blob URL to trigger save dialog regardless of Chrome app-mode restrictions; `_emFmtSize()` helper
- web/static/postbox.css: `.em-attachments`, `.em-att-chip`, `.em-att-size` styles for attachment bar
