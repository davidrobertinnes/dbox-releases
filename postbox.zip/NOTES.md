# Dogbox Mailman — Session Notes

## 1.0.0 released 2026-11-26

First numbered release (dbox-releases postbox.zip; the previous zip was July code). Tested first on a copy of the owner's
real postbox.pbox from ~/DogboxMailman: migrations OK, inbox/reading pane/accounts/contacts pages OK, no JS errors.
That test found the UIDNEXT fast-path bug (folders never re-synced) — fixed before release. No version number in the app
and no auto-update: installed copies (including the owner's ~/DogboxMailman, July code) update by re-running the installer.

## Ports (2026-11-05)

Starts on `"port"` in `mailman.conf` (beside mail.py), else 5200, else the next free of 10
(`core/ports.py` — keep identical to the copies in dbox and dbox-investments). `/api/alive`
returns `{"app": "dogbox-mailman"}`; Accounting finds Mailman with it. No settings page yet,
so the port setting is the conf file or `--port`. OAuth redirect URIs follow the port
(`REDIRECT_PORT`, set by mail.py). Microsoft treats localhost redirects as port-agnostic —
if a user's Azure app registration ever rejects a non-5200 port, register that port too.
Tested on a copy with an empty mailbox (5200-equivalent taken → next port; second launch
reopens the window). Not run against the real mailbox — the installed copy
(~/DogboxMailman) is older than this repo (July) and wasn't touched.

## Current state (2026-09-13)

### Session 2026-09-13 (3) — reading pane + resizable columns

- **Reading pane (Thunderbird/Outlook style)** — email list view now splits horizontally: 380px list column on left, reading pane fills remaining width; selecting a row populates the pane immediately without a slide-over; Preview/snippet column removed from list table (content now in the pane); pane shows subject header, scrollable body, pinned action buttons at bottom; empty state shown until a message is selected; `_emCloseView()` helper replaces all `detClose()` calls in email actions — handles both pane-reset and det-panel-close modes transparently; `_emShowPane()` sets up pane state before fetch; `_emRenderListOnly()` rebuilds only the list tbody+footer on `keepScroll=true` re-renders (sort, triage, mark-all-read) — pane is untouched; `emOpen()` detects pane vs. panel mode and routes accordingly; `_emRenderDetail()`, `_emRenderThread()`, `_emRenderThreadFoot()` auto-detect `em-pane-body`/`em-pane-foot` vs. `det-body`/`det-foot`; keyboard j/k now auto-advance in reading pane even without a prior open; Escape clears pane; navigate() resets `mc.style.cssText` so split layout is torn down on module change. (`web/static/js/emails.js`, `web/static/postbox.css`, `web/templates/dashboard.html`)
- **Resizable list columns** — From/Subject/Date column headers have drag handles on their right edge; dragging resizes the column live; widths persisted in localStorage and restored on next load; default widths: From=110px, Date=82px, Subject fills remaining; `table-layout:fixed` + `overflow:hidden`/`text-overflow:ellipsis` on cells prevent overflow. (`web/static/js/emails.js`, `web/static/postbox.css`)

### Session 2026-09-13 (2) — incremental IMAP sync

- **STATUS-based sync fast path** — `STATUS (MESSAGES UNSEEN UIDNEXT)` called before SELECT; folders with no new messages skip SELECT and SEARCH entirely; timing: Internode 4.3s→1.3s, Gmail 23s→13s (`core/imap_sync.py`)
- **UID-range incremental sync** — `sync_all_folders_messages` and `sync_inbox` now use `SEARCH UID {max_uid+1}:*` for folders that have existing data rather than `SEARCH ALL`; on startup when no new mail exists, no UIDs are transferred at all; only the first sync per folder uses `SEARCH ALL` (to get the initial batch); `UIDVALIDITY` is now stored per folder and checked on each sync — if the server resets it (rare, but happens with Exchange), the folder is wiped and re-fetched; `total_exists` from `SELECT_FOLDER` response replaces the second `SEARCH ALL` that was used for message count (`core/imap_sync.py`)

### Session 2026-09-13 — outbox queue (offline send)

- **Outbox queue** — messages that fail to send due to network errors are now queued rather than lost; `core/outbox.py` implements `queue_message()`, `retry_outbox()`, `get_outbox_items()`, and a `start_outbox_retry()` background loop (retries every 60 s); `outbox` + `outbox_attachments` tables added to schema (`core/database.py`); `is_network_error()` classifies SMTP failures by error string; `/api/send` queues on network error and returns `{queued:true}` instead of error (`web/routes/compose.py`); outbox blueprint + routes (`web/routes/outbox.py`): GET /api/outbox, GET /api/outbox/count, POST /api/outbox/<id>/retry, DELETE /api/outbox/<id>; retry fires SMTP and deletes row on success (max 10 attempts before marking failed); Outbox page (`web/static/js/outbox.js`): table with status badges, per-row Retry/Delete, "Retry All" toolbar button; outbox nav badge in sidebar polls every 60 s; compose.js shows "No connection — message queued" toast instead of error; CSS for `.obx-*` classes added to `postbox.css`

### Roadmap (updated 2026-09-13)
1. ✅ Print view
2. ✅ FTS5 search index
3. ✅ Packaging / website
4. ✅ Outbox queue (compose-while-disconnected send)
5. **Service worker / offline reading** — cache email bodies locally so the reader works without internet (separate from outbox)
6. **Google verification** — remove 7-day OAuth token limit and 100-user cap (blocked on CASA Tier 2)
7. **Microsoft OAuth testing** — get Azure app registered and test end-to-end

---

## Current state (2026-07-20)

### Session 2026-07-20 (4) — print view, FTS5 search, packaging

- **Print view** — "Print" button added to single-message and thread footers; `_emPrint(msg)` opens a clean standalone window (From/To/CC/Date/Subject header + full body) and fires `window.print()` automatically; dual-trigger guard (load event + 600ms timeout) handles both HTML and plain-text emails (`web/static/js/emails.js`)
- **FTS5 full-text search** — `messages_fts` virtual table (subject, from_addr, from_name, body) with `unicode61` tokeniser; triggers keep it in sync on message insert/delete and body fetch; backfill migration populated 7,799 existing messages; freetext search replaced from LIKE scan to FTS5 MATCH with prefix matching (`word*`) in `web/routes/emails.py`; `_fts_query()` helper added (`core/database.py`, `web/routes/emails.py`)
- **Packaging** — `wininstall.bat` and `macinstall.sh` created (Python detection, pip install, Desktop shortcut); `postbox.zip` built (39 files, 0.11 MB) and added to dbox-releases; `install_mailman_stub.ps1` / `.sh` stub scripts in dbox-releases; thin wrapper `.bat` / `.command` install files added to dbox-website; `mailman.html` product page created (hero, 12 features, how-it-works, pricing, 7 FAQ, download); `icon_mailman.svg` + `mailman_banner.svg` added; Mailman added to nav dropdown + products-strip in `index.html` and `investments.html`

### Roadmap (updated 2026-07-20)
1. ✅ Print view
2. ✅ FTS5 search index
3. ✅ Packaging / website
4. **Offline mode** — service worker + outbox queue for compose-while-disconnected
5. **Microsoft OAuth testing** — blocked on Azure credit card requirement

---

## Current state (2026-07-14)

### Session 2026-07-14 (7) — keyboard shortcuts, tab unread badge

- **Keyboard shortcuts** — full vim-style navigation: j/↓ next, k/↑ prev, Enter open, r reply, a reply-all, f forward, e trash, u mark-unread, n compose, / focus search, Esc close panel; j/k auto-advance through messages when panel is already open; suppressed when typing in inputs or a modal is open; listener registered on page enter, removed on re-entry to prevent duplicates; selected row gets accent outline via `.em-selected`
- **Tab unread badge** — `document.title` prefixed with `(N)` when inbox has unread messages; updates on inbox load, mark-all-read, and after opening a message; strips any existing prefix before applying new count

### Session 2026-07-20 — rules UI overhaul

- **Rules UI overhaul** — click-to-select row pattern with Edit/Delete in toolbar; active badge clickable inline to toggle; priority column + field in form; active checkbox in form; "Run Now" button applies rules to existing inbox messages and toasts result count; `@domain.com` matching in whitelist/blacklist (engine + add modal); sender_lists normalises bare domain entries on insert; DB migration adds priority column

### Session 2026-07-19 (4) — async IMAP write-back, Create Rule from email

- **Async IMAP write-back** — all user-triggered IMAP flag/move operations now return immediately after the DB commit; IMAP write fires in a background thread (best-effort); affects: `toggle_starred`, `mark_read`, `mark_unread`, `trash_message`, `bulk_move_messages`, `empty_trash`, `mark_spam`, `mark_not_spam`, `mark_all_read`, `move_message`; `threading` import hoisted to module level; `purge_old_trash` intentionally left synchronous (background maintenance job)
- **Create Rule from email** — "Create Rule" button added to both single-message and thread view footers; opens rule det-panel pre-filled with sender email, account, and auto-generated name (`From: sender@example.com`); `_rlCreateRuleFromEmail()` helper in `rules.js` loads accounts on demand so it works without visiting the Filters page first

### Session 2026-07-19 — undo trash

- **Undo trash** — `_emTrash()` now defers the IMAP call by 5 s; UI removes the message immediately; a toast with an Undo button appears; clicking Undo cancels the timer, splices the message back into `_emMessages` at its original index, and re-selects it; messages already in Trash are permanently deleted immediately (no undo); pending deferred trash is committed synchronously on folder navigation (`pageEmails`, `pageEmailsFolder`); `_emUndoToast()` helper added; `.toast-undo` / `.toast-undo-btn` CSS added to `postbox.css`; call sites cleaned up (no longer pass `btn` arg)

### Session 2026-07-19 (3) — contacts module

- **Contacts module** — address book with CRUD, search, source badges (manual/dbox/auto); contacts table with dbox_contact_id for future integration; Import from Dogbox pulls from dbox GET /api/ext/contacts (unauthenticated ext endpoint added to dbox); autocomplete in compose To/CC/BCC fields with dropdown, arrow key nav, multi-recipient support
- **dbox change** — GET /api/ext/contacts added to dbox web/routes/contacts.py (no auth, localhost trust, active contacts with email only)

### Session 2026-07-19 (2) — starred folder

- **Starred folder** — sidebar ★ Starred item below All Mail; `pageEmailsStarred()` loads all accounts/folders filtered to `is:starred`; unstarring removes message from list immediately; `_emStarredOnly` flag gates query and removal logic in row, detail footer, and thread footer star toggles

### Session 2026-07-20 (2) — dbox integration: contact email history

No postbox code changed this session. Work was entirely on the dbox side:
- **dbox: contact Emails tab** — `GET /api/contacts/<id>/emails` route added to dbox; calls Mailman `localhost:5200/api/ext/emails?contact=<email>` (stdlib urllib, 2-second timeout); returns `{emails, offline}`. "Emails" tab added to contact det-panel in dbox (only shown when contact has an email); renders subject, date, sender name, Mailman account badge, snippet; graceful "Mailman not running" offline state. (`dbox/web/routes/contacts.py`, `dbox/web/static/js/contacts.js`, `dbox/web/static/dbox.css`)
- Mailman's `GET /api/ext/emails` and `GET /api/ext/unread_count` endpoints (added in Session 2026-07-19) are now being consumed by dbox.

### Session 2026-07-20 (3) — dbox integration: unread badge

No postbox code changed this session. Work was entirely on the dbox side:
- **dbox: Mailman unread badge** — ✉ icon added to dbox sidebar footer; red badge shows unread count sourced from Mailman's `GET /api/ext/unread_count`; polls on load and every 2 minutes; badge hidden when count is zero or Mailman is offline; clicking icon opens Mailman in a new tab. New `GET /api/mailman/unread` proxy route added to dbox. (`dbox/web/templates/dashboard.html`, `dbox/web/routes/contacts.py`, `dbox/web/static/dbox.css`)

### Next items (priority order)

1. **Rules UI overhaul** — ✓ done 2026-07-20
2. **dbox unread badge** — ✓ done 2026-07-20
3. **Print email** — clean print view button in detail footer
4. **True offline mode** — service worker or local Flask cache so the app remains readable/composable when the machine has no internet; current body prefetch is server-dependent; compose queue needed for outbox-while-offline
5. **Packaging** — release bundle / installer for Dogbox Mailman
6. **Google verification** — remove 7-day OAuth token limit and 100-user cap
7. **Microsoft OAuth testing** — get Azure app registered and test end-to-end

---

### Session 2026-07-14 (6) — draft saving, thread/conversation view

- **Draft saving** — "Save Draft" button in compose footer; `POST /api/drafts` creates, `PUT /api/drafts/<id>` updates; `_draftId` tracked on modal so repeated saves update in place; sending auto-deletes the draft server-side via `draft_id` in FormData; clicking a draft message in the Drafts folder reopens compose pre-populated (BCC and reply context restored from `draft_meta` JSON); drafts stored in messages table with `\Draft` flag, inserted into Drafts folder (created if missing)
- **Thread/conversation view** — opening a message with thread siblings renders a collapsible conversation view; all messages shown chronologically as cards; most-recent message pre-expanded with full body + attachments; body lazy-fetched from IMAP on first expand of a collapsed message; footer (Reply, Reply All, Forward, AI Draft, Move, Star, Spam, Delete) updates on expand; falls back to single-message view for threads of 1; `/api/threads/<thread_id>` extended with `cc_addrs`, `folder_role`, `account_email`, `has_attachments`, `body_fetched`

### Next items (priority order)

1. **Google verification** — submit for production publishing to remove 7-day token limit and 100-user cap
2. **Remaining UX gaps** — keyboard shortcuts (j/k/r/e), undo trash, contact autocomplete, tab unread badge, starred folder, print view
3. **Packaging** — release bundle / installer for Dogbox Mailman
4. **Microsoft OAuth testing** — get Azure app registered and test end-to-end (deferred — Azure requires credit card)

---

### Session 2026-07-14 (5) — empty trash, spam/unspam, filter rules, whitelist/blacklist, read receipts, offline prefetch, import

- **Empty Trash** — `POST /api/emails/empty_trash` calls `imap_actions.empty_trash()`; IMAP EXPUNGE on trash folder; DB deletes all messages in trash for account; "Empty Trash" button in toolbar (visible in trash folder)
- **Spam / Not Spam** — `POST /api/emails/<id>/spam` and `unspam`; IMAP move to/from spam folder; contextual button in detail footer based on `msg.folder_role`; synced back to correct folder on next pull
- **Filter Rules** — `core/rules.py`: `apply_rules_to_message()` runs after sync Phase 3 for each new message; rules table with `field`, `operator`, `value`, `action`, `target_folder_id`, `is_active`; terminal actions (move/trash/spam/delete) stop chain; non-terminal (mark_read/mark_unread/star) continue; whitelist bypasses all rules; blacklist auto-spams before rules
- **Whitelist / Blacklist** — `sender_lists` table; `type` = `whitelist` or `blacklist`; matched on `from_addr` before rules are applied
- **Rules UI** — `web/static/js/rules.js`: `pageFilters()` renders two cards — Filter Rules and Sender Lists; add/edit/delete rules via det-panel form; "Filters" nav item added to dashboard; `/api/rules` and `/api/sender_lists` CRUD routes
- **Read Receipts** — `Disposition-Notification-To` header added to sent messages when "Read receipt" checkbox checked in compose; `email_parser.py` stores `receipt_to` from `Disposition-Notification-To` or `Return-Receipt-To` on inbound messages; `mark_read` checks `receipt_to` + `receipt_sent=0` and fires background `_send_mdn_and_mark()` thread; RFC 3798 compliant MDN via `smtp_send.send_mdn()`
- **Offline / Body Prefetch** — `POST /api/emails/prefetch` starts background thread fetching all unfetched bodies in a folder; `GET /api/emails/prefetch_status` polls progress; "⇙ Offline" button in toolbar polls every 3s and shows progress toast; module-level `_prefetch_state` dict keyed by folder+account
- **Import** — `web/routes/import_mail.py`: `POST /api/import` accepts `.eml` (single message) and `.mbox` (mailbox file) uploads; mbox detected by filename or `b"From "` content prefix; `_import_one()` parses with `email_parser.parse_raw()`, inserts with synthetic UID, updates uid to DB row id; accounts page has Import button with folder picker modal

### Next items (priority order)

1. **Google verification** — submit for production publishing to remove 7-day token limit and 100-user cap
2. **Microsoft OAuth testing** — get Azure app registered and test end-to-end (deferred — Azure requires credit card)

---

### Session 2026-07-14 (4) — signatures, star/flag, bulk mark-read, search operators, AI draft modal, auto-refresh

- **Signatures** — `signature TEXT` column added to accounts table (migration); edit form in accounts panel has a signature textarea; new messages auto-inject signature below a `-- ` separator; switching accounts in compose replaces the signature
- **Star/flag** — star column (☆/★) added to email list; click toggles `\\Flagged` IMAP flag without opening email; Star/Unstar button in detail footer; `is:starred` search operator supported
- **Bulk mark-read** — "✓ All read" button in toolbar (inbox and folder views); marks all visible messages read in DB and IMAP; `POST /api/emails/mark_all_read` route
- **Search operators** — `from:`, `subject:`, `has:attachment`, `is:unread`, `is:starred` now parsed server-side; freetext remainder used for full-text search as before
- **AI draft modal** — `window.prompt()` replaced with proper textarea modal; Ctrl+Enter submits; Cancel closes
- **Auto-refresh** — inbox now polls every 2 minutes for new mail and runs triage; timer cleared on folder navigation

### Next items (priority order)

1. **Google verification** — submit for production publishing to remove 7-day token limit and 100-user cap
2. **Microsoft OAuth testing** — get Azure app registered and test end-to-end (deferred — Azure requires credit card)

---

### Session 2026-07-14 (3) — compose: file attachments

- Attach button in compose footer opens file picker (multi-file supported)
- Selected files shown as removable chips above the footer
- FormData replaces JSON on send so binary data carries correctly
- Backend builds multipart/mixed with body as multipart/alternative sub-part
- Files cleared on modal open/close; backend accepts both form-data and JSON

### Session 2026-07-14 (2) — compose: CC, BCC, Reply All

- CC field added to compose modal (always visible)
- BCC field added (hidden behind "+ BCC" toggle in header)
- Reply All added — To=sender, CC=original To+CC minus own address, button in detail footer
- Modal title now reflects context: New Message / Reply / Reply All / Forward
- BCC wired through backend (smtp_send.py + compose.py); SMTP envelope only, not headers

### Session 2026-07-14 (1) — bug fixes across sync, preview panel, and flags

- DB lock contention fixed — sync functions now use three-phase pattern (read DB → IMAP → write DB); connection no longer held open during network I/O
- Junk folder was always empty — `navigate('junk')` passed `folder=junk` but DB role is `spam`; aliased in `pageEmails`
- Attachment badge false positives fixed — `_has_attachments` heuristic now skips `ALTERNATIVE` and `RELATED` subtypes; body fetch corrects `has_attachments` from actual parsed attachments
- Preview panel: AI summary/actions boxes hidden until content arrives (CSS `display:none` + JS show on load)
- Preview panel: date now shows full date+time; CC field added to meta strip; iframe height re-measured 800ms after load for images
- Thread ID chaining fixed for 3+ message chains — parent lookup resolves root thread_id
- Flags format fixed in `mark_read` (JSON parse, not substring) and `mark_unread` (dead entries removed)
- Unread row styling in JS now uses `JSON.parse(flags).includes('\\Seen')` not substring match
- DB indices added on `messages(account_id, folder_id)`, `messages(date)`, `messages(thread_id)`, `folders(role)`

### Next items (priority order)

1. **Google verification** — submit for production publishing to remove 7-day token limit and 100-user cap
2. **Microsoft OAuth testing** — get Azure app registered and test end-to-end (deferred — Azure requires credit card)

---

## Current state (2026-07-12)

### Session 2026-07-12 (2) — category filtering, bulk move, triage fallback, bug fixes

- Search focus loss fixed — focus and cursor restored after `_emRender`; 300ms debounce added
- Scroll preservation fixed — `scrollTop` now correctly restored in `_emRender(keepScroll)`
- Category filter pills in inbox toolbar — filter by invoice/support/personal/newsletter/etc
- Bulk move — "Move all N…" modal moves all messages in active category to chosen folder
- Rule-based triage fallback in `core/ai_client.py` — works without an API key
- Triage query now covers all untriaged messages, not just unread

### Session 2026-07-12 (1) — launcher rename + CLAUDE.md added

- Launcher renamed `web_server.py` → `mail.py`
- `CLAUDE.md` created — full context file covering app overview, tech stack, directory layout, web UI conventions, hard rules, and session end protocol

---

## State as of 2026-07-11

App is running and functional. All features from prior sessions are working.

### OAuth2 — implemented and tested

**Gmail OAuth2** — working end-to-end:
- Bundled Desktop app credentials (`core/oauth_google.py`) — same pattern as Thunderbird
- Google Cloud project: Dogbox Mailman, owned by dogboxsoftware@gmail.com (switched 2026-07-11)
- Consent screen: External / Testing mode — user must be listed as test user in Google Cloud Console → Audience → Test users
- Scope fix: `email` → `https://www.googleapis.com/auth/userinfo.email` (google-auth-oauthlib scope mismatch)
- IMAP XOAUTH2 via IMAPClient.oauth2_login(); SMTP XOAUTH2 via docmd AUTH
- Token refresh handled automatically in `get_valid_access_token`
- 7-day refresh token limit while in Testing mode — Google verification needed to remove

**Microsoft OAuth2** — implemented, not yet tested end-to-end:
- MSAL public client flow (no client secret needed)
- Requires user to register their own Azure app + enter client ID in MS Integration settings
- Redirect URI: `http://localhost:5200/oauth/callback/microsoft`

### Attachment download — implemented and working

- `GET /api/emails/<mid>/attachment/<att_id>` — re-fetches RFC822 from IMAP on demand, extracts attachment by index, streams as file download
- `core/imap_sync.py`: `fetch_raw()` — lightweight RFC822 fetch without storing anything
- `core/email_parser.py`: `extract_attachment_bytes(raw, index)` — extracts attachment bytes by zero-based index from MIME tree
- UI: attachment chips shown between meta strip and body in email detail view; click to download

### Re-auth flow — implemented

- `needs_reauth` column on accounts table; set when any auth/token error detected in sync loop, fetch_body, fetch_raw; cleared on successful IMAP connect or after OAuth re-auth
- Amber banner in main area shown when any account needs re-auth; checked on load + every 5 min
- Account edit panel shows warning + Re-authenticate button for affected accounts
- OAuth callback upserts tokens for existing account (same email+auth_type) rather than inserting duplicate; restarts sync thread

### Next items (priority order)

1. **Google verification** — submit for production publishing to remove 7-day token limit and 100-user cap; requires privacy policy page, CASA Tier 2 security assessment
2. **Microsoft OAuth testing** — get Azure app registered and test end-to-end (deferred — Azure requires credit card)

### Architecture

- Stack: Flask + vanilla JS + SQLite (`.pbox`)
- Port: 5200
- Auth types: `password`, `oauth_microsoft`, `oauth_google`
- OAuth tokens: keyring (`postbox_oauth` service, keyed by account_id)
- MS client ID: keyring (`postbox_ms` service)
- Google credentials: hardcoded in `core/oauth_google.py` — project owned by dogboxsoftware@gmail.com
