"""
Dogbox Mailman — AI Email Client
Flask application entry point.
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import threading
from flask import Flask, render_template, redirect, jsonify

app = Flask(
    __name__,
    static_folder=os.path.join(os.path.dirname(__file__), "static"),
    static_url_path="/static",
    template_folder=os.path.join(os.path.dirname(__file__), "templates"),
)

app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SEND_FILE_MAX_AGE_DEFAULT=0,
)
app.secret_key = b"postbox-local-only"

DB_PATH = None


@app.route("/api/alive")
def api_alive():
    # Lets a new launch (and Dogbox Accounting) tell this server from another program
    # on the port (core/ports.py)
    return jsonify({"ok": True, "data": {"app": "dogbox-mailman"}})


# ── Blueprints ──────────────────────────────────────────────────────────────────
from web.routes.accounts     import bp as accounts_bp
from web.routes.emails       import bp as emails_bp
from web.routes.compose      import bp as compose_bp
from web.routes.ai           import bp as ai_bp
from web.routes.oauth        import bp as oauth_bp
from web.routes.rules        import bp as rules_bp
from web.routes.import_mail  import bp as import_bp
from web.routes.contacts     import bp as contacts_bp
from web.routes.outbox       import bp as outbox_bp

app.register_blueprint(accounts_bp)
app.register_blueprint(emails_bp)
app.register_blueprint(compose_bp)
app.register_blueprint(ai_bp)
app.register_blueprint(oauth_bp)
app.register_blueprint(rules_bp)
app.register_blueprint(import_bp)
app.register_blueprint(contacts_bp)
app.register_blueprint(outbox_bp)


# ── Shell route ─────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("dashboard.html")


@app.route("/favicon.ico")
def favicon():
    return redirect("/static/favicon.svg")


# ── Updates (web/updater.py) ──────────────────────────────────────────────────
LAUNCH = {"host": "127.0.0.1", "port": 5200}   # set by mail.py; used to restart on the same port


@app.route("/api/system/version", methods=["GET"])
def api_system_version():
    from flask import request
    from web import updater
    from web.shared import ok
    return ok(updater.check(force=request.args.get("force") == "1"))


@app.route("/api/system/apply-update", methods=["POST"])
def api_system_apply_update():
    from web import updater
    from web.shared import ok, err
    try:
        updater.start_update()
        return ok({"started": True})
    except ValueError as e:
        return err(str(e))


@app.route("/api/system/update-progress", methods=["GET"])
def api_system_update_progress():
    from web import updater
    from web.shared import ok
    return ok(updater.progress)


@app.route("/api/system/restart", methods=["POST"])
def api_system_restart():
    from web import updater
    from web.shared import ok
    updater.restart(LAUNCH["host"], LAUNCH["port"])
    return ok({"restarting": True})


@app.route("/api/shutdown", methods=["POST"])
def shutdown():
    def _kill():
        import time, os, signal
        time.sleep(0.3)
        os.kill(os.getpid(), signal.SIGTERM)
    threading.Thread(target=_kill, daemon=True).start()
    return jsonify({"ok": True})
